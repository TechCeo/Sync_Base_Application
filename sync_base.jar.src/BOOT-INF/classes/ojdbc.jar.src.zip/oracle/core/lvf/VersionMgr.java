/*     */ package oracle.core.lvf;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class VersionMgr
/*     */ {
/*     */   public static final byte ALPHA = 1;
/*     */   public static final byte BETA = 2;
/*     */   public static final byte PROD = 3;
/*     */   public static final byte NONE = 4;
/*  55 */   private final byte MAX_LEN = 64;
/*  56 */   private final byte MAX_PRODLEN = 30;
/*  57 */   private final byte MAX_VERLEN = 15;
/*  58 */   private final byte MAX_DISTLEN = 5;
/*  59 */   private final String alpha = "Alpha";
/*  60 */   private final String beta = "Beta";
/*  61 */   private final String prod = "Production";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String version;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setVersion(String paramString1, byte paramByte1, byte paramByte2, byte paramByte3, byte paramByte4, byte paramByte5, char paramChar, String paramString2, byte paramByte6, int paramInt) {
/*     */     String str1;
/*  86 */     char[] arrayOfChar = new char[64];
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  91 */     String str2 = "";
/*     */     
/*     */     byte b3;
/*  94 */     if ((b3 = (byte)paramString1.length()) > 30) {
/*  95 */       b3 = 30;
/*     */     }
/*     */     
/*  98 */     byte b2 = 0;
/*  99 */     for (b3 = (byte)(b3 - 1); 0 < b3; ) {
/*     */       
/* 101 */       arrayOfChar[b2] = paramString1.charAt(b2);
/* 102 */       b2 = (byte)(b2 + 1);
/*     */     } 
/*     */ 
/*     */     
/* 106 */     b2 = (byte)(b2 + 1); arrayOfChar[b2] = '\t';
/*     */ 
/*     */     
/* 109 */     if (paramByte1 < 0)
/* 110 */       paramByte1 = 0; 
/* 111 */     if (paramByte2 < 0)
/* 112 */       paramByte2 = 0; 
/* 113 */     if (paramByte3 < 0)
/* 114 */       paramByte3 = 0; 
/* 115 */     if (paramByte4 < 0)
/* 116 */       paramByte4 = 0; 
/* 117 */     if (paramByte5 < 0) {
/* 118 */       paramByte5 = 0;
/*     */     }
/*     */     
/* 121 */     if (paramByte1 > 99)
/* 122 */       paramByte1 = 99; 
/* 123 */     if (paramByte2 > 99)
/* 124 */       paramByte2 = 99; 
/* 125 */     if (paramByte3 > 99)
/* 126 */       paramByte3 = 99; 
/* 127 */     if (paramByte4 > 99)
/* 128 */       paramByte4 = 99; 
/* 129 */     if (paramByte5 > 99) {
/* 130 */       paramByte5 = 99;
/*     */     }
/*     */     
/* 133 */     if (paramChar != '\000') {
/* 134 */       str1 = paramByte1 + "." + paramByte2 + "." + paramByte3 + "." + paramByte4 + "." + paramByte5 + paramChar;
/*     */     } else {
/* 136 */       str1 = paramByte1 + "." + paramByte2 + "." + paramByte3 + "." + paramByte4 + "." + paramByte5;
/* 137 */     }  byte b4 = (byte)str1.length();
/*     */ 
/*     */     
/* 140 */     byte b1 = 0;
/* 141 */     for (b4 = (byte)(b4 - 1); 0 < b4; ) {
/* 142 */       b2 = (byte)(b2 + 1); b1 = (byte)(b1 + 1); arrayOfChar[b2] = str1.charAt(b1);
/*     */     } 
/* 144 */     if (paramByte6 != 4) {
/*     */ 
/*     */       
/* 147 */       b2 = (byte)(b2 + 1); arrayOfChar[b2] = '\t';
/*     */       
/* 149 */       if (paramString2 != null) {
/*     */         
/* 151 */         byte b5 = 0;
/*     */ 
/*     */         
/* 154 */         if ((b5 = (byte)paramString2.length()) > 5) {
/* 155 */           b5 = 5;
/*     */         }
/*     */         
/* 158 */         b1 = 0;
/* 159 */         for (b5 = (byte)(b5 - 1); 0 < b5; ) {
/* 160 */           b2 = (byte)(b2 + 1); b1 = (byte)(b1 + 1); arrayOfChar[b2] = paramString2.charAt(b1);
/*     */         } 
/*     */         
/* 163 */         b2 = (byte)(b2 + 1); arrayOfChar[b2] = '\t';
/*     */       } 
/*     */ 
/*     */       
/* 167 */       switch (paramByte6) {
/*     */         
/*     */         case 1:
/* 170 */           str2 = "Alpha";
/*     */           break;
/*     */         case 2:
/* 173 */           str2 = "Beta";
/*     */           break;
/*     */         case 3:
/* 176 */           str2 = "Production";
/*     */           break;
/*     */       } 
/*     */       
/* 180 */       b1 = 0;
/* 181 */       byte b = (byte)str2.length();
/*     */ 
/*     */       
/* 184 */       for (b = (byte)(b - 1); 0 < b; ) {
/* 185 */         b2 = (byte)(b2 + 1); b1 = (byte)(b1 + 1); arrayOfChar[b2] = str2.charAt(b1);
/*     */       } 
/*     */     } 
/*     */     
/* 189 */     this.version = new String(arrayOfChar, 0, b2);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getVersion() {
/* 198 */     return this.version;
/*     */   }
/*     */ }


/* Location:              C:\Users\olatu\OneDrive\Documents\Calypso\syncbase\sync_base.jar!\BOOT-INF\classes\ojdbc.jar!\oracle\core\lvf\VersionMgr.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */