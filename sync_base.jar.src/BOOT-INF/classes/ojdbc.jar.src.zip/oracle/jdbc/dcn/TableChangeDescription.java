/*     */ package oracle.jdbc.dcn;
/*     */ 
/*     */ import java.util.EnumSet;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public interface TableChangeDescription
/*     */ {
/*     */   EnumSet<TableOperation> getTableOperations();
/*     */   
/*     */   String getTableName();
/*     */   
/*     */   int getObjectNumber();
/*     */   
/*     */   RowChangeDescription[] getRowChangeDescription();
/*     */   
/*     */   public enum TableOperation
/*     */   {
/*  57 */     ALL_ROWS(1),
/*     */ 
/*     */ 
/*     */     
/*  61 */     INSERT(2),
/*     */ 
/*     */ 
/*     */     
/*  65 */     UPDATE(4),
/*     */ 
/*     */ 
/*     */     
/*  69 */     DELETE(8),
/*     */ 
/*     */ 
/*     */     
/*  73 */     ALTER(16),
/*     */ 
/*     */ 
/*     */     
/*  77 */     DROP(32);
/*     */     private final int code;
/*     */     
/*     */     TableOperation(int param1Int1) {
/*  81 */       this.code = param1Int1;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final int getCode() {
/*  88 */       return this.code;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public static final EnumSet<TableOperation> getTableOperations(int param1Int) {
/*  95 */       EnumSet<TableOperation> enumSet = EnumSet.noneOf(TableOperation.class);
/*  96 */       if ((param1Int & ALL_ROWS.getCode()) != 0)
/*  97 */         enumSet.add(ALL_ROWS); 
/*  98 */       if ((param1Int & INSERT.getCode()) != 0)
/*  99 */         enumSet.add(INSERT); 
/* 100 */       if ((param1Int & UPDATE.getCode()) != 0)
/* 101 */         enumSet.add(UPDATE); 
/* 102 */       if ((param1Int & DELETE.getCode()) != 0)
/* 103 */         enumSet.add(DELETE); 
/* 104 */       if ((param1Int & ALTER.getCode()) != 0)
/* 105 */         enumSet.add(ALTER); 
/* 106 */       if ((param1Int & DROP.getCode()) != 0)
/* 107 */         enumSet.add(DROP); 
/* 108 */       return enumSet;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\olatu\OneDrive\Documents\Calypso\syncbase\sync_base.jar!\BOOT-INF\classes\ojdbc.jar!\oracle\jdbc\dcn\TableChangeDescription.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */