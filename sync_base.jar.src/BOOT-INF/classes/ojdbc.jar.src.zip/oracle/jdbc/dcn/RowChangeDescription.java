/*    */ package oracle.jdbc.dcn;
/*    */ 
/*    */ import oracle.sql.ROWID;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public interface RowChangeDescription
/*    */ {
/*    */   RowOperation getRowOperation();
/*    */   
/*    */   ROWID getRowid();
/*    */   
/*    */   public enum RowOperation
/*    */   {
/* 47 */     INSERT(TableChangeDescription.TableOperation.INSERT.getCode()),
/*    */ 
/*    */ 
/*    */     
/* 51 */     UPDATE(TableChangeDescription.TableOperation.UPDATE.getCode()),
/*    */ 
/*    */ 
/*    */     
/* 55 */     DELETE(TableChangeDescription.TableOperation.DELETE.getCode());
/*    */     private final int code;
/*    */     
/*    */     RowOperation(int param1Int1) {
/* 59 */       this.code = param1Int1;
/*    */     }
/*    */ 
/*    */ 
/*    */ 
/*    */     
/*    */     public final int getCode() {
/* 66 */       return this.code;
/*    */     }
/*    */ 
/*    */ 
/*    */ 
/*    */     
/*    */     public static final RowOperation getRowOperation(int param1Int) {
/* 73 */       if (param1Int == INSERT.getCode())
/* 74 */         return INSERT; 
/* 75 */       if (param1Int == UPDATE.getCode()) {
/* 76 */         return UPDATE;
/*    */       }
/* 78 */       return DELETE;
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\olatu\OneDrive\Documents\Calypso\syncbase\sync_base.jar!\BOOT-INF\classes\ojdbc.jar!\oracle\jdbc\dcn\RowChangeDescription.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */