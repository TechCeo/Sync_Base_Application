/*     */ package oracle.jdbc.dcn;
/*     */ 
/*     */ import java.util.EventObject;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class DatabaseChangeEvent
/*     */   extends EventObject
/*     */ {
/*     */   protected DatabaseChangeEvent(Object paramObject) {
/*  49 */     super(paramObject);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public enum EventType
/*     */   {
/*  59 */     NONE(0),
/*     */ 
/*     */ 
/*     */     
/*  63 */     STARTUP(1),
/*     */ 
/*     */ 
/*     */     
/*  67 */     SHUTDOWN(2),
/*     */ 
/*     */ 
/*     */     
/*  71 */     SHUTDOWN_ANY(3),
/*     */ 
/*     */ 
/*     */     
/*  75 */     DEREG(5),
/*     */ 
/*     */ 
/*     */     
/*  79 */     OBJCHANGE(6),
/*     */ 
/*     */ 
/*     */     
/*  83 */     QUERYCHANGE(7);
/*     */     
/*     */     private final int code;
/*     */     
/*     */     EventType(int param1Int1) {
/*  88 */       this.code = param1Int1;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final int getCode() {
/*  96 */       return this.code;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public static final EventType getEventType(int param1Int) {
/* 103 */       if (param1Int == STARTUP.getCode())
/* 104 */         return STARTUP; 
/* 105 */       if (param1Int == SHUTDOWN.getCode())
/* 106 */         return SHUTDOWN; 
/* 107 */       if (param1Int == SHUTDOWN_ANY.getCode())
/* 108 */         return SHUTDOWN_ANY; 
/* 109 */       if (param1Int == DEREG.getCode())
/* 110 */         return DEREG; 
/* 111 */       if (param1Int == OBJCHANGE.getCode())
/* 112 */         return OBJCHANGE; 
/* 113 */       if (param1Int == QUERYCHANGE.getCode()) {
/* 114 */         return QUERYCHANGE;
/*     */       }
/* 116 */       return NONE;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public enum AdditionalEventType
/*     */   {
/* 131 */     NONE(0),
/*     */ 
/*     */ 
/*     */     
/* 135 */     TIMEOUT(1),
/*     */ 
/*     */ 
/*     */     
/* 139 */     GROUPING(2);
/*     */     
/*     */     private final int code;
/*     */ 
/*     */     
/*     */     AdditionalEventType(int param1Int1) {
/* 145 */       this.code = param1Int1;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final int getCode() {
/* 153 */       return this.code;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public static final AdditionalEventType getEventType(int param1Int) {
/* 160 */       if (param1Int == TIMEOUT.getCode())
/* 161 */         return TIMEOUT; 
/* 162 */       if (param1Int == GROUPING.getCode()) {
/* 163 */         return GROUPING;
/*     */       }
/* 165 */       return NONE;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 256 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*     */   public static final String BUILD_DATE = "Thu_Apr_04_15:09:24_PDT_2013";
/*     */   public static final boolean TRACE = false;
/*     */   
/*     */   public abstract EventType getEventType();
/*     */   
/*     */   public abstract AdditionalEventType getAdditionalEventType();
/*     */   
/*     */   public abstract TableChangeDescription[] getTableChangeDescription();
/*     */   
/*     */   public abstract QueryChangeDescription[] getQueryChangeDescription();
/*     */   
/*     */   public abstract String getConnectionInformation();
/*     */   
/*     */   public abstract String getDatabaseName();
/*     */   
/*     */   public abstract int getRegistrationId();
/*     */   
/*     */   public abstract long getRegId();
/*     */   
/*     */   public abstract byte[] getTransactionId();
/*     */   
/*     */   public abstract String getTransactionId(boolean paramBoolean);
/*     */   
/*     */   public abstract String toString();
/*     */ }


/* Location:              C:\Users\olatu\OneDrive\Documents\Calypso\syncbase\sync_base.jar!\BOOT-INF\classes\ojdbc.jar!\oracle\jdbc\dcn\DatabaseChangeEvent.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */