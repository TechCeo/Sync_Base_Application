/*    */ package oracle.jdbc.aq;
/*    */ 
/*    */ import java.sql.SQLException;
/*    */ import oracle.jdbc.driver.InternalFactory;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class AQFactory
/*    */ {
/*    */   public static AQMessage createAQMessage(AQMessageProperties paramAQMessageProperties) throws SQLException {
/* 50 */     return (AQMessage)InternalFactory.createAQMessage(paramAQMessageProperties);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static AQMessageProperties createAQMessageProperties() throws SQLException {
/* 61 */     return (AQMessageProperties)InternalFactory.createAQMessageProperties();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static AQAgent createAQAgent() throws SQLException {
/* 71 */     return (AQAgent)InternalFactory.createAQAgent();
/*    */   }
/*    */ 
/*    */   
/* 75 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*    */   public static final String BUILD_DATE = "Thu_Apr_04_15:09:24_PDT_2013";
/*    */   public static final boolean TRACE = false;
/*    */ }


/* Location:              C:\Users\olatu\OneDrive\Documents\Calypso\syncbase\sync_base.jar!\BOOT-INF\classes\ojdbc.jar!\oracle\jdbc\aq\AQFactory.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */