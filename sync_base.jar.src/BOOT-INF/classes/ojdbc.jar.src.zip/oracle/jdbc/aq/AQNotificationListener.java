package oracle.jdbc.aq;

import java.util.EventListener;

public interface AQNotificationListener extends EventListener {
  void onAQNotification(AQNotificationEvent paramAQNotificationEvent);
}


/* Location:              C:\Users\olatu\OneDrive\Documents\Calypso\syncbase\sync_base.jar!\BOOT-INF\classes\ojdbc.jar!\oracle\jdbc\aq\AQNotificationListener.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */