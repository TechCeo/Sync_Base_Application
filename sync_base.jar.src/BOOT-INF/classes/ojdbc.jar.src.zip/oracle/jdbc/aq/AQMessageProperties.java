/*     */ package oracle.jdbc.aq;
/*     */ 
/*     */ import java.sql.SQLException;
/*     */ import java.sql.Timestamp;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public interface AQMessageProperties
/*     */ {
/*     */   public static final int MESSAGE_NO_DELAY = 0;
/*     */   public static final int MESSAGE_NO_EXPIRATION = -1;
/*     */   
/*     */   int getDequeueAttemptsCount();
/*     */   
/*     */   void setCorrelation(String paramString) throws SQLException;
/*     */   
/*     */   String getCorrelation();
/*     */   
/*     */   void setDelay(int paramInt) throws SQLException;
/*     */   
/*     */   int getDelay();
/*     */   
/*     */   Timestamp getEnqueueTime();
/*     */   
/*     */   void setExceptionQueue(String paramString) throws SQLException;
/*     */   
/*     */   String getExceptionQueue();
/*     */   
/*     */   void setExpiration(int paramInt) throws SQLException;
/*     */   
/*     */   int getExpiration();
/*     */   
/*     */   MessageState getState();
/*     */   
/*     */   void setPriority(int paramInt) throws SQLException;
/*     */   
/*     */   int getPriority();
/*     */   
/*     */   void setRecipientList(AQAgent[] paramArrayOfAQAgent) throws SQLException;
/*     */   
/*     */   AQAgent[] getRecipientList();
/*     */   
/*     */   void setSender(AQAgent paramAQAgent) throws SQLException;
/*     */   
/*     */   AQAgent getSender();
/*     */   
/*     */   String getTransactionGroup();
/*     */   
/*     */   byte[] getPreviousQueueMessageId();
/*     */   
/*     */   DeliveryMode getDeliveryMode();
/*     */   
/*     */   String toString();
/*     */   
/*     */   public enum MessageState
/*     */   {
/*  72 */     WAITING(1),
/*     */ 
/*     */ 
/*     */     
/*  76 */     READY(0),
/*     */ 
/*     */ 
/*     */     
/*  80 */     PROCESSED(2),
/*     */ 
/*     */ 
/*     */     
/*  84 */     EXPIRED(3);
/*     */     private final int code;
/*     */     
/*     */     MessageState(int param1Int1) {
/*  88 */       this.code = param1Int1;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final int getCode() {
/*  96 */       return this.code;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public static final MessageState getMessageState(int param1Int) {
/* 104 */       if (param1Int == WAITING.getCode())
/* 105 */         return WAITING; 
/* 106 */       if (param1Int == READY.getCode())
/* 107 */         return READY; 
/* 108 */       if (param1Int == PROCESSED.getCode()) {
/* 109 */         return PROCESSED;
/*     */       }
/* 111 */       return EXPIRED;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public enum DeliveryMode
/*     */   {
/* 121 */     PERSISTENT(1),
/*     */ 
/*     */ 
/*     */     
/* 125 */     BUFFERED(2);
/*     */     private final int code;
/*     */     
/*     */     DeliveryMode(int param1Int1) {
/* 129 */       this.code = param1Int1;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final int getCode() {
/* 137 */       return this.code;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public static final DeliveryMode getDeliveryMode(int param1Int) {
/* 145 */       if (param1Int == BUFFERED.getCode()) {
/* 146 */         return BUFFERED;
/*     */       }
/* 148 */       return PERSISTENT;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\olatu\OneDrive\Documents\Calypso\syncbase\sync_base.jar!\BOOT-INF\classes\ojdbc.jar!\oracle\jdbc\aq\AQMessageProperties.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */