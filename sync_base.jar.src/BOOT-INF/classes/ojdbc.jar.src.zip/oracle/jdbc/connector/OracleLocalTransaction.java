/*     */ package oracle.jdbc.connector;
/*     */ 
/*     */ import java.sql.Connection;
/*     */ import java.sql.SQLException;
/*     */ import javax.resource.ResourceException;
/*     */ import javax.resource.spi.EISSystemException;
/*     */ import javax.resource.spi.IllegalStateException;
/*     */ import javax.resource.spi.LocalTransaction;
/*     */ import javax.resource.spi.LocalTransactionException;
/*     */ import oracle.jdbc.internal.OracleConnection;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class OracleLocalTransaction
/*     */   implements LocalTransaction
/*     */ {
/*  30 */   private OracleManagedConnection managedConnection = null;
/*  31 */   private Connection connection = null;
/*     */ 
/*     */   
/*     */   boolean isBeginCalled = false;
/*     */ 
/*     */   
/*     */   private static final String RAERR_LTXN_COMMIT = "commit without begin";
/*     */   
/*     */   private static final String RAERR_LTXN_ROLLBACK = "rollback without begin";
/*     */ 
/*     */   
/*     */   OracleLocalTransaction(OracleManagedConnection paramOracleManagedConnection) throws ResourceException {
/*  43 */     this.managedConnection = paramOracleManagedConnection;
/*  44 */     this.connection = paramOracleManagedConnection.getPhysicalConnection();
/*  45 */     this.isBeginCalled = false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void begin() throws ResourceException {
/*     */     try {
/*  74 */       if (((OracleConnection)this.connection).getTxnMode() == 1)
/*     */       {
/*     */         
/*  77 */         throw new IllegalStateException("Could not start a new transaction inside an active transaction");
/*     */       }
/*     */       
/*  80 */       if (this.connection.getAutoCommit()) {
/*  81 */         this.connection.setAutoCommit(false);
/*     */       }
/*  83 */       this.isBeginCalled = true;
/*     */     
/*     */     }
/*  86 */     catch (SQLException sQLException) {
/*     */       
/*  88 */       EISSystemException eISSystemException = new EISSystemException("SQLException: " + sQLException.getMessage());
/*     */ 
/*     */       
/*  91 */       eISSystemException.setLinkedException(sQLException);
/*     */       
/*  93 */       throw eISSystemException;
/*     */     } 
/*     */ 
/*     */     
/*  97 */     this.managedConnection.eventOccurred(2);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void commit() throws ResourceException {
/* 121 */     if (!this.isBeginCalled) {
/* 122 */       throw new LocalTransactionException("begin() must be called before commit()", "commit without begin");
/*     */     }
/*     */     
/*     */     try {
/* 126 */       this.connection.commit();
/*     */     
/*     */     }
/* 129 */     catch (SQLException sQLException) {
/*     */       
/* 131 */       EISSystemException eISSystemException = new EISSystemException("SQLException: " + sQLException.getMessage());
/*     */ 
/*     */       
/* 134 */       eISSystemException.setLinkedException(sQLException);
/*     */       
/* 136 */       throw eISSystemException;
/*     */     } 
/*     */ 
/*     */     
/* 140 */     this.isBeginCalled = false;
/*     */     
/* 142 */     this.managedConnection.eventOccurred(3);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void rollback() throws ResourceException {
/* 166 */     if (!this.isBeginCalled) {
/* 167 */       throw new LocalTransactionException("begin() must be called before rollback()", "rollback without begin");
/*     */     }
/*     */     
/*     */     try {
/* 171 */       this.connection.rollback();
/*     */     
/*     */     }
/* 174 */     catch (SQLException sQLException) {
/*     */       
/* 176 */       EISSystemException eISSystemException = new EISSystemException("SQLException: " + sQLException.getMessage());
/*     */ 
/*     */       
/* 179 */       eISSystemException.setLinkedException(sQLException);
/*     */       
/* 181 */       throw eISSystemException;
/*     */     } 
/*     */ 
/*     */     
/* 185 */     this.isBeginCalled = false;
/*     */     
/* 187 */     this.managedConnection.eventOccurred(4);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 193 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*     */   public static final String BUILD_DATE = "Thu_Apr_04_15:09:24_PDT_2013";
/*     */   public static final boolean TRACE = false;
/*     */ }


/* Location:              C:\Users\olatu\OneDrive\Documents\Calypso\syncbase\sync_base.jar!\BOOT-INF\classes\ojdbc.jar!\oracle\jdbc\connector\OracleLocalTransaction.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */