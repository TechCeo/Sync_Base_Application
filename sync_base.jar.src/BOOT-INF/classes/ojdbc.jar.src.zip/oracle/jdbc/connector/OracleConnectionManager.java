/*    */ package oracle.jdbc.connector;
/*    */ 
/*    */ import javax.resource.ResourceException;
/*    */ import javax.resource.spi.ConnectionManager;
/*    */ import javax.resource.spi.ConnectionRequestInfo;
/*    */ import javax.resource.spi.ManagedConnection;
/*    */ import javax.resource.spi.ManagedConnectionFactory;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class OracleConnectionManager
/*    */   implements ConnectionManager
/*    */ {
/*    */   public Object allocateConnection(ManagedConnectionFactory paramManagedConnectionFactory, ConnectionRequestInfo paramConnectionRequestInfo) throws ResourceException {
/* 71 */     ManagedConnection managedConnection = paramManagedConnectionFactory.createManagedConnection(null, paramConnectionRequestInfo);
/*    */     
/* 73 */     return managedConnection.getConnection(null, paramConnectionRequestInfo);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/* 78 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*    */   public static final String BUILD_DATE = "Thu_Apr_04_15:09:24_PDT_2013";
/*    */   public static final boolean TRACE = false;
/*    */ }


/* Location:              C:\Users\olatu\OneDrive\Documents\Calypso\syncbase\sync_base.jar!\BOOT-INF\classes\ojdbc.jar!\oracle\jdbc\connector\OracleConnectionManager.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */