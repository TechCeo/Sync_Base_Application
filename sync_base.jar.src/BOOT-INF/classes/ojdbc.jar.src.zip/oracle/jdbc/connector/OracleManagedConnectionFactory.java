/*     */ package oracle.jdbc.connector;
/*     */ 
/*     */ import java.io.PrintWriter;
/*     */ import java.sql.SQLException;
/*     */ import java.util.Iterator;
/*     */ import java.util.Properties;
/*     */ import java.util.Set;
/*     */ import javax.naming.InitialContext;
/*     */ import javax.naming.NamingException;
/*     */ import javax.resource.ResourceException;
/*     */ import javax.resource.spi.ConnectionManager;
/*     */ import javax.resource.spi.ConnectionRequestInfo;
/*     */ import javax.resource.spi.EISSystemException;
/*     */ import javax.resource.spi.ManagedConnection;
/*     */ import javax.resource.spi.ManagedConnectionFactory;
/*     */ import javax.resource.spi.ResourceAdapterInternalException;
/*     */ import javax.resource.spi.SecurityException;
/*     */ import javax.resource.spi.security.PasswordCredential;
/*     */ import javax.security.auth.Subject;
/*     */ import javax.sql.XAConnection;
/*     */ import javax.sql.XADataSource;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class OracleManagedConnectionFactory
/*     */   implements ManagedConnectionFactory
/*     */ {
/*  42 */   private XADataSource xaDataSource = null;
/*  43 */   private String xaDataSourceName = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final String RAERR_MCF_SET_XADS = "invalid xads";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final String RAERR_MCF_GET_PCRED = "no password credential";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public OracleManagedConnectionFactory() throws ResourceException {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public OracleManagedConnectionFactory(XADataSource paramXADataSource) throws ResourceException {
/*  73 */     this.xaDataSource = paramXADataSource;
/*  74 */     this.xaDataSourceName = "XADataSource";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setXADataSourceName(String paramString) {
/*  88 */     this.xaDataSourceName = paramString;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getXADataSourceName() {
/* 102 */     return this.xaDataSourceName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object createConnectionFactory(ConnectionManager paramConnectionManager) throws ResourceException {
/* 127 */     if (this.xaDataSource == null)
/*     */     {
/* 129 */       setupXADataSource();
/*     */     }
/*     */     
/* 132 */     return this.xaDataSource;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object createConnectionFactory() throws ResourceException {
/* 155 */     return createConnectionFactory(null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ManagedConnection createManagedConnection(Subject paramSubject, ConnectionRequestInfo paramConnectionRequestInfo) throws ResourceException {
/*     */     try {
/* 185 */       if (this.xaDataSource == null)
/*     */       {
/* 187 */         setupXADataSource();
/*     */       }
/*     */       
/* 190 */       XAConnection xAConnection = null;
/* 191 */       PasswordCredential passwordCredential = getPasswordCredential(paramSubject, paramConnectionRequestInfo);
/*     */       
/* 193 */       if (passwordCredential == null) {
/*     */         
/* 195 */         xAConnection = this.xaDataSource.getXAConnection();
/*     */       }
/*     */       else {
/*     */         
/* 199 */         xAConnection = this.xaDataSource.getXAConnection(passwordCredential.getUserName(), new String(passwordCredential.getPassword()));
/*     */       } 
/*     */ 
/*     */       
/* 203 */       OracleManagedConnection oracleManagedConnection = new OracleManagedConnection(xAConnection);
/*     */       
/* 205 */       oracleManagedConnection.setPasswordCredential(passwordCredential);
/*     */ 
/*     */       
/* 208 */       oracleManagedConnection.setLogWriter(getLogWriter());
/*     */       
/* 210 */       return oracleManagedConnection;
/*     */     }
/* 212 */     catch (SQLException sQLException) {
/*     */       
/* 214 */       EISSystemException eISSystemException = new EISSystemException("SQLException: " + sQLException.getMessage());
/*     */ 
/*     */       
/* 217 */       eISSystemException.setLinkedException(sQLException);
/*     */       
/* 219 */       throw eISSystemException;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ManagedConnection matchManagedConnections(Set paramSet, Subject paramSubject, ConnectionRequestInfo paramConnectionRequestInfo) throws ResourceException {
/* 252 */     PasswordCredential passwordCredential = getPasswordCredential(paramSubject, paramConnectionRequestInfo);
/* 253 */     Iterator<Object> iterator = paramSet.iterator();
/*     */     
/* 255 */     while (iterator.hasNext()) {
/*     */       
/* 257 */       OracleManagedConnection oracleManagedConnection = (OracleManagedConnection)iterator.next();
/*     */       
/* 259 */       if (oracleManagedConnection instanceof OracleManagedConnection) {
/*     */         
/* 261 */         OracleManagedConnection oracleManagedConnection1 = oracleManagedConnection;
/*     */ 
/*     */         
/* 264 */         if (oracleManagedConnection1.getPasswordCredential().equals(passwordCredential))
/*     */         {
/* 266 */           return oracleManagedConnection1;
/*     */         }
/*     */       } 
/*     */     } 
/*     */     
/* 271 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setLogWriter(PrintWriter paramPrintWriter) throws ResourceException {
/*     */     try {
/* 296 */       if (this.xaDataSource == null)
/*     */       {
/* 298 */         setupXADataSource();
/*     */       }
/*     */       
/* 301 */       this.xaDataSource.setLogWriter(paramPrintWriter);
/*     */     }
/* 303 */     catch (SQLException sQLException) {
/*     */ 
/*     */ 
/*     */       
/* 307 */       EISSystemException eISSystemException = new EISSystemException("SQLException: " + sQLException.getMessage());
/*     */ 
/*     */       
/* 310 */       eISSystemException.setLinkedException(sQLException);
/*     */       
/* 312 */       throw eISSystemException;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PrintWriter getLogWriter() throws ResourceException {
/*     */     try {
/* 337 */       if (this.xaDataSource == null)
/*     */       {
/* 339 */         setupXADataSource();
/*     */       }
/*     */       
/* 342 */       return this.xaDataSource.getLogWriter();
/*     */     }
/* 344 */     catch (SQLException sQLException) {
/*     */ 
/*     */ 
/*     */       
/* 348 */       EISSystemException eISSystemException = new EISSystemException("SQLException: " + sQLException.getMessage());
/*     */ 
/*     */       
/* 351 */       eISSystemException.setLinkedException(sQLException);
/*     */       
/* 353 */       throw eISSystemException;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void setupXADataSource() throws ResourceException {
/*     */     try {
/* 400 */       InitialContext initialContext = null;
/*     */ 
/*     */       
/*     */       try {
/* 404 */         Properties properties = System.getProperties();
/*     */         
/* 406 */         initialContext = new InitialContext(properties);
/*     */       }
/* 408 */       catch (SecurityException securityException) {}
/*     */ 
/*     */ 
/*     */       
/* 412 */       if (initialContext == null)
/*     */       {
/* 414 */         initialContext = new InitialContext();
/*     */       }
/*     */       
/* 417 */       XADataSource xADataSource = (XADataSource)initialContext.lookup(this.xaDataSourceName);
/*     */       
/* 419 */       if (xADataSource == null)
/*     */       {
/* 421 */         throw new ResourceAdapterInternalException("Invalid XADataSource object");
/*     */       }
/*     */       
/* 424 */       this.xaDataSource = xADataSource;
/*     */     }
/* 426 */     catch (NamingException namingException) {
/*     */       
/* 428 */       ResourceException resourceException = new ResourceException("NamingException: " + namingException.getMessage());
/*     */ 
/*     */       
/* 431 */       resourceException.setLinkedException(namingException);
/*     */       
/* 433 */       throw resourceException;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private PasswordCredential getPasswordCredential(Subject paramSubject, ConnectionRequestInfo paramConnectionRequestInfo) throws ResourceException {
/* 446 */     if (paramSubject != null) {
/*     */ 
/*     */ 
/*     */       
/* 450 */       Set<PasswordCredential> set = paramSubject.getPrivateCredentials(PasswordCredential.class);
/* 451 */       Iterator<PasswordCredential> iterator = set.iterator();
/*     */       
/* 453 */       while (iterator.hasNext()) {
/*     */         
/* 455 */         PasswordCredential passwordCredential1 = iterator.next();
/*     */         
/* 457 */         if (passwordCredential1.getManagedConnectionFactory().equals(this))
/*     */         {
/* 459 */           return passwordCredential1;
/*     */         }
/*     */       } 
/*     */       
/* 463 */       throw new SecurityException("Can not find user/password information", "no password credential");
/*     */     } 
/*     */ 
/*     */     
/* 467 */     if (paramConnectionRequestInfo == null)
/*     */     {
/* 469 */       return null;
/*     */     }
/*     */ 
/*     */     
/* 473 */     OracleConnectionRequestInfo oracleConnectionRequestInfo = (OracleConnectionRequestInfo)paramConnectionRequestInfo;
/*     */     
/* 475 */     PasswordCredential passwordCredential = new PasswordCredential(oracleConnectionRequestInfo.getUser(), oracleConnectionRequestInfo.getPassword().toCharArray());
/*     */ 
/*     */     
/* 478 */     passwordCredential.setManagedConnectionFactory(this);
/*     */     
/* 480 */     return passwordCredential;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 489 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*     */   public static final String BUILD_DATE = "Thu_Apr_04_15:09:24_PDT_2013";
/*     */   public static final boolean TRACE = false;
/*     */ }


/* Location:              C:\Users\olatu\OneDrive\Documents\Calypso\syncbase\sync_base.jar!\BOOT-INF\classes\ojdbc.jar!\oracle\jdbc\connector\OracleManagedConnectionFactory.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */