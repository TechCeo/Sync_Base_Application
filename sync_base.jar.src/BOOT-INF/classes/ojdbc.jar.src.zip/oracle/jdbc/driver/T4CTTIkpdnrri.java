/*    */ package oracle.jdbc.driver;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.sql.SQLException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class T4CTTIkpdnrri
/*    */ {
/*    */   byte[] kpdnrrinm;
/*    */   T4CMAREngine mar;
/*    */   
/*    */   T4CTTIkpdnrri(T4CConnection paramT4CConnection) {
/* 36 */     this.mar = paramT4CConnection.mare;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   void receive() throws SQLException, IOException {
/* 43 */     int i = this.mar.unmarshalSWORD();
/* 44 */     if (i > 0) {
/* 45 */       this.kpdnrrinm = new byte[i];
/* 46 */       int[] arrayOfInt = new int[1];
/*    */ 
/*    */       
/* 49 */       this.mar.unmarshalCLR(this.kpdnrrinm, 0, arrayOfInt, i);
/*    */     } else {
/*    */       
/* 52 */       this.kpdnrrinm = null;
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   byte[] getKpdnrrinm() {
/* 59 */     return this.kpdnrrinm;
/*    */   }
/*    */ 
/*    */   
/* 63 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*    */   public static final String BUILD_DATE = "Thu_Apr_04_15:09:24_PDT_2013";
/*    */   public static final boolean TRACE = false;
/*    */ }


/* Location:              C:\Users\olatu\OneDrive\Documents\Calypso\syncbase\sync_base.jar!\BOOT-INF\classes\ojdbc.jar!\oracle\jdbc\driver\T4CTTIkpdnrri.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */