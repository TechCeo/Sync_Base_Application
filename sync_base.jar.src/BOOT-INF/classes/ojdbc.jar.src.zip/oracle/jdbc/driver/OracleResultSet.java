/*      */ package oracle.jdbc.driver;
/*      */ 
/*      */ import java.sql.ResultSetMetaData;
/*      */ import java.sql.SQLException;
/*      */ import java.sql.SQLWarning;
/*      */ import java.sql.Statement;
/*      */ import oracle.jdbc.internal.OracleConnection;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ abstract class OracleResultSet
/*      */   extends GeneratedResultSet
/*      */ {
/*      */   static final boolean DEBUG = false;
/*      */   boolean closed;
/*      */   SQLWarning sqlWarning;
/*      */   
/*      */   enum ResultSetType
/*      */   {
/*   72 */     UNKNOWN(-1, -1, false)
/*      */     {
/*      */       
/*      */       OracleResultSet createResultSet(OracleStatement param2OracleStatement) throws SQLException
/*      */       {
/*   77 */         SQLException sQLException = DatabaseError.createSqlException((OracleConnection)null, 23, null);
/*   78 */         sQLException.fillInStackTrace();
/*   79 */         throw sQLException;
/*      */       }
/*      */ 
/*      */       
/*      */       ResultSetType downgrade() {
/*   84 */         return UNKNOWN;
/*      */       }
/*      */     },
/*      */     
/*   88 */     FORWARD_READ_ONLY(1003, 1007, false)
/*      */     {
/*      */ 
/*      */       
/*      */       OracleResultSet createResultSet(OracleStatement param2OracleStatement) throws SQLException
/*      */       {
/*   94 */         return new ForwardOnlyResultSet(param2OracleStatement.connection, param2OracleStatement);
/*      */       }
/*      */       
/*      */       ResultSetType downgrade() {
/*   98 */         return FORWARD_READ_ONLY;
/*      */       }
/*      */     },
/*      */     
/*  102 */     FORWARD_UPDATABLE(1003, 1008, true)
/*      */     {
/*      */ 
/*      */       
/*      */       OracleResultSet createResultSet(OracleStatement param2OracleStatement) throws SQLException
/*      */       {
/*  108 */         ForwardOnlyResultSet forwardOnlyResultSet = new ForwardOnlyResultSet(param2OracleStatement.connection, param2OracleStatement);
/*  109 */         return new UpdatableResultSet(param2OracleStatement, forwardOnlyResultSet);
/*      */       }
/*      */       
/*      */       ResultSetType downgrade() {
/*  113 */         return FORWARD_READ_ONLY;
/*      */       }
/*      */     },
/*      */     
/*  117 */     INSENSITIVE_READ_ONLY(1004, 1007, false)
/*      */     {
/*      */ 
/*      */       
/*      */       OracleResultSet createResultSet(OracleStatement param2OracleStatement) throws SQLException
/*      */       {
/*  123 */         return new InsensitiveScrollableResultSet(param2OracleStatement.connection, param2OracleStatement);
/*      */       }
/*      */       
/*      */       ResultSetType downgrade() {
/*  127 */         return FORWARD_READ_ONLY;
/*      */       }
/*      */     },
/*      */     
/*  131 */     INSENSITIVE_UPDATABLE(1004, 1008, true)
/*      */     {
/*      */ 
/*      */       
/*      */       OracleResultSet createResultSet(OracleStatement param2OracleStatement) throws SQLException
/*      */       {
/*  137 */         InsensitiveScrollableResultSet insensitiveScrollableResultSet = new InsensitiveScrollableResultSet(param2OracleStatement.connection, param2OracleStatement);
/*  138 */         return new UpdatableResultSet(param2OracleStatement, insensitiveScrollableResultSet);
/*      */       }
/*      */       
/*      */       ResultSetType downgrade() {
/*  142 */         return INSENSITIVE_READ_ONLY;
/*      */       }
/*      */     },
/*      */     
/*  146 */     SENSITIVE_READ_ONLY(1005, 1007, true)
/*      */     {
/*      */ 
/*      */       
/*      */       OracleResultSet createResultSet(OracleStatement param2OracleStatement) throws SQLException
/*      */       {
/*  152 */         return new SensitiveScrollableResultSet(param2OracleStatement.connection, param2OracleStatement);
/*      */       }
/*      */       
/*      */       ResultSetType downgrade() {
/*  156 */         return INSENSITIVE_READ_ONLY;
/*      */       }
/*      */     },
/*      */     
/*  160 */     SENSITIVE_UPDATABLE(1005, 1008, true)
/*      */     {
/*      */ 
/*      */       
/*      */       OracleResultSet createResultSet(OracleStatement param2OracleStatement) throws SQLException
/*      */       {
/*  166 */         SensitiveScrollableResultSet sensitiveScrollableResultSet = new SensitiveScrollableResultSet(param2OracleStatement.connection, param2OracleStatement);
/*  167 */         return new UpdatableResultSet(param2OracleStatement, sensitiveScrollableResultSet);
/*      */       }
/*      */       
/*      */       ResultSetType downgrade() {
/*  171 */         return INSENSITIVE_READ_ONLY;
/*      */       }
/*      */     };
/*      */ 
/*      */     
/*      */     private final int type;
/*      */     
/*      */     private final int concur;
/*      */     
/*      */     private final boolean isIdentifierRequired;
/*      */ 
/*      */     
/*      */     static ResultSetType typeFor(int param1Int1, int param1Int2) throws SQLException {
/*  184 */       for (ResultSetType resultSetType : (ResultSetType[])ResultSetType.class.getEnumConstants()) {
/*  185 */         if (resultSetType.getType() == param1Int1 && resultSetType.getConcur() == param1Int2) return resultSetType;
/*      */       
/*      */       } 
/*  188 */       SQLException sQLException = DatabaseError.createSqlException((OracleConnection)null, 68, "type: " + param1Int1 + " concurency: " + param1Int2);
/*  189 */       sQLException.fillInStackTrace();
/*  190 */       throw sQLException;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     ResultSetType(int param1Int1, int param1Int2, boolean param1Boolean) {
/*  199 */       this.type = param1Int1;
/*  200 */       this.concur = param1Int2;
/*  201 */       this.isIdentifierRequired = param1Boolean;
/*      */     }
/*      */     int getType() {
/*  204 */       return this.type;
/*      */     } int getConcur() {
/*  206 */       return this.concur;
/*      */     } boolean isIdentifierRequired() {
/*  208 */       return this.isIdentifierRequired;
/*      */     } boolean isForwardOnly() {
/*  210 */       return (this.type == 1003);
/*      */     } boolean isScrollable() {
/*  212 */       return (this.type != 1003);
/*      */     } boolean isUpdatable() {
/*  214 */       return (this.concur == 1008);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     abstract OracleResultSet createResultSet(OracleStatement param1OracleStatement) throws SQLException;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     abstract ResultSetType downgrade();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static OracleResultSet createResultSet(OracleStatement paramOracleStatement) throws SQLException {
/*  233 */     if (!paramOracleStatement.sqlKind.isSELECT()) {
/*  234 */       paramOracleStatement.realRsetType = ResultSetType.FORWARD_READ_ONLY;
/*  235 */       paramOracleStatement.described = true;
/*      */     } 
/*      */     
/*  238 */     if (paramOracleStatement.realRsetType == ResultSetType.UNKNOWN) {
/*  239 */       return paramOracleStatement.userRsetType.createResultSet(paramOracleStatement);
/*      */     }
/*      */     
/*  242 */     return paramOracleStatement.realRsetType.createResultSet(paramOracleStatement);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean closeStatementOnClose = false;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected OracleResultSet(PhysicalConnection paramPhysicalConnection) {
/*  263 */     super(paramPhysicalConnection);
/*      */     
/*  265 */     this.closed = false;
/*  266 */     this.sqlWarning = null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected abstract void doneFetchingRows(boolean paramBoolean) throws SQLException;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void closeStatementOnClose() {
/*  285 */     this.closeStatementOnClose = true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public abstract oracle.jdbc.OracleResultSet.AuthorizationIndicator getAuthorizationIndicator(int paramInt) throws SQLException;
/*      */ 
/*      */ 
/*      */   
/*      */   public oracle.jdbc.OracleResultSet.AuthorizationIndicator getAuthorizationIndicator(String paramString) throws SQLException {
/*  296 */     return getAuthorizationIndicator(findColumn(paramString));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   boolean isValidRow() throws SQLException {
/*  307 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 23, "isValidRow");
/*  308 */     sQLException.fillInStackTrace();
/*  309 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void close() throws SQLException {
/*  326 */     this.closed = true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isClosed() throws SQLException {
/*  339 */     return this.closed;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public SQLWarning getWarnings() throws SQLException {
/*  358 */     return this.sqlWarning;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void clearWarnings() throws SQLException {
/*  377 */     this.sqlWarning = null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public abstract String getCursorName() throws SQLException;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public abstract ResultSetMetaData getMetaData() throws SQLException;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public abstract boolean next() throws SQLException;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public abstract boolean wasNull() throws SQLException;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public abstract boolean isBeforeFirst() throws SQLException;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public abstract boolean isAfterLast() throws SQLException;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public abstract boolean isFirst() throws SQLException;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public abstract boolean isLast() throws SQLException;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public abstract void beforeFirst() throws SQLException;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public abstract void afterLast() throws SQLException;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public abstract boolean first() throws SQLException;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public abstract boolean last() throws SQLException;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public abstract int getRow() throws SQLException;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public abstract boolean absolute(int paramInt) throws SQLException;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public abstract boolean relative(int paramInt) throws SQLException;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public abstract boolean previous() throws SQLException;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setFetchDirection(int paramInt) throws SQLException {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getFetchDirection() throws SQLException {
/*  623 */     return 1000;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public abstract void setFetchSize(int paramInt) throws SQLException;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public abstract int getFetchSize() throws SQLException;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public abstract int getType() throws SQLException;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public abstract int getConcurrency() throws SQLException;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getHoldability() throws SQLException {
/*  684 */     if (isClosed()) {
/*      */       
/*  686 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 10, (Object)null);
/*  687 */       sQLException.fillInStackTrace();
/*  688 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  693 */     return 1;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void insertRow() throws SQLException {
/*  717 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 76, "insertRow");
/*  718 */     sQLException.fillInStackTrace();
/*  719 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateRow() throws SQLException {
/*  741 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 76, "updateRow");
/*  742 */     sQLException.fillInStackTrace();
/*  743 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void deleteRow() throws SQLException {
/*  765 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 76, "deleteRow");
/*  766 */     sQLException.fillInStackTrace();
/*  767 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void refreshRow() throws SQLException {
/*  801 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 23, (Object)null);
/*  802 */     sQLException.fillInStackTrace();
/*  803 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void moveToInsertRow() throws SQLException {
/*  825 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 76, "moveToInsertRow");
/*  826 */     sQLException.fillInStackTrace();
/*  827 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void cancelRowUpdates() throws SQLException {
/*  854 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 76, "cancelRowUpdates");
/*  855 */     sQLException.fillInStackTrace();
/*  856 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void moveToCurrentRow() throws SQLException {
/*  878 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 76, "moveToCurrentRow");
/*  879 */     sQLException.fillInStackTrace();
/*  880 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public abstract Statement getStatement() throws SQLException;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateNull(int paramInt) throws SQLException {
/*  920 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 76, "updateNull");
/*  921 */     sQLException.fillInStackTrace();
/*  922 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateNull(String paramString) throws SQLException {
/*  943 */     updateNull(findColumn(paramString));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean rowUpdated() throws SQLException {
/*  962 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean rowInserted() throws SQLException {
/*  982 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean rowDeleted() throws SQLException {
/* 1002 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isWrapperFor(Class<?> paramClass) throws SQLException {
/* 1022 */     if (paramClass.isInterface()) return paramClass.isInstance(this);
/*      */     
/* 1024 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 177);
/* 1025 */     sQLException.fillInStackTrace();
/* 1026 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <T> T unwrap(Class<T> paramClass) throws SQLException {
/* 1048 */     if (paramClass.isInterface() && paramClass.isInstance(this)) return (T)this;
/*      */     
/* 1050 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 177);
/* 1051 */     sQLException.fillInStackTrace();
/* 1052 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public abstract <T> T getObject(int paramInt, Class<T> paramClass) throws SQLException;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <T> T getObject(String paramString, Class<T> paramClass) throws SQLException {
/* 1120 */     return getObject(findColumn(paramString), paramClass);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected OracleConnection getConnectionDuringExceptionHandling() {
/* 1137 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1169 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*      */   public static final String BUILD_DATE = "Thu_Apr_04_15:09:24_PDT_2013";
/*      */   public static final boolean TRACE = false;
/*      */   
/*      */   abstract OracleStatement getOracleStatement() throws SQLException;
/*      */   
/*      */   abstract int refreshRows(int paramInt1, int paramInt2) throws SQLException;
/*      */   
/*      */   abstract void removeCurrentRowFromCache() throws SQLException;
/*      */   
/*      */   abstract int getColumnCount() throws SQLException;
/*      */ }


/* Location:              C:\Users\olatu\OneDrive\Documents\Calypso\syncbase\sync_base.jar!\BOOT-INF\classes\ojdbc.jar!\oracle\jdbc\driver\OracleResultSet.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */