/*     */ package oracle.jdbc.driver;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.net.SocketTimeoutException;
/*     */ import java.sql.SQLException;
/*     */ import oracle.net.ns.BreakNetException;
/*     */ import oracle.net.ns.Communication;
/*     */ import oracle.net.ns.NetException;
/*     */ import oracle.net.ns.NetInputStream;
/*     */ import oracle.net.ns.NetOutputStream;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class T4CMAREngineStream
/*     */   extends T4CMAREngine
/*     */ {
/*     */   NetInputStream inStream;
/*     */   NetOutputStream outStream;
/*     */   
/*     */   T4CMAREngineStream(Communication paramCommunication) throws SQLException, IOException {
/*  59 */     if (paramCommunication == null) {
/*     */ 
/*     */ 
/*     */       
/*  63 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 433);
/*  64 */       sQLException.fillInStackTrace();
/*  65 */       throw sQLException;
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/*  70 */     this.net = paramCommunication;
/*     */     
/*     */     try {
/*  73 */       this.outStream = new T4CSocketOutputStreamWrapper((NetOutputStream)paramCommunication.getOutputStream());
/*  74 */       this.inStream = new T4CSocketInputStreamWrapper((NetInputStream)paramCommunication.getInputStream(), (T4CSocketOutputStreamWrapper)this.outStream);
/*     */     
/*     */     }
/*  77 */     catch (NetException netException) {
/*     */       
/*  79 */       throw new IOException(netException.getMessage());
/*     */     } 
/*     */     
/*  82 */     this.types = new T4CTypeRep(this, false);
/*     */     
/*  84 */     this.types.setRep((byte)1, (byte)2);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void initBuffers() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   final void marshalSB1(byte paramByte) throws IOException {
/* 122 */     marshalSB2((short)paramByte);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   final void marshalUB1(short paramShort) throws IOException {
/* 134 */     this.outStream.write((byte)(paramShort & 0xFF));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   final void marshalSB2(short paramShort) throws IOException {
/* 150 */     byte b = value2Buffer(paramShort, this.tmpBuffer2, (byte)1);
/*     */     
/* 152 */     if (b != 0)
/*     */     {
/* 154 */       this.outStream.write(this.tmpBuffer2, 0, b);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   final void marshalUB2(int paramInt) throws IOException {
/* 167 */     marshalSB2((short)(paramInt & 0xFFFF));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   final void marshalSB4(int paramInt) throws IOException {
/* 184 */     byte b = value2Buffer(paramInt, this.tmpBuffer4, (byte)2);
/*     */ 
/*     */     
/* 187 */     if (b != 0)
/*     */     {
/* 189 */       this.outStream.write(this.tmpBuffer4, 0, b);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   final void marshalUB4(long paramLong) throws IOException {
/* 202 */     marshalSB4((int)(paramLong & 0xFFFFFFFFFFFFFFFFL));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   final void marshalSB8(long paramLong) throws IOException {
/* 218 */     byte b = value2Buffer(paramLong, this.tmpBuffer8, (byte)3);
/*     */ 
/*     */     
/* 221 */     if (b != 0)
/*     */     {
/* 223 */       this.outStream.write(this.tmpBuffer8, 0, b);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   final void marshalB1Array(byte[] paramArrayOfbyte) throws IOException {
/* 237 */     if (paramArrayOfbyte.length > 0)
/*     */     {
/* 239 */       this.outStream.write(paramArrayOfbyte);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   final void marshalB1Array(byte[] paramArrayOfbyte, int paramInt1, int paramInt2) throws IOException {
/* 255 */     if (paramArrayOfbyte.length > 0)
/*     */     {
/* 257 */       this.outStream.write(paramArrayOfbyte, paramInt1, paramInt2);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   final byte value2Buffer(int paramInt, byte[] paramArrayOfbyte, byte paramByte) throws IOException {
/* 277 */     boolean bool1 = ((this.types.rep[paramByte] & 0x1) > 0) ? true : false;
/* 278 */     boolean bool2 = true;
/* 279 */     byte b = 0;
/*     */ 
/*     */ 
/*     */     
/* 283 */     for (int i = paramArrayOfbyte.length - 1; i >= 0; i--) {
/*     */       
/* 285 */       paramArrayOfbyte[b] = (byte)(paramInt >>> 8 * i & 0xFF);
/*     */ 
/*     */ 
/*     */       
/* 289 */       if (bool1) {
/*     */         
/* 291 */         if (!bool2 || paramArrayOfbyte[b] != 0) {
/*     */           
/* 293 */           bool2 = false;
/* 294 */           b = (byte)(b + 1);
/*     */         } 
/*     */       } else {
/*     */         
/* 298 */         b = (byte)(b + 1);
/*     */       } 
/*     */     } 
/*     */     
/* 302 */     if (bool1)
/*     */     {
/* 304 */       this.outStream.write(b);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 310 */     if ((this.types.rep[paramByte] & 0x2) > 0) {
/* 311 */       reverseArray(paramArrayOfbyte, b);
/*     */     }
/* 313 */     return b;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   final byte value2Buffer(long paramLong, byte[] paramArrayOfbyte, byte paramByte) throws IOException {
/* 321 */     boolean bool1 = ((this.types.rep[paramByte] & 0x1) > 0) ? true : false;
/* 322 */     boolean bool2 = true;
/* 323 */     byte b = 0;
/*     */ 
/*     */ 
/*     */     
/* 327 */     for (int i = paramArrayOfbyte.length - 1; i >= 0; i--) {
/*     */       
/* 329 */       paramArrayOfbyte[b] = (byte)(int)(paramLong >>> 8 * i & 0xFFL);
/*     */ 
/*     */ 
/*     */       
/* 333 */       if (bool1) {
/*     */         
/* 335 */         if (!bool2 || paramArrayOfbyte[b] != 0) {
/*     */           
/* 337 */           bool2 = false;
/* 338 */           b = (byte)(b + 1);
/*     */         } 
/*     */       } else {
/*     */         
/* 342 */         b = (byte)(b + 1);
/*     */       } 
/*     */     } 
/*     */     
/* 346 */     if (bool1)
/*     */     {
/* 348 */       this.outStream.write(b);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 354 */     if ((this.types.rep[paramByte] & 0x2) > 0) {
/* 355 */       reverseArray(paramArrayOfbyte, b);
/*     */     }
/* 357 */     return b;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   final void reverseArray(byte[] paramArrayOfbyte, byte paramByte) {
/* 372 */     int i = paramByte / 2;
/*     */     
/* 374 */     for (byte b = 0; b < i; b++) {
/*     */       
/* 376 */       byte b1 = paramArrayOfbyte[b];
/* 377 */       paramArrayOfbyte[b] = paramArrayOfbyte[paramByte - 1 - b];
/* 378 */       paramArrayOfbyte[paramByte - 1 - b] = b1;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   final byte unmarshalSB1() throws SQLException, IOException {
/* 406 */     return (byte)unmarshalSB2();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   final short unmarshalUB1() throws SQLException, IOException {
/* 421 */     short s = 0;
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/* 426 */       s = (short)this.inStream.read();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     }
/* 433 */     catch (SocketTimeoutException socketTimeoutException) {
/* 434 */       ((T4CConnection)getConnectionDuringExceptionHandling()).doAsynchronousClose();
/* 435 */       throw socketTimeoutException;
/*     */ 
/*     */     
/*     */     }
/* 439 */     catch (BreakNetException breakNetException) {
/*     */ 
/*     */       
/* 442 */       this.net.sendReset();
/* 443 */       throw breakNetException;
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 448 */     if (s < 0) {
/*     */ 
/*     */ 
/*     */       
/* 452 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 410);
/* 453 */       sQLException.fillInStackTrace();
/* 454 */       throw sQLException;
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 463 */     return s;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   final short unmarshalSB2() throws SQLException, IOException {
/* 477 */     return (short)unmarshalUB2();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   final int unmarshalUB2() throws SQLException, IOException {
/* 495 */     int i = (int)buffer2Value((byte)1);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 503 */     return i & 0xFFFF;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   final int unmarshalSB4() throws SQLException, IOException {
/* 517 */     return (int)unmarshalUB4();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   final long unmarshalUB4() throws SQLException, IOException {
/* 535 */     return buffer2Value((byte)2);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   byte[] unmarshalNBytes(int paramInt) throws SQLException, IOException {
/* 552 */     byte[] arrayOfByte = new byte[paramInt];
/*     */     
/* 554 */     if (paramInt > 0) {
/*     */       
/*     */       try {
/*     */ 
/*     */         
/* 559 */         if (this.inStream.read(arrayOfByte) < 0)
/*     */         {
/*     */ 
/*     */           
/* 563 */           SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 410);
/* 564 */           sQLException.fillInStackTrace();
/* 565 */           throw sQLException;
/*     */ 
/*     */ 
/*     */         
/*     */         }
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       }
/* 575 */       catch (SocketTimeoutException socketTimeoutException) {
/* 576 */         ((T4CConnection)getConnectionDuringExceptionHandling()).doAsynchronousClose();
/* 577 */         throw socketTimeoutException;
/*     */ 
/*     */       
/*     */       }
/* 581 */       catch (BreakNetException breakNetException) {
/*     */ 
/*     */         
/* 584 */         this.net.sendReset();
/* 585 */         throw breakNetException;
/*     */       } 
/*     */     }
/*     */     
/* 589 */     return arrayOfByte;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   int unmarshalNBytes(byte[] paramArrayOfbyte, int paramInt1, int paramInt2) throws SQLException, IOException {
/* 605 */     if (paramInt1 + paramInt2 > paramArrayOfbyte.length)
/*     */     {
/* 607 */       paramInt2 = paramArrayOfbyte.length - paramInt1;
/*     */     }
/*     */     
/* 610 */     int i = 0;
/*     */     
/* 612 */     while (i < paramInt2) {
/* 613 */       i += getNBytes(paramArrayOfbyte, paramInt1 + i, paramInt2 - i);
/*     */     }
/* 615 */     return i;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   int getNBytes(byte[] paramArrayOfbyte, int paramInt1, int paramInt2) throws SQLException, IOException {
/* 632 */     if (paramInt1 + paramInt2 > paramArrayOfbyte.length)
/*     */     {
/* 634 */       paramInt2 = paramArrayOfbyte.length - paramInt1;
/*     */     }
/*     */     
/* 637 */     int i = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/* 643 */       if ((i = this.inStream.read(paramArrayOfbyte, paramInt1, paramInt2)) < 0)
/*     */       {
/*     */ 
/*     */         
/* 647 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 410);
/* 648 */         sQLException.fillInStackTrace();
/* 649 */         throw sQLException;
/*     */ 
/*     */ 
/*     */       
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     }
/* 659 */     catch (SocketTimeoutException socketTimeoutException) {
/* 660 */       ((T4CConnection)getConnectionDuringExceptionHandling()).doAsynchronousClose();
/* 661 */       throw socketTimeoutException;
/*     */ 
/*     */     
/*     */     }
/* 665 */     catch (BreakNetException breakNetException) {
/*     */ 
/*     */ 
/*     */       
/* 669 */       this.net.sendReset();
/* 670 */       throw breakNetException;
/*     */     } 
/*     */ 
/*     */     
/* 674 */     return i;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   byte[] getNBytes(int paramInt) throws SQLException, IOException {
/* 688 */     byte[] arrayOfByte = new byte[paramInt];
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/* 694 */       if (this.inStream.read(arrayOfByte) < 0)
/*     */       {
/*     */ 
/*     */ 
/*     */         
/* 699 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 410);
/* 700 */         sQLException.fillInStackTrace();
/* 701 */         throw sQLException;
/*     */ 
/*     */ 
/*     */       
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     }
/* 711 */     catch (SocketTimeoutException socketTimeoutException) {
/* 712 */       ((T4CConnection)getConnectionDuringExceptionHandling()).doAsynchronousClose();
/* 713 */       throw socketTimeoutException;
/*     */ 
/*     */     
/*     */     }
/* 717 */     catch (BreakNetException breakNetException) {
/*     */ 
/*     */ 
/*     */       
/* 721 */       this.net.sendReset();
/* 722 */       throw breakNetException;
/*     */     } 
/*     */ 
/*     */     
/* 726 */     return arrayOfByte;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   byte[] unmarshalTEXT(int paramInt) throws SQLException, IOException {
/*     */     byte[] arrayOfByte2;
/* 744 */     byte b = 0;
/*     */ 
/*     */ 
/*     */     
/* 748 */     byte[] arrayOfByte1 = new byte[paramInt];
/*     */ 
/*     */     
/* 751 */     while (b < paramInt) {
/*     */ 
/*     */       
/*     */       try {
/*     */ 
/*     */         
/* 757 */         if (this.inStream.read(arrayOfByte1, b, 1) < 0)
/*     */         {
/*     */ 
/*     */ 
/*     */           
/* 762 */           SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 410);
/* 763 */           sQLException.fillInStackTrace();
/* 764 */           throw sQLException;
/*     */ 
/*     */ 
/*     */         
/*     */         }
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       }
/* 774 */       catch (SocketTimeoutException socketTimeoutException) {
/* 775 */         ((T4CConnection)getConnectionDuringExceptionHandling()).doAsynchronousClose();
/* 776 */         throw socketTimeoutException;
/*     */ 
/*     */       
/*     */       }
/* 780 */       catch (BreakNetException breakNetException) {
/*     */ 
/*     */ 
/*     */         
/* 784 */         this.net.sendReset();
/* 785 */         throw breakNetException;
/*     */       } 
/*     */ 
/*     */       
/* 789 */       if (arrayOfByte1[b++] == 0) {
/*     */         break;
/*     */       }
/*     */     } 
/*     */     
/* 794 */     if (arrayOfByte1.length == --b) {
/*     */       
/* 796 */       arrayOfByte2 = arrayOfByte1;
/*     */     }
/*     */     else {
/*     */       
/* 800 */       arrayOfByte2 = new byte[b];
/*     */       
/* 802 */       System.arraycopy(arrayOfByte1, 0, arrayOfByte2, 0, b);
/*     */     } 
/*     */     
/* 805 */     return arrayOfByte2;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   final long buffer2Value(byte paramByte) throws SQLException, IOException {
/*     */     try {
/* 826 */       long l = 0L;
/* 827 */       int i = 1;
/* 828 */       if ((this.types.rep[paramByte] & 0x1) > 0) {
/* 829 */         i = this.inStream.readB1();
/*     */       } else {
/*     */         
/* 832 */         switch (paramByte) {
/*     */           case 1:
/* 834 */             i = 2;
/*     */             break;
/*     */           case 2:
/* 837 */             i = 4;
/*     */             break;
/*     */           case 3:
/* 840 */             i = 8;
/*     */             break;
/*     */         } 
/*     */       
/*     */       } 
/* 845 */       if ((this.types.rep[paramByte] & 0x2) > 0) {
/* 846 */         l = this.inStream.readLongLSB(i);
/*     */       } else {
/* 848 */         l = this.inStream.readLongMSB(i);
/* 849 */       }  return l;
/*     */     }
/* 851 */     catch (BreakNetException breakNetException) {
/*     */ 
/*     */       
/* 854 */       this.net.sendReset();
/* 855 */       throw breakNetException;
/*     */     }
/* 857 */     catch (SocketTimeoutException socketTimeoutException) {
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 862 */       ((T4CConnection)getConnectionDuringExceptionHandling()).doAsynchronousClose();
/*     */ 
/*     */       
/* 865 */       throw socketTimeoutException;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void setByteOrder(byte paramByte) throws IOException {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void flush() throws IOException {
/* 881 */     ((T4CSocketOutputStreamWrapper)this.outStream).flush(true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void writeZeroCopyIO(byte[] paramArrayOfbyte, int paramInt1, int paramInt2) throws IOException, NetException {
/* 892 */     this.outStream.flush();
/* 893 */     this.outStream.writeZeroCopyIO(paramArrayOfbyte, paramInt1, paramInt2);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/* 898 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*     */   public static final String BUILD_DATE = "Thu_Apr_04_15:09:24_PDT_2013";
/*     */   public static final boolean TRACE = false;
/*     */ }


/* Location:              C:\Users\olatu\OneDrive\Documents\Calypso\syncbase\sync_base.jar!\BOOT-INF\classes\ojdbc.jar!\oracle\jdbc\driver\T4CMAREngineStream.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */