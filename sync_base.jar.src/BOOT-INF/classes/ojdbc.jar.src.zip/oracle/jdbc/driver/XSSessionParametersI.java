/*    */ package oracle.jdbc.driver;
/*    */ 
/*    */ import java.sql.SQLException;
/*    */ import oracle.jdbc.internal.XSSessionParameters;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class XSSessionParametersI
/*    */   extends XSSessionParameters
/*    */ {
/* 27 */   int intParam = 0;
/* 28 */   byte[] binaryParam = null;
/* 29 */   String[] textParam = null;
/*    */   
/*    */   byte[][] textParamBytes;
/*    */   
/*    */   void doCharConversion(DBConversion paramDBConversion) throws SQLException {
/* 34 */     if (this.textParam != null && this.textParam.length > 0) {
/*    */       
/* 36 */       this.textParamBytes = new byte[this.textParam.length][];
/* 37 */       for (byte b = 0; b < this.textParam.length; b++) {
/* 38 */         this.textParamBytes[b] = paramDBConversion.StringToCharBytes(this.textParam[b]);
/*    */       }
/*    */     } else {
/* 41 */       this.textParamBytes = (byte[][])null;
/*    */     } 
/*    */   }
/*    */   public void setBinary(byte[] paramArrayOfbyte) throws SQLException {
/* 45 */     this.binaryParam = paramArrayOfbyte;
/*    */   }
/*    */   
/*    */   public void setInt(int paramInt) throws SQLException {
/* 49 */     this.intParam = paramInt;
/*    */   }
/*    */   public void setText(String[] paramArrayOfString) throws SQLException {
/* 52 */     this.textParam = paramArrayOfString;
/*    */   }
/*    */ }


/* Location:              C:\Users\olatu\OneDrive\Documents\Calypso\syncbase\sync_base.jar!\BOOT-INF\classes\ojdbc.jar!\oracle\jdbc\driver\XSSessionParametersI.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */