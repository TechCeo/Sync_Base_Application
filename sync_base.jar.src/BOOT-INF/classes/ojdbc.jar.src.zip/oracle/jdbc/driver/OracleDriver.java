/*      */ package oracle.jdbc.driver;
/*      */ 
/*      */ import java.io.IOException;
/*      */ import java.io.InputStream;
/*      */ import java.lang.management.ManagementFactory;
/*      */ import java.lang.reflect.Field;
/*      */ import java.lang.reflect.InvocationTargetException;
/*      */ import java.lang.reflect.Method;
/*      */ import java.security.AccessController;
/*      */ import java.security.PrivilegedAction;
/*      */ import java.sql.Connection;
/*      */ import java.sql.Driver;
/*      */ import java.sql.DriverManager;
/*      */ import java.sql.DriverPropertyInfo;
/*      */ import java.sql.SQLException;
/*      */ import java.sql.SQLFeatureNotSupportedException;
/*      */ import java.sql.Timestamp;
/*      */ import java.util.Enumeration;
/*      */ import java.util.Hashtable;
/*      */ import java.util.Map;
/*      */ import java.util.Properties;
/*      */ import java.util.logging.Level;
/*      */ import java.util.logging.Logger;
/*      */ import javax.management.InstanceAlreadyExistsException;
/*      */ import javax.management.InstanceNotFoundException;
/*      */ import javax.management.JMException;
/*      */ import javax.management.MBeanServer;
/*      */ import javax.management.ObjectName;
/*      */ import oracle.jdbc.OracleDatabaseMetaData;
/*      */ import oracle.jdbc.babelfish.BabelfishCallableStatement;
/*      */ import oracle.jdbc.babelfish.BabelfishConnection;
/*      */ import oracle.jdbc.babelfish.BabelfishGenericProxy;
/*      */ import oracle.jdbc.babelfish.BabelfishPreparedStatement;
/*      */ import oracle.jdbc.babelfish.BabelfishStatement;
/*      */ import oracle.jdbc.babelfish.TranslationManager;
/*      */ import oracle.jdbc.babelfish.Translator;
/*      */ import oracle.jdbc.internal.OracleConnection;
/*      */ import oracle.jdbc.proxy.ProxyFactory;
/*      */ import oracle.security.pki.OraclePKIProvider;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class OracleDriver
/*      */   implements Driver
/*      */ {
/*      */   public static final String oracle_string = "oracle";
/*      */   public static final String jdbc_string = "jdbc";
/*      */   public static final String protocol_string = "protocol";
/*      */   public static final String user_string = "user";
/*      */   public static final String password_string = "password";
/*      */   public static final String database_string = "database";
/*      */   public static final String server_string = "server";
/*      */   public static final String access_string = "access";
/*      */   public static final String protocolFullName_string = "protocolFullName";
/*      */   public static final String logon_as_internal_str = "internal_logon";
/*      */   public static final String proxy_client_name = "oracle.jdbc.proxyClientName";
/*      */   public static final String prefetch_string = "prefetch";
/*      */   public static final String row_prefetch_string = "rowPrefetch";
/*      */   public static final String default_row_prefetch_string = "defaultRowPrefetch";
/*      */   public static final String batch_string = "batch";
/*      */   public static final String execute_batch_string = "executeBatch";
/*      */   public static final String default_execute_batch_string = "defaultExecuteBatch";
/*      */   public static final String process_escapes_string = "processEscapes";
/*      */   public static final String accumulate_batch_result = "AccumulateBatchResult";
/*      */   public static final String j2ee_compliance = "oracle.jdbc.J2EE13Compliant";
/*      */   public static final String v8compatible_string = "V8Compatible";
/*      */   public static final String permit_timestamp_date_mismatch_string = "oracle.jdbc.internal.permitBindDateDefineTimestampMismatch";
/*      */   public static final String prelim_auth_string = "prelim_auth";
/*      */   public static final String SetFloatAndDoubleUseBinary_string = "SetFloatAndDoubleUseBinary";
/*      */   public static final String xa_trans_loose = "oracle.jdbc.XATransLoose";
/*      */   public static final String tcp_no_delay = "oracle.jdbc.TcpNoDelay";
/*      */   public static final String read_timeout = "oracle.jdbc.ReadTimeout";
/*      */   public static final String defaultnchar_string = "oracle.jdbc.defaultNChar";
/*      */   public static final String defaultncharprop_string = "defaultNChar";
/*      */   public static final String useFetchSizeWithLongColumn_prop_string = "useFetchSizeWithLongColumn";
/*      */   public static final String useFetchSizeWithLongColumn_string = "oracle.jdbc.useFetchSizeWithLongColumn";
/*      */   public static final String remarks_string = "remarks";
/*      */   public static final String report_remarks_string = "remarksReporting";
/*      */   public static final String synonyms_string = "synonyms";
/*      */   public static final String include_synonyms_string = "includeSynonyms";
/*      */   public static final String restrict_getTables_string = "restrictGetTables";
/*      */   public static final String fixed_string_string = "fixedString";
/*      */   public static final String dll_string = "oracle.jdbc.ocinativelibrary";
/*      */   public static final String nls_lang_backdoor = "oracle.jdbc.ociNlsLangBackwardCompatible";
/*      */   public static final String disable_defineColumnType_string = "disableDefineColumnType";
/*      */   public static final String convert_nchar_literals_string = "oracle.jdbc.convertNcharLiterals";
/*      */   public static final String dataSizeUnitsPropertyName = "";
/*      */   public static final String dataSizeBytes = "";
/*      */   public static final String dataSizeChars = "";
/*      */   public static final String set_new_password_string = "OCINewPassword";
/*      */   public static final String retain_v9_bind_behavior_string = "oracle.jdbc.RetainV9LongBindBehavior";
/*      */   public static final String no_caching_buffers = "oracle.jdbc.FreeMemoryOnEnterImplicitCache";
/*      */   static final int EXTENSION_TYPE_ORACLE_ERROR = -3;
/*      */   static final int EXTENSION_TYPE_GEN_ERROR = -2;
/*      */   static final int EXTENSION_TYPE_TYPE4_CLIENT = 0;
/*      */   static final int EXTENSION_TYPE_TYPE4_SERVER = 1;
/*      */   static final int EXTENSION_TYPE_TYPE2_CLIENT = 2;
/*      */   static final int EXTENSION_TYPE_TYPE2_SERVER = 3;
/*      */   private static final int NUMBER_OF_EXTENSION_TYPES = 4;
/*  150 */   private OracleDriverExtension[] driverExtensions = new OracleDriverExtension[4];
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static final String DRIVER_PACKAGE_STRING = "driver";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  166 */   private static final String[] driverExtensionClassNames = new String[] { "oracle.jdbc.driver.T4CDriverExtension", "oracle.jdbc.driver.T4CDriverExtension", "oracle.jdbc.driver.T2CDriverExtension", "oracle.jdbc.driver.T2SDriverExtension" };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static Properties driverAccess;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  185 */   protected static Connection defaultConn = null;
/*  186 */   private static OracleDriver defaultDriver = null;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static {
/*      */     try {
/*  193 */       if (defaultDriver == null) {
/*      */         
/*  195 */         defaultDriver = (OracleDriver)new oracle.jdbc.OracleDriver();
/*  196 */         DriverManager.registerDriver(defaultDriver);
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  203 */       AccessController.doPrivileged(new PrivilegedAction()
/*      */           {
/*      */             public Object run()
/*      */             {
/*  207 */               OracleDriver.registerMBeans();
/*  208 */               return null;
/*      */             }
/*      */           });
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  224 */       Timestamp timestamp = Timestamp.valueOf("2000-01-01 00:00:00.0");
/*      */ 
/*      */     
/*      */     }
/*  228 */     catch (SQLException sQLException) {
/*  229 */       Logger.getLogger("oracle.jdbc.driver").log(Level.SEVERE, "SQLException in static block.", sQLException);
/*      */ 
/*      */ 
/*      */     
/*      */     }
/*  234 */     catch (RuntimeException runtimeException) {
/*  235 */       Logger.getLogger("oracle.jdbc.driver").log(Level.SEVERE, "RuntimeException in static block.", runtimeException);
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     try {
/*  249 */       OraclePKIProvider oraclePKIProvider = new OraclePKIProvider();
/*      */     }
/*  251 */     catch (Throwable throwable) {}
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  260 */   public static final Map<String, Class> systemTypeMap = (Map)new Hashtable<>(2);
/*      */ 
/*      */   
/*      */   private static final String DEFAULT_CONNECTION_PROPERTIES_RESOURCE_NAME = "/oracle/jdbc/defaultConnectionProperties.properties";
/*      */ 
/*      */   
/*      */   static {
/*      */     try {
/*  268 */       systemTypeMap.put("SYS.ANYDATA", Class.forName("oracle.sql.AnyDataFactory"));
/*  269 */       systemTypeMap.put("SYS.ANYTYPE", Class.forName("oracle.sql.TypeDescriptorFactory"));
/*      */     }
/*  271 */     catch (ClassNotFoundException classNotFoundException) {}
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  284 */   protected static final Properties DEFAULT_CONNECTION_PROPERTIES = new Properties();
/*      */   static {
/*      */     try {
/*  287 */       InputStream inputStream = PhysicalConnection.class.getResourceAsStream("/oracle/jdbc/defaultConnectionProperties.properties");
/*  288 */       if (inputStream != null) DEFAULT_CONNECTION_PROPERTIES.load(inputStream);
/*      */     
/*  290 */     } catch (IOException iOException) {}
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  297 */   private static ObjectName diagnosticMBeanObjectName = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void registerMBeans() {
/*      */     try {
/*  309 */       MBeanServer mBeanServer = null;
/*      */       
/*      */       try {
/*  312 */         Class<?> clazz = Class.forName("oracle.as.jmx.framework.PortableMBeanFactory");
/*  313 */         Object object = clazz.newInstance();
/*  314 */         Method method = clazz.getMethod("getMBeanServer", new Class[0]);
/*  315 */         mBeanServer = (MBeanServer)method.invoke(object, new Object[0]);
/*      */       }
/*  317 */       catch (NoClassDefFoundError noClassDefFoundError) {
/*      */ 
/*      */         
/*  320 */         mBeanServer = ManagementFactory.getPlatformMBeanServer();
/*      */       }
/*  322 */       catch (ClassNotFoundException classNotFoundException) {
/*      */ 
/*      */         
/*  325 */         mBeanServer = ManagementFactory.getPlatformMBeanServer();
/*      */       }
/*  327 */       catch (NoSuchMethodException noSuchMethodException) {
/*  328 */         Logger.getLogger("oracle.jdbc").log(Level.WARNING, "Found Oracle Apps MBeanServer but not the getMBeanServer method.", noSuchMethodException);
/*      */ 
/*      */ 
/*      */         
/*  332 */         mBeanServer = ManagementFactory.getPlatformMBeanServer();
/*      */       }
/*  334 */       catch (InstantiationException instantiationException) {
/*  335 */         Logger.getLogger("oracle.jdbc").log(Level.WARNING, "Found Oracle Apps MBeanServer but could not create an instance.", instantiationException);
/*      */ 
/*      */ 
/*      */         
/*  339 */         mBeanServer = ManagementFactory.getPlatformMBeanServer();
/*      */       }
/*  341 */       catch (IllegalAccessException illegalAccessException) {
/*  342 */         Logger.getLogger("oracle.jdbc").log(Level.WARNING, "Found Oracle Apps MBeanServer but could not access the getMBeanServer method.", illegalAccessException);
/*      */ 
/*      */ 
/*      */         
/*  346 */         mBeanServer = ManagementFactory.getPlatformMBeanServer();
/*      */       }
/*  348 */       catch (InvocationTargetException invocationTargetException) {
/*  349 */         Logger.getLogger("oracle.jdbc").log(Level.WARNING, "Found Oracle Apps MBeanServer but the getMBeanServer method threw an exception.", invocationTargetException);
/*      */ 
/*      */ 
/*      */         
/*  353 */         mBeanServer = ManagementFactory.getPlatformMBeanServer();
/*      */       } 
/*  355 */       if (mBeanServer != null) {
/*  356 */         ClassLoader classLoader = OracleDriver.class.getClassLoader();
/*  357 */         String str = (classLoader == null) ? "nullLoader" : classLoader.getClass().getName();
/*  358 */         byte b = 0;
/*      */         while (true) {
/*  360 */           String str1 = str + "@" + Integer.toHexString(((classLoader == null) ? 0 : classLoader.hashCode()) + b++);
/*      */           
/*  362 */           diagnosticMBeanObjectName = new ObjectName("com.oracle.jdbc:type=diagnosability,name=" + str1);
/*      */           
/*      */           try {
/*  365 */             mBeanServer.registerMBean(new OracleDiagnosabilityMBean(), diagnosticMBeanObjectName);
/*      */             
/*      */             break;
/*  368 */           } catch (InstanceAlreadyExistsException instanceAlreadyExistsException) {}
/*      */         }
/*      */       
/*      */       } else {
/*      */         
/*  373 */         Logger.getLogger("oracle.jdbc").log(Level.WARNING, "Unable to find an MBeanServer so no MBears are registered.");
/*      */       }
/*      */     
/*      */     }
/*  377 */     catch (JMException jMException) {
/*  378 */       Logger.getLogger("oracle.jdbc").log(Level.WARNING, "Error while registering Oracle JDBC Diagnosability MBean.", jMException);
/*      */ 
/*      */ 
/*      */     
/*      */     }
/*  383 */     catch (Throwable throwable) {
/*  384 */       Logger.getLogger("oracle.jdbc").log(Level.WARNING, "Error while registering Oracle JDBC Diagnosability MBean.", throwable);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Connection connect(String paramString, Properties paramProperties) throws SQLException {
/*      */     PhysicalConnection physicalConnection;
/*  423 */     if (paramString.regionMatches(0, "jdbc:default:connection", 0, 23)) {
/*      */       
/*  425 */       String str = "jdbc:oracle:kprb";
/*  426 */       int j = paramString.length();
/*      */       
/*  428 */       if (j > 23) {
/*  429 */         paramString = str.concat(paramString.substring(23, paramString.length()));
/*      */       } else {
/*  431 */         paramString = str.concat(":");
/*      */       } 
/*  433 */       str = null;
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  443 */     int i = oracleDriverExtensionTypeFromURL(paramString);
/*      */     
/*  445 */     if (i == -2) {
/*  446 */       return null;
/*      */     }
/*  448 */     if (i == -3) {
/*      */       
/*  450 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 67);
/*  451 */       sQLException.fillInStackTrace();
/*  452 */       throw sQLException;
/*      */     } 
/*      */     
/*  455 */     OracleDriverExtension oracleDriverExtension = null;
/*      */     
/*  457 */     oracleDriverExtension = this.driverExtensions[i];
/*      */     
/*  459 */     if (oracleDriverExtension == null) {
/*      */       
/*      */       try {
/*      */ 
/*      */         
/*  464 */         synchronized (this)
/*      */         {
/*  466 */           if (oracleDriverExtension == null)
/*      */           {
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*  472 */             oracleDriverExtension = (OracleDriverExtension)Class.forName(driverExtensionClassNames[i]).newInstance();
/*      */             
/*  474 */             this.driverExtensions[i] = oracleDriverExtension;
/*      */           }
/*      */           else
/*      */           {
/*  478 */             oracleDriverExtension = this.driverExtensions[i];
/*      */           }
/*      */         
/*      */         }
/*      */       
/*  483 */       } catch (Exception exception) {
/*      */ 
/*      */         
/*  486 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), exception);
/*  487 */         sQLException.fillInStackTrace();
/*  488 */         throw sQLException;
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  495 */     if (paramProperties == null) {
/*  496 */       paramProperties = new Properties();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  507 */     Enumeration<Driver> enumeration = DriverManager.getDrivers();
/*      */ 
/*      */     
/*  510 */     while (enumeration.hasMoreElements()) {
/*      */       
/*  512 */       Driver driver = enumeration.nextElement();
/*      */       
/*  514 */       if (driver instanceof OracleDriver) {
/*      */         break;
/*      */       }
/*      */     } 
/*      */     
/*  519 */     while (enumeration.hasMoreElements()) {
/*      */       
/*  521 */       Driver driver = enumeration.nextElement();
/*      */       
/*  523 */       if (driver instanceof OracleDriver) {
/*  524 */         DriverManager.deregisterDriver(driver);
/*      */       }
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  531 */     Connection connection = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  541 */     if (i != 2 || !paramProperties.containsKey("connection_pool") || !paramProperties.getProperty("connection_pool").equals("connection_pool")) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  546 */       String str = null;
/*  547 */       if (paramProperties != null)
/*      */       {
/*  549 */         str = paramProperties.getProperty("oracle.jdbc.sqlTranslationProfile");
/*      */       }
/*  551 */       if (str == null)
/*      */       {
/*  553 */         str = PhysicalConnection.getSqlTranslationProfile();
/*      */       }
/*      */ 
/*      */       
/*  557 */       if (str != null)
/*      */       {
/*  559 */         connection = babelfishConnect(paramProperties, str, paramString, oracleDriverExtension, i);
/*      */       
/*      */       }
/*      */       else
/*      */       {
/*  564 */         physicalConnection = (PhysicalConnection)oracleDriverExtension.getConnection(paramString, paramProperties);
/*  565 */         physicalConnection.protocolId = i;
/*      */       }
/*      */     
/*      */     }
/*      */     else {
/*      */       
/*  571 */       physicalConnection = (PhysicalConnection)oracleDriverExtension.getConnection(paramString, paramProperties);
/*  572 */       physicalConnection.protocolId = i;
/*      */     } 
/*      */ 
/*      */     
/*  576 */     return (Connection)physicalConnection;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private Connection babelfishConnect(Properties paramProperties, String paramString1, String paramString2, OracleDriverExtension paramOracleDriverExtension, int paramInt) throws SQLException {
/*  591 */     paramProperties.put("oracle.jdbc.sqlTranslationProfile", paramString1);
/*      */ 
/*      */     
/*  594 */     paramString1 = null;
/*  595 */     if (paramProperties != null)
/*      */     {
/*  597 */       paramString1 = paramProperties.getProperty("oracle.jdbc.sqlErrorTranslationFile");
/*      */     }
/*  599 */     if (paramString1 == null)
/*      */     {
/*  601 */       paramString1 = System.getProperty("oracle.jdbc.sqlErrorTranslationFile", null);
/*      */     }
/*  603 */     if (paramString1 != null)
/*      */     {
/*  605 */       paramProperties.put("oracle.jdbc.sqlErrorTranslationFile", paramString1);
/*      */     }
/*      */ 
/*      */     
/*  609 */     paramString1 = null;
/*  610 */     if (paramProperties != null) {
/*      */       
/*  612 */       paramString1 = paramProperties.getProperty("user");
/*  613 */       if (paramString1 == null)
/*      */       {
/*  615 */         paramString1 = paramProperties.getProperty("oracle.jdbc.user");
/*      */       }
/*      */     } 
/*  618 */     if (paramString1 == null)
/*      */     {
/*  620 */       paramString1 = System.getProperty("oracle.jdbc.user", null);
/*      */     }
/*  622 */     if (paramString1 == null) {
/*      */       
/*  624 */       Hashtable hashtable = PhysicalConnection.parseUrl(paramString2, null, null);
/*  625 */       paramString1 = (String)hashtable.get("user");
/*      */     } 
/*      */     
/*  628 */     paramProperties.put("user", paramString1);
/*      */ 
/*      */ 
/*      */     
/*  632 */     ProxyFactory proxyFactory = ProxyFactory.createJDBCProxyFactory(new Class[] { BabelfishGenericProxy.class, BabelfishConnection.class, BabelfishStatement.class, BabelfishPreparedStatement.class, BabelfishCallableStatement.class });
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  644 */     Translator translator = TranslationManager.getTranslator(paramString2, paramProperties.getProperty("user"), paramProperties.getProperty("oracle.jdbc.sqlTranslationProfile"), paramProperties.getProperty("oracle.jdbc.sqlErrorTranslationFile"));
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     try {
/*  652 */       PhysicalConnection physicalConnection = (PhysicalConnection)paramOracleDriverExtension.getConnection(paramString2, paramProperties);
/*  653 */       physicalConnection.protocolId = paramInt;
/*      */       
/*  655 */       Connection connection = (Connection)proxyFactory.proxyFor(physicalConnection);
/*  656 */       ((BabelfishConnection)connection).setTranslator(translator);
/*  657 */       translator.activateServerTranslation((Connection)physicalConnection);
/*  658 */       return connection;
/*      */     }
/*  660 */     catch (SQLException sQLException) {
/*      */       
/*  662 */       throw translator.translateError(sQLException);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Connection defaultConnection() throws SQLException {
/*  681 */     if (defaultConn == null || defaultConn.isClosed())
/*      */     {
/*  683 */       synchronized (OracleDriver.class) {
/*      */         
/*  685 */         if (defaultConn == null || defaultConn.isClosed())
/*      */         {
/*  687 */           defaultConn = connect("jdbc:oracle:kprb:", new Properties());
/*      */         }
/*      */       } 
/*      */     }
/*      */     
/*  692 */     return defaultConn;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static final int oracleDriverExtensionTypeFromURL(String paramString) {
/*  717 */     int i = paramString.indexOf(':');
/*      */     
/*  719 */     if (i == -1) {
/*  720 */       return -2;
/*      */     }
/*  722 */     if (!paramString.regionMatches(true, 0, "jdbc", 0, i)) {
/*  723 */       return -2;
/*      */     }
/*  725 */     i++;
/*      */     
/*  727 */     int j = paramString.indexOf(':', i);
/*      */     
/*  729 */     if (j == -1) {
/*  730 */       return -2;
/*      */     }
/*  732 */     if (!paramString.regionMatches(true, i, "oracle", 0, j - i))
/*      */     {
/*  734 */       return -2;
/*      */     }
/*  736 */     j++;
/*      */     
/*  738 */     int k = paramString.indexOf(':', j);
/*      */     
/*  740 */     String str = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  747 */     if (k == -1) {
/*  748 */       return -3;
/*      */     }
/*  750 */     str = paramString.substring(j, k);
/*      */     
/*  752 */     if (str.equals("thin")) {
/*  753 */       return 0;
/*      */     }
/*  755 */     if (str.equals("oci8") || str.equals("oci")) {
/*  756 */       return 2;
/*      */     }
/*      */ 
/*      */     
/*  760 */     return -3;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean acceptsURL(String paramString) {
/*  785 */     if (paramString.startsWith("jdbc:oracle:"))
/*      */     {
/*  787 */       return (oracleDriverExtensionTypeFromURL(paramString) > -2);
/*      */     }
/*      */     
/*  790 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public DriverPropertyInfo[] getPropertyInfo(String paramString, Properties paramProperties) throws SQLException {
/*  803 */     Class<?> clazz = null;
/*      */     
/*      */     try {
/*  806 */       clazz = Class.forName("oracle.jdbc.OracleConnection");
/*      */     }
/*  808 */     catch (ClassNotFoundException classNotFoundException) {}
/*      */     
/*  810 */     byte b1 = 0;
/*  811 */     String[] arrayOfString1 = new String[150];
/*  812 */     String[] arrayOfString2 = new String[150];
/*      */     
/*  814 */     Field[] arrayOfField = clazz.getFields();
/*  815 */     for (byte b2 = 0; b2 < arrayOfField.length; b2++) {
/*      */       
/*  817 */       if (arrayOfField[b2].getName().startsWith("CONNECTION_PROPERTY_") && !arrayOfField[b2].getName().endsWith("_DEFAULT") && !arrayOfField[b2].getName().endsWith("_ACCESSMODE")) {
/*      */         
/*      */         try {
/*      */ 
/*      */ 
/*      */           
/*  823 */           String str1 = (String)arrayOfField[b2].get(null);
/*  824 */           Field field = clazz.getField(arrayOfField[b2].getName() + "_DEFAULT");
/*  825 */           String str2 = (String)field.get(null);
/*  826 */           if (b1 == arrayOfString1.length) {
/*      */             
/*  828 */             String[] arrayOfString3 = new String[arrayOfString1.length * 2];
/*  829 */             String[] arrayOfString4 = new String[arrayOfString1.length * 2];
/*  830 */             System.arraycopy(arrayOfString1, 0, arrayOfString3, 0, arrayOfString1.length);
/*  831 */             System.arraycopy(arrayOfString2, 0, arrayOfString4, 0, arrayOfString1.length);
/*  832 */             arrayOfString1 = arrayOfString3;
/*  833 */             arrayOfString2 = arrayOfString4;
/*      */           } 
/*  835 */           arrayOfString1[b1] = str1;
/*  836 */           arrayOfString2[b1] = str2;
/*  837 */           b1++;
/*      */         }
/*  839 */         catch (IllegalAccessException illegalAccessException) {
/*      */         
/*  841 */         } catch (NoSuchFieldException noSuchFieldException) {}
/*      */       }
/*      */     } 
/*      */     
/*  845 */     DriverPropertyInfo[] arrayOfDriverPropertyInfo = new DriverPropertyInfo[b1];
/*  846 */     for (byte b3 = 0; b3 < b1; b3++)
/*  847 */       arrayOfDriverPropertyInfo[b3] = new DriverPropertyInfo(arrayOfString1[b3], arrayOfString2[b3]); 
/*  848 */     return arrayOfDriverPropertyInfo;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getMajorVersion() {
/*  860 */     return OracleDatabaseMetaData.getDriverMajorVersionInfo();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getMinorVersion() {
/*  872 */     return OracleDatabaseMetaData.getDriverMinorVersionInfo();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean jdbcCompliant() {
/*  884 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String processSqlEscapes(String paramString) throws SQLException {
/*  904 */     OracleSql oracleSql = new OracleSql(null);
/*      */ 
/*      */ 
/*      */     
/*  908 */     oracleSql.initialize(paramString);
/*      */     
/*  910 */     return oracleSql.parse(paramString);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String getCompileTime() {
/*  925 */     return "Thu_Apr_04_15:09:24_PDT_2013";
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String getSystemPropertyFastConnectionFailover(String paramString) {
/*  932 */     return PhysicalConnection.getSystemPropertyFastConnectionFailover(paramString);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected OracleConnection getConnectionDuringExceptionHandling() {
/*  947 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Logger getParentLogger() throws SQLFeatureNotSupportedException {
/*  964 */     return Logger.getLogger("oracle");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void finalize() throws Throwable {
/*  977 */     if (diagnosticMBeanObjectName != null) {
/*      */       
/*      */       try {
/*      */         
/*  981 */         MBeanServer mBeanServer = null;
/*      */ 
/*      */ 
/*      */         
/*      */         try {
/*  986 */           Class<?> clazz = Class.forName("oracle.as.jmx.framework.PortableMBeanFactory");
/*  987 */           Object object = clazz.newInstance();
/*  988 */           Method method = clazz.getMethod("getMBeanServer", new Class[0]);
/*  989 */           mBeanServer = (MBeanServer)method.invoke(object, new Object[0]);
/*      */         }
/*  991 */         catch (Throwable throwable) {
/*      */ 
/*      */ 
/*      */           
/*  995 */           mBeanServer = ManagementFactory.getPlatformMBeanServer();
/*      */         } 
/*      */         
/*  998 */         if (mBeanServer != null) {
/*      */ 
/*      */           
/*      */           try {
/* 1002 */             mBeanServer.unregisterMBean(diagnosticMBeanObjectName);
/*      */           }
/* 1004 */           catch (InstanceNotFoundException instanceNotFoundException) {}
/*      */         } else {
/*      */           
/* 1007 */           Logger.getLogger("oracle.jdbc").log(Level.WARNING, "Unable to find an MBeanServer so no MBeans are unregistered.");
/*      */         }
/*      */       
/*      */       }
/* 1011 */       catch (Throwable throwable) {
/*      */         
/* 1013 */         Logger.getLogger("oracle.jdbc").log(Level.WARNING, "Error while unregistering Oracle JDBC Diagnosability MBean.", throwable);
/*      */       } 
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1026 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*      */   public static final String BUILD_DATE = "Thu_Apr_04_15:09:24_PDT_2013";
/*      */   public static final boolean TRACE = false;
/*      */ }


/* Location:              C:\Users\olatu\OneDrive\Documents\Calypso\syncbase\sync_base.jar!\BOOT-INF\classes\ojdbc.jar!\oracle\jdbc\driver\OracleDriver.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */