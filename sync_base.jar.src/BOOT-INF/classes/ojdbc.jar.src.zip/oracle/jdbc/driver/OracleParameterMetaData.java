/*     */ package oracle.jdbc.driver;
/*     */ 
/*     */ import java.sql.Connection;
/*     */ import java.sql.ParameterMetaData;
/*     */ import java.sql.PreparedStatement;
/*     */ import java.sql.ResultSetMetaData;
/*     */ import java.sql.SQLException;
/*     */ import oracle.jdbc.internal.OracleConnection;
/*     */ import oracle.jdbc.internal.OracleParameterMetaData;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class OracleParameterMetaData
/*     */   implements OracleParameterMetaData
/*     */ {
/*  27 */   int parameterCount = 0; int[] isNullable; boolean[] isSigned;
/*     */   int[] precision;
/*     */   int[] scale;
/*     */   int[] parameterType;
/*     */   String[] parameterTypeName;
/*     */   String[] parameterClassName;
/*     */   int[] parameterMode;
/*     */   boolean throwUnsupportedFeature = false;
/*     */   int parameterNoNulls;
/*     */   int parameterNullable;
/*     */   int parameterNullableUnknown;
/*     */   int parameterModeUnknown;
/*     */   int parameterModeIn;
/*     */   int parameterModeInOut;
/*     */   int parameterModeOut;
/*     */   Object acProxy;
/*     */   
/*     */   static final ParameterMetaData getParameterMetaData(OracleSql paramOracleSql, Connection paramConnection) throws SQLException {
/*  45 */     OracleParameterMetaData oracleParameterMetaData = null;
/*  46 */     String str1 = paramOracleSql.getSql(true, true);
/*  47 */     int i = paramOracleSql.getParameterCount();
/*     */     
/*  49 */     OracleParameterMetaDataParser oracleParameterMetaDataParser = null;
/*  50 */     String str2 = null;
/*     */     
/*  52 */     if (!paramOracleSql.sqlKind.isPlsqlOrCall() && paramOracleSql.getReturnParameterCount() < 1 && i > 0) {
/*     */ 
/*     */ 
/*     */       
/*  56 */       oracleParameterMetaDataParser = new OracleParameterMetaDataParser();
/*  57 */       oracleParameterMetaDataParser.initialize(str1, paramOracleSql.sqlKind, i);
/*  58 */       str2 = oracleParameterMetaDataParser.getParameterMetaDataSql();
/*     */     } 
/*     */     
/*  61 */     if (str2 == null) {
/*     */       
/*  63 */       oracleParameterMetaData = new OracleParameterMetaData(i);
/*     */     } else {
/*     */       
/*  66 */       PreparedStatement preparedStatement = null;
/*     */       
/*     */       try {
/*  69 */         preparedStatement = paramConnection.prepareStatement(str2);
/*  70 */         ResultSetMetaData resultSetMetaData = preparedStatement.getMetaData();
/*  71 */         if (oracleParameterMetaDataParser.needBindStatusForParameterMetaData()) {
/*     */           
/*  73 */           oracleParameterMetaData = new OracleParameterMetaData(resultSetMetaData, paramOracleSql.getParameterCount(), oracleParameterMetaDataParser.getBindStatusForInsert());
/*     */         
/*     */         }
/*     */         else {
/*     */           
/*  78 */           oracleParameterMetaData = new OracleParameterMetaData(resultSetMetaData);
/*     */         } 
/*     */       } finally {
/*     */         
/*  82 */         if (preparedStatement != null) {
/*  83 */           preparedStatement.close();
/*     */         }
/*     */       } 
/*     */     } 
/*  87 */     return (ParameterMetaData)oracleParameterMetaData;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getParameterCount() throws SQLException {
/* 166 */     return this.parameterCount;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   void checkValidIndex(int paramInt) throws SQLException {
/* 172 */     if (this.throwUnsupportedFeature) {
/*     */ 
/*     */       
/* 175 */       SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException();
/* 176 */       sQLException.fillInStackTrace();
/* 177 */       throw sQLException;
/*     */     } 
/* 179 */     if (paramInt < 1 || paramInt > this.parameterCount) {
/*     */ 
/*     */       
/* 182 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 183 */       sQLException.fillInStackTrace();
/* 184 */       throw sQLException;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int isNullable(int paramInt) throws SQLException {
/* 210 */     checkValidIndex(paramInt);
/* 211 */     return this.isNullable[paramInt - 1];
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private OracleParameterMetaData(ResultSetMetaData paramResultSetMetaData) throws SQLException {
/* 221 */     this.parameterNoNulls = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 229 */     this.parameterNullable = 1;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 237 */     this.parameterNullableUnknown = 2;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 390 */     this.parameterModeUnknown = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 397 */     this.parameterModeIn = 1;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 404 */     this.parameterModeInOut = 2;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 411 */     this.parameterModeOut = 4; this.parameterCount = paramResultSetMetaData.getColumnCount(); this.isNullable = new int[this.parameterCount]; this.isSigned = new boolean[this.parameterCount]; this.precision = new int[this.parameterCount]; this.scale = new int[this.parameterCount]; this.parameterType = new int[this.parameterCount]; this.parameterTypeName = new String[this.parameterCount]; this.parameterClassName = new String[this.parameterCount]; this.parameterMode = new int[this.parameterCount]; for (byte b1 = 1, b2 = 0; b1 <= this.parameterCount; b1++, b2++) { this.isNullable[b2] = paramResultSetMetaData.isNullable(b1); this.isSigned[b2] = paramResultSetMetaData.isSigned(b1); this.precision[b2] = paramResultSetMetaData.getPrecision(b1); this.scale[b2] = paramResultSetMetaData.getScale(b1); this.parameterType[b2] = paramResultSetMetaData.getColumnType(b1); this.parameterTypeName[b2] = paramResultSetMetaData.getColumnTypeName(b1); this.parameterClassName[b2] = paramResultSetMetaData.getColumnClassName(b1); this.parameterMode[b2] = this.parameterModeIn; }  } private OracleParameterMetaData(ResultSetMetaData paramResultSetMetaData, int paramInt, byte[] paramArrayOfbyte) throws SQLException { this.parameterNoNulls = 0; this.parameterNullable = 1; this.parameterNullableUnknown = 2; this.parameterModeUnknown = 0; this.parameterModeIn = 1; this.parameterModeInOut = 2; this.parameterModeOut = 4; this.parameterCount = paramInt; this.isNullable = new int[this.parameterCount]; this.isSigned = new boolean[this.parameterCount]; this.precision = new int[this.parameterCount]; this.scale = new int[this.parameterCount]; this.parameterType = new int[this.parameterCount]; this.parameterTypeName = new String[this.parameterCount]; this.parameterClassName = new String[this.parameterCount]; this.parameterMode = new int[this.parameterCount]; for (byte b1 = 1, b2 = 0; b1 <= this.parameterCount; b1++) { if (paramArrayOfbyte[b1 - 1] == 1) { this.isNullable[b2] = paramResultSetMetaData.isNullable(b1); this.isSigned[b2] = paramResultSetMetaData.isSigned(b1); this.precision[b2] = paramResultSetMetaData.getPrecision(b1); this.scale[b2] = paramResultSetMetaData.getScale(b1); this.parameterType[b2] = paramResultSetMetaData.getColumnType(b1); this.parameterTypeName[b2] = paramResultSetMetaData.getColumnTypeName(b1); this.parameterClassName[b2] = paramResultSetMetaData.getColumnClassName(b1); this.parameterMode[b2] = this.parameterModeIn; b2++; }  }  } OracleParameterMetaData(int paramInt) throws SQLException { this.parameterNoNulls = 0; this.parameterNullable = 1; this.parameterNullableUnknown = 2; this.parameterModeUnknown = 0; this.parameterModeIn = 1; this.parameterModeInOut = 2; this.parameterModeOut = 4;
/*     */     this.parameterCount = paramInt;
/*     */     this.throwUnsupportedFeature = true; }
/*     */    public boolean isSigned(int paramInt) throws SQLException {
/*     */     checkValidIndex(paramInt);
/*     */     return this.isSigned[paramInt - 1];
/*     */   } public int getPrecision(int paramInt) throws SQLException {
/*     */     checkValidIndex(paramInt);
/*     */     return this.precision[paramInt - 1];
/*     */   } public int getScale(int paramInt) throws SQLException {
/*     */     checkValidIndex(paramInt);
/*     */     return this.scale[paramInt - 1];
/*     */   } public int getParameterType(int paramInt) throws SQLException {
/*     */     checkValidIndex(paramInt);
/*     */     return this.parameterType[paramInt - 1];
/*     */   } public String getParameterTypeName(int paramInt) throws SQLException {
/*     */     checkValidIndex(paramInt);
/*     */     return this.parameterTypeName[paramInt - 1];
/*     */   }
/*     */   public String getParameterClassName(int paramInt) throws SQLException {
/*     */     checkValidIndex(paramInt);
/*     */     return this.parameterClassName[paramInt - 1];
/*     */   }
/*     */   public int getParameterMode(int paramInt) throws SQLException {
/* 435 */     checkValidIndex(paramInt);
/* 436 */     return this.parameterMode[paramInt - 1];
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isWrapperFor(Class<?> paramClass) throws SQLException {
/* 456 */     if (paramClass.isInterface()) return paramClass.isInstance(this);
/*     */     
/* 458 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 177);
/* 459 */     sQLException.fillInStackTrace();
/* 460 */     throw sQLException;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <T> T unwrap(Class<T> paramClass) throws SQLException {
/* 482 */     if (paramClass.isInterface() && paramClass.isInstance(this)) return (T)this;
/*     */     
/* 484 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 177);
/* 485 */     sQLException.fillInStackTrace();
/* 486 */     throw sQLException;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected OracleConnection getConnectionDuringExceptionHandling() {
/* 502 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setACProxy(Object paramObject) {
/* 510 */     this.acProxy = paramObject;
/*     */   }
/*     */ 
/*     */   
/*     */   public Object getACProxy() {
/* 515 */     return this.acProxy;
/*     */   }
/*     */ 
/*     */   
/* 519 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*     */   public static final String BUILD_DATE = "Thu_Apr_04_15:09:24_PDT_2013";
/*     */   public static final boolean TRACE = false;
/*     */ }


/* Location:              C:\Users\olatu\OneDrive\Documents\Calypso\syncbase\sync_base.jar!\BOOT-INF\classes\ojdbc.jar!\oracle\jdbc\driver\OracleParameterMetaData.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */