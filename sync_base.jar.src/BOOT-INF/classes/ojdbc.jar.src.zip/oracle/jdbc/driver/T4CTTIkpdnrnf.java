/*     */ package oracle.jdbc.driver;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.sql.SQLException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class T4CTTIkpdnrnf
/*     */ {
/*     */   int messageType;
/*     */   int errorCode;
/*     */   long registrationId;
/*  54 */   byte[] notificationQueue = null;
/*     */ 
/*     */   
/*  57 */   byte[] consumerName = null;
/*  58 */   String consumerNameString = null;
/*  59 */   T4CConnection connection = null;
/*     */   
/*     */   T4CMAREngine mar;
/*     */   
/*     */   T4CTTIkpdnrnf(T4CConnection paramT4CConnection) {
/*  64 */     this.mar = paramT4CConnection.mare;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void receive() throws SQLException, IOException {
/*  70 */     this.messageType = (int)this.mar.unmarshalUB4();
/*  71 */     this.errorCode = (int)this.mar.unmarshalUB4();
/*  72 */     this.registrationId = this.mar.unmarshalUB4();
/*     */     
/*  74 */     int i = (int)this.mar.unmarshalUB4();
/*  75 */     if (i > 0) {
/*  76 */       this.notificationQueue = new byte[i];
/*  77 */       int[] arrayOfInt = new int[1];
/*  78 */       this.mar.unmarshalCLR(this.notificationQueue, 0, arrayOfInt, this.notificationQueue.length);
/*  79 */       i = arrayOfInt[0];
/*     */     } 
/*     */     
/*  82 */     int j = (int)this.mar.unmarshalUB4();
/*  83 */     if (j > 0) {
/*  84 */       this.consumerName = new byte[j];
/*  85 */       int[] arrayOfInt = new int[1];
/*  86 */       this.mar.unmarshalCLR(this.consumerName, 0, arrayOfInt, this.consumerName.length);
/*  87 */       j = arrayOfInt[0];
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getNotificationQueue() throws SQLException {
/*  97 */     return this.mar.conv.CharBytesToString(this.notificationQueue, this.notificationQueue.length);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public long getRegistrationId() {
/* 107 */     return this.registrationId;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getConsumerName() throws SQLException {
/* 116 */     if (this.consumerName == null) {
/* 117 */       return null;
/*     */     }
/*     */     
/* 120 */     return this.mar.conv.CharBytesToString(this.consumerName, this.consumerName.length);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/* 125 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*     */   public static final String BUILD_DATE = "Thu_Apr_04_15:09:24_PDT_2013";
/*     */   public static final boolean TRACE = false;
/*     */ }


/* Location:              C:\Users\olatu\OneDrive\Documents\Calypso\syncbase\sync_base.jar!\BOOT-INF\classes\ojdbc.jar!\oracle\jdbc\driver\T4CTTIkpdnrnf.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */