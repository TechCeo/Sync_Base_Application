/*     */ package oracle.jdbc.driver;
/*     */ 
/*     */ import java.sql.SQLException;
/*     */ import oracle.sql.CharacterSet;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class AggregateByteArray
/*     */   extends SimpleByteArray
/*     */ {
/*     */   protected ByteArray extension;
/*     */   
/*     */   AggregateByteArray(byte[] paramArrayOfbyte, ByteArray paramByteArray) {
/*  29 */     super(paramArrayOfbyte);
/*  30 */     this.extension = paramByteArray;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   long length() {
/*  39 */     return this.bytes.length + this.extension.length();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void put(long paramLong, byte paramByte) {
/*  53 */     if (paramLong < this.bytes.length) { super.put(paramLong, paramByte); }
/*  54 */     else { this.extension.put(paramLong - this.bytes.length, paramByte); }
/*     */   
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   byte get(long paramLong) {
/*  69 */     if (paramLong < this.bytes.length) return super.get(paramLong); 
/*  70 */     return this.extension.get(paramLong - this.bytes.length);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void put(long paramLong, byte[] paramArrayOfbyte, int paramInt1, int paramInt2) {
/*     */     assert false;
/*  90 */     if (paramLong < this.bytes.length) { super.put(paramLong, paramArrayOfbyte, paramInt1, paramInt2); }
/*  91 */     else { this.extension.put(paramLong - this.bytes.length, paramArrayOfbyte, paramInt1, paramInt2); }
/*     */   
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void get(long paramLong, byte[] paramArrayOfbyte, int paramInt1, int paramInt2) {
/*     */     assert false;
/* 111 */     if (paramLong < this.bytes.length) { super.get(paramLong, paramArrayOfbyte, paramInt1, paramInt2); }
/* 112 */     else { this.extension.get(paramLong - this.bytes.length, paramArrayOfbyte, paramInt1, paramInt2); }
/*     */   
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   char[] getChars(long paramLong, int paramInt, CharacterSet paramCharacterSet, int[] paramArrayOfint) throws SQLException {
/*     */     assert false;
/* 138 */     if (paramLong < this.bytes.length) return super.getChars(paramLong, paramInt, paramCharacterSet, paramArrayOfint); 
/* 139 */     return this.extension.getChars(paramLong - this.bytes.length, paramInt, paramCharacterSet, paramArrayOfint);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   long updateChecksum(long paramLong1, int paramInt, CRC64 paramCRC64, long paramLong2) {
/*     */     assert false;
/* 156 */     if (paramLong1 < this.bytes.length) return super.updateChecksum(paramLong1, paramInt, paramCRC64, paramLong2); 
/* 157 */     return this.extension.updateChecksum(paramLong1 - this.bytes.length, paramInt, paramCRC64, paramLong2);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   byte[] getBlockBasic(long paramLong, int[] paramArrayOfint) {
/* 166 */     if (paramLong < this.bytes.length) {
/* 167 */       return super.getBlockBasic(paramLong, paramArrayOfint);
/*     */     }
/* 169 */     return this.extension.getBlockBasic(paramLong, paramArrayOfint);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void free() {
/* 177 */     super.free();
/* 178 */     this.extension.free();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/* 183 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*     */   public static final String BUILD_DATE = "Thu_Apr_04_15:09:24_PDT_2013";
/*     */   public static final boolean TRACE = false;
/*     */ }


/* Location:              C:\Users\olatu\OneDrive\Documents\Calypso\syncbase\sync_base.jar!\BOOT-INF\classes\ojdbc.jar!\oracle\jdbc\driver\AggregateByteArray.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */