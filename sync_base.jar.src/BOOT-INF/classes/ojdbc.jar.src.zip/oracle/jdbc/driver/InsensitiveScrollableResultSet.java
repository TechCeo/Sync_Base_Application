/*      */ package oracle.jdbc.driver;
/*      */ 
/*      */ import java.sql.ResultSetMetaData;
/*      */ import java.sql.RowId;
/*      */ import java.sql.SQLException;
/*      */ import java.sql.SQLRecoverableException;
/*      */ import java.sql.Statement;
/*      */ import oracle.jdbc.OracleResultSet;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ class InsensitiveScrollableResultSet
/*      */   extends GeneratedScrollableResultSet
/*      */ {
/*      */   protected boolean isComplete;
/*      */   protected boolean isDoneFetchingRows;
/*      */   protected final int maxRows;
/*      */   
/*      */   InsensitiveScrollableResultSet(PhysicalConnection paramPhysicalConnection, OracleStatement paramOracleStatement) throws SQLException {
/*   66 */     super(paramPhysicalConnection, paramOracleStatement);
/*      */     
/*   68 */     this.closeStatementOnClose = (paramOracleStatement == null) ? false : paramOracleStatement.isCloseOnCompletion();
/*   69 */     this.isDoneFetchingRows = false;
/*   70 */     this.fetchedRowCount = paramOracleStatement.validRows;
/*   71 */     this.isComplete = paramOracleStatement.isComplete;
/*   72 */     this.maxRows = paramOracleStatement.getMaxRows();
/*   73 */     if (this.maxRows > 0 && this.maxRows < this.fetchedRowCount) {
/*   74 */       this.fetchedRowCount = this.maxRows;
/*   75 */       doneFetchingRows(false);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean isForwardOnly() {
/*   94 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getType() {
/*  113 */     return 1004;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getConcurrency() {
/*  129 */     return 1007;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public String getCursorName() throws SQLException {
/*  135 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  143 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 23, "getCursorName");
/*  144 */       sQLException.fillInStackTrace();
/*  145 */       throw sQLException;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void close() throws SQLException {
/*  156 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  163 */       if (this.closed)
/*  164 */         return;  super.close();
/*      */ 
/*      */       
/*  167 */       if (this.statement.numReturnParams > 0)
/*      */         return; 
/*  169 */       doneFetchingRows(false);
/*  170 */       this.statement.endOfResultSet(false);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  177 */       this.statement.closeCursorOnPlainStatement();
/*      */       
/*  179 */       if (this.closeStatementOnClose) {
/*      */         try {
/*  181 */           this.statement.close();
/*      */         }
/*  183 */         catch (SQLException sQLException) {}
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean wasNull() throws SQLException {
/*  191 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  199 */       if (this.closed) {
/*      */         
/*  201 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 10, "wasNull");
/*  202 */         sQLException.fillInStackTrace();
/*  203 */         throw sQLException;
/*      */       } 
/*      */       
/*  206 */       return this.statement.wasNullValue(this.currentRow);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean rowDeleted() throws SQLException {
/*  218 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public ResultSetMetaData getMetaData() throws SQLException {
/*  224 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  231 */       if (this.closed) {
/*      */         
/*  233 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 10, "getMetaData");
/*  234 */         sQLException.fillInStackTrace();
/*  235 */         throw sQLException;
/*      */       } 
/*      */       
/*  238 */       if (this.statement.closed) {
/*      */         
/*  240 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9, "getMetaData");
/*  241 */         sQLException.fillInStackTrace();
/*  242 */         throw sQLException;
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  248 */       if (!this.statement.isOpen) {
/*      */         
/*  250 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 144, "getMetaData");
/*  251 */         sQLException.fillInStackTrace();
/*  252 */         throw sQLException;
/*      */       } 
/*      */       
/*  255 */       return this.statement.getResultSetMetaData();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public Statement getStatement() throws SQLException {
/*  262 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  270 */       if (this.closed) {
/*  271 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 10, "getStatement");
/*  272 */         sQLException.fillInStackTrace();
/*  273 */         throw sQLException;
/*      */       } 
/*  275 */       if (this.statement.closed) {
/*  276 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9, "getStatement");
/*  277 */         sQLException.fillInStackTrace();
/*  278 */         throw sQLException;
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/*  283 */       return (this.statement.wrapper == null) ? (Statement)this.statement : (Statement)this.statement.wrapper;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int findColumn(String paramString) throws SQLException {
/*  292 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  299 */       return this.statement.getColumnIndex(paramString);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public void setFetchSize(int paramInt) throws SQLException {
/*  305 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  312 */       this.statement.setPrefetchInternal(paramInt, false, false);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public int getFetchSize() throws SQLException {
/*  318 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  325 */       return this.statement.getPrefetchInternal(false);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isBeforeFirst() throws SQLException {
/*  335 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  342 */       if (this.closed) {
/*  343 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 10, "isBeforeFirst");
/*  344 */         sQLException.fillInStackTrace();
/*  345 */         throw sQLException;
/*      */       } 
/*  347 */       if (this.statement.closed) {
/*  348 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9, "isBeforeFirst");
/*  349 */         sQLException.fillInStackTrace();
/*  350 */         throw sQLException;
/*      */       } 
/*  352 */       return (!isEmptyResultSet() && this.currentRow == -1);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isAfterLast() throws SQLException {
/*  362 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  369 */       if (this.closed) {
/*  370 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 10, "isAfterLast");
/*  371 */         sQLException.fillInStackTrace();
/*  372 */         throw sQLException;
/*      */       } 
/*  374 */       if (this.statement.closed) {
/*  375 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9, "isAfterLast");
/*  376 */         sQLException.fillInStackTrace();
/*  377 */         throw sQLException;
/*      */       } 
/*  379 */       return (this.currentRow == this.fetchedRowCount);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isFirst() throws SQLException {
/*  385 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  392 */       if (this.closed) {
/*  393 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 10, "isFirst");
/*  394 */         sQLException.fillInStackTrace();
/*  395 */         throw sQLException;
/*      */       } 
/*  397 */       if (this.statement.closed) {
/*  398 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9, "isFirst");
/*  399 */         sQLException.fillInStackTrace();
/*  400 */         throw sQLException;
/*      */       } 
/*  402 */       return (!isEmptyResultSet() && this.currentRow == 0);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isLast() throws SQLException {
/*  412 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  420 */       if (this.closed) {
/*  421 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 10, "isLast");
/*  422 */         sQLException.fillInStackTrace();
/*  423 */         throw sQLException;
/*      */       } 
/*  425 */       if (this.statement.closed) {
/*  426 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9, "isLast");
/*  427 */         sQLException.fillInStackTrace();
/*  428 */         throw sQLException;
/*      */       } 
/*  430 */       if (isForwardOnly()) {
/*  431 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 75, "isLast");
/*  432 */         sQLException.fillInStackTrace();
/*  433 */         throw sQLException;
/*      */       } 
/*      */       
/*  436 */       if (!this.isComplete && this.currentRow + 1 == this.fetchedRowCount) fetchMoreRows();
/*      */       
/*  438 */       assert this.isComplete || this.fetchedRowCount > this.currentRow + 1 : "isComplete: " + this.isComplete + ", fetchedRowCount: " + this.fetchedRowCount + ", currentRow: " + this.currentRow;
/*  439 */       if (this.fetchedRowCount == 0) return false; 
/*  440 */       return (this.isComplete && this.currentRow + 1 == this.fetchedRowCount);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public int getRow() throws SQLException {
/*  447 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  455 */       if (this.closed) {
/*  456 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 10, "getRow");
/*  457 */         sQLException.fillInStackTrace();
/*  458 */         throw sQLException;
/*      */       } 
/*  460 */       if (this.statement.closed) {
/*  461 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9, "getRow");
/*  462 */         sQLException.fillInStackTrace();
/*  463 */         throw sQLException;
/*      */       } 
/*      */       
/*  466 */       if (isEmptyResultSet()) return 0; 
/*  467 */       if (this.currentRow == this.fetchedRowCount) return 0; 
/*  468 */       return this.currentRow + 1;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean absolute(int paramInt) throws SQLException {
/*  482 */     if (this.closed) {
/*  483 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 10, "absolute");
/*  484 */       sQLException.fillInStackTrace();
/*  485 */       throw sQLException;
/*      */     } 
/*  487 */     if (this.connection.isClosed()) {
/*  488 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 8, "absolute");
/*  489 */       sQLException.fillInStackTrace();
/*  490 */       throw sQLException;
/*      */     } 
/*  492 */     if (this.statement.closed) {
/*  493 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9, "absolute");
/*  494 */       sQLException.fillInStackTrace();
/*  495 */       throw sQLException;
/*      */     } 
/*  497 */     if (isForwardOnly()) {
/*  498 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 75, "absolute");
/*  499 */       sQLException.fillInStackTrace();
/*  500 */       throw sQLException;
/*      */     } 
/*      */     
/*  503 */     return absoluteInternal(paramInt);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean first() throws SQLException {
/*  509 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  517 */       if (this.closed) {
/*  518 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 10, "first");
/*  519 */         sQLException.fillInStackTrace();
/*  520 */         throw sQLException;
/*      */       } 
/*  522 */       if (this.connection.isClosed()) {
/*  523 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 8, "first");
/*  524 */         sQLException.fillInStackTrace();
/*  525 */         throw sQLException;
/*      */       } 
/*  527 */       if (this.statement.closed) {
/*  528 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9, "first");
/*  529 */         sQLException.fillInStackTrace();
/*  530 */         throw sQLException;
/*      */       } 
/*  532 */       if (isForwardOnly()) {
/*  533 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 75, "first");
/*  534 */         sQLException.fillInStackTrace();
/*  535 */         throw sQLException;
/*      */       } 
/*  537 */       return absoluteInternal(1);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean next() throws SQLException {
/*  543 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  551 */       if (this.statement.sqlKind.isPlsqlOrCall()) {
/*  552 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 166, "next");
/*  553 */         sQLException.fillInStackTrace();
/*  554 */         throw sQLException;
/*      */       } 
/*  556 */       if (this.closed) {
/*  557 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 10, "next");
/*  558 */         sQLException.fillInStackTrace();
/*  559 */         throw sQLException;
/*      */       } 
/*  561 */       if (this.connection.isClosed()) {
/*  562 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 8, "next");
/*  563 */         sQLException.fillInStackTrace();
/*  564 */         throw sQLException;
/*      */       } 
/*  566 */       if (this.statement.closed) {
/*  567 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9, "next");
/*  568 */         sQLException.fillInStackTrace();
/*  569 */         throw sQLException;
/*      */       } 
/*      */       
/*  572 */       return absoluteInternal(this.currentRow + 2);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean previous() throws SQLException {
/*  578 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  586 */       if (this.closed) {
/*  587 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 10, "previous");
/*  588 */         sQLException.fillInStackTrace();
/*  589 */         throw sQLException;
/*      */       } 
/*  591 */       if (this.connection.isClosed()) {
/*  592 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 8, "previous");
/*  593 */         sQLException.fillInStackTrace();
/*  594 */         throw sQLException;
/*      */       } 
/*  596 */       if (this.statement.closed) {
/*  597 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9, "previous");
/*  598 */         sQLException.fillInStackTrace();
/*  599 */         throw sQLException;
/*      */       } 
/*      */       
/*  602 */       if (isForwardOnly()) {
/*  603 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 75, "previous");
/*  604 */         sQLException.fillInStackTrace();
/*  605 */         throw sQLException;
/*      */       } 
/*  607 */       if (this.currentRow > -1) return absoluteInternal(this.currentRow); 
/*  608 */       return false;
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean last() throws SQLException {
/*  614 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  622 */       if (this.closed) {
/*  623 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 10, "last");
/*  624 */         sQLException.fillInStackTrace();
/*  625 */         throw sQLException;
/*      */       } 
/*  627 */       if (this.connection.isClosed()) {
/*  628 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 8, "last");
/*  629 */         sQLException.fillInStackTrace();
/*  630 */         throw sQLException;
/*      */       } 
/*  632 */       if (this.statement.closed) {
/*  633 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9, "last");
/*  634 */         sQLException.fillInStackTrace();
/*  635 */         throw sQLException;
/*      */       } 
/*  637 */       if (isForwardOnly()) {
/*  638 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 75, "last");
/*  639 */         sQLException.fillInStackTrace();
/*  640 */         throw sQLException;
/*      */       } 
/*      */       
/*  643 */       if (isEmptyResultSet()) return false; 
/*  644 */       for (; !this.isComplete; fetchMoreRows());
/*  645 */       this.currentRow = this.fetchedRowCount - 1;
/*  646 */       return true;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void beforeFirst() throws SQLException {
/*  661 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  669 */       if (this.closed) {
/*  670 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 10, "beforeFirst");
/*  671 */         sQLException.fillInStackTrace();
/*  672 */         throw sQLException;
/*      */       } 
/*  674 */       if (this.connection.isClosed()) {
/*  675 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 8, "beforeFirst");
/*  676 */         sQLException.fillInStackTrace();
/*  677 */         throw sQLException;
/*      */       } 
/*  679 */       if (this.statement.closed) {
/*  680 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9, "beforeFirst");
/*  681 */         sQLException.fillInStackTrace();
/*  682 */         throw sQLException;
/*      */       } 
/*  684 */       if (isForwardOnly()) {
/*  685 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 75, "beforeFirst");
/*  686 */         sQLException.fillInStackTrace();
/*  687 */         throw sQLException;
/*      */       } 
/*      */       
/*  690 */       absolute(0);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void afterLast() throws SQLException {
/*  705 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  713 */       if (this.closed) {
/*  714 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 10, "afterLast");
/*  715 */         sQLException.fillInStackTrace();
/*  716 */         throw sQLException;
/*      */       } 
/*  718 */       if (this.connection.isClosed()) {
/*  719 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 8, "afterLast");
/*  720 */         sQLException.fillInStackTrace();
/*  721 */         throw sQLException;
/*      */       } 
/*  723 */       if (this.statement.closed) {
/*  724 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9, "afterLast");
/*  725 */         sQLException.fillInStackTrace();
/*  726 */         throw sQLException;
/*      */       } 
/*  728 */       if (isForwardOnly()) {
/*  729 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 75, "afterLast");
/*  730 */         sQLException.fillInStackTrace();
/*  731 */         throw sQLException;
/*      */       } 
/*      */       
/*  734 */       if (!isEmptyResultSet()) {
/*  735 */         for (; !this.isComplete; fetchMoreRows());
/*  736 */         this.currentRow = this.fetchedRowCount;
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean relative(int paramInt) throws SQLException {
/*  743 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  751 */       if (this.closed) {
/*  752 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 10, "relative");
/*  753 */         sQLException.fillInStackTrace();
/*  754 */         throw sQLException;
/*      */       } 
/*  756 */       if (this.connection.isClosed()) {
/*  757 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 8, "relative");
/*  758 */         sQLException.fillInStackTrace();
/*  759 */         throw sQLException;
/*      */       } 
/*  761 */       if (this.statement.closed) {
/*  762 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9, "relative");
/*  763 */         sQLException.fillInStackTrace();
/*  764 */         throw sQLException;
/*      */       } 
/*  766 */       if (isForwardOnly()) {
/*  767 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 75, "relative");
/*  768 */         sQLException.fillInStackTrace();
/*  769 */         throw sQLException;
/*      */       } 
/*  771 */       if (paramInt == 0) return isValidRow(); 
/*  772 */       if (paramInt == 1) return next(); 
/*  773 */       if (paramInt == -1) return previous(); 
/*  774 */       if (this.currentRow + paramInt < 0) return absoluteInternal(0); 
/*  775 */       return absoluteInternal(this.currentRow + paramInt + 1);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public void refreshRow() throws SQLException {
/*  781 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  789 */       if (!this.statement.isRowidPrepended || isForwardOnly()) {
/*      */         
/*  791 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 23, "refreshRow");
/*  792 */         sQLException.fillInStackTrace();
/*  793 */         throw sQLException;
/*      */       } 
/*      */       
/*  796 */       if (this.closed) {
/*  797 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 10, "refreshRow");
/*  798 */         sQLException.fillInStackTrace();
/*  799 */         throw sQLException;
/*      */       } 
/*  801 */       if (this.statement.closed) {
/*  802 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9, "refreshRow");
/*  803 */         sQLException.fillInStackTrace();
/*  804 */         throw sQLException;
/*      */       } 
/*  806 */       if (this.currentRow < 0 || this.currentRow >= this.fetchedRowCount) {
/*      */         
/*  808 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 11);
/*  809 */         sQLException.fillInStackTrace();
/*  810 */         throw sQLException;
/*      */       } 
/*      */ 
/*      */       
/*      */       try {
/*  815 */         int i = this.currentRow + 1;
/*  816 */         if (getFetchDirection() == 1001) {
/*  817 */           i = Math.max(1, this.currentRow - getFetchSize() + 1);
/*      */         }
/*  819 */         refreshRows(i, getFetchSize());
/*      */       }
/*  821 */       catch (SQLRecoverableException sQLRecoverableException) {
/*      */         
/*  823 */         throw sQLRecoverableException;
/*      */       }
/*  825 */       catch (SQLException sQLException1) {
/*      */         
/*  827 */         SQLException sQLException2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Unsupported syntax for refreshRow()", sQLException1);
/*  828 */         sQLException2.fillInStackTrace();
/*  829 */         throw sQLException2;
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <T> T getObject(int paramInt, Class<T> paramClass) throws SQLException {
/*  871 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  879 */       if (this.closed) {
/*      */         
/*  881 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 11);
/*  882 */         sQLException.fillInStackTrace();
/*  883 */         throw sQLException;
/*      */       } 
/*  885 */       if (this.statement.closed) {
/*  886 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9, "getObject");
/*  887 */         sQLException.fillInStackTrace();
/*  888 */         throw sQLException;
/*      */       } 
/*  890 */       if (paramInt < 1 || paramInt > this.statement.getNumberOfColumns()) {
/*      */         
/*  892 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/*  893 */         sQLException.fillInStackTrace();
/*  894 */         throw sQLException;
/*      */       } 
/*  896 */       if (this.currentRow < 0) {
/*      */         
/*  898 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 14);
/*  899 */         sQLException.fillInStackTrace();
/*  900 */         throw sQLException;
/*      */       } 
/*  902 */       if (this.currentRow == this.fetchedRowCount) {
/*      */         
/*  904 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 289);
/*  905 */         sQLException.fillInStackTrace();
/*  906 */         throw sQLException;
/*      */       } 
/*      */       
/*  909 */       return this.statement.getObject(this.currentRow, paramInt, paramClass);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public OracleResultSet.AuthorizationIndicator getAuthorizationIndicator(int paramInt) throws SQLException {
/*  919 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  927 */       if (this.closed) {
/*      */         
/*  929 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 11);
/*  930 */         sQLException.fillInStackTrace();
/*  931 */         throw sQLException;
/*      */       } 
/*  933 */       if (this.currentRow < 0) {
/*      */         
/*  935 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 14);
/*  936 */         sQLException.fillInStackTrace();
/*  937 */         throw sQLException;
/*      */       } 
/*  939 */       if (this.currentRow == this.fetchedRowCount) {
/*      */         
/*  941 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 289);
/*  942 */         sQLException.fillInStackTrace();
/*  943 */         throw sQLException;
/*      */       } 
/*      */       
/*  946 */       return this.statement.getAuthorizationIndicator(this.currentRow, paramInt);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean absoluteInternal(int paramInt) throws SQLException {
/*  967 */     int i = paramInt - 1;
/*      */     
/*  969 */     if (paramInt == 0) { this.currentRow = i; }
/*  970 */     else if (i >= 0 && i < this.fetchedRowCount) { this.currentRow = i; }
/*  971 */     else if (i >= 0)
/*  972 */     { for (; !this.isComplete && this.fetchedRowCount <= i; fetchMoreRows());
/*  973 */       if (i < this.fetchedRowCount) { this.currentRow = i; }
/*      */       else
/*  975 */       { assert this.isComplete : "isComplete: " + this.isComplete;
/*  976 */         this.currentRow = this.fetchedRowCount;
/*  977 */         if (isForwardOnly()) doneFetchingRows(false);
/*      */          }
/*      */        }
/*      */     else
/*  981 */     { for (; !this.isComplete; fetchMoreRows());
/*  982 */       i = this.fetchedRowCount + paramInt;
/*  983 */       if (i >= 0 && i < this.fetchedRowCount) { this.currentRow = i; }
/*  984 */       else { this.currentRow = -1; }
/*      */        }
/*      */     
/*  987 */     assert this.currentRow < this.fetchedRowCount || this.isComplete : "currentRow: " + this.currentRow + ", fetchedRowCount: " + this.fetchedRowCount + ", isComplete: " + this.isComplete;
/*      */     
/*  989 */     assert -1 <= this.currentRow && this.currentRow <= this.fetchedRowCount : "currentRow: " + this.currentRow + ", fetchedRowCount: " + this.fetchedRowCount;
/*  990 */     return (this.currentRow > -1 && this.currentRow < this.fetchedRowCount);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void fetchMoreRows() throws SQLException {
/* 1005 */     assert !this.isComplete : "isComplete: " + this.isComplete;
/* 1006 */     clearWarnings();
/*      */     
/* 1008 */     this.fetchedRowCount += this.statement.fetchMoreRows(this.fetchedRowCount);
/* 1009 */     this.isComplete = this.statement.isComplete;
/* 1010 */     if (this.currentRow == this.fetchedRowCount && isForwardOnly()) doneFetchingRows(false); 
/* 1011 */     if (this.maxRows > 0 && this.fetchedRowCount > this.maxRows) {
/* 1012 */       this.fetchedRowCount = this.maxRows;
/* 1013 */       doneFetchingRows(false);
/* 1014 */       this.sqlWarning = DatabaseError.addSqlWarning(this.sqlWarning, 275);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void doneFetchingRows(boolean paramBoolean) throws SQLException {
/* 1029 */     if (this.isDoneFetchingRows)
/*      */       return; 
/* 1031 */     this.isDoneFetchingRows = true;
/* 1032 */     this.isComplete = true;
/*      */     
/*      */     try {
/* 1035 */       this.statement.closeQuery();
/*      */     }
/* 1037 */     catch (SQLException sQLException) {}
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean isEmptyResultSet() throws SQLException {
/* 1051 */     if (this.fetchedRowCount > 0) return false; 
/* 1052 */     if (this.isComplete) return true;
/*      */     
/* 1054 */     fetchMoreRows();
/* 1055 */     assert this.fetchedRowCount >= 0 : "fetchedRowCount: " + this.fetchedRowCount;
/* 1056 */     return (this.fetchedRowCount == 0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   boolean isValidRow() throws SQLException {
/* 1066 */     return (this.currentRow > -1 && this.currentRow < this.fetchedRowCount);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected int getValidRows() {
/* 1077 */     return this.fetchedRowCount;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   OracleStatement getOracleStatement() throws SQLException {
/* 1086 */     synchronized (this.connection) {
/*      */       
/* 1088 */       return this.statement;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void removeCurrentRowFromCache() throws SQLException {
/* 1100 */     assert this.currentRow < this.fetchedRowCount : "currentRow:" + this.currentRow + " fetchedRowCount:" + this.fetchedRowCount;
/* 1101 */     if (!this.isComplete && this.currentRow + 1 == this.fetchedRowCount)
/*      */     {
/*      */       
/* 1104 */       fetchMoreRows();
/*      */     }
/* 1106 */     this.statement.removeRowFromCache(this.currentRow);
/* 1107 */     this.fetchedRowCount--;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   int refreshRows(int paramInt1, int paramInt2) throws SQLException {
/* 1121 */     return this.statement.refreshRows(paramInt1, paramInt2);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   int getColumnCount() throws SQLException {
/* 1130 */     if (this.statement.accessors != null) {
/* 1131 */       return this.statement.numberOfDefinePositions - 1 + this.statement.offsetOfFirstUserColumn;
/*      */     }
/*      */     
/* 1134 */     return getMetaData().getColumnCount();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   RowId getPrependedRowId() throws SQLException {
/* 1148 */     return this.statement.getPrependedRowId(this.currentRow);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/* 1153 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*      */   public static final String BUILD_DATE = "Thu_Apr_04_15:09:24_PDT_2013";
/*      */   public static final boolean TRACE = false;
/*      */ }


/* Location:              C:\Users\olatu\OneDrive\Documents\Calypso\syncbase\sync_base.jar!\BOOT-INF\classes\ojdbc.jar!\oracle\jdbc\driver\InsensitiveScrollableResultSet.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */