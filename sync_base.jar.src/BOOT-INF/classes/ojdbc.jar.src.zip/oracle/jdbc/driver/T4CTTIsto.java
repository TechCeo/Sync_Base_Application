/*     */ package oracle.jdbc.driver;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.sql.SQLException;
/*     */ import oracle.jdbc.internal.OracleConnection;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class T4CTTIsto
/*     */   extends T4CTTIfun
/*     */ {
/*     */   static final short OV6STRT = 48;
/*     */   static final short OV6STOP = 49;
/*     */   static final int STOMFDBA = 1;
/*     */   static final int STOMFACA = 2;
/*     */   static final int STOMFALO = 4;
/*     */   static final int STOMFSHU = 8;
/*     */   static final int STOMFFRC = 16;
/*     */   static final int STOMFPOL = 32;
/*     */   static final int STOMFABO = 64;
/*     */   static final int STOMFATX = 128;
/*     */   static final int STOMFLTX = 256;
/*     */   static final int STOSDONE = 1;
/*     */   static final int STOSINPR = 2;
/*     */   static final int STOSERR = 3;
/*     */   private int inmode;
/*     */   private int outmode;
/*     */   
/*     */   T4CTTIsto(T4CConnection paramT4CConnection) {
/*  93 */     super(paramT4CConnection, (byte)3);
/*     */ 
/*     */ 
/*     */     
/*  97 */     this.inmode = 0;
/*  98 */     this.outmode = 0;
/*     */   }
/*     */   
/*     */   void doOV6STRT(int paramInt) throws IOException, SQLException {
/* 102 */     setFunCode((short)48);
/* 103 */     this.inmode = paramInt;
/* 104 */     this.outmode = 0;
/* 105 */     doRPC();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   void doOV6STOP(int paramInt) throws IOException, SQLException {
/* 111 */     setFunCode((short)49);
/* 112 */     this.inmode = paramInt;
/* 113 */     this.outmode = 0;
/* 114 */     doRPC();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   void marshal() throws IOException {
/* 120 */     this.meg.marshalSWORD(this.inmode);
/* 121 */     this.meg.marshalPTR();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void readRPA() throws IOException, SQLException {
/* 134 */     this.outmode = (int)this.meg.unmarshalUB4();
/* 135 */     if (this.outmode == 3);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected OracleConnection getConnectionDuringExceptionHandling() {
/* 154 */     return this.connection;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/* 159 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*     */   public static final String BUILD_DATE = "Thu_Apr_04_15:09:24_PDT_2013";
/*     */   public static final boolean TRACE = false;
/*     */ }


/* Location:              C:\Users\olatu\OneDrive\Documents\Calypso\syncbase\sync_base.jar!\BOOT-INF\classes\ojdbc.jar!\oracle\jdbc\driver\T4CTTIsto.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */