/*      */ package oracle.jdbc.driver;
/*      */ 
/*      */ import java.net.SocketException;
/*      */ import java.security.NoSuchAlgorithmException;
/*      */ import java.security.spec.InvalidKeySpecException;
/*      */ import java.sql.CallableStatement;
/*      */ import java.sql.Connection;
/*      */ import java.sql.PreparedStatement;
/*      */ import java.sql.ResultSet;
/*      */ import java.sql.ResultSetMetaData;
/*      */ import java.sql.SQLException;
/*      */ import java.util.EnumSet;
/*      */ import java.util.Enumeration;
/*      */ import java.util.Map;
/*      */ import java.util.Properties;
/*      */ import java.util.concurrent.Executor;
/*      */ import javax.transaction.xa.XAResource;
/*      */ import oracle.jdbc.LogicalTransactionIdEventListener;
/*      */ import oracle.jdbc.OracleConnection;
/*      */ import oracle.jdbc.aq.AQMessageProperties;
/*      */ import oracle.jdbc.internal.JMSDequeueOptions;
/*      */ import oracle.jdbc.internal.JMSEnqueueOptions;
/*      */ import oracle.jdbc.internal.JMSMessage;
/*      */ import oracle.jdbc.internal.JMSNotificationRegistration;
/*      */ import oracle.jdbc.internal.KeywordValueLong;
/*      */ import oracle.jdbc.internal.OracleConnection;
/*      */ import oracle.jdbc.internal.OracleStatement;
/*      */ import oracle.jdbc.internal.PDBChangeEventListener;
/*      */ import oracle.jdbc.internal.ReplayContext;
/*      */ import oracle.jdbc.internal.XSEventListener;
/*      */ import oracle.jdbc.internal.XSKeyval;
/*      */ import oracle.jdbc.internal.XSNamespace;
/*      */ import oracle.jdbc.internal.XSPrincipal;
/*      */ import oracle.jdbc.internal.XSSecureId;
/*      */ import oracle.jdbc.internal.XSSessionParameters;
/*      */ import oracle.jdbc.oracore.OracleTypeADT;
/*      */ import oracle.jdbc.oracore.OracleTypeCLOB;
/*      */ import oracle.jdbc.pool.OracleConnectionCacheCallback;
/*      */ import oracle.jdbc.pool.OraclePooledConnection;
/*      */ import oracle.sql.ARRAY;
/*      */ import oracle.sql.ArrayDescriptor;
/*      */ import oracle.sql.BFILE;
/*      */ import oracle.sql.BLOB;
/*      */ import oracle.sql.BfileDBAccess;
/*      */ import oracle.sql.BlobDBAccess;
/*      */ import oracle.sql.CLOB;
/*      */ import oracle.sql.ClobDBAccess;
/*      */ import oracle.sql.CustomDatum;
/*      */ import oracle.sql.Datum;
/*      */ import oracle.sql.StructDescriptor;
/*      */ import oracle.sql.TIMESTAMPTZ;
/*      */ import oracle.sql.TIMEZONETAB;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ class LogicalConnection
/*      */   extends OracleConnection
/*      */ {
/*   85 */   static final ClosedConnection closedConnection = new ClosedConnection();
/*      */ 
/*      */   
/*      */   PhysicalConnection internalConnection;
/*      */ 
/*      */   
/*      */   OraclePooledConnection pooledConnection;
/*      */   
/*      */   boolean closed;
/*      */   
/*   95 */   OracleCloseCallback closeCallback = null;
/*   96 */   Object privateData = null;
/*      */ 
/*      */   
/*   99 */   long startTime = 0L;
/*      */ 
/*      */ 
/*      */   
/*  103 */   OracleConnectionCacheCallback connectionCacheCallback = null;
/*  104 */   Object connectionCacheCallbackUserObj = null;
/*  105 */   int callbackFlag = 0;
/*  106 */   int releasePriority = 0;
/*      */ 
/*      */   
/*  109 */   int heartbeatCount = 0;
/*  110 */   int heartbeatLastCount = 0;
/*  111 */   int heartbeatNoChangeCount = 0;
/*      */ 
/*      */ 
/*      */   
/*      */   boolean isAbandonedTimeoutEnabled = false;
/*      */ 
/*      */ 
/*      */   
/*      */   LogicalConnection(OraclePooledConnection paramOraclePooledConnection, PhysicalConnection paramPhysicalConnection, boolean paramBoolean) throws SQLException {
/*  120 */     this.internalConnection = paramPhysicalConnection;
/*  121 */     this.pooledConnection = paramOraclePooledConnection;
/*  122 */     this.connection = (OracleConnection)this.internalConnection;
/*      */     
/*  124 */     this.connection.setWrapper((OracleConnection)this);
/*      */     
/*  126 */     this.closed = false;
/*      */     
/*  128 */     this.internalConnection.setAutoCommit(paramBoolean);
/*      */     
/*  130 */     this.internalConnection.attachServerConnection();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void registerHeartbeat() throws SQLException {
/*  146 */     if (this.isAbandonedTimeoutEnabled) {
/*      */       
/*      */       try {
/*      */         
/*  150 */         this.heartbeatCount++;
/*      */       }
/*  152 */       catch (ArithmeticException arithmeticException) {
/*      */         
/*  154 */         this.heartbeatCount = 0;
/*      */       } 
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getHeartbeatNoChangeCount() throws SQLException {
/*  167 */     if (this.heartbeatCount == this.heartbeatLastCount) {
/*      */       
/*  169 */       this.heartbeatNoChangeCount++;
/*      */     }
/*      */     else {
/*      */       
/*  173 */       this.heartbeatLastCount = this.heartbeatCount;
/*  174 */       this.heartbeatNoChangeCount = 0;
/*      */     } 
/*      */     
/*  177 */     return this.heartbeatNoChangeCount;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public OracleConnection physicalConnectionWithin() {
/*  184 */     return this.internalConnection;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void registerCloseCallback(OracleCloseCallback paramOracleCloseCallback, Object paramObject) {
/*  197 */     this.closeCallback = paramOracleCloseCallback;
/*  198 */     this.privateData = paramObject;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Connection _getPC() {
/*  205 */     return (Connection)this.internalConnection;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized boolean isLogicalConnection() {
/*  223 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public OracleConnection getPhysicalConnection() {
/*  230 */     return this.internalConnection;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Connection getLogicalConnection(OraclePooledConnection paramOraclePooledConnection, boolean paramBoolean) throws SQLException {
/*  243 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 153);
/*  244 */     sQLException.fillInStackTrace();
/*  245 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void getPropertyForPooledConnection(OraclePooledConnection paramOraclePooledConnection) throws SQLException {
/*  258 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 153);
/*  259 */     sQLException.fillInStackTrace();
/*  260 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void close() throws SQLException {
/*  274 */     closeInternal(this.internalConnection.isUsable);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void closeInternal(boolean paramBoolean) throws SQLException {
/*  288 */     if (this.closed) {
/*      */       return;
/*      */     }
/*  291 */     if (this.closeCallback != null) {
/*  292 */       this.closeCallback.beforeClose(this, this.privateData);
/*      */     }
/*      */     
/*  295 */     if (this.internalConnection.lifecycle == 1) {
/*  296 */       this.internalConnection.detachServerConnection((String)null);
/*      */     }
/*      */ 
/*      */     
/*  300 */     this.internalConnection.closeLogicalConnection();
/*      */ 
/*      */     
/*  303 */     this.startTime = 0L;
/*      */     
/*  305 */     this.closed = true;
/*      */ 
/*      */     
/*  308 */     if (this.pooledConnection != null && paramBoolean) {
/*  309 */       this.pooledConnection.logicalClose();
/*      */     }
/*      */ 
/*      */     
/*  313 */     this.internalConnection = closedConnection;
/*  314 */     this.connection = (OracleConnection)closedConnection;
/*      */     
/*  316 */     if (this.closeCallback != null) {
/*  317 */       this.closeCallback.afterClose(this.privateData);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void cleanupAndClose(boolean paramBoolean) throws SQLException {
/*  328 */     if (this.closed) {
/*      */       return;
/*      */     }
/*      */     
/*  332 */     this.closed = true;
/*      */ 
/*      */     
/*  335 */     PhysicalConnection physicalConnection = this.internalConnection;
/*  336 */     OraclePooledConnection oraclePooledConnection = this.pooledConnection;
/*  337 */     this.internalConnection = closedConnection;
/*  338 */     this.connection = (OracleConnection)closedConnection;
/*  339 */     this.startTime = 0L;
/*      */     
/*  341 */     if (this.closeCallback != null) {
/*  342 */       this.closeCallback.beforeClose(this, this.privateData);
/*      */     }
/*      */     
/*  345 */     physicalConnection.cleanupAndClose();
/*  346 */     physicalConnection.closeLogicalConnection();
/*      */ 
/*      */     
/*  349 */     if (oraclePooledConnection != null && paramBoolean) {
/*  350 */       oraclePooledConnection.logicalClose();
/*      */     }
/*  352 */     if (this.closeCallback != null) {
/*  353 */       this.closeCallback.afterClose(this.privateData);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void abort() throws SQLException {
/*  360 */     if (this.closed)
/*      */       return; 
/*  362 */     this.internalConnection.abort();
/*  363 */     this.closed = true;
/*      */     
/*  365 */     this.internalConnection = closedConnection;
/*  366 */     this.connection = (OracleConnection)closedConnection;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void close(Properties paramProperties) throws SQLException {
/*  385 */     if (this.pooledConnection != null)
/*      */     {
/*  387 */       if (this.pooledConnection.cachedConnectionAttributes != null) {
/*      */         
/*  389 */         if (paramProperties != null) {
/*      */           
/*  391 */           this.pooledConnection.cachedConnectionAttributes.clear();
/*  392 */           this.pooledConnection.cachedConnectionAttributes.putAll(paramProperties);
/*      */ 
/*      */           
/*  395 */           this.internalConnection.detachServerConnection((String)null);
/*      */         }
/*      */         else {
/*      */           
/*  399 */           this.internalConnection.drcpTagName = null;
/*      */         } 
/*  401 */       } else if (paramProperties != null) {
/*      */         
/*  403 */         this.internalConnection.detachServerConnection((String)null);
/*  404 */         this.pooledConnection.cachedConnectionAttributes = paramProperties;
/*      */       } 
/*      */     }
/*      */     
/*  408 */     close();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void close(int paramInt) throws SQLException {
/*  421 */     if ((paramInt & 0x1000) != 0) {
/*      */ 
/*      */ 
/*      */       
/*  425 */       if (this.pooledConnection != null) {
/*  426 */         this.pooledConnection.closeOption = paramInt;
/*      */       }
/*  428 */       close();
/*      */       
/*      */       return;
/*      */     } 
/*      */     
/*  433 */     if ((paramInt & 0x1) != 0)
/*      */     {
/*      */ 
/*      */       
/*  437 */       this.internalConnection.close(1);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void applyConnectionAttributes(Properties paramProperties) throws SQLException {
/*  457 */     if (this.pooledConnection != null) {
/*  458 */       this.pooledConnection.cachedConnectionAttributes.putAll(paramProperties);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized Properties getConnectionAttributes() throws SQLException {
/*  478 */     if (this.pooledConnection != null) {
/*  479 */       return this.pooledConnection.cachedConnectionAttributes;
/*      */     }
/*  481 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized Properties getUnMatchedConnectionAttributes() throws SQLException {
/*  499 */     if (this.pooledConnection != null) {
/*  500 */       return this.pooledConnection.unMatchedCachedConnAttr;
/*      */     }
/*  502 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void setAbandonedTimeoutEnabled(boolean paramBoolean) throws SQLException {
/*  519 */     this.isAbandonedTimeoutEnabled = true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void registerConnectionCacheCallback(OracleConnectionCacheCallback paramOracleConnectionCacheCallback, Object paramObject, int paramInt) throws SQLException {
/*  536 */     this.connectionCacheCallback = paramOracleConnectionCacheCallback;
/*  537 */     this.connectionCacheCallbackUserObj = paramObject;
/*  538 */     this.callbackFlag = paramInt;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public OracleConnectionCacheCallback getConnectionCacheCallbackObj() throws SQLException {
/*  554 */     return this.connectionCacheCallback;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Object getConnectionCacheCallbackPrivObj() throws SQLException {
/*  569 */     return this.connectionCacheCallbackUserObj;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getConnectionCacheCallbackFlag() throws SQLException {
/*  584 */     return this.callbackFlag;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void setConnectionReleasePriority(int paramInt) throws SQLException {
/*  600 */     this.releasePriority = paramInt;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getConnectionReleasePriority() throws SQLException {
/*  616 */     return this.releasePriority;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized boolean isClosed() throws SQLException {
/*  634 */     return this.closed;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setStartTime(long paramLong) throws SQLException {
/*  653 */     if (paramLong <= 0L) {
/*      */ 
/*      */       
/*  656 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/*  657 */       sQLException.fillInStackTrace();
/*  658 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  663 */     this.startTime = paramLong;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public long getStartTime() throws SQLException {
/*  679 */     return this.startTime;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getDatabaseTimeZone() throws SQLException {
/*  689 */     return this.internalConnection.getDatabaseTimeZone();
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public Properties getServerSessionInfo() throws SQLException {
/*  695 */     return this.internalConnection.getServerSessionInfo();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Object getClientData(Object paramObject) {
/*  702 */     return this.internalConnection.getClientData(paramObject);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Object setClientData(Object paramObject1, Object paramObject2) {
/*  709 */     return this.internalConnection.setClientData(paramObject1, paramObject2);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Object removeClientData(Object paramObject) {
/*  716 */     return this.internalConnection.removeClientData(paramObject);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setClientIdentifier(String paramString) throws SQLException {
/*  723 */     this.internalConnection.setClientIdentifier(paramString);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void clearClientIdentifier(String paramString) throws SQLException {
/*  730 */     this.internalConnection.clearClientIdentifier(paramString);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public short getStructAttrNCsId() throws SQLException {
/*  737 */     return this.internalConnection.getStructAttrNCsId();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Map getTypeMap() throws SQLException {
/*  744 */     return this.internalConnection.getTypeMap();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Properties getDBAccessProperties() throws SQLException {
/*  751 */     return this.internalConnection.getDBAccessProperties();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Properties getOCIHandles() throws SQLException {
/*  758 */     return this.internalConnection.getOCIHandles();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getDatabaseProductVersion() throws SQLException {
/*  765 */     return this.internalConnection.getDatabaseProductVersion();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void cancel() throws SQLException {
/*  776 */     registerHeartbeat();
/*  777 */     this.internalConnection.cancel();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getURL() throws SQLException {
/*  784 */     return this.internalConnection.getURL();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean getIncludeSynonyms() {
/*  791 */     return this.internalConnection.getIncludeSynonyms();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean getRemarksReporting() {
/*  798 */     return this.internalConnection.getRemarksReporting();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean getRestrictGetTables() {
/*  805 */     return this.internalConnection.getRestrictGetTables();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public short getVersionNumber() throws SQLException {
/*  812 */     return this.internalConnection.getVersionNumber();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Map getJavaObjectTypeMap() {
/*  819 */     return this.internalConnection.getJavaObjectTypeMap();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setJavaObjectTypeMap(Map paramMap) {
/*  826 */     this.internalConnection.setJavaObjectTypeMap(paramMap);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public BfileDBAccess createBfileDBAccess() throws SQLException {
/*  833 */     return this.internalConnection.createBfileDBAccess();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public BlobDBAccess createBlobDBAccess() throws SQLException {
/*  840 */     return this.internalConnection.createBlobDBAccess();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ClobDBAccess createClobDBAccess() throws SQLException {
/*  847 */     return this.internalConnection.createClobDBAccess();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setDefaultFixedString(boolean paramBoolean) {
/*  854 */     this.internalConnection.setDefaultFixedString(paramBoolean);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean getTimestamptzInGmt() {
/*  861 */     return this.internalConnection.getTimestamptzInGmt();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean getUse1900AsYearForTime() {
/*  868 */     return this.internalConnection.getUse1900AsYearForTime();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean getDefaultFixedString() {
/*  875 */     return this.internalConnection.getDefaultFixedString();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public OracleConnection getWrapper() {
/*  882 */     return (OracleConnection)this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Class classForNameAndSchema(String paramString1, String paramString2) throws ClassNotFoundException {
/*  890 */     return this.internalConnection.classForNameAndSchema(paramString1, paramString2);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setFDO(byte[] paramArrayOfbyte) throws SQLException {
/*  897 */     this.internalConnection.setFDO(paramArrayOfbyte);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public byte[] getFDO(boolean paramBoolean) throws SQLException {
/*  904 */     return this.internalConnection.getFDO(paramBoolean);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean getBigEndian() throws SQLException {
/*  911 */     return this.internalConnection.getBigEndian();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Object getDescriptor(byte[] paramArrayOfbyte) {
/*  918 */     return this.internalConnection.getDescriptor(paramArrayOfbyte);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void putDescriptor(byte[] paramArrayOfbyte, Object paramObject) throws SQLException {
/*  925 */     this.internalConnection.putDescriptor(paramArrayOfbyte, paramObject);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void removeDescriptor(String paramString) {
/*  932 */     this.internalConnection.removeDescriptor(paramString);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void removeAllDescriptor() {
/*  939 */     this.internalConnection.removeAllDescriptor();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int numberOfDescriptorCacheEntries() {
/*  946 */     return this.internalConnection.numberOfDescriptorCacheEntries();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Enumeration descriptorCacheKeys() {
/*  953 */     return this.internalConnection.descriptorCacheKeys();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void getOracleTypeADT(OracleTypeADT paramOracleTypeADT) throws SQLException {
/*  961 */     this.internalConnection.getOracleTypeADT(paramOracleTypeADT);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public short getDbCsId() throws SQLException {
/*  968 */     return this.internalConnection.getDbCsId();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public short getJdbcCsId() throws SQLException {
/*  975 */     return this.internalConnection.getJdbcCsId();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public short getNCharSet() {
/*  982 */     return this.internalConnection.getNCharSet();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ResultSet newArrayDataResultSet(Datum[] paramArrayOfDatum, long paramLong, int paramInt, Map paramMap) throws SQLException {
/*  990 */     return this.internalConnection.newArrayDataResultSet(paramArrayOfDatum, paramLong, paramInt, paramMap);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ResultSet newArrayDataResultSet(ARRAY paramARRAY, long paramLong, int paramInt, Map paramMap) throws SQLException {
/*  998 */     return this.internalConnection.newArrayDataResultSet(paramARRAY, paramLong, paramInt, paramMap);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ResultSet newArrayLocatorResultSet(ArrayDescriptor paramArrayDescriptor, byte[] paramArrayOfbyte, long paramLong, int paramInt, Map paramMap) throws SQLException {
/* 1008 */     return this.internalConnection.newArrayLocatorResultSet(paramArrayDescriptor, paramArrayOfbyte, paramLong, paramInt, paramMap);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ResultSetMetaData newStructMetaData(StructDescriptor paramStructDescriptor) throws SQLException {
/* 1017 */     return this.internalConnection.newStructMetaData(paramStructDescriptor);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void getForm(OracleTypeADT paramOracleTypeADT, OracleTypeCLOB paramOracleTypeCLOB, int paramInt) throws SQLException {
/* 1026 */     this.internalConnection.getForm(paramOracleTypeADT, paramOracleTypeCLOB, paramInt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int CHARBytesToJavaChars(byte[] paramArrayOfbyte, int paramInt, char[] paramArrayOfchar) throws SQLException {
/* 1034 */     return this.internalConnection.CHARBytesToJavaChars(paramArrayOfbyte, paramInt, paramArrayOfchar);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int NCHARBytesToJavaChars(byte[] paramArrayOfbyte, int paramInt, char[] paramArrayOfchar) throws SQLException {
/* 1042 */     return this.internalConnection.NCHARBytesToJavaChars(paramArrayOfbyte, paramInt, paramArrayOfchar);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean IsNCharFixedWith() {
/* 1049 */     return this.internalConnection.IsNCharFixedWith();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public short getDriverCharSet() {
/* 1056 */     return this.internalConnection.getDriverCharSet();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getC2SNlsRatio() {
/* 1063 */     return this.internalConnection.getC2SNlsRatio();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getMaxCharSize() throws SQLException {
/* 1070 */     return this.internalConnection.getMaxCharSize();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getMaxCharbyteSize() {
/* 1077 */     return this.internalConnection.getMaxCharbyteSize();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getMaxNCharbyteSize() {
/* 1084 */     return this.internalConnection.getMaxNCharbyteSize();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isCharSetMultibyte(short paramShort) {
/* 1091 */     return this.internalConnection.isCharSetMultibyte(paramShort);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int javaCharsToCHARBytes(char[] paramArrayOfchar, int paramInt, byte[] paramArrayOfbyte) throws SQLException {
/* 1099 */     return this.internalConnection.javaCharsToCHARBytes(paramArrayOfchar, paramInt, paramArrayOfbyte);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int javaCharsToNCHARBytes(char[] paramArrayOfchar, int paramInt, byte[] paramArrayOfbyte) throws SQLException {
/* 1107 */     return this.internalConnection.javaCharsToNCHARBytes(paramArrayOfchar, paramInt, paramArrayOfbyte);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getStmtCacheSize() {
/* 1114 */     return this.internalConnection.getStmtCacheSize();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getStatementCacheSize() throws SQLException {
/* 1121 */     return this.internalConnection.getStatementCacheSize();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean getImplicitCachingEnabled() throws SQLException {
/* 1128 */     return this.internalConnection.getImplicitCachingEnabled();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean getExplicitCachingEnabled() throws SQLException {
/* 1135 */     return this.internalConnection.getExplicitCachingEnabled();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void purgeImplicitCache() throws SQLException {
/* 1142 */     this.internalConnection.purgeImplicitCache();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void purgeExplicitCache() throws SQLException {
/* 1149 */     this.internalConnection.purgeExplicitCache();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public PreparedStatement getStatementWithKey(String paramString) throws SQLException {
/* 1157 */     return this.internalConnection.getStatementWithKey(paramString);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public CallableStatement getCallWithKey(String paramString) throws SQLException {
/* 1165 */     return this.internalConnection.getCallWithKey(paramString);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isStatementCacheInitialized() {
/* 1172 */     return this.internalConnection.isStatementCacheInitialized();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setTypeMap(Map paramMap) throws SQLException {
/* 1179 */     this.internalConnection.setTypeMap(paramMap);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getProtocolType() {
/* 1186 */     return this.internalConnection.getProtocolType();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setTxnMode(int paramInt) {
/* 1195 */     this.internalConnection.setTxnMode(paramInt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getTxnMode() {
/* 1202 */     return this.internalConnection.getTxnMode();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getHeapAllocSize() throws SQLException {
/* 1210 */     return this.internalConnection.getHeapAllocSize();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getOCIEnvHeapAllocSize() throws SQLException {
/* 1217 */     return this.internalConnection.getOCIEnvHeapAllocSize();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public CLOB createClob(byte[] paramArrayOfbyte) throws SQLException {
/* 1228 */     registerHeartbeat();
/* 1229 */     return this.internalConnection.createClob(paramArrayOfbyte);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public CLOB createClobWithUnpickledBytes(byte[] paramArrayOfbyte) throws SQLException {
/* 1241 */     registerHeartbeat();
/* 1242 */     return this.internalConnection.createClobWithUnpickledBytes(paramArrayOfbyte);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public CLOB createClob(byte[] paramArrayOfbyte, short paramShort) throws SQLException {
/* 1254 */     registerHeartbeat();
/* 1255 */     return this.internalConnection.createClob(paramArrayOfbyte, paramShort);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public BLOB createBlob(byte[] paramArrayOfbyte) throws SQLException {
/* 1266 */     registerHeartbeat();
/* 1267 */     return this.internalConnection.createBlob(paramArrayOfbyte);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public BLOB createBlobWithUnpickledBytes(byte[] paramArrayOfbyte) throws SQLException {
/* 1278 */     registerHeartbeat();
/* 1279 */     return this.internalConnection.createBlobWithUnpickledBytes(paramArrayOfbyte);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public BFILE createBfile(byte[] paramArrayOfbyte) throws SQLException {
/* 1290 */     registerHeartbeat();
/* 1291 */     return this.internalConnection.createBfile(paramArrayOfbyte);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isDescriptorSharable(OracleConnection paramOracleConnection) throws SQLException {
/* 1299 */     return this.internalConnection.isDescriptorSharable(paramOracleConnection);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public OracleStatement refCursorCursorToStatement(int paramInt) throws SQLException {
/* 1307 */     return this.internalConnection.refCursorCursorToStatement(paramInt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public long getTdoCState(String paramString1, String paramString2) throws SQLException {
/* 1314 */     return this.internalConnection.getTdoCState(paramString1, paramString2);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public long getTdoCState(String paramString) throws SQLException {
/* 1321 */     return this.internalConnection.getTdoCState(paramString);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public Datum toDatum(CustomDatum paramCustomDatum) throws SQLException {
/* 1327 */     return this.internalConnection.toDatum(paramCustomDatum);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public XAResource getXAResource() throws SQLException {
/* 1344 */     return this.pooledConnection.getXAResource();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setApplicationContext(String paramString1, String paramString2, String paramString3) throws SQLException {
/* 1355 */     this.internalConnection.setApplicationContext(paramString1, paramString2, paramString3);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void clearAllApplicationContext(String paramString) throws SQLException {
/* 1364 */     this.internalConnection.clearAllApplicationContext(paramString);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isV8Compatible() throws SQLException {
/* 1381 */     return getMapDateToTimestamp();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean getMapDateToTimestamp() {
/* 1394 */     return this.internalConnection.getMapDateToTimestamp();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void abort(Executor paramExecutor) throws SQLException {
/* 1406 */     this.internalConnection.abort(paramExecutor);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getNetworkTimeout() throws SQLException {
/* 1413 */     return this.internalConnection.getNetworkTimeout();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getSchema() throws SQLException {
/* 1420 */     return this.internalConnection.getSchema();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setNetworkTimeout(Executor paramExecutor, int paramInt) throws SQLException {
/* 1427 */     this.internalConnection.setNetworkTimeout(paramExecutor, paramInt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setSchema(String paramString) throws SQLException {
/* 1434 */     this.internalConnection.setSchema(paramString);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public byte[] createLightweightSession(String paramString, KeywordValueLong[] paramArrayOfKeywordValueLong, int paramInt, KeywordValueLong[][] paramArrayOfKeywordValueLong1, int[] paramArrayOfint) throws SQLException {
/* 1450 */     return this.internalConnection.createLightweightSession(paramString, paramArrayOfKeywordValueLong, paramInt, paramArrayOfKeywordValueLong1, paramArrayOfint);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void executeLightweightSessionRoundtrip(int paramInt1, byte[] paramArrayOfbyte, KeywordValueLong[] paramArrayOfKeywordValueLong, int paramInt2, KeywordValueLong[][] paramArrayOfKeywordValueLong1, int[] paramArrayOfint) throws SQLException {
/* 1463 */     this.internalConnection.executeLightweightSessionRoundtrip(paramInt1, paramArrayOfbyte, paramArrayOfKeywordValueLong, paramInt2, paramArrayOfKeywordValueLong1, paramArrayOfint);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void executeLightweightSessionPiggyback(int paramInt1, byte[] paramArrayOfbyte, KeywordValueLong[] paramArrayOfKeywordValueLong, int paramInt2) throws SQLException {
/* 1475 */     this.internalConnection.executeLightweightSessionPiggyback(paramInt1, paramArrayOfbyte, paramArrayOfKeywordValueLong, paramInt2);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void doXSNamespaceOp(OracleConnection.XSOperationCode paramXSOperationCode, byte[] paramArrayOfbyte, XSNamespace[] paramArrayOfXSNamespace, XSNamespace[][] paramArrayOfXSNamespace1, XSSecureId paramXSSecureId) throws SQLException {
/* 1487 */     this.internalConnection.doXSNamespaceOp(paramXSOperationCode, paramArrayOfbyte, paramArrayOfXSNamespace, paramArrayOfXSNamespace1, paramXSSecureId);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void doXSNamespaceOp(OracleConnection.XSOperationCode paramXSOperationCode, byte[] paramArrayOfbyte, XSNamespace[] paramArrayOfXSNamespace, XSSecureId paramXSSecureId) throws SQLException {
/* 1496 */     this.internalConnection.doXSNamespaceOp(paramXSOperationCode, paramArrayOfbyte, paramArrayOfXSNamespace, paramXSSecureId);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void doXSSessionAttachOp(int paramInt1, byte[] paramArrayOfbyte1, XSSecureId paramXSSecureId, byte[] paramArrayOfbyte2, XSPrincipal paramXSPrincipal, String[] paramArrayOfString1, String[] paramArrayOfString2, String[] paramArrayOfString3, XSNamespace[] paramArrayOfXSNamespace1, XSNamespace[] paramArrayOfXSNamespace2, XSNamespace[] paramArrayOfXSNamespace3, TIMESTAMPTZ paramTIMESTAMPTZ1, TIMESTAMPTZ paramTIMESTAMPTZ2, int paramInt2, long paramLong, XSKeyval paramXSKeyval, int[] paramArrayOfint) throws SQLException {
/* 1518 */     this.internalConnection.doXSSessionAttachOp(paramInt1, paramArrayOfbyte1, paramXSSecureId, paramArrayOfbyte2, paramXSPrincipal, paramArrayOfString1, paramArrayOfString2, paramArrayOfString3, paramArrayOfXSNamespace1, paramArrayOfXSNamespace2, paramArrayOfXSNamespace3, paramTIMESTAMPTZ1, paramTIMESTAMPTZ2, paramInt2, paramLong, paramXSKeyval, paramArrayOfint);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void doXSSessionChangeOp(OracleConnection.XSSessionSetOperationCode paramXSSessionSetOperationCode, byte[] paramArrayOfbyte, XSSecureId paramXSSecureId, XSSessionParameters paramXSSessionParameters) throws SQLException {
/* 1545 */     this.internalConnection.doXSSessionChangeOp(paramXSSessionSetOperationCode, paramArrayOfbyte, paramXSSecureId, paramXSSessionParameters);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public byte[] doXSSessionCreateOp(OracleConnection.XSSessionOperationCode paramXSSessionOperationCode, XSSecureId paramXSSecureId, byte[] paramArrayOfbyte, XSPrincipal paramXSPrincipal, String paramString, XSNamespace[] paramArrayOfXSNamespace, OracleConnection.XSSessionModeFlag paramXSSessionModeFlag, XSKeyval paramXSKeyval) throws SQLException {
/* 1561 */     return this.internalConnection.doXSSessionCreateOp(paramXSSessionOperationCode, paramXSSecureId, paramArrayOfbyte, paramXSPrincipal, paramString, paramArrayOfXSNamespace, paramXSSessionModeFlag, paramXSKeyval);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void doXSSessionDestroyOp(byte[] paramArrayOfbyte1, XSSecureId paramXSSecureId, byte[] paramArrayOfbyte2) throws SQLException {
/* 1576 */     this.internalConnection.doXSSessionDestroyOp(paramArrayOfbyte1, paramXSSecureId, paramArrayOfbyte2);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void doXSSessionDetachOp(int paramInt, byte[] paramArrayOfbyte, XSSecureId paramXSSecureId, boolean paramBoolean) throws SQLException {
/* 1587 */     this.internalConnection.doXSSessionDetachOp(paramInt, paramArrayOfbyte, paramXSSecureId, paramBoolean);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public BLOB createTemporaryBlob(Connection paramConnection, boolean paramBoolean, int paramInt) throws SQLException {
/* 1603 */     registerHeartbeat();
/* 1604 */     return this.internalConnection.createTemporaryBlob(paramConnection, paramBoolean, paramInt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public CLOB createTemporaryClob(Connection paramConnection, boolean paramBoolean, int paramInt, short paramShort) throws SQLException {
/* 1616 */     registerHeartbeat();
/* 1617 */     return this.internalConnection.createTemporaryClob(paramConnection, paramBoolean, paramInt, paramShort);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getDefaultSchemaNameForNamedTypes() throws SQLException {
/* 1630 */     return this.internalConnection.getDefaultSchemaNameForNamedTypes();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isUsable() {
/* 1647 */     return (!this.closed && this.internalConnection.isUsable());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public byte getInstanceProperty(OracleConnection.InstanceProperty paramInstanceProperty) throws SQLException {
/* 1659 */     return this.internalConnection.getInstanceProperty(paramInstanceProperty);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setUsable(boolean paramBoolean) {
/* 1678 */     this.internalConnection.setUsable(paramBoolean);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getTimezoneVersionNumber() throws SQLException {
/* 1691 */     return this.internalConnection.getTimezoneVersionNumber();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public TIMEZONETAB getTIMEZONETAB() throws SQLException {
/* 1709 */     return this.internalConnection.getTIMEZONETAB();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setPDBChangeEventListener(PDBChangeEventListener paramPDBChangeEventListener) throws SQLException {
/* 1721 */     this.internalConnection.setPDBChangeEventListener(paramPDBChangeEventListener);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setPDBChangeEventListener(PDBChangeEventListener paramPDBChangeEventListener, Executor paramExecutor) throws SQLException {
/* 1734 */     this.internalConnection.setPDBChangeEventListener(paramPDBChangeEventListener, paramExecutor);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void addXSEventListener(XSEventListener paramXSEventListener) throws SQLException {
/* 1747 */     this.internalConnection.addXSEventListener(paramXSEventListener);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void addXSEventListener(XSEventListener paramXSEventListener, Executor paramExecutor) throws SQLException {
/* 1761 */     this.internalConnection.addXSEventListener(paramXSEventListener, paramExecutor);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void removeXSEventListener(XSEventListener paramXSEventListener) throws SQLException {
/* 1774 */     this.internalConnection.removeXSEventListener(paramXSEventListener);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void removeAllXSEventListener() throws SQLException {
/* 1787 */     this.internalConnection.removeAllXSEventListener();
/*      */   }
/*      */ 
/*      */   
/*      */   public OracleConnection.BufferCacheStatistics getByteBufferCacheStatistics() {
/* 1792 */     return this.internalConnection.getByteBufferCacheStatistics();
/*      */   }
/*      */   
/*      */   public OracleConnection.BufferCacheStatistics getCharBufferCacheStatistics() {
/* 1796 */     return this.internalConnection.getCharBufferCacheStatistics();
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isDataInLocatorEnabled() throws SQLException {
/* 1801 */     return this.internalConnection.isDataInLocatorEnabled();
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isLobStreamPosStandardCompliant() throws SQLException {
/* 1806 */     return this.internalConnection.isLobStreamPosStandardCompliant();
/*      */   }
/*      */ 
/*      */   
/*      */   public long getCurrentSCN() throws SQLException {
/* 1811 */     return this.internalConnection.getCurrentSCN();
/*      */   }
/*      */ 
/*      */   
/*      */   public EnumSet<OracleConnection.TransactionState> getTransactionState() throws SQLException {
/* 1816 */     return this.internalConnection.getTransactionState();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isConnectionSocketKeepAlive() throws SocketException, SQLException {
/* 1823 */     return this.internalConnection.isConnectionSocketKeepAlive();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void removeLogicalTransactionIdEventListener(LogicalTransactionIdEventListener paramLogicalTransactionIdEventListener) throws SQLException {
/* 1831 */     this.connection.removeLogicalTransactionIdEventListener(paramLogicalTransactionIdEventListener);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void setReplayOperations(EnumSet<OracleConnection.ReplayOperation> paramEnumSet) throws SQLException {
/* 1837 */     this.internalConnection.setReplayOperations(paramEnumSet);
/*      */   }
/*      */ 
/*      */   
/*      */   public void beginNonRequestCalls() throws SQLException {
/* 1842 */     this.internalConnection.beginNonRequestCalls();
/*      */   }
/*      */   
/*      */   public void endNonRequestCalls() throws SQLException {
/* 1846 */     this.internalConnection.endNonRequestCalls();
/*      */   }
/*      */ 
/*      */   
/*      */   public void setReplayContext(ReplayContext[] paramArrayOfReplayContext) throws SQLException {
/* 1851 */     this.internalConnection.setReplayContext(paramArrayOfReplayContext);
/*      */   }
/*      */   
/*      */   public void registerEndReplayCallback(OracleConnection.EndReplayCallback paramEndReplayCallback) throws SQLException {
/* 1855 */     this.internalConnection.registerEndReplayCallback(paramEndReplayCallback);
/*      */   }
/*      */ 
/*      */   
/*      */   public int getEOC() throws SQLException {
/* 1860 */     return this.internalConnection.getEOC();
/*      */   }
/*      */   
/*      */   public ReplayContext[] getReplayContext() throws SQLException {
/* 1864 */     return this.internalConnection.getReplayContext();
/*      */   }
/*      */   
/*      */   public ReplayContext getLastReplayContext() throws SQLException {
/* 1868 */     return this.internalConnection.getLastReplayContext();
/*      */   }
/*      */ 
/*      */   
/*      */   public byte[] getDerivedKeyInternal(byte[] paramArrayOfbyte, int paramInt) throws NoSuchAlgorithmException, InvalidKeySpecException, SQLException {
/* 1873 */     return this.internalConnection.getDerivedKeyInternal(paramArrayOfbyte, paramInt);
/*      */   }
/*      */   
/*      */   public short getExecutingRPCFunctionCode() {
/* 1877 */     return this.internalConnection.getExecutingRPCFunctionCode();
/*      */   }
/*      */   
/*      */   public String getExecutingRPCSQL() {
/* 1881 */     return this.internalConnection.getExecutingRPCSQL();
/*      */   }
/*      */   
/*      */   public void setReplayingMode(boolean paramBoolean) throws SQLException {
/* 1885 */     this.internalConnection.setReplayingMode(paramBoolean);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void jmsEnqueue(String paramString, JMSEnqueueOptions paramJMSEnqueueOptions, JMSMessage paramJMSMessage, AQMessageProperties paramAQMessageProperties) throws SQLException {
/* 1893 */     this.internalConnection.jmsEnqueue(paramString, paramJMSEnqueueOptions, paramJMSMessage, paramAQMessageProperties);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JMSMessage jmsDequeue(String paramString, JMSDequeueOptions paramJMSDequeueOptions) throws SQLException {
/* 1901 */     return this.internalConnection.jmsDequeue(paramString, paramJMSDequeueOptions);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JMSMessage jmsDequeue(String paramString1, JMSDequeueOptions paramJMSDequeueOptions, String paramString2) throws SQLException {
/* 1909 */     return this.internalConnection.jmsDequeue(paramString1, paramJMSDequeueOptions, paramString2);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Map<String, JMSNotificationRegistration> registerJMSNotification(String[] paramArrayOfString, Map<String, Properties> paramMap) throws SQLException {
/* 1917 */     return this.internalConnection.registerJMSNotification(paramArrayOfString, paramMap);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void unregisterJMSNotification(JMSNotificationRegistration paramJMSNotificationRegistration) throws SQLException {
/* 1924 */     this.internalConnection.unregisterJMSNotification(paramJMSNotificationRegistration);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void ackJMSNotification(JMSNotificationRegistration paramJMSNotificationRegistration, byte[] paramArrayOfbyte, JMSNotificationRegistration.Directive paramDirective) throws SQLException {
/* 1931 */     this.internalConnection.ackJMSNotification(paramJMSNotificationRegistration, paramArrayOfbyte, paramDirective);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isDRCPEnabled() throws SQLException {
/* 1944 */     return this.internalConnection.isDRCPEnabled();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean attachServerConnection() throws SQLException {
/* 1957 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 153);
/* 1958 */     sQLException.fillInStackTrace();
/* 1959 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void detachServerConnection(String paramString) throws SQLException {
/* 1973 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 153);
/* 1974 */     sQLException.fillInStackTrace();
/* 1975 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean needToPurgeStatementCache() throws SQLException {
/* 1998 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 153);
/* 1999 */     sQLException.fillInStackTrace();
/* 2000 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getNegotiatedSDU() throws SQLException {
/* 2007 */     return this.internalConnection.getNegotiatedSDU();
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public int getVarTypeMaxLenCompat() throws SQLException {
/* 2013 */     return this.internalConnection.getVarTypeMaxLenCompat();
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void setChecksumMode(OracleConnection.ChecksumMode paramChecksumMode) throws SQLException {
/* 2019 */     this.internalConnection.setChecksumMode(paramChecksumMode);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 2025 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*      */   public static final String BUILD_DATE = "Thu_Apr_04_15:09:24_PDT_2013";
/*      */   public static final boolean TRACE = false;
/*      */ }


/* Location:              C:\Users\olatu\OneDrive\Documents\Calypso\syncbase\sync_base.jar!\BOOT-INF\classes\ojdbc.jar!\oracle\jdbc\driver\LogicalConnection.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */