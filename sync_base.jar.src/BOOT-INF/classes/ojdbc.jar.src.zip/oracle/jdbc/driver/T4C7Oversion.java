/*     */ package oracle.jdbc.driver;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.sql.SQLException;
/*     */ import oracle.jdbc.internal.OracleConnection;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class T4C7Oversion
/*     */   extends T4CTTIfun
/*     */ {
/*  37 */   byte[] rdbmsVersion = new byte[] { 78, 111, 116, 32, 100, 101, 116, 101, 114, 109, 105, 110, 101, 100, 32, 121, 101, 116 };
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final boolean rdbmsVersionO2U = true;
/*     */ 
/*     */ 
/*     */   
/*  46 */   private final int bufLen = 256;
/*     */   private final boolean retVerLenO2U = true;
/*  48 */   int retVerLen = 0;
/*     */   private final boolean retVerNumO2U = true;
/*  50 */   long retVerNum = 0L;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   T4C7Oversion(T4CConnection paramT4CConnection) {
/*  59 */     super(paramT4CConnection, (byte)3);
/*     */     
/*  61 */     setFunCode((short)59);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void doOVERSION() throws SQLException, IOException {
/*  68 */     doRPC();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void readRPA() throws IOException, SQLException {
/*  77 */     this.retVerLen = this.meg.unmarshalUB2();
/*  78 */     this.rdbmsVersion = this.meg.unmarshalCHR(this.retVerLen);
/*  79 */     this.retVerNum = this.meg.unmarshalUB4();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void processRPA() throws SQLException {
/*  87 */     if (this.rdbmsVersion == null) {
/*     */       
/*  89 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 438);
/*  90 */       sQLException.fillInStackTrace();
/*  91 */       throw sQLException;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   byte[] getVersion() {
/* 106 */     return this.rdbmsVersion;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   short getVersionNumber() {
/* 119 */     int i = 0;
/*     */     
/* 121 */     i = (int)(i + (this.retVerNum >>> 24L & 0xFFL) * 1000L);
/* 122 */     i = (int)(i + (this.retVerNum >>> 20L & 0xFL) * 100L);
/* 123 */     i = (int)(i + (this.retVerNum >>> 12L & 0xFL) * 10L);
/* 124 */     i = (int)(i + (this.retVerNum >>> 8L & 0xFL));
/*     */     
/* 126 */     return (short)i;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   long getVersionNumberasIs() {
/* 139 */     return this.retVerNum;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void marshal() throws IOException {
/* 153 */     this.meg.marshalO2U(true);
/* 154 */     this.meg.marshalSWORD(256);
/* 155 */     this.meg.marshalO2U(true);
/* 156 */     this.meg.marshalO2U(true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected OracleConnection getConnectionDuringExceptionHandling() {
/* 172 */     return this.connection;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/* 177 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*     */   public static final String BUILD_DATE = "Thu_Apr_04_15:09:24_PDT_2013";
/*     */   public static final boolean TRACE = false;
/*     */ }


/* Location:              C:\Users\olatu\OneDrive\Documents\Calypso\syncbase\sync_base.jar!\BOOT-INF\classes\ojdbc.jar!\oracle\jdbc\driver\T4C7Oversion.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */