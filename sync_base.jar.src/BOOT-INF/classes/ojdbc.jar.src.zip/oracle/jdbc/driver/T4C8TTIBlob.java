/*     */ package oracle.jdbc.driver;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.sql.Connection;
/*     */ import java.sql.SQLException;
/*     */ import oracle.jdbc.OracleConnection;
/*     */ import oracle.sql.BLOB;
/*     */ import oracle.sql.Datum;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class T4C8TTIBlob
/*     */   extends T4C8TTILob
/*     */ {
/*     */   T4C8TTIBlob(T4CConnection paramT4CConnection) {
/* 114 */     super(paramT4CConnection);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Datum createTemporaryLob(Connection paramConnection, boolean paramBoolean, int paramInt) throws SQLException, IOException {
/* 138 */     if (paramInt == 12) {
/*     */       
/* 140 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 158);
/* 141 */       sQLException.fillInStackTrace();
/* 142 */       throw sQLException;
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 147 */     BLOB bLOB = null;
/*     */ 
/*     */     
/* 150 */     initializeLobdef();
/*     */ 
/*     */     
/* 153 */     this.lobops = 272L;
/* 154 */     this.sourceLobLocator = new byte[40];
/* 155 */     this.sourceLobLocator[1] = 84;
/*     */ 
/*     */     
/* 158 */     this.characterSet = 1;
/*     */ 
/*     */ 
/*     */     
/* 162 */     this.destinationOffset = 113L;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 167 */     this.destinationLength = paramInt;
/*     */     
/* 169 */     this.lobamt = paramInt;
/* 170 */     this.sendLobamt = true;
/*     */ 
/*     */     
/* 173 */     this.nullO2U = true;
/*     */     
/* 175 */     if (this.connection.versionNumber >= 9000) {
/*     */       
/* 177 */       this.lobscn = new int[1];
/* 178 */       this.lobscn[0] = paramBoolean ? 1 : 0;
/* 179 */       this.lobscnl = 1;
/*     */     } 
/*     */     
/* 182 */     doRPC();
/*     */ 
/*     */ 
/*     */     
/* 186 */     if (this.sourceLobLocator != null)
/*     */     {
/* 188 */       bLOB = new BLOB((OracleConnection)paramConnection, this.sourceLobLocator);
/*     */     }
/*     */ 
/*     */     
/* 192 */     return (Datum)bLOB;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean open(byte[] paramArrayOfbyte, int paramInt) throws SQLException, IOException {
/* 210 */     boolean bool = false;
/*     */ 
/*     */ 
/*     */     
/* 214 */     byte b = 2;
/*     */     
/* 216 */     if (paramInt == 0) {
/* 217 */       b = 1;
/*     */     }
/* 219 */     bool = _open(paramArrayOfbyte, b, 32768);
/*     */     
/* 221 */     return bool;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean close(byte[] paramArrayOfbyte) throws SQLException, IOException {
/* 239 */     boolean bool = false;
/*     */     
/* 241 */     bool = _close(paramArrayOfbyte, 65536);
/*     */     
/* 243 */     return bool;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean isOpen(byte[] paramArrayOfbyte) throws SQLException, IOException {
/* 261 */     boolean bool = false;
/*     */     
/* 263 */     bool = _isOpen(paramArrayOfbyte, 69632);
/*     */     
/* 265 */     return bool;
/*     */   }
/*     */ 
/*     */   
/* 269 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*     */   public static final String BUILD_DATE = "Thu_Apr_04_15:09:24_PDT_2013";
/*     */   public static final boolean TRACE = false;
/*     */ }


/* Location:              C:\Users\olatu\OneDrive\Documents\Calypso\syncbase\sync_base.jar!\BOOT-INF\classes\ojdbc.jar!\oracle\jdbc\driver\T4C8TTIBlob.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */