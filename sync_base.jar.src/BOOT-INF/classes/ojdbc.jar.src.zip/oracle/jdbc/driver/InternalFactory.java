/*     */ package oracle.jdbc.driver;
/*     */ 
/*     */ import java.sql.SQLException;
/*     */ import oracle.jdbc.aq.AQMessageProperties;
/*     */ import oracle.jdbc.internal.JMSMessageProperties;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class InternalFactory
/*     */ {
/*     */   public static KeywordValueI createKeywordValue(int paramInt, String paramString, byte[] paramArrayOfbyte) throws SQLException {
/*  51 */     return new KeywordValueI(paramInt, paramString, paramArrayOfbyte);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static KeywordValueLongI createKeywordValueLong(int paramInt, String paramString, byte[] paramArrayOfbyte) throws SQLException {
/*  59 */     return new KeywordValueLongI(paramInt, paramString, paramArrayOfbyte);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static XSAttributeI createXSAttribute() throws SQLException {
/*  65 */     return new XSAttributeI();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static XSNamespaceI createXSNamespace() throws SQLException {
/*  71 */     return new XSNamespaceI();
/*     */   }
/*     */ 
/*     */   
/*     */   public static AQMessagePropertiesI createAQMessageProperties() throws SQLException {
/*  76 */     return new AQMessagePropertiesI();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static AQAgentI createAQAgent() throws SQLException {
/*  82 */     return new AQAgentI();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static AQMessageI createAQMessage(AQMessageProperties paramAQMessageProperties) throws SQLException {
/*  89 */     return new AQMessageI((AQMessagePropertiesI)paramAQMessageProperties);
/*     */   }
/*     */ 
/*     */   
/*     */   public static JMSMessageI createJMSMessage(JMSMessageProperties paramJMSMessageProperties) {
/*  94 */     return new JMSMessageI(paramJMSMessageProperties);
/*     */   }
/*     */ 
/*     */   
/*     */   public static JMSMessagePropertiesI createJMSMessageProperties() throws SQLException {
/*  99 */     return new JMSMessagePropertiesI();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static byte[] urowid2rowid(long[] paramArrayOflong) {
/* 114 */     return T4CRowidAccessor.rowidToString(paramArrayOflong);
/*     */   }
/*     */   
/*     */   public static long[] rowid2urowid(byte[] paramArrayOfbyte, int paramInt1, int paramInt2) throws SQLException {
/* 118 */     return T4CRowidAccessor.stringToRowid(paramArrayOfbyte, paramInt1, paramInt2);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static XSSecureIdI createXSecureId() throws SQLException {
/* 124 */     return new XSSecureIdI();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static XSPrincipalI createXSPrincipal() throws SQLException {
/* 130 */     return new XSPrincipalI();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static XSKeyvalI createXSKeyval() throws SQLException {
/* 136 */     return new XSKeyvalI();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static XSSessionNamespaceI createXSSessionNamespace() throws SQLException {
/* 142 */     return new XSSessionNamespaceI();
/*     */   }
/*     */ 
/*     */   
/*     */   public static XSSessionParametersI createXSSessionParameters() throws SQLException {
/* 147 */     return new XSSessionParametersI();
/*     */   }
/*     */ }


/* Location:              C:\Users\olatu\OneDrive\Documents\Calypso\syncbase\sync_base.jar!\BOOT-INF\classes\ojdbc.jar!\oracle\jdbc\driver\InternalFactory.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */