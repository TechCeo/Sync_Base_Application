/*     */ package oracle.jdbc.driver;
/*     */ 
/*     */ import java.lang.ref.SoftReference;
/*     */ import java.lang.reflect.Array;
/*     */ import oracle.jdbc.internal.OracleConnection;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class BufferCache<T>
/*     */ {
/* 142 */   private static final double ln2 = Math.log(2.0D);
/*     */ 
/*     */ 
/*     */   
/*     */   private static final int BUFFERS_PER_BUCKET = 8;
/*     */ 
/*     */ 
/*     */   
/*     */   private static final int MIN_INDEX = 12;
/*     */ 
/*     */   
/*     */   private final InternalStatistics stats;
/*     */ 
/*     */   
/*     */   private final int[] bufferSize;
/*     */ 
/*     */   
/*     */   private final SoftReference<T>[][] buckets;
/*     */ 
/*     */   
/*     */   private final int[] top;
/*     */ 
/*     */ 
/*     */   
/*     */   BufferCache(int paramInt) {
/*     */     int i;
/* 168 */     if (paramInt < 31) {
/* 169 */       i = paramInt;
/*     */     
/*     */     }
/*     */     else {
/*     */       
/* 174 */       i = (int)Math.ceil(Math.log(paramInt) / ln2);
/*     */     } 
/*     */     
/* 177 */     int j = Math.max(0, i - 12 + 1);
/*     */     
/* 179 */     this.buckets = (SoftReference<T>[][])new SoftReference[j][8];
/* 180 */     this.top = new int[j];
/*     */     
/* 182 */     this.bufferSize = new int[j];
/* 183 */     int k = 4096;
/* 184 */     for (byte b = 0; b < this.bufferSize.length; b++) {
/* 185 */       this.bufferSize[b] = k;
/* 186 */       k <<= 1;
/*     */     } 
/* 188 */     this.stats = new InternalStatistics(this.bufferSize);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   T get(Class<?> paramClass, int paramInt) {
/* 206 */     int i = bufferIndex(paramInt);
/*     */     
/* 208 */     if (i >= this.buckets.length) {
/* 209 */       this.stats.requestTooBig();
/* 210 */       return (T)Array.newInstance(paramClass, paramInt);
/*     */     } 
/*     */     
/* 213 */     while (this.top[i] > 0) {
/* 214 */       this.top[i] = this.top[i] - 1; SoftReference<T> softReference = this.buckets[i][this.top[i] - 1];
/* 215 */       this.buckets[i][this.top[i]] = null;
/* 216 */       T t = softReference.get();
/* 217 */       if (t != null) {
/* 218 */         this.stats.cacheHit(i);
/* 219 */         return t;
/*     */       } 
/*     */     } 
/*     */     
/* 223 */     this.stats.cacheMiss(i);
/* 224 */     return (T)Array.newInstance(paramClass, this.bufferSize[i]);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void put(T paramT) {
/* 238 */     int i = Array.getLength(paramT);
/*     */     
/* 240 */     int j = bufferIndex(i);
/*     */ 
/*     */     
/* 243 */     if (j >= this.buckets.length || i != this.bufferSize[j]) {
/* 244 */       this.stats.cacheTooBig();
/*     */       
/*     */       return;
/*     */     } 
/* 248 */     if (this.top[j] < 8) {
/* 249 */       this.stats.bufferCached(j);
/* 250 */       this.top[j] = this.top[j] + 1; this.buckets[j][this.top[j]] = new SoftReference<>(paramT);
/*     */     
/*     */     }
/*     */     else {
/*     */ 
/*     */       
/* 256 */       for (int k = this.top[j]; k > 0;) {
/* 257 */         if (this.buckets[j][--k].get() == null) {
/*     */           
/* 259 */           this.stats.refCleared(j);
/* 260 */           this.buckets[j][k] = new SoftReference<>(paramT);
/*     */           return;
/*     */         } 
/*     */       } 
/* 264 */       this.stats.bucketFull(j);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   OracleConnection.BufferCacheStatistics getStatistics() {
/* 272 */     return this.stats;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int bufferIndex(int paramInt) {
/* 280 */     for (byte b = 0; b < this.bufferSize.length; b++) {
/* 281 */       if (paramInt <= this.bufferSize[b]) return b; 
/*     */     } 
/* 283 */     return Integer.MAX_VALUE;
/*     */   }
/*     */   
/*     */   private static final class InternalStatistics
/*     */     implements OracleConnection.BufferCacheStatistics {
/* 288 */     private static int CACHE_COUNT = 0;
/*     */     
/* 290 */     private final int cacheId = ++CACHE_COUNT;
/*     */     
/*     */     private final int[] sizes;
/*     */     
/*     */     private final int[] nCacheHit;
/*     */     
/*     */     private final int[] nCacheMiss;
/*     */     private int nRequestTooBig;
/*     */     private final int[] nBufferCached;
/*     */     private final int[] nBucketFull;
/*     */     private final int[] nRefCleared;
/*     */     private int nCacheTooBig;
/*     */     
/*     */     InternalStatistics(int[] param1ArrayOfint) {
/* 304 */       this.sizes = param1ArrayOfint;
/* 305 */       int i = param1ArrayOfint.length;
/* 306 */       this.nCacheHit = new int[i];
/* 307 */       this.nCacheMiss = new int[i];
/* 308 */       this.nRequestTooBig = 0;
/* 309 */       this.nBufferCached = new int[i];
/* 310 */       this.nBucketFull = new int[i];
/* 311 */       this.nRefCleared = new int[i];
/* 312 */       this.nCacheTooBig = 0;
/*     */     }
/*     */     
/* 315 */     void cacheHit(int param1Int) { this.nCacheHit[param1Int] = this.nCacheHit[param1Int] + 1; }
/* 316 */     void cacheMiss(int param1Int) { this.nCacheMiss[param1Int] = this.nCacheMiss[param1Int] + 1; }
/* 317 */     void requestTooBig() { this.nRequestTooBig++; }
/* 318 */     void bufferCached(int param1Int) { this.nBufferCached[param1Int] = this.nBufferCached[param1Int] + 1; }
/* 319 */     void bucketFull(int param1Int) { this.nBucketFull[param1Int] = this.nBucketFull[param1Int] + 1; }
/* 320 */     void refCleared(int param1Int) { this.nRefCleared[param1Int] = this.nRefCleared[param1Int] + 1; } void cacheTooBig() {
/* 321 */       this.nCacheTooBig++;
/*     */     }
/*     */     public int getId() {
/* 324 */       return this.cacheId;
/*     */     } public int[] getBufferSizes() {
/* 326 */       int[] arrayOfInt = new int[this.sizes.length];
/* 327 */       System.arraycopy(this.sizes, 0, arrayOfInt, 0, this.sizes.length);
/* 328 */       return arrayOfInt;
/*     */     }
/* 330 */     public int getCacheHits(int param1Int) { return this.nCacheHit[param1Int]; }
/* 331 */     public int getCacheMisses(int param1Int) { return this.nCacheMiss[param1Int]; }
/* 332 */     public int getRequestsTooBig() { return this.nRequestTooBig; }
/* 333 */     public int getBuffersCached(int param1Int) { return this.nBufferCached[param1Int]; }
/* 334 */     public int getBucketsFull(int param1Int) { return this.nBucketFull[param1Int]; }
/* 335 */     public int getReferencesCleared(int param1Int) { return this.nRefCleared[param1Int]; } public int getTooBigToCache() {
/* 336 */       return this.nCacheTooBig;
/*     */     }
/*     */     public String toString() {
/* 339 */       int i = 0;
/* 340 */       int j = 0;
/* 341 */       int k = 0;
/* 342 */       int m = 0;
/* 343 */       int n = 0;
/* 344 */       for (byte b = 0; b < this.sizes.length; b++) {
/* 345 */         i += this.nCacheHit[b];
/* 346 */         j += this.nCacheMiss[b];
/* 347 */         k += this.nBufferCached[b];
/* 348 */         m += this.nBucketFull[b];
/* 349 */         n += this.nRefCleared[b];
/*     */       } 
/* 351 */       return "oracle.jdbc.driver.BufferCache<" + this.cacheId + ">\n" + "\tTotal Hits   :\t" + i + "\n" + "\tTotal Misses :\t" + (j + this.nRequestTooBig) + "\n" + "\tTotal Cached :\t" + k + "\n" + "\tTotal Dropped:\t" + (m + this.nCacheTooBig) + "\n" + "\tTotal Cleared:\t" + n + "\n";
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 362 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*     */   public static final String BUILD_DATE = "Thu_Apr_04_15:09:24_PDT_2013";
/*     */   public static final boolean TRACE = false;
/*     */ }


/* Location:              C:\Users\olatu\OneDrive\Documents\Calypso\syncbase\sync_base.jar!\BOOT-INF\classes\ojdbc.jar!\oracle\jdbc\driver\BufferCache.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */