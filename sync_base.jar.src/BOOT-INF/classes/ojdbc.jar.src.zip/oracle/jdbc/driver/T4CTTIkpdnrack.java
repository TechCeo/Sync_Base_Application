/*    */ package oracle.jdbc.driver;
/*    */ 
/*    */ import java.io.IOException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class T4CTTIkpdnrack
/*    */ {
/*    */   byte[] acknowledgmentQueue;
/*    */   long acknowledgementRegistrationId;
/*    */   byte[] lastReceivedMessageId;
/*    */   T4CMAREngine mar;
/*    */   
/*    */   T4CTTIkpdnrack(T4CConnection paramT4CConnection) {
/* 41 */     this.mar = paramT4CConnection.mare;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   void send(byte[] paramArrayOfbyte1, long paramLong, byte[] paramArrayOfbyte2) throws IOException {
/* 48 */     this.acknowledgmentQueue = paramArrayOfbyte1;
/* 49 */     this.acknowledgementRegistrationId = paramLong;
/* 50 */     this.lastReceivedMessageId = paramArrayOfbyte2;
/* 51 */     marshal();
/*    */   }
/*    */ 
/*    */   
/*    */   void marshal() throws IOException {
/* 56 */     if (this.acknowledgmentQueue != null && this.acknowledgmentQueue.length != 0) {
/* 57 */       this.mar.marshalSWORD(this.acknowledgmentQueue.length);
/* 58 */       this.mar.marshalCLR(this.acknowledgmentQueue, 0, this.acknowledgmentQueue.length);
/*    */     } else {
/*    */       
/* 61 */       this.mar.marshalSWORD(0);
/*    */     } 
/* 63 */     this.mar.marshalUB4(this.acknowledgementRegistrationId);
/*    */     
/* 65 */     if (this.lastReceivedMessageId != null && this.lastReceivedMessageId.length != 0) {
/* 66 */       this.mar.marshalSWORD(this.lastReceivedMessageId.length);
/* 67 */       this.mar.marshalCLR(this.lastReceivedMessageId, 0, this.lastReceivedMessageId.length);
/*    */     } else {
/*    */       
/* 70 */       this.mar.marshalSWORD(0);
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/* 75 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*    */   public static final String BUILD_DATE = "Thu_Apr_04_15:09:24_PDT_2013";
/*    */   public static final boolean TRACE = false;
/*    */ }


/* Location:              C:\Users\olatu\OneDrive\Documents\Calypso\syncbase\sync_base.jar!\BOOT-INF\classes\ojdbc.jar!\oracle\jdbc\driver\T4CTTIkpdnrack.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */