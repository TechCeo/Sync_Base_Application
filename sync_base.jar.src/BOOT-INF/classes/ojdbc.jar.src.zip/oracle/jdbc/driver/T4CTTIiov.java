/*     */ package oracle.jdbc.driver;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.sql.SQLException;
/*     */ import oracle.jdbc.oracore.OracleTypeADT;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class T4CTTIiov
/*     */   extends T4CTTIMsg
/*     */ {
/*     */   T4C8TTIrxh rxh;
/*     */   T4CTTIrxd rxd;
/*  38 */   short bindtype = 0;
/*     */   
/*     */   byte[] iovector;
/*  41 */   int bindcnt = 0;
/*  42 */   int inbinds = 0;
/*  43 */   int outbinds = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static final byte BV_IN_V = 32;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static final byte BV_OUT_V = 16;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   T4CTTIiov(T4CConnection paramT4CConnection, T4C8TTIrxh paramT4C8TTIrxh, T4CTTIrxd paramT4CTTIrxd) throws SQLException, IOException {
/*  59 */     super(paramT4CConnection, (byte)0);
/*     */     
/*  61 */     this.rxh = paramT4C8TTIrxh;
/*  62 */     this.rxd = paramT4CTTIrxd;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void init() throws SQLException, IOException {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Accessor[] processRXD(Accessor[] paramArrayOfAccessor, int paramInt1, byte[] paramArrayOfbyte1, char[] paramArrayOfchar1, short[] paramArrayOfshort1, int paramInt2, DBConversion paramDBConversion, byte[] paramArrayOfbyte2, byte[] paramArrayOfbyte3, InputStream[][] paramArrayOfInputStream, byte[][][] paramArrayOfbyte, OracleTypeADT[][] paramArrayOfOracleTypeADT, OracleStatement paramOracleStatement, byte[] paramArrayOfbyte4, char[] paramArrayOfchar2, short[] paramArrayOfshort2) throws SQLException, IOException {
/*  97 */     if (paramArrayOfbyte3 != null)
/*     */     {
/*  99 */       for (byte b = 0; b < paramArrayOfbyte3.length; b++) {
/*     */         
/* 101 */         if ((paramArrayOfbyte3[b] & 0x10) != 0 && (paramArrayOfAccessor == null || paramArrayOfAccessor.length <= b || paramArrayOfAccessor[b] == null)) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 108 */           int i = paramInt2 + 5 + 10 * b;
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 113 */           int j = paramArrayOfshort1[i + 0] & 0xFFFF;
/*     */ 
/*     */           
/* 116 */           int k = j;
/*     */           
/* 118 */           if (j == 9) {
/* 119 */             j = 1;
/*     */           }
/* 121 */           Accessor accessor = paramOracleStatement.allocateAccessor(j, j, b, 0, (short)0, null, false);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 130 */           accessor.rowSpaceIndicator = null;
/*     */           
/* 132 */           if (paramArrayOfAccessor == null)
/*     */           {
/* 134 */             paramArrayOfAccessor = new Accessor[b + 1];
/* 135 */             paramArrayOfAccessor[b] = accessor;
/*     */           }
/* 137 */           else if (paramArrayOfAccessor.length <= b)
/*     */           {
/* 139 */             Accessor[] arrayOfAccessor = new Accessor[b + 1];
/*     */             
/* 141 */             arrayOfAccessor[b] = accessor;
/*     */             
/* 143 */             for (byte b1 = 0; b1 < paramArrayOfAccessor.length; b1++) {
/*     */               
/* 145 */               if (paramArrayOfAccessor[b1] != null) {
/* 146 */                 arrayOfAccessor[b1] = paramArrayOfAccessor[b1];
/*     */               }
/*     */             } 
/* 149 */             paramArrayOfAccessor = arrayOfAccessor;
/*     */           
/*     */           }
/*     */           else
/*     */           {
/*     */             
/* 155 */             paramArrayOfAccessor[b] = accessor;
/*     */           }
/*     */         
/* 158 */         } else if ((paramArrayOfbyte3[b] & 0x10) == 0 && paramArrayOfAccessor != null && b < paramArrayOfAccessor.length && paramArrayOfAccessor[b] != null) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 164 */           (paramArrayOfAccessor[b]).isUseLess = true;
/*     */         } 
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 171 */     return paramArrayOfAccessor;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void unmarshalV10() throws IOException, SQLException {
/* 180 */     this.rxh.unmarshalV10(this.rxd);
/*     */     
/* 182 */     this.bindcnt = this.rxh.numRqsts;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 192 */     this.iovector = new byte[this.connection.all8.numberOfBindPositions];
/*     */     
/* 194 */     for (byte b = 0; b < this.iovector.length; b++) {
/*     */ 
/*     */ 
/*     */       
/* 198 */       if ((this.bindtype = this.meg.unmarshalUB1()) == 0) {
/*     */ 
/*     */ 
/*     */         
/* 202 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 401);
/* 203 */         sQLException.fillInStackTrace();
/* 204 */         throw sQLException;
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 210 */       if ((this.bindtype & 0x20) > 0) {
/*     */         
/* 212 */         this.iovector[b] = (byte)(this.iovector[b] | 0x20);
/* 213 */         this.inbinds++;
/*     */       } 
/*     */       
/* 216 */       if ((this.bindtype & 0x10) > 0) {
/*     */         
/* 218 */         this.iovector[b] = (byte)(this.iovector[b] | 0x10);
/* 219 */         this.outbinds++;
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   byte[] getIOVector() {
/* 237 */     return this.iovector;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean isIOVectorEmpty() {
/* 248 */     return (this.iovector.length == 0);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/* 253 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*     */   public static final String BUILD_DATE = "Thu_Apr_04_15:09:24_PDT_2013";
/*     */   public static final boolean TRACE = false;
/*     */ }


/* Location:              C:\Users\olatu\OneDrive\Documents\Calypso\syncbase\sync_base.jar!\BOOT-INF\classes\ojdbc.jar!\oracle\jdbc\driver\T4CTTIiov.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */