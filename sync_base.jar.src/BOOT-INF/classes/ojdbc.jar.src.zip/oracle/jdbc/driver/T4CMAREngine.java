/*      */ package oracle.jdbc.driver;
/*      */ 
/*      */ import java.io.ByteArrayInputStream;
/*      */ import java.io.IOException;
/*      */ import java.io.InputStream;
/*      */ import java.sql.SQLException;
/*      */ import java.util.ArrayList;
/*      */ import java.util.concurrent.atomic.AtomicReference;
/*      */ import oracle.jdbc.internal.OracleConnection;
/*      */ import oracle.net.ns.Communication;
/*      */ import oracle.net.ns.NetException;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ abstract class T4CMAREngine
/*      */ {
/*      */   static final int TTCC_MXL = 252;
/*      */   static final int TTCC_ESC = 253;
/*      */   static final int TTCC_LNG = 254;
/*      */   static final int TTCC_ERR = 255;
/*      */   static final int TTCC_MXIN = 32767;
/*      */   static final int TTCC_MXIN_OLD = 64;
/*   88 */   private int effectiveTTCC_MXIN = 64;
/*      */ 
/*      */   
/*      */   static final byte TTCLXMULTI = 1;
/*      */   
/*      */   static final byte TTCLXMCONV = 2;
/*      */   
/*      */   T4CTypeRep types;
/*      */   
/*      */   Communication net;
/*      */   
/*      */   DBConversion conv;
/*      */   
/*      */   short proSvrVer;
/*      */   
/*  103 */   static final byte[] NO_BYTES = new byte[0];
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   boolean useCLRBigChunks = false;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  125 */   static final byte[] IGNORED = new byte[32767];
/*  126 */   final byte[] tmpBuffer1 = new byte[1];
/*  127 */   final byte[] tmpBuffer2 = new byte[2];
/*  128 */   final byte[] tmpBuffer3 = new byte[3];
/*  129 */   final byte[] tmpBuffer4 = new byte[4];
/*  130 */   final byte[] tmpBuffer5 = new byte[5];
/*  131 */   final byte[] tmpBuffer6 = new byte[6];
/*  132 */   final byte[] tmpBuffer7 = new byte[7];
/*  133 */   final byte[] tmpBuffer8 = new byte[8];
/*  134 */   final byte[] tmpBuffer10 = new byte[10];
/*  135 */   final int[] retLen = new int[1];
/*      */ 
/*      */   
/*  138 */   AtomicReference<OracleConnection> connForException = new AtomicReference<>();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static String toHex(long paramLong, int paramInt) {
/*      */     String str;
/*  150 */     switch (paramInt) {
/*      */ 
/*      */       
/*      */       case 1:
/*  154 */         str = "00" + Long.toString(paramLong & 0xFFL, 16);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  196 */         return "0x" + str.substring(str.length() - 2 * paramInt);case 2: str = "0000" + Long.toString(paramLong & 0xFFFFL, 16); return "0x" + str.substring(str.length() - 2 * paramInt);case 3: str = "000000" + Long.toString(paramLong & 0xFFFFFFL, 16); return "0x" + str.substring(str.length() - 2 * paramInt);case 4: str = "00000000" + Long.toString(paramLong & 0xFFFFFFFFL, 16); return "0x" + str.substring(str.length() - 2 * paramInt);case 5: str = "0000000000" + Long.toString(paramLong & 0xFFFFFFFFFFL, 16); return "0x" + str.substring(str.length() - 2 * paramInt);case 6: str = "000000000000" + Long.toString(paramLong & 0xFFFFFFFFFFFFL, 16); return "0x" + str.substring(str.length() - 2 * paramInt);case 7: str = "00000000000000" + Long.toString(paramLong & 0xFFFFFFFFFFFFFFL, 16); return "0x" + str.substring(str.length() - 2 * paramInt);
/*      */       case 8:
/*      */         return toHex(paramLong >> 32L, 4) + toHex(paramLong, 4).substring(2);
/*      */     } 
/*      */     return "more than 8 bytes"; } static String toHex(byte paramByte) {
/*  201 */     String str = "00" + Integer.toHexString(paramByte & 0xFF);
/*  202 */     return "0x" + str.substring(str.length() - 2);
/*      */   }
/*      */ 
/*      */   
/*      */   static String toHex(short paramShort) {
/*  207 */     return toHex(paramShort, 2);
/*      */   }
/*      */ 
/*      */   
/*      */   static String toHex(int paramInt) {
/*  212 */     return toHex(paramInt, 4);
/*      */   }
/*      */ 
/*      */   
/*      */   static String toHex(byte[] paramArrayOfbyte, int paramInt) {
/*  217 */     if (paramArrayOfbyte == null) {
/*  218 */       return "null";
/*      */     }
/*  220 */     if (paramInt > paramArrayOfbyte.length) {
/*  221 */       return "byte array not long enough";
/*      */     }
/*  223 */     String str = "[";
/*  224 */     int i = Math.min(64, paramInt);
/*      */     
/*  226 */     for (byte b = 0; b < i; b++)
/*      */     {
/*  228 */       str = str + toHex(paramArrayOfbyte[b]) + " ";
/*      */     }
/*      */     
/*  231 */     if (i < paramInt) {
/*  232 */       str = str + "...";
/*      */     }
/*  234 */     return str + "]";
/*      */   }
/*      */ 
/*      */   
/*      */   static String toHex(byte[] paramArrayOfbyte) {
/*  239 */     if (paramArrayOfbyte == null) {
/*  240 */       return "null";
/*      */     }
/*  242 */     return toHex(paramArrayOfbyte, paramArrayOfbyte.length);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   abstract void marshalSB1(byte paramByte) throws IOException;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   abstract void marshalUB1(short paramShort) throws IOException;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   abstract void marshalSB2(short paramShort) throws IOException;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   abstract void marshalUB2(int paramInt) throws IOException;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   abstract void marshalSB4(int paramInt) throws IOException;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   abstract void marshalUB4(long paramLong) throws IOException;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   abstract void marshalSB8(long paramLong) throws IOException;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final void marshalSWORD(int paramInt) throws IOException {
/*  316 */     marshalSB4(paramInt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final void marshalUWORD(long paramLong) throws IOException {
/*  328 */     marshalSB4((int)(paramLong & 0xFFFFFFFFFFFFFFFFL));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   abstract void marshalB1Array(byte[] paramArrayOfbyte) throws IOException;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   abstract void marshalB1Array(byte[] paramArrayOfbyte, int paramInt1, int paramInt2) throws IOException;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final void marshalUB4Array(long[] paramArrayOflong) throws IOException {
/*  356 */     for (byte b = 0; b < paramArrayOflong.length; b++) {
/*  357 */       marshalSB4((int)(paramArrayOflong[b] & 0xFFFFFFFFFFFFFFFFL));
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final void marshalO2U(boolean paramBoolean) throws IOException {
/*  400 */     if (paramBoolean) {
/*  401 */       addPtr((byte)1);
/*      */     } else {
/*  403 */       addPtr((byte)0);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final void marshalNULLPTR() throws IOException {
/*  419 */     addPtr((byte)0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final void marshalPTR() throws IOException {
/*  437 */     addPtr((byte)1);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final void marshalCHR(byte[] paramArrayOfbyte) throws IOException {
/*  452 */     marshalCHR(paramArrayOfbyte, 0, paramArrayOfbyte.length);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final void marshalCHR(byte[] paramArrayOfbyte, int paramInt1, int paramInt2) throws IOException {
/*  460 */     if (paramInt2 > 0)
/*      */     {
/*  462 */       if (this.types.isConvNeeded()) {
/*  463 */         marshalCLR(paramArrayOfbyte, paramInt1, paramInt2);
/*      */       } else {
/*      */         
/*  466 */         marshalB1Array(paramArrayOfbyte, paramInt1, paramInt2);
/*      */       } 
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final void marshalCLR(byte[] paramArrayOfbyte, int paramInt) throws IOException {
/*  481 */     marshalCLR(paramArrayOfbyte, 0, paramInt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final void marshalCLR(byte[] paramArrayOfbyte, int paramInt1, int paramInt2) throws IOException {
/*  491 */     if (paramInt2 > 252) {
/*      */       
/*  493 */       int i = 0;
/*      */ 
/*      */ 
/*      */       
/*  497 */       marshalUB1((short)-2);
/*      */       
/*      */       while (true) {
/*  500 */         int j = paramInt2 - i;
/*  501 */         int k = (j > this.effectiveTTCC_MXIN) ? this.effectiveTTCC_MXIN : j;
/*      */ 
/*      */         
/*  504 */         if (this.useCLRBigChunks) {
/*      */           
/*  506 */           marshalSB4(k);
/*      */         }
/*      */         else {
/*      */           
/*  510 */           marshalUB1((short)(byte)(k & 0xFF));
/*      */         } 
/*      */         
/*  513 */         marshalB1Array(paramArrayOfbyte, paramInt1 + i, k);
/*      */         
/*  515 */         i += k;
/*      */         
/*  517 */         if (i >= paramInt2) {
/*  518 */           marshalUB1((short)0); return;
/*      */         } 
/*      */       } 
/*      */     } 
/*  522 */     marshalUB1((short)(byte)(paramInt2 & 0xFF));
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  528 */     if (paramArrayOfbyte.length != 0) {
/*  529 */       marshalB1Array(paramArrayOfbyte, paramInt1, paramInt2);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final void marshalCLR(InputStream paramInputStream, int paramInt) throws IOException {
/*  546 */     int i = this.effectiveTTCC_MXIN;
/*  547 */     byte[] arrayOfByte = new byte[i];
/*  548 */     int j = 0;
/*  549 */     boolean bool = false;
/*      */ 
/*      */     
/*  552 */     marshalUB1((short)254);
/*      */     
/*      */     try {
/*  555 */       while (!bool)
/*      */       {
/*  557 */         j = paramInputStream.read(arrayOfByte, 0, i);
/*  558 */         if (j == -1)
/*      */         {
/*  560 */           bool = true;
/*      */         }
/*      */         
/*  563 */         if (j > 0)
/*      */         {
/*  565 */           if (this.useCLRBigChunks) {
/*      */             
/*  567 */             marshalSB4(j);
/*      */           }
/*      */           else {
/*      */             
/*  571 */             marshalUB1((short)(byte)(j & 0xFF));
/*      */           } 
/*      */ 
/*      */           
/*  575 */           marshalB1Array(arrayOfByte, 0, j);
/*      */         }
/*      */       
/*      */       }
/*      */     
/*      */     } finally {
/*      */       
/*  582 */       marshalUB1((short)0);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final void marshalKEYVAL(byte[][] paramArrayOfbyte1, int[] paramArrayOfint1, byte[][] paramArrayOfbyte2, int[] paramArrayOfint2, byte[] paramArrayOfbyte, int paramInt) throws IOException {
/*  597 */     for (byte b = 0; b < paramInt; b++) {
/*      */       
/*  599 */       if (paramArrayOfbyte1[b] != null && paramArrayOfint1[b] > 0) {
/*      */         
/*  601 */         marshalUB4(paramArrayOfint1[b]);
/*  602 */         marshalCLR(paramArrayOfbyte1[b], 0, paramArrayOfint1[b]);
/*      */       } else {
/*      */         
/*  605 */         marshalUB4(0L);
/*      */       } 
/*  607 */       if (paramArrayOfbyte2[b] != null && paramArrayOfint2[b] > 0) {
/*      */         
/*  609 */         marshalUB4(paramArrayOfint2[b]);
/*  610 */         marshalCLR(paramArrayOfbyte2[b], 0, paramArrayOfint2[b]);
/*      */       } else {
/*      */         
/*  613 */         marshalUB4(0L);
/*      */       } 
/*      */       
/*  616 */       if (paramArrayOfbyte[b] != 0) {
/*  617 */         marshalUB4(1L);
/*      */       } else {
/*  619 */         marshalUB4(0L);
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final void marshalKEYVAL(byte[][] paramArrayOfbyte1, byte[][] paramArrayOfbyte2, byte[] paramArrayOfbyte, int paramInt) throws IOException {
/*  630 */     int[] arrayOfInt1 = new int[paramInt];
/*  631 */     int[] arrayOfInt2 = new int[paramInt];
/*  632 */     for (byte b = 0; b < paramInt; b++) {
/*      */       
/*  634 */       if (paramArrayOfbyte1[b] != null)
/*  635 */         arrayOfInt1[b] = (paramArrayOfbyte1[b]).length; 
/*  636 */       if (paramArrayOfbyte2[b] != null)
/*  637 */         arrayOfInt2[b] = (paramArrayOfbyte2[b]).length; 
/*      */     } 
/*  639 */     marshalKEYVAL(paramArrayOfbyte1, arrayOfInt1, paramArrayOfbyte2, arrayOfInt2, paramArrayOfbyte, paramInt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final void marshalDALC(byte[] paramArrayOfbyte) throws IOException {
/*  657 */     if (paramArrayOfbyte == null || paramArrayOfbyte.length < 1) {
/*      */       
/*  659 */       marshalUB4(0L);
/*      */     }
/*      */     else {
/*      */       
/*  663 */       marshalUB4(paramArrayOfbyte.length);
/*  664 */       marshalCLR(paramArrayOfbyte, paramArrayOfbyte.length);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final void marshalKPDKV(byte[][] paramArrayOfbyte1, byte[][] paramArrayOfbyte2, int[] paramArrayOfint) throws IOException {
/*  675 */     for (byte b = 0; b < paramArrayOfbyte1.length; b++) {
/*      */       
/*  677 */       if (paramArrayOfbyte1[b] != null) {
/*      */         
/*  679 */         marshalUB4((paramArrayOfbyte1[b]).length);
/*  680 */         marshalCLR(paramArrayOfbyte1[b], 0, (paramArrayOfbyte1[b]).length);
/*      */       } else {
/*      */         
/*  683 */         marshalUB4(0L);
/*  684 */       }  if (paramArrayOfbyte2[b] != null) {
/*      */         
/*  686 */         marshalUB4((paramArrayOfbyte2[b]).length);
/*  687 */         marshalCLR(paramArrayOfbyte2[b], 0, (paramArrayOfbyte2[b]).length);
/*      */       } else {
/*      */         
/*  690 */         marshalUB4(0L);
/*  691 */       }  marshalUB2(paramArrayOfint[b]);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final void unmarshalKPDKV(byte[][] paramArrayOfbyte1, int[] paramArrayOfint1, byte[][] paramArrayOfbyte2, int[] paramArrayOfint2) throws IOException, SQLException {
/*  703 */     int i = 0;
/*  704 */     int[] arrayOfInt = new int[1];
/*      */     
/*  706 */     for (byte b = 0; b < paramArrayOfbyte1.length; b++) {
/*      */       
/*  708 */       i = (int)unmarshalUB4();
/*  709 */       if (i > 0) {
/*      */         
/*  711 */         paramArrayOfbyte1[b] = new byte[i];
/*  712 */         unmarshalCLR(paramArrayOfbyte1[b], 0, arrayOfInt, i);
/*  713 */         paramArrayOfint1[b] = arrayOfInt[0];
/*      */       } 
/*  715 */       i = (int)unmarshalUB4();
/*  716 */       if (i > 0) {
/*      */         
/*  718 */         paramArrayOfbyte2[b] = new byte[i];
/*  719 */         unmarshalCLR(paramArrayOfbyte2[b], 0, arrayOfInt, i);
/*      */       } 
/*  721 */       paramArrayOfint2[b] = unmarshalUB2();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  737 */   static final byte[] NULL_PTR = new byte[] { 0, 0, 0, 0 };
/*  738 */   static final byte[] NOTNULL_PTR = new byte[] { Byte.MAX_VALUE, Byte.MAX_VALUE, Byte.MAX_VALUE, Byte.MAX_VALUE };
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final void addPtr(byte paramByte) throws IOException {
/*  744 */     if (this.types.rep[4] == 1) {
/*  745 */       marshalUB1((short)paramByte);
/*      */ 
/*      */     
/*      */     }
/*  749 */     else if (paramByte == 0) {
/*      */       
/*  751 */       marshalB1Array(NULL_PTR);
/*      */     }
/*      */     else {
/*      */       
/*  755 */       marshalB1Array(NOTNULL_PTR);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   abstract byte unmarshalSB1() throws SQLException, IOException;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   abstract short unmarshalUB1() throws SQLException, IOException;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   abstract short unmarshalSB2() throws SQLException, IOException;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   abstract int unmarshalUB2() throws SQLException, IOException;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final int unmarshalUCS2(byte[] paramArrayOfbyte, long paramLong) throws SQLException, IOException {
/*  842 */     int i = unmarshalUB2();
/*      */     
/*  844 */     this.tmpBuffer2[0] = (byte)((i & 0xFF00) >> 8);
/*  845 */     this.tmpBuffer2[1] = (byte)(i & 0xFF);
/*      */ 
/*      */     
/*  848 */     if (paramLong + 1L < paramArrayOfbyte.length) {
/*      */ 
/*      */ 
/*      */       
/*  852 */       paramArrayOfbyte[(int)paramLong] = this.tmpBuffer2[0];
/*  853 */       paramArrayOfbyte[(int)paramLong + 1] = this.tmpBuffer2[1];
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  879 */     return (this.tmpBuffer2[0] == 0) ? ((this.tmpBuffer2[1] == 0) ? 1 : 2) : 3;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   abstract int unmarshalSB4() throws SQLException, IOException;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   abstract long unmarshalUB4() throws SQLException, IOException;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final int unmarshalSB4(byte[] paramArrayOfbyte) throws SQLException, IOException {
/*  926 */     long l = buffer2Value((byte)2, new ByteArrayInputStream(paramArrayOfbyte));
/*      */     
/*  928 */     return (int)l;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final long unmarshalSB8() throws SQLException, IOException {
/*  949 */     return buffer2Value((byte)3);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final int unmarshalRefCursor(byte[] paramArrayOfbyte) throws SQLException, IOException {
/*  960 */     return unmarshalSB4(paramArrayOfbyte);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   int unmarshalSWORD() throws SQLException, IOException {
/*  981 */     return (int)unmarshalUB4();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   long unmarshalUWORD() throws SQLException, IOException {
/* 1001 */     return unmarshalUB4();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   abstract byte[] unmarshalNBytes(int paramInt) throws SQLException, IOException;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   abstract int unmarshalNBytes(byte[] paramArrayOfbyte, int paramInt1, int paramInt2) throws SQLException, IOException;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   abstract int getNBytes(byte[] paramArrayOfbyte, int paramInt1, int paramInt2) throws SQLException, IOException;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   abstract byte[] getNBytes(int paramInt) throws SQLException, IOException;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   abstract byte[] unmarshalTEXT(int paramInt) throws SQLException, IOException;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   byte[] unmarshalCHR(int paramInt) throws SQLException, IOException {
/* 1085 */     byte[] arrayOfByte = null;
/*      */     
/* 1087 */     if (this.types.isConvNeeded()) {
/*      */       
/* 1089 */       arrayOfByte = unmarshalCLR(paramInt, this.retLen);
/*      */       
/* 1091 */       if (arrayOfByte.length != this.retLen[0])
/*      */       {
/* 1093 */         byte[] arrayOfByte1 = new byte[this.retLen[0]];
/*      */         
/* 1095 */         System.arraycopy(arrayOfByte, 0, arrayOfByte1, 0, this.retLen[0]);
/*      */         
/* 1097 */         arrayOfByte = arrayOfByte1;
/*      */       }
/*      */     
/*      */     } else {
/*      */       
/* 1102 */       arrayOfByte = getNBytes(paramInt);
/*      */     } 
/*      */     
/* 1105 */     return arrayOfByte;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void unmarshalCLR(byte[] paramArrayOfbyte, int paramInt, int[] paramArrayOfint) throws SQLException, IOException {
/* 1114 */     unmarshalCLR(paramArrayOfbyte, paramInt, paramArrayOfint, 2147483647);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void unmarshalCLR(byte[] paramArrayOfbyte, int paramInt1, int[] paramArrayOfint, int paramInt2) throws SQLException, IOException {
/* 1122 */     unmarshalCLR(paramArrayOfbyte, paramInt1, paramArrayOfint, paramInt2, 0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void unmarshalCLR(Object paramObject, long paramLong, int[] paramArrayOfint, int paramInt1, int paramInt2) throws SQLException, IOException {
/* 1145 */     int i = 0;
/* 1146 */     int j = 0;
/* 1147 */     long l = paramLong;
/* 1148 */     boolean bool = false;
/* 1149 */     int k = 0;
/* 1150 */     int m = 0;
/* 1151 */     int n = 0;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1157 */     byte b = -1;
/*      */     
/* 1159 */     i = unmarshalUB1();
/*      */ 
/*      */     
/* 1162 */     if (i < 0) {
/*      */ 
/*      */ 
/*      */       
/* 1166 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 401);
/* 1167 */       sQLException.fillInStackTrace();
/* 1168 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/* 1172 */     if (i == 0) {
/*      */       
/* 1174 */       paramArrayOfint[0] = 0;
/*      */       
/*      */       return;
/*      */     } 
/* 1178 */     if (escapeSequenceNull(i)) {
/*      */       
/* 1180 */       paramArrayOfint[0] = 0;
/*      */       
/*      */       return;
/*      */     } 
/* 1184 */     if (i != 254) {
/*      */       
/* 1186 */       if (paramInt2 - n >= i) {
/*      */ 
/*      */         
/* 1189 */         unmarshalBuffer(IGNORED, 0, i);
/* 1190 */         n += i;
/*      */         
/* 1192 */         i = 0;
/*      */       }
/* 1194 */       else if (paramInt2 - n > 0) {
/*      */ 
/*      */ 
/*      */         
/* 1198 */         unmarshalBuffer(IGNORED, 0, paramInt2 - n);
/*      */         
/* 1200 */         i -= paramInt2 - n;
/* 1201 */         n += paramInt2 - n;
/*      */       } 
/*      */       
/* 1204 */       if (i > 0) {
/*      */ 
/*      */         
/* 1207 */         m = Math.min(paramInt1 - k, i);
/* 1208 */         l = unmarshalBuffer(paramObject, l, m);
/* 1209 */         k += m;
/*      */ 
/*      */         
/* 1212 */         int i1 = i - m;
/*      */         
/* 1214 */         if (i1 > 0) {
/* 1215 */           unmarshalBuffer(IGNORED, 0, i1);
/*      */         }
/*      */       } 
/*      */     } else {
/*      */       
/* 1220 */       b = -1;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       while (true) {
/* 1227 */         if (b != -1) {
/*      */           
/* 1229 */           if (this.useCLRBigChunks) {
/*      */             
/* 1231 */             i = unmarshalSB4();
/*      */           }
/*      */           else {
/*      */             
/* 1235 */             i = unmarshalUB1();
/*      */           } 
/*      */ 
/*      */           
/* 1239 */           if (i <= 0) {
/*      */             break;
/*      */           }
/*      */         } 
/* 1243 */         if (i == 254)
/*      */         {
/* 1245 */           switch (b) {
/*      */ 
/*      */             
/*      */             case -1:
/* 1249 */               b = 1;
/*      */               continue;
/*      */ 
/*      */             
/*      */             case 1:
/* 1254 */               b = 0;
/*      */               break;
/*      */ 
/*      */             
/*      */             case 0:
/* 1259 */               if (bool) {
/*      */                 
/* 1261 */                 b = 0;
/*      */ 
/*      */                 
/*      */                 break;
/*      */               } 
/*      */               
/* 1267 */               b = 0;
/*      */               continue;
/*      */           } 
/*      */ 
/*      */         
/*      */         }
/* 1273 */         if (l == -1L) {
/*      */           
/* 1275 */           unmarshalBuffer(IGNORED, 0, i);
/*      */         
/*      */         }
/*      */         else {
/*      */           
/* 1280 */           j = i;
/* 1281 */           if (paramInt2 - n >= j) {
/*      */ 
/*      */             
/* 1284 */             unmarshalBuffer(IGNORED, 0, j);
/* 1285 */             n += j;
/*      */             
/* 1287 */             j = 0;
/*      */           }
/* 1289 */           else if (paramInt2 - n > 0) {
/*      */ 
/*      */ 
/*      */             
/* 1293 */             unmarshalBuffer(IGNORED, 0, paramInt2 - n);
/*      */             
/* 1295 */             j -= paramInt2 - n;
/* 1296 */             n += paramInt2 - n;
/*      */           } 
/*      */           
/* 1299 */           if (j > 0) {
/*      */ 
/*      */             
/* 1302 */             m = Math.min(paramInt1 - k, j);
/* 1303 */             l = unmarshalBuffer(paramObject, l, m);
/* 1304 */             k += m;
/*      */ 
/*      */             
/* 1307 */             int i1 = j - m;
/*      */             
/* 1309 */             if (i1 > 0) {
/* 1310 */               unmarshalBuffer(IGNORED, 0, i1);
/*      */             }
/*      */           } 
/*      */         } 
/*      */         
/* 1315 */         b = 0;
/*      */         
/* 1317 */         if (i > 252) {
/* 1318 */           bool = true;
/*      */         }
/*      */       } 
/*      */     } 
/*      */     
/* 1323 */     if (paramArrayOfint != null)
/*      */     {
/* 1325 */       if (l != -1L) {
/* 1326 */         paramArrayOfint[0] = k;
/*      */       }
/*      */       else {
/*      */         
/* 1330 */         paramArrayOfint[0] = ((byte[])paramObject).length - (int)paramLong;
/*      */       } 
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final byte[] unmarshalCLR(int paramInt, int[] paramArrayOfint) throws SQLException, IOException {
/* 1344 */     byte[] arrayOfByte = new byte[paramInt * this.conv.c2sNlsRatio];
/*      */     
/* 1346 */     unmarshalCLR(arrayOfByte, 0, paramArrayOfint, paramInt);
/* 1347 */     return arrayOfByte;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final int[] unmarshalKEYVAL(byte[][] paramArrayOfbyte1, byte[][] paramArrayOfbyte2, int paramInt) throws SQLException, IOException {
/* 1357 */     byte[] arrayOfByte = new byte[1000];
/* 1358 */     int[] arrayOfInt1 = new int[1];
/* 1359 */     int[] arrayOfInt2 = new int[paramInt];
/*      */ 
/*      */     
/* 1362 */     for (byte b = 0; b < paramInt; b++) {
/*      */       
/* 1364 */       int i = unmarshalSB4();
/*      */       
/* 1366 */       if (i > 0) {
/*      */         
/* 1368 */         unmarshalCLR(arrayOfByte, 0, arrayOfInt1);
/*      */         
/* 1370 */         paramArrayOfbyte1[b] = new byte[arrayOfInt1[0]];
/*      */         
/* 1372 */         System.arraycopy(arrayOfByte, 0, paramArrayOfbyte1[b], 0, arrayOfInt1[0]);
/*      */       } 
/*      */       
/* 1375 */       i = unmarshalSB4();
/*      */       
/* 1377 */       if (i > 0) {
/*      */         
/* 1379 */         unmarshalCLR(arrayOfByte, 0, arrayOfInt1);
/*      */         
/* 1381 */         paramArrayOfbyte2[b] = new byte[arrayOfInt1[0]];
/*      */         
/* 1383 */         System.arraycopy(arrayOfByte, 0, paramArrayOfbyte2[b], 0, arrayOfInt1[0]);
/*      */       } 
/*      */       
/* 1386 */       arrayOfInt2[b] = unmarshalSB4();
/*      */     } 
/*      */     
/* 1389 */     arrayOfByte = null;
/*      */ 
/*      */     
/* 1392 */     return arrayOfInt2;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final long unmarshalBuffer(Object paramObject, long paramLong, int paramInt) throws SQLException, IOException {
/* 1400 */     if (paramObject instanceof DynamicByteArray) {
/* 1401 */       return ((DynamicByteArray)paramObject).unmarshalBuffer(this, paramLong, paramInt);
/*      */     }
/* 1403 */     return unmarshalBuffer((byte[])paramObject, (int)paramLong, paramInt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final int unmarshalBuffer(byte[] paramArrayOfbyte, int paramInt1, int paramInt2) throws SQLException, IOException {
/* 1411 */     if (paramInt2 <= 0) {
/* 1412 */       return paramInt1;
/*      */     }
/* 1414 */     if (paramArrayOfbyte.length < paramInt1 + paramInt2) {
/*      */       
/* 1416 */       unmarshalNBytes(paramArrayOfbyte, paramInt1, paramArrayOfbyte.length - paramInt1);
/*      */ 
/*      */       
/* 1419 */       unmarshalNBytes(IGNORED, 0, paramInt1 + paramInt2 - paramArrayOfbyte.length);
/*      */       
/* 1421 */       paramInt1 = -1;
/*      */     
/*      */     }
/*      */     else {
/*      */ 
/*      */       
/* 1427 */       unmarshalNBytes(paramArrayOfbyte, paramInt1, paramInt2);
/*      */       
/* 1429 */       paramInt1 += paramInt2;
/*      */     } 
/* 1431 */     return paramInt1;
/*      */   }
/*      */ 
/*      */   
/* 1435 */   ArrayList refVector = null;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final byte[] unmarshalCLRforREFS() throws SQLException, IOException {
/* 1441 */     byte b = 0;
/* 1442 */     short s = 0;
/* 1443 */     byte[] arrayOfByte = null;
/*      */ 
/*      */     
/* 1446 */     short s1 = unmarshalUB1();
/*      */ 
/*      */ 
/*      */     
/* 1450 */     if (s1 < 0) {
/*      */ 
/*      */ 
/*      */       
/* 1454 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 401);
/* 1455 */       sQLException.fillInStackTrace();
/* 1456 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/* 1460 */     if (s1 == 0)
/*      */     {
/* 1462 */       return null;
/*      */     }
/*      */ 
/*      */     
/* 1466 */     boolean bool = escapeSequenceNull(s1);
/* 1467 */     if (!bool)
/*      */     {
/* 1469 */       if (this.refVector == null) {
/* 1470 */         this.refVector = new ArrayList(10);
/*      */       } else {
/* 1472 */         this.refVector.clear();
/*      */       } 
/*      */     }
/* 1475 */     if (!bool) {
/*      */       
/* 1477 */       if (s1 == 254) {
/*      */         
/*      */         while (true) {
/*      */           
/* 1481 */           if (b = this.useCLRBigChunks ? unmarshalSB4() : unmarshalUB1()) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/* 1487 */             if (b == 'þ')
/*      */             {
/* 1489 */               if (this.types.isServerConversion()) {
/*      */                 continue;
/*      */               }
/*      */             }
/* 1493 */             s = (short)(s + b);
/* 1494 */             byte[] arrayOfByte1 = new byte[b];
/*      */             
/* 1496 */             unmarshalBuffer(arrayOfByte1, 0, b);
/* 1497 */             this.refVector.add(arrayOfByte1); continue;
/*      */           } 
/*      */           break;
/*      */         } 
/*      */       } else {
/* 1502 */         s = s1;
/*      */         
/* 1504 */         byte[] arrayOfByte1 = new byte[s1];
/*      */         
/* 1506 */         unmarshalBuffer(arrayOfByte1, 0, s1);
/* 1507 */         this.refVector.add(arrayOfByte1);
/*      */       } 
/*      */ 
/*      */       
/* 1511 */       arrayOfByte = new byte[s];
/*      */       
/* 1513 */       int i = 0;
/*      */       
/* 1515 */       while (this.refVector.size() > 0)
/*      */       {
/* 1517 */         int j = ((byte[])this.refVector.get(0)).length;
/*      */         
/* 1519 */         System.arraycopy(this.refVector.get(0), 0, arrayOfByte, i, j);
/*      */ 
/*      */         
/* 1522 */         i += j;
/*      */ 
/*      */ 
/*      */         
/* 1526 */         this.refVector.remove(0);
/*      */       }
/*      */     
/*      */     }
/*      */     else {
/*      */       
/* 1532 */       arrayOfByte = null;
/*      */     } 
/* 1534 */     return arrayOfByte;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final boolean escapeSequenceNull(int paramInt) throws SQLException {
/*      */     SQLException sQLException;
/* 1547 */     boolean bool = false;
/*      */     
/* 1549 */     switch (paramInt) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 0:
/* 1555 */         bool = true;
/*      */         break;
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 253:
/* 1562 */         sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 401);
/* 1563 */         sQLException.fillInStackTrace();
/* 1564 */         throw sQLException;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 255:
/* 1574 */         bool = true;
/*      */         break;
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1592 */     return bool;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final int processIndicator(boolean paramBoolean, int paramInt) throws SQLException, IOException {
/* 1605 */     short s = unmarshalSB2();
/* 1606 */     int i = 0;
/*      */     
/* 1608 */     if (!paramBoolean)
/*      */     {
/* 1610 */       if (s == 0) {
/* 1611 */         i = paramInt;
/* 1612 */       } else if (s == -2 || s > 0) {
/* 1613 */         i = s;
/*      */       }
/*      */       else {
/*      */         
/* 1617 */         i = 65536 + s;
/*      */       }  } 
/* 1619 */     return i;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final long unmarshalDALC(byte[] paramArrayOfbyte, int paramInt, int[] paramArrayOfint) throws SQLException, IOException {
/* 1638 */     long l = unmarshalUB4();
/*      */     
/* 1640 */     if (l > 0L)
/* 1641 */       unmarshalCLR(paramArrayOfbyte, paramInt, paramArrayOfint); 
/* 1642 */     return l;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final byte[] unmarshalDALC() throws SQLException, IOException {
/* 1650 */     long l = unmarshalUB4();
/* 1651 */     byte[] arrayOfByte = new byte[(int)(0xFFFFFFFFFFFFFFFFL & l)];
/*      */     
/* 1653 */     if (arrayOfByte.length > 0) {
/*      */       
/* 1655 */       arrayOfByte = unmarshalCLR(arrayOfByte.length, this.retLen);
/*      */       
/* 1657 */       if (arrayOfByte == null)
/*      */       {
/*      */ 
/*      */         
/* 1661 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 401);
/* 1662 */         sQLException.fillInStackTrace();
/* 1663 */         throw sQLException;
/*      */       }
/*      */     
/*      */     } else {
/*      */       
/* 1668 */       arrayOfByte = new byte[0];
/* 1669 */     }  return arrayOfByte;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final byte[] unmarshalDALC(int[] paramArrayOfint) throws SQLException, IOException {
/* 1677 */     long l = unmarshalUB4();
/* 1678 */     byte[] arrayOfByte = new byte[(int)(0xFFFFFFFFFFFFFFFFL & l)];
/*      */ 
/*      */     
/* 1681 */     if (arrayOfByte.length > 0) {
/*      */       
/* 1683 */       arrayOfByte = unmarshalCLR(arrayOfByte.length, paramArrayOfint);
/*      */       
/* 1685 */       if (arrayOfByte == null)
/*      */       {
/*      */ 
/*      */ 
/*      */         
/* 1690 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 401);
/* 1691 */         sQLException.fillInStackTrace();
/* 1692 */         throw sQLException;
/*      */       }
/*      */     
/*      */     } else {
/*      */       
/* 1697 */       arrayOfByte = new byte[0];
/* 1698 */     }  return arrayOfByte;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   abstract long buffer2Value(byte paramByte) throws SQLException, IOException;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final long buffer2Value(byte paramByte, ByteArrayInputStream paramByteArrayInputStream) throws SQLException, IOException {
/* 1736 */     int i = 0;
/*      */     
/* 1738 */     long l = 0L;
/* 1739 */     boolean bool = false;
/*      */ 
/*      */     
/* 1742 */     if ((this.types.rep[paramByte] & 0x1) > 0) {
/*      */       
/* 1744 */       i = paramByteArrayInputStream.read();
/*      */ 
/*      */       
/* 1747 */       if ((i & 0x80) > 0) {
/*      */         
/* 1749 */         i &= 0x7F;
/* 1750 */         bool = true;
/*      */       } 
/*      */       
/* 1753 */       if (i < 0) {
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1758 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 410);
/* 1759 */         sQLException.fillInStackTrace();
/* 1760 */         throw sQLException;
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1767 */       if (i == 0)
/*      */       {
/*      */         
/* 1770 */         return 0L;
/*      */       }
/*      */ 
/*      */       
/* 1774 */       if ((paramByte == 1 && i > 2) || (paramByte == 2 && i > 4))
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1780 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 412);
/* 1781 */         sQLException.fillInStackTrace();
/* 1782 */         throw sQLException;
/*      */ 
/*      */       
/*      */       }
/*      */ 
/*      */     
/*      */     }
/* 1789 */     else if (paramByte == 1) {
/* 1790 */       i = 2;
/* 1791 */     } else if (paramByte == 2) {
/* 1792 */       i = 4;
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1800 */     byte[] arrayOfByte = new byte[i];
/*      */     
/* 1802 */     if (paramByteArrayInputStream.read(arrayOfByte) < 0) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1807 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 410);
/* 1808 */       sQLException.fillInStackTrace();
/* 1809 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/* 1813 */     for (byte b = 0; b < arrayOfByte.length; b++) {
/*      */       short s;
/*      */       
/* 1816 */       if ((this.types.rep[paramByte] & 0x2) > 0) {
/* 1817 */         s = (short)(arrayOfByte[arrayOfByte.length - 1 - b] & 0xFF);
/*      */       } else {
/* 1819 */         s = (short)(arrayOfByte[b] & 0xFF);
/*      */       } 
/* 1821 */       l |= (s << 8 * (arrayOfByte.length - 1 - b));
/*      */     } 
/*      */ 
/*      */     
/* 1825 */     l &= 0xFFFFFFFFFFFFFFFFL;
/*      */     
/* 1827 */     if (bool) {
/* 1828 */       l = -l;
/*      */     }
/* 1830 */     return l;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected OracleConnection getConnectionDuringExceptionHandling() {
/* 1845 */     return this.connForException.get();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void setConnectionDuringExceptionHandling(OracleConnection paramOracleConnection) {
/* 1856 */     this.connForException.set(paramOracleConnection);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected abstract void flush() throws IOException;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   abstract void setByteOrder(byte paramByte) throws IOException;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   abstract void writeZeroCopyIO(byte[] paramArrayOfbyte, int paramInt1, int paramInt2) throws IOException, NetException;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   boolean readZeroCopyIO(byte[] paramArrayOfbyte, int paramInt, int[] paramArrayOfint) throws IOException, NetException {
/* 1894 */     return this.net.readZeroCopyIO(paramArrayOfbyte, paramInt, paramArrayOfint);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void setUseCLRBigChunks(boolean paramBoolean) {
/* 1902 */     this.useCLRBigChunks = paramBoolean;
/*      */     
/* 1904 */     if (paramBoolean == true) {
/*      */       
/* 1906 */       this.effectiveTTCC_MXIN = 32767;
/*      */     } else {
/*      */       assert false;
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1913 */       this.effectiveTTCC_MXIN = 64;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/* 1919 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*      */   public static final String BUILD_DATE = "Thu_Apr_04_15:09:24_PDT_2013";
/*      */   public static final boolean TRACE = false;
/*      */ }


/* Location:              C:\Users\olatu\OneDrive\Documents\Calypso\syncbase\sync_base.jar!\BOOT-INF\classes\ojdbc.jar!\oracle\jdbc\driver\T4CMAREngine.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */