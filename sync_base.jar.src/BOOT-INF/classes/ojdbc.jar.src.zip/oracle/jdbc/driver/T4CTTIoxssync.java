/*    */ package oracle.jdbc.driver;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.sql.SQLException;
/*    */ import oracle.jdbc.internal.OracleConnection;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class T4CTTIoxssync
/*    */   extends T4CTTIfun
/*    */ {
/*    */   T4CTTIoxssync(T4CConnection paramT4CConnection) {
/* 54 */     super(paramT4CConnection, (byte)17);
/* 55 */     setFunCode((short)176);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   void doOXSSYNC() throws IOException, SQLException {
/* 62 */     doPigRPC();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   void marshal() throws IOException {}
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected OracleConnection getConnectionDuringExceptionHandling() {
/* 81 */     return this.connection;
/*    */   }
/*    */ }


/* Location:              C:\Users\olatu\OneDrive\Documents\Calypso\syncbase\sync_base.jar!\BOOT-INF\classes\ojdbc.jar!\oracle\jdbc\driver\T4CTTIoxssync.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */