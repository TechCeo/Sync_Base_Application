/*     */ package oracle.jdbc.driver;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.sql.SQLException;
/*     */ import java.sql.SQLRecoverableException;
/*     */ import java.sql.SQLWarning;
/*     */ import java.util.Arrays;
/*     */ import oracle.jdbc.internal.OracleConnection;
/*     */ import oracle.net.ns.BreakNetException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ abstract class T4CTTIfun
/*     */   extends T4CTTIMsg
/*     */ {
/*     */   static final short OOPEN = 2;
/*     */   static final short OFETCH = 5;
/*     */   static final short OCLOSE = 8;
/*     */   static final short OLOGOFF = 9;
/*     */   static final short OCOMON = 12;
/*     */   static final short OCOMOFF = 13;
/*     */   static final short OCOMMIT = 14;
/*     */   static final short OROLLBACK = 15;
/*     */   static final short OCANCEL = 20;
/*     */   static final short ODSCRARR = 43;
/*     */   static final short OVERSION = 59;
/*     */   static final short OK2RPC = 67;
/*     */   static final short OALL7 = 71;
/*     */   static final short OSQL7 = 74;
/*     */   static final short O3LOGON = 81;
/*     */   static final short O3LOGA = 82;
/*     */   static final short OKOD = 92;
/*     */   static final short OALL8 = 94;
/*     */   static final short OLOBOPS = 96;
/*     */   static final short ODNY = 98;
/*     */   static final short OTXSE = 103;
/*     */   static final short OTXEN = 104;
/*     */   static final short OCCA = 105;
/*     */   static final short O80SES = 107;
/*     */   static final short OAUTH = 115;
/*     */   static final short OSESSKEY = 118;
/*     */   static final short OCANA = 120;
/*     */   static final short OKPN = 125;
/*     */   static final short OOTCM = 127;
/*     */   static final short OSCID = 135;
/*     */   static final short OSPFPPUT = 138;
/*     */   static final short OKPFC = 139;
/*     */   static final short OPING = 147;
/*     */   static final short OKEYVAL = 154;
/*     */   static final short OXSSCS = 155;
/*     */   static final short OXSSRO = 156;
/*     */   static final short OXSSPO = 157;
/*     */   static final short OAQEQ = 121;
/*     */   static final short OAQDQ = 122;
/*     */   static final short OAQGPS = 132;
/*     */   static final short OAQLS = 126;
/*     */   static final short OAQXQ = 145;
/*     */   static final short OSESSGET = 162;
/*     */   static final short OSESSRLS = 163;
/*     */   static final short OXSNSO = 172;
/*     */   static final short OXSNS = 178;
/*     */   static final short OXSSYNC = 176;
/*     */   static final short OXSATT = 180;
/*     */   static final short OXSCRE = 179;
/*     */   static final short OXSDET = 181;
/*     */   static final short OXSDES = 182;
/*     */   static final short OXSSET = 183;
/*     */   static final short OSESSSTATE = 176;
/*     */   static final short OAPPCONTREPLAY = 177;
/*     */   static final short OAQENQ = 184;
/*     */   static final short OAQDEQ = 185;
/*     */   static final short OAQEMNDEQ = 186;
/*     */   static final short OAQNFY = 187;
/*     */   private short funCode;
/*     */   protected final T4CTTIoer oer;
/*     */   int receiveState;
/*     */   static final int IDLE_RECEIVE_STATE = 0;
/*     */   static final int ACTIVE_RECEIVE_STATE = 1;
/*     */   static final int READROW_RECEIVE_STATE = 2;
/*     */   static final int STREAM_RECEIVE_STATE = 3;
/*     */   boolean rpaProcessed;
/*     */   boolean rxhProcessed;
/*     */   boolean iovProcessed;
/*     */   private final short[] ttiList;
/*     */   private int ttiListEnd;
/*     */   
/*     */   T4CTTIfun(T4CConnection paramT4CConnection, byte paramByte) {
/* 147 */     super(paramT4CConnection, paramByte);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 311 */     this.receiveState = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 323 */     this.rpaProcessed = false;
/* 324 */     this.rxhProcessed = false;
/* 325 */     this.iovProcessed = false;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 355 */     this.ttiListEnd = 0; this.oer = paramT4CConnection.getT4CTTIoer(); this.ttiList = paramT4CConnection.ttiList;
/*     */   } final void setFunCode(short paramShort) { this.funCode = paramShort; } final short getFunCode() { return this.funCode; } private final void marshalFunHeader() throws IOException { this.connection.setExecutingRPCFunctionCode(this.funCode); marshalTTCcode(); this.meg.marshalUB1(this.funCode);
/*     */     this.meg.marshalUB1((short)this.connection.getNextSeqNumber()); }
/*     */   abstract void marshal() throws IOException;
/* 359 */   private final String ttiListString() { String str = "[ ";
/* 360 */     for (byte b = 0; b < this.ttiListEnd; ) { str = str + this.ttiList[b] + ", "; b++; }
/* 361 */      str = str + "]";
/* 362 */     return str; }
/*     */   final void doRPC() throws IOException, SQLException { if (getTTCCode() == 17) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 401); sQLException.fillInStackTrace(); throw sQLException; }
/*     */      this.connection.sendPiggyBackedMessages(); for (byte b = 0; b < 5; b++) { init(); marshalFunHeader(); try { this.connection.pipeState = 1; marshal(); this.connection.pipeState = 2; receive(); break; }
/*     */       catch (SQLException sQLException) { synchronized (this.connection.cancelInProgressLockForThin) { if (sQLException.getErrorCode() == 1013 || (this.connection.cancelInProgressFlag && sQLException.getMessage() != null && sQLException.getMessage().contains("ORA-01013"))) { this.connection.cancelInProgressFlag = false; if (this.funCode == 15 || this.funCode == 12 || this.funCode == 13 || this.funCode == 14 || this.funCode == 59)
/*     */               if (this.oer.callNumber != this.connection.currentTTCSeqNumber || this.connection.statementCancel) { this.connection.pipeState = -1; continue; }
/*     */                 }
/*     */            }
/*     */          throw sQLException; }
/*     */       finally
/*     */       { this.connection.pipeState = -1; }
/*     */        }
/* 373 */      } private void receive() throws SQLException, IOException { ReplayContext replayContext = null;
/*     */ 
/*     */     
/* 376 */     this.receiveState = 1;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/* 383 */       SQLException sQLException = null; while (true) {
/*     */         
/*     */         try { byte b1; int i; byte[] arrayOfByte1; SQLException sQLException1; byte b2; int j; byte b3; byte[] arrayOfByte2; T4CTTIkvarr t4CTTIkvarr; LogicalTransactionId logicalTransactionId; int k; SQLException sQLException2; NTFLTXIDEvent nTFLTXIDEvent; byte b4;
/*     */           byte b5;
/*     */           long l1, l2;
/*     */           short s2;
/*     */           byte[] arrayOfByte3;
/* 390 */           short s1 = this.meg.unmarshalUB1();
/* 391 */           if (this.ttiListEnd < this.ttiList.length) this.ttiList[this.ttiListEnd++] = s1;
/*     */ 
/*     */           
/* 394 */           switch (s1)
/*     */           
/*     */           { 
/*     */             
/*     */             case 8:
/* 399 */               if (this.rpaProcessed) {
/*     */                 
/* 401 */                 SQLException sQLException3 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 401);
/* 402 */                 sQLException3.fillInStackTrace();
/* 403 */                 throw sQLException3;
/*     */               } 
/* 405 */               readRPA();
/*     */               try {
/* 407 */                 processRPA();
/* 408 */               } catch (SQLException sQLException3) {
/*     */ 
/*     */                 
/* 411 */                 sQLException = sQLException3;
/*     */               } 
/* 413 */               this.rpaProcessed = true;
/*     */               break;
/*     */ 
/*     */ 
/*     */             
/*     */             case 21:
/* 419 */               readBVC();
/*     */               break;
/*     */             
/*     */             case 11:
/* 423 */               readIOV();
/* 424 */               this.iovProcessed = true;
/*     */               break;
/*     */ 
/*     */             
/*     */             case 6:
/* 429 */               readRXH();
/* 430 */               this.rxhProcessed = true;
/*     */               break;
/*     */             case 12:
/* 433 */               processSLG();
/*     */               break;
/*     */ 
/*     */             
/*     */             case 7:
/* 438 */               this.receiveState = 2;
/*     */ 
/*     */               
/* 441 */               if (readRXD()) {
/*     */ 
/*     */ 
/*     */                 
/* 445 */                 this.receiveState = 3;
/*     */ 
/*     */                 
/*     */                 return;
/*     */               } 
/*     */ 
/*     */               
/* 452 */               this.receiveState = 1;
/*     */               break;
/*     */ 
/*     */ 
/*     */             
/*     */             case 16:
/* 458 */               readDCB();
/*     */               break;
/*     */             case 14:
/* 461 */               readLOBD();
/*     */               break;
/*     */ 
/*     */             
/*     */             case 23:
/* 466 */               b1 = (byte)this.meg.unmarshalUB1();
/* 467 */               switch (b1) {
/*     */                 
/*     */                 case 1:
/* 470 */                   i = this.meg.unmarshalUB2();
/* 471 */                   b2 = (byte)this.meg.unmarshalUB1();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */                   
/* 483 */                   for (b3 = 0; b3 < i; b3++) {
/* 484 */                     T4CTTIidc t4CTTIidc = new T4CTTIidc(this.connection);
/* 485 */                     t4CTTIidc.unmarshal();
/*     */                   } 
/*     */                   break;
/*     */ 
/*     */ 
/*     */                 
/*     */                 case 2:
/* 492 */                   i = this.meg.unmarshalUB2();
/* 493 */                   b2 = (byte)this.meg.unmarshalUB1();
/*     */                   
/* 495 */                   arrayOfByte2 = this.meg.unmarshalNBytes(i);
/*     */                   break;
/*     */ 
/*     */ 
/*     */                 
/*     */                 case 4:
/* 501 */                   this.connection.ocsessret.receive();
/*     */                   break;
/*     */ 
/*     */ 
/*     */                 
/*     */                 case 5:
/* 507 */                   i = this.meg.unmarshalUB2();
/* 508 */                   b2 = (byte)this.meg.unmarshalUB1();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */                   
/* 514 */                   t4CTTIkvarr = new T4CTTIkvarr(this.connection);
/* 515 */                   t4CTTIkvarr.unmarshal();
/*     */                   break;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */                 
/*     */                 case 7:
/* 528 */                   arrayOfByte1 = this.meg.unmarshalDALC();
/* 529 */                   j = Arrays.hashCode(arrayOfByte1);
/* 530 */                   if (this.connection.thinACLastLtxidHash == j) {
/*     */                     break;
/*     */                   }
/*     */ 
/*     */ 
/*     */                   
/* 536 */                   logicalTransactionId = new LogicalTransactionId(arrayOfByte1);
/*     */                   
/* 538 */                   this.connection.thinACCurrentLTXID = logicalTransactionId;
/* 539 */                   nTFLTXIDEvent = new NTFLTXIDEvent(this.connection, logicalTransactionId);
/* 540 */                   this.connection.notify(nTFLTXIDEvent);
/* 541 */                   this.connection.thinACLastLtxidHash = j;
/*     */                   break;
/*     */ 
/*     */ 
/*     */ 
/*     */                 
/*     */                 case 9:
/* 548 */                   k = this.meg.unmarshalUB2();
/* 549 */                   b4 = (byte)this.meg.unmarshalUB1();
/* 550 */                   for (b5 = 0; b5 < k; b5++) {
/* 551 */                     NTFXSEvent nTFXSEvent = new NTFXSEvent(this.connection);
/* 552 */                     this.connection.notify(nTFXSEvent);
/*     */                   } 
/*     */                   break;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */                 
/*     */                 case 8:
/* 585 */                   k = this.meg.unmarshalUB2();
/* 586 */                   b4 = (byte)this.meg.unmarshalUB1();
/* 587 */                   l1 = this.meg.unmarshalUB4();
/* 588 */                   l2 = this.meg.unmarshalUB4();
/* 589 */                   s2 = this.meg.unmarshalUB1();
/* 590 */                   arrayOfByte3 = this.meg.unmarshalDALC();
/* 591 */                   replayContext = new ReplayContext(l1, s2, arrayOfByte3, l2);
/*     */                   break;
/*     */               } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */               
/* 604 */               sQLException2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 401, ttiListString());
/* 605 */               sQLException2.fillInStackTrace();
/* 606 */               throw sQLException2;
/*     */ 
/*     */ 
/*     */ 
/*     */             
/*     */             case 19:
/* 612 */               this.meg.marshalUB1((short)19);
/*     */               break;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */             
/*     */             case 27:
/* 622 */               readIMPLRES();
/*     */               break;
/*     */ 
/*     */ 
/*     */             
/*     */             case 15:
/* 628 */               this.oer.init();
/* 629 */               this.oer.unmarshalWarning();
/*     */               
/*     */               try {
/* 632 */                 this.oer.processWarning();
/* 633 */               } catch (SQLWarning sQLWarning) {
/* 634 */                 this.connection.setWarnings(DatabaseError.addSqlWarning(this.connection.getWarnings(), sQLWarning));
/*     */               } 
/*     */               break;
/*     */             
/*     */             case 9:
/* 639 */               processEOCS();
/* 640 */               if (this.connection.getTTCVersion() >= 3) {
/* 641 */                 short s = (short)this.meg.unmarshalUB2();
/* 642 */                 this.connection.endToEndECIDSequenceNumber = s;
/*     */               } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */               
/* 678 */               this.connection.sentCancel = false; break;case 13: readOAC(); break;case 4: processEOCS(); this.oer.init(); this.oer.unmarshal(); try { processError(); } catch (SQLException sQLException3) { sQLException = sQLException3; }  this.connection.sentCancel = false; break;default: sQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 401, ttiListString()); sQLException1.fillInStackTrace(); throw sQLException1; }  } catch (BreakNetException breakNetException) {  } finally { this.connection.sentCancel = false; }
/*     */       
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 684 */       this.receiveState = 0;
/*     */       
/* 686 */       if (sQLException != null) {
/* 687 */         throw sQLException;
/*     */       }
/*     */     }
/* 690 */     catch (SQLRecoverableException sQLRecoverableException) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 702 */       throw sQLRecoverableException;
/* 703 */     } catch (IOException iOException) {
/*     */ 
/*     */       
/* 706 */       if (replayContext != null)
/* 707 */         handleReplayContext(replayContext); 
/* 708 */       throw iOException;
/* 709 */     } catch (SQLException sQLException) {
/* 710 */       if (replayContext != null) {
/* 711 */         handleReplayContext(replayContext);
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 717 */       this.connection.setExecutingRPCFunctionCode((short)0);
/* 718 */       this.connection.setExecutingRPCSQL((String)null);
/*     */       
/* 720 */       throw sQLException;
/*     */     } 
/* 722 */     if (replayContext != null) {
/* 723 */       handleReplayContext(replayContext);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 737 */     this.connection.setExecutingRPCFunctionCode((short)0);
/* 738 */     this.connection.setExecutingRPCSQL((String)null); }
/*     */   final void doPigRPC() throws IOException { init(); marshalFunHeader();
/*     */     marshal(); }
/*     */   final void doOneWayRPC() throws IOException, SQLException { this.connection.sendPiggyBackedMessages();
/*     */     init();
/*     */     marshalFunHeader();
/*     */     marshal();
/*     */     this.meg.flush(); }
/*     */   private void init() { this.rpaProcessed = false;
/*     */     this.rxhProcessed = false;
/*     */     this.iovProcessed = false;
/*     */     this.ttiListEnd = 0; }
/* 750 */   void resumeReceive() throws SQLException, IOException { receive(); } private final void handleReplayContext(ReplayContext paramReplayContext) { if (this.connection.replayModes.contains(T4CConnection.ReplayMode.NONREQUEST)) {
/*     */       return;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 759 */     assert (paramReplayContext.flags_kpdxcAppContCtl & 0x4L) != 0L || paramReplayContext.errcode_kpdxcAppContCtl != 41406L || !this.connection.replayModes.contains(T4CConnection.ReplayMode.RUNTIME_REPLAY_ENABLED) : "Server disabled replay with error " + paramReplayContext.errcode_kpdxcAppContCtl + " but our replayModes=" + this.connection.replayModes;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 768 */     assert paramReplayContext.replayctx_kpdxcAppContCtl == null || paramReplayContext.replayctx_kpdxcAppContCtl.length <= 0 || this.connection.getExecutingRPCFunctionCode() == 115 || this.connection.replayModes.contains(T4CConnection.ReplayMode.RUNTIME_REPLAY_ENABLED) : "Server is sending a non-null replay context but our replayModes=" + this.connection.replayModes;
/*     */     
/* 770 */     if (this.connection.thinACReplayContextReceived.length == this.connection.thinACReplayContextReceivedCurrent) {
/*     */       
/* 772 */       ReplayContext[] arrayOfReplayContext = new ReplayContext[this.connection.thinACReplayContextReceived.length * 2];
/* 773 */       System.arraycopy(this.connection.thinACReplayContextReceived, 0, arrayOfReplayContext, 0, this.connection.thinACReplayContextReceived.length);
/* 774 */       this.connection.thinACReplayContextReceived = arrayOfReplayContext;
/*     */     } 
/* 776 */     this.connection.thinACReplayContextReceived[this.connection.thinACReplayContextReceivedCurrent++] = paramReplayContext;
/*     */     
/* 778 */     if ((paramReplayContext.flags_kpdxcAppContCtl & 0x4L) == 0L) {
/*     */       
/* 780 */       this.connection.replayModes.remove(T4CConnection.ReplayMode.RUNTIME_REPLAY_ENABLED);
/* 781 */       this.connection.replayModes.remove(T4CConnection.ReplayMode.RUNTIME_OR_REPLAYING_STATIC);
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 788 */     if (paramReplayContext.replayctx_kpdxcAppContCtl != null && paramReplayContext.replayctx_kpdxcAppContCtl.length > 0 && (this.connection.getExecutingRPCFunctionCode() != 115 || !this.connection.ignoreReplayContextFromAuthentication))
/*     */     {
/*     */ 
/*     */       
/* 792 */       this.connection.thinACLastReplayContextReceived = paramReplayContext;
/*     */     } }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final void processEOCS() throws SQLException, IOException {
/* 803 */     if (this.connection.hasServerCompileTimeCapability(15, 1)) {
/*     */       
/* 805 */       int i = (int)this.meg.unmarshalUB4();
/* 806 */       this.connection.eocs = i;
/* 807 */       if ((i & 0x8) != 0)
/*     */       {
/*     */ 
/*     */         
/* 811 */         long l = this.meg.unmarshalSB8();
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void processRPA() throws SQLException {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void readOAC() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void readRPA() throws IOException, SQLException {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void readBVC() throws IOException, SQLException {
/* 849 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 401);
/* 850 */     sQLException.fillInStackTrace();
/* 851 */     throw sQLException;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void readLOBD() throws IOException, SQLException {
/* 860 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 401);
/* 861 */     sQLException.fillInStackTrace();
/* 862 */     throw sQLException;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void readIOV() throws IOException, SQLException {
/* 871 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 401);
/* 872 */     sQLException.fillInStackTrace();
/* 873 */     throw sQLException;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void readRXH() throws IOException, SQLException {
/* 882 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 401);
/* 883 */     sQLException.fillInStackTrace();
/* 884 */     throw sQLException;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean readRXD() throws IOException, SQLException {
/* 893 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 401);
/* 894 */     sQLException.fillInStackTrace();
/* 895 */     throw sQLException;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void readIMPLRES() throws IOException, SQLException {
/* 904 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 401);
/* 905 */     sQLException.fillInStackTrace();
/* 906 */     throw sQLException;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void readDCB() throws IOException, SQLException {
/* 915 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 401);
/* 916 */     sQLException.fillInStackTrace();
/* 917 */     throw sQLException;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void processSLG() throws IOException, SQLException {
/* 926 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 401);
/* 927 */     sQLException.fillInStackTrace();
/* 928 */     throw sQLException;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void processError() throws SQLException {
/* 938 */     this.oer.processError();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   final int getErrorCode() throws SQLException {
/* 945 */     return this.oer.retCode;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected OracleConnection getConnectionDuringExceptionHandling() {
/* 960 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/* 965 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*     */   public static final String BUILD_DATE = "Thu_Apr_04_15:09:24_PDT_2013";
/*     */   public static final boolean TRACE = false;
/*     */ }


/* Location:              C:\Users\olatu\OneDrive\Documents\Calypso\syncbase\sync_base.jar!\BOOT-INF\classes\ojdbc.jar!\oracle\jdbc\driver\T4CTTIfun.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */