/*     */ package oracle.jdbc.driver;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.Reader;
/*     */ import java.sql.SQLException;
/*     */ import oracle.jdbc.internal.OracleConnection;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class OracleConversionInputStream
/*     */   extends OracleBufferedStream
/*     */ {
/*     */   static final int CHUNK_SIZE = 32768;
/*     */   DBConversion converter;
/*     */   int conversion;
/*     */   InputStream istream;
/*     */   Reader reader;
/*     */   byte[] convbuf;
/*     */   char[] javaChars;
/*     */   int maxSize;
/*     */   int totalSize;
/*     */   int numUnconvertedBytes;
/*     */   boolean endOfStream;
/*     */   private short csform;
/*     */   int[] nbytes;
/*     */   
/*     */   public OracleConversionInputStream(DBConversion paramDBConversion, InputStream paramInputStream, int paramInt) {
/*  50 */     this(paramDBConversion, paramInputStream, paramInt, (short)1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public OracleConversionInputStream(DBConversion paramDBConversion, InputStream paramInputStream, int paramInt, short paramShort) {
/*  60 */     super(32768);
/*     */     int i;
/*  62 */     this.istream = paramInputStream;
/*  63 */     this.conversion = paramInt;
/*  64 */     this.converter = paramDBConversion;
/*  65 */     this.maxSize = 0;
/*  66 */     this.totalSize = 0;
/*  67 */     this.numUnconvertedBytes = 0;
/*  68 */     this.endOfStream = false;
/*  69 */     this.nbytes = new int[1];
/*  70 */     this.csform = paramShort;
/*  71 */     this.currentBufferSize = this.initialBufferSize;
/*  72 */     this.resizableBuffer = new byte[this.currentBufferSize];
/*     */     
/*  74 */     switch (paramInt) {
/*     */ 
/*     */ 
/*     */       
/*     */       case 0:
/*  79 */         this.javaChars = new char[32768];
/*  80 */         this.convbuf = new byte[32768];
/*     */         return;
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       case 1:
/*  87 */         this.convbuf = new byte[16384];
/*  88 */         this.javaChars = new char[16384];
/*     */         return;
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       case 2:
/*  95 */         this.convbuf = new byte[16384];
/*  96 */         this.javaChars = new char[32768];
/*     */         return;
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       case 3:
/* 103 */         this.convbuf = new byte[8192];
/* 104 */         this.javaChars = new char[16384];
/*     */         return;
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       case 4:
/* 111 */         i = 32768 / this.converter.getMaxCharbyteSize();
/*     */         
/* 113 */         this.convbuf = new byte[i * 2];
/* 114 */         this.javaChars = new char[i];
/*     */         return;
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       case 5:
/* 121 */         if (this.converter.isUcs2CharSet()) {
/*     */           
/* 123 */           this.convbuf = new byte[16384];
/* 124 */           this.javaChars = new char[16384];
/*     */         }
/*     */         else {
/*     */           
/* 128 */           this.convbuf = new byte[32768];
/* 129 */           this.javaChars = new char[32768];
/*     */         } 
/*     */         return;
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       case 7:
/* 137 */         i = 32768 / ((paramShort == 2) ? this.converter.getMaxNCharbyteSize() : this.converter.getMaxCharbyteSize());
/*     */         
/* 139 */         this.javaChars = new char[i];
/*     */         return;
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 146 */     this.convbuf = new byte[32768];
/* 147 */     this.javaChars = new char[32768];
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public OracleConversionInputStream(DBConversion paramDBConversion, InputStream paramInputStream, int paramInt1, int paramInt2) {
/* 158 */     this(paramDBConversion, paramInputStream, paramInt1, (short)1);
/*     */     
/* 160 */     this.maxSize = paramInt2;
/* 161 */     this.totalSize = 0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public OracleConversionInputStream(DBConversion paramDBConversion, Reader paramReader, int paramInt1, int paramInt2, short paramShort) {
/* 170 */     this(paramDBConversion, (InputStream)null, paramInt1, paramShort);
/*     */     
/* 172 */     this.reader = paramReader;
/* 173 */     this.maxSize = paramInt2;
/* 174 */     this.totalSize = 0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setFormOfUse(short paramShort) {
/* 182 */     this.csform = paramShort;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean needBytes(int paramInt) throws IOException {
/* 189 */     return needBytes();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean needBytes() throws IOException {
/* 199 */     if (this.closed) {
/* 200 */       return false;
/*     */     }
/*     */ 
/*     */     
/* 204 */     if (this.pos < this.count) {
/* 205 */       return true;
/*     */     }
/* 207 */     if (this.istream != null)
/*     */     {
/* 209 */       return needBytesFromStream();
/*     */     }
/* 211 */     if (this.reader != null)
/*     */     {
/* 213 */       return needBytesFromReader();
/*     */     }
/*     */     
/* 216 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean needBytesFromReader() throws IOException {
/*     */     
/* 226 */     try { int i = 0;
/*     */       
/* 228 */       if (this.maxSize == 0) {
/*     */         
/* 230 */         i = this.javaChars.length;
/*     */       }
/*     */       else {
/*     */         
/* 234 */         i = Math.min(this.maxSize - this.totalSize, this.javaChars.length);
/*     */       } 
/*     */       
/* 237 */       if (i <= 0)
/*     */       {
/* 239 */         return false;
/*     */       }
/*     */       
/* 242 */       int j = this.reader.read(this.javaChars, 0, i);
/*     */       
/* 244 */       if (j == -1)
/*     */       {
/* 246 */         return false;
/*     */       }
/*     */ 
/*     */       
/* 250 */       this.totalSize += j;
/*     */ 
/*     */ 
/*     */       
/* 254 */       switch (this.conversion)
/*     */       
/*     */       { 
/*     */         
/*     */         case 7:
/* 259 */           if (this.csform == 2) {
/* 260 */             this.count = this.converter.javaCharsToNCHARBytes(this.javaChars, j, this.resizableBuffer);
/*     */           } else {
/* 262 */             this.count = this.converter.javaCharsToCHARBytes(this.javaChars, j, this.resizableBuffer);
/*     */           } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 285 */           this.pos = 0;
/*     */ 
/*     */           
/* 288 */           return true; }  System.arraycopy(this.convbuf, 0, this.resizableBuffer, 0, j); this.count = j; } catch (SQLException sQLException) { IOException iOException = DatabaseError.createIOException(sQLException); iOException.fillInStackTrace(); throw iOException; }  this.pos = 0; return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean needBytesFromStream() throws IOException {
/* 296 */     if (!this.endOfStream) {
/*     */       
/*     */       try { int k;
/*     */         byte b;
/* 300 */         int i = 0;
/*     */         
/* 302 */         if (this.maxSize == 0) {
/*     */           
/* 304 */           i = this.convbuf.length;
/*     */         }
/*     */         else {
/*     */           
/* 308 */           i = Math.min(this.maxSize - this.totalSize, this.convbuf.length);
/*     */         } 
/*     */         
/* 311 */         int j = 0;
/*     */         
/* 313 */         if (i <= 0) {
/*     */ 
/*     */ 
/*     */           
/* 317 */           this.endOfStream = true;
/*     */           
/* 319 */           this.istream.close();
/*     */           
/* 321 */           if (this.numUnconvertedBytes != 0)
/*     */           {
/* 323 */             SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 55);
/* 324 */             sQLException.fillInStackTrace();
/* 325 */             throw sQLException;
/*     */           
/*     */           }
/*     */         
/*     */         }
/*     */         else {
/*     */           
/* 332 */           j = this.istream.read(this.convbuf, this.numUnconvertedBytes, i - this.numUnconvertedBytes);
/*     */         } 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 338 */         if (j == -1) {
/*     */ 
/*     */ 
/*     */           
/* 342 */           this.endOfStream = true;
/*     */           
/* 344 */           this.istream.close();
/*     */           
/* 346 */           if (this.numUnconvertedBytes != 0)
/*     */           {
/* 348 */             SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 55);
/* 349 */             sQLException.fillInStackTrace();
/* 350 */             throw sQLException;
/*     */           }
/*     */         
/*     */         } else {
/*     */           
/* 355 */           j += this.numUnconvertedBytes;
/* 356 */           this.totalSize += j;
/*     */         } 
/*     */         
/* 359 */         if (j <= 0)
/*     */         {
/* 361 */           return false;
/*     */         }
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 367 */         switch (this.conversion)
/*     */         
/*     */         { 
/*     */ 
/*     */ 
/*     */           
/*     */           case 0:
/* 374 */             this.nbytes[0] = j;
/*     */             
/* 376 */             k = this.converter.CHARBytesToJavaChars(this.convbuf, 0, this.javaChars, 0, this.nbytes, this.javaChars.length);
/*     */ 
/*     */ 
/*     */ 
/*     */             
/* 381 */             this.numUnconvertedBytes = this.nbytes[0];
/*     */             
/* 383 */             for (b = 0; b < this.numUnconvertedBytes; b++) {
/* 384 */               this.convbuf[b] = this.convbuf[j - this.numUnconvertedBytes];
/*     */             }
/*     */             
/* 387 */             this.count = DBConversion.javaCharsToAsciiBytes(this.javaChars, k, this.resizableBuffer);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */             
/* 500 */             this.pos = 0;
/*     */ 
/*     */             
/* 503 */             return true;case 1: this.nbytes[0] = j; k = this.converter.CHARBytesToJavaChars(this.convbuf, 0, this.javaChars, 0, this.nbytes, this.javaChars.length); this.numUnconvertedBytes = this.nbytes[0]; for (b = 0; b < this.numUnconvertedBytes; b++) this.convbuf[b] = this.convbuf[j - this.numUnconvertedBytes];  this.count = DBConversion.javaCharsToUcs2Bytes(this.javaChars, k, this.resizableBuffer); this.pos = 0; return true;case 2: k = DBConversion.RAWBytesToHexChars(this.convbuf, j, this.javaChars); this.count = DBConversion.javaCharsToAsciiBytes(this.javaChars, k, this.resizableBuffer); this.pos = 0; return true;case 3: k = DBConversion.RAWBytesToHexChars(this.convbuf, j, this.javaChars); this.count = DBConversion.javaCharsToUcs2Bytes(this.javaChars, k, this.resizableBuffer); this.pos = 0; return true;case 4: k = DBConversion.ucs2BytesToJavaChars(this.convbuf, j, this.javaChars); this.count = this.converter.javaCharsToCHARBytes(this.javaChars, k, this.resizableBuffer); this.pos = 0; return true;case 12: k = DBConversion.ucs2BytesToJavaChars(this.convbuf, j, this.javaChars); this.count = DBConversion.javaCharsToAsciiBytes(this.javaChars, k, this.resizableBuffer); this.pos = 0; return true;case 5: DBConversion.asciiBytesToJavaChars(this.convbuf, j, this.javaChars); this.count = this.converter.javaCharsToCHARBytes(this.javaChars, j, this.resizableBuffer); this.pos = 0; return true; }  System.arraycopy(this.convbuf, 0, this.resizableBuffer, 0, j); this.count = j; } catch (SQLException sQLException) { IOException iOException = DatabaseError.createIOException(sQLException); iOException.fillInStackTrace(); throw iOException; }  this.pos = 0; return true;
/*     */     } 
/*     */     
/* 506 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected OracleConnection getConnectionDuringExceptionHandling() {
/* 521 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/* 526 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*     */   public static final String BUILD_DATE = "Thu_Apr_04_15:09:24_PDT_2013";
/*     */   public static final boolean TRACE = false;
/*     */ }


/* Location:              C:\Users\olatu\OneDrive\Documents\Calypso\syncbase\sync_base.jar!\BOOT-INF\classes\ojdbc.jar!\oracle\jdbc\driver\OracleConversionInputStream.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */