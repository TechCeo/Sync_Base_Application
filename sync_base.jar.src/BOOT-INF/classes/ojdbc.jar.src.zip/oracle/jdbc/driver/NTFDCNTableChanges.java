/*     */ package oracle.jdbc.driver;
/*     */ 
/*     */ import java.nio.ByteBuffer;
/*     */ import java.util.EnumSet;
/*     */ import oracle.jdbc.dcn.RowChangeDescription;
/*     */ import oracle.jdbc.dcn.TableChangeDescription;
/*     */ import oracle.sql.CharacterSet;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class NTFDCNTableChanges
/*     */   implements TableChangeDescription
/*     */ {
/*     */   final EnumSet<TableChangeDescription.TableOperation> opcode;
/*     */   String tableName;
/*     */   final int objectNumber;
/*     */   final int numberOfRows;
/*     */   final RowChangeDescription.RowOperation[] rowOpcode;
/*     */   final int[] rowIdLength;
/*     */   final byte[][] rowid;
/*     */   final CharacterSet charset;
/*  43 */   NTFDCNRowChanges[] rowsDescription = null;
/*     */   
/*     */   private static final byte OPERATION_ANY = 0;
/*     */   
/*     */   private static final byte OPERATION_UNKNOWN = 64;
/*     */ 
/*     */   
/*     */   NTFDCNTableChanges(ByteBuffer paramByteBuffer, int paramInt) {
/*  51 */     this.charset = CharacterSet.make(paramInt);
/*  52 */     this.opcode = TableChangeDescription.TableOperation.getTableOperations(paramByteBuffer.getInt());
/*  53 */     short s = paramByteBuffer.getShort();
/*  54 */     byte[] arrayOfByte = new byte[s];
/*  55 */     paramByteBuffer.get(arrayOfByte, 0, s);
/*  56 */     this.tableName = this.charset.toStringWithReplacement(arrayOfByte, 0, s);
/*     */ 
/*     */     
/*  59 */     this.objectNumber = paramByteBuffer.getInt();
/*  60 */     if (!this.opcode.contains(TableChangeDescription.TableOperation.ALL_ROWS)) {
/*     */       
/*  62 */       this.numberOfRows = paramByteBuffer.getShort();
/*  63 */       this.rowOpcode = new RowChangeDescription.RowOperation[this.numberOfRows];
/*  64 */       this.rowIdLength = new int[this.numberOfRows];
/*  65 */       this.rowid = new byte[this.numberOfRows][];
/*  66 */       for (byte b = 0; b < this.numberOfRows; b++)
/*     */       {
/*  68 */         this.rowOpcode[b] = RowChangeDescription.RowOperation.getRowOperation(paramByteBuffer.getInt());
/*  69 */         this.rowIdLength[b] = paramByteBuffer.getShort();
/*  70 */         this.rowid[b] = new byte[this.rowIdLength[b]];
/*  71 */         paramByteBuffer.get(this.rowid[b], 0, this.rowIdLength[b]);
/*     */       }
/*     */     
/*     */     } else {
/*     */       
/*  76 */       this.numberOfRows = 0;
/*  77 */       this.rowid = (byte[][])null;
/*  78 */       this.rowOpcode = null;
/*  79 */       this.rowIdLength = null;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getTableName() {
/*  87 */     return this.tableName;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int getObjectNumber() {
/*  93 */     return this.objectNumber;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public RowChangeDescription[] getRowChangeDescription() {
/*  99 */     if (this.rowsDescription == null)
/*     */     {
/* 101 */       synchronized (this) {
/*     */         
/* 103 */         if (this.rowsDescription == null) {
/*     */           
/* 105 */           this.rowsDescription = new NTFDCNRowChanges[this.numberOfRows];
/* 106 */           for (byte b = 0; b < this.rowsDescription.length; b++)
/* 107 */             this.rowsDescription[b] = new NTFDCNRowChanges(this.rowOpcode[b], this.rowIdLength[b], this.rowid[b]); 
/*     */         } 
/*     */       } 
/*     */     }
/* 111 */     return (RowChangeDescription[])this.rowsDescription;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public EnumSet<TableChangeDescription.TableOperation> getTableOperations() {
/* 117 */     return this.opcode;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 128 */     StringBuffer stringBuffer = new StringBuffer();
/* 129 */     stringBuffer.append("    operation=" + getTableOperations() + ", tableName=" + this.tableName + ", objectNumber=" + this.objectNumber + "\n");
/* 130 */     RowChangeDescription[] arrayOfRowChangeDescription = getRowChangeDescription();
/* 131 */     if (arrayOfRowChangeDescription != null && arrayOfRowChangeDescription.length > 0) {
/*     */       
/* 133 */       stringBuffer.append("    Row Change Description (length=" + arrayOfRowChangeDescription.length + "):\n");
/* 134 */       for (byte b = 0; b < arrayOfRowChangeDescription.length; b++)
/* 135 */         stringBuffer.append(arrayOfRowChangeDescription[b].toString()); 
/*     */     } 
/* 137 */     return stringBuffer.toString();
/*     */   }
/*     */ 
/*     */   
/* 141 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*     */   public static final String BUILD_DATE = "Thu_Apr_04_15:09:24_PDT_2013";
/*     */   public static final boolean TRACE = false;
/*     */ }


/* Location:              C:\Users\olatu\OneDrive\Documents\Calypso\syncbase\sync_base.jar!\BOOT-INF\classes\ojdbc.jar!\oracle\jdbc\driver\NTFDCNTableChanges.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */