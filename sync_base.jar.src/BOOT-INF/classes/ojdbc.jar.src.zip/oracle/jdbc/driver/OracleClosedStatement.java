/*      */ package oracle.jdbc.driver;
/*      */ 
/*      */ import java.io.InputStream;
/*      */ import java.io.Reader;
/*      */ import java.math.BigDecimal;
/*      */ import java.net.URL;
/*      */ import java.sql.Array;
/*      */ import java.sql.Blob;
/*      */ import java.sql.Clob;
/*      */ import java.sql.Connection;
/*      */ import java.sql.Date;
/*      */ import java.sql.NClob;
/*      */ import java.sql.ParameterMetaData;
/*      */ import java.sql.Ref;
/*      */ import java.sql.ResultSet;
/*      */ import java.sql.ResultSetMetaData;
/*      */ import java.sql.RowId;
/*      */ import java.sql.SQLException;
/*      */ import java.sql.SQLWarning;
/*      */ import java.sql.SQLXML;
/*      */ import java.sql.Time;
/*      */ import java.sql.Timestamp;
/*      */ import java.util.Calendar;
/*      */ import java.util.Map;
/*      */ import oracle.jdbc.OracleDataFactory;
/*      */ import oracle.jdbc.OracleParameterMetaData;
/*      */ import oracle.jdbc.dcn.DatabaseChangeRegistration;
/*      */ import oracle.jdbc.internal.OracleCallableStatement;
/*      */ import oracle.jdbc.internal.OracleConnection;
/*      */ import oracle.jdbc.internal.OracleStatement;
/*      */ import oracle.sql.ARRAY;
/*      */ import oracle.sql.BFILE;
/*      */ import oracle.sql.BINARY_DOUBLE;
/*      */ import oracle.sql.BINARY_FLOAT;
/*      */ import oracle.sql.BLOB;
/*      */ import oracle.sql.CHAR;
/*      */ import oracle.sql.CLOB;
/*      */ import oracle.sql.CustomDatum;
/*      */ import oracle.sql.CustomDatumFactory;
/*      */ import oracle.sql.DATE;
/*      */ import oracle.sql.Datum;
/*      */ import oracle.sql.INTERVALDS;
/*      */ import oracle.sql.INTERVALYM;
/*      */ import oracle.sql.NUMBER;
/*      */ import oracle.sql.OPAQUE;
/*      */ import oracle.sql.ORAData;
/*      */ import oracle.sql.ORADataFactory;
/*      */ import oracle.sql.RAW;
/*      */ import oracle.sql.REF;
/*      */ import oracle.sql.ROWID;
/*      */ import oracle.sql.STRUCT;
/*      */ import oracle.sql.StructDescriptor;
/*      */ import oracle.sql.TIMESTAMP;
/*      */ import oracle.sql.TIMESTAMPLTZ;
/*      */ import oracle.sql.TIMESTAMPTZ;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ class OracleClosedStatement
/*      */   implements OracleCallableStatement, Wrappable<OracleStatementWrapper>
/*      */ {
/*      */   Object acProxy;
/*      */   
/*      */   public void setWrapper(OracleStatementWrapper paramOracleStatementWrapper) {}
/*      */   
/*      */   public void setArray(int paramInt, Array paramArray) throws SQLException {
/*   79 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*   80 */     sQLException.fillInStackTrace();
/*   81 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setArrayAtName(String paramString, Array paramArray) throws SQLException {
/*   89 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*   90 */     sQLException.fillInStackTrace();
/*   91 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setArray(String paramString, Array paramArray) throws SQLException {
/*   99 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  100 */     sQLException.fillInStackTrace();
/*  101 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBigDecimal(int paramInt, BigDecimal paramBigDecimal) throws SQLException {
/*  110 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  111 */     sQLException.fillInStackTrace();
/*  112 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBigDecimalAtName(String paramString, BigDecimal paramBigDecimal) throws SQLException {
/*  120 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  121 */     sQLException.fillInStackTrace();
/*  122 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBigDecimal(String paramString, BigDecimal paramBigDecimal) throws SQLException {
/*  130 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  131 */     sQLException.fillInStackTrace();
/*  132 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBlob(int paramInt, Blob paramBlob) throws SQLException {
/*  141 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  142 */     sQLException.fillInStackTrace();
/*  143 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBlobAtName(String paramString, Blob paramBlob) throws SQLException {
/*  151 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  152 */     sQLException.fillInStackTrace();
/*  153 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBlob(String paramString, Blob paramBlob) throws SQLException {
/*  161 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  162 */     sQLException.fillInStackTrace();
/*  163 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBoolean(int paramInt, boolean paramBoolean) throws SQLException {
/*  172 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  173 */     sQLException.fillInStackTrace();
/*  174 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBooleanAtName(String paramString, boolean paramBoolean) throws SQLException {
/*  182 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  183 */     sQLException.fillInStackTrace();
/*  184 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBoolean(String paramString, boolean paramBoolean) throws SQLException {
/*  192 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  193 */     sQLException.fillInStackTrace();
/*  194 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setByte(int paramInt, byte paramByte) throws SQLException {
/*  203 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  204 */     sQLException.fillInStackTrace();
/*  205 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setByteAtName(String paramString, byte paramByte) throws SQLException {
/*  213 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  214 */     sQLException.fillInStackTrace();
/*  215 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setByte(String paramString, byte paramByte) throws SQLException {
/*  223 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  224 */     sQLException.fillInStackTrace();
/*  225 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBytes(int paramInt, byte[] paramArrayOfbyte) throws SQLException {
/*  234 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  235 */     sQLException.fillInStackTrace();
/*  236 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBytesAtName(String paramString, byte[] paramArrayOfbyte) throws SQLException {
/*  244 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  245 */     sQLException.fillInStackTrace();
/*  246 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBytes(String paramString, byte[] paramArrayOfbyte) throws SQLException {
/*  254 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  255 */     sQLException.fillInStackTrace();
/*  256 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setClob(int paramInt, Clob paramClob) throws SQLException {
/*  265 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  266 */     sQLException.fillInStackTrace();
/*  267 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setClobAtName(String paramString, Clob paramClob) throws SQLException {
/*  275 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  276 */     sQLException.fillInStackTrace();
/*  277 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setClob(String paramString, Clob paramClob) throws SQLException {
/*  285 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  286 */     sQLException.fillInStackTrace();
/*  287 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setDate(int paramInt, Date paramDate) throws SQLException {
/*  296 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  297 */     sQLException.fillInStackTrace();
/*  298 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setDateAtName(String paramString, Date paramDate) throws SQLException {
/*  306 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  307 */     sQLException.fillInStackTrace();
/*  308 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setDate(String paramString, Date paramDate) throws SQLException {
/*  316 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  317 */     sQLException.fillInStackTrace();
/*  318 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setDate(int paramInt, Date paramDate, Calendar paramCalendar) throws SQLException {
/*  327 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  328 */     sQLException.fillInStackTrace();
/*  329 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setDateAtName(String paramString, Date paramDate, Calendar paramCalendar) throws SQLException {
/*  337 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  338 */     sQLException.fillInStackTrace();
/*  339 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setDate(String paramString, Date paramDate, Calendar paramCalendar) throws SQLException {
/*  347 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  348 */     sQLException.fillInStackTrace();
/*  349 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setDouble(int paramInt, double paramDouble) throws SQLException {
/*  358 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  359 */     sQLException.fillInStackTrace();
/*  360 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setDoubleAtName(String paramString, double paramDouble) throws SQLException {
/*  368 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  369 */     sQLException.fillInStackTrace();
/*  370 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setDouble(String paramString, double paramDouble) throws SQLException {
/*  378 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  379 */     sQLException.fillInStackTrace();
/*  380 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setFloat(int paramInt, float paramFloat) throws SQLException {
/*  389 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  390 */     sQLException.fillInStackTrace();
/*  391 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setFloatAtName(String paramString, float paramFloat) throws SQLException {
/*  399 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  400 */     sQLException.fillInStackTrace();
/*  401 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setFloat(String paramString, float paramFloat) throws SQLException {
/*  409 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  410 */     sQLException.fillInStackTrace();
/*  411 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setInt(int paramInt1, int paramInt2) throws SQLException {
/*  420 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  421 */     sQLException.fillInStackTrace();
/*  422 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setIntAtName(String paramString, int paramInt) throws SQLException {
/*  430 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  431 */     sQLException.fillInStackTrace();
/*  432 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setInt(String paramString, int paramInt) throws SQLException {
/*  440 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  441 */     sQLException.fillInStackTrace();
/*  442 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setLong(int paramInt, long paramLong) throws SQLException {
/*  451 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  452 */     sQLException.fillInStackTrace();
/*  453 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setLongAtName(String paramString, long paramLong) throws SQLException {
/*  461 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  462 */     sQLException.fillInStackTrace();
/*  463 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setLong(String paramString, long paramLong) throws SQLException {
/*  471 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  472 */     sQLException.fillInStackTrace();
/*  473 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setNClob(int paramInt, NClob paramNClob) throws SQLException {
/*  482 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  483 */     sQLException.fillInStackTrace();
/*  484 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setNClobAtName(String paramString, NClob paramNClob) throws SQLException {
/*  492 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  493 */     sQLException.fillInStackTrace();
/*  494 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setNClob(String paramString, NClob paramNClob) throws SQLException {
/*  502 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  503 */     sQLException.fillInStackTrace();
/*  504 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setNString(int paramInt, String paramString) throws SQLException {
/*  513 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  514 */     sQLException.fillInStackTrace();
/*  515 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setNStringAtName(String paramString1, String paramString2) throws SQLException {
/*  523 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  524 */     sQLException.fillInStackTrace();
/*  525 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setNString(String paramString1, String paramString2) throws SQLException {
/*  533 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  534 */     sQLException.fillInStackTrace();
/*  535 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setObject(int paramInt, Object paramObject) throws SQLException {
/*  544 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  545 */     sQLException.fillInStackTrace();
/*  546 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setObjectAtName(String paramString, Object paramObject) throws SQLException {
/*  554 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  555 */     sQLException.fillInStackTrace();
/*  556 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setObject(String paramString, Object paramObject) throws SQLException {
/*  564 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  565 */     sQLException.fillInStackTrace();
/*  566 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setObject(int paramInt1, Object paramObject, int paramInt2) throws SQLException {
/*  575 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  576 */     sQLException.fillInStackTrace();
/*  577 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setObjectAtName(String paramString, Object paramObject, int paramInt) throws SQLException {
/*  585 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  586 */     sQLException.fillInStackTrace();
/*  587 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setObject(String paramString, Object paramObject, int paramInt) throws SQLException {
/*  595 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  596 */     sQLException.fillInStackTrace();
/*  597 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setRef(int paramInt, Ref paramRef) throws SQLException {
/*  606 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  607 */     sQLException.fillInStackTrace();
/*  608 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setRefAtName(String paramString, Ref paramRef) throws SQLException {
/*  616 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  617 */     sQLException.fillInStackTrace();
/*  618 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setRef(String paramString, Ref paramRef) throws SQLException {
/*  626 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  627 */     sQLException.fillInStackTrace();
/*  628 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setRowId(int paramInt, RowId paramRowId) throws SQLException {
/*  637 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  638 */     sQLException.fillInStackTrace();
/*  639 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setRowIdAtName(String paramString, RowId paramRowId) throws SQLException {
/*  647 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  648 */     sQLException.fillInStackTrace();
/*  649 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setRowId(String paramString, RowId paramRowId) throws SQLException {
/*  657 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  658 */     sQLException.fillInStackTrace();
/*  659 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setShort(int paramInt, short paramShort) throws SQLException {
/*  668 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  669 */     sQLException.fillInStackTrace();
/*  670 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setShortAtName(String paramString, short paramShort) throws SQLException {
/*  678 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  679 */     sQLException.fillInStackTrace();
/*  680 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setShort(String paramString, short paramShort) throws SQLException {
/*  688 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  689 */     sQLException.fillInStackTrace();
/*  690 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setSQLXML(int paramInt, SQLXML paramSQLXML) throws SQLException {
/*  699 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  700 */     sQLException.fillInStackTrace();
/*  701 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setSQLXMLAtName(String paramString, SQLXML paramSQLXML) throws SQLException {
/*  709 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  710 */     sQLException.fillInStackTrace();
/*  711 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setSQLXML(String paramString, SQLXML paramSQLXML) throws SQLException {
/*  719 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  720 */     sQLException.fillInStackTrace();
/*  721 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setString(int paramInt, String paramString) throws SQLException {
/*  730 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  731 */     sQLException.fillInStackTrace();
/*  732 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setStringAtName(String paramString1, String paramString2) throws SQLException {
/*  740 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  741 */     sQLException.fillInStackTrace();
/*  742 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setString(String paramString1, String paramString2) throws SQLException {
/*  750 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  751 */     sQLException.fillInStackTrace();
/*  752 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setTime(int paramInt, Time paramTime) throws SQLException {
/*  761 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  762 */     sQLException.fillInStackTrace();
/*  763 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setTimeAtName(String paramString, Time paramTime) throws SQLException {
/*  771 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  772 */     sQLException.fillInStackTrace();
/*  773 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setTime(String paramString, Time paramTime) throws SQLException {
/*  781 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  782 */     sQLException.fillInStackTrace();
/*  783 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setTime(int paramInt, Time paramTime, Calendar paramCalendar) throws SQLException {
/*  792 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  793 */     sQLException.fillInStackTrace();
/*  794 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setTimeAtName(String paramString, Time paramTime, Calendar paramCalendar) throws SQLException {
/*  802 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  803 */     sQLException.fillInStackTrace();
/*  804 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setTime(String paramString, Time paramTime, Calendar paramCalendar) throws SQLException {
/*  812 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  813 */     sQLException.fillInStackTrace();
/*  814 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setTimestamp(int paramInt, Timestamp paramTimestamp) throws SQLException {
/*  823 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  824 */     sQLException.fillInStackTrace();
/*  825 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setTimestampAtName(String paramString, Timestamp paramTimestamp) throws SQLException {
/*  833 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  834 */     sQLException.fillInStackTrace();
/*  835 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setTimestamp(String paramString, Timestamp paramTimestamp) throws SQLException {
/*  843 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  844 */     sQLException.fillInStackTrace();
/*  845 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setTimestamp(int paramInt, Timestamp paramTimestamp, Calendar paramCalendar) throws SQLException {
/*  854 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  855 */     sQLException.fillInStackTrace();
/*  856 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setTimestampAtName(String paramString, Timestamp paramTimestamp, Calendar paramCalendar) throws SQLException {
/*  864 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  865 */     sQLException.fillInStackTrace();
/*  866 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setTimestamp(String paramString, Timestamp paramTimestamp, Calendar paramCalendar) throws SQLException {
/*  874 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  875 */     sQLException.fillInStackTrace();
/*  876 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setURL(int paramInt, URL paramURL) throws SQLException {
/*  885 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  886 */     sQLException.fillInStackTrace();
/*  887 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setURLAtName(String paramString, URL paramURL) throws SQLException {
/*  895 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  896 */     sQLException.fillInStackTrace();
/*  897 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setURL(String paramString, URL paramURL) throws SQLException {
/*  905 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  906 */     sQLException.fillInStackTrace();
/*  907 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setARRAY(int paramInt, ARRAY paramARRAY) throws SQLException {
/*  916 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  917 */     sQLException.fillInStackTrace();
/*  918 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setARRAYAtName(String paramString, ARRAY paramARRAY) throws SQLException {
/*  926 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  927 */     sQLException.fillInStackTrace();
/*  928 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setARRAY(String paramString, ARRAY paramARRAY) throws SQLException {
/*  936 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  937 */     sQLException.fillInStackTrace();
/*  938 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBFILE(int paramInt, BFILE paramBFILE) throws SQLException {
/*  947 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  948 */     sQLException.fillInStackTrace();
/*  949 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBFILEAtName(String paramString, BFILE paramBFILE) throws SQLException {
/*  957 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  958 */     sQLException.fillInStackTrace();
/*  959 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBFILE(String paramString, BFILE paramBFILE) throws SQLException {
/*  967 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  968 */     sQLException.fillInStackTrace();
/*  969 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBfile(int paramInt, BFILE paramBFILE) throws SQLException {
/*  978 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  979 */     sQLException.fillInStackTrace();
/*  980 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBfileAtName(String paramString, BFILE paramBFILE) throws SQLException {
/*  988 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  989 */     sQLException.fillInStackTrace();
/*  990 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBfile(String paramString, BFILE paramBFILE) throws SQLException {
/*  998 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  999 */     sQLException.fillInStackTrace();
/* 1000 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBinaryFloat(int paramInt, float paramFloat) throws SQLException {
/* 1009 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 1010 */     sQLException.fillInStackTrace();
/* 1011 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBinaryFloatAtName(String paramString, float paramFloat) throws SQLException {
/* 1019 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 1020 */     sQLException.fillInStackTrace();
/* 1021 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBinaryFloat(String paramString, float paramFloat) throws SQLException {
/* 1029 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 1030 */     sQLException.fillInStackTrace();
/* 1031 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBinaryFloat(int paramInt, BINARY_FLOAT paramBINARY_FLOAT) throws SQLException {
/* 1040 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 1041 */     sQLException.fillInStackTrace();
/* 1042 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBinaryFloatAtName(String paramString, BINARY_FLOAT paramBINARY_FLOAT) throws SQLException {
/* 1050 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 1051 */     sQLException.fillInStackTrace();
/* 1052 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBinaryFloat(String paramString, BINARY_FLOAT paramBINARY_FLOAT) throws SQLException {
/* 1060 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 1061 */     sQLException.fillInStackTrace();
/* 1062 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBinaryDouble(int paramInt, double paramDouble) throws SQLException {
/* 1071 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 1072 */     sQLException.fillInStackTrace();
/* 1073 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBinaryDoubleAtName(String paramString, double paramDouble) throws SQLException {
/* 1081 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 1082 */     sQLException.fillInStackTrace();
/* 1083 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBinaryDouble(String paramString, double paramDouble) throws SQLException {
/* 1091 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 1092 */     sQLException.fillInStackTrace();
/* 1093 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBinaryDouble(int paramInt, BINARY_DOUBLE paramBINARY_DOUBLE) throws SQLException {
/* 1102 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 1103 */     sQLException.fillInStackTrace();
/* 1104 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBinaryDoubleAtName(String paramString, BINARY_DOUBLE paramBINARY_DOUBLE) throws SQLException {
/* 1112 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 1113 */     sQLException.fillInStackTrace();
/* 1114 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBinaryDouble(String paramString, BINARY_DOUBLE paramBINARY_DOUBLE) throws SQLException {
/* 1122 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 1123 */     sQLException.fillInStackTrace();
/* 1124 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBLOB(int paramInt, BLOB paramBLOB) throws SQLException {
/* 1133 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 1134 */     sQLException.fillInStackTrace();
/* 1135 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBLOBAtName(String paramString, BLOB paramBLOB) throws SQLException {
/* 1143 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 1144 */     sQLException.fillInStackTrace();
/* 1145 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBLOB(String paramString, BLOB paramBLOB) throws SQLException {
/* 1153 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 1154 */     sQLException.fillInStackTrace();
/* 1155 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setCHAR(int paramInt, CHAR paramCHAR) throws SQLException {
/* 1164 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 1165 */     sQLException.fillInStackTrace();
/* 1166 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setCHARAtName(String paramString, CHAR paramCHAR) throws SQLException {
/* 1174 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 1175 */     sQLException.fillInStackTrace();
/* 1176 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setCHAR(String paramString, CHAR paramCHAR) throws SQLException {
/* 1184 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 1185 */     sQLException.fillInStackTrace();
/* 1186 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setCLOB(int paramInt, CLOB paramCLOB) throws SQLException {
/* 1195 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 1196 */     sQLException.fillInStackTrace();
/* 1197 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setCLOBAtName(String paramString, CLOB paramCLOB) throws SQLException {
/* 1205 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 1206 */     sQLException.fillInStackTrace();
/* 1207 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setCLOB(String paramString, CLOB paramCLOB) throws SQLException {
/* 1215 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 1216 */     sQLException.fillInStackTrace();
/* 1217 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setCursor(int paramInt, ResultSet paramResultSet) throws SQLException {
/* 1226 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 1227 */     sQLException.fillInStackTrace();
/* 1228 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setCursorAtName(String paramString, ResultSet paramResultSet) throws SQLException {
/* 1236 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 1237 */     sQLException.fillInStackTrace();
/* 1238 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setCursor(String paramString, ResultSet paramResultSet) throws SQLException {
/* 1246 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 1247 */     sQLException.fillInStackTrace();
/* 1248 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setDATE(int paramInt, DATE paramDATE) throws SQLException {
/* 1257 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 1258 */     sQLException.fillInStackTrace();
/* 1259 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setDATEAtName(String paramString, DATE paramDATE) throws SQLException {
/* 1267 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 1268 */     sQLException.fillInStackTrace();
/* 1269 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setDATE(String paramString, DATE paramDATE) throws SQLException {
/* 1277 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 1278 */     sQLException.fillInStackTrace();
/* 1279 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setFixedCHAR(int paramInt, String paramString) throws SQLException {
/* 1288 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 1289 */     sQLException.fillInStackTrace();
/* 1290 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setFixedCHARAtName(String paramString1, String paramString2) throws SQLException {
/* 1298 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 1299 */     sQLException.fillInStackTrace();
/* 1300 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setFixedCHAR(String paramString1, String paramString2) throws SQLException {
/* 1308 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 1309 */     sQLException.fillInStackTrace();
/* 1310 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setINTERVALDS(int paramInt, INTERVALDS paramINTERVALDS) throws SQLException {
/* 1319 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 1320 */     sQLException.fillInStackTrace();
/* 1321 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setINTERVALDSAtName(String paramString, INTERVALDS paramINTERVALDS) throws SQLException {
/* 1329 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 1330 */     sQLException.fillInStackTrace();
/* 1331 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setINTERVALDS(String paramString, INTERVALDS paramINTERVALDS) throws SQLException {
/* 1339 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 1340 */     sQLException.fillInStackTrace();
/* 1341 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setINTERVALYM(int paramInt, INTERVALYM paramINTERVALYM) throws SQLException {
/* 1350 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 1351 */     sQLException.fillInStackTrace();
/* 1352 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setINTERVALYMAtName(String paramString, INTERVALYM paramINTERVALYM) throws SQLException {
/* 1360 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 1361 */     sQLException.fillInStackTrace();
/* 1362 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setINTERVALYM(String paramString, INTERVALYM paramINTERVALYM) throws SQLException {
/* 1370 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 1371 */     sQLException.fillInStackTrace();
/* 1372 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setNUMBER(int paramInt, NUMBER paramNUMBER) throws SQLException {
/* 1381 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 1382 */     sQLException.fillInStackTrace();
/* 1383 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setNUMBERAtName(String paramString, NUMBER paramNUMBER) throws SQLException {
/* 1391 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 1392 */     sQLException.fillInStackTrace();
/* 1393 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setNUMBER(String paramString, NUMBER paramNUMBER) throws SQLException {
/* 1401 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 1402 */     sQLException.fillInStackTrace();
/* 1403 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setOPAQUE(int paramInt, OPAQUE paramOPAQUE) throws SQLException {
/* 1412 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 1413 */     sQLException.fillInStackTrace();
/* 1414 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setOPAQUEAtName(String paramString, OPAQUE paramOPAQUE) throws SQLException {
/* 1422 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 1423 */     sQLException.fillInStackTrace();
/* 1424 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setOPAQUE(String paramString, OPAQUE paramOPAQUE) throws SQLException {
/* 1432 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 1433 */     sQLException.fillInStackTrace();
/* 1434 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setOracleObject(int paramInt, Datum paramDatum) throws SQLException {
/* 1443 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 1444 */     sQLException.fillInStackTrace();
/* 1445 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setOracleObjectAtName(String paramString, Datum paramDatum) throws SQLException {
/* 1453 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 1454 */     sQLException.fillInStackTrace();
/* 1455 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setOracleObject(String paramString, Datum paramDatum) throws SQLException {
/* 1463 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 1464 */     sQLException.fillInStackTrace();
/* 1465 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setORAData(int paramInt, ORAData paramORAData) throws SQLException {
/* 1474 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 1475 */     sQLException.fillInStackTrace();
/* 1476 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setORADataAtName(String paramString, ORAData paramORAData) throws SQLException {
/* 1484 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 1485 */     sQLException.fillInStackTrace();
/* 1486 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setORAData(String paramString, ORAData paramORAData) throws SQLException {
/* 1494 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 1495 */     sQLException.fillInStackTrace();
/* 1496 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setRAW(int paramInt, RAW paramRAW) throws SQLException {
/* 1505 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 1506 */     sQLException.fillInStackTrace();
/* 1507 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setRAWAtName(String paramString, RAW paramRAW) throws SQLException {
/* 1515 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 1516 */     sQLException.fillInStackTrace();
/* 1517 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setRAW(String paramString, RAW paramRAW) throws SQLException {
/* 1525 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 1526 */     sQLException.fillInStackTrace();
/* 1527 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setREF(int paramInt, REF paramREF) throws SQLException {
/* 1536 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 1537 */     sQLException.fillInStackTrace();
/* 1538 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setREFAtName(String paramString, REF paramREF) throws SQLException {
/* 1546 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 1547 */     sQLException.fillInStackTrace();
/* 1548 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setREF(String paramString, REF paramREF) throws SQLException {
/* 1556 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 1557 */     sQLException.fillInStackTrace();
/* 1558 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setRefType(int paramInt, REF paramREF) throws SQLException {
/* 1567 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 1568 */     sQLException.fillInStackTrace();
/* 1569 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setRefTypeAtName(String paramString, REF paramREF) throws SQLException {
/* 1577 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 1578 */     sQLException.fillInStackTrace();
/* 1579 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setRefType(String paramString, REF paramREF) throws SQLException {
/* 1587 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 1588 */     sQLException.fillInStackTrace();
/* 1589 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setROWID(int paramInt, ROWID paramROWID) throws SQLException {
/* 1598 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 1599 */     sQLException.fillInStackTrace();
/* 1600 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setROWIDAtName(String paramString, ROWID paramROWID) throws SQLException {
/* 1608 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 1609 */     sQLException.fillInStackTrace();
/* 1610 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setROWID(String paramString, ROWID paramROWID) throws SQLException {
/* 1618 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 1619 */     sQLException.fillInStackTrace();
/* 1620 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setSTRUCT(int paramInt, STRUCT paramSTRUCT) throws SQLException {
/* 1629 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 1630 */     sQLException.fillInStackTrace();
/* 1631 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setSTRUCTAtName(String paramString, STRUCT paramSTRUCT) throws SQLException {
/* 1639 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 1640 */     sQLException.fillInStackTrace();
/* 1641 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setSTRUCT(String paramString, STRUCT paramSTRUCT) throws SQLException {
/* 1649 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 1650 */     sQLException.fillInStackTrace();
/* 1651 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setTIMESTAMPLTZ(int paramInt, TIMESTAMPLTZ paramTIMESTAMPLTZ) throws SQLException {
/* 1660 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 1661 */     sQLException.fillInStackTrace();
/* 1662 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setTIMESTAMPLTZAtName(String paramString, TIMESTAMPLTZ paramTIMESTAMPLTZ) throws SQLException {
/* 1670 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 1671 */     sQLException.fillInStackTrace();
/* 1672 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setTIMESTAMPLTZ(String paramString, TIMESTAMPLTZ paramTIMESTAMPLTZ) throws SQLException {
/* 1680 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 1681 */     sQLException.fillInStackTrace();
/* 1682 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setTIMESTAMPTZ(int paramInt, TIMESTAMPTZ paramTIMESTAMPTZ) throws SQLException {
/* 1691 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 1692 */     sQLException.fillInStackTrace();
/* 1693 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setTIMESTAMPTZAtName(String paramString, TIMESTAMPTZ paramTIMESTAMPTZ) throws SQLException {
/* 1701 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 1702 */     sQLException.fillInStackTrace();
/* 1703 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setTIMESTAMPTZ(String paramString, TIMESTAMPTZ paramTIMESTAMPTZ) throws SQLException {
/* 1711 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 1712 */     sQLException.fillInStackTrace();
/* 1713 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setTIMESTAMP(int paramInt, TIMESTAMP paramTIMESTAMP) throws SQLException {
/* 1722 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 1723 */     sQLException.fillInStackTrace();
/* 1724 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setTIMESTAMPAtName(String paramString, TIMESTAMP paramTIMESTAMP) throws SQLException {
/* 1732 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 1733 */     sQLException.fillInStackTrace();
/* 1734 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setTIMESTAMP(String paramString, TIMESTAMP paramTIMESTAMP) throws SQLException {
/* 1742 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 1743 */     sQLException.fillInStackTrace();
/* 1744 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setCustomDatum(int paramInt, CustomDatum paramCustomDatum) throws SQLException {
/* 1753 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 1754 */     sQLException.fillInStackTrace();
/* 1755 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setCustomDatumAtName(String paramString, CustomDatum paramCustomDatum) throws SQLException {
/* 1763 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 1764 */     sQLException.fillInStackTrace();
/* 1765 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setCustomDatum(String paramString, CustomDatum paramCustomDatum) throws SQLException {
/* 1773 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 1774 */     sQLException.fillInStackTrace();
/* 1775 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBlob(int paramInt, InputStream paramInputStream) throws SQLException {
/* 1784 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 1785 */     sQLException.fillInStackTrace();
/* 1786 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBlobAtName(String paramString, InputStream paramInputStream) throws SQLException {
/* 1794 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 1795 */     sQLException.fillInStackTrace();
/* 1796 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBlob(String paramString, InputStream paramInputStream) throws SQLException {
/* 1804 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 1805 */     sQLException.fillInStackTrace();
/* 1806 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBlob(int paramInt, InputStream paramInputStream, long paramLong) throws SQLException {
/* 1815 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 1816 */     sQLException.fillInStackTrace();
/* 1817 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBlobAtName(String paramString, InputStream paramInputStream, long paramLong) throws SQLException {
/* 1825 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 1826 */     sQLException.fillInStackTrace();
/* 1827 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBlob(String paramString, InputStream paramInputStream, long paramLong) throws SQLException {
/* 1835 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 1836 */     sQLException.fillInStackTrace();
/* 1837 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setClob(int paramInt, Reader paramReader) throws SQLException {
/* 1846 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 1847 */     sQLException.fillInStackTrace();
/* 1848 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setClobAtName(String paramString, Reader paramReader) throws SQLException {
/* 1856 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 1857 */     sQLException.fillInStackTrace();
/* 1858 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setClob(String paramString, Reader paramReader) throws SQLException {
/* 1866 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 1867 */     sQLException.fillInStackTrace();
/* 1868 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setClob(int paramInt, Reader paramReader, long paramLong) throws SQLException {
/* 1877 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 1878 */     sQLException.fillInStackTrace();
/* 1879 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setClobAtName(String paramString, Reader paramReader, long paramLong) throws SQLException {
/* 1887 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 1888 */     sQLException.fillInStackTrace();
/* 1889 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setClob(String paramString, Reader paramReader, long paramLong) throws SQLException {
/* 1897 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 1898 */     sQLException.fillInStackTrace();
/* 1899 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setNClob(int paramInt, Reader paramReader) throws SQLException {
/* 1908 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 1909 */     sQLException.fillInStackTrace();
/* 1910 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setNClobAtName(String paramString, Reader paramReader) throws SQLException {
/* 1918 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 1919 */     sQLException.fillInStackTrace();
/* 1920 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setNClob(String paramString, Reader paramReader) throws SQLException {
/* 1928 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 1929 */     sQLException.fillInStackTrace();
/* 1930 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setNClob(int paramInt, Reader paramReader, long paramLong) throws SQLException {
/* 1939 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 1940 */     sQLException.fillInStackTrace();
/* 1941 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setNClobAtName(String paramString, Reader paramReader, long paramLong) throws SQLException {
/* 1949 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 1950 */     sQLException.fillInStackTrace();
/* 1951 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setNClob(String paramString, Reader paramReader, long paramLong) throws SQLException {
/* 1959 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 1960 */     sQLException.fillInStackTrace();
/* 1961 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setAsciiStream(int paramInt, InputStream paramInputStream) throws SQLException {
/* 1970 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 1971 */     sQLException.fillInStackTrace();
/* 1972 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setAsciiStreamAtName(String paramString, InputStream paramInputStream) throws SQLException {
/* 1980 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 1981 */     sQLException.fillInStackTrace();
/* 1982 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setAsciiStream(String paramString, InputStream paramInputStream) throws SQLException {
/* 1990 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 1991 */     sQLException.fillInStackTrace();
/* 1992 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setAsciiStream(int paramInt1, InputStream paramInputStream, int paramInt2) throws SQLException {
/* 2001 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 2002 */     sQLException.fillInStackTrace();
/* 2003 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setAsciiStreamAtName(String paramString, InputStream paramInputStream, int paramInt) throws SQLException {
/* 2011 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 2012 */     sQLException.fillInStackTrace();
/* 2013 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setAsciiStream(String paramString, InputStream paramInputStream, int paramInt) throws SQLException {
/* 2021 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 2022 */     sQLException.fillInStackTrace();
/* 2023 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setAsciiStream(int paramInt, InputStream paramInputStream, long paramLong) throws SQLException {
/* 2032 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 2033 */     sQLException.fillInStackTrace();
/* 2034 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setAsciiStreamAtName(String paramString, InputStream paramInputStream, long paramLong) throws SQLException {
/* 2042 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 2043 */     sQLException.fillInStackTrace();
/* 2044 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setAsciiStream(String paramString, InputStream paramInputStream, long paramLong) throws SQLException {
/* 2052 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 2053 */     sQLException.fillInStackTrace();
/* 2054 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBinaryStream(int paramInt, InputStream paramInputStream) throws SQLException {
/* 2063 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 2064 */     sQLException.fillInStackTrace();
/* 2065 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBinaryStreamAtName(String paramString, InputStream paramInputStream) throws SQLException {
/* 2073 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 2074 */     sQLException.fillInStackTrace();
/* 2075 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBinaryStream(String paramString, InputStream paramInputStream) throws SQLException {
/* 2083 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 2084 */     sQLException.fillInStackTrace();
/* 2085 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBinaryStream(int paramInt1, InputStream paramInputStream, int paramInt2) throws SQLException {
/* 2094 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 2095 */     sQLException.fillInStackTrace();
/* 2096 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBinaryStreamAtName(String paramString, InputStream paramInputStream, int paramInt) throws SQLException {
/* 2104 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 2105 */     sQLException.fillInStackTrace();
/* 2106 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBinaryStream(String paramString, InputStream paramInputStream, int paramInt) throws SQLException {
/* 2114 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 2115 */     sQLException.fillInStackTrace();
/* 2116 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBinaryStream(int paramInt, InputStream paramInputStream, long paramLong) throws SQLException {
/* 2125 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 2126 */     sQLException.fillInStackTrace();
/* 2127 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBinaryStreamAtName(String paramString, InputStream paramInputStream, long paramLong) throws SQLException {
/* 2135 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 2136 */     sQLException.fillInStackTrace();
/* 2137 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBinaryStream(String paramString, InputStream paramInputStream, long paramLong) throws SQLException {
/* 2145 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 2146 */     sQLException.fillInStackTrace();
/* 2147 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setCharacterStream(int paramInt, Reader paramReader) throws SQLException {
/* 2156 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 2157 */     sQLException.fillInStackTrace();
/* 2158 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setCharacterStreamAtName(String paramString, Reader paramReader) throws SQLException {
/* 2166 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 2167 */     sQLException.fillInStackTrace();
/* 2168 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setCharacterStream(String paramString, Reader paramReader) throws SQLException {
/* 2176 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 2177 */     sQLException.fillInStackTrace();
/* 2178 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setCharacterStream(int paramInt1, Reader paramReader, int paramInt2) throws SQLException {
/* 2187 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 2188 */     sQLException.fillInStackTrace();
/* 2189 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setCharacterStreamAtName(String paramString, Reader paramReader, int paramInt) throws SQLException {
/* 2197 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 2198 */     sQLException.fillInStackTrace();
/* 2199 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setCharacterStream(String paramString, Reader paramReader, int paramInt) throws SQLException {
/* 2207 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 2208 */     sQLException.fillInStackTrace();
/* 2209 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setCharacterStream(int paramInt, Reader paramReader, long paramLong) throws SQLException {
/* 2218 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 2219 */     sQLException.fillInStackTrace();
/* 2220 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setCharacterStreamAtName(String paramString, Reader paramReader, long paramLong) throws SQLException {
/* 2228 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 2229 */     sQLException.fillInStackTrace();
/* 2230 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setCharacterStream(String paramString, Reader paramReader, long paramLong) throws SQLException {
/* 2238 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 2239 */     sQLException.fillInStackTrace();
/* 2240 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setNCharacterStream(int paramInt, Reader paramReader) throws SQLException {
/* 2249 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 2250 */     sQLException.fillInStackTrace();
/* 2251 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setNCharacterStreamAtName(String paramString, Reader paramReader) throws SQLException {
/* 2259 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 2260 */     sQLException.fillInStackTrace();
/* 2261 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setNCharacterStream(String paramString, Reader paramReader) throws SQLException {
/* 2269 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 2270 */     sQLException.fillInStackTrace();
/* 2271 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setNCharacterStream(int paramInt, Reader paramReader, long paramLong) throws SQLException {
/* 2280 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 2281 */     sQLException.fillInStackTrace();
/* 2282 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setNCharacterStreamAtName(String paramString, Reader paramReader, long paramLong) throws SQLException {
/* 2290 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 2291 */     sQLException.fillInStackTrace();
/* 2292 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setNCharacterStream(String paramString, Reader paramReader, long paramLong) throws SQLException {
/* 2300 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 2301 */     sQLException.fillInStackTrace();
/* 2302 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setUnicodeStream(int paramInt1, InputStream paramInputStream, int paramInt2) throws SQLException {
/* 2311 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 2312 */     sQLException.fillInStackTrace();
/* 2313 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setUnicodeStreamAtName(String paramString, InputStream paramInputStream, int paramInt) throws SQLException {
/* 2321 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 2322 */     sQLException.fillInStackTrace();
/* 2323 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setUnicodeStream(String paramString, InputStream paramInputStream, int paramInt) throws SQLException {
/* 2331 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 2332 */     sQLException.fillInStackTrace();
/* 2333 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Array getArray(int paramInt) throws SQLException {
/* 2344 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 2345 */     sQLException.fillInStackTrace();
/* 2346 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Array getArray(String paramString) throws SQLException {
/* 2354 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 2355 */     sQLException.fillInStackTrace();
/* 2356 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public BigDecimal getBigDecimal(int paramInt) throws SQLException {
/* 2364 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 2365 */     sQLException.fillInStackTrace();
/* 2366 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public BigDecimal getBigDecimal(String paramString) throws SQLException {
/* 2374 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 2375 */     sQLException.fillInStackTrace();
/* 2376 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public BigDecimal getBigDecimal(int paramInt1, int paramInt2) throws SQLException {
/* 2384 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 2385 */     sQLException.fillInStackTrace();
/* 2386 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public BigDecimal getBigDecimal(String paramString, int paramInt) throws SQLException {
/* 2394 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 2395 */     sQLException.fillInStackTrace();
/* 2396 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Blob getBlob(int paramInt) throws SQLException {
/* 2404 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 2405 */     sQLException.fillInStackTrace();
/* 2406 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Blob getBlob(String paramString) throws SQLException {
/* 2414 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 2415 */     sQLException.fillInStackTrace();
/* 2416 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean getBoolean(int paramInt) throws SQLException {
/* 2424 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 2425 */     sQLException.fillInStackTrace();
/* 2426 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean getBoolean(String paramString) throws SQLException {
/* 2434 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 2435 */     sQLException.fillInStackTrace();
/* 2436 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public byte getByte(int paramInt) throws SQLException {
/* 2444 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 2445 */     sQLException.fillInStackTrace();
/* 2446 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public byte getByte(String paramString) throws SQLException {
/* 2454 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 2455 */     sQLException.fillInStackTrace();
/* 2456 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public byte[] getBytes(int paramInt) throws SQLException {
/* 2464 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 2465 */     sQLException.fillInStackTrace();
/* 2466 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public byte[] getBytes(String paramString) throws SQLException {
/* 2474 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 2475 */     sQLException.fillInStackTrace();
/* 2476 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Clob getClob(int paramInt) throws SQLException {
/* 2484 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 2485 */     sQLException.fillInStackTrace();
/* 2486 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Clob getClob(String paramString) throws SQLException {
/* 2494 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 2495 */     sQLException.fillInStackTrace();
/* 2496 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Date getDate(int paramInt) throws SQLException {
/* 2504 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 2505 */     sQLException.fillInStackTrace();
/* 2506 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Date getDate(String paramString) throws SQLException {
/* 2514 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 2515 */     sQLException.fillInStackTrace();
/* 2516 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Date getDate(int paramInt, Calendar paramCalendar) throws SQLException {
/* 2524 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 2525 */     sQLException.fillInStackTrace();
/* 2526 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Date getDate(String paramString, Calendar paramCalendar) throws SQLException {
/* 2534 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 2535 */     sQLException.fillInStackTrace();
/* 2536 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public double getDouble(int paramInt) throws SQLException {
/* 2544 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 2545 */     sQLException.fillInStackTrace();
/* 2546 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public double getDouble(String paramString) throws SQLException {
/* 2554 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 2555 */     sQLException.fillInStackTrace();
/* 2556 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public float getFloat(int paramInt) throws SQLException {
/* 2564 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 2565 */     sQLException.fillInStackTrace();
/* 2566 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public float getFloat(String paramString) throws SQLException {
/* 2574 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 2575 */     sQLException.fillInStackTrace();
/* 2576 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getInt(int paramInt) throws SQLException {
/* 2584 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 2585 */     sQLException.fillInStackTrace();
/* 2586 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getInt(String paramString) throws SQLException {
/* 2594 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 2595 */     sQLException.fillInStackTrace();
/* 2596 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public long getLong(int paramInt) throws SQLException {
/* 2604 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 2605 */     sQLException.fillInStackTrace();
/* 2606 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public long getLong(String paramString) throws SQLException {
/* 2614 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 2615 */     sQLException.fillInStackTrace();
/* 2616 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public NClob getNClob(int paramInt) throws SQLException {
/* 2624 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 2625 */     sQLException.fillInStackTrace();
/* 2626 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public NClob getNClob(String paramString) throws SQLException {
/* 2634 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 2635 */     sQLException.fillInStackTrace();
/* 2636 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getNString(int paramInt) throws SQLException {
/* 2644 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 2645 */     sQLException.fillInStackTrace();
/* 2646 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getNString(String paramString) throws SQLException {
/* 2654 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 2655 */     sQLException.fillInStackTrace();
/* 2656 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Object getObject(int paramInt) throws SQLException {
/* 2664 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 2665 */     sQLException.fillInStackTrace();
/* 2666 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Object getObject(String paramString) throws SQLException {
/* 2674 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 2675 */     sQLException.fillInStackTrace();
/* 2676 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Object getObject(int paramInt, Map paramMap) throws SQLException {
/* 2684 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 2685 */     sQLException.fillInStackTrace();
/* 2686 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Object getObject(String paramString, Map paramMap) throws SQLException {
/* 2694 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 2695 */     sQLException.fillInStackTrace();
/* 2696 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Ref getRef(int paramInt) throws SQLException {
/* 2704 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 2705 */     sQLException.fillInStackTrace();
/* 2706 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Ref getRef(String paramString) throws SQLException {
/* 2714 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 2715 */     sQLException.fillInStackTrace();
/* 2716 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public RowId getRowId(int paramInt) throws SQLException {
/* 2724 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 2725 */     sQLException.fillInStackTrace();
/* 2726 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public RowId getRowId(String paramString) throws SQLException {
/* 2734 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 2735 */     sQLException.fillInStackTrace();
/* 2736 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public short getShort(int paramInt) throws SQLException {
/* 2744 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 2745 */     sQLException.fillInStackTrace();
/* 2746 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public short getShort(String paramString) throws SQLException {
/* 2754 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 2755 */     sQLException.fillInStackTrace();
/* 2756 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public SQLXML getSQLXML(int paramInt) throws SQLException {
/* 2764 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 2765 */     sQLException.fillInStackTrace();
/* 2766 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public SQLXML getSQLXML(String paramString) throws SQLException {
/* 2774 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 2775 */     sQLException.fillInStackTrace();
/* 2776 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getString(int paramInt) throws SQLException {
/* 2784 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 2785 */     sQLException.fillInStackTrace();
/* 2786 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getString(String paramString) throws SQLException {
/* 2794 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 2795 */     sQLException.fillInStackTrace();
/* 2796 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Time getTime(int paramInt) throws SQLException {
/* 2804 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 2805 */     sQLException.fillInStackTrace();
/* 2806 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Time getTime(String paramString) throws SQLException {
/* 2814 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 2815 */     sQLException.fillInStackTrace();
/* 2816 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Time getTime(int paramInt, Calendar paramCalendar) throws SQLException {
/* 2824 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 2825 */     sQLException.fillInStackTrace();
/* 2826 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Time getTime(String paramString, Calendar paramCalendar) throws SQLException {
/* 2834 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 2835 */     sQLException.fillInStackTrace();
/* 2836 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Timestamp getTimestamp(int paramInt) throws SQLException {
/* 2844 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 2845 */     sQLException.fillInStackTrace();
/* 2846 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Timestamp getTimestamp(String paramString) throws SQLException {
/* 2854 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 2855 */     sQLException.fillInStackTrace();
/* 2856 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Timestamp getTimestamp(int paramInt, Calendar paramCalendar) throws SQLException {
/* 2864 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 2865 */     sQLException.fillInStackTrace();
/* 2866 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Timestamp getTimestamp(String paramString, Calendar paramCalendar) throws SQLException {
/* 2874 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 2875 */     sQLException.fillInStackTrace();
/* 2876 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public URL getURL(int paramInt) throws SQLException {
/* 2884 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 2885 */     sQLException.fillInStackTrace();
/* 2886 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public URL getURL(String paramString) throws SQLException {
/* 2894 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 2895 */     sQLException.fillInStackTrace();
/* 2896 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ARRAY getARRAY(int paramInt) throws SQLException {
/* 2904 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 2905 */     sQLException.fillInStackTrace();
/* 2906 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ARRAY getARRAY(String paramString) throws SQLException {
/* 2914 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 2915 */     sQLException.fillInStackTrace();
/* 2916 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public BFILE getBFILE(int paramInt) throws SQLException {
/* 2924 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 2925 */     sQLException.fillInStackTrace();
/* 2926 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public BFILE getBFILE(String paramString) throws SQLException {
/* 2934 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 2935 */     sQLException.fillInStackTrace();
/* 2936 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public BFILE getBfile(int paramInt) throws SQLException {
/* 2944 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 2945 */     sQLException.fillInStackTrace();
/* 2946 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public BFILE getBfile(String paramString) throws SQLException {
/* 2954 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 2955 */     sQLException.fillInStackTrace();
/* 2956 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public BLOB getBLOB(int paramInt) throws SQLException {
/* 2964 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 2965 */     sQLException.fillInStackTrace();
/* 2966 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public BLOB getBLOB(String paramString) throws SQLException {
/* 2974 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 2975 */     sQLException.fillInStackTrace();
/* 2976 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public CHAR getCHAR(int paramInt) throws SQLException {
/* 2984 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 2985 */     sQLException.fillInStackTrace();
/* 2986 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public CHAR getCHAR(String paramString) throws SQLException {
/* 2994 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 2995 */     sQLException.fillInStackTrace();
/* 2996 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public CLOB getCLOB(int paramInt) throws SQLException {
/* 3004 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 3005 */     sQLException.fillInStackTrace();
/* 3006 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public CLOB getCLOB(String paramString) throws SQLException {
/* 3014 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 3015 */     sQLException.fillInStackTrace();
/* 3016 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ResultSet getCursor(int paramInt) throws SQLException {
/* 3024 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 3025 */     sQLException.fillInStackTrace();
/* 3026 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ResultSet getCursor(String paramString) throws SQLException {
/* 3034 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 3035 */     sQLException.fillInStackTrace();
/* 3036 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public DATE getDATE(int paramInt) throws SQLException {
/* 3044 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 3045 */     sQLException.fillInStackTrace();
/* 3046 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public DATE getDATE(String paramString) throws SQLException {
/* 3054 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 3055 */     sQLException.fillInStackTrace();
/* 3056 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public INTERVALDS getINTERVALDS(int paramInt) throws SQLException {
/* 3064 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 3065 */     sQLException.fillInStackTrace();
/* 3066 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public INTERVALDS getINTERVALDS(String paramString) throws SQLException {
/* 3074 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 3075 */     sQLException.fillInStackTrace();
/* 3076 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public INTERVALYM getINTERVALYM(int paramInt) throws SQLException {
/* 3084 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 3085 */     sQLException.fillInStackTrace();
/* 3086 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public INTERVALYM getINTERVALYM(String paramString) throws SQLException {
/* 3094 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 3095 */     sQLException.fillInStackTrace();
/* 3096 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public NUMBER getNUMBER(int paramInt) throws SQLException {
/* 3104 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 3105 */     sQLException.fillInStackTrace();
/* 3106 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public NUMBER getNUMBER(String paramString) throws SQLException {
/* 3114 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 3115 */     sQLException.fillInStackTrace();
/* 3116 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public OPAQUE getOPAQUE(int paramInt) throws SQLException {
/* 3124 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 3125 */     sQLException.fillInStackTrace();
/* 3126 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public OPAQUE getOPAQUE(String paramString) throws SQLException {
/* 3134 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 3135 */     sQLException.fillInStackTrace();
/* 3136 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Datum getOracleObject(int paramInt) throws SQLException {
/* 3144 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 3145 */     sQLException.fillInStackTrace();
/* 3146 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Datum getOracleObject(String paramString) throws SQLException {
/* 3154 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 3155 */     sQLException.fillInStackTrace();
/* 3156 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ORAData getORAData(int paramInt, ORADataFactory paramORADataFactory) throws SQLException {
/* 3164 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 3165 */     sQLException.fillInStackTrace();
/* 3166 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ORAData getORAData(String paramString, ORADataFactory paramORADataFactory) throws SQLException {
/* 3174 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 3175 */     sQLException.fillInStackTrace();
/* 3176 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Object getObject(int paramInt, OracleDataFactory paramOracleDataFactory) throws SQLException {
/* 3184 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 3185 */     sQLException.fillInStackTrace();
/* 3186 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Object getObject(String paramString, OracleDataFactory paramOracleDataFactory) throws SQLException {
/* 3194 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 3195 */     sQLException.fillInStackTrace();
/* 3196 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public RAW getRAW(int paramInt) throws SQLException {
/* 3204 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 3205 */     sQLException.fillInStackTrace();
/* 3206 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public RAW getRAW(String paramString) throws SQLException {
/* 3214 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 3215 */     sQLException.fillInStackTrace();
/* 3216 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public REF getREF(int paramInt) throws SQLException {
/* 3224 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 3225 */     sQLException.fillInStackTrace();
/* 3226 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public REF getREF(String paramString) throws SQLException {
/* 3234 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 3235 */     sQLException.fillInStackTrace();
/* 3236 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ROWID getROWID(int paramInt) throws SQLException {
/* 3244 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 3245 */     sQLException.fillInStackTrace();
/* 3246 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ROWID getROWID(String paramString) throws SQLException {
/* 3254 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 3255 */     sQLException.fillInStackTrace();
/* 3256 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public STRUCT getSTRUCT(int paramInt) throws SQLException {
/* 3264 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 3265 */     sQLException.fillInStackTrace();
/* 3266 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public STRUCT getSTRUCT(String paramString) throws SQLException {
/* 3274 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 3275 */     sQLException.fillInStackTrace();
/* 3276 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public TIMESTAMPLTZ getTIMESTAMPLTZ(int paramInt) throws SQLException {
/* 3284 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 3285 */     sQLException.fillInStackTrace();
/* 3286 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public TIMESTAMPLTZ getTIMESTAMPLTZ(String paramString) throws SQLException {
/* 3294 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 3295 */     sQLException.fillInStackTrace();
/* 3296 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public TIMESTAMPTZ getTIMESTAMPTZ(int paramInt) throws SQLException {
/* 3304 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 3305 */     sQLException.fillInStackTrace();
/* 3306 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public TIMESTAMPTZ getTIMESTAMPTZ(String paramString) throws SQLException {
/* 3314 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 3315 */     sQLException.fillInStackTrace();
/* 3316 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public TIMESTAMP getTIMESTAMP(int paramInt) throws SQLException {
/* 3324 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 3325 */     sQLException.fillInStackTrace();
/* 3326 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public TIMESTAMP getTIMESTAMP(String paramString) throws SQLException {
/* 3334 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 3335 */     sQLException.fillInStackTrace();
/* 3336 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public CustomDatum getCustomDatum(int paramInt, CustomDatumFactory paramCustomDatumFactory) throws SQLException {
/* 3344 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 3345 */     sQLException.fillInStackTrace();
/* 3346 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public CustomDatum getCustomDatum(String paramString, CustomDatumFactory paramCustomDatumFactory) throws SQLException {
/* 3354 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 3355 */     sQLException.fillInStackTrace();
/* 3356 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public InputStream getAsciiStream(int paramInt) throws SQLException {
/* 3364 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 3365 */     sQLException.fillInStackTrace();
/* 3366 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public InputStream getAsciiStream(String paramString) throws SQLException {
/* 3374 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 3375 */     sQLException.fillInStackTrace();
/* 3376 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public InputStream getBinaryStream(int paramInt) throws SQLException {
/* 3384 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 3385 */     sQLException.fillInStackTrace();
/* 3386 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public InputStream getBinaryStream(String paramString) throws SQLException {
/* 3394 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 3395 */     sQLException.fillInStackTrace();
/* 3396 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Reader getCharacterStream(int paramInt) throws SQLException {
/* 3404 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 3405 */     sQLException.fillInStackTrace();
/* 3406 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Reader getCharacterStream(String paramString) throws SQLException {
/* 3414 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 3415 */     sQLException.fillInStackTrace();
/* 3416 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Reader getNCharacterStream(int paramInt) throws SQLException {
/* 3424 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 3425 */     sQLException.fillInStackTrace();
/* 3426 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Reader getNCharacterStream(String paramString) throws SQLException {
/* 3434 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 3435 */     sQLException.fillInStackTrace();
/* 3436 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public InputStream getUnicodeStream(int paramInt) throws SQLException {
/* 3444 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 3445 */     sQLException.fillInStackTrace();
/* 3446 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public InputStream getUnicodeStream(String paramString) throws SQLException {
/* 3454 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 3455 */     sQLException.fillInStackTrace();
/* 3456 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setNull(int paramInt1, int paramInt2) throws SQLException {
/* 3465 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 3466 */     sQLException.fillInStackTrace();
/* 3467 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setNull(String paramString, int paramInt) throws SQLException {
/* 3474 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 3475 */     sQLException.fillInStackTrace();
/* 3476 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setNull(int paramInt1, int paramInt2, String paramString) throws SQLException {
/* 3483 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 3484 */     sQLException.fillInStackTrace();
/* 3485 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setNull(String paramString1, int paramInt, String paramString2) throws SQLException {
/* 3492 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 3493 */     sQLException.fillInStackTrace();
/* 3494 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setNullAtName(String paramString, int paramInt) throws SQLException {
/* 3501 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 3502 */     sQLException.fillInStackTrace();
/* 3503 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setNullAtName(String paramString1, int paramInt, String paramString2) throws SQLException {
/* 3510 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 3511 */     sQLException.fillInStackTrace();
/* 3512 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setObject(int paramInt1, Object paramObject, int paramInt2, int paramInt3) throws SQLException {
/* 3523 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 3524 */     sQLException.fillInStackTrace();
/* 3525 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setObject(String paramString, Object paramObject, int paramInt1, int paramInt2) throws SQLException {
/* 3536 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 3537 */     sQLException.fillInStackTrace();
/* 3538 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setObjectAtName(String paramString, Object paramObject, int paramInt1, int paramInt2) throws SQLException {
/* 3549 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 3550 */     sQLException.fillInStackTrace();
/* 3551 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getFetchDirection() throws SQLException {
/* 3564 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 3565 */     sQLException.fillInStackTrace();
/* 3566 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getFetchSize() throws SQLException {
/* 3574 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 3575 */     sQLException.fillInStackTrace();
/* 3576 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getMaxFieldSize() throws SQLException {
/* 3584 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 3585 */     sQLException.fillInStackTrace();
/* 3586 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getMaxRows() throws SQLException {
/* 3594 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 3595 */     sQLException.fillInStackTrace();
/* 3596 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getQueryTimeout() throws SQLException {
/* 3604 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 3605 */     sQLException.fillInStackTrace();
/* 3606 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getResultSetConcurrency() throws SQLException {
/* 3614 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 3615 */     sQLException.fillInStackTrace();
/* 3616 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getResultSetHoldability() throws SQLException {
/* 3624 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 3625 */     sQLException.fillInStackTrace();
/* 3626 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getResultSetType() throws SQLException {
/* 3634 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 3635 */     sQLException.fillInStackTrace();
/* 3636 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getUpdateCount() throws SQLException {
/* 3644 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 3645 */     sQLException.fillInStackTrace();
/* 3646 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void cancel() throws SQLException {
/* 3654 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 3655 */     sQLException.fillInStackTrace();
/* 3656 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void clearBatch() throws SQLException {
/* 3664 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 3665 */     sQLException.fillInStackTrace();
/* 3666 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void clearWarnings() throws SQLException {
/* 3674 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 3675 */     sQLException.fillInStackTrace();
/* 3676 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void close() throws SQLException {}
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean getMoreResults() throws SQLException {
/* 3689 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 3690 */     sQLException.fillInStackTrace();
/* 3691 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int[] executeBatch() throws SQLException {
/* 3699 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 3700 */     sQLException.fillInStackTrace();
/* 3701 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setFetchDirection(int paramInt) throws SQLException {
/* 3709 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 3710 */     sQLException.fillInStackTrace();
/* 3711 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setFetchSize(int paramInt) throws SQLException {
/* 3719 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 3720 */     sQLException.fillInStackTrace();
/* 3721 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setMaxFieldSize(int paramInt) throws SQLException {
/* 3729 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 3730 */     sQLException.fillInStackTrace();
/* 3731 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setMaxRows(int paramInt) throws SQLException {
/* 3739 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 3740 */     sQLException.fillInStackTrace();
/* 3741 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setQueryTimeout(int paramInt) throws SQLException {
/* 3749 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 3750 */     sQLException.fillInStackTrace();
/* 3751 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean getMoreResults(int paramInt) throws SQLException {
/* 3759 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 3760 */     sQLException.fillInStackTrace();
/* 3761 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setEscapeProcessing(boolean paramBoolean) throws SQLException {
/* 3769 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 3770 */     sQLException.fillInStackTrace();
/* 3771 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int executeUpdate(String paramString) throws SQLException {
/* 3779 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 3780 */     sQLException.fillInStackTrace();
/* 3781 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void addBatch(String paramString) throws SQLException {
/* 3789 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 3790 */     sQLException.fillInStackTrace();
/* 3791 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setCursorName(String paramString) throws SQLException {
/* 3799 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 3800 */     sQLException.fillInStackTrace();
/* 3801 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean execute(String paramString) throws SQLException {
/* 3809 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 3810 */     sQLException.fillInStackTrace();
/* 3811 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int executeUpdate(String paramString, int paramInt) throws SQLException {
/* 3819 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 3820 */     sQLException.fillInStackTrace();
/* 3821 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean execute(String paramString, int paramInt) throws SQLException {
/* 3829 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 3830 */     sQLException.fillInStackTrace();
/* 3831 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int executeUpdate(String paramString, int[] paramArrayOfint) throws SQLException {
/* 3839 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 3840 */     sQLException.fillInStackTrace();
/* 3841 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean execute(String paramString, int[] paramArrayOfint) throws SQLException {
/* 3849 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 3850 */     sQLException.fillInStackTrace();
/* 3851 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Connection getConnection() throws SQLException {
/* 3859 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 3860 */     sQLException.fillInStackTrace();
/* 3861 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ResultSet getGeneratedKeys() throws SQLException {
/* 3869 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 3870 */     sQLException.fillInStackTrace();
/* 3871 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ResultSet getResultSet() throws SQLException {
/* 3879 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 3880 */     sQLException.fillInStackTrace();
/* 3881 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public SQLWarning getWarnings() throws SQLException {
/* 3889 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 3890 */     sQLException.fillInStackTrace();
/* 3891 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int executeUpdate(String paramString, String[] paramArrayOfString) throws SQLException {
/* 3899 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 3900 */     sQLException.fillInStackTrace();
/* 3901 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean execute(String paramString, String[] paramArrayOfString) throws SQLException {
/* 3909 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 3910 */     sQLException.fillInStackTrace();
/* 3911 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ResultSet executeQuery(String paramString) throws SQLException {
/* 3919 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 3920 */     sQLException.fillInStackTrace();
/* 3921 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void clearDefines() throws SQLException {
/* 3935 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 3936 */     sQLException.fillInStackTrace();
/* 3937 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void defineColumnType(int paramInt1, int paramInt2) throws SQLException {
/* 3945 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 3946 */     sQLException.fillInStackTrace();
/* 3947 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void defineColumnType(int paramInt1, int paramInt2, int paramInt3) throws SQLException {
/* 3955 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 3956 */     sQLException.fillInStackTrace();
/* 3957 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void defineColumnType(int paramInt1, int paramInt2, int paramInt3, short paramShort) throws SQLException {
/* 3965 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 3966 */     sQLException.fillInStackTrace();
/* 3967 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void defineColumnTypeBytes(int paramInt1, int paramInt2, int paramInt3) throws SQLException {
/* 3975 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 3976 */     sQLException.fillInStackTrace();
/* 3977 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void defineColumnTypeChars(int paramInt1, int paramInt2, int paramInt3) throws SQLException {
/* 3985 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 3986 */     sQLException.fillInStackTrace();
/* 3987 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void defineColumnType(int paramInt1, int paramInt2, String paramString) throws SQLException {
/* 3995 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 3996 */     sQLException.fillInStackTrace();
/* 3997 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public int getRowPrefetch() {
/* 4003 */     return -1;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setRowPrefetch(int paramInt) throws SQLException {
/* 4010 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 4011 */     sQLException.fillInStackTrace();
/* 4012 */     throw sQLException;
/*      */   }
/*      */ 
/*      */   
/*      */   public int getLobPrefetchSize() throws SQLException {
/* 4017 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 4018 */     sQLException.fillInStackTrace();
/* 4019 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setLobPrefetchSize(int paramInt) throws SQLException {
/* 4026 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 4027 */     sQLException.fillInStackTrace();
/* 4028 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void closeWithKey(String paramString) throws SQLException {
/* 4036 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 4037 */     sQLException.fillInStackTrace();
/* 4038 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public int creationState() {
/* 4044 */     return -1;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isNCHAR(int paramInt) throws SQLException {
/* 4051 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 4052 */     sQLException.fillInStackTrace();
/* 4053 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int executeUpdate() throws SQLException {
/* 4065 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 4066 */     sQLException.fillInStackTrace();
/* 4067 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void addBatch() throws SQLException {
/* 4075 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 4076 */     sQLException.fillInStackTrace();
/* 4077 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void clearParameters() throws SQLException {
/* 4085 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 4086 */     sQLException.fillInStackTrace();
/* 4087 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean execute() throws SQLException {
/* 4095 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 4096 */     sQLException.fillInStackTrace();
/* 4097 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ParameterMetaData getParameterMetaData() throws SQLException {
/* 4105 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 4106 */     sQLException.fillInStackTrace();
/* 4107 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ResultSet executeQuery() throws SQLException {
/* 4115 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 4116 */     sQLException.fillInStackTrace();
/* 4117 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ResultSetMetaData getMetaData() throws SQLException {
/* 4125 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 4126 */     sQLException.fillInStackTrace();
/* 4127 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ResultSet getReturnResultSet() throws SQLException {
/* 4135 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 4136 */     sQLException.fillInStackTrace();
/* 4137 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void defineParameterTypeBytes(int paramInt1, int paramInt2, int paramInt3) throws SQLException {
/* 4148 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 4149 */     sQLException.fillInStackTrace();
/* 4150 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void defineParameterTypeChars(int paramInt1, int paramInt2, int paramInt3) throws SQLException {
/* 4158 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 4159 */     sQLException.fillInStackTrace();
/* 4160 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void defineParameterType(int paramInt1, int paramInt2, int paramInt3) throws SQLException {
/* 4168 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 4169 */     sQLException.fillInStackTrace();
/* 4170 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public int getExecuteBatch() {
/* 4176 */     return -1;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int sendBatch() throws SQLException {
/* 4183 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 4184 */     sQLException.fillInStackTrace();
/* 4185 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setExecuteBatch(int paramInt) throws SQLException {
/* 4193 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 4194 */     sQLException.fillInStackTrace();
/* 4195 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setPlsqlIndexTable(int paramInt1, Object paramObject, int paramInt2, int paramInt3, int paramInt4, int paramInt5) throws SQLException {
/* 4203 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 4204 */     sQLException.fillInStackTrace();
/* 4205 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setFormOfUse(int paramInt, short paramShort) {}
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setDisableStmtCaching(boolean paramBoolean) {}
/*      */ 
/*      */ 
/*      */   
/*      */   public OracleParameterMetaData OracleGetParameterMetaData() throws SQLException {
/* 4221 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 4222 */     sQLException.fillInStackTrace();
/* 4223 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void registerReturnParameter(int paramInt1, int paramInt2) throws SQLException {
/* 4231 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 4232 */     sQLException.fillInStackTrace();
/* 4233 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void registerReturnParameter(int paramInt1, int paramInt2, int paramInt3) throws SQLException {
/* 4241 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 4242 */     sQLException.fillInStackTrace();
/* 4243 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void registerReturnParameter(int paramInt1, int paramInt2, String paramString) throws SQLException {
/* 4251 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 4252 */     sQLException.fillInStackTrace();
/* 4253 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBytesForBlob(int paramInt, byte[] paramArrayOfbyte) throws SQLException {
/* 4261 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 4262 */     sQLException.fillInStackTrace();
/* 4263 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBytesForBlobAtName(String paramString, byte[] paramArrayOfbyte) throws SQLException {
/* 4271 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 4272 */     sQLException.fillInStackTrace();
/* 4273 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setStringForClob(int paramInt, String paramString) throws SQLException {
/* 4282 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 4283 */     sQLException.fillInStackTrace();
/* 4284 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setStringForClobAtName(String paramString1, String paramString2) throws SQLException {
/* 4292 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 4293 */     sQLException.fillInStackTrace();
/* 4294 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setStructDescriptor(int paramInt, StructDescriptor paramStructDescriptor) throws SQLException {
/* 4303 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 4304 */     sQLException.fillInStackTrace();
/* 4305 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setStructDescriptor(String paramString, StructDescriptor paramStructDescriptor) throws SQLException {
/* 4314 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 4315 */     sQLException.fillInStackTrace();
/* 4316 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setStructDescriptorAtName(String paramString, StructDescriptor paramStructDescriptor) throws SQLException {
/* 4325 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 4326 */     sQLException.fillInStackTrace();
/* 4327 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Object getAnyDataEmbeddedObject(int paramInt) throws SQLException {
/* 4341 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 4342 */     sQLException.fillInStackTrace();
/* 4343 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void registerOutParameter(int paramInt1, int paramInt2, int paramInt3, int paramInt4) throws SQLException {
/* 4351 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 4352 */     sQLException.fillInStackTrace();
/* 4353 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void registerOutParameter(int paramInt1, int paramInt2, String paramString) throws SQLException {
/* 4361 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 4362 */     sQLException.fillInStackTrace();
/* 4363 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void registerOutParameter(int paramInt1, int paramInt2, int paramInt3) throws SQLException {
/* 4371 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 4372 */     sQLException.fillInStackTrace();
/* 4373 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void registerOutParameter(int paramInt1, int paramInt2) throws SQLException {
/* 4381 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 4382 */     sQLException.fillInStackTrace();
/* 4383 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void registerOutParameterBytes(int paramInt1, int paramInt2, int paramInt3, int paramInt4) throws SQLException {
/* 4391 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 4392 */     sQLException.fillInStackTrace();
/* 4393 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void registerOutParameterChars(int paramInt1, int paramInt2, int paramInt3, int paramInt4) throws SQLException {
/* 4401 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 4402 */     sQLException.fillInStackTrace();
/* 4403 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Object getPlsqlIndexTable(int paramInt) throws SQLException {
/* 4411 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 4412 */     sQLException.fillInStackTrace();
/* 4413 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Object getPlsqlIndexTable(int paramInt, Class paramClass) throws SQLException {
/* 4421 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 4422 */     sQLException.fillInStackTrace();
/* 4423 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Datum[] getOraclePlsqlIndexTable(int paramInt) throws SQLException {
/* 4431 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 4432 */     sQLException.fillInStackTrace();
/* 4433 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void registerIndexTableOutParameter(int paramInt1, int paramInt2, int paramInt3, int paramInt4) throws SQLException {
/* 4441 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 4442 */     sQLException.fillInStackTrace();
/* 4443 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setStringForClob(String paramString1, String paramString2) throws SQLException {
/* 4451 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 4452 */     sQLException.fillInStackTrace();
/* 4453 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBytesForBlob(String paramString, byte[] paramArrayOfbyte) throws SQLException {
/* 4461 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 4462 */     sQLException.fillInStackTrace();
/* 4463 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void registerOutParameter(String paramString, int paramInt1, int paramInt2, int paramInt3) throws SQLException {
/* 4471 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 4472 */     sQLException.fillInStackTrace();
/* 4473 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean wasNull() throws SQLException {
/* 4482 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 4483 */     sQLException.fillInStackTrace();
/* 4484 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void registerOutParameter(String paramString, int paramInt) throws SQLException {
/* 4492 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 4493 */     sQLException.fillInStackTrace();
/* 4494 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void registerOutParameter(String paramString, int paramInt1, int paramInt2) throws SQLException {
/* 4502 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 4503 */     sQLException.fillInStackTrace();
/* 4504 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void registerOutParameter(String paramString1, int paramInt, String paramString2) throws SQLException {
/* 4512 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 4513 */     sQLException.fillInStackTrace();
/* 4514 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void registerOutParameterAtName(String paramString, int paramInt) throws SQLException {
/* 4521 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 4522 */     sQLException.fillInStackTrace();
/* 4523 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void registerOutParameterAtName(String paramString, int paramInt1, int paramInt2) throws SQLException {
/* 4530 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 4531 */     sQLException.fillInStackTrace();
/* 4532 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void registerOutParameterAtName(String paramString1, int paramInt, String paramString2) throws SQLException {
/* 4539 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 4540 */     sQLException.fillInStackTrace();
/* 4541 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public byte[] privateGetBytes(int paramInt) throws SQLException {
/* 4551 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 4552 */     sQLException.fillInStackTrace();
/* 4553 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setDatabaseChangeRegistration(DatabaseChangeRegistration paramDatabaseChangeRegistration) throws SQLException {
/* 4562 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 4563 */     sQLException.fillInStackTrace();
/* 4564 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isClosed() throws SQLException {
/* 4575 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isPoolable() throws SQLException {
/* 4586 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void setPoolable(boolean paramBoolean) throws SQLException {
/* 4592 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 4593 */     sQLException.fillInStackTrace();
/* 4594 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isWrapperFor(Class<?> paramClass) throws SQLException {
/* 4615 */     if (paramClass.isInterface()) return paramClass.isInstance(this);
/*      */     
/* 4617 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 177);
/* 4618 */     sQLException.fillInStackTrace();
/* 4619 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <T> T unwrap(Class<T> paramClass) throws SQLException {
/* 4642 */     if (paramClass.isInterface() && paramClass.isInstance(this)) return (T)this;
/*      */     
/* 4644 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 177);
/* 4645 */     sQLException.fillInStackTrace();
/* 4646 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <T> T getObject(int paramInt, Class<T> paramClass) throws SQLException {
/* 4659 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 4660 */     sQLException.fillInStackTrace();
/* 4661 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <T> T getObject(String paramString, Class<T> paramClass) throws SQLException {
/* 4668 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 4669 */     sQLException.fillInStackTrace();
/* 4670 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isCloseOnCompletion() throws SQLException {
/* 4677 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 4678 */     sQLException.fillInStackTrace();
/* 4679 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void closeOnCompletion() throws SQLException {
/* 4686 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 4687 */     sQLException.fillInStackTrace();
/* 4688 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setFixedString(boolean paramBoolean) {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean getFixedString() {
/* 4707 */     return false;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean getserverCursor() {
/* 4712 */     return false;
/*      */   }
/*      */ 
/*      */   
/*      */   public int getcacheState() {
/* 4717 */     return 0;
/*      */   }
/*      */ 
/*      */   
/*      */   public int getstatementType() {
/* 4722 */     return 3;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setCheckBindTypes(boolean paramBoolean) {}
/*      */ 
/*      */ 
/*      */   
/*      */   public void setInternalBytes(int paramInt1, byte[] paramArrayOfbyte, int paramInt2) throws SQLException {
/* 4733 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 4734 */     sQLException.fillInStackTrace();
/* 4735 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void enterImplicitCache() throws SQLException {
/* 4743 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 4744 */     sQLException.fillInStackTrace();
/* 4745 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void enterExplicitCache() throws SQLException {
/* 4753 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 4754 */     sQLException.fillInStackTrace();
/* 4755 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void exitImplicitCacheToActive() throws SQLException {
/* 4763 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 4764 */     sQLException.fillInStackTrace();
/* 4765 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void exitExplicitCacheToActive() throws SQLException {
/* 4773 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 4774 */     sQLException.fillInStackTrace();
/* 4775 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void exitImplicitCacheToClose() throws SQLException {
/* 4783 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 4784 */     sQLException.fillInStackTrace();
/* 4785 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void exitExplicitCacheToClose() throws SQLException {
/* 4793 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 4794 */     sQLException.fillInStackTrace();
/* 4795 */     throw sQLException;
/*      */   }
/*      */ 
/*      */   
/*      */   public String[] getRegisteredTableNames() throws SQLException {
/* 4800 */     return null;
/*      */   }
/*      */   
/*      */   public long getRegisteredQueryId() throws SQLException {
/* 4804 */     return -1L;
/*      */   }
/*      */ 
/*      */   
/*      */   public String getOriginalSql() throws SQLException {
/* 4809 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 4810 */     sQLException.fillInStackTrace();
/* 4811 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setSnapshotSCN(long paramLong) throws SQLException {
/* 4818 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 4819 */     sQLException.fillInStackTrace();
/* 4820 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected OracleConnection getConnectionDuringExceptionHandling() {
/* 4835 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public OracleStatement.SqlKind getSqlKind() throws SQLException {
/* 4843 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 4844 */     sQLException.fillInStackTrace();
/* 4845 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public long getChecksum() throws SQLException {
/* 4854 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 4855 */     sQLException.fillInStackTrace();
/* 4856 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void registerBindChecksumListener(OracleStatement.BindChecksumListener paramBindChecksumListener) throws SQLException {
/* 4870 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 4871 */     sQLException.fillInStackTrace();
/* 4872 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setACProxy(Object paramObject) {
/* 4881 */     this.acProxy = paramObject;
/*      */   }
/*      */ 
/*      */   
/*      */   public Object getACProxy() {
/* 4886 */     return this.acProxy;
/*      */   }
/*      */ 
/*      */   
/* 4890 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*      */   public static final String BUILD_DATE = "Thu_Apr_04_15:09:24_PDT_2013";
/*      */   public static final boolean TRACE = false;
/*      */ }


/* Location:              C:\Users\olatu\OneDrive\Documents\Calypso\syncbase\sync_base.jar!\BOOT-INF\classes\ojdbc.jar!\oracle\jdbc\driver\OracleClosedStatement.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */