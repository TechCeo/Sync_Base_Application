/*       */ package oracle.jdbc.driver;
/*       */ 
/*       */ import java.io.InputStream;
/*       */ import java.io.Reader;
/*       */ import java.math.BigDecimal;
/*       */ import java.net.URL;
/*       */ import java.sql.Array;
/*       */ import java.sql.Blob;
/*       */ import java.sql.Clob;
/*       */ import java.sql.Date;
/*       */ import java.sql.NClob;
/*       */ import java.sql.Ref;
/*       */ import java.sql.ResultSet;
/*       */ import java.sql.RowId;
/*       */ import java.sql.SQLException;
/*       */ import java.sql.SQLXML;
/*       */ import java.sql.Time;
/*       */ import java.sql.Timestamp;
/*       */ import java.util.Calendar;
/*       */ import java.util.Map;
/*       */ import oracle.jdbc.OracleDataFactory;
/*       */ import oracle.jdbc.internal.OracleCallableStatement;
/*       */ import oracle.sql.ANYDATA;
/*       */ import oracle.sql.ARRAY;
/*       */ import oracle.sql.BFILE;
/*       */ import oracle.sql.BINARY_DOUBLE;
/*       */ import oracle.sql.BINARY_FLOAT;
/*       */ import oracle.sql.BLOB;
/*       */ import oracle.sql.CHAR;
/*       */ import oracle.sql.CLOB;
/*       */ import oracle.sql.CustomDatum;
/*       */ import oracle.sql.CustomDatumFactory;
/*       */ import oracle.sql.DATE;
/*       */ import oracle.sql.Datum;
/*       */ import oracle.sql.INTERVALDS;
/*       */ import oracle.sql.INTERVALYM;
/*       */ import oracle.sql.NUMBER;
/*       */ import oracle.sql.OPAQUE;
/*       */ import oracle.sql.ORAData;
/*       */ import oracle.sql.ORADataFactory;
/*       */ import oracle.sql.RAW;
/*       */ import oracle.sql.REF;
/*       */ import oracle.sql.ROWID;
/*       */ import oracle.sql.STRUCT;
/*       */ import oracle.sql.StructDescriptor;
/*       */ import oracle.sql.TIMESTAMP;
/*       */ import oracle.sql.TIMESTAMPLTZ;
/*       */ import oracle.sql.TIMESTAMPTZ;
/*       */ 
/*       */ abstract class OracleCallableStatement extends OraclePreparedStatement implements OracleCallableStatement {
/*       */   boolean atLeastOneOrdinalParameter = false;
/*       */   boolean atLeastOneNamedParameter = false;
/*    53 */   String[] namedParameters = new String[8];
/*       */ 
/*       */   
/*    56 */   int parameterCount = 0;
/*       */ 
/*       */   
/*    59 */   final String errMsgMixedBind = "Ordinal binding and Named binding cannot be combined!";
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   OracleCallableStatement(PhysicalConnection paramPhysicalConnection, String paramString, int paramInt1, int paramInt2) throws SQLException {
/*    80 */     this(paramPhysicalConnection, paramString, paramInt1, paramInt2, 1003, 1007);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   OracleCallableStatement(PhysicalConnection paramPhysicalConnection, String paramString, int paramInt1, int paramInt2, int paramInt3, int paramInt4) throws SQLException {
/*    98 */     super(paramPhysicalConnection, paramString, 1, paramInt2, paramInt3, paramInt4);
/*       */ 
/*       */     
/*   101 */     this.statementType = 2;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   void registerOutParameterInternal(int paramInt1, int paramInt2, int paramInt3, int paramInt4, String paramString) throws SQLException {
/*   114 */     ensureOpen();
/*   115 */     int i = paramInt1 - 1;
/*   116 */     if (i < 0 || paramInt1 > this.numberOfBindPositions) {
/*       */       
/*   118 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/*   119 */       sQLException.fillInStackTrace();
/*   120 */       throw sQLException;
/*       */     } 
/*       */     
/*   123 */     if (paramInt2 == 0) {
/*       */       
/*   125 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4);
/*   126 */       sQLException.fillInStackTrace();
/*   127 */       throw sQLException;
/*       */     } 
/*   129 */     int j = getInternalType(paramInt2);
/*       */     
/*   131 */     resetBatch();
/*   132 */     this.currentRowNeedToPrepareBinds = true;
/*       */     
/*   134 */     if (this.currentRowBindAccessors == null) {
/*   135 */       this.currentRowBindAccessors = new Accessor[this.numberOfBindPositions];
/*       */     }
/*       */     
/*   138 */     switch (paramInt2) {
/*       */       case -4:
/*       */       case -3:
/*       */       case -1:
/*       */       case 1:
/*       */       case 12:
/*       */       case 70:
/*       */         break;
/*       */ 
/*       */       
/*       */       case -16:
/*       */       case -15:
/*       */       case -9:
/*   151 */         this.currentRowFormOfUse[i] = 2;
/*       */         break;
/*       */       case 2011:
/*   154 */         paramInt4 = 0;
/*   155 */         this.currentRowFormOfUse[i] = 2;
/*       */         break;
/*       */       case 2009:
/*   158 */         paramInt4 = 0;
/*   159 */         paramString = "SYS.XMLTYPE";
/*       */         break;
/*       */       
/*       */       case 2002:
/*       */       case 2003:
/*   164 */         if (paramString == null || paramString.length() == 0) {
/*       */           
/*   166 */           SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 60, "empty Object name");
/*   167 */           sQLException.fillInStackTrace();
/*   168 */           throw sQLException;
/*       */         } 
/*       */ 
/*       */       
/*       */       default:
/*   173 */         paramInt4 = 0;
/*       */         break;
/*       */     } 
/*       */     
/*   177 */     this.currentRowBindAccessors[i] = allocateAccessor(j, paramInt2, i + 1, paramInt4, this.currentRowFormOfUse[i], paramString, true);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void registerOutParameter(int paramInt1, int paramInt2, String paramString) throws SQLException {
/*   216 */     if (paramString == null || paramString.length() == 0) {
/*       */       
/*   218 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 60, "empty Object name");
/*   219 */       sQLException.fillInStackTrace();
/*   220 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*   226 */     synchronized (this.connection) {
/*   227 */       registerOutParameterInternal(paramInt1, paramInt2, 0, 0, paramString);
/*   228 */       this.atLeastOneOrdinalParameter = true;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void registerOutParameterBytes(int paramInt1, int paramInt2, int paramInt3, int paramInt4) throws SQLException {
/*   257 */     synchronized (this.connection) {
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*   264 */       registerOutParameterInternal(paramInt1, paramInt2, paramInt3, paramInt4, (String)null);
/*   265 */       this.atLeastOneOrdinalParameter = true;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void registerOutParameterChars(int paramInt1, int paramInt2, int paramInt3, int paramInt4) throws SQLException {
/*   294 */     synchronized (this.connection) {
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*   301 */       registerOutParameterInternal(paramInt1, paramInt2, paramInt3, paramInt4, (String)null);
/*   302 */       this.atLeastOneOrdinalParameter = true;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void registerOutParameter(int paramInt1, int paramInt2, int paramInt3, int paramInt4) throws SQLException {
/*   319 */     synchronized (this.connection) {
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*   326 */       registerOutParameterInternal(paramInt1, paramInt2, paramInt3, paramInt4, (String)null);
/*   327 */       this.atLeastOneOrdinalParameter = true;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void registerOutParameter(String paramString, int paramInt1, int paramInt2, int paramInt3) throws SQLException {
/*   344 */     synchronized (this.connection) {
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*   351 */       registerOutParameterInternal(paramString, paramInt1, paramInt2, paramInt3, (String)null);
/*   352 */       this.atLeastOneNamedParameter = true;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void registerOutParameterAtName(String paramString, int paramInt) throws SQLException {
/*   369 */     String str = paramString.intern();
/*   370 */     String[] arrayOfString = this.sqlObject.getParameterList();
/*   371 */     int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*   372 */     boolean bool = true;
/*       */     
/*   374 */     for (byte b = 0; b < i; b++) {
/*       */       
/*   376 */       if (arrayOfString[b] == str)
/*       */       {
/*   378 */         if (bool) {
/*       */           
/*   380 */           registerOutParameter(b + 1, paramInt);
/*       */           
/*   382 */           bool = false;
/*       */         
/*       */         }
/*       */         else {
/*       */           
/*   387 */           SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 135);
/*   388 */           sQLException.fillInStackTrace();
/*   389 */           throw sQLException;
/*       */         } 
/*       */       }
/*       */     } 
/*       */     
/*   394 */     if (bool) {
/*       */       
/*   396 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/*   397 */       sQLException.fillInStackTrace();
/*   398 */       throw sQLException;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void registerOutParameterAtName(String paramString, int paramInt1, int paramInt2) throws SQLException {
/*   413 */     String str = paramString.intern();
/*   414 */     String[] arrayOfString = this.sqlObject.getParameterList();
/*   415 */     int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*   416 */     boolean bool = true;
/*       */     
/*   418 */     for (byte b = 0; b < i; b++) {
/*       */       
/*   420 */       if (arrayOfString[b] == str)
/*       */       {
/*   422 */         if (bool) {
/*       */           
/*   424 */           registerOutParameter(b + 1, paramInt1, paramInt2);
/*       */           
/*   426 */           bool = false;
/*       */         
/*       */         }
/*       */         else {
/*       */           
/*   431 */           SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 135);
/*   432 */           sQLException.fillInStackTrace();
/*   433 */           throw sQLException;
/*       */         } 
/*       */       }
/*       */     } 
/*       */     
/*   438 */     if (bool) {
/*       */       
/*   440 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/*   441 */       sQLException.fillInStackTrace();
/*   442 */       throw sQLException;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void registerOutParameterAtName(String paramString1, int paramInt, String paramString2) throws SQLException {
/*   456 */     String str = paramString1.intern();
/*   457 */     String[] arrayOfString = this.sqlObject.getParameterList();
/*   458 */     int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*   459 */     boolean bool = true;
/*       */     
/*   461 */     for (byte b = 0; b < i; b++) {
/*       */       
/*   463 */       if (arrayOfString[b] == str)
/*       */       {
/*   465 */         if (bool) {
/*       */           
/*   467 */           registerOutParameter(b + 1, paramInt, paramString2);
/*       */           
/*   469 */           bool = false;
/*       */         
/*       */         }
/*       */         else {
/*       */           
/*   474 */           SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 135);
/*   475 */           sQLException.fillInStackTrace();
/*   476 */           throw sQLException;
/*       */         } 
/*       */       }
/*       */     } 
/*       */     
/*   481 */     if (bool) {
/*       */       
/*   483 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString1);
/*   484 */       sQLException.fillInStackTrace();
/*   485 */       throw sQLException;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   boolean isOracleBatchStyle() {
/*   498 */     return false;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   void resetBatch() {
/*   508 */     this.batch = 1;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setExecuteBatch(int paramInt) throws SQLException {}
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public int sendBatch() throws SQLException {
/*   542 */     synchronized (this.connection) {
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*   550 */       return this.validRows;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void registerOutParameter(int paramInt1, int paramInt2) throws SQLException {
/*   574 */     registerOutParameter(paramInt1, paramInt2, 0, -1);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void registerOutParameter(int paramInt1, int paramInt2, int paramInt3) throws SQLException {
/*   591 */     registerOutParameter(paramInt1, paramInt2, paramInt3, -1);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public boolean wasNull() throws SQLException {
/*   604 */     return wasNullValue(0);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public String getString(int paramInt) throws SQLException {
/*   619 */     if (this.closed) {
/*       */       
/*   621 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*   622 */       sQLException.fillInStackTrace();
/*   623 */       throw sQLException;
/*       */     } 
/*       */     
/*   626 */     if (this.atLeastOneNamedParameter) {
/*       */ 
/*       */       
/*   629 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/*   630 */       sQLException.fillInStackTrace();
/*   631 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */     
/*   635 */     Accessor accessor = null;
/*   636 */     if (paramInt <= 0 || paramInt > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[paramInt - 1]) == null) {
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*   641 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/*   642 */       sQLException.fillInStackTrace();
/*   643 */       throw sQLException;
/*       */     } 
/*       */     
/*   646 */     this.lastIndex = paramInt;
/*       */     
/*   648 */     if (this.streamList != null) {
/*   649 */       closeUsedStreams(paramInt);
/*       */     }
/*       */     
/*   652 */     return accessor.getString(this.currentRank);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public Datum getOracleObject(int paramInt) throws SQLException {
/*   667 */     if (this.closed) {
/*       */       
/*   669 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*   670 */       sQLException.fillInStackTrace();
/*   671 */       throw sQLException;
/*       */     } 
/*       */     
/*   674 */     if (this.atLeastOneNamedParameter) {
/*       */ 
/*       */       
/*   677 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/*   678 */       sQLException.fillInStackTrace();
/*   679 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */     
/*   683 */     Accessor accessor = null;
/*   684 */     if (paramInt <= 0 || paramInt > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[paramInt - 1]) == null) {
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*   689 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/*   690 */       sQLException.fillInStackTrace();
/*   691 */       throw sQLException;
/*       */     } 
/*       */     
/*   694 */     this.lastIndex = paramInt;
/*       */     
/*   696 */     if (this.streamList != null) {
/*   697 */       closeUsedStreams(paramInt);
/*       */     }
/*       */     
/*   700 */     return accessor.getOracleObject(this.currentRank);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public ROWID getROWID(int paramInt) throws SQLException {
/*   715 */     if (this.closed) {
/*       */       
/*   717 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*   718 */       sQLException.fillInStackTrace();
/*   719 */       throw sQLException;
/*       */     } 
/*       */     
/*   722 */     if (this.atLeastOneNamedParameter) {
/*       */ 
/*       */       
/*   725 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/*   726 */       sQLException.fillInStackTrace();
/*   727 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */     
/*   731 */     Accessor accessor = null;
/*   732 */     if (paramInt <= 0 || paramInt > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[paramInt - 1]) == null) {
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*   737 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/*   738 */       sQLException.fillInStackTrace();
/*   739 */       throw sQLException;
/*       */     } 
/*       */     
/*   742 */     this.lastIndex = paramInt;
/*       */     
/*   744 */     if (this.streamList != null) {
/*   745 */       closeUsedStreams(paramInt);
/*       */     }
/*       */     
/*   748 */     return accessor.getROWID(this.currentRank);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public NUMBER getNUMBER(int paramInt) throws SQLException {
/*   763 */     if (this.closed) {
/*       */       
/*   765 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*   766 */       sQLException.fillInStackTrace();
/*   767 */       throw sQLException;
/*       */     } 
/*       */     
/*   770 */     if (this.atLeastOneNamedParameter) {
/*       */ 
/*       */       
/*   773 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/*   774 */       sQLException.fillInStackTrace();
/*   775 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */     
/*   779 */     Accessor accessor = null;
/*   780 */     if (paramInt <= 0 || paramInt > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[paramInt - 1]) == null) {
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*   785 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/*   786 */       sQLException.fillInStackTrace();
/*   787 */       throw sQLException;
/*       */     } 
/*       */     
/*   790 */     this.lastIndex = paramInt;
/*       */     
/*   792 */     if (this.streamList != null) {
/*   793 */       closeUsedStreams(paramInt);
/*       */     }
/*       */     
/*   796 */     return accessor.getNUMBER(this.currentRank);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public DATE getDATE(int paramInt) throws SQLException {
/*   811 */     if (this.closed) {
/*       */       
/*   813 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*   814 */       sQLException.fillInStackTrace();
/*   815 */       throw sQLException;
/*       */     } 
/*       */     
/*   818 */     if (this.atLeastOneNamedParameter) {
/*       */ 
/*       */       
/*   821 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/*   822 */       sQLException.fillInStackTrace();
/*   823 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */     
/*   827 */     Accessor accessor = null;
/*   828 */     if (paramInt <= 0 || paramInt > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[paramInt - 1]) == null) {
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*   833 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/*   834 */       sQLException.fillInStackTrace();
/*   835 */       throw sQLException;
/*       */     } 
/*       */     
/*   838 */     this.lastIndex = paramInt;
/*       */     
/*   840 */     if (this.streamList != null) {
/*   841 */       closeUsedStreams(paramInt);
/*       */     }
/*       */     
/*   844 */     return accessor.getDATE(this.currentRank);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public INTERVALYM getINTERVALYM(int paramInt) throws SQLException {
/*   859 */     if (this.closed) {
/*       */       
/*   861 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*   862 */       sQLException.fillInStackTrace();
/*   863 */       throw sQLException;
/*       */     } 
/*       */     
/*   866 */     if (this.atLeastOneNamedParameter) {
/*       */ 
/*       */       
/*   869 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/*   870 */       sQLException.fillInStackTrace();
/*   871 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */     
/*   875 */     Accessor accessor = null;
/*   876 */     if (paramInt <= 0 || paramInt > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[paramInt - 1]) == null) {
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*   881 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/*   882 */       sQLException.fillInStackTrace();
/*   883 */       throw sQLException;
/*       */     } 
/*       */     
/*   886 */     this.lastIndex = paramInt;
/*       */     
/*   888 */     if (this.streamList != null) {
/*   889 */       closeUsedStreams(paramInt);
/*       */     }
/*       */     
/*   892 */     return accessor.getINTERVALYM(this.currentRank);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public INTERVALDS getINTERVALDS(int paramInt) throws SQLException {
/*   907 */     if (this.closed) {
/*       */       
/*   909 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*   910 */       sQLException.fillInStackTrace();
/*   911 */       throw sQLException;
/*       */     } 
/*       */     
/*   914 */     if (this.atLeastOneNamedParameter) {
/*       */ 
/*       */       
/*   917 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/*   918 */       sQLException.fillInStackTrace();
/*   919 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */     
/*   923 */     Accessor accessor = null;
/*   924 */     if (paramInt <= 0 || paramInt > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[paramInt - 1]) == null) {
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*   929 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/*   930 */       sQLException.fillInStackTrace();
/*   931 */       throw sQLException;
/*       */     } 
/*       */     
/*   934 */     this.lastIndex = paramInt;
/*       */     
/*   936 */     if (this.streamList != null) {
/*   937 */       closeUsedStreams(paramInt);
/*       */     }
/*       */     
/*   940 */     return accessor.getINTERVALDS(this.currentRank);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public TIMESTAMP getTIMESTAMP(int paramInt) throws SQLException {
/*   955 */     if (this.closed) {
/*       */       
/*   957 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*   958 */       sQLException.fillInStackTrace();
/*   959 */       throw sQLException;
/*       */     } 
/*       */     
/*   962 */     if (this.atLeastOneNamedParameter) {
/*       */ 
/*       */       
/*   965 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/*   966 */       sQLException.fillInStackTrace();
/*   967 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */     
/*   971 */     Accessor accessor = null;
/*   972 */     if (paramInt <= 0 || paramInt > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[paramInt - 1]) == null) {
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*   977 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/*   978 */       sQLException.fillInStackTrace();
/*   979 */       throw sQLException;
/*       */     } 
/*       */     
/*   982 */     this.lastIndex = paramInt;
/*       */     
/*   984 */     if (this.streamList != null) {
/*   985 */       closeUsedStreams(paramInt);
/*       */     }
/*       */     
/*   988 */     return accessor.getTIMESTAMP(this.currentRank);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public TIMESTAMPTZ getTIMESTAMPTZ(int paramInt) throws SQLException {
/*  1003 */     if (this.closed) {
/*       */       
/*  1005 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  1006 */       sQLException.fillInStackTrace();
/*  1007 */       throw sQLException;
/*       */     } 
/*       */     
/*  1010 */     if (this.atLeastOneNamedParameter) {
/*       */ 
/*       */       
/*  1013 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/*  1014 */       sQLException.fillInStackTrace();
/*  1015 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */     
/*  1019 */     Accessor accessor = null;
/*  1020 */     if (paramInt <= 0 || paramInt > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[paramInt - 1]) == null) {
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*  1025 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/*  1026 */       sQLException.fillInStackTrace();
/*  1027 */       throw sQLException;
/*       */     } 
/*       */     
/*  1030 */     this.lastIndex = paramInt;
/*       */     
/*  1032 */     if (this.streamList != null) {
/*  1033 */       closeUsedStreams(paramInt);
/*       */     }
/*       */     
/*  1036 */     return accessor.getTIMESTAMPTZ(this.currentRank);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public TIMESTAMPLTZ getTIMESTAMPLTZ(int paramInt) throws SQLException {
/*  1051 */     if (this.closed) {
/*       */       
/*  1053 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  1054 */       sQLException.fillInStackTrace();
/*  1055 */       throw sQLException;
/*       */     } 
/*       */     
/*  1058 */     if (this.atLeastOneNamedParameter) {
/*       */ 
/*       */       
/*  1061 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/*  1062 */       sQLException.fillInStackTrace();
/*  1063 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */     
/*  1067 */     Accessor accessor = null;
/*  1068 */     if (paramInt <= 0 || paramInt > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[paramInt - 1]) == null) {
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*  1073 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/*  1074 */       sQLException.fillInStackTrace();
/*  1075 */       throw sQLException;
/*       */     } 
/*       */     
/*  1078 */     this.lastIndex = paramInt;
/*       */     
/*  1080 */     if (this.streamList != null) {
/*  1081 */       closeUsedStreams(paramInt);
/*       */     }
/*       */     
/*  1084 */     return accessor.getTIMESTAMPLTZ(this.currentRank);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public REF getREF(int paramInt) throws SQLException {
/*  1099 */     if (this.closed) {
/*       */       
/*  1101 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  1102 */       sQLException.fillInStackTrace();
/*  1103 */       throw sQLException;
/*       */     } 
/*       */     
/*  1106 */     if (this.atLeastOneNamedParameter) {
/*       */ 
/*       */       
/*  1109 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/*  1110 */       sQLException.fillInStackTrace();
/*  1111 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */     
/*  1115 */     Accessor accessor = null;
/*  1116 */     if (paramInt <= 0 || paramInt > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[paramInt - 1]) == null) {
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*  1121 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/*  1122 */       sQLException.fillInStackTrace();
/*  1123 */       throw sQLException;
/*       */     } 
/*       */     
/*  1126 */     this.lastIndex = paramInt;
/*       */     
/*  1128 */     if (this.streamList != null) {
/*  1129 */       closeUsedStreams(paramInt);
/*       */     }
/*       */     
/*  1132 */     return accessor.getREF(this.currentRank);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public ARRAY getARRAY(int paramInt) throws SQLException {
/*  1147 */     if (this.closed) {
/*       */       
/*  1149 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  1150 */       sQLException.fillInStackTrace();
/*  1151 */       throw sQLException;
/*       */     } 
/*       */     
/*  1154 */     if (this.atLeastOneNamedParameter) {
/*       */ 
/*       */       
/*  1157 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/*  1158 */       sQLException.fillInStackTrace();
/*  1159 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */     
/*  1163 */     Accessor accessor = null;
/*  1164 */     if (paramInt <= 0 || paramInt > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[paramInt - 1]) == null) {
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*  1169 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/*  1170 */       sQLException.fillInStackTrace();
/*  1171 */       throw sQLException;
/*       */     } 
/*       */     
/*  1174 */     this.lastIndex = paramInt;
/*       */     
/*  1176 */     if (this.streamList != null) {
/*  1177 */       closeUsedStreams(paramInt);
/*       */     }
/*       */     
/*  1180 */     return accessor.getARRAY(this.currentRank);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public STRUCT getSTRUCT(int paramInt) throws SQLException {
/*  1195 */     if (this.closed) {
/*       */       
/*  1197 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  1198 */       sQLException.fillInStackTrace();
/*  1199 */       throw sQLException;
/*       */     } 
/*       */     
/*  1202 */     if (this.atLeastOneNamedParameter) {
/*       */ 
/*       */       
/*  1205 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/*  1206 */       sQLException.fillInStackTrace();
/*  1207 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */     
/*  1211 */     Accessor accessor = null;
/*  1212 */     if (paramInt <= 0 || paramInt > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[paramInt - 1]) == null) {
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*  1217 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/*  1218 */       sQLException.fillInStackTrace();
/*  1219 */       throw sQLException;
/*       */     } 
/*       */     
/*  1222 */     this.lastIndex = paramInt;
/*       */     
/*  1224 */     if (this.streamList != null) {
/*  1225 */       closeUsedStreams(paramInt);
/*       */     }
/*       */     
/*  1228 */     return accessor.getSTRUCT(this.currentRank);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public OPAQUE getOPAQUE(int paramInt) throws SQLException {
/*  1243 */     if (this.closed) {
/*       */       
/*  1245 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  1246 */       sQLException.fillInStackTrace();
/*  1247 */       throw sQLException;
/*       */     } 
/*       */     
/*  1250 */     if (this.atLeastOneNamedParameter) {
/*       */ 
/*       */       
/*  1253 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/*  1254 */       sQLException.fillInStackTrace();
/*  1255 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */     
/*  1259 */     Accessor accessor = null;
/*  1260 */     if (paramInt <= 0 || paramInt > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[paramInt - 1]) == null) {
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*  1265 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/*  1266 */       sQLException.fillInStackTrace();
/*  1267 */       throw sQLException;
/*       */     } 
/*       */     
/*  1270 */     this.lastIndex = paramInt;
/*       */     
/*  1272 */     if (this.streamList != null) {
/*  1273 */       closeUsedStreams(paramInt);
/*       */     }
/*       */     
/*  1276 */     return accessor.getOPAQUE(this.currentRank);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public CHAR getCHAR(int paramInt) throws SQLException {
/*  1291 */     if (this.closed) {
/*       */       
/*  1293 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  1294 */       sQLException.fillInStackTrace();
/*  1295 */       throw sQLException;
/*       */     } 
/*       */     
/*  1298 */     if (this.atLeastOneNamedParameter) {
/*       */ 
/*       */       
/*  1301 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/*  1302 */       sQLException.fillInStackTrace();
/*  1303 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */     
/*  1307 */     Accessor accessor = null;
/*  1308 */     if (paramInt <= 0 || paramInt > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[paramInt - 1]) == null) {
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*  1313 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/*  1314 */       sQLException.fillInStackTrace();
/*  1315 */       throw sQLException;
/*       */     } 
/*       */     
/*  1318 */     this.lastIndex = paramInt;
/*       */     
/*  1320 */     if (this.streamList != null) {
/*  1321 */       closeUsedStreams(paramInt);
/*       */     }
/*       */     
/*  1324 */     return accessor.getCHAR(this.currentRank);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public Reader getCharacterStream(int paramInt) throws SQLException {
/*  1340 */     if (this.closed) {
/*       */       
/*  1342 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  1343 */       sQLException.fillInStackTrace();
/*  1344 */       throw sQLException;
/*       */     } 
/*       */     
/*  1347 */     if (this.atLeastOneNamedParameter) {
/*       */ 
/*       */       
/*  1350 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/*  1351 */       sQLException.fillInStackTrace();
/*  1352 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */     
/*  1356 */     Accessor accessor = null;
/*  1357 */     if (paramInt <= 0 || paramInt > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[paramInt - 1]) == null) {
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*  1362 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/*  1363 */       sQLException.fillInStackTrace();
/*  1364 */       throw sQLException;
/*       */     } 
/*       */     
/*  1367 */     this.lastIndex = paramInt;
/*       */     
/*  1369 */     if (this.streamList != null) {
/*  1370 */       closeUsedStreams(paramInt);
/*       */     }
/*       */     
/*  1373 */     return accessor.getCharacterStream(this.currentRank);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public RAW getRAW(int paramInt) throws SQLException {
/*  1388 */     if (this.closed) {
/*       */       
/*  1390 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  1391 */       sQLException.fillInStackTrace();
/*  1392 */       throw sQLException;
/*       */     } 
/*       */     
/*  1395 */     if (this.atLeastOneNamedParameter) {
/*       */ 
/*       */       
/*  1398 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/*  1399 */       sQLException.fillInStackTrace();
/*  1400 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */     
/*  1404 */     Accessor accessor = null;
/*  1405 */     if (paramInt <= 0 || paramInt > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[paramInt - 1]) == null) {
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*  1410 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/*  1411 */       sQLException.fillInStackTrace();
/*  1412 */       throw sQLException;
/*       */     } 
/*       */     
/*  1415 */     this.lastIndex = paramInt;
/*       */     
/*  1417 */     if (this.streamList != null) {
/*  1418 */       closeUsedStreams(paramInt);
/*       */     }
/*       */     
/*  1421 */     return accessor.getRAW(this.currentRank);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public BLOB getBLOB(int paramInt) throws SQLException {
/*  1437 */     if (this.closed) {
/*       */       
/*  1439 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  1440 */       sQLException.fillInStackTrace();
/*  1441 */       throw sQLException;
/*       */     } 
/*       */     
/*  1444 */     if (this.atLeastOneNamedParameter) {
/*       */ 
/*       */       
/*  1447 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/*  1448 */       sQLException.fillInStackTrace();
/*  1449 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */     
/*  1453 */     Accessor accessor = null;
/*  1454 */     if (paramInt <= 0 || paramInt > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[paramInt - 1]) == null) {
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*  1459 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/*  1460 */       sQLException.fillInStackTrace();
/*  1461 */       throw sQLException;
/*       */     } 
/*       */     
/*  1464 */     this.lastIndex = paramInt;
/*       */     
/*  1466 */     if (this.streamList != null) {
/*  1467 */       closeUsedStreams(paramInt);
/*       */     }
/*       */     
/*  1470 */     return accessor.getBLOB(this.currentRank);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public CLOB getCLOB(int paramInt) throws SQLException {
/*  1485 */     if (this.closed) {
/*       */       
/*  1487 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  1488 */       sQLException.fillInStackTrace();
/*  1489 */       throw sQLException;
/*       */     } 
/*       */     
/*  1492 */     if (this.atLeastOneNamedParameter) {
/*       */ 
/*       */       
/*  1495 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/*  1496 */       sQLException.fillInStackTrace();
/*  1497 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */     
/*  1501 */     Accessor accessor = null;
/*  1502 */     if (paramInt <= 0 || paramInt > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[paramInt - 1]) == null) {
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*  1507 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/*  1508 */       sQLException.fillInStackTrace();
/*  1509 */       throw sQLException;
/*       */     } 
/*       */     
/*  1512 */     this.lastIndex = paramInt;
/*       */     
/*  1514 */     if (this.streamList != null) {
/*  1515 */       closeUsedStreams(paramInt);
/*       */     }
/*       */     
/*  1518 */     return accessor.getCLOB(this.currentRank);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public BFILE getBFILE(int paramInt) throws SQLException {
/*  1533 */     if (this.closed) {
/*       */       
/*  1535 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  1536 */       sQLException.fillInStackTrace();
/*  1537 */       throw sQLException;
/*       */     } 
/*       */     
/*  1540 */     if (this.atLeastOneNamedParameter) {
/*       */ 
/*       */       
/*  1543 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/*  1544 */       sQLException.fillInStackTrace();
/*  1545 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */     
/*  1549 */     Accessor accessor = null;
/*  1550 */     if (paramInt <= 0 || paramInt > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[paramInt - 1]) == null) {
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*  1555 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/*  1556 */       sQLException.fillInStackTrace();
/*  1557 */       throw sQLException;
/*       */     } 
/*       */     
/*  1560 */     this.lastIndex = paramInt;
/*       */     
/*  1562 */     if (this.streamList != null) {
/*  1563 */       closeUsedStreams(paramInt);
/*       */     }
/*       */     
/*  1566 */     return accessor.getBFILE(this.currentRank);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public BFILE getBfile(int paramInt) throws SQLException {
/*  1581 */     if (this.closed) {
/*       */       
/*  1583 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  1584 */       sQLException.fillInStackTrace();
/*  1585 */       throw sQLException;
/*       */     } 
/*       */     
/*  1588 */     if (this.atLeastOneNamedParameter) {
/*       */ 
/*       */       
/*  1591 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/*  1592 */       sQLException.fillInStackTrace();
/*  1593 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */     
/*  1597 */     Accessor accessor = null;
/*  1598 */     if (paramInt <= 0 || paramInt > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[paramInt - 1]) == null) {
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*  1603 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/*  1604 */       sQLException.fillInStackTrace();
/*  1605 */       throw sQLException;
/*       */     } 
/*       */     
/*  1608 */     this.lastIndex = paramInt;
/*       */     
/*  1610 */     if (this.streamList != null) {
/*  1611 */       closeUsedStreams(paramInt);
/*       */     }
/*       */     
/*  1614 */     return accessor.getBFILE(this.currentRank);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public boolean getBoolean(int paramInt) throws SQLException {
/*  1629 */     if (this.closed) {
/*       */       
/*  1631 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  1632 */       sQLException.fillInStackTrace();
/*  1633 */       throw sQLException;
/*       */     } 
/*       */     
/*  1636 */     if (this.atLeastOneNamedParameter) {
/*       */ 
/*       */       
/*  1639 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/*  1640 */       sQLException.fillInStackTrace();
/*  1641 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */     
/*  1645 */     Accessor accessor = null;
/*  1646 */     if (paramInt <= 0 || paramInt > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[paramInt - 1]) == null) {
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*  1651 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/*  1652 */       sQLException.fillInStackTrace();
/*  1653 */       throw sQLException;
/*       */     } 
/*       */     
/*  1656 */     this.lastIndex = paramInt;
/*       */     
/*  1658 */     if (this.streamList != null) {
/*  1659 */       closeUsedStreams(paramInt);
/*       */     }
/*       */     
/*  1662 */     return accessor.getBoolean(this.currentRank);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public byte getByte(int paramInt) throws SQLException {
/*  1677 */     if (this.closed) {
/*       */       
/*  1679 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  1680 */       sQLException.fillInStackTrace();
/*  1681 */       throw sQLException;
/*       */     } 
/*       */     
/*  1684 */     if (this.atLeastOneNamedParameter) {
/*       */ 
/*       */       
/*  1687 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/*  1688 */       sQLException.fillInStackTrace();
/*  1689 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */     
/*  1693 */     Accessor accessor = null;
/*  1694 */     if (paramInt <= 0 || paramInt > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[paramInt - 1]) == null) {
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*  1699 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/*  1700 */       sQLException.fillInStackTrace();
/*  1701 */       throw sQLException;
/*       */     } 
/*       */     
/*  1704 */     this.lastIndex = paramInt;
/*       */     
/*  1706 */     if (this.streamList != null) {
/*  1707 */       closeUsedStreams(paramInt);
/*       */     }
/*       */     
/*  1710 */     return accessor.getByte(this.currentRank);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public short getShort(int paramInt) throws SQLException {
/*  1725 */     if (this.closed) {
/*       */       
/*  1727 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  1728 */       sQLException.fillInStackTrace();
/*  1729 */       throw sQLException;
/*       */     } 
/*       */     
/*  1732 */     if (this.atLeastOneNamedParameter) {
/*       */ 
/*       */       
/*  1735 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/*  1736 */       sQLException.fillInStackTrace();
/*  1737 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */     
/*  1741 */     Accessor accessor = null;
/*  1742 */     if (paramInt <= 0 || paramInt > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[paramInt - 1]) == null) {
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*  1747 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/*  1748 */       sQLException.fillInStackTrace();
/*  1749 */       throw sQLException;
/*       */     } 
/*       */     
/*  1752 */     this.lastIndex = paramInt;
/*       */     
/*  1754 */     if (this.streamList != null) {
/*  1755 */       closeUsedStreams(paramInt);
/*       */     }
/*       */     
/*  1758 */     return accessor.getShort(this.currentRank);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public int getInt(int paramInt) throws SQLException {
/*  1773 */     if (this.closed) {
/*       */       
/*  1775 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  1776 */       sQLException.fillInStackTrace();
/*  1777 */       throw sQLException;
/*       */     } 
/*       */     
/*  1780 */     if (this.atLeastOneNamedParameter) {
/*       */ 
/*       */       
/*  1783 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/*  1784 */       sQLException.fillInStackTrace();
/*  1785 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */     
/*  1789 */     Accessor accessor = null;
/*  1790 */     if (paramInt <= 0 || paramInt > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[paramInt - 1]) == null) {
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*  1795 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/*  1796 */       sQLException.fillInStackTrace();
/*  1797 */       throw sQLException;
/*       */     } 
/*       */     
/*  1800 */     this.lastIndex = paramInt;
/*       */     
/*  1802 */     if (this.streamList != null) {
/*  1803 */       closeUsedStreams(paramInt);
/*       */     }
/*       */     
/*  1806 */     return accessor.getInt(this.currentRank);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public long getLong(int paramInt) throws SQLException {
/*  1821 */     if (this.closed) {
/*       */       
/*  1823 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  1824 */       sQLException.fillInStackTrace();
/*  1825 */       throw sQLException;
/*       */     } 
/*       */     
/*  1828 */     if (this.atLeastOneNamedParameter) {
/*       */ 
/*       */       
/*  1831 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/*  1832 */       sQLException.fillInStackTrace();
/*  1833 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */     
/*  1837 */     Accessor accessor = null;
/*  1838 */     if (paramInt <= 0 || paramInt > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[paramInt - 1]) == null) {
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*  1843 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/*  1844 */       sQLException.fillInStackTrace();
/*  1845 */       throw sQLException;
/*       */     } 
/*       */     
/*  1848 */     this.lastIndex = paramInt;
/*       */     
/*  1850 */     if (this.streamList != null) {
/*  1851 */       closeUsedStreams(paramInt);
/*       */     }
/*       */     
/*  1854 */     return accessor.getLong(this.currentRank);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public float getFloat(int paramInt) throws SQLException {
/*  1869 */     if (this.closed) {
/*       */       
/*  1871 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  1872 */       sQLException.fillInStackTrace();
/*  1873 */       throw sQLException;
/*       */     } 
/*       */     
/*  1876 */     if (this.atLeastOneNamedParameter) {
/*       */ 
/*       */       
/*  1879 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/*  1880 */       sQLException.fillInStackTrace();
/*  1881 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */     
/*  1885 */     Accessor accessor = null;
/*  1886 */     if (paramInt <= 0 || paramInt > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[paramInt - 1]) == null) {
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*  1891 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/*  1892 */       sQLException.fillInStackTrace();
/*  1893 */       throw sQLException;
/*       */     } 
/*       */     
/*  1896 */     this.lastIndex = paramInt;
/*       */     
/*  1898 */     if (this.streamList != null) {
/*  1899 */       closeUsedStreams(paramInt);
/*       */     }
/*       */     
/*  1902 */     return accessor.getFloat(this.currentRank);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public double getDouble(int paramInt) throws SQLException {
/*  1917 */     if (this.closed) {
/*       */       
/*  1919 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  1920 */       sQLException.fillInStackTrace();
/*  1921 */       throw sQLException;
/*       */     } 
/*       */     
/*  1924 */     if (this.atLeastOneNamedParameter) {
/*       */ 
/*       */       
/*  1927 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/*  1928 */       sQLException.fillInStackTrace();
/*  1929 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */     
/*  1933 */     Accessor accessor = null;
/*  1934 */     if (paramInt <= 0 || paramInt > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[paramInt - 1]) == null) {
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*  1939 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/*  1940 */       sQLException.fillInStackTrace();
/*  1941 */       throw sQLException;
/*       */     } 
/*       */     
/*  1944 */     this.lastIndex = paramInt;
/*       */     
/*  1946 */     if (this.streamList != null) {
/*  1947 */       closeUsedStreams(paramInt);
/*       */     }
/*       */     
/*  1950 */     return accessor.getDouble(this.currentRank);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public BigDecimal getBigDecimal(int paramInt1, int paramInt2) throws SQLException {
/*  1965 */     if (this.closed) {
/*       */       
/*  1967 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  1968 */       sQLException.fillInStackTrace();
/*  1969 */       throw sQLException;
/*       */     } 
/*       */     
/*  1972 */     if (this.atLeastOneNamedParameter) {
/*       */ 
/*       */       
/*  1975 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/*  1976 */       sQLException.fillInStackTrace();
/*  1977 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */     
/*  1981 */     Accessor accessor = null;
/*  1982 */     if (paramInt1 <= 0 || paramInt1 > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[paramInt1 - 1]) == null) {
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*  1987 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/*  1988 */       sQLException.fillInStackTrace();
/*  1989 */       throw sQLException;
/*       */     } 
/*       */     
/*  1992 */     this.lastIndex = paramInt1;
/*       */     
/*  1994 */     if (this.streamList != null) {
/*  1995 */       closeUsedStreams(paramInt1);
/*       */     }
/*       */     
/*  1998 */     return accessor.getBigDecimal(this.currentRank);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public byte[] getBytes(int paramInt) throws SQLException {
/*  2013 */     if (this.closed) {
/*       */       
/*  2015 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  2016 */       sQLException.fillInStackTrace();
/*  2017 */       throw sQLException;
/*       */     } 
/*       */     
/*  2020 */     if (this.atLeastOneNamedParameter) {
/*       */ 
/*       */       
/*  2023 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/*  2024 */       sQLException.fillInStackTrace();
/*  2025 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */     
/*  2029 */     Accessor accessor = null;
/*  2030 */     if (paramInt <= 0 || paramInt > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[paramInt - 1]) == null) {
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*  2035 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/*  2036 */       sQLException.fillInStackTrace();
/*  2037 */       throw sQLException;
/*       */     } 
/*       */     
/*  2040 */     this.lastIndex = paramInt;
/*       */     
/*  2042 */     if (this.streamList != null) {
/*  2043 */       closeUsedStreams(paramInt);
/*       */     }
/*       */     
/*  2046 */     return accessor.getBytes(this.currentRank);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public byte[] privateGetBytes(int paramInt) throws SQLException {
/*  2056 */     if (this.closed) {
/*       */       
/*  2058 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  2059 */       sQLException.fillInStackTrace();
/*  2060 */       throw sQLException;
/*       */     } 
/*       */     
/*  2063 */     if (this.atLeastOneNamedParameter) {
/*       */ 
/*       */       
/*  2066 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/*  2067 */       sQLException.fillInStackTrace();
/*  2068 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */     
/*  2072 */     Accessor accessor = null;
/*  2073 */     if (paramInt <= 0 || paramInt > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[paramInt - 1]) == null) {
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*  2078 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/*  2079 */       sQLException.fillInStackTrace();
/*  2080 */       throw sQLException;
/*       */     } 
/*       */     
/*  2083 */     this.lastIndex = paramInt;
/*       */     
/*  2085 */     if (this.streamList != null) {
/*  2086 */       closeUsedStreams(paramInt);
/*       */     }
/*       */     
/*  2089 */     return accessor.getBytesInternal(this.currentRank);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public Date getDate(int paramInt) throws SQLException {
/*  2104 */     if (this.closed) {
/*       */       
/*  2106 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  2107 */       sQLException.fillInStackTrace();
/*  2108 */       throw sQLException;
/*       */     } 
/*       */     
/*  2111 */     if (this.atLeastOneNamedParameter) {
/*       */ 
/*       */       
/*  2114 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/*  2115 */       sQLException.fillInStackTrace();
/*  2116 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */     
/*  2120 */     Accessor accessor = null;
/*  2121 */     if (paramInt <= 0 || paramInt > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[paramInt - 1]) == null) {
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*  2126 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/*  2127 */       sQLException.fillInStackTrace();
/*  2128 */       throw sQLException;
/*       */     } 
/*       */     
/*  2131 */     this.lastIndex = paramInt;
/*       */     
/*  2133 */     if (this.streamList != null) {
/*  2134 */       closeUsedStreams(paramInt);
/*       */     }
/*       */     
/*  2137 */     return accessor.getDate(this.currentRank);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public Time getTime(int paramInt) throws SQLException {
/*  2152 */     if (this.closed) {
/*       */       
/*  2154 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  2155 */       sQLException.fillInStackTrace();
/*  2156 */       throw sQLException;
/*       */     } 
/*       */     
/*  2159 */     if (this.atLeastOneNamedParameter) {
/*       */ 
/*       */       
/*  2162 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/*  2163 */       sQLException.fillInStackTrace();
/*  2164 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */     
/*  2168 */     Accessor accessor = null;
/*  2169 */     if (paramInt <= 0 || paramInt > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[paramInt - 1]) == null) {
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*  2174 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/*  2175 */       sQLException.fillInStackTrace();
/*  2176 */       throw sQLException;
/*       */     } 
/*       */     
/*  2179 */     this.lastIndex = paramInt;
/*       */     
/*  2181 */     if (this.streamList != null) {
/*  2182 */       closeUsedStreams(paramInt);
/*       */     }
/*       */     
/*  2185 */     return accessor.getTime(this.currentRank);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public Timestamp getTimestamp(int paramInt) throws SQLException {
/*  2200 */     if (this.closed) {
/*       */       
/*  2202 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  2203 */       sQLException.fillInStackTrace();
/*  2204 */       throw sQLException;
/*       */     } 
/*       */     
/*  2207 */     if (this.atLeastOneNamedParameter) {
/*       */ 
/*       */       
/*  2210 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/*  2211 */       sQLException.fillInStackTrace();
/*  2212 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */     
/*  2216 */     Accessor accessor = null;
/*  2217 */     if (paramInt <= 0 || paramInt > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[paramInt - 1]) == null) {
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*  2222 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/*  2223 */       sQLException.fillInStackTrace();
/*  2224 */       throw sQLException;
/*       */     } 
/*       */     
/*  2227 */     this.lastIndex = paramInt;
/*       */     
/*  2229 */     if (this.streamList != null) {
/*  2230 */       closeUsedStreams(paramInt);
/*       */     }
/*       */     
/*  2233 */     return accessor.getTimestamp(this.currentRank);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public InputStream getAsciiStream(int paramInt) throws SQLException {
/*  2248 */     if (this.closed) {
/*       */       
/*  2250 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  2251 */       sQLException.fillInStackTrace();
/*  2252 */       throw sQLException;
/*       */     } 
/*       */     
/*  2255 */     if (this.atLeastOneNamedParameter) {
/*       */ 
/*       */       
/*  2258 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/*  2259 */       sQLException.fillInStackTrace();
/*  2260 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */     
/*  2264 */     Accessor accessor = null;
/*  2265 */     if (paramInt <= 0 || paramInt > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[paramInt - 1]) == null) {
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*  2270 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/*  2271 */       sQLException.fillInStackTrace();
/*  2272 */       throw sQLException;
/*       */     } 
/*       */     
/*  2275 */     this.lastIndex = paramInt;
/*       */     
/*  2277 */     if (this.streamList != null) {
/*  2278 */       closeUsedStreams(paramInt);
/*       */     }
/*       */     
/*  2281 */     return accessor.getAsciiStream(this.currentRank);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public InputStream getUnicodeStream(int paramInt) throws SQLException {
/*  2296 */     if (this.closed) {
/*       */       
/*  2298 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  2299 */       sQLException.fillInStackTrace();
/*  2300 */       throw sQLException;
/*       */     } 
/*       */     
/*  2303 */     if (this.atLeastOneNamedParameter) {
/*       */ 
/*       */       
/*  2306 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/*  2307 */       sQLException.fillInStackTrace();
/*  2308 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */     
/*  2312 */     Accessor accessor = null;
/*  2313 */     if (paramInt <= 0 || paramInt > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[paramInt - 1]) == null) {
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*  2318 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/*  2319 */       sQLException.fillInStackTrace();
/*  2320 */       throw sQLException;
/*       */     } 
/*       */     
/*  2323 */     this.lastIndex = paramInt;
/*       */     
/*  2325 */     if (this.streamList != null) {
/*  2326 */       closeUsedStreams(paramInt);
/*       */     }
/*       */     
/*  2329 */     return accessor.getUnicodeStream(this.currentRank);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public InputStream getBinaryStream(int paramInt) throws SQLException {
/*  2344 */     if (this.closed) {
/*       */       
/*  2346 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  2347 */       sQLException.fillInStackTrace();
/*  2348 */       throw sQLException;
/*       */     } 
/*       */     
/*  2351 */     if (this.atLeastOneNamedParameter) {
/*       */ 
/*       */       
/*  2354 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/*  2355 */       sQLException.fillInStackTrace();
/*  2356 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */     
/*  2360 */     Accessor accessor = null;
/*  2361 */     if (paramInt <= 0 || paramInt > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[paramInt - 1]) == null) {
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*  2366 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/*  2367 */       sQLException.fillInStackTrace();
/*  2368 */       throw sQLException;
/*       */     } 
/*       */     
/*  2371 */     this.lastIndex = paramInt;
/*       */     
/*  2373 */     if (this.streamList != null) {
/*  2374 */       closeUsedStreams(paramInt);
/*       */     }
/*       */     
/*  2377 */     return accessor.getBinaryStream(this.currentRank);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public Object getObject(int paramInt) throws SQLException {
/*  2392 */     if (this.closed) {
/*       */       
/*  2394 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  2395 */       sQLException.fillInStackTrace();
/*  2396 */       throw sQLException;
/*       */     } 
/*       */     
/*  2399 */     if (this.atLeastOneNamedParameter) {
/*       */ 
/*       */       
/*  2402 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/*  2403 */       sQLException.fillInStackTrace();
/*  2404 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */     
/*  2408 */     Accessor accessor = null;
/*  2409 */     if (paramInt <= 0 || paramInt > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[paramInt - 1]) == null) {
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*  2414 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/*  2415 */       sQLException.fillInStackTrace();
/*  2416 */       throw sQLException;
/*       */     } 
/*       */     
/*  2419 */     this.lastIndex = paramInt;
/*       */     
/*  2421 */     if (this.streamList != null) {
/*  2422 */       closeUsedStreams(paramInt);
/*       */     }
/*       */     
/*  2425 */     return accessor.getObject(this.currentRank);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public Object getAnyDataEmbeddedObject(int paramInt) throws SQLException {
/*  2439 */     Object object1 = null;
/*  2440 */     Object object2 = getObject(paramInt);
/*  2441 */     if (object2 instanceof ANYDATA) {
/*       */       
/*  2443 */       Datum datum = ((ANYDATA)object2).accessDatum();
/*  2444 */       if (datum != null) object1 = datum.toJdbc(); 
/*       */     } 
/*  2446 */     return object1;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public Object getCustomDatum(int paramInt, CustomDatumFactory paramCustomDatumFactory) throws SQLException {
/*  2461 */     if (this.closed) {
/*       */       
/*  2463 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  2464 */       sQLException.fillInStackTrace();
/*  2465 */       throw sQLException;
/*       */     } 
/*       */     
/*  2468 */     if (this.atLeastOneNamedParameter) {
/*       */ 
/*       */       
/*  2471 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/*  2472 */       sQLException.fillInStackTrace();
/*  2473 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */     
/*  2477 */     Accessor accessor = null;
/*  2478 */     if (paramInt <= 0 || paramInt > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[paramInt - 1]) == null) {
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*  2483 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/*  2484 */       sQLException.fillInStackTrace();
/*  2485 */       throw sQLException;
/*       */     } 
/*       */     
/*  2488 */     this.lastIndex = paramInt;
/*       */     
/*  2490 */     if (this.streamList != null) {
/*  2491 */       closeUsedStreams(paramInt);
/*       */     }
/*       */     
/*  2494 */     return accessor.getCustomDatum(this.currentRank, paramCustomDatumFactory);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public Object getObject(int paramInt, OracleDataFactory paramOracleDataFactory) throws SQLException {
/*  2508 */     if (this.closed) {
/*       */       
/*  2510 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  2511 */       sQLException.fillInStackTrace();
/*  2512 */       throw sQLException;
/*       */     } 
/*       */     
/*  2515 */     if (this.atLeastOneNamedParameter) {
/*       */ 
/*       */       
/*  2518 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/*  2519 */       sQLException.fillInStackTrace();
/*  2520 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */     
/*  2524 */     Accessor accessor = null;
/*  2525 */     if (paramInt <= 0 || paramInt > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[paramInt - 1]) == null) {
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*  2530 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/*  2531 */       sQLException.fillInStackTrace();
/*  2532 */       throw sQLException;
/*       */     } 
/*       */     
/*  2535 */     this.lastIndex = paramInt;
/*       */     
/*  2537 */     if (this.streamList != null) {
/*  2538 */       closeUsedStreams(paramInt);
/*       */     }
/*  2540 */     return accessor.getObject(this.currentRank, paramOracleDataFactory);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public Object getORAData(int paramInt, ORADataFactory paramORADataFactory) throws SQLException {
/*  2555 */     if (this.closed) {
/*       */       
/*  2557 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  2558 */       sQLException.fillInStackTrace();
/*  2559 */       throw sQLException;
/*       */     } 
/*       */     
/*  2562 */     if (this.atLeastOneNamedParameter) {
/*       */ 
/*       */       
/*  2565 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/*  2566 */       sQLException.fillInStackTrace();
/*  2567 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */     
/*  2571 */     Accessor accessor = null;
/*  2572 */     if (paramInt <= 0 || paramInt > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[paramInt - 1]) == null) {
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*  2577 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/*  2578 */       sQLException.fillInStackTrace();
/*  2579 */       throw sQLException;
/*       */     } 
/*       */     
/*  2582 */     this.lastIndex = paramInt;
/*       */     
/*  2584 */     if (this.streamList != null) {
/*  2585 */       closeUsedStreams(paramInt);
/*       */     }
/*       */     
/*  2588 */     return accessor.getORAData(this.currentRank, paramORADataFactory);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public ResultSet getCursor(int paramInt) throws SQLException {
/*  2603 */     if (this.closed) {
/*       */       
/*  2605 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  2606 */       sQLException.fillInStackTrace();
/*  2607 */       throw sQLException;
/*       */     } 
/*       */     
/*  2610 */     if (this.atLeastOneNamedParameter) {
/*       */ 
/*       */       
/*  2613 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/*  2614 */       sQLException.fillInStackTrace();
/*  2615 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */     
/*  2619 */     Accessor accessor = null;
/*  2620 */     if (paramInt <= 0 || paramInt > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[paramInt - 1]) == null) {
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*  2625 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/*  2626 */       sQLException.fillInStackTrace();
/*  2627 */       throw sQLException;
/*       */     } 
/*       */     
/*  2630 */     this.lastIndex = paramInt;
/*       */     
/*  2632 */     if (this.streamList != null) {
/*  2633 */       closeUsedStreams(paramInt);
/*       */     }
/*       */     
/*  2636 */     return accessor.getCursor(this.currentRank);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void clearParameters() throws SQLException {
/*  2643 */     synchronized (this.connection) {
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*  2651 */       super.clearParameters();
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public Object getObject(int paramInt, Map paramMap) throws SQLException {
/*  2677 */     if (this.closed) {
/*       */       
/*  2679 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  2680 */       sQLException.fillInStackTrace();
/*  2681 */       throw sQLException;
/*       */     } 
/*       */     
/*  2684 */     if (this.atLeastOneNamedParameter) {
/*       */ 
/*       */       
/*  2687 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/*  2688 */       sQLException.fillInStackTrace();
/*  2689 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */     
/*  2693 */     Accessor accessor = null;
/*  2694 */     if (paramInt <= 0 || paramInt > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[paramInt - 1]) == null) {
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*  2699 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/*  2700 */       sQLException.fillInStackTrace();
/*  2701 */       throw sQLException;
/*       */     } 
/*       */     
/*  2704 */     this.lastIndex = paramInt;
/*       */     
/*  2706 */     if (this.streamList != null) {
/*  2707 */       closeUsedStreams(paramInt);
/*       */     }
/*       */     
/*  2710 */     return accessor.getObject(this.currentRank, paramMap);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public Ref getRef(int paramInt) throws SQLException {
/*  2725 */     if (this.closed) {
/*       */       
/*  2727 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  2728 */       sQLException.fillInStackTrace();
/*  2729 */       throw sQLException;
/*       */     } 
/*       */     
/*  2732 */     if (this.atLeastOneNamedParameter) {
/*       */ 
/*       */       
/*  2735 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/*  2736 */       sQLException.fillInStackTrace();
/*  2737 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */     
/*  2741 */     Accessor accessor = null;
/*  2742 */     if (paramInt <= 0 || paramInt > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[paramInt - 1]) == null) {
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*  2747 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/*  2748 */       sQLException.fillInStackTrace();
/*  2749 */       throw sQLException;
/*       */     } 
/*       */     
/*  2752 */     this.lastIndex = paramInt;
/*       */     
/*  2754 */     if (this.streamList != null) {
/*  2755 */       closeUsedStreams(paramInt);
/*       */     }
/*       */     
/*  2758 */     return (Ref)accessor.getREF(this.currentRank);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public Blob getBlob(int paramInt) throws SQLException {
/*  2773 */     if (this.closed) {
/*       */       
/*  2775 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  2776 */       sQLException.fillInStackTrace();
/*  2777 */       throw sQLException;
/*       */     } 
/*       */     
/*  2780 */     if (this.atLeastOneNamedParameter) {
/*       */ 
/*       */       
/*  2783 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/*  2784 */       sQLException.fillInStackTrace();
/*  2785 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */     
/*  2789 */     Accessor accessor = null;
/*  2790 */     if (paramInt <= 0 || paramInt > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[paramInt - 1]) == null) {
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*  2795 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/*  2796 */       sQLException.fillInStackTrace();
/*  2797 */       throw sQLException;
/*       */     } 
/*       */     
/*  2800 */     this.lastIndex = paramInt;
/*       */     
/*  2802 */     if (this.streamList != null) {
/*  2803 */       closeUsedStreams(paramInt);
/*       */     }
/*       */     
/*  2806 */     return (Blob)accessor.getBLOB(this.currentRank);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public Clob getClob(int paramInt) throws SQLException {
/*  2821 */     if (this.closed) {
/*       */       
/*  2823 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  2824 */       sQLException.fillInStackTrace();
/*  2825 */       throw sQLException;
/*       */     } 
/*       */     
/*  2828 */     if (this.atLeastOneNamedParameter) {
/*       */ 
/*       */       
/*  2831 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/*  2832 */       sQLException.fillInStackTrace();
/*  2833 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */     
/*  2837 */     Accessor accessor = null;
/*  2838 */     if (paramInt <= 0 || paramInt > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[paramInt - 1]) == null) {
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*  2843 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/*  2844 */       sQLException.fillInStackTrace();
/*  2845 */       throw sQLException;
/*       */     } 
/*       */     
/*  2848 */     this.lastIndex = paramInt;
/*       */     
/*  2850 */     if (this.streamList != null) {
/*  2851 */       closeUsedStreams(paramInt);
/*       */     }
/*       */     
/*  2854 */     return (Clob)accessor.getCLOB(this.currentRank);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public Array getArray(int paramInt) throws SQLException {
/*  2869 */     if (this.closed) {
/*       */       
/*  2871 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  2872 */       sQLException.fillInStackTrace();
/*  2873 */       throw sQLException;
/*       */     } 
/*       */     
/*  2876 */     if (this.atLeastOneNamedParameter) {
/*       */ 
/*       */       
/*  2879 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/*  2880 */       sQLException.fillInStackTrace();
/*  2881 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */     
/*  2885 */     Accessor accessor = null;
/*  2886 */     if (paramInt <= 0 || paramInt > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[paramInt - 1]) == null) {
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*  2891 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/*  2892 */       sQLException.fillInStackTrace();
/*  2893 */       throw sQLException;
/*       */     } 
/*       */     
/*  2896 */     this.lastIndex = paramInt;
/*       */     
/*  2898 */     if (this.streamList != null) {
/*  2899 */       closeUsedStreams(paramInt);
/*       */     }
/*       */     
/*  2902 */     return (Array)accessor.getARRAY(this.currentRank);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public BigDecimal getBigDecimal(int paramInt) throws SQLException {
/*  2917 */     if (this.closed) {
/*       */       
/*  2919 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  2920 */       sQLException.fillInStackTrace();
/*  2921 */       throw sQLException;
/*       */     } 
/*       */     
/*  2924 */     if (this.atLeastOneNamedParameter) {
/*       */ 
/*       */       
/*  2927 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/*  2928 */       sQLException.fillInStackTrace();
/*  2929 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */     
/*  2933 */     Accessor accessor = null;
/*  2934 */     if (paramInt <= 0 || paramInt > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[paramInt - 1]) == null) {
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*  2939 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/*  2940 */       sQLException.fillInStackTrace();
/*  2941 */       throw sQLException;
/*       */     } 
/*       */     
/*  2944 */     this.lastIndex = paramInt;
/*       */     
/*  2946 */     if (this.streamList != null) {
/*  2947 */       closeUsedStreams(paramInt);
/*       */     }
/*       */     
/*  2950 */     return accessor.getBigDecimal(this.currentRank);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public Date getDate(int paramInt, Calendar paramCalendar) throws SQLException {
/*  2965 */     if (this.closed) {
/*       */       
/*  2967 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  2968 */       sQLException.fillInStackTrace();
/*  2969 */       throw sQLException;
/*       */     } 
/*       */     
/*  2972 */     if (this.atLeastOneNamedParameter) {
/*       */ 
/*       */       
/*  2975 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/*  2976 */       sQLException.fillInStackTrace();
/*  2977 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */     
/*  2981 */     Accessor accessor = null;
/*  2982 */     if (paramInt <= 0 || paramInt > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[paramInt - 1]) == null) {
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*  2987 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/*  2988 */       sQLException.fillInStackTrace();
/*  2989 */       throw sQLException;
/*       */     } 
/*       */     
/*  2992 */     this.lastIndex = paramInt;
/*       */     
/*  2994 */     if (this.streamList != null) {
/*  2995 */       closeUsedStreams(paramInt);
/*       */     }
/*       */     
/*  2998 */     return accessor.getDate(this.currentRank, paramCalendar);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public Time getTime(int paramInt, Calendar paramCalendar) throws SQLException {
/*  3013 */     if (this.closed) {
/*       */       
/*  3015 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  3016 */       sQLException.fillInStackTrace();
/*  3017 */       throw sQLException;
/*       */     } 
/*       */     
/*  3020 */     if (this.atLeastOneNamedParameter) {
/*       */ 
/*       */       
/*  3023 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/*  3024 */       sQLException.fillInStackTrace();
/*  3025 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */     
/*  3029 */     Accessor accessor = null;
/*  3030 */     if (paramInt <= 0 || paramInt > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[paramInt - 1]) == null) {
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*  3035 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/*  3036 */       sQLException.fillInStackTrace();
/*  3037 */       throw sQLException;
/*       */     } 
/*       */     
/*  3040 */     this.lastIndex = paramInt;
/*       */     
/*  3042 */     if (this.streamList != null) {
/*  3043 */       closeUsedStreams(paramInt);
/*       */     }
/*       */     
/*  3046 */     return accessor.getTime(this.currentRank, paramCalendar);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public Timestamp getTimestamp(int paramInt, Calendar paramCalendar) throws SQLException {
/*  3061 */     if (this.closed) {
/*       */       
/*  3063 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  3064 */       sQLException.fillInStackTrace();
/*  3065 */       throw sQLException;
/*       */     } 
/*       */     
/*  3068 */     if (this.atLeastOneNamedParameter) {
/*       */ 
/*       */       
/*  3071 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/*  3072 */       sQLException.fillInStackTrace();
/*  3073 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */     
/*  3077 */     Accessor accessor = null;
/*  3078 */     if (paramInt <= 0 || paramInt > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[paramInt - 1]) == null) {
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*  3083 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/*  3084 */       sQLException.fillInStackTrace();
/*  3085 */       throw sQLException;
/*       */     } 
/*       */     
/*  3088 */     this.lastIndex = paramInt;
/*       */     
/*  3090 */     if (this.streamList != null) {
/*  3091 */       closeUsedStreams(paramInt);
/*       */     }
/*       */     
/*  3094 */     return accessor.getTimestamp(this.currentRank, paramCalendar);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void addBatch() throws SQLException {
/*  3145 */     if (this.currentRowBindAccessors != null) {
/*       */ 
/*       */       
/*  3148 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Stored procedure with out or inout parameters cannot be batched");
/*  3149 */       sQLException.fillInStackTrace();
/*  3150 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */     
/*  3154 */     super.addBatch();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   protected void alwaysOnClose() throws SQLException {
/*  3164 */     this.sqlObject.resetNamedParameters();
/*       */ 
/*       */     
/*  3167 */     this.namedParameters = new String[8];
/*  3168 */     this.parameterCount = 0;
/*  3169 */     this.atLeastOneOrdinalParameter = false;
/*  3170 */     this.atLeastOneNamedParameter = false;
/*       */     
/*  3172 */     super.alwaysOnClose();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void registerOutParameter(String paramString, int paramInt) throws SQLException {
/*  3214 */     registerOutParameterInternal(paramString, paramInt, 0, -1, (String)null);
/*  3215 */     this.atLeastOneNamedParameter = true;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void registerOutParameter(String paramString, int paramInt1, int paramInt2) throws SQLException {
/*  3253 */     registerOutParameterInternal(paramString, paramInt1, paramInt2, -1, (String)null);
/*  3254 */     this.atLeastOneNamedParameter = true;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void registerOutParameter(String paramString1, int paramInt, String paramString2) throws SQLException {
/*  3304 */     registerOutParameterInternal(paramString1, paramInt, 0, -1, paramString2);
/*  3305 */     this.atLeastOneNamedParameter = true;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   void registerOutParameterInternal(String paramString1, int paramInt1, int paramInt2, int paramInt3, String paramString2) throws SQLException {
/*  3313 */     int i = addNamedPara(paramString1);
/*  3314 */     registerOutParameterInternal(i, paramInt1, paramInt2, paramInt3, paramString2);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public URL getURL(int paramInt) throws SQLException {
/*  3344 */     if (this.closed) {
/*       */       
/*  3346 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  3347 */       sQLException.fillInStackTrace();
/*  3348 */       throw sQLException;
/*       */     } 
/*       */     
/*  3351 */     if (this.atLeastOneNamedParameter) {
/*       */ 
/*       */       
/*  3354 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/*  3355 */       sQLException.fillInStackTrace();
/*  3356 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */     
/*  3360 */     Accessor accessor = null;
/*  3361 */     if (paramInt <= 0 || paramInt > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[paramInt - 1]) == null) {
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*  3366 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/*  3367 */       sQLException.fillInStackTrace();
/*  3368 */       throw sQLException;
/*       */     } 
/*       */     
/*  3371 */     this.lastIndex = paramInt;
/*       */     
/*  3373 */     if (this.streamList != null) {
/*  3374 */       closeUsedStreams(paramInt);
/*       */     }
/*       */     
/*  3377 */     return accessor.getURL(this.currentRank);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setStringForClob(String paramString1, String paramString2) throws SQLException {
/*  3409 */     int i = addNamedPara(paramString1);
/*  3410 */     if (paramString2 == null || paramString2.length() == 0) {
/*       */       
/*  3412 */       setNull(i, 2005);
/*       */       return;
/*       */     } 
/*  3415 */     setStringForClob(i, paramString2);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setStringForClob(int paramInt, String paramString) throws SQLException {
/*  3439 */     if (paramString == null || paramString.length() == 0) {
/*       */       
/*  3441 */       setNull(paramInt, 2005);
/*       */       return;
/*       */     } 
/*  3444 */     synchronized (this.connection) {
/*  3445 */       setStringForClobCritical(paramInt, paramString);
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setBytesForBlob(String paramString, byte[] paramArrayOfbyte) throws SQLException {
/*  3475 */     int i = addNamedPara(paramString);
/*  3476 */     setBytesForBlob(i, paramArrayOfbyte);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setBytesForBlob(int paramInt, byte[] paramArrayOfbyte) throws SQLException {
/*  3499 */     if (paramArrayOfbyte == null || paramArrayOfbyte.length == 0) {
/*       */       
/*  3501 */       setNull(paramInt, 2004);
/*       */       return;
/*       */     } 
/*  3504 */     synchronized (this.connection) {
/*  3505 */       setBytesForBlobCritical(paramInt, paramArrayOfbyte);
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public String getString(String paramString) throws SQLException {
/*  3539 */     if (!this.atLeastOneNamedParameter) {
/*       */ 
/*       */       
/*  3542 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/*  3543 */       sQLException.fillInStackTrace();
/*  3544 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */     
/*  3548 */     if (paramString == null) {
/*       */ 
/*       */       
/*  3551 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/*  3552 */       sQLException.fillInStackTrace();
/*  3553 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */     
/*  3557 */     String str = paramString.toUpperCase().intern();
/*       */     
/*       */     byte b;
/*  3560 */     for (b = 0; b < this.parameterCount; b++) {
/*       */       
/*  3562 */       if (str == this.namedParameters[b])
/*       */         break; 
/*       */     } 
/*  3565 */     b++;
/*       */     
/*  3567 */     Accessor accessor = null;
/*  3568 */     if (b <= 0 || b > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[b - 1]) == null) {
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*  3573 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 6);
/*  3574 */       sQLException.fillInStackTrace();
/*  3575 */       throw sQLException;
/*       */     } 
/*       */     
/*  3578 */     this.lastIndex = b;
/*       */     
/*  3580 */     if (this.streamList != null) {
/*  3581 */       closeUsedStreams(b);
/*       */     }
/*       */     
/*  3584 */     return accessor.getString(this.currentRank);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public boolean getBoolean(String paramString) throws SQLException {
/*  3610 */     if (!this.atLeastOneNamedParameter) {
/*       */ 
/*       */       
/*  3613 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/*  3614 */       sQLException.fillInStackTrace();
/*  3615 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */     
/*  3619 */     if (paramString == null) {
/*       */ 
/*       */       
/*  3622 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/*  3623 */       sQLException.fillInStackTrace();
/*  3624 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */     
/*  3628 */     String str = paramString.toUpperCase().intern();
/*       */     
/*       */     byte b;
/*  3631 */     for (b = 0; b < this.parameterCount; b++) {
/*       */       
/*  3633 */       if (str == this.namedParameters[b])
/*       */         break; 
/*       */     } 
/*  3636 */     b++;
/*       */     
/*  3638 */     Accessor accessor = null;
/*  3639 */     if (b <= 0 || b > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[b - 1]) == null) {
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*  3644 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 6);
/*  3645 */       sQLException.fillInStackTrace();
/*  3646 */       throw sQLException;
/*       */     } 
/*       */     
/*  3649 */     this.lastIndex = b;
/*       */     
/*  3651 */     if (this.streamList != null) {
/*  3652 */       closeUsedStreams(b);
/*       */     }
/*       */     
/*  3655 */     return accessor.getBoolean(this.currentRank);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public byte getByte(String paramString) throws SQLException {
/*  3681 */     if (!this.atLeastOneNamedParameter) {
/*       */ 
/*       */       
/*  3684 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/*  3685 */       sQLException.fillInStackTrace();
/*  3686 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */     
/*  3690 */     if (paramString == null) {
/*       */ 
/*       */       
/*  3693 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/*  3694 */       sQLException.fillInStackTrace();
/*  3695 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */     
/*  3699 */     String str = paramString.toUpperCase().intern();
/*       */     
/*       */     byte b;
/*  3702 */     for (b = 0; b < this.parameterCount; b++) {
/*       */       
/*  3704 */       if (str == this.namedParameters[b])
/*       */         break; 
/*       */     } 
/*  3707 */     b++;
/*       */     
/*  3709 */     Accessor accessor = null;
/*  3710 */     if (b <= 0 || b > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[b - 1]) == null) {
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*  3715 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 6);
/*  3716 */       sQLException.fillInStackTrace();
/*  3717 */       throw sQLException;
/*       */     } 
/*       */     
/*  3720 */     this.lastIndex = b;
/*       */     
/*  3722 */     if (this.streamList != null) {
/*  3723 */       closeUsedStreams(b);
/*       */     }
/*       */     
/*  3726 */     return accessor.getByte(this.currentRank);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public short getShort(String paramString) throws SQLException {
/*  3752 */     if (!this.atLeastOneNamedParameter) {
/*       */ 
/*       */       
/*  3755 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/*  3756 */       sQLException.fillInStackTrace();
/*  3757 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */     
/*  3761 */     if (paramString == null) {
/*       */ 
/*       */       
/*  3764 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/*  3765 */       sQLException.fillInStackTrace();
/*  3766 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */     
/*  3770 */     String str = paramString.toUpperCase().intern();
/*       */     
/*       */     byte b;
/*  3773 */     for (b = 0; b < this.parameterCount; b++) {
/*       */       
/*  3775 */       if (str == this.namedParameters[b])
/*       */         break; 
/*       */     } 
/*  3778 */     b++;
/*       */     
/*  3780 */     Accessor accessor = null;
/*  3781 */     if (b <= 0 || b > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[b - 1]) == null) {
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*  3786 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 6);
/*  3787 */       sQLException.fillInStackTrace();
/*  3788 */       throw sQLException;
/*       */     } 
/*       */     
/*  3791 */     this.lastIndex = b;
/*       */     
/*  3793 */     if (this.streamList != null) {
/*  3794 */       closeUsedStreams(b);
/*       */     }
/*       */     
/*  3797 */     return accessor.getShort(this.currentRank);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public int getInt(String paramString) throws SQLException {
/*  3824 */     if (!this.atLeastOneNamedParameter) {
/*       */ 
/*       */       
/*  3827 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/*  3828 */       sQLException.fillInStackTrace();
/*  3829 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */     
/*  3833 */     if (paramString == null) {
/*       */ 
/*       */       
/*  3836 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/*  3837 */       sQLException.fillInStackTrace();
/*  3838 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */     
/*  3842 */     String str = paramString.toUpperCase().intern();
/*       */     
/*       */     byte b;
/*  3845 */     for (b = 0; b < this.parameterCount; b++) {
/*       */       
/*  3847 */       if (str == this.namedParameters[b])
/*       */         break; 
/*       */     } 
/*  3850 */     b++;
/*       */     
/*  3852 */     Accessor accessor = null;
/*  3853 */     if (b <= 0 || b > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[b - 1]) == null) {
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*  3858 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 6);
/*  3859 */       sQLException.fillInStackTrace();
/*  3860 */       throw sQLException;
/*       */     } 
/*       */     
/*  3863 */     this.lastIndex = b;
/*       */     
/*  3865 */     if (this.streamList != null) {
/*  3866 */       closeUsedStreams(b);
/*       */     }
/*       */     
/*  3869 */     return accessor.getInt(this.currentRank);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public long getLong(String paramString) throws SQLException {
/*  3896 */     if (!this.atLeastOneNamedParameter) {
/*       */ 
/*       */       
/*  3899 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/*  3900 */       sQLException.fillInStackTrace();
/*  3901 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */     
/*  3905 */     if (paramString == null) {
/*       */ 
/*       */       
/*  3908 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/*  3909 */       sQLException.fillInStackTrace();
/*  3910 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */     
/*  3914 */     String str = paramString.toUpperCase().intern();
/*       */     
/*       */     byte b;
/*  3917 */     for (b = 0; b < this.parameterCount; b++) {
/*       */       
/*  3919 */       if (str == this.namedParameters[b])
/*       */         break; 
/*       */     } 
/*  3922 */     b++;
/*       */     
/*  3924 */     Accessor accessor = null;
/*  3925 */     if (b <= 0 || b > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[b - 1]) == null) {
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*  3930 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 6);
/*  3931 */       sQLException.fillInStackTrace();
/*  3932 */       throw sQLException;
/*       */     } 
/*       */     
/*  3935 */     this.lastIndex = b;
/*       */     
/*  3937 */     if (this.streamList != null) {
/*  3938 */       closeUsedStreams(b);
/*       */     }
/*       */     
/*  3941 */     return accessor.getLong(this.currentRank);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public float getFloat(String paramString) throws SQLException {
/*  3967 */     if (!this.atLeastOneNamedParameter) {
/*       */ 
/*       */       
/*  3970 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/*  3971 */       sQLException.fillInStackTrace();
/*  3972 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */     
/*  3976 */     if (paramString == null) {
/*       */ 
/*       */       
/*  3979 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/*  3980 */       sQLException.fillInStackTrace();
/*  3981 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */     
/*  3985 */     String str = paramString.toUpperCase().intern();
/*       */     
/*       */     byte b;
/*  3988 */     for (b = 0; b < this.parameterCount; b++) {
/*       */       
/*  3990 */       if (str == this.namedParameters[b])
/*       */         break; 
/*       */     } 
/*  3993 */     b++;
/*       */     
/*  3995 */     Accessor accessor = null;
/*  3996 */     if (b <= 0 || b > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[b - 1]) == null) {
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*  4001 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 6);
/*  4002 */       sQLException.fillInStackTrace();
/*  4003 */       throw sQLException;
/*       */     } 
/*       */     
/*  4006 */     this.lastIndex = b;
/*       */     
/*  4008 */     if (this.streamList != null) {
/*  4009 */       closeUsedStreams(b);
/*       */     }
/*       */     
/*  4012 */     return accessor.getFloat(this.currentRank);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public double getDouble(String paramString) throws SQLException {
/*  4038 */     if (!this.atLeastOneNamedParameter) {
/*       */ 
/*       */       
/*  4041 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/*  4042 */       sQLException.fillInStackTrace();
/*  4043 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */     
/*  4047 */     if (paramString == null) {
/*       */ 
/*       */       
/*  4050 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/*  4051 */       sQLException.fillInStackTrace();
/*  4052 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */     
/*  4056 */     String str = paramString.toUpperCase().intern();
/*       */     
/*       */     byte b;
/*  4059 */     for (b = 0; b < this.parameterCount; b++) {
/*       */       
/*  4061 */       if (str == this.namedParameters[b])
/*       */         break; 
/*       */     } 
/*  4064 */     b++;
/*       */     
/*  4066 */     Accessor accessor = null;
/*  4067 */     if (b <= 0 || b > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[b - 1]) == null) {
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*  4072 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 6);
/*  4073 */       sQLException.fillInStackTrace();
/*  4074 */       throw sQLException;
/*       */     } 
/*       */     
/*  4077 */     this.lastIndex = b;
/*       */     
/*  4079 */     if (this.streamList != null) {
/*  4080 */       closeUsedStreams(b);
/*       */     }
/*       */     
/*  4083 */     return accessor.getDouble(this.currentRank);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public byte[] getBytes(String paramString) throws SQLException {
/*  4110 */     if (!this.atLeastOneNamedParameter) {
/*       */ 
/*       */       
/*  4113 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/*  4114 */       sQLException.fillInStackTrace();
/*  4115 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */     
/*  4119 */     if (paramString == null) {
/*       */ 
/*       */       
/*  4122 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/*  4123 */       sQLException.fillInStackTrace();
/*  4124 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */     
/*  4128 */     String str = paramString.toUpperCase().intern();
/*       */     
/*       */     byte b;
/*  4131 */     for (b = 0; b < this.parameterCount; b++) {
/*       */       
/*  4133 */       if (str == this.namedParameters[b])
/*       */         break; 
/*       */     } 
/*  4136 */     b++;
/*       */     
/*  4138 */     Accessor accessor = null;
/*  4139 */     if (b <= 0 || b > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[b - 1]) == null) {
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*  4144 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 6);
/*  4145 */       sQLException.fillInStackTrace();
/*  4146 */       throw sQLException;
/*       */     } 
/*       */     
/*  4149 */     this.lastIndex = b;
/*       */     
/*  4151 */     if (this.streamList != null) {
/*  4152 */       closeUsedStreams(b);
/*       */     }
/*       */     
/*  4155 */     return accessor.getBytes(this.currentRank);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public Date getDate(String paramString) throws SQLException {
/*  4181 */     if (!this.atLeastOneNamedParameter) {
/*       */ 
/*       */       
/*  4184 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/*  4185 */       sQLException.fillInStackTrace();
/*  4186 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */     
/*  4190 */     if (paramString == null) {
/*       */ 
/*       */       
/*  4193 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/*  4194 */       sQLException.fillInStackTrace();
/*  4195 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */     
/*  4199 */     String str = paramString.toUpperCase().intern();
/*       */     
/*       */     byte b;
/*  4202 */     for (b = 0; b < this.parameterCount; b++) {
/*       */       
/*  4204 */       if (str == this.namedParameters[b])
/*       */         break; 
/*       */     } 
/*  4207 */     b++;
/*       */     
/*  4209 */     Accessor accessor = null;
/*  4210 */     if (b <= 0 || b > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[b - 1]) == null) {
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*  4215 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 6);
/*  4216 */       sQLException.fillInStackTrace();
/*  4217 */       throw sQLException;
/*       */     } 
/*       */     
/*  4220 */     this.lastIndex = b;
/*       */     
/*  4222 */     if (this.streamList != null) {
/*  4223 */       closeUsedStreams(b);
/*       */     }
/*       */     
/*  4226 */     return accessor.getDate(this.currentRank);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public Time getTime(String paramString) throws SQLException {
/*  4252 */     if (!this.atLeastOneNamedParameter) {
/*       */ 
/*       */       
/*  4255 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/*  4256 */       sQLException.fillInStackTrace();
/*  4257 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */     
/*  4261 */     if (paramString == null) {
/*       */ 
/*       */       
/*  4264 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/*  4265 */       sQLException.fillInStackTrace();
/*  4266 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */     
/*  4270 */     String str = paramString.toUpperCase().intern();
/*       */     
/*       */     byte b;
/*  4273 */     for (b = 0; b < this.parameterCount; b++) {
/*       */       
/*  4275 */       if (str == this.namedParameters[b])
/*       */         break; 
/*       */     } 
/*  4278 */     b++;
/*       */     
/*  4280 */     Accessor accessor = null;
/*  4281 */     if (b <= 0 || b > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[b - 1]) == null) {
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*  4286 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 6);
/*  4287 */       sQLException.fillInStackTrace();
/*  4288 */       throw sQLException;
/*       */     } 
/*       */     
/*  4291 */     this.lastIndex = b;
/*       */     
/*  4293 */     if (this.streamList != null) {
/*  4294 */       closeUsedStreams(b);
/*       */     }
/*       */     
/*  4297 */     return accessor.getTime(this.currentRank);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public Timestamp getTimestamp(String paramString) throws SQLException {
/*  4323 */     if (!this.atLeastOneNamedParameter) {
/*       */ 
/*       */       
/*  4326 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/*  4327 */       sQLException.fillInStackTrace();
/*  4328 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */     
/*  4332 */     if (paramString == null) {
/*       */ 
/*       */       
/*  4335 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/*  4336 */       sQLException.fillInStackTrace();
/*  4337 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */     
/*  4341 */     String str = paramString.toUpperCase().intern();
/*       */     
/*       */     byte b;
/*  4344 */     for (b = 0; b < this.parameterCount; b++) {
/*       */       
/*  4346 */       if (str == this.namedParameters[b])
/*       */         break; 
/*       */     } 
/*  4349 */     b++;
/*       */     
/*  4351 */     Accessor accessor = null;
/*  4352 */     if (b <= 0 || b > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[b - 1]) == null) {
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*  4357 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 6);
/*  4358 */       sQLException.fillInStackTrace();
/*  4359 */       throw sQLException;
/*       */     } 
/*       */     
/*  4362 */     this.lastIndex = b;
/*       */     
/*  4364 */     if (this.streamList != null) {
/*  4365 */       closeUsedStreams(b);
/*       */     }
/*       */     
/*  4368 */     return accessor.getTimestamp(this.currentRank);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public Object getObject(String paramString) throws SQLException {
/*  4401 */     if (!this.atLeastOneNamedParameter) {
/*       */ 
/*       */       
/*  4404 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/*  4405 */       sQLException.fillInStackTrace();
/*  4406 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */     
/*  4410 */     if (paramString == null) {
/*       */ 
/*       */       
/*  4413 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/*  4414 */       sQLException.fillInStackTrace();
/*  4415 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */     
/*  4419 */     String str = paramString.toUpperCase().intern();
/*       */     
/*       */     byte b;
/*  4422 */     for (b = 0; b < this.parameterCount; b++) {
/*       */       
/*  4424 */       if (str == this.namedParameters[b])
/*       */         break; 
/*       */     } 
/*  4427 */     b++;
/*       */     
/*  4429 */     Accessor accessor = null;
/*  4430 */     if (b <= 0 || b > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[b - 1]) == null) {
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*  4435 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 6);
/*  4436 */       sQLException.fillInStackTrace();
/*  4437 */       throw sQLException;
/*       */     } 
/*       */     
/*  4440 */     this.lastIndex = b;
/*       */     
/*  4442 */     if (this.streamList != null) {
/*  4443 */       closeUsedStreams(b);
/*       */     }
/*       */     
/*  4446 */     return accessor.getObject(this.currentRank);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public BigDecimal getBigDecimal(String paramString) throws SQLException {
/*  4473 */     if (!this.atLeastOneNamedParameter) {
/*       */ 
/*       */       
/*  4476 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/*  4477 */       sQLException.fillInStackTrace();
/*  4478 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */     
/*  4482 */     if (paramString == null) {
/*       */ 
/*       */       
/*  4485 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/*  4486 */       sQLException.fillInStackTrace();
/*  4487 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */     
/*  4491 */     String str = paramString.toUpperCase().intern();
/*       */     
/*       */     byte b;
/*  4494 */     for (b = 0; b < this.parameterCount; b++) {
/*       */       
/*  4496 */       if (str == this.namedParameters[b])
/*       */         break; 
/*       */     } 
/*  4499 */     b++;
/*       */     
/*  4501 */     Accessor accessor = null;
/*  4502 */     if (b <= 0 || b > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[b - 1]) == null) {
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*  4507 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 6);
/*  4508 */       sQLException.fillInStackTrace();
/*  4509 */       throw sQLException;
/*       */     } 
/*       */     
/*  4512 */     this.lastIndex = b;
/*       */     
/*  4514 */     if (this.streamList != null) {
/*  4515 */       closeUsedStreams(b);
/*       */     }
/*       */     
/*  4518 */     return accessor.getBigDecimal(this.currentRank);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public BigDecimal getBigDecimal(String paramString, int paramInt) throws SQLException {
/*  4532 */     if (!this.atLeastOneNamedParameter) {
/*       */ 
/*       */       
/*  4535 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/*  4536 */       sQLException.fillInStackTrace();
/*  4537 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */     
/*  4541 */     if (paramString == null) {
/*       */ 
/*       */       
/*  4544 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/*  4545 */       sQLException.fillInStackTrace();
/*  4546 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */     
/*  4550 */     String str = paramString.toUpperCase().intern();
/*       */     
/*       */     byte b;
/*  4553 */     for (b = 0; b < this.parameterCount; b++) {
/*       */       
/*  4555 */       if (str == this.namedParameters[b])
/*       */         break; 
/*       */     } 
/*  4558 */     b++;
/*       */     
/*  4560 */     Accessor accessor = null;
/*  4561 */     if (b <= 0 || b > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[b - 1]) == null) {
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*  4566 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 6);
/*  4567 */       sQLException.fillInStackTrace();
/*  4568 */       throw sQLException;
/*       */     } 
/*       */     
/*  4571 */     this.lastIndex = b;
/*       */     
/*  4573 */     if (this.streamList != null) {
/*  4574 */       closeUsedStreams(b);
/*       */     }
/*       */     
/*  4577 */     return accessor.getBigDecimal(this.currentRank, paramInt);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public Object getObject(String paramString, Map paramMap) throws SQLException {
/*  4610 */     if (!this.atLeastOneNamedParameter) {
/*       */ 
/*       */       
/*  4613 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/*  4614 */       sQLException.fillInStackTrace();
/*  4615 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */     
/*  4619 */     if (paramString == null) {
/*       */ 
/*       */       
/*  4622 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/*  4623 */       sQLException.fillInStackTrace();
/*  4624 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */     
/*  4628 */     String str = paramString.toUpperCase().intern();
/*       */     
/*       */     byte b;
/*  4631 */     for (b = 0; b < this.parameterCount; b++) {
/*       */       
/*  4633 */       if (str == this.namedParameters[b])
/*       */         break; 
/*       */     } 
/*  4636 */     b++;
/*       */     
/*  4638 */     Accessor accessor = null;
/*  4639 */     if (b <= 0 || b > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[b - 1]) == null) {
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*  4644 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 6);
/*  4645 */       sQLException.fillInStackTrace();
/*  4646 */       throw sQLException;
/*       */     } 
/*       */     
/*  4649 */     this.lastIndex = b;
/*       */     
/*  4651 */     if (this.streamList != null) {
/*  4652 */       closeUsedStreams(b);
/*       */     }
/*       */     
/*  4655 */     return accessor.getObject(this.currentRank, paramMap);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public Ref getRef(String paramString) throws SQLException {
/*  4682 */     if (!this.atLeastOneNamedParameter) {
/*       */ 
/*       */       
/*  4685 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/*  4686 */       sQLException.fillInStackTrace();
/*  4687 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */     
/*  4691 */     if (paramString == null) {
/*       */ 
/*       */       
/*  4694 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/*  4695 */       sQLException.fillInStackTrace();
/*  4696 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */     
/*  4700 */     String str = paramString.toUpperCase().intern();
/*       */     
/*       */     byte b;
/*  4703 */     for (b = 0; b < this.parameterCount; b++) {
/*       */       
/*  4705 */       if (str == this.namedParameters[b])
/*       */         break; 
/*       */     } 
/*  4708 */     b++;
/*       */     
/*  4710 */     Accessor accessor = null;
/*  4711 */     if (b <= 0 || b > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[b - 1]) == null) {
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*  4716 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 6);
/*  4717 */       sQLException.fillInStackTrace();
/*  4718 */       throw sQLException;
/*       */     } 
/*       */     
/*  4721 */     this.lastIndex = b;
/*       */     
/*  4723 */     if (this.streamList != null) {
/*  4724 */       closeUsedStreams(b);
/*       */     }
/*       */     
/*  4727 */     return (Ref)accessor.getREF(this.currentRank);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public Blob getBlob(String paramString) throws SQLException {
/*  4754 */     if (!this.atLeastOneNamedParameter) {
/*       */ 
/*       */       
/*  4757 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/*  4758 */       sQLException.fillInStackTrace();
/*  4759 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */     
/*  4763 */     if (paramString == null) {
/*       */ 
/*       */       
/*  4766 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/*  4767 */       sQLException.fillInStackTrace();
/*  4768 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */     
/*  4772 */     String str = paramString.toUpperCase().intern();
/*       */     
/*       */     byte b;
/*  4775 */     for (b = 0; b < this.parameterCount; b++) {
/*       */       
/*  4777 */       if (str == this.namedParameters[b])
/*       */         break; 
/*       */     } 
/*  4780 */     b++;
/*       */     
/*  4782 */     Accessor accessor = null;
/*  4783 */     if (b <= 0 || b > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[b - 1]) == null) {
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*  4788 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 6);
/*  4789 */       sQLException.fillInStackTrace();
/*  4790 */       throw sQLException;
/*       */     } 
/*       */     
/*  4793 */     this.lastIndex = b;
/*       */     
/*  4795 */     if (this.streamList != null) {
/*  4796 */       closeUsedStreams(b);
/*       */     }
/*       */     
/*  4799 */     return (Blob)accessor.getBLOB(this.currentRank);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public Clob getClob(String paramString) throws SQLException {
/*  4825 */     if (!this.atLeastOneNamedParameter) {
/*       */ 
/*       */       
/*  4828 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/*  4829 */       sQLException.fillInStackTrace();
/*  4830 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */     
/*  4834 */     if (paramString == null) {
/*       */ 
/*       */       
/*  4837 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/*  4838 */       sQLException.fillInStackTrace();
/*  4839 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */     
/*  4843 */     String str = paramString.toUpperCase().intern();
/*       */     
/*       */     byte b;
/*  4846 */     for (b = 0; b < this.parameterCount; b++) {
/*       */       
/*  4848 */       if (str == this.namedParameters[b])
/*       */         break; 
/*       */     } 
/*  4851 */     b++;
/*       */     
/*  4853 */     Accessor accessor = null;
/*  4854 */     if (b <= 0 || b > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[b - 1]) == null) {
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*  4859 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 6);
/*  4860 */       sQLException.fillInStackTrace();
/*  4861 */       throw sQLException;
/*       */     } 
/*       */     
/*  4864 */     this.lastIndex = b;
/*       */     
/*  4866 */     if (this.streamList != null) {
/*  4867 */       closeUsedStreams(b);
/*       */     }
/*       */     
/*  4870 */     return (Clob)accessor.getCLOB(this.currentRank);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public Array getArray(String paramString) throws SQLException {
/*  4897 */     if (!this.atLeastOneNamedParameter) {
/*       */ 
/*       */       
/*  4900 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/*  4901 */       sQLException.fillInStackTrace();
/*  4902 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */     
/*  4906 */     if (paramString == null) {
/*       */ 
/*       */       
/*  4909 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/*  4910 */       sQLException.fillInStackTrace();
/*  4911 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */     
/*  4915 */     String str = paramString.toUpperCase().intern();
/*       */     
/*       */     byte b;
/*  4918 */     for (b = 0; b < this.parameterCount; b++) {
/*       */       
/*  4920 */       if (str == this.namedParameters[b])
/*       */         break; 
/*       */     } 
/*  4923 */     b++;
/*       */     
/*  4925 */     Accessor accessor = null;
/*  4926 */     if (b <= 0 || b > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[b - 1]) == null) {
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*  4931 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 6);
/*  4932 */       sQLException.fillInStackTrace();
/*  4933 */       throw sQLException;
/*       */     } 
/*       */     
/*  4936 */     this.lastIndex = b;
/*       */     
/*  4938 */     if (this.streamList != null) {
/*  4939 */       closeUsedStreams(b);
/*       */     }
/*       */     
/*  4942 */     return (Array)accessor.getARRAY(this.currentRank);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public Date getDate(String paramString, Calendar paramCalendar) throws SQLException {
/*  4977 */     if (!this.atLeastOneNamedParameter) {
/*       */ 
/*       */       
/*  4980 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/*  4981 */       sQLException.fillInStackTrace();
/*  4982 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */     
/*  4986 */     if (paramString == null) {
/*       */ 
/*       */       
/*  4989 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/*  4990 */       sQLException.fillInStackTrace();
/*  4991 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */     
/*  4995 */     String str = paramString.toUpperCase().intern();
/*       */     
/*       */     byte b;
/*  4998 */     for (b = 0; b < this.parameterCount; b++) {
/*       */       
/*  5000 */       if (str == this.namedParameters[b])
/*       */         break; 
/*       */     } 
/*  5003 */     b++;
/*       */     
/*  5005 */     Accessor accessor = null;
/*  5006 */     if (b <= 0 || b > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[b - 1]) == null) {
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*  5011 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 6);
/*  5012 */       sQLException.fillInStackTrace();
/*  5013 */       throw sQLException;
/*       */     } 
/*       */     
/*  5016 */     this.lastIndex = b;
/*       */     
/*  5018 */     if (this.streamList != null) {
/*  5019 */       closeUsedStreams(b);
/*       */     }
/*       */     
/*  5022 */     return accessor.getDate(this.currentRank, paramCalendar);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public Time getTime(String paramString, Calendar paramCalendar) throws SQLException {
/*  5057 */     if (!this.atLeastOneNamedParameter) {
/*       */ 
/*       */       
/*  5060 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/*  5061 */       sQLException.fillInStackTrace();
/*  5062 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */     
/*  5066 */     if (paramString == null) {
/*       */ 
/*       */       
/*  5069 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/*  5070 */       sQLException.fillInStackTrace();
/*  5071 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */     
/*  5075 */     String str = paramString.toUpperCase().intern();
/*       */     
/*       */     byte b;
/*  5078 */     for (b = 0; b < this.parameterCount; b++) {
/*       */       
/*  5080 */       if (str == this.namedParameters[b])
/*       */         break; 
/*       */     } 
/*  5083 */     b++;
/*       */     
/*  5085 */     Accessor accessor = null;
/*  5086 */     if (b <= 0 || b > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[b - 1]) == null) {
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*  5091 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 6);
/*  5092 */       sQLException.fillInStackTrace();
/*  5093 */       throw sQLException;
/*       */     } 
/*       */     
/*  5096 */     this.lastIndex = b;
/*       */     
/*  5098 */     if (this.streamList != null) {
/*  5099 */       closeUsedStreams(b);
/*       */     }
/*       */     
/*  5102 */     return accessor.getTime(this.currentRank, paramCalendar);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public Timestamp getTimestamp(String paramString, Calendar paramCalendar) throws SQLException {
/*  5138 */     if (!this.atLeastOneNamedParameter) {
/*       */ 
/*       */       
/*  5141 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/*  5142 */       sQLException.fillInStackTrace();
/*  5143 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */     
/*  5147 */     if (paramString == null) {
/*       */ 
/*       */       
/*  5150 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/*  5151 */       sQLException.fillInStackTrace();
/*  5152 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */     
/*  5156 */     String str = paramString.toUpperCase().intern();
/*       */     
/*       */     byte b;
/*  5159 */     for (b = 0; b < this.parameterCount; b++) {
/*       */       
/*  5161 */       if (str == this.namedParameters[b])
/*       */         break; 
/*       */     } 
/*  5164 */     b++;
/*       */     
/*  5166 */     Accessor accessor = null;
/*  5167 */     if (b <= 0 || b > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[b - 1]) == null) {
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*  5172 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 6);
/*  5173 */       sQLException.fillInStackTrace();
/*  5174 */       throw sQLException;
/*       */     } 
/*       */     
/*  5177 */     this.lastIndex = b;
/*       */     
/*  5179 */     if (this.streamList != null) {
/*  5180 */       closeUsedStreams(b);
/*       */     }
/*       */     
/*  5183 */     return accessor.getTimestamp(this.currentRank, paramCalendar);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public URL getURL(String paramString) throws SQLException {
/*  5212 */     if (!this.atLeastOneNamedParameter) {
/*       */ 
/*       */       
/*  5215 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/*  5216 */       sQLException.fillInStackTrace();
/*  5217 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */     
/*  5221 */     if (paramString == null) {
/*       */ 
/*       */       
/*  5224 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/*  5225 */       sQLException.fillInStackTrace();
/*  5226 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */     
/*  5230 */     String str = paramString.toUpperCase().intern();
/*       */     
/*       */     byte b;
/*  5233 */     for (b = 0; b < this.parameterCount; b++) {
/*       */       
/*  5235 */       if (str == this.namedParameters[b])
/*       */         break; 
/*       */     } 
/*  5238 */     b++;
/*       */     
/*  5240 */     Accessor accessor = null;
/*  5241 */     if (b <= 0 || b > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[b - 1]) == null) {
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*  5246 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 6);
/*  5247 */       sQLException.fillInStackTrace();
/*  5248 */       throw sQLException;
/*       */     } 
/*       */     
/*  5251 */     this.lastIndex = b;
/*       */     
/*  5253 */     if (this.streamList != null) {
/*  5254 */       closeUsedStreams(b);
/*       */     }
/*       */     
/*  5257 */     return accessor.getURL(this.currentRank);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public InputStream getAsciiStream(String paramString) throws SQLException {
/*  5267 */     SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException();
/*  5268 */     sQLException.fillInStackTrace();
/*  5269 */     throw sQLException;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void registerIndexTableOutParameter(int paramInt1, int paramInt2, int paramInt3, int paramInt4) throws SQLException {
/*  5308 */     synchronized (this.connection) {
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*  5316 */       int i = paramInt1 - 1;
/*  5317 */       if (i < 0 || paramInt1 > this.numberOfBindPositions) {
/*       */         
/*  5319 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/*  5320 */         sQLException.fillInStackTrace();
/*  5321 */         throw sQLException;
/*       */       } 
/*       */       
/*  5324 */       int j = getInternalType(paramInt3);
/*       */       
/*  5326 */       if (j == 96 || j == 1) {
/*       */ 
/*       */         
/*  5329 */         if (paramInt4 < 0 || paramInt4 > this.maxIbtVarcharElementLength) {
/*       */           
/*  5331 */           SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 53);
/*  5332 */           sQLException.fillInStackTrace();
/*  5333 */           throw sQLException;
/*       */         } 
/*  5335 */         if (paramInt4 == 0) {
/*  5336 */           paramInt4 = this.maxIbtVarcharElementLength;
/*       */         }
/*       */       } 
/*  5339 */       resetBatch();
/*  5340 */       this.currentRowNeedToPrepareBinds = true;
/*       */       
/*  5342 */       if (this.currentRowBindAccessors == null) {
/*  5343 */         this.currentRowBindAccessors = new Accessor[this.numberOfBindPositions];
/*       */       }
/*  5345 */       this.currentRowBindAccessors[i] = allocateIndexTableAccessor(new PlsqlIbtBindInfo(this, null, paramInt2, 0, j, paramInt4), this.currentRowFormOfUse[i]);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*  5354 */       this.hasIbtBind = true;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   Accessor allocateIndexTableAccessor(PlsqlIbtBindInfo paramPlsqlIbtBindInfo, short paramShort) throws SQLException {
/*  5366 */     return new PlsqlIndexTableAccessor(this, paramPlsqlIbtBindInfo, paramShort);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public Object getPlsqlIndexTable(int paramInt) throws SQLException {
/*  5384 */     synchronized (this.connection) {
/*       */       BigDecimal[] arrayOfBigDecimal;
/*       */ 
/*       */ 
/*       */       
/*       */       SQLException sQLException;
/*       */ 
/*       */       
/*  5392 */       Datum[] arrayOfDatum = getOraclePlsqlIndexTable(paramInt);
/*       */       
/*  5394 */       Accessor accessor = this.outBindAccessors[paramInt - 1];
/*       */       
/*  5396 */       int i = (accessor.plsqlIndexTableBindInfo()).element_internal_type;
/*       */       
/*  5398 */       String[] arrayOfString = null;
/*       */       
/*  5400 */       switch (i) {
/*       */         
/*       */         case 9:
/*  5403 */           arrayOfString = new String[arrayOfDatum.length];
/*       */           break;
/*       */         case 6:
/*  5406 */           arrayOfBigDecimal = new BigDecimal[arrayOfDatum.length];
/*       */           break;
/*       */         
/*       */         default:
/*  5410 */           sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 1, "Invalid column type");
/*  5411 */           sQLException.fillInStackTrace();
/*  5412 */           throw sQLException;
/*       */       } 
/*       */ 
/*       */       
/*  5416 */       for (byte b = 0; b < arrayOfBigDecimal.length; b++) {
/*  5417 */         arrayOfBigDecimal[b] = (arrayOfDatum[b] != null && arrayOfDatum[b].getLength() != 0L) ? (BigDecimal)arrayOfDatum[b].toJdbc() : null;
/*       */       }
/*       */ 
/*       */ 
/*       */       
/*  5422 */       return arrayOfBigDecimal;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public Object getPlsqlIndexTable(int paramInt, Class paramClass) throws SQLException {
/*  5442 */     synchronized (this.connection) {
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*  5449 */       Datum[] arrayOfDatum = getOraclePlsqlIndexTable(paramInt);
/*       */       
/*  5451 */       if (paramClass == null || !paramClass.isPrimitive()) {
/*       */         
/*  5453 */         SQLException sQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/*  5454 */         sQLException1.fillInStackTrace();
/*  5455 */         throw sQLException1;
/*       */       } 
/*       */       
/*  5458 */       String str = paramClass.getName();
/*       */       
/*  5460 */       if (str.equals("byte")) {
/*       */         
/*  5462 */         byte[] arrayOfByte = new byte[arrayOfDatum.length];
/*  5463 */         for (byte b = 0; b < arrayOfDatum.length; b++)
/*  5464 */           arrayOfByte[b] = (arrayOfDatum[b] != null) ? arrayOfDatum[b].byteValue() : 0; 
/*  5465 */         return arrayOfByte;
/*       */       } 
/*  5467 */       if (str.equals("char")) {
/*       */         
/*  5469 */         char[] arrayOfChar = new char[arrayOfDatum.length];
/*  5470 */         for (byte b = 0; b < arrayOfDatum.length; b++) {
/*  5471 */           arrayOfChar[b] = (arrayOfDatum[b] != null && arrayOfDatum[b].getLength() != 0L) ? (char)arrayOfDatum[b].intValue() : Character.MIN_VALUE;
/*       */         }
/*  5473 */         return arrayOfChar;
/*       */       } 
/*  5475 */       if (str.equals("double")) {
/*       */         
/*  5477 */         double[] arrayOfDouble = new double[arrayOfDatum.length];
/*  5478 */         for (byte b = 0; b < arrayOfDatum.length; b++) {
/*  5479 */           arrayOfDouble[b] = (arrayOfDatum[b] != null && arrayOfDatum[b].getLength() != 0L) ? arrayOfDatum[b].doubleValue() : 0.0D;
/*       */         }
/*  5481 */         return arrayOfDouble;
/*       */       } 
/*  5483 */       if (str.equals("float")) {
/*       */         
/*  5485 */         float[] arrayOfFloat = new float[arrayOfDatum.length];
/*  5486 */         for (byte b = 0; b < arrayOfDatum.length; b++) {
/*  5487 */           arrayOfFloat[b] = (arrayOfDatum[b] != null && arrayOfDatum[b].getLength() != 0L) ? arrayOfDatum[b].floatValue() : 0.0F;
/*       */         }
/*  5489 */         return arrayOfFloat;
/*       */       } 
/*  5491 */       if (str.equals("int")) {
/*       */         
/*  5493 */         int[] arrayOfInt = new int[arrayOfDatum.length];
/*  5494 */         for (byte b = 0; b < arrayOfDatum.length; b++) {
/*  5495 */           arrayOfInt[b] = (arrayOfDatum[b] != null && arrayOfDatum[b].getLength() != 0L) ? arrayOfDatum[b].intValue() : 0;
/*       */         }
/*  5497 */         return arrayOfInt;
/*       */       } 
/*  5499 */       if (str.equals("long")) {
/*       */         
/*  5501 */         long[] arrayOfLong = new long[arrayOfDatum.length];
/*  5502 */         for (byte b = 0; b < arrayOfDatum.length; b++) {
/*  5503 */           arrayOfLong[b] = (arrayOfDatum[b] != null && arrayOfDatum[b].getLength() != 0L) ? arrayOfDatum[b].longValue() : 0L;
/*       */         }
/*  5505 */         return arrayOfLong;
/*       */       } 
/*  5507 */       if (str.equals("short")) {
/*       */         
/*  5509 */         short[] arrayOfShort = new short[arrayOfDatum.length];
/*  5510 */         for (byte b = 0; b < arrayOfDatum.length; b++) {
/*  5511 */           arrayOfShort[b] = (arrayOfDatum[b] != null && arrayOfDatum[b].getLength() != 0L) ? (short)arrayOfDatum[b].intValue() : 0;
/*       */         }
/*  5513 */         return arrayOfShort;
/*       */       } 
/*  5515 */       if (str.equals("boolean")) {
/*       */         
/*  5517 */         boolean[] arrayOfBoolean = new boolean[arrayOfDatum.length];
/*  5518 */         for (byte b = 0; b < arrayOfDatum.length; b++) {
/*  5519 */           arrayOfBoolean[b] = (arrayOfDatum[b] != null && arrayOfDatum[b].getLength() != 0L) ? arrayOfDatum[b].booleanValue() : false;
/*       */         }
/*  5521 */         return arrayOfBoolean;
/*       */       } 
/*       */ 
/*       */       
/*  5525 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 23);
/*  5526 */       sQLException.fillInStackTrace();
/*  5527 */       throw sQLException;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public Datum[] getOraclePlsqlIndexTable(int paramInt) throws SQLException {
/*  5545 */     synchronized (this.connection) {
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*  5554 */       if (this.closed) {
/*       */         
/*  5556 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  5557 */         sQLException.fillInStackTrace();
/*  5558 */         throw sQLException;
/*       */       } 
/*       */       
/*  5561 */       if (this.atLeastOneNamedParameter) {
/*       */ 
/*       */         
/*  5564 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/*  5565 */         sQLException.fillInStackTrace();
/*  5566 */         throw sQLException;
/*       */       } 
/*       */ 
/*       */       
/*  5570 */       Accessor accessor = null;
/*  5571 */       if (paramInt <= 0 || paramInt > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[paramInt - 1]) == null) {
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*  5576 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/*  5577 */         sQLException.fillInStackTrace();
/*  5578 */         throw sQLException;
/*       */       } 
/*       */       
/*  5581 */       this.lastIndex = paramInt;
/*       */       
/*  5583 */       if (this.streamList != null) {
/*  5584 */         closeUsedStreams(paramInt);
/*       */       }
/*       */       
/*  5587 */       return accessor.getOraclePlsqlIndexTable(this.currentRank);
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public boolean execute() throws SQLException {
/*  5607 */     synchronized (this.connection) {
/*  5608 */       ensureOpen();
/*  5609 */       if (this.atLeastOneNamedParameter && this.atLeastOneOrdinalParameter) {
/*       */         
/*  5611 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/*  5612 */         sQLException.fillInStackTrace();
/*  5613 */         throw sQLException;
/*       */       } 
/*  5615 */       if (this.sqlObject.setNamedParameters(this.parameterCount, this.namedParameters))
/*  5616 */         this.needToParse = true; 
/*  5617 */       return super.execute();
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public int executeUpdate() throws SQLException {
/*  5631 */     synchronized (this.connection) {
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*  5638 */       ensureOpen();
/*  5639 */       if (this.atLeastOneNamedParameter && this.atLeastOneOrdinalParameter) {
/*       */         
/*  5641 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/*  5642 */         sQLException.fillInStackTrace();
/*  5643 */         throw sQLException;
/*       */       } 
/*  5645 */       if (this.sqlObject.setNamedParameters(this.parameterCount, this.namedParameters))
/*  5646 */         this.needToParse = true; 
/*  5647 */       return super.executeUpdate();
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */   
/*       */   void releaseBuffers() {
/*  5654 */     super.releaseBuffers();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setArray(int paramInt, Array paramArray) throws SQLException {
/*  5673 */     if (this.closed) {
/*       */       
/*  5675 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  5676 */       sQLException.fillInStackTrace();
/*  5677 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */     
/*  5681 */     this.atLeastOneOrdinalParameter = true;
/*  5682 */     setArrayInternal(paramInt, paramArray);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setBigDecimal(int paramInt, BigDecimal paramBigDecimal) throws SQLException {
/*  5689 */     synchronized (this.connection) {
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*  5696 */       if (this.closed) {
/*       */         
/*  5698 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  5699 */         sQLException.fillInStackTrace();
/*  5700 */         throw sQLException;
/*       */       } 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*  5706 */       this.atLeastOneOrdinalParameter = true;
/*  5707 */       setBigDecimalInternal(paramInt, paramBigDecimal);
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setBlob(int paramInt, Blob paramBlob) throws SQLException {
/*  5715 */     synchronized (this.connection) {
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*  5722 */       if (this.closed) {
/*       */         
/*  5724 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  5725 */         sQLException.fillInStackTrace();
/*  5726 */         throw sQLException;
/*       */       } 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*  5732 */       this.atLeastOneOrdinalParameter = true;
/*  5733 */       setBlobInternal(paramInt, paramBlob);
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setBoolean(int paramInt, boolean paramBoolean) throws SQLException {
/*  5741 */     synchronized (this.connection) {
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*  5748 */       if (this.closed) {
/*       */         
/*  5750 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  5751 */         sQLException.fillInStackTrace();
/*  5752 */         throw sQLException;
/*       */       } 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*  5758 */       this.atLeastOneOrdinalParameter = true;
/*  5759 */       setBooleanInternal(paramInt, paramBoolean);
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setByte(int paramInt, byte paramByte) throws SQLException {
/*  5767 */     synchronized (this.connection) {
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*  5774 */       if (this.closed) {
/*       */         
/*  5776 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  5777 */         sQLException.fillInStackTrace();
/*  5778 */         throw sQLException;
/*       */       } 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*  5784 */       this.atLeastOneOrdinalParameter = true;
/*  5785 */       setByteInternal(paramInt, paramByte);
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setBytes(int paramInt, byte[] paramArrayOfbyte) throws SQLException {
/*  5793 */     synchronized (this.connection) {
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*  5800 */       if (this.closed) {
/*       */         
/*  5802 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  5803 */         sQLException.fillInStackTrace();
/*  5804 */         throw sQLException;
/*       */       } 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*  5810 */       this.atLeastOneOrdinalParameter = true;
/*  5811 */       setBytesInternal(paramInt, paramArrayOfbyte);
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setClob(int paramInt, Clob paramClob) throws SQLException {
/*  5819 */     synchronized (this.connection) {
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*  5826 */       if (this.closed) {
/*       */         
/*  5828 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  5829 */         sQLException.fillInStackTrace();
/*  5830 */         throw sQLException;
/*       */       } 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*  5836 */       this.atLeastOneOrdinalParameter = true;
/*  5837 */       setClobInternal(paramInt, paramClob);
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setDate(int paramInt, Date paramDate) throws SQLException {
/*  5845 */     synchronized (this.connection) {
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*  5852 */       if (this.closed) {
/*       */         
/*  5854 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  5855 */         sQLException.fillInStackTrace();
/*  5856 */         throw sQLException;
/*       */       } 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*  5862 */       this.atLeastOneOrdinalParameter = true;
/*  5863 */       setDateInternal(paramInt, paramDate);
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setDate(int paramInt, Date paramDate, Calendar paramCalendar) throws SQLException {
/*  5871 */     synchronized (this.connection) {
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*  5878 */       if (this.closed) {
/*       */         
/*  5880 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  5881 */         sQLException.fillInStackTrace();
/*  5882 */         throw sQLException;
/*       */       } 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*  5888 */       this.atLeastOneOrdinalParameter = true;
/*  5889 */       setDateInternal(paramInt, paramDate, paramCalendar);
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setDouble(int paramInt, double paramDouble) throws SQLException {
/*  5897 */     synchronized (this.connection) {
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*  5904 */       if (this.closed) {
/*       */         
/*  5906 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  5907 */         sQLException.fillInStackTrace();
/*  5908 */         throw sQLException;
/*       */       } 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*  5914 */       this.atLeastOneOrdinalParameter = true;
/*  5915 */       setDoubleInternal(paramInt, paramDouble);
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setFloat(int paramInt, float paramFloat) throws SQLException {
/*  5923 */     synchronized (this.connection) {
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*  5930 */       if (this.closed) {
/*       */         
/*  5932 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  5933 */         sQLException.fillInStackTrace();
/*  5934 */         throw sQLException;
/*       */       } 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*  5940 */       this.atLeastOneOrdinalParameter = true;
/*  5941 */       setFloatInternal(paramInt, paramFloat);
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setInt(int paramInt1, int paramInt2) throws SQLException {
/*  5949 */     synchronized (this.connection) {
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*  5956 */       if (this.closed) {
/*       */         
/*  5958 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  5959 */         sQLException.fillInStackTrace();
/*  5960 */         throw sQLException;
/*       */       } 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*  5966 */       this.atLeastOneOrdinalParameter = true;
/*  5967 */       setIntInternal(paramInt1, paramInt2);
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setLong(int paramInt, long paramLong) throws SQLException {
/*  5975 */     synchronized (this.connection) {
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*  5982 */       if (this.closed) {
/*       */         
/*  5984 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  5985 */         sQLException.fillInStackTrace();
/*  5986 */         throw sQLException;
/*       */       } 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*  5992 */       this.atLeastOneOrdinalParameter = true;
/*  5993 */       setLongInternal(paramInt, paramLong);
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setNClob(int paramInt, NClob paramNClob) throws SQLException {
/*  6001 */     synchronized (this.connection) {
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*  6008 */       if (this.closed) {
/*       */         
/*  6010 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  6011 */         sQLException.fillInStackTrace();
/*  6012 */         throw sQLException;
/*       */       } 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*  6018 */       this.atLeastOneOrdinalParameter = true;
/*  6019 */       setNClobInternal(paramInt, paramNClob);
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setNString(int paramInt, String paramString) throws SQLException {
/*  6027 */     synchronized (this.connection) {
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*  6034 */       if (this.closed) {
/*       */         
/*  6036 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  6037 */         sQLException.fillInStackTrace();
/*  6038 */         throw sQLException;
/*       */       } 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*  6044 */       this.atLeastOneOrdinalParameter = true;
/*  6045 */       setNStringInternal(paramInt, paramString);
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setObject(int paramInt, Object paramObject) throws SQLException {
/*  6059 */     if (this.closed) {
/*       */       
/*  6061 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  6062 */       sQLException.fillInStackTrace();
/*  6063 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */     
/*  6067 */     this.atLeastOneOrdinalParameter = true;
/*  6068 */     setObjectInternal(paramInt, paramObject);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setObject(int paramInt1, Object paramObject, int paramInt2) throws SQLException {
/*  6081 */     if (this.closed) {
/*       */       
/*  6083 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  6084 */       sQLException.fillInStackTrace();
/*  6085 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */     
/*  6089 */     this.atLeastOneOrdinalParameter = true;
/*  6090 */     setObjectInternal(paramInt1, paramObject, paramInt2);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setRef(int paramInt, Ref paramRef) throws SQLException {
/*  6103 */     if (this.closed) {
/*       */       
/*  6105 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  6106 */       sQLException.fillInStackTrace();
/*  6107 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */     
/*  6111 */     this.atLeastOneOrdinalParameter = true;
/*  6112 */     setRefInternal(paramInt, paramRef);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setRowId(int paramInt, RowId paramRowId) throws SQLException {
/*  6119 */     synchronized (this.connection) {
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*  6126 */       if (this.closed) {
/*       */         
/*  6128 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  6129 */         sQLException.fillInStackTrace();
/*  6130 */         throw sQLException;
/*       */       } 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*  6136 */       this.atLeastOneOrdinalParameter = true;
/*  6137 */       setRowIdInternal(paramInt, paramRowId);
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setShort(int paramInt, short paramShort) throws SQLException {
/*  6145 */     synchronized (this.connection) {
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*  6152 */       if (this.closed) {
/*       */         
/*  6154 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  6155 */         sQLException.fillInStackTrace();
/*  6156 */         throw sQLException;
/*       */       } 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*  6162 */       this.atLeastOneOrdinalParameter = true;
/*  6163 */       setShortInternal(paramInt, paramShort);
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setSQLXML(int paramInt, SQLXML paramSQLXML) throws SQLException {
/*  6171 */     synchronized (this.connection) {
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*  6178 */       if (this.closed) {
/*       */         
/*  6180 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  6181 */         sQLException.fillInStackTrace();
/*  6182 */         throw sQLException;
/*       */       } 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*  6188 */       this.atLeastOneOrdinalParameter = true;
/*  6189 */       setSQLXMLInternal(paramInt, paramSQLXML);
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setString(int paramInt, String paramString) throws SQLException {
/*  6197 */     synchronized (this.connection) {
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*  6204 */       if (this.closed) {
/*       */         
/*  6206 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  6207 */         sQLException.fillInStackTrace();
/*  6208 */         throw sQLException;
/*       */       } 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*  6214 */       this.atLeastOneOrdinalParameter = true;
/*  6215 */       setStringInternal(paramInt, paramString);
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setTime(int paramInt, Time paramTime) throws SQLException {
/*  6223 */     synchronized (this.connection) {
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*  6230 */       if (this.closed) {
/*       */         
/*  6232 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  6233 */         sQLException.fillInStackTrace();
/*  6234 */         throw sQLException;
/*       */       } 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*  6240 */       this.atLeastOneOrdinalParameter = true;
/*  6241 */       setTimeInternal(paramInt, paramTime);
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setTime(int paramInt, Time paramTime, Calendar paramCalendar) throws SQLException {
/*  6249 */     synchronized (this.connection) {
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*  6256 */       if (this.closed) {
/*       */         
/*  6258 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  6259 */         sQLException.fillInStackTrace();
/*  6260 */         throw sQLException;
/*       */       } 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*  6266 */       this.atLeastOneOrdinalParameter = true;
/*  6267 */       setTimeInternal(paramInt, paramTime, paramCalendar);
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setTimestamp(int paramInt, Timestamp paramTimestamp) throws SQLException {
/*  6275 */     synchronized (this.connection) {
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*  6282 */       if (this.closed) {
/*       */         
/*  6284 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  6285 */         sQLException.fillInStackTrace();
/*  6286 */         throw sQLException;
/*       */       } 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*  6292 */       this.atLeastOneOrdinalParameter = true;
/*  6293 */       setTimestampInternal(paramInt, paramTimestamp);
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setTimestamp(int paramInt, Timestamp paramTimestamp, Calendar paramCalendar) throws SQLException {
/*  6301 */     synchronized (this.connection) {
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*  6308 */       if (this.closed) {
/*       */         
/*  6310 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  6311 */         sQLException.fillInStackTrace();
/*  6312 */         throw sQLException;
/*       */       } 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*  6318 */       this.atLeastOneOrdinalParameter = true;
/*  6319 */       setTimestampInternal(paramInt, paramTimestamp, paramCalendar);
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setURL(int paramInt, URL paramURL) throws SQLException {
/*  6327 */     synchronized (this.connection) {
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*  6334 */       if (this.closed) {
/*       */         
/*  6336 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  6337 */         sQLException.fillInStackTrace();
/*  6338 */         throw sQLException;
/*       */       } 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*  6344 */       this.atLeastOneOrdinalParameter = true;
/*  6345 */       setURLInternal(paramInt, paramURL);
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setARRAY(int paramInt, ARRAY paramARRAY) throws SQLException {
/*  6359 */     if (this.closed) {
/*       */       
/*  6361 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  6362 */       sQLException.fillInStackTrace();
/*  6363 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */     
/*  6367 */     this.atLeastOneOrdinalParameter = true;
/*  6368 */     setARRAYInternal(paramInt, paramARRAY);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setBFILE(int paramInt, BFILE paramBFILE) throws SQLException {
/*  6375 */     synchronized (this.connection) {
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*  6382 */       if (this.closed) {
/*       */         
/*  6384 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  6385 */         sQLException.fillInStackTrace();
/*  6386 */         throw sQLException;
/*       */       } 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*  6392 */       this.atLeastOneOrdinalParameter = true;
/*  6393 */       setBFILEInternal(paramInt, paramBFILE);
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setBfile(int paramInt, BFILE paramBFILE) throws SQLException {
/*  6401 */     synchronized (this.connection) {
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*  6408 */       if (this.closed) {
/*       */         
/*  6410 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  6411 */         sQLException.fillInStackTrace();
/*  6412 */         throw sQLException;
/*       */       } 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*  6418 */       this.atLeastOneOrdinalParameter = true;
/*  6419 */       setBfileInternal(paramInt, paramBFILE);
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setBinaryFloat(int paramInt, float paramFloat) throws SQLException {
/*  6427 */     synchronized (this.connection) {
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*  6434 */       if (this.closed) {
/*       */         
/*  6436 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  6437 */         sQLException.fillInStackTrace();
/*  6438 */         throw sQLException;
/*       */       } 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*  6444 */       this.atLeastOneOrdinalParameter = true;
/*  6445 */       setBinaryFloatInternal(paramInt, paramFloat);
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setBinaryFloat(int paramInt, BINARY_FLOAT paramBINARY_FLOAT) throws SQLException {
/*  6453 */     synchronized (this.connection) {
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*  6460 */       if (this.closed) {
/*       */         
/*  6462 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  6463 */         sQLException.fillInStackTrace();
/*  6464 */         throw sQLException;
/*       */       } 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*  6470 */       this.atLeastOneOrdinalParameter = true;
/*  6471 */       setBinaryFloatInternal(paramInt, paramBINARY_FLOAT);
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setBinaryDouble(int paramInt, double paramDouble) throws SQLException {
/*  6479 */     synchronized (this.connection) {
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*  6486 */       if (this.closed) {
/*       */         
/*  6488 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  6489 */         sQLException.fillInStackTrace();
/*  6490 */         throw sQLException;
/*       */       } 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*  6496 */       this.atLeastOneOrdinalParameter = true;
/*  6497 */       setBinaryDoubleInternal(paramInt, paramDouble);
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setBinaryDouble(int paramInt, BINARY_DOUBLE paramBINARY_DOUBLE) throws SQLException {
/*  6505 */     synchronized (this.connection) {
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*  6512 */       if (this.closed) {
/*       */         
/*  6514 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  6515 */         sQLException.fillInStackTrace();
/*  6516 */         throw sQLException;
/*       */       } 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*  6522 */       this.atLeastOneOrdinalParameter = true;
/*  6523 */       setBinaryDoubleInternal(paramInt, paramBINARY_DOUBLE);
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setBLOB(int paramInt, BLOB paramBLOB) throws SQLException {
/*  6531 */     synchronized (this.connection) {
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*  6538 */       if (this.closed) {
/*       */         
/*  6540 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  6541 */         sQLException.fillInStackTrace();
/*  6542 */         throw sQLException;
/*       */       } 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*  6548 */       this.atLeastOneOrdinalParameter = true;
/*  6549 */       setBLOBInternal(paramInt, paramBLOB);
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setCHAR(int paramInt, CHAR paramCHAR) throws SQLException {
/*  6557 */     synchronized (this.connection) {
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*  6564 */       if (this.closed) {
/*       */         
/*  6566 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  6567 */         sQLException.fillInStackTrace();
/*  6568 */         throw sQLException;
/*       */       } 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*  6574 */       this.atLeastOneOrdinalParameter = true;
/*  6575 */       setCHARInternal(paramInt, paramCHAR);
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setCLOB(int paramInt, CLOB paramCLOB) throws SQLException {
/*  6583 */     synchronized (this.connection) {
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*  6590 */       if (this.closed) {
/*       */         
/*  6592 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  6593 */         sQLException.fillInStackTrace();
/*  6594 */         throw sQLException;
/*       */       } 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*  6600 */       this.atLeastOneOrdinalParameter = true;
/*  6601 */       setCLOBInternal(paramInt, paramCLOB);
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setCursor(int paramInt, ResultSet paramResultSet) throws SQLException {
/*  6609 */     synchronized (this.connection) {
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*  6616 */       if (this.closed) {
/*       */         
/*  6618 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  6619 */         sQLException.fillInStackTrace();
/*  6620 */         throw sQLException;
/*       */       } 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*  6626 */       this.atLeastOneOrdinalParameter = true;
/*  6627 */       setCursorInternal(paramInt, paramResultSet);
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setDATE(int paramInt, DATE paramDATE) throws SQLException {
/*  6635 */     synchronized (this.connection) {
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*  6642 */       if (this.closed) {
/*       */         
/*  6644 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  6645 */         sQLException.fillInStackTrace();
/*  6646 */         throw sQLException;
/*       */       } 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*  6652 */       this.atLeastOneOrdinalParameter = true;
/*  6653 */       setDATEInternal(paramInt, paramDATE);
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setFixedCHAR(int paramInt, String paramString) throws SQLException {
/*  6661 */     synchronized (this.connection) {
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*  6668 */       if (this.closed) {
/*       */         
/*  6670 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  6671 */         sQLException.fillInStackTrace();
/*  6672 */         throw sQLException;
/*       */       } 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*  6678 */       this.atLeastOneOrdinalParameter = true;
/*  6679 */       setFixedCHARInternal(paramInt, paramString);
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setINTERVALDS(int paramInt, INTERVALDS paramINTERVALDS) throws SQLException {
/*  6687 */     synchronized (this.connection) {
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*  6694 */       if (this.closed) {
/*       */         
/*  6696 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  6697 */         sQLException.fillInStackTrace();
/*  6698 */         throw sQLException;
/*       */       } 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*  6704 */       this.atLeastOneOrdinalParameter = true;
/*  6705 */       setINTERVALDSInternal(paramInt, paramINTERVALDS);
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setINTERVALYM(int paramInt, INTERVALYM paramINTERVALYM) throws SQLException {
/*  6713 */     synchronized (this.connection) {
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*  6720 */       if (this.closed) {
/*       */         
/*  6722 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  6723 */         sQLException.fillInStackTrace();
/*  6724 */         throw sQLException;
/*       */       } 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*  6730 */       this.atLeastOneOrdinalParameter = true;
/*  6731 */       setINTERVALYMInternal(paramInt, paramINTERVALYM);
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setNUMBER(int paramInt, NUMBER paramNUMBER) throws SQLException {
/*  6739 */     synchronized (this.connection) {
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*  6746 */       if (this.closed) {
/*       */         
/*  6748 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  6749 */         sQLException.fillInStackTrace();
/*  6750 */         throw sQLException;
/*       */       } 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*  6756 */       this.atLeastOneOrdinalParameter = true;
/*  6757 */       setNUMBERInternal(paramInt, paramNUMBER);
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setOPAQUE(int paramInt, OPAQUE paramOPAQUE) throws SQLException {
/*  6771 */     if (this.closed) {
/*       */       
/*  6773 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  6774 */       sQLException.fillInStackTrace();
/*  6775 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */     
/*  6779 */     this.atLeastOneOrdinalParameter = true;
/*  6780 */     setOPAQUEInternal(paramInt, paramOPAQUE);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setOracleObject(int paramInt, Datum paramDatum) throws SQLException {
/*  6793 */     if (this.closed) {
/*       */       
/*  6795 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  6796 */       sQLException.fillInStackTrace();
/*  6797 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */     
/*  6801 */     this.atLeastOneOrdinalParameter = true;
/*  6802 */     setOracleObjectInternal(paramInt, paramDatum);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setORAData(int paramInt, ORAData paramORAData) throws SQLException {
/*  6815 */     if (this.closed) {
/*       */       
/*  6817 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  6818 */       sQLException.fillInStackTrace();
/*  6819 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */     
/*  6823 */     this.atLeastOneOrdinalParameter = true;
/*  6824 */     setORADataInternal(paramInt, paramORAData);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setRAW(int paramInt, RAW paramRAW) throws SQLException {
/*  6831 */     synchronized (this.connection) {
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*  6838 */       if (this.closed) {
/*       */         
/*  6840 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  6841 */         sQLException.fillInStackTrace();
/*  6842 */         throw sQLException;
/*       */       } 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*  6848 */       this.atLeastOneOrdinalParameter = true;
/*  6849 */       setRAWInternal(paramInt, paramRAW);
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setREF(int paramInt, REF paramREF) throws SQLException {
/*  6863 */     if (this.closed) {
/*       */       
/*  6865 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  6866 */       sQLException.fillInStackTrace();
/*  6867 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */     
/*  6871 */     this.atLeastOneOrdinalParameter = true;
/*  6872 */     setREFInternal(paramInt, paramREF);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setRefType(int paramInt, REF paramREF) throws SQLException {
/*  6885 */     if (this.closed) {
/*       */       
/*  6887 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  6888 */       sQLException.fillInStackTrace();
/*  6889 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */     
/*  6893 */     this.atLeastOneOrdinalParameter = true;
/*  6894 */     setRefTypeInternal(paramInt, paramREF);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setROWID(int paramInt, ROWID paramROWID) throws SQLException {
/*  6901 */     synchronized (this.connection) {
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*  6908 */       if (this.closed) {
/*       */         
/*  6910 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  6911 */         sQLException.fillInStackTrace();
/*  6912 */         throw sQLException;
/*       */       } 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*  6918 */       this.atLeastOneOrdinalParameter = true;
/*  6919 */       setROWIDInternal(paramInt, paramROWID);
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setSTRUCT(int paramInt, STRUCT paramSTRUCT) throws SQLException {
/*  6933 */     if (this.closed) {
/*       */       
/*  6935 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  6936 */       sQLException.fillInStackTrace();
/*  6937 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */     
/*  6941 */     this.atLeastOneOrdinalParameter = true;
/*  6942 */     setSTRUCTInternal(paramInt, paramSTRUCT);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setTIMESTAMPLTZ(int paramInt, TIMESTAMPLTZ paramTIMESTAMPLTZ) throws SQLException {
/*  6949 */     synchronized (this.connection) {
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*  6956 */       if (this.closed) {
/*       */         
/*  6958 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  6959 */         sQLException.fillInStackTrace();
/*  6960 */         throw sQLException;
/*       */       } 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*  6966 */       this.atLeastOneOrdinalParameter = true;
/*  6967 */       setTIMESTAMPLTZInternal(paramInt, paramTIMESTAMPLTZ);
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setTIMESTAMPTZ(int paramInt, TIMESTAMPTZ paramTIMESTAMPTZ) throws SQLException {
/*  6975 */     synchronized (this.connection) {
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*  6982 */       if (this.closed) {
/*       */         
/*  6984 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  6985 */         sQLException.fillInStackTrace();
/*  6986 */         throw sQLException;
/*       */       } 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*  6992 */       this.atLeastOneOrdinalParameter = true;
/*  6993 */       setTIMESTAMPTZInternal(paramInt, paramTIMESTAMPTZ);
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setTIMESTAMP(int paramInt, TIMESTAMP paramTIMESTAMP) throws SQLException {
/*  7001 */     synchronized (this.connection) {
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*  7008 */       if (this.closed) {
/*       */         
/*  7010 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  7011 */         sQLException.fillInStackTrace();
/*  7012 */         throw sQLException;
/*       */       } 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*  7018 */       this.atLeastOneOrdinalParameter = true;
/*  7019 */       setTIMESTAMPInternal(paramInt, paramTIMESTAMP);
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setCustomDatum(int paramInt, CustomDatum paramCustomDatum) throws SQLException {
/*  7033 */     if (this.closed) {
/*       */       
/*  7035 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  7036 */       sQLException.fillInStackTrace();
/*  7037 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */     
/*  7041 */     this.atLeastOneOrdinalParameter = true;
/*  7042 */     setCustomDatumInternal(paramInt, paramCustomDatum);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setBlob(int paramInt, InputStream paramInputStream) throws SQLException {
/*  7049 */     synchronized (this.connection) {
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*  7056 */       if (this.closed) {
/*       */         
/*  7058 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  7059 */         sQLException.fillInStackTrace();
/*  7060 */         throw sQLException;
/*       */       } 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*  7066 */       this.atLeastOneOrdinalParameter = true;
/*  7067 */       setBlobInternal(paramInt, paramInputStream);
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setBlob(int paramInt, InputStream paramInputStream, long paramLong) throws SQLException {
/*  7075 */     synchronized (this.connection) {
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*  7082 */       if (this.closed) {
/*       */         
/*  7084 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  7085 */         sQLException.fillInStackTrace();
/*  7086 */         throw sQLException;
/*       */       } 
/*       */ 
/*       */ 
/*       */       
/*  7091 */       if (paramLong < 0L) {
/*       */         
/*  7093 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68, "length for setBlob() cannot be negative");
/*  7094 */         sQLException.fillInStackTrace();
/*  7095 */         throw sQLException;
/*       */       } 
/*       */       
/*  7098 */       this.atLeastOneOrdinalParameter = true;
/*  7099 */       setBlobInternal(paramInt, paramInputStream, paramLong);
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setClob(int paramInt, Reader paramReader) throws SQLException {
/*  7107 */     synchronized (this.connection) {
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*  7114 */       if (this.closed) {
/*       */         
/*  7116 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  7117 */         sQLException.fillInStackTrace();
/*  7118 */         throw sQLException;
/*       */       } 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*  7124 */       this.atLeastOneOrdinalParameter = true;
/*  7125 */       setClobInternal(paramInt, paramReader);
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setClob(int paramInt, Reader paramReader, long paramLong) throws SQLException {
/*  7133 */     synchronized (this.connection) {
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*  7140 */       if (this.closed) {
/*       */         
/*  7142 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  7143 */         sQLException.fillInStackTrace();
/*  7144 */         throw sQLException;
/*       */       } 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*  7150 */       if (paramLong < 0L) {
/*       */         
/*  7152 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68, "length for setClob() cannot be negative");
/*  7153 */         sQLException.fillInStackTrace();
/*  7154 */         throw sQLException;
/*       */       } 
/*  7156 */       this.atLeastOneOrdinalParameter = true;
/*  7157 */       setClobInternal(paramInt, paramReader, paramLong);
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setNClob(int paramInt, Reader paramReader) throws SQLException {
/*  7165 */     synchronized (this.connection) {
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*  7172 */       if (this.closed) {
/*       */         
/*  7174 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  7175 */         sQLException.fillInStackTrace();
/*  7176 */         throw sQLException;
/*       */       } 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*  7182 */       this.atLeastOneOrdinalParameter = true;
/*  7183 */       setNClobInternal(paramInt, paramReader);
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setNClob(int paramInt, Reader paramReader, long paramLong) throws SQLException {
/*  7191 */     synchronized (this.connection) {
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*  7198 */       if (this.closed) {
/*       */         
/*  7200 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  7201 */         sQLException.fillInStackTrace();
/*  7202 */         throw sQLException;
/*       */       } 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*  7208 */       this.atLeastOneOrdinalParameter = true;
/*  7209 */       setNClobInternal(paramInt, paramReader, paramLong);
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setAsciiStream(int paramInt, InputStream paramInputStream) throws SQLException {
/*  7217 */     synchronized (this.connection) {
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*  7224 */       if (this.closed) {
/*       */         
/*  7226 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  7227 */         sQLException.fillInStackTrace();
/*  7228 */         throw sQLException;
/*       */       } 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*  7234 */       this.atLeastOneOrdinalParameter = true;
/*  7235 */       setAsciiStreamInternal(paramInt, paramInputStream);
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setAsciiStream(int paramInt1, InputStream paramInputStream, int paramInt2) throws SQLException {
/*  7243 */     synchronized (this.connection) {
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*  7250 */       if (this.closed) {
/*       */         
/*  7252 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  7253 */         sQLException.fillInStackTrace();
/*  7254 */         throw sQLException;
/*       */       } 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*  7260 */       this.atLeastOneOrdinalParameter = true;
/*  7261 */       setAsciiStreamInternal(paramInt1, paramInputStream, paramInt2);
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setAsciiStream(int paramInt, InputStream paramInputStream, long paramLong) throws SQLException {
/*  7269 */     synchronized (this.connection) {
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*  7276 */       if (this.closed) {
/*       */         
/*  7278 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  7279 */         sQLException.fillInStackTrace();
/*  7280 */         throw sQLException;
/*       */       } 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*  7286 */       this.atLeastOneOrdinalParameter = true;
/*  7287 */       setAsciiStreamInternal(paramInt, paramInputStream, paramLong);
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setBinaryStream(int paramInt, InputStream paramInputStream) throws SQLException {
/*  7295 */     synchronized (this.connection) {
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*  7302 */       if (this.closed) {
/*       */         
/*  7304 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  7305 */         sQLException.fillInStackTrace();
/*  7306 */         throw sQLException;
/*       */       } 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*  7312 */       this.atLeastOneOrdinalParameter = true;
/*  7313 */       setBinaryStreamInternal(paramInt, paramInputStream);
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setBinaryStream(int paramInt1, InputStream paramInputStream, int paramInt2) throws SQLException {
/*  7321 */     synchronized (this.connection) {
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*  7328 */       if (this.closed) {
/*       */         
/*  7330 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  7331 */         sQLException.fillInStackTrace();
/*  7332 */         throw sQLException;
/*       */       } 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*  7338 */       this.atLeastOneOrdinalParameter = true;
/*  7339 */       setBinaryStreamInternal(paramInt1, paramInputStream, paramInt2);
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setBinaryStream(int paramInt, InputStream paramInputStream, long paramLong) throws SQLException {
/*  7347 */     synchronized (this.connection) {
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*  7354 */       if (this.closed) {
/*       */         
/*  7356 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  7357 */         sQLException.fillInStackTrace();
/*  7358 */         throw sQLException;
/*       */       } 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*  7364 */       this.atLeastOneOrdinalParameter = true;
/*  7365 */       setBinaryStreamInternal(paramInt, paramInputStream, paramLong);
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setCharacterStream(int paramInt, Reader paramReader) throws SQLException {
/*  7373 */     synchronized (this.connection) {
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*  7380 */       if (this.closed) {
/*       */         
/*  7382 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  7383 */         sQLException.fillInStackTrace();
/*  7384 */         throw sQLException;
/*       */       } 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*  7390 */       this.atLeastOneOrdinalParameter = true;
/*  7391 */       setCharacterStreamInternal(paramInt, paramReader);
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setCharacterStream(int paramInt1, Reader paramReader, int paramInt2) throws SQLException {
/*  7399 */     synchronized (this.connection) {
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*  7406 */       if (this.closed) {
/*       */         
/*  7408 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  7409 */         sQLException.fillInStackTrace();
/*  7410 */         throw sQLException;
/*       */       } 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*  7416 */       this.atLeastOneOrdinalParameter = true;
/*  7417 */       setCharacterStreamInternal(paramInt1, paramReader, paramInt2);
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setCharacterStream(int paramInt, Reader paramReader, long paramLong) throws SQLException {
/*  7425 */     synchronized (this.connection) {
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*  7432 */       if (this.closed) {
/*       */         
/*  7434 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  7435 */         sQLException.fillInStackTrace();
/*  7436 */         throw sQLException;
/*       */       } 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*  7442 */       this.atLeastOneOrdinalParameter = true;
/*  7443 */       setCharacterStreamInternal(paramInt, paramReader, paramLong);
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setNCharacterStream(int paramInt, Reader paramReader) throws SQLException {
/*  7451 */     synchronized (this.connection) {
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*  7458 */       if (this.closed) {
/*       */         
/*  7460 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  7461 */         sQLException.fillInStackTrace();
/*  7462 */         throw sQLException;
/*       */       } 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*  7468 */       this.atLeastOneOrdinalParameter = true;
/*  7469 */       setNCharacterStreamInternal(paramInt, paramReader);
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setNCharacterStream(int paramInt, Reader paramReader, long paramLong) throws SQLException {
/*  7477 */     synchronized (this.connection) {
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*  7484 */       if (this.closed) {
/*       */         
/*  7486 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  7487 */         sQLException.fillInStackTrace();
/*  7488 */         throw sQLException;
/*       */       } 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*  7494 */       this.atLeastOneOrdinalParameter = true;
/*  7495 */       setNCharacterStreamInternal(paramInt, paramReader, paramLong);
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setUnicodeStream(int paramInt1, InputStream paramInputStream, int paramInt2) throws SQLException {
/*  7503 */     synchronized (this.connection) {
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*  7510 */       if (this.closed) {
/*       */         
/*  7512 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  7513 */         sQLException.fillInStackTrace();
/*  7514 */         throw sQLException;
/*       */       } 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*  7520 */       this.atLeastOneOrdinalParameter = true;
/*  7521 */       setUnicodeStreamInternal(paramInt1, paramInputStream, paramInt2);
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setArray(String paramString, Array paramArray) throws SQLException {
/*  7536 */     if (this.closed) {
/*       */       
/*  7538 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  7539 */       sQLException.fillInStackTrace();
/*  7540 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*  7546 */     int i = addNamedPara(paramString);
/*  7547 */     setArrayInternal(i, paramArray);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setBigDecimal(String paramString, BigDecimal paramBigDecimal) throws SQLException {
/*  7560 */     if (this.closed) {
/*       */       
/*  7562 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  7563 */       sQLException.fillInStackTrace();
/*  7564 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*  7570 */     int i = addNamedPara(paramString);
/*  7571 */     setBigDecimalInternal(i, paramBigDecimal);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setBlob(String paramString, Blob paramBlob) throws SQLException {
/*  7584 */     if (this.closed) {
/*       */       
/*  7586 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  7587 */       sQLException.fillInStackTrace();
/*  7588 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*  7594 */     int i = addNamedPara(paramString);
/*  7595 */     setBlobInternal(i, paramBlob);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setBoolean(String paramString, boolean paramBoolean) throws SQLException {
/*  7608 */     if (this.closed) {
/*       */       
/*  7610 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  7611 */       sQLException.fillInStackTrace();
/*  7612 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*  7618 */     int i = addNamedPara(paramString);
/*  7619 */     setBooleanInternal(i, paramBoolean);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setByte(String paramString, byte paramByte) throws SQLException {
/*  7632 */     if (this.closed) {
/*       */       
/*  7634 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  7635 */       sQLException.fillInStackTrace();
/*  7636 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*  7642 */     int i = addNamedPara(paramString);
/*  7643 */     setByteInternal(i, paramByte);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setBytes(String paramString, byte[] paramArrayOfbyte) throws SQLException {
/*  7656 */     if (this.closed) {
/*       */       
/*  7658 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  7659 */       sQLException.fillInStackTrace();
/*  7660 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*  7666 */     int i = addNamedPara(paramString);
/*  7667 */     setBytesInternal(i, paramArrayOfbyte);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setClob(String paramString, Clob paramClob) throws SQLException {
/*  7680 */     if (this.closed) {
/*       */       
/*  7682 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  7683 */       sQLException.fillInStackTrace();
/*  7684 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*  7690 */     int i = addNamedPara(paramString);
/*  7691 */     setClobInternal(i, paramClob);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setDate(String paramString, Date paramDate) throws SQLException {
/*  7704 */     if (this.closed) {
/*       */       
/*  7706 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  7707 */       sQLException.fillInStackTrace();
/*  7708 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*  7714 */     int i = addNamedPara(paramString);
/*  7715 */     setDateInternal(i, paramDate);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setDate(String paramString, Date paramDate, Calendar paramCalendar) throws SQLException {
/*  7728 */     if (this.closed) {
/*       */       
/*  7730 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  7731 */       sQLException.fillInStackTrace();
/*  7732 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*  7738 */     int i = addNamedPara(paramString);
/*  7739 */     setDateInternal(i, paramDate, paramCalendar);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setDouble(String paramString, double paramDouble) throws SQLException {
/*  7752 */     if (this.closed) {
/*       */       
/*  7754 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  7755 */       sQLException.fillInStackTrace();
/*  7756 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*  7762 */     int i = addNamedPara(paramString);
/*  7763 */     setDoubleInternal(i, paramDouble);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setFloat(String paramString, float paramFloat) throws SQLException {
/*  7776 */     if (this.closed) {
/*       */       
/*  7778 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  7779 */       sQLException.fillInStackTrace();
/*  7780 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*  7786 */     int i = addNamedPara(paramString);
/*  7787 */     setFloatInternal(i, paramFloat);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setInt(String paramString, int paramInt) throws SQLException {
/*  7800 */     if (this.closed) {
/*       */       
/*  7802 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  7803 */       sQLException.fillInStackTrace();
/*  7804 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*  7810 */     int i = addNamedPara(paramString);
/*  7811 */     setIntInternal(i, paramInt);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setLong(String paramString, long paramLong) throws SQLException {
/*  7824 */     if (this.closed) {
/*       */       
/*  7826 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  7827 */       sQLException.fillInStackTrace();
/*  7828 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*  7834 */     int i = addNamedPara(paramString);
/*  7835 */     setLongInternal(i, paramLong);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setNClob(String paramString, NClob paramNClob) throws SQLException {
/*  7848 */     if (this.closed) {
/*       */       
/*  7850 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  7851 */       sQLException.fillInStackTrace();
/*  7852 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*  7858 */     int i = addNamedPara(paramString);
/*  7859 */     setNClobInternal(i, paramNClob);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setNString(String paramString1, String paramString2) throws SQLException {
/*  7872 */     if (this.closed) {
/*       */       
/*  7874 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  7875 */       sQLException.fillInStackTrace();
/*  7876 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*  7882 */     int i = addNamedPara(paramString1);
/*  7883 */     setNStringInternal(i, paramString2);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setObject(String paramString, Object paramObject) throws SQLException {
/*  7896 */     if (this.closed) {
/*       */       
/*  7898 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  7899 */       sQLException.fillInStackTrace();
/*  7900 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*  7906 */     int i = addNamedPara(paramString);
/*  7907 */     setObjectInternal(i, paramObject);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setObject(String paramString, Object paramObject, int paramInt) throws SQLException {
/*  7920 */     if (this.closed) {
/*       */       
/*  7922 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  7923 */       sQLException.fillInStackTrace();
/*  7924 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*  7930 */     int i = addNamedPara(paramString);
/*  7931 */     setObjectInternal(i, paramObject, paramInt);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setRef(String paramString, Ref paramRef) throws SQLException {
/*  7944 */     if (this.closed) {
/*       */       
/*  7946 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  7947 */       sQLException.fillInStackTrace();
/*  7948 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*  7954 */     int i = addNamedPara(paramString);
/*  7955 */     setRefInternal(i, paramRef);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setRowId(String paramString, RowId paramRowId) throws SQLException {
/*  7968 */     if (this.closed) {
/*       */       
/*  7970 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  7971 */       sQLException.fillInStackTrace();
/*  7972 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*  7978 */     int i = addNamedPara(paramString);
/*  7979 */     setRowIdInternal(i, paramRowId);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setShort(String paramString, short paramShort) throws SQLException {
/*  7992 */     if (this.closed) {
/*       */       
/*  7994 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  7995 */       sQLException.fillInStackTrace();
/*  7996 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*  8002 */     int i = addNamedPara(paramString);
/*  8003 */     setShortInternal(i, paramShort);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setSQLXML(String paramString, SQLXML paramSQLXML) throws SQLException {
/*  8016 */     if (this.closed) {
/*       */       
/*  8018 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  8019 */       sQLException.fillInStackTrace();
/*  8020 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*  8026 */     int i = addNamedPara(paramString);
/*  8027 */     setSQLXMLInternal(i, paramSQLXML);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setString(String paramString1, String paramString2) throws SQLException {
/*  8040 */     if (this.closed) {
/*       */       
/*  8042 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  8043 */       sQLException.fillInStackTrace();
/*  8044 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*  8050 */     int i = addNamedPara(paramString1);
/*  8051 */     setStringInternal(i, paramString2);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setTime(String paramString, Time paramTime) throws SQLException {
/*  8064 */     if (this.closed) {
/*       */       
/*  8066 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  8067 */       sQLException.fillInStackTrace();
/*  8068 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*  8074 */     int i = addNamedPara(paramString);
/*  8075 */     setTimeInternal(i, paramTime);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setTime(String paramString, Time paramTime, Calendar paramCalendar) throws SQLException {
/*  8088 */     if (this.closed) {
/*       */       
/*  8090 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  8091 */       sQLException.fillInStackTrace();
/*  8092 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*  8098 */     int i = addNamedPara(paramString);
/*  8099 */     setTimeInternal(i, paramTime, paramCalendar);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setTimestamp(String paramString, Timestamp paramTimestamp) throws SQLException {
/*  8112 */     if (this.closed) {
/*       */       
/*  8114 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  8115 */       sQLException.fillInStackTrace();
/*  8116 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*  8122 */     int i = addNamedPara(paramString);
/*  8123 */     setTimestampInternal(i, paramTimestamp);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setTimestamp(String paramString, Timestamp paramTimestamp, Calendar paramCalendar) throws SQLException {
/*  8136 */     if (this.closed) {
/*       */       
/*  8138 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  8139 */       sQLException.fillInStackTrace();
/*  8140 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*  8146 */     int i = addNamedPara(paramString);
/*  8147 */     setTimestampInternal(i, paramTimestamp, paramCalendar);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setURL(String paramString, URL paramURL) throws SQLException {
/*  8160 */     if (this.closed) {
/*       */       
/*  8162 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  8163 */       sQLException.fillInStackTrace();
/*  8164 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*  8170 */     int i = addNamedPara(paramString);
/*  8171 */     setURLInternal(i, paramURL);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setARRAY(String paramString, ARRAY paramARRAY) throws SQLException {
/*  8184 */     if (this.closed) {
/*       */       
/*  8186 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  8187 */       sQLException.fillInStackTrace();
/*  8188 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*  8194 */     int i = addNamedPara(paramString);
/*  8195 */     setARRAYInternal(i, paramARRAY);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setBFILE(String paramString, BFILE paramBFILE) throws SQLException {
/*  8208 */     if (this.closed) {
/*       */       
/*  8210 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  8211 */       sQLException.fillInStackTrace();
/*  8212 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*  8218 */     int i = addNamedPara(paramString);
/*  8219 */     setBFILEInternal(i, paramBFILE);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setBfile(String paramString, BFILE paramBFILE) throws SQLException {
/*  8232 */     if (this.closed) {
/*       */       
/*  8234 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  8235 */       sQLException.fillInStackTrace();
/*  8236 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*  8242 */     int i = addNamedPara(paramString);
/*  8243 */     setBfileInternal(i, paramBFILE);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setBinaryFloat(String paramString, float paramFloat) throws SQLException {
/*  8256 */     if (this.closed) {
/*       */       
/*  8258 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  8259 */       sQLException.fillInStackTrace();
/*  8260 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*  8266 */     int i = addNamedPara(paramString);
/*  8267 */     setBinaryFloatInternal(i, paramFloat);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setBinaryFloat(String paramString, BINARY_FLOAT paramBINARY_FLOAT) throws SQLException {
/*  8280 */     if (this.closed) {
/*       */       
/*  8282 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  8283 */       sQLException.fillInStackTrace();
/*  8284 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*  8290 */     int i = addNamedPara(paramString);
/*  8291 */     setBinaryFloatInternal(i, paramBINARY_FLOAT);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setBinaryDouble(String paramString, double paramDouble) throws SQLException {
/*  8304 */     if (this.closed) {
/*       */       
/*  8306 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  8307 */       sQLException.fillInStackTrace();
/*  8308 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*  8314 */     int i = addNamedPara(paramString);
/*  8315 */     setBinaryDoubleInternal(i, paramDouble);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setBinaryDouble(String paramString, BINARY_DOUBLE paramBINARY_DOUBLE) throws SQLException {
/*  8328 */     if (this.closed) {
/*       */       
/*  8330 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  8331 */       sQLException.fillInStackTrace();
/*  8332 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*  8338 */     int i = addNamedPara(paramString);
/*  8339 */     setBinaryDoubleInternal(i, paramBINARY_DOUBLE);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setBLOB(String paramString, BLOB paramBLOB) throws SQLException {
/*  8352 */     if (this.closed) {
/*       */       
/*  8354 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  8355 */       sQLException.fillInStackTrace();
/*  8356 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*  8362 */     int i = addNamedPara(paramString);
/*  8363 */     setBLOBInternal(i, paramBLOB);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setCHAR(String paramString, CHAR paramCHAR) throws SQLException {
/*  8376 */     if (this.closed) {
/*       */       
/*  8378 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  8379 */       sQLException.fillInStackTrace();
/*  8380 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*  8386 */     int i = addNamedPara(paramString);
/*  8387 */     setCHARInternal(i, paramCHAR);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setCLOB(String paramString, CLOB paramCLOB) throws SQLException {
/*  8400 */     if (this.closed) {
/*       */       
/*  8402 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  8403 */       sQLException.fillInStackTrace();
/*  8404 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*  8410 */     int i = addNamedPara(paramString);
/*  8411 */     setCLOBInternal(i, paramCLOB);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setCursor(String paramString, ResultSet paramResultSet) throws SQLException {
/*  8424 */     if (this.closed) {
/*       */       
/*  8426 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  8427 */       sQLException.fillInStackTrace();
/*  8428 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*  8434 */     int i = addNamedPara(paramString);
/*  8435 */     setCursorInternal(i, paramResultSet);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setDATE(String paramString, DATE paramDATE) throws SQLException {
/*  8448 */     if (this.closed) {
/*       */       
/*  8450 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  8451 */       sQLException.fillInStackTrace();
/*  8452 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*  8458 */     int i = addNamedPara(paramString);
/*  8459 */     setDATEInternal(i, paramDATE);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setFixedCHAR(String paramString1, String paramString2) throws SQLException {
/*  8472 */     if (this.closed) {
/*       */       
/*  8474 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  8475 */       sQLException.fillInStackTrace();
/*  8476 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*  8482 */     int i = addNamedPara(paramString1);
/*  8483 */     setFixedCHARInternal(i, paramString2);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setINTERVALDS(String paramString, INTERVALDS paramINTERVALDS) throws SQLException {
/*  8496 */     if (this.closed) {
/*       */       
/*  8498 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  8499 */       sQLException.fillInStackTrace();
/*  8500 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*  8506 */     int i = addNamedPara(paramString);
/*  8507 */     setINTERVALDSInternal(i, paramINTERVALDS);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setINTERVALYM(String paramString, INTERVALYM paramINTERVALYM) throws SQLException {
/*  8520 */     if (this.closed) {
/*       */       
/*  8522 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  8523 */       sQLException.fillInStackTrace();
/*  8524 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*  8530 */     int i = addNamedPara(paramString);
/*  8531 */     setINTERVALYMInternal(i, paramINTERVALYM);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setNUMBER(String paramString, NUMBER paramNUMBER) throws SQLException {
/*  8544 */     if (this.closed) {
/*       */       
/*  8546 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  8547 */       sQLException.fillInStackTrace();
/*  8548 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*  8554 */     int i = addNamedPara(paramString);
/*  8555 */     setNUMBERInternal(i, paramNUMBER);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setOPAQUE(String paramString, OPAQUE paramOPAQUE) throws SQLException {
/*  8568 */     if (this.closed) {
/*       */       
/*  8570 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  8571 */       sQLException.fillInStackTrace();
/*  8572 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*  8578 */     int i = addNamedPara(paramString);
/*  8579 */     setOPAQUEInternal(i, paramOPAQUE);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setOracleObject(String paramString, Datum paramDatum) throws SQLException {
/*  8592 */     if (this.closed) {
/*       */       
/*  8594 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  8595 */       sQLException.fillInStackTrace();
/*  8596 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*  8602 */     int i = addNamedPara(paramString);
/*  8603 */     setOracleObjectInternal(i, paramDatum);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setORAData(String paramString, ORAData paramORAData) throws SQLException {
/*  8616 */     if (this.closed) {
/*       */       
/*  8618 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  8619 */       sQLException.fillInStackTrace();
/*  8620 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*  8626 */     int i = addNamedPara(paramString);
/*  8627 */     setORADataInternal(i, paramORAData);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setRAW(String paramString, RAW paramRAW) throws SQLException {
/*  8640 */     if (this.closed) {
/*       */       
/*  8642 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  8643 */       sQLException.fillInStackTrace();
/*  8644 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*  8650 */     int i = addNamedPara(paramString);
/*  8651 */     setRAWInternal(i, paramRAW);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setREF(String paramString, REF paramREF) throws SQLException {
/*  8664 */     if (this.closed) {
/*       */       
/*  8666 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  8667 */       sQLException.fillInStackTrace();
/*  8668 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*  8674 */     int i = addNamedPara(paramString);
/*  8675 */     setREFInternal(i, paramREF);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setRefType(String paramString, REF paramREF) throws SQLException {
/*  8688 */     if (this.closed) {
/*       */       
/*  8690 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  8691 */       sQLException.fillInStackTrace();
/*  8692 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*  8698 */     int i = addNamedPara(paramString);
/*  8699 */     setRefTypeInternal(i, paramREF);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setROWID(String paramString, ROWID paramROWID) throws SQLException {
/*  8712 */     if (this.closed) {
/*       */       
/*  8714 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  8715 */       sQLException.fillInStackTrace();
/*  8716 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*  8722 */     int i = addNamedPara(paramString);
/*  8723 */     setROWIDInternal(i, paramROWID);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setSTRUCT(String paramString, STRUCT paramSTRUCT) throws SQLException {
/*  8736 */     if (this.closed) {
/*       */       
/*  8738 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  8739 */       sQLException.fillInStackTrace();
/*  8740 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*  8746 */     int i = addNamedPara(paramString);
/*  8747 */     setSTRUCTInternal(i, paramSTRUCT);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setTIMESTAMPLTZ(String paramString, TIMESTAMPLTZ paramTIMESTAMPLTZ) throws SQLException {
/*  8760 */     if (this.closed) {
/*       */       
/*  8762 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  8763 */       sQLException.fillInStackTrace();
/*  8764 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*  8770 */     int i = addNamedPara(paramString);
/*  8771 */     setTIMESTAMPLTZInternal(i, paramTIMESTAMPLTZ);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setTIMESTAMPTZ(String paramString, TIMESTAMPTZ paramTIMESTAMPTZ) throws SQLException {
/*  8784 */     if (this.closed) {
/*       */       
/*  8786 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  8787 */       sQLException.fillInStackTrace();
/*  8788 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*  8794 */     int i = addNamedPara(paramString);
/*  8795 */     setTIMESTAMPTZInternal(i, paramTIMESTAMPTZ);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setTIMESTAMP(String paramString, TIMESTAMP paramTIMESTAMP) throws SQLException {
/*  8808 */     if (this.closed) {
/*       */       
/*  8810 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  8811 */       sQLException.fillInStackTrace();
/*  8812 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*  8818 */     int i = addNamedPara(paramString);
/*  8819 */     setTIMESTAMPInternal(i, paramTIMESTAMP);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setCustomDatum(String paramString, CustomDatum paramCustomDatum) throws SQLException {
/*  8832 */     if (this.closed) {
/*       */       
/*  8834 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  8835 */       sQLException.fillInStackTrace();
/*  8836 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*  8842 */     int i = addNamedPara(paramString);
/*  8843 */     setCustomDatumInternal(i, paramCustomDatum);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setBlob(String paramString, InputStream paramInputStream) throws SQLException {
/*  8856 */     if (this.closed) {
/*       */       
/*  8858 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  8859 */       sQLException.fillInStackTrace();
/*  8860 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*  8866 */     int i = addNamedPara(paramString);
/*  8867 */     setBlobInternal(i, paramInputStream);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setBlob(String paramString, InputStream paramInputStream, long paramLong) throws SQLException {
/*  8880 */     if (this.closed) {
/*       */       
/*  8882 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  8883 */       sQLException.fillInStackTrace();
/*  8884 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */ 
/*       */     
/*  8889 */     if (paramLong < 0L) {
/*       */       
/*  8891 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68, "length for setBlob() cannot be negative");
/*  8892 */       sQLException.fillInStackTrace();
/*  8893 */       throw sQLException;
/*       */     } 
/*       */     
/*  8896 */     int i = addNamedPara(paramString);
/*  8897 */     setBlobInternal(i, paramInputStream, paramLong);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setClob(String paramString, Reader paramReader) throws SQLException {
/*  8910 */     if (this.closed) {
/*       */       
/*  8912 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  8913 */       sQLException.fillInStackTrace();
/*  8914 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*  8920 */     int i = addNamedPara(paramString);
/*  8921 */     setClobInternal(i, paramReader);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setClob(String paramString, Reader paramReader, long paramLong) throws SQLException {
/*  8934 */     if (this.closed) {
/*       */       
/*  8936 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  8937 */       sQLException.fillInStackTrace();
/*  8938 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*  8944 */     if (paramLong < 0L) {
/*       */       
/*  8946 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68, "length for setClob() cannot be negative");
/*  8947 */       sQLException.fillInStackTrace();
/*  8948 */       throw sQLException;
/*       */     } 
/*  8950 */     int i = addNamedPara(paramString);
/*  8951 */     setClobInternal(i, paramReader, paramLong);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setNClob(String paramString, Reader paramReader) throws SQLException {
/*  8964 */     if (this.closed) {
/*       */       
/*  8966 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  8967 */       sQLException.fillInStackTrace();
/*  8968 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*  8974 */     int i = addNamedPara(paramString);
/*  8975 */     setNClobInternal(i, paramReader);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setNClob(String paramString, Reader paramReader, long paramLong) throws SQLException {
/*  8988 */     if (this.closed) {
/*       */       
/*  8990 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  8991 */       sQLException.fillInStackTrace();
/*  8992 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*  8998 */     int i = addNamedPara(paramString);
/*  8999 */     setNClobInternal(i, paramReader, paramLong);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setAsciiStream(String paramString, InputStream paramInputStream) throws SQLException {
/*  9012 */     if (this.closed) {
/*       */       
/*  9014 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  9015 */       sQLException.fillInStackTrace();
/*  9016 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*  9022 */     int i = addNamedPara(paramString);
/*  9023 */     setAsciiStreamInternal(i, paramInputStream);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setAsciiStream(String paramString, InputStream paramInputStream, int paramInt) throws SQLException {
/*  9036 */     if (this.closed) {
/*       */       
/*  9038 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  9039 */       sQLException.fillInStackTrace();
/*  9040 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*  9046 */     int i = addNamedPara(paramString);
/*  9047 */     setAsciiStreamInternal(i, paramInputStream, paramInt);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setAsciiStream(String paramString, InputStream paramInputStream, long paramLong) throws SQLException {
/*  9060 */     if (this.closed) {
/*       */       
/*  9062 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  9063 */       sQLException.fillInStackTrace();
/*  9064 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*  9070 */     int i = addNamedPara(paramString);
/*  9071 */     setAsciiStreamInternal(i, paramInputStream, paramLong);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setBinaryStream(String paramString, InputStream paramInputStream) throws SQLException {
/*  9084 */     if (this.closed) {
/*       */       
/*  9086 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  9087 */       sQLException.fillInStackTrace();
/*  9088 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*  9094 */     int i = addNamedPara(paramString);
/*  9095 */     setBinaryStreamInternal(i, paramInputStream);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setBinaryStream(String paramString, InputStream paramInputStream, int paramInt) throws SQLException {
/*  9108 */     if (this.closed) {
/*       */       
/*  9110 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  9111 */       sQLException.fillInStackTrace();
/*  9112 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*  9118 */     int i = addNamedPara(paramString);
/*  9119 */     setBinaryStreamInternal(i, paramInputStream, paramInt);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setBinaryStream(String paramString, InputStream paramInputStream, long paramLong) throws SQLException {
/*  9132 */     if (this.closed) {
/*       */       
/*  9134 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  9135 */       sQLException.fillInStackTrace();
/*  9136 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*  9142 */     int i = addNamedPara(paramString);
/*  9143 */     setBinaryStreamInternal(i, paramInputStream, paramLong);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setCharacterStream(String paramString, Reader paramReader) throws SQLException {
/*  9156 */     if (this.closed) {
/*       */       
/*  9158 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  9159 */       sQLException.fillInStackTrace();
/*  9160 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*  9166 */     int i = addNamedPara(paramString);
/*  9167 */     setCharacterStreamInternal(i, paramReader);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setCharacterStream(String paramString, Reader paramReader, int paramInt) throws SQLException {
/*  9180 */     if (this.closed) {
/*       */       
/*  9182 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  9183 */       sQLException.fillInStackTrace();
/*  9184 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*  9190 */     int i = addNamedPara(paramString);
/*  9191 */     setCharacterStreamInternal(i, paramReader, paramInt);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setCharacterStream(String paramString, Reader paramReader, long paramLong) throws SQLException {
/*  9204 */     if (this.closed) {
/*       */       
/*  9206 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  9207 */       sQLException.fillInStackTrace();
/*  9208 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*  9214 */     int i = addNamedPara(paramString);
/*  9215 */     setCharacterStreamInternal(i, paramReader, paramLong);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setNCharacterStream(String paramString, Reader paramReader) throws SQLException {
/*  9228 */     if (this.closed) {
/*       */       
/*  9230 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  9231 */       sQLException.fillInStackTrace();
/*  9232 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*  9238 */     int i = addNamedPara(paramString);
/*  9239 */     setNCharacterStreamInternal(i, paramReader);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setNCharacterStream(String paramString, Reader paramReader, long paramLong) throws SQLException {
/*  9252 */     if (this.closed) {
/*       */       
/*  9254 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  9255 */       sQLException.fillInStackTrace();
/*  9256 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*  9262 */     int i = addNamedPara(paramString);
/*  9263 */     setNCharacterStreamInternal(i, paramReader, paramLong);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setUnicodeStream(String paramString, InputStream paramInputStream, int paramInt) throws SQLException {
/*  9276 */     if (this.closed) {
/*       */       
/*  9278 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  9279 */       sQLException.fillInStackTrace();
/*  9280 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*  9286 */     int i = addNamedPara(paramString);
/*  9287 */     setUnicodeStreamInternal(i, paramInputStream, paramInt);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setNull(String paramString1, int paramInt, String paramString2) throws SQLException {
/*  9301 */     if (this.closed) {
/*       */       
/*  9303 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  9304 */       sQLException.fillInStackTrace();
/*  9305 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*  9311 */     int i = addNamedPara(paramString1);
/*  9312 */     setNullInternal(i, paramInt, paramString2);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setNull(String paramString, int paramInt) throws SQLException {
/*  9326 */     if (this.closed) {
/*       */       
/*  9328 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  9329 */       sQLException.fillInStackTrace();
/*  9330 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*  9336 */     int i = addNamedPara(paramString);
/*  9337 */     setNullInternal(i, paramInt);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setStructDescriptor(String paramString, StructDescriptor paramStructDescriptor) throws SQLException {
/*  9351 */     if (this.closed) {
/*       */       
/*  9353 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  9354 */       sQLException.fillInStackTrace();
/*  9355 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */     
/*  9359 */     int i = addNamedPara(paramString);
/*  9360 */     setStructDescriptorInternal(i, paramStructDescriptor);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setObject(String paramString, Object paramObject, int paramInt1, int paramInt2) throws SQLException {
/*  9376 */     if (this.closed) {
/*       */       
/*  9378 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  9379 */       sQLException.fillInStackTrace();
/*  9380 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */     
/*  9384 */     int i = addNamedPara(paramString);
/*  9385 */     setObjectInternal(i, paramObject, paramInt1, paramInt2);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setPlsqlIndexTable(int paramInt1, Object paramObject, int paramInt2, int paramInt3, int paramInt4, int paramInt5) throws SQLException {
/*  9397 */     synchronized (this.connection) {
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*  9404 */       if (this.closed) {
/*       */         
/*  9406 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  9407 */         sQLException.fillInStackTrace();
/*  9408 */         throw sQLException;
/*       */       } 
/*       */ 
/*       */       
/*  9412 */       this.atLeastOneOrdinalParameter = true;
/*  9413 */       setPlsqlIndexTableInternal(paramInt1, paramObject, paramInt2, paramInt3, paramInt4, paramInt5);
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   int addNamedPara(String paramString) throws SQLException {
/*  9431 */     if (this.closed) {
/*       */       
/*  9433 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  9434 */       sQLException.fillInStackTrace();
/*  9435 */       throw sQLException;
/*       */     } 
/*       */     
/*  9438 */     String str = paramString.toUpperCase().intern();
/*       */     
/*  9440 */     for (byte b = 0; b < this.parameterCount; b++) {
/*       */       
/*  9442 */       if (str == this.namedParameters[b]) {
/*  9443 */         return b + 1;
/*       */       }
/*       */     } 
/*  9446 */     if (this.parameterCount >= this.namedParameters.length) {
/*       */       
/*  9448 */       String[] arrayOfString = new String[this.namedParameters.length * 2];
/*  9449 */       System.arraycopy(this.namedParameters, 0, arrayOfString, 0, this.namedParameters.length);
/*  9450 */       this.namedParameters = arrayOfString;
/*       */     } 
/*       */     
/*  9453 */     this.namedParameters[this.parameterCount++] = str;
/*       */     
/*  9455 */     this.atLeastOneNamedParameter = true;
/*  9456 */     return this.parameterCount;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public Reader getCharacterStream(String paramString) throws SQLException {
/*  9471 */     if (!this.atLeastOneNamedParameter) {
/*       */ 
/*       */       
/*  9474 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/*  9475 */       sQLException.fillInStackTrace();
/*  9476 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */     
/*  9480 */     if (paramString == null) {
/*       */ 
/*       */       
/*  9483 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/*  9484 */       sQLException.fillInStackTrace();
/*  9485 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */     
/*  9489 */     String str = paramString.toUpperCase().intern();
/*       */     
/*       */     byte b;
/*  9492 */     for (b = 0; b < this.parameterCount; b++) {
/*       */       
/*  9494 */       if (str == this.namedParameters[b])
/*       */         break; 
/*       */     } 
/*  9497 */     b++;
/*       */     
/*  9499 */     Accessor accessor = null;
/*  9500 */     if (b <= 0 || b > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[b - 1]) == null) {
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*  9505 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 6);
/*  9506 */       sQLException.fillInStackTrace();
/*  9507 */       throw sQLException;
/*       */     } 
/*       */     
/*  9510 */     this.lastIndex = b;
/*       */     
/*  9512 */     if (this.streamList != null) {
/*  9513 */       closeUsedStreams(b);
/*       */     }
/*       */     
/*  9516 */     return accessor.getCharacterStream(this.currentRank);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public InputStream getUnicodeStream(String paramString) throws SQLException {
/*  9529 */     if (!this.atLeastOneNamedParameter) {
/*       */ 
/*       */       
/*  9532 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/*  9533 */       sQLException.fillInStackTrace();
/*  9534 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */     
/*  9538 */     if (paramString == null) {
/*       */ 
/*       */       
/*  9541 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/*  9542 */       sQLException.fillInStackTrace();
/*  9543 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */     
/*  9547 */     String str = paramString.toUpperCase().intern();
/*       */     
/*       */     byte b;
/*  9550 */     for (b = 0; b < this.parameterCount; b++) {
/*       */       
/*  9552 */       if (str == this.namedParameters[b])
/*       */         break; 
/*       */     } 
/*  9555 */     b++;
/*       */     
/*  9557 */     Accessor accessor = null;
/*  9558 */     if (b <= 0 || b > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[b - 1]) == null) {
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*  9563 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 6);
/*  9564 */       sQLException.fillInStackTrace();
/*  9565 */       throw sQLException;
/*       */     } 
/*       */     
/*  9568 */     this.lastIndex = b;
/*       */     
/*  9570 */     if (this.streamList != null) {
/*  9571 */       closeUsedStreams(b);
/*       */     }
/*       */     
/*  9574 */     return accessor.getUnicodeStream(this.currentRank);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public InputStream getBinaryStream(String paramString) throws SQLException {
/*  9587 */     if (!this.atLeastOneNamedParameter) {
/*       */ 
/*       */       
/*  9590 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/*  9591 */       sQLException.fillInStackTrace();
/*  9592 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */     
/*  9596 */     if (paramString == null) {
/*       */ 
/*       */       
/*  9599 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/*  9600 */       sQLException.fillInStackTrace();
/*  9601 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */     
/*  9605 */     String str = paramString.toUpperCase().intern();
/*       */     
/*       */     byte b;
/*  9608 */     for (b = 0; b < this.parameterCount; b++) {
/*       */       
/*  9610 */       if (str == this.namedParameters[b])
/*       */         break; 
/*       */     } 
/*  9613 */     b++;
/*       */     
/*  9615 */     Accessor accessor = null;
/*  9616 */     if (b <= 0 || b > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[b - 1]) == null) {
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*  9621 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 6);
/*  9622 */       sQLException.fillInStackTrace();
/*  9623 */       throw sQLException;
/*       */     } 
/*       */     
/*  9626 */     this.lastIndex = b;
/*       */     
/*  9628 */     if (this.streamList != null) {
/*  9629 */       closeUsedStreams(b);
/*       */     }
/*       */     
/*  9632 */     return accessor.getBinaryStream(this.currentRank);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public RowId getRowId(int paramInt) throws SQLException {
/*  9646 */     if (this.closed) {
/*       */       
/*  9648 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  9649 */       sQLException.fillInStackTrace();
/*  9650 */       throw sQLException;
/*       */     } 
/*       */     
/*  9653 */     if (this.atLeastOneNamedParameter) {
/*       */ 
/*       */       
/*  9656 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/*  9657 */       sQLException.fillInStackTrace();
/*  9658 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */     
/*  9662 */     Accessor accessor = null;
/*  9663 */     if (paramInt <= 0 || paramInt > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[paramInt - 1]) == null) {
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*  9668 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/*  9669 */       sQLException.fillInStackTrace();
/*  9670 */       throw sQLException;
/*       */     } 
/*       */     
/*  9673 */     this.lastIndex = paramInt;
/*       */     
/*  9675 */     if (this.streamList != null) {
/*  9676 */       closeUsedStreams(paramInt);
/*       */     }
/*       */     
/*  9679 */     return (RowId)accessor.getROWID(this.currentRank);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public RowId getRowId(String paramString) throws SQLException {
/*  9692 */     if (!this.atLeastOneNamedParameter) {
/*       */ 
/*       */       
/*  9695 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/*  9696 */       sQLException.fillInStackTrace();
/*  9697 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */     
/*  9701 */     if (paramString == null) {
/*       */ 
/*       */       
/*  9704 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/*  9705 */       sQLException.fillInStackTrace();
/*  9706 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */     
/*  9710 */     String str = paramString.toUpperCase().intern();
/*       */     
/*       */     byte b;
/*  9713 */     for (b = 0; b < this.parameterCount; b++) {
/*       */       
/*  9715 */       if (str == this.namedParameters[b])
/*       */         break; 
/*       */     } 
/*  9718 */     b++;
/*       */     
/*  9720 */     Accessor accessor = null;
/*  9721 */     if (b <= 0 || b > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[b - 1]) == null) {
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*  9726 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 6);
/*  9727 */       sQLException.fillInStackTrace();
/*  9728 */       throw sQLException;
/*       */     } 
/*       */     
/*  9731 */     this.lastIndex = b;
/*       */     
/*  9733 */     if (this.streamList != null) {
/*  9734 */       closeUsedStreams(b);
/*       */     }
/*       */     
/*  9737 */     return (RowId)accessor.getROWID(this.currentRank);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public NClob getNClob(int paramInt) throws SQLException {
/*  9751 */     if (this.closed) {
/*       */       
/*  9753 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  9754 */       sQLException.fillInStackTrace();
/*  9755 */       throw sQLException;
/*       */     } 
/*       */     
/*  9758 */     if (this.atLeastOneNamedParameter) {
/*       */ 
/*       */       
/*  9761 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/*  9762 */       sQLException.fillInStackTrace();
/*  9763 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */     
/*  9767 */     Accessor accessor = null;
/*  9768 */     if (paramInt <= 0 || paramInt > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[paramInt - 1]) == null) {
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*  9773 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/*  9774 */       sQLException.fillInStackTrace();
/*  9775 */       throw sQLException;
/*       */     } 
/*       */     
/*  9778 */     this.lastIndex = paramInt;
/*       */     
/*  9780 */     if (this.streamList != null) {
/*  9781 */       closeUsedStreams(paramInt);
/*       */     }
/*       */     
/*  9784 */     return accessor.getNClob(this.currentRank);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public NClob getNClob(String paramString) throws SQLException {
/*  9797 */     if (!this.atLeastOneNamedParameter) {
/*       */ 
/*       */       
/*  9800 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/*  9801 */       sQLException.fillInStackTrace();
/*  9802 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */     
/*  9806 */     if (paramString == null) {
/*       */ 
/*       */       
/*  9809 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/*  9810 */       sQLException.fillInStackTrace();
/*  9811 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */     
/*  9815 */     String str = paramString.toUpperCase().intern();
/*       */     
/*       */     byte b;
/*  9818 */     for (b = 0; b < this.parameterCount; b++) {
/*       */       
/*  9820 */       if (str == this.namedParameters[b])
/*       */         break; 
/*       */     } 
/*  9823 */     b++;
/*       */     
/*  9825 */     Accessor accessor = null;
/*  9826 */     if (b <= 0 || b > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[b - 1]) == null) {
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*  9831 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 6);
/*  9832 */       sQLException.fillInStackTrace();
/*  9833 */       throw sQLException;
/*       */     } 
/*       */     
/*  9836 */     this.lastIndex = b;
/*       */     
/*  9838 */     if (this.streamList != null) {
/*  9839 */       closeUsedStreams(b);
/*       */     }
/*       */     
/*  9842 */     return accessor.getNClob(this.currentRank);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public SQLXML getSQLXML(int paramInt) throws SQLException {
/*  9855 */     if (this.closed) {
/*       */       
/*  9857 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  9858 */       sQLException.fillInStackTrace();
/*  9859 */       throw sQLException;
/*       */     } 
/*       */     
/*  9862 */     if (this.atLeastOneNamedParameter) {
/*       */ 
/*       */       
/*  9865 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/*  9866 */       sQLException.fillInStackTrace();
/*  9867 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */     
/*  9871 */     Accessor accessor = null;
/*  9872 */     if (paramInt <= 0 || paramInt > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[paramInt - 1]) == null) {
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*  9877 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/*  9878 */       sQLException.fillInStackTrace();
/*  9879 */       throw sQLException;
/*       */     } 
/*       */     
/*  9882 */     this.lastIndex = paramInt;
/*       */     
/*  9884 */     if (this.streamList != null) {
/*  9885 */       closeUsedStreams(paramInt);
/*       */     }
/*  9887 */     return accessor.getSQLXML(this.currentRank);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public SQLXML getSQLXML(String paramString) throws SQLException {
/*  9900 */     if (!this.atLeastOneNamedParameter) {
/*       */ 
/*       */       
/*  9903 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/*  9904 */       sQLException.fillInStackTrace();
/*  9905 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */     
/*  9909 */     if (paramString == null) {
/*       */ 
/*       */       
/*  9912 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/*  9913 */       sQLException.fillInStackTrace();
/*  9914 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */     
/*  9918 */     String str = paramString.toUpperCase().intern();
/*       */     
/*       */     byte b;
/*  9921 */     for (b = 0; b < this.parameterCount; b++) {
/*       */       
/*  9923 */       if (str == this.namedParameters[b])
/*       */         break; 
/*       */     } 
/*  9926 */     b++;
/*       */     
/*  9928 */     Accessor accessor = null;
/*  9929 */     if (b <= 0 || b > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[b - 1]) == null) {
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*  9934 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 6);
/*  9935 */       sQLException.fillInStackTrace();
/*  9936 */       throw sQLException;
/*       */     } 
/*       */     
/*  9939 */     this.lastIndex = b;
/*       */     
/*  9941 */     if (this.streamList != null) {
/*  9942 */       closeUsedStreams(b);
/*       */     }
/*  9944 */     return accessor.getSQLXML(this.currentRank);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public String getNString(int paramInt) throws SQLException {
/*  9958 */     if (this.closed) {
/*       */       
/*  9960 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  9961 */       sQLException.fillInStackTrace();
/*  9962 */       throw sQLException;
/*       */     } 
/*       */     
/*  9965 */     if (this.atLeastOneNamedParameter) {
/*       */ 
/*       */       
/*  9968 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/*  9969 */       sQLException.fillInStackTrace();
/*  9970 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */     
/*  9974 */     Accessor accessor = null;
/*  9975 */     if (paramInt <= 0 || paramInt > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[paramInt - 1]) == null) {
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*  9980 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/*  9981 */       sQLException.fillInStackTrace();
/*  9982 */       throw sQLException;
/*       */     } 
/*       */     
/*  9985 */     this.lastIndex = paramInt;
/*       */     
/*  9987 */     if (this.streamList != null) {
/*  9988 */       closeUsedStreams(paramInt);
/*       */     }
/*       */     
/*  9991 */     return accessor.getNString(this.currentRank);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public String getNString(String paramString) throws SQLException {
/* 10004 */     if (!this.atLeastOneNamedParameter) {
/*       */ 
/*       */       
/* 10007 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 10008 */       sQLException.fillInStackTrace();
/* 10009 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */     
/* 10013 */     if (paramString == null) {
/*       */ 
/*       */       
/* 10016 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/* 10017 */       sQLException.fillInStackTrace();
/* 10018 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */     
/* 10022 */     String str = paramString.toUpperCase().intern();
/*       */     
/*       */     byte b;
/* 10025 */     for (b = 0; b < this.parameterCount; b++) {
/*       */       
/* 10027 */       if (str == this.namedParameters[b])
/*       */         break; 
/*       */     } 
/* 10030 */     b++;
/*       */     
/* 10032 */     Accessor accessor = null;
/* 10033 */     if (b <= 0 || b > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[b - 1]) == null) {
/*       */ 
/*       */ 
/*       */ 
/*       */       
/* 10038 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 6);
/* 10039 */       sQLException.fillInStackTrace();
/* 10040 */       throw sQLException;
/*       */     } 
/*       */     
/* 10043 */     this.lastIndex = b;
/*       */     
/* 10045 */     if (this.streamList != null) {
/* 10046 */       closeUsedStreams(b);
/*       */     }
/*       */     
/* 10049 */     return accessor.getNString(this.currentRank);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public Reader getNCharacterStream(int paramInt) throws SQLException {
/* 10063 */     if (this.closed) {
/*       */       
/* 10065 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 10066 */       sQLException.fillInStackTrace();
/* 10067 */       throw sQLException;
/*       */     } 
/*       */     
/* 10070 */     if (this.atLeastOneNamedParameter) {
/*       */ 
/*       */       
/* 10073 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 10074 */       sQLException.fillInStackTrace();
/* 10075 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */     
/* 10079 */     Accessor accessor = null;
/* 10080 */     if (paramInt <= 0 || paramInt > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[paramInt - 1]) == null) {
/*       */ 
/*       */ 
/*       */ 
/*       */       
/* 10085 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 10086 */       sQLException.fillInStackTrace();
/* 10087 */       throw sQLException;
/*       */     } 
/*       */     
/* 10090 */     this.lastIndex = paramInt;
/*       */     
/* 10092 */     if (this.streamList != null) {
/* 10093 */       closeUsedStreams(paramInt);
/*       */     }
/*       */     
/* 10096 */     return accessor.getNCharacterStream(this.currentRank);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public Reader getNCharacterStream(String paramString) throws SQLException {
/* 10109 */     if (!this.atLeastOneNamedParameter) {
/*       */ 
/*       */       
/* 10112 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 10113 */       sQLException.fillInStackTrace();
/* 10114 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */     
/* 10118 */     if (paramString == null) {
/*       */ 
/*       */       
/* 10121 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/* 10122 */       sQLException.fillInStackTrace();
/* 10123 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */     
/* 10127 */     String str = paramString.toUpperCase().intern();
/*       */     
/*       */     byte b;
/* 10130 */     for (b = 0; b < this.parameterCount; b++) {
/*       */       
/* 10132 */       if (str == this.namedParameters[b])
/*       */         break; 
/*       */     } 
/* 10135 */     b++;
/*       */     
/* 10137 */     Accessor accessor = null;
/* 10138 */     if (b <= 0 || b > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[b - 1]) == null) {
/*       */ 
/*       */ 
/*       */ 
/*       */       
/* 10143 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 6);
/* 10144 */       sQLException.fillInStackTrace();
/* 10145 */       throw sQLException;
/*       */     } 
/*       */     
/* 10148 */     this.lastIndex = b;
/*       */     
/* 10150 */     if (this.streamList != null) {
/* 10151 */       closeUsedStreams(b);
/*       */     }
/*       */     
/* 10154 */     return accessor.getNCharacterStream(this.currentRank);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public <T> T getObject(int paramInt, Class<T> paramClass) throws SQLException {
/* 10171 */     if (this.closed) {
/*       */       
/* 10173 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 10174 */       sQLException.fillInStackTrace();
/* 10175 */       throw sQLException;
/*       */     } 
/*       */     
/* 10178 */     if (this.atLeastOneNamedParameter) {
/*       */ 
/*       */       
/* 10181 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 10182 */       sQLException.fillInStackTrace();
/* 10183 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */     
/* 10187 */     Accessor accessor = null;
/* 10188 */     if (paramInt <= 0 || paramInt > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[paramInt - 1]) == null) {
/*       */ 
/*       */ 
/*       */ 
/*       */       
/* 10193 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 10194 */       sQLException.fillInStackTrace();
/* 10195 */       throw sQLException;
/*       */     } 
/*       */     
/* 10198 */     this.lastIndex = paramInt;
/*       */     
/* 10200 */     if (this.streamList != null) {
/* 10201 */       closeUsedStreams(paramInt);
/*       */     }
/* 10203 */     return accessor.getObject(this.currentRank, paramClass);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public <T> T getObject(String paramString, Class<T> paramClass) throws SQLException {
/* 10215 */     if (!this.atLeastOneNamedParameter) {
/*       */ 
/*       */       
/* 10218 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 10219 */       sQLException.fillInStackTrace();
/* 10220 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */     
/* 10224 */     if (paramString == null) {
/*       */ 
/*       */       
/* 10227 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/* 10228 */       sQLException.fillInStackTrace();
/* 10229 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */     
/* 10233 */     String str = paramString.toUpperCase().intern();
/*       */     
/*       */     byte b;
/* 10236 */     for (b = 0; b < this.parameterCount; b++) {
/*       */       
/* 10238 */       if (str == this.namedParameters[b])
/*       */         break; 
/*       */     } 
/* 10241 */     b++;
/*       */     
/* 10243 */     Accessor accessor = null;
/* 10244 */     if (b <= 0 || b > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[b - 1]) == null) {
/*       */ 
/*       */ 
/*       */ 
/*       */       
/* 10249 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 6);
/* 10250 */       sQLException.fillInStackTrace();
/* 10251 */       throw sQLException;
/*       */     } 
/*       */     
/* 10254 */     this.lastIndex = b;
/*       */     
/* 10256 */     if (this.streamList != null) {
/* 10257 */       closeUsedStreams(b);
/*       */     }
/* 10259 */     return accessor.getObject(this.currentRank, paramClass);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/* 10267 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*       */   public static final String BUILD_DATE = "Thu_Apr_04_15:09:24_PDT_2013";
/*       */   public static final boolean TRACE = false;
/*       */ }


/* Location:              C:\Users\olatu\OneDrive\Documents\Calypso\syncbase\sync_base.jar!\BOOT-INF\classes\ojdbc.jar!\oracle\jdbc\driver\OracleCallableStatement.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */