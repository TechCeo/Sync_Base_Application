/*     */ package oracle.jdbc.driver;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.sql.SQLException;
/*     */ import oracle.jdbc.OracleResultSetMetaData;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class T4CLongAccessor
/*     */   extends LongAccessor
/*     */   implements T4CAccessor
/*     */ {
/*     */   T4CMAREngine mare;
/*     */   static final int PLSQL_MAXLENGTH = 32760;
/*  32 */   byte[][] data = (byte[][])null;
/*  33 */   int[] nbBytesRead = null;
/*  34 */   int[] bytesReadSoFar = null;
/*     */   
/*     */   private T4CMarshaller marshaller;
/*     */   
/*     */   T4CLongAccessor(OracleStatement paramOracleStatement, int paramInt1, int paramInt2, short paramShort, int paramInt3, T4CMAREngine paramT4CMAREngine) throws SQLException
/*     */   {
/*  40 */     super(paramOracleStatement, paramInt1, paramInt2, paramShort, paramInt3);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 271 */     this.marshaller = null; this.mare = paramT4CMAREngine; if (paramOracleStatement.isFetchStreams) { this.data = new byte[paramOracleStatement.rowPrefetch][]; for (byte b = 0; b < paramOracleStatement.rowPrefetch; b++) this.data[b] = new byte[4080];  this.nbBytesRead = new int[paramOracleStatement.rowPrefetch]; this.bytesReadSoFar = new int[paramOracleStatement.rowPrefetch]; }  } public T4CMAREngine getMAREngine() { return this.mare; } public void unmarshalColumnMetadata() throws SQLException, IOException { if (this.statement.statementType != 2 && !this.statement.sqlKind.isPlsqlOrCall() && this.securityAttribute == OracleResultSetMetaData.SecurityAttribute.ENABLED) setRowMetadata(this.lastRowProcessed, (byte)this.mare.unmarshalUB1());  } T4CLongAccessor(OracleStatement paramOracleStatement, int paramInt1, int paramInt2, boolean paramBoolean, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, short paramShort, int paramInt8, int paramInt9, T4CMAREngine paramT4CMAREngine) throws SQLException { super(paramOracleStatement, paramInt1, paramInt2, paramBoolean, paramInt3, paramInt4, paramInt5, paramInt6, paramInt7, paramShort); this.marshaller = null; this.mare = paramT4CMAREngine; if (paramOracleStatement != null && paramOracleStatement.implicitDefineForLobPrefetchDone) { this.definedColumnType = 0; this.definedColumnSize = 0; } else { this.definedColumnType = paramInt8; this.definedColumnSize = paramInt9; }  if (paramOracleStatement.isFetchStreams) { this.data = new byte[paramOracleStatement.rowPrefetch][]; for (byte b = 0; b < paramOracleStatement.rowPrefetch; b++) this.data[b] = new byte[4080];  this.nbBytesRead = new int[paramOracleStatement.rowPrefetch]; this.bytesReadSoFar = new int[paramOracleStatement.rowPrefetch]; }  }
/*     */   public void processIndicator(int paramInt) throws IOException, SQLException { if ((this.internalType == 1 && this.describeType == 112) || (this.internalType == 23 && this.describeType == 113)) { this.mare.unmarshalUB2(); this.mare.unmarshalUB2(); } else if (this.statement.connection.versionNumber < 9200) { this.mare.unmarshalSB2(); if (!this.statement.sqlKind.isPlsqlOrCall()) this.mare.unmarshalSB2();  } else if (this.statement.sqlKind.isPlsqlOrCall() || this.isDMLReturnedParam) { this.mare.processIndicator((paramInt <= 0), paramInt); }  }
/* 273 */   int getPreviousRowProcessed() { if (this.previousRowProcessed == -1) this.previousRowProcessed = this.statement.rowPrefetchInLastFetch - 1;  return this.previousRowProcessed; } private final T4CMarshaller getMarshaller() { if (this.marshaller == null) this.marshaller = (this.describeType == 8 || this.describeType == 112) ? T4CMarshaller.LONG : T4CMarshaller.VARCHAR;
/*     */ 
/*     */ 
/*     */     
/* 277 */     return this.marshaller; } void copyRow() throws SQLException, IOException { if (this.isNullByDescribe) { setNull(this.lastRowProcessed, true); } else if (this.lastRowProcessed == 0) { if (this.previousRowProcessed == -1)
/*     */         this.previousRowProcessed = this.statement.rowPrefetchInLastFetch - 1;  long l = getOffset(this.previousRowProcessed); setNull(this.lastRowProcessed, isNull(this.previousRowProcessed)); this.rowMetadata[this.lastRowProcessed] = this.rowMetadata[this.previousRowProcessed]; if (!isNull(this.previousRowProcessed)) { setOffset(this.lastRowProcessed); ((DynamicByteArray)this.rowData).copyLeft(l, getLength(this.previousRowProcessed)); setLength(this.lastRowProcessed, getLength(this.previousRowProcessed)); }
/*     */        }
/*     */     else { setNull(this.lastRowProcessed, isNull(this.previousRowProcessed)); this.rowMetadata[this.lastRowProcessed] = this.rowMetadata[this.previousRowProcessed]; setOffset(this.lastRowProcessed, getOffset(this.previousRowProcessed)); setLength(this.lastRowProcessed, getLength(this.previousRowProcessed)); }
/*     */      this.previousRowProcessed = this.lastRowProcessed; this.lastRowProcessed++; }
/*     */   boolean unmarshalOneRow() throws SQLException, IOException { return getMarshaller().unmarshalOneRow(this); }
/* 283 */   boolean isNullByDescribe() { return false; } int readStreamFromWire(byte[] paramArrayOfbyte, int paramInt1, int paramInt2, int[] paramArrayOfint, boolean[] paramArrayOfboolean1, boolean[] paramArrayOfboolean2, T4CMAREngine paramT4CMAREngine, T4CTTIoer paramT4CTTIoer) throws SQLException, IOException { return getMarshaller().readStreamFromWire(paramArrayOfbyte, paramInt1, paramInt2, paramArrayOfint, paramArrayOfboolean1, paramArrayOfboolean2, paramT4CMAREngine, paramT4CTTIoer); }
/*     */   void fetchNextColumns() throws SQLException { this.statement.continueReadRow(this.columnPosition); }
/*     */   int readStream(byte[] paramArrayOfbyte, int paramInt) throws SQLException, IOException { int i = this.lastRowProcessed; if (this.statement.isFetchStreams) { int k = getLength(i); int m = this.bytesReadSoFar[i]; if (m == k)
/*     */         return -1;  int n = 0; if (paramInt <= k - m) { n = paramInt; } else { n = k - m; }
/*     */        this.rowData.setPosition(getOffset(i) + m); this.rowData.getBytes(paramArrayOfbyte, 0, n); this.bytesReadSoFar[i] = this.bytesReadSoFar[i] + n; return n; }
/*     */      int j = readStreamFromWire(paramArrayOfbyte, 0, paramInt, this.escapeSequenceArr, this.readHeaderArr, this.readAsNonStreamArr, this.mare, ((T4CConnection)this.statement.connection).oer); if (this.statement.connection.checksumMode.needToCalculateFetchChecksum() && j != -1) { long l = CRC64.updateChecksum(this.statement.checkSum, paramArrayOfbyte, 0, j); this.statement.checkSum = l; }
/*     */      return j; }
/* 290 */   long updateChecksum(long paramLong, int paramInt) throws SQLException { if (isNull(paramInt))
/*     */     {
/* 292 */       paramLong = CRC64.updateChecksum(paramLong, NULL_DATA_BYTES, 0, NULL_DATA_BYTES.length);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 298 */     return paramLong; }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 303 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*     */   public static final String BUILD_DATE = "Thu_Apr_04_15:09:24_PDT_2013";
/*     */   public static final boolean TRACE = false;
/*     */ }


/* Location:              C:\Users\olatu\OneDrive\Documents\Calypso\syncbase\sync_base.jar!\BOOT-INF\classes\ojdbc.jar!\oracle\jdbc\driver\T4CLongAccessor.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */