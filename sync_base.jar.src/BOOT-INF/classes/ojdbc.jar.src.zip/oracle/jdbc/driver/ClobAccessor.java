/*     */ package oracle.jdbc.driver;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.Reader;
/*     */ import java.io.StringWriter;
/*     */ import java.sql.SQLException;
/*     */ import java.util.Map;
/*     */ import oracle.jdbc.OracleConnection;
/*     */ import oracle.sql.CLOB;
/*     */ import oracle.sql.CharacterSet;
/*     */ import oracle.sql.Datum;
/*     */ import oracle.sql.NCLOB;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class ClobAccessor
/*     */   extends LobCommonAccessor
/*     */ {
/*     */   static final int MAXLENGTH = 4000;
/*     */   int[] prefetchedDataCharset;
/*     */   int[] prefetchedDataFormOfUse;
/*     */   private CharacterSet cachedCharSet;
/*     */   
/*     */   ClobAccessor(OracleStatement paramOracleStatement, int paramInt1, short paramShort, int paramInt2, boolean paramBoolean) throws SQLException {
/*  33 */     super((paramShort == 2) ? Representation.NCLOB : Representation.CLOB, paramOracleStatement, 4000, paramBoolean);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 324 */     this.cachedCharSet = null; init(paramOracleStatement, 112, 112, paramShort, paramBoolean); initForDataAccess(paramInt2, paramInt1, null); } ClobAccessor(OracleStatement paramOracleStatement, int paramInt1, boolean paramBoolean, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, short paramShort) throws SQLException { super((paramShort == 2) ? Representation.NCLOB : Representation.CLOB, paramOracleStatement, 4000, false); this.cachedCharSet = null; init(paramOracleStatement, 112, 112, paramShort, false); initForDescribe(112, paramInt1, paramBoolean, paramInt2, paramInt3, paramInt4, paramInt5, paramInt6, paramShort, null); initForDataAccess(0, paramInt1, null); }
/*     */   void setCapacity(int paramInt) { super.setCapacity(paramInt); if (this.prefetchedDataCharset == null) { this.prefetchedDataCharset = new int[paramInt]; this.prefetchedDataFormOfUse = new int[paramInt]; } else if (paramInt > this.prefetchedDataCharset.length) { int[] arrayOfInt = new int[paramInt]; System.arraycopy(this.prefetchedDataCharset, 0, arrayOfInt, 0, this.prefetchedDataCharset.length); this.prefetchedDataCharset = arrayOfInt; arrayOfInt = new int[paramInt]; System.arraycopy(this.prefetchedDataFormOfUse, 0, arrayOfInt, 0, this.prefetchedDataFormOfUse.length); this.prefetchedDataFormOfUse = arrayOfInt; }  }
/*     */   Accessor copyForDefine(OracleStatement paramOracleStatement) { ClobAccessor clobAccessor = (ClobAccessor)super.copyForDefine(paramOracleStatement); clobAccessor.prefetchedDataCharset = null; clobAccessor.prefetchedDataFormOfUse = null; return clobAccessor; }
/*     */   protected void copyFromInternal(Accessor paramAccessor, int paramInt1, int paramInt2) throws SQLException { super.copyFromInternal(paramAccessor, paramInt1, paramInt2); if (isPrefetched()) { ClobAccessor clobAccessor = (ClobAccessor)paramAccessor; setPrefetchedDataCharset(paramInt2, clobAccessor.getPrefetchedDataCharset(paramInt1)); setPrefetchedDataFormOfUse(paramInt2, clobAccessor.getPrefetchedDataFormOfUse(paramInt1)); }  }
/* 328 */   void deleteRow(int paramInt) throws SQLException { super.deleteRow(paramInt); if (isPrefetched()) { delete(this.prefetchedDataCharset, paramInt); delete(this.prefetchedDataFormOfUse, paramInt); }  } final char[] getPrefetchedCharData(int paramInt, int[] paramArrayOfint) throws SQLException { if (getPrefetchLength() == -1) return null; 
/* 329 */     if (getPrefetchedDataCharset(paramInt) == 0) {
/* 330 */       return ((DynamicByteArray)this.rowData).getChars(getPrefetchedDataOffset(paramInt), getPrefetchedDataLength(paramInt), this.statement.connection.conversion.getCharacterSet((short)getPrefetchedDataFormOfUse(paramInt)), paramArrayOfint);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 337 */     if (this.cachedCharSet == null || this.cachedCharSet.getOracleId() != getPrefetchedDataCharset(paramInt))
/*     */     {
/* 339 */       this.cachedCharSet = CharacterSet.make(getPrefetchedDataCharset(paramInt));
/*     */     }
/* 341 */     return ((DynamicByteArray)this.rowData).getChars(getPrefetchedDataOffset(paramInt), getPrefetchedDataLength(paramInt), this.cachedCharSet, paramArrayOfint); }
/*     */    final int getPrefetchedDataCharset(int paramInt) {
/*     */     return this.prefetchedDataCharset[paramInt];
/*     */   } final void setPrefetchedDataCharset(int paramInt1, int paramInt2) {
/*     */     this.prefetchedDataCharset[paramInt1] = paramInt2;
/*     */   } final int getPrefetchedDataFormOfUse(int paramInt) {
/*     */     return this.prefetchedDataFormOfUse[paramInt];
/*     */   } final void setPrefetchedDataFormOfUse(int paramInt1, int paramInt2) {
/*     */     this.prefetchedDataFormOfUse[paramInt1] = paramInt2;
/*     */   } Object getObject(int paramInt) throws SQLException {
/*     */     return getCLOB(paramInt);
/*     */   } Object getObject(int paramInt, Map paramMap) throws SQLException {
/*     */     return getCLOB(paramInt);
/*     */   } Datum getOracleObject(int paramInt) throws SQLException {
/*     */     return (Datum)getCLOB(paramInt);
/*     */   }
/*     */   protected void normalizeFormOfUse(byte[] paramArrayOfbyte) {
/*     */     short s = CLOB.getFormOfUseFromLocator(paramArrayOfbyte);
/*     */     if (s != -1)
/*     */       this.formOfUse = s; 
/*     */   }
/*     */   InputStream getAsciiStream(int paramInt) throws SQLException {
/* 363 */     CLOB cLOB = getCLOB(paramInt);
/*     */     
/* 365 */     if (cLOB == null) {
/* 366 */       return null;
/*     */     }
/* 368 */     return cLOB.getAsciiStream();
/*     */   } private CLOB getCLOB_(int paramInt, byte[] paramArrayOfbyte) throws SQLException { NCLOB nCLOB; if (this.formOfUse == 1) { CLOB cLOB = new CLOB((OracleConnection)this.statement.connection, paramArrayOfbyte, this.formOfUse); } else { nCLOB = new NCLOB((OracleConnection)this.statement.connection, paramArrayOfbyte); }
/*     */      if (isPrefetched()) { nCLOB.setActivePrefetch(true); nCLOB.setLength(getPrefetchedLength(paramInt)); nCLOB.setChunkSize(getPrefetchedChunkSize(paramInt)); int[] arrayOfInt = new int[1]; nCLOB.setPrefetchedData(getPrefetchedCharData(paramInt, arrayOfInt), arrayOfInt[0]); }
/*     */      return (CLOB)nCLOB; } CLOB getCLOB(int paramInt) throws SQLException { if (isNull(paramInt))
/*     */       return null;  byte[] arrayOfByte = getBytesInternal(paramInt); normalizeFormOfUse(arrayOfByte); return getCLOB_(paramInt, arrayOfByte); }
/*     */   NCLOB getNCLOB(int paramInt) throws SQLException { if (isNull(paramInt))
/*     */       return null;  byte[] arrayOfByte = getBytesInternal(paramInt); normalizeFormOfUse(arrayOfByte); if (this.formOfUse != 2) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 132); sQLException.fillInStackTrace(); throw sQLException; }
/*     */      return (NCLOB)getCLOB_(paramInt, arrayOfByte); }
/*     */   final char[] XgetPrefetchedCharData(int paramInt, int[] paramArrayOfint) throws SQLException { if (getPrefetchLength() == -1)
/*     */       return null;  int i = -1; int j = getPrefetchedDataLength(paramInt); char[] arrayOfChar = new char[getPrefetchedDataLength(paramInt)]; byte[] arrayOfByte = this.rowData.get(getPrefetchedDataOffset(paramInt), getPrefetchedDataLength(paramInt)); if (getPrefetchedDataCharset(paramInt) != 0) { if (getPrefetchedDataCharset(paramInt) == 2000) { i = CharacterSet.convertAL16UTF16BytesToJavaChars(arrayOfByte, 0, arrayOfChar, 0, j, true); }
/*     */       else { i = CharacterSet.convertAL16UTF16LEBytesToJavaChars(arrayOfByte, 0, arrayOfChar, 0, j, true); }
/*     */        }
/*     */     else { int[] arrayOfInt = { j }; if (this.formOfUse == 1) { i = this.statement.connection.conversion.CHARBytesToJavaChars(arrayOfByte, 0, arrayOfChar, 0, arrayOfInt, arrayOfChar.length); }
/*     */       else { i = this.statement.connection.conversion.NCHARBytesToJavaChars(arrayOfByte, 0, arrayOfChar, 0, arrayOfInt, arrayOfChar.length); }
/*     */        }
/*     */      paramArrayOfint[0] = i; return arrayOfChar; }
/* 384 */   Reader getCharacterStream(int paramInt) throws SQLException { CLOB cLOB = getCLOB(paramInt);
/*     */     
/* 386 */     if (cLOB == null) {
/* 387 */       return null;
/*     */     }
/* 389 */     return cLOB.getCharacterStream(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   InputStream getBinaryStream(int paramInt) throws SQLException {
/* 405 */     CLOB cLOB = getCLOB(paramInt);
/*     */     
/* 407 */     if (cLOB == null) {
/* 408 */       return null;
/*     */     }
/* 410 */     return cLOB.getAsciiStream();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   String getString(int paramInt) throws SQLException {
/* 427 */     if (isNull(paramInt)) return null; 
/* 428 */     if (isPrefetched() && getPrefetchedLength(paramInt) > 2147483647L) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 434 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 151);
/* 435 */       sQLException.fillInStackTrace();
/* 436 */       throw sQLException;
/*     */     } 
/*     */     
/* 439 */     if (isPrefetched() && getPrefetchedLength(paramInt) == getPrefetchedDataLength(paramInt))
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 445 */       return this.rowData.getString(getPrefetchedDataOffset(paramInt), getPrefetchedDataLength(paramInt), this.statement.connection.conversion.getCharacterSet((short)getPrefetchedDataFormOfUse(paramInt)));
/*     */     }
/*     */ 
/*     */     
/* 449 */     if (isPrefetched()) {
/*     */ 
/*     */       
/* 452 */       CLOB cLOB = getCLOB(paramInt);
/* 453 */       if (cLOB == null) return null; 
/* 454 */       return cLOB.getSubString(1L, (int)getPrefetchedLength(paramInt));
/*     */     } 
/* 456 */     return getStringNoPrefetch(paramInt);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   String getStringNoPrefetch(int paramInt) throws SQLException {
/* 464 */     CLOB cLOB = getCLOB(paramInt);
/*     */     
/* 466 */     if (cLOB == null) {
/* 467 */       return null;
/*     */     }
/* 469 */     Reader reader = cLOB.getCharacterStream();
/* 470 */     int i = cLOB.getBufferSize();
/* 471 */     int j = 0;
/* 472 */     StringWriter stringWriter = new StringWriter(i);
/* 473 */     char[] arrayOfChar = new char[i];
/*     */ 
/*     */     
/*     */     try {
/* 477 */       while ((j = reader.read(arrayOfChar)) != -1)
/*     */       {
/* 479 */         stringWriter.write(arrayOfChar, 0, j);
/*     */       }
/*     */     }
/* 482 */     catch (IOException iOException) {
/*     */ 
/*     */       
/* 485 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException);
/* 486 */       sQLException.fillInStackTrace();
/* 487 */       throw sQLException;
/*     */     
/*     */     }
/* 490 */     catch (IndexOutOfBoundsException indexOutOfBoundsException) {
/*     */ 
/*     */       
/* 493 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 151);
/* 494 */       sQLException.fillInStackTrace();
/* 495 */       throw sQLException;
/*     */     } 
/*     */ 
/*     */     
/* 499 */     if (cLOB.isTemporary()) this.statement.addToTempLobsToFree(cLOB); 
/* 500 */     return stringWriter.getBuffer().substring(0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   byte[] getBytes(int paramInt) throws SQLException {
/* 518 */     SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException();
/* 519 */     sQLException.fillInStackTrace();
/* 520 */     throw sQLException;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   long updateChecksum(long paramLong, int paramInt) throws SQLException {
/* 528 */     unimpl("updateChecksum");
/* 529 */     return -1L;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/* 534 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*     */   public static final String BUILD_DATE = "Thu_Apr_04_15:09:24_PDT_2013";
/*     */   public static final boolean TRACE = false;
/*     */ }


/* Location:              C:\Users\olatu\OneDrive\Documents\Calypso\syncbase\sync_base.jar!\BOOT-INF\classes\ojdbc.jar!\oracle\jdbc\driver\ClobAccessor.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */