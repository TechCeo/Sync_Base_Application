/*    */ package oracle.jdbc.driver;
/*    */ 
/*    */ import java.sql.SQLException;
/*    */ import oracle.jdbc.internal.OracleStatement;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class CharAccessor
/*    */   extends CharCommonAccessor
/*    */ {
/*    */   static final int MAXLENGTH = 2000;
/*    */   
/*    */   CharAccessor(OracleStatement paramOracleStatement, int paramInt1, short paramShort, int paramInt2, boolean paramBoolean) throws SQLException {
/* 21 */     super(paramOracleStatement, (paramOracleStatement.sqlKind == OracleStatement.SqlKind.PLSQL_BLOCK) ? paramOracleStatement.connection.maxVcsBytesPlsql : 2000, paramShort, paramBoolean);
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 29 */     init(paramOracleStatement, 96, 9, paramInt1, paramShort, paramInt2, paramBoolean, (paramInt1 > this.representationMaxLength) ? paramInt1 : this.representationMaxLength);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   CharAccessor(OracleStatement paramOracleStatement, int paramInt1, boolean paramBoolean, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, short paramShort) throws SQLException {
/* 42 */     super(paramOracleStatement, (paramOracleStatement.sqlKind == OracleStatement.SqlKind.PLSQL_BLOCK) ? paramOracleStatement.connection.maxVcsBytesPlsql : 2000, paramShort, false);
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 49 */     init(paramOracleStatement, 96, 9, paramInt1, paramBoolean, paramInt2, paramInt3, paramInt4, paramInt5, paramInt6, paramShort, (paramInt1 > this.representationMaxLength) ? paramInt1 : this.representationMaxLength);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   CharAccessor(OracleStatement paramOracleStatement, int paramInt1, boolean paramBoolean, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, short paramShort, int paramInt7) throws SQLException {
/* 65 */     this(paramOracleStatement, paramInt1, paramBoolean, paramInt2, paramInt3, paramInt4, paramInt5, paramInt6, paramShort);
/*    */     
/* 67 */     this.describeMaxLengthChars = paramInt7;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/* 72 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*    */   public static final String BUILD_DATE = "Thu_Apr_04_15:09:24_PDT_2013";
/*    */   public static final boolean TRACE = false;
/*    */ }


/* Location:              C:\Users\olatu\OneDrive\Documents\Calypso\syncbase\sync_base.jar!\BOOT-INF\classes\ojdbc.jar!\oracle\jdbc\driver\CharAccessor.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */