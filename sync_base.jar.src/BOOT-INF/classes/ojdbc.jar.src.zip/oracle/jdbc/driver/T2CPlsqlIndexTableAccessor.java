/*     */ package oracle.jdbc.driver;
/*     */ 
/*     */ import java.math.BigDecimal;
/*     */ import java.sql.SQLException;
/*     */ import oracle.sql.CHAR;
/*     */ import oracle.sql.CharacterSet;
/*     */ import oracle.sql.Datum;
/*     */ import oracle.sql.NUMBER;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class T2CPlsqlIndexTableAccessor
/*     */   extends PlsqlIndexTableAccessor
/*     */ {
/*     */   int ibtMetaIndex;
/*     */   
/*     */   T2CPlsqlIndexTableAccessor(OracleStatement paramOracleStatement, PlsqlIbtBindInfo paramPlsqlIbtBindInfo, short paramShort) throws SQLException {
/*  46 */     super(paramOracleStatement, paramPlsqlIbtBindInfo, paramShort);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void initForDataAccess(int paramInt1, int paramInt2, String paramString) throws SQLException {
/*  55 */     unimpl("initForDataAccess");
/*     */   }
/*     */   
/*     */   Object[] getPlsqlIndexTable(int paramInt) throws SQLException {
/*     */     String[] arrayOfString;
/*     */     BigDecimal[] arrayOfBigDecimal;
/*     */     int[] arrayOfInt;
/*     */     byte b;
/*     */     int k;
/*  64 */     short[] arrayOfShort = this.statement.ibtBindIndicators;
/*  65 */     int i = ((arrayOfShort[this.ibtMetaIndex + 4] & 0xFFFF) << 16) + (arrayOfShort[this.ibtMetaIndex + 5] & 0xFFFF);
/*     */ 
/*     */     
/*  68 */     long l = getOffset(paramInt);
/*  69 */     int j = this.ibtBindInfo.elemMaxLen;
/*     */ 
/*     */     
/*  72 */     switch (this.ibtBindInfo.element_internal_type) {
/*     */ 
/*     */       
/*     */       case 9:
/*  76 */         arrayOfInt = new int[1];
/*  77 */         arrayOfString = new String[i];
/*  78 */         for (k = 0; k < i; k++) {
/*  79 */           this.rowData.setPosition(l);
/*  80 */           char[] arrayOfChar = this.rowData.getChars(l, 1, this.statement.connection.conversion.getCharacterSet((short)1), arrayOfInt);
/*     */ 
/*     */ 
/*     */           
/*  84 */           int m = arrayOfChar[0] / 2;
/*  85 */           this.rowData.setPosition(l + 1L);
/*  86 */           if (m == 0) { arrayOfString[k] = null; }
/*  87 */           else { arrayOfString[k] = this.rowData.getString(m, this.statement.connection.conversion.getCharacterSet((short)1)); }
/*     */           
/*  89 */           l += j;
/*     */         } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 111 */         return (Object[])arrayOfString;case 6: arrayOfBigDecimal = new BigDecimal[i]; for (b = 0; b < i; b++) { this.rowData.setPosition(l); k = this.rowData.get() & 0xFF; if (k == 0) { arrayOfBigDecimal[b] = null; } else { arrayOfBigDecimal[b] = NUMBER.toBigDecimal(this.rowData.getBytes(k)); }  l += j; }  return (Object[])arrayOfBigDecimal;
/*     */     } 
/*     */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 97);
/*     */     sQLException.fillInStackTrace();
/*     */     throw sQLException;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Datum[] getOraclePlsqlIndexTable(int paramInt) throws SQLException {
/*     */     NUMBER[] arrayOfNUMBER;
/*     */     int[] arrayOfInt;
/*     */     byte b1;
/*     */     CharacterSet characterSet;
/*     */     byte b2;
/* 129 */     short[] arrayOfShort = this.statement.ibtBindIndicators;
/* 130 */     int i = ((arrayOfShort[this.ibtMetaIndex + 4] & 0xFFFF) << 16) + (arrayOfShort[this.ibtMetaIndex + 5] & 0xFFFF);
/*     */ 
/*     */     
/* 133 */     long l = getOffset(paramInt);
/* 134 */     int j = this.ibtBindInfo.elemMaxLen;
/*     */     
/* 136 */     CHAR[] arrayOfCHAR = null;
/* 137 */     switch (this.ibtBindInfo.element_internal_type) {
/*     */ 
/*     */       
/*     */       case 9:
/* 141 */         arrayOfInt = new int[1];
/* 142 */         arrayOfCHAR = new CHAR[i];
/* 143 */         characterSet = this.statement.connection.conversion.getDriverCharSetObj();
/* 144 */         for (b2 = 0; b2 < i; b2++) {
/* 145 */           this.rowData.setPosition(l);
/* 146 */           char[] arrayOfChar = this.rowData.getChars(l, 1, this.statement.connection.conversion.getCharacterSet((short)1), arrayOfInt);
/*     */ 
/*     */ 
/*     */           
/* 150 */           int k = arrayOfChar[0] / 2;
/* 151 */           this.rowData.setPosition(l + 1L);
/* 152 */           if (k == 0) { arrayOfCHAR[b2] = null; }
/*     */           else
/*     */           
/* 155 */           { String str = this.rowData.getString(k, this.statement.connection.conversion.getCharacterSet((short)1));
/*     */             
/* 157 */             arrayOfCHAR[b2] = new CHAR(str, characterSet); }
/*     */           
/* 159 */           l += j;
/*     */         } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 181 */         return (Datum[])arrayOfCHAR;case 6: arrayOfNUMBER = new NUMBER[i]; for (b1 = 0; b1 < i; b1++) { this.rowData.setPosition(l); int k = this.rowData.get() & 0xFF; if (k == 0) { arrayOfNUMBER[b1] = null; } else { arrayOfNUMBER[b1] = new NUMBER(this.rowData.getBytes(k)); }  l += j; }  return (Datum[])arrayOfNUMBER;
/*     */     } 
/*     */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 97);
/*     */     sQLException.fillInStackTrace();
/*     */     throw sQLException;
/*     */   }
/* 187 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*     */   public static final String BUILD_DATE = "Thu_Apr_04_15:09:24_PDT_2013";
/*     */   public static final boolean TRACE = false;
/*     */ }


/* Location:              C:\Users\olatu\OneDrive\Documents\Calypso\syncbase\sync_base.jar!\BOOT-INF\classes\ojdbc.jar!\oracle\jdbc\driver\T2CPlsqlIndexTableAccessor.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */