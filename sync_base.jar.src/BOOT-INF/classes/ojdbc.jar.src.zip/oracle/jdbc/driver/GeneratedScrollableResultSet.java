/*      */ package oracle.jdbc.driver;
/*      */ 
/*      */ import java.io.InputStream;
/*      */ import java.io.Reader;
/*      */ import java.math.BigDecimal;
/*      */ import java.net.URL;
/*      */ import java.sql.Array;
/*      */ import java.sql.Blob;
/*      */ import java.sql.Clob;
/*      */ import java.sql.Date;
/*      */ import java.sql.NClob;
/*      */ import java.sql.Ref;
/*      */ import java.sql.ResultSet;
/*      */ import java.sql.RowId;
/*      */ import java.sql.SQLException;
/*      */ import java.sql.SQLXML;
/*      */ import java.sql.Time;
/*      */ import java.sql.Timestamp;
/*      */ import java.util.Calendar;
/*      */ import java.util.Map;
/*      */ import oracle.jdbc.OracleDataFactory;
/*      */ import oracle.jdbc.internal.OracleConnection;
/*      */ import oracle.sql.ARRAY;
/*      */ import oracle.sql.BFILE;
/*      */ import oracle.sql.BLOB;
/*      */ import oracle.sql.CHAR;
/*      */ import oracle.sql.CLOB;
/*      */ import oracle.sql.CustomDatum;
/*      */ import oracle.sql.CustomDatumFactory;
/*      */ import oracle.sql.DATE;
/*      */ import oracle.sql.Datum;
/*      */ import oracle.sql.INTERVALDS;
/*      */ import oracle.sql.INTERVALYM;
/*      */ import oracle.sql.NUMBER;
/*      */ import oracle.sql.OPAQUE;
/*      */ import oracle.sql.ORAData;
/*      */ import oracle.sql.ORADataFactory;
/*      */ import oracle.sql.RAW;
/*      */ import oracle.sql.REF;
/*      */ import oracle.sql.ROWID;
/*      */ import oracle.sql.STRUCT;
/*      */ import oracle.sql.TIMESTAMP;
/*      */ import oracle.sql.TIMESTAMPLTZ;
/*      */ import oracle.sql.TIMESTAMPTZ;
/*      */ 
/*      */ abstract class GeneratedScrollableResultSet
/*      */   extends OracleResultSet
/*      */ {
/*      */   protected OracleStatement statement;
/*      */   protected int currentRow;
/*      */   protected int fetchedRowCount;
/*      */   
/*      */   GeneratedScrollableResultSet(PhysicalConnection paramPhysicalConnection, OracleStatement paramOracleStatement) throws SQLException {
/*   54 */     super(paramPhysicalConnection);
/*      */     
/*   56 */     this.statement = paramOracleStatement;
/*   57 */     this.currentRow = -1;
/*   58 */     this.fetchedRowCount = 0;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Array getArray(int paramInt) throws SQLException {
/*   79 */     return (Array)getARRAY(paramInt);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public BigDecimal getBigDecimal(int paramInt) throws SQLException {
/*   85 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*   93 */       if (this.closed) {
/*   94 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 10, "getBigDecimal");
/*   95 */         sQLException.fillInStackTrace();
/*   96 */         throw sQLException;
/*      */       } 
/*   98 */       if (this.statement.closed) {
/*   99 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9, "getBigDecimal");
/*  100 */         sQLException.fillInStackTrace();
/*  101 */         throw sQLException;
/*      */       } 
/*  103 */       if (paramInt < 1 || paramInt > this.statement.getNumberOfColumns()) {
/*      */         
/*  105 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/*  106 */         sQLException.fillInStackTrace();
/*  107 */         throw sQLException;
/*      */       } 
/*      */       
/*  110 */       if (this.currentRow < 0) {
/*  111 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 14);
/*  112 */         sQLException.fillInStackTrace();
/*  113 */         throw sQLException;
/*      */       } 
/*  115 */       if (this.currentRow == this.fetchedRowCount) {
/*  116 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 289);
/*  117 */         sQLException.fillInStackTrace();
/*  118 */         throw sQLException;
/*      */       } 
/*  120 */       return this.statement.getBigDecimal(this.currentRow, paramInt);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public BigDecimal getBigDecimal(int paramInt1, int paramInt2) throws SQLException {
/*  127 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  135 */       if (this.closed) {
/*  136 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 10, "getBigDecimal");
/*  137 */         sQLException.fillInStackTrace();
/*  138 */         throw sQLException;
/*      */       } 
/*  140 */       if (this.statement.closed) {
/*  141 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9, "getBigDecimal");
/*  142 */         sQLException.fillInStackTrace();
/*  143 */         throw sQLException;
/*      */       } 
/*  145 */       if (paramInt1 < 1 || paramInt1 > this.statement.getNumberOfColumns()) {
/*      */         
/*  147 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/*  148 */         sQLException.fillInStackTrace();
/*  149 */         throw sQLException;
/*      */       } 
/*      */       
/*  152 */       if (this.currentRow < 0) {
/*  153 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 14);
/*  154 */         sQLException.fillInStackTrace();
/*  155 */         throw sQLException;
/*      */       } 
/*  157 */       if (this.currentRow == this.fetchedRowCount) {
/*  158 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 289);
/*  159 */         sQLException.fillInStackTrace();
/*  160 */         throw sQLException;
/*      */       } 
/*  162 */       return this.statement.getBigDecimal(this.currentRow, paramInt1, paramInt2);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Blob getBlob(int paramInt) throws SQLException {
/*  175 */     return (Blob)getBLOB(paramInt);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean getBoolean(int paramInt) throws SQLException {
/*  181 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  189 */       if (this.closed) {
/*  190 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 10, "getBoolean");
/*  191 */         sQLException.fillInStackTrace();
/*  192 */         throw sQLException;
/*      */       } 
/*  194 */       if (this.statement.closed) {
/*  195 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9, "getBoolean");
/*  196 */         sQLException.fillInStackTrace();
/*  197 */         throw sQLException;
/*      */       } 
/*  199 */       if (paramInt < 1 || paramInt > this.statement.getNumberOfColumns()) {
/*      */         
/*  201 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/*  202 */         sQLException.fillInStackTrace();
/*  203 */         throw sQLException;
/*      */       } 
/*      */       
/*  206 */       if (this.currentRow < 0) {
/*  207 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 14);
/*  208 */         sQLException.fillInStackTrace();
/*  209 */         throw sQLException;
/*      */       } 
/*  211 */       if (this.currentRow == this.fetchedRowCount) {
/*  212 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 289);
/*  213 */         sQLException.fillInStackTrace();
/*  214 */         throw sQLException;
/*      */       } 
/*  216 */       return this.statement.getBoolean(this.currentRow, paramInt);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public byte getByte(int paramInt) throws SQLException {
/*  223 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  231 */       if (this.closed) {
/*  232 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 10, "getByte");
/*  233 */         sQLException.fillInStackTrace();
/*  234 */         throw sQLException;
/*      */       } 
/*  236 */       if (this.statement.closed) {
/*  237 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9, "getByte");
/*  238 */         sQLException.fillInStackTrace();
/*  239 */         throw sQLException;
/*      */       } 
/*  241 */       if (paramInt < 1 || paramInt > this.statement.getNumberOfColumns()) {
/*      */         
/*  243 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/*  244 */         sQLException.fillInStackTrace();
/*  245 */         throw sQLException;
/*      */       } 
/*      */       
/*  248 */       if (this.currentRow < 0) {
/*  249 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 14);
/*  250 */         sQLException.fillInStackTrace();
/*  251 */         throw sQLException;
/*      */       } 
/*  253 */       if (this.currentRow == this.fetchedRowCount) {
/*  254 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 289);
/*  255 */         sQLException.fillInStackTrace();
/*  256 */         throw sQLException;
/*      */       } 
/*  258 */       return this.statement.getByte(this.currentRow, paramInt);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public byte[] getBytes(int paramInt) throws SQLException {
/*  265 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  273 */       if (this.closed) {
/*  274 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 10, "getBytes");
/*  275 */         sQLException.fillInStackTrace();
/*  276 */         throw sQLException;
/*      */       } 
/*  278 */       if (this.statement.closed) {
/*  279 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9, "getBytes");
/*  280 */         sQLException.fillInStackTrace();
/*  281 */         throw sQLException;
/*      */       } 
/*  283 */       if (paramInt < 1 || paramInt > this.statement.getNumberOfColumns()) {
/*      */         
/*  285 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/*  286 */         sQLException.fillInStackTrace();
/*  287 */         throw sQLException;
/*      */       } 
/*      */       
/*  290 */       if (this.currentRow < 0) {
/*  291 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 14);
/*  292 */         sQLException.fillInStackTrace();
/*  293 */         throw sQLException;
/*      */       } 
/*  295 */       if (this.currentRow == this.fetchedRowCount) {
/*  296 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 289);
/*  297 */         sQLException.fillInStackTrace();
/*  298 */         throw sQLException;
/*      */       } 
/*  300 */       return this.statement.getBytes(this.currentRow, paramInt);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Clob getClob(int paramInt) throws SQLException {
/*  313 */     return (Clob)getCLOB(paramInt);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public Date getDate(int paramInt) throws SQLException {
/*  319 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  327 */       if (this.closed) {
/*  328 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 10, "getDate");
/*  329 */         sQLException.fillInStackTrace();
/*  330 */         throw sQLException;
/*      */       } 
/*  332 */       if (this.statement.closed) {
/*  333 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9, "getDate");
/*  334 */         sQLException.fillInStackTrace();
/*  335 */         throw sQLException;
/*      */       } 
/*  337 */       if (paramInt < 1 || paramInt > this.statement.getNumberOfColumns()) {
/*      */         
/*  339 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/*  340 */         sQLException.fillInStackTrace();
/*  341 */         throw sQLException;
/*      */       } 
/*      */       
/*  344 */       if (this.currentRow < 0) {
/*  345 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 14);
/*  346 */         sQLException.fillInStackTrace();
/*  347 */         throw sQLException;
/*      */       } 
/*  349 */       if (this.currentRow == this.fetchedRowCount) {
/*  350 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 289);
/*  351 */         sQLException.fillInStackTrace();
/*  352 */         throw sQLException;
/*      */       } 
/*  354 */       return this.statement.getDate(this.currentRow, paramInt);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public Date getDate(int paramInt, Calendar paramCalendar) throws SQLException {
/*  361 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  369 */       if (this.closed) {
/*  370 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 10, "getDate");
/*  371 */         sQLException.fillInStackTrace();
/*  372 */         throw sQLException;
/*      */       } 
/*  374 */       if (this.statement.closed) {
/*  375 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9, "getDate");
/*  376 */         sQLException.fillInStackTrace();
/*  377 */         throw sQLException;
/*      */       } 
/*  379 */       if (paramInt < 1 || paramInt > this.statement.getNumberOfColumns()) {
/*      */         
/*  381 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/*  382 */         sQLException.fillInStackTrace();
/*  383 */         throw sQLException;
/*      */       } 
/*      */       
/*  386 */       if (this.currentRow < 0) {
/*  387 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 14);
/*  388 */         sQLException.fillInStackTrace();
/*  389 */         throw sQLException;
/*      */       } 
/*  391 */       if (this.currentRow == this.fetchedRowCount) {
/*  392 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 289);
/*  393 */         sQLException.fillInStackTrace();
/*  394 */         throw sQLException;
/*      */       } 
/*  396 */       return this.statement.getDate(this.currentRow, paramInt, paramCalendar);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public double getDouble(int paramInt) throws SQLException {
/*  403 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  411 */       if (this.closed) {
/*  412 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 10, "getDouble");
/*  413 */         sQLException.fillInStackTrace();
/*  414 */         throw sQLException;
/*      */       } 
/*  416 */       if (this.statement.closed) {
/*  417 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9, "getDouble");
/*  418 */         sQLException.fillInStackTrace();
/*  419 */         throw sQLException;
/*      */       } 
/*  421 */       if (paramInt < 1 || paramInt > this.statement.getNumberOfColumns()) {
/*      */         
/*  423 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/*  424 */         sQLException.fillInStackTrace();
/*  425 */         throw sQLException;
/*      */       } 
/*      */       
/*  428 */       if (this.currentRow < 0) {
/*  429 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 14);
/*  430 */         sQLException.fillInStackTrace();
/*  431 */         throw sQLException;
/*      */       } 
/*  433 */       if (this.currentRow == this.fetchedRowCount) {
/*  434 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 289);
/*  435 */         sQLException.fillInStackTrace();
/*  436 */         throw sQLException;
/*      */       } 
/*  438 */       return this.statement.getDouble(this.currentRow, paramInt);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public float getFloat(int paramInt) throws SQLException {
/*  445 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  453 */       if (this.closed) {
/*  454 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 10, "getFloat");
/*  455 */         sQLException.fillInStackTrace();
/*  456 */         throw sQLException;
/*      */       } 
/*  458 */       if (this.statement.closed) {
/*  459 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9, "getFloat");
/*  460 */         sQLException.fillInStackTrace();
/*  461 */         throw sQLException;
/*      */       } 
/*  463 */       if (paramInt < 1 || paramInt > this.statement.getNumberOfColumns()) {
/*      */         
/*  465 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/*  466 */         sQLException.fillInStackTrace();
/*  467 */         throw sQLException;
/*      */       } 
/*      */       
/*  470 */       if (this.currentRow < 0) {
/*  471 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 14);
/*  472 */         sQLException.fillInStackTrace();
/*  473 */         throw sQLException;
/*      */       } 
/*  475 */       if (this.currentRow == this.fetchedRowCount) {
/*  476 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 289);
/*  477 */         sQLException.fillInStackTrace();
/*  478 */         throw sQLException;
/*      */       } 
/*  480 */       return this.statement.getFloat(this.currentRow, paramInt);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public int getInt(int paramInt) throws SQLException {
/*  487 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  495 */       if (this.closed) {
/*  496 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 10, "getInt");
/*  497 */         sQLException.fillInStackTrace();
/*  498 */         throw sQLException;
/*      */       } 
/*  500 */       if (this.statement.closed) {
/*  501 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9, "getInt");
/*  502 */         sQLException.fillInStackTrace();
/*  503 */         throw sQLException;
/*      */       } 
/*  505 */       if (paramInt < 1 || paramInt > this.statement.getNumberOfColumns()) {
/*      */         
/*  507 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/*  508 */         sQLException.fillInStackTrace();
/*  509 */         throw sQLException;
/*      */       } 
/*      */       
/*  512 */       if (this.currentRow < 0) {
/*  513 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 14);
/*  514 */         sQLException.fillInStackTrace();
/*  515 */         throw sQLException;
/*      */       } 
/*  517 */       if (this.currentRow == this.fetchedRowCount) {
/*  518 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 289);
/*  519 */         sQLException.fillInStackTrace();
/*  520 */         throw sQLException;
/*      */       } 
/*  522 */       return this.statement.getInt(this.currentRow, paramInt);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public long getLong(int paramInt) throws SQLException {
/*  529 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  537 */       if (this.closed) {
/*  538 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 10, "getLong");
/*  539 */         sQLException.fillInStackTrace();
/*  540 */         throw sQLException;
/*      */       } 
/*  542 */       if (this.statement.closed) {
/*  543 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9, "getLong");
/*  544 */         sQLException.fillInStackTrace();
/*  545 */         throw sQLException;
/*      */       } 
/*  547 */       if (paramInt < 1 || paramInt > this.statement.getNumberOfColumns()) {
/*      */         
/*  549 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/*  550 */         sQLException.fillInStackTrace();
/*  551 */         throw sQLException;
/*      */       } 
/*      */       
/*  554 */       if (this.currentRow < 0) {
/*  555 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 14);
/*  556 */         sQLException.fillInStackTrace();
/*  557 */         throw sQLException;
/*      */       } 
/*  559 */       if (this.currentRow == this.fetchedRowCount) {
/*  560 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 289);
/*  561 */         sQLException.fillInStackTrace();
/*  562 */         throw sQLException;
/*      */       } 
/*  564 */       return this.statement.getLong(this.currentRow, paramInt);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public NClob getNClob(int paramInt) throws SQLException {
/*  571 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  579 */       if (this.closed) {
/*  580 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 10, "getNClob");
/*  581 */         sQLException.fillInStackTrace();
/*  582 */         throw sQLException;
/*      */       } 
/*  584 */       if (this.statement.closed) {
/*  585 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9, "getNClob");
/*  586 */         sQLException.fillInStackTrace();
/*  587 */         throw sQLException;
/*      */       } 
/*  589 */       if (paramInt < 1 || paramInt > this.statement.getNumberOfColumns()) {
/*      */         
/*  591 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/*  592 */         sQLException.fillInStackTrace();
/*  593 */         throw sQLException;
/*      */       } 
/*      */       
/*  596 */       if (this.currentRow < 0) {
/*  597 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 14);
/*  598 */         sQLException.fillInStackTrace();
/*  599 */         throw sQLException;
/*      */       } 
/*  601 */       if (this.currentRow == this.fetchedRowCount) {
/*  602 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 289);
/*  603 */         sQLException.fillInStackTrace();
/*  604 */         throw sQLException;
/*      */       } 
/*  606 */       return this.statement.getNClob(this.currentRow, paramInt);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public String getNString(int paramInt) throws SQLException {
/*  613 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  621 */       if (this.closed) {
/*  622 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 10, "getNString");
/*  623 */         sQLException.fillInStackTrace();
/*  624 */         throw sQLException;
/*      */       } 
/*  626 */       if (this.statement.closed) {
/*  627 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9, "getNString");
/*  628 */         sQLException.fillInStackTrace();
/*  629 */         throw sQLException;
/*      */       } 
/*  631 */       if (paramInt < 1 || paramInt > this.statement.getNumberOfColumns()) {
/*      */         
/*  633 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/*  634 */         sQLException.fillInStackTrace();
/*  635 */         throw sQLException;
/*      */       } 
/*      */       
/*  638 */       if (this.currentRow < 0) {
/*  639 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 14);
/*  640 */         sQLException.fillInStackTrace();
/*  641 */         throw sQLException;
/*      */       } 
/*  643 */       if (this.currentRow == this.fetchedRowCount) {
/*  644 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 289);
/*  645 */         sQLException.fillInStackTrace();
/*  646 */         throw sQLException;
/*      */       } 
/*  648 */       return this.statement.getNString(this.currentRow, paramInt);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public Object getObject(int paramInt) throws SQLException {
/*  655 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  663 */       if (this.closed) {
/*  664 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 10, "getObject");
/*  665 */         sQLException.fillInStackTrace();
/*  666 */         throw sQLException;
/*      */       } 
/*  668 */       if (this.statement.closed) {
/*  669 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9, "getObject");
/*  670 */         sQLException.fillInStackTrace();
/*  671 */         throw sQLException;
/*      */       } 
/*  673 */       if (paramInt < 1 || paramInt > this.statement.getNumberOfColumns()) {
/*      */         
/*  675 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/*  676 */         sQLException.fillInStackTrace();
/*  677 */         throw sQLException;
/*      */       } 
/*      */       
/*  680 */       if (this.currentRow < 0) {
/*  681 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 14);
/*  682 */         sQLException.fillInStackTrace();
/*  683 */         throw sQLException;
/*      */       } 
/*  685 */       if (this.currentRow == this.fetchedRowCount) {
/*  686 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 289);
/*  687 */         sQLException.fillInStackTrace();
/*  688 */         throw sQLException;
/*      */       } 
/*  690 */       return this.statement.getObject(this.currentRow, paramInt);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public Object getObject(int paramInt, Map paramMap) throws SQLException {
/*  697 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  705 */       if (this.closed) {
/*  706 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 10, "getObject");
/*  707 */         sQLException.fillInStackTrace();
/*  708 */         throw sQLException;
/*      */       } 
/*  710 */       if (this.statement.closed) {
/*  711 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9, "getObject");
/*  712 */         sQLException.fillInStackTrace();
/*  713 */         throw sQLException;
/*      */       } 
/*  715 */       if (paramInt < 1 || paramInt > this.statement.getNumberOfColumns()) {
/*      */         
/*  717 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/*  718 */         sQLException.fillInStackTrace();
/*  719 */         throw sQLException;
/*      */       } 
/*      */       
/*  722 */       if (this.currentRow < 0) {
/*  723 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 14);
/*  724 */         sQLException.fillInStackTrace();
/*  725 */         throw sQLException;
/*      */       } 
/*  727 */       if (this.currentRow == this.fetchedRowCount) {
/*  728 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 289);
/*  729 */         sQLException.fillInStackTrace();
/*  730 */         throw sQLException;
/*      */       } 
/*  732 */       return this.statement.getObject(this.currentRow, paramInt, paramMap);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Ref getRef(int paramInt) throws SQLException {
/*  745 */     return (Ref)getREF(paramInt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public RowId getRowId(int paramInt) throws SQLException {
/*  757 */     return (RowId)getROWID(paramInt);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public short getShort(int paramInt) throws SQLException {
/*  763 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  771 */       if (this.closed) {
/*  772 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 10, "getShort");
/*  773 */         sQLException.fillInStackTrace();
/*  774 */         throw sQLException;
/*      */       } 
/*  776 */       if (this.statement.closed) {
/*  777 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9, "getShort");
/*  778 */         sQLException.fillInStackTrace();
/*  779 */         throw sQLException;
/*      */       } 
/*  781 */       if (paramInt < 1 || paramInt > this.statement.getNumberOfColumns()) {
/*      */         
/*  783 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/*  784 */         sQLException.fillInStackTrace();
/*  785 */         throw sQLException;
/*      */       } 
/*      */       
/*  788 */       if (this.currentRow < 0) {
/*  789 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 14);
/*  790 */         sQLException.fillInStackTrace();
/*  791 */         throw sQLException;
/*      */       } 
/*  793 */       if (this.currentRow == this.fetchedRowCount) {
/*  794 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 289);
/*  795 */         sQLException.fillInStackTrace();
/*  796 */         throw sQLException;
/*      */       } 
/*  798 */       return this.statement.getShort(this.currentRow, paramInt);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public SQLXML getSQLXML(int paramInt) throws SQLException {
/*  805 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  813 */       if (this.closed) {
/*  814 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 10, "getSQLXML");
/*  815 */         sQLException.fillInStackTrace();
/*  816 */         throw sQLException;
/*      */       } 
/*  818 */       if (this.statement.closed) {
/*  819 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9, "getSQLXML");
/*  820 */         sQLException.fillInStackTrace();
/*  821 */         throw sQLException;
/*      */       } 
/*  823 */       if (paramInt < 1 || paramInt > this.statement.getNumberOfColumns()) {
/*      */         
/*  825 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/*  826 */         sQLException.fillInStackTrace();
/*  827 */         throw sQLException;
/*      */       } 
/*      */       
/*  830 */       if (this.currentRow < 0) {
/*  831 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 14);
/*  832 */         sQLException.fillInStackTrace();
/*  833 */         throw sQLException;
/*      */       } 
/*  835 */       if (this.currentRow == this.fetchedRowCount) {
/*  836 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 289);
/*  837 */         sQLException.fillInStackTrace();
/*  838 */         throw sQLException;
/*      */       } 
/*  840 */       return this.statement.getSQLXML(this.currentRow, paramInt);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public String getString(int paramInt) throws SQLException {
/*  847 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  855 */       if (this.closed) {
/*  856 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 10, "getString");
/*  857 */         sQLException.fillInStackTrace();
/*  858 */         throw sQLException;
/*      */       } 
/*  860 */       if (this.statement.closed) {
/*  861 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9, "getString");
/*  862 */         sQLException.fillInStackTrace();
/*  863 */         throw sQLException;
/*      */       } 
/*  865 */       if (paramInt < 1 || paramInt > this.statement.getNumberOfColumns()) {
/*      */         
/*  867 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/*  868 */         sQLException.fillInStackTrace();
/*  869 */         throw sQLException;
/*      */       } 
/*      */       
/*  872 */       if (this.currentRow < 0) {
/*  873 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 14);
/*  874 */         sQLException.fillInStackTrace();
/*  875 */         throw sQLException;
/*      */       } 
/*  877 */       if (this.currentRow == this.fetchedRowCount) {
/*  878 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 289);
/*  879 */         sQLException.fillInStackTrace();
/*  880 */         throw sQLException;
/*      */       } 
/*  882 */       return this.statement.getString(this.currentRow, paramInt);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public Time getTime(int paramInt) throws SQLException {
/*  889 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  897 */       if (this.closed) {
/*  898 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 10, "getTime");
/*  899 */         sQLException.fillInStackTrace();
/*  900 */         throw sQLException;
/*      */       } 
/*  902 */       if (this.statement.closed) {
/*  903 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9, "getTime");
/*  904 */         sQLException.fillInStackTrace();
/*  905 */         throw sQLException;
/*      */       } 
/*  907 */       if (paramInt < 1 || paramInt > this.statement.getNumberOfColumns()) {
/*      */         
/*  909 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/*  910 */         sQLException.fillInStackTrace();
/*  911 */         throw sQLException;
/*      */       } 
/*      */       
/*  914 */       if (this.currentRow < 0) {
/*  915 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 14);
/*  916 */         sQLException.fillInStackTrace();
/*  917 */         throw sQLException;
/*      */       } 
/*  919 */       if (this.currentRow == this.fetchedRowCount) {
/*  920 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 289);
/*  921 */         sQLException.fillInStackTrace();
/*  922 */         throw sQLException;
/*      */       } 
/*  924 */       return this.statement.getTime(this.currentRow, paramInt);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public Time getTime(int paramInt, Calendar paramCalendar) throws SQLException {
/*  931 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  939 */       if (this.closed) {
/*  940 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 10, "getTime");
/*  941 */         sQLException.fillInStackTrace();
/*  942 */         throw sQLException;
/*      */       } 
/*  944 */       if (this.statement.closed) {
/*  945 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9, "getTime");
/*  946 */         sQLException.fillInStackTrace();
/*  947 */         throw sQLException;
/*      */       } 
/*  949 */       if (paramInt < 1 || paramInt > this.statement.getNumberOfColumns()) {
/*      */         
/*  951 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/*  952 */         sQLException.fillInStackTrace();
/*  953 */         throw sQLException;
/*      */       } 
/*      */       
/*  956 */       if (this.currentRow < 0) {
/*  957 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 14);
/*  958 */         sQLException.fillInStackTrace();
/*  959 */         throw sQLException;
/*      */       } 
/*  961 */       if (this.currentRow == this.fetchedRowCount) {
/*  962 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 289);
/*  963 */         sQLException.fillInStackTrace();
/*  964 */         throw sQLException;
/*      */       } 
/*  966 */       return this.statement.getTime(this.currentRow, paramInt, paramCalendar);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public Timestamp getTimestamp(int paramInt) throws SQLException {
/*  973 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  981 */       if (this.closed) {
/*  982 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 10, "getTimestamp");
/*  983 */         sQLException.fillInStackTrace();
/*  984 */         throw sQLException;
/*      */       } 
/*  986 */       if (this.statement.closed) {
/*  987 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9, "getTimestamp");
/*  988 */         sQLException.fillInStackTrace();
/*  989 */         throw sQLException;
/*      */       } 
/*  991 */       if (paramInt < 1 || paramInt > this.statement.getNumberOfColumns()) {
/*      */         
/*  993 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/*  994 */         sQLException.fillInStackTrace();
/*  995 */         throw sQLException;
/*      */       } 
/*      */       
/*  998 */       if (this.currentRow < 0) {
/*  999 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 14);
/* 1000 */         sQLException.fillInStackTrace();
/* 1001 */         throw sQLException;
/*      */       } 
/* 1003 */       if (this.currentRow == this.fetchedRowCount) {
/* 1004 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 289);
/* 1005 */         sQLException.fillInStackTrace();
/* 1006 */         throw sQLException;
/*      */       } 
/* 1008 */       return this.statement.getTimestamp(this.currentRow, paramInt);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public Timestamp getTimestamp(int paramInt, Calendar paramCalendar) throws SQLException {
/* 1015 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1023 */       if (this.closed) {
/* 1024 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 10, "getTimestamp");
/* 1025 */         sQLException.fillInStackTrace();
/* 1026 */         throw sQLException;
/*      */       } 
/* 1028 */       if (this.statement.closed) {
/* 1029 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9, "getTimestamp");
/* 1030 */         sQLException.fillInStackTrace();
/* 1031 */         throw sQLException;
/*      */       } 
/* 1033 */       if (paramInt < 1 || paramInt > this.statement.getNumberOfColumns()) {
/*      */         
/* 1035 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 1036 */         sQLException.fillInStackTrace();
/* 1037 */         throw sQLException;
/*      */       } 
/*      */       
/* 1040 */       if (this.currentRow < 0) {
/* 1041 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 14);
/* 1042 */         sQLException.fillInStackTrace();
/* 1043 */         throw sQLException;
/*      */       } 
/* 1045 */       if (this.currentRow == this.fetchedRowCount) {
/* 1046 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 289);
/* 1047 */         sQLException.fillInStackTrace();
/* 1048 */         throw sQLException;
/*      */       } 
/* 1050 */       return this.statement.getTimestamp(this.currentRow, paramInt, paramCalendar);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public URL getURL(int paramInt) throws SQLException {
/* 1057 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1065 */       if (this.closed) {
/* 1066 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 10, "getURL");
/* 1067 */         sQLException.fillInStackTrace();
/* 1068 */         throw sQLException;
/*      */       } 
/* 1070 */       if (this.statement.closed) {
/* 1071 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9, "getURL");
/* 1072 */         sQLException.fillInStackTrace();
/* 1073 */         throw sQLException;
/*      */       } 
/* 1075 */       if (paramInt < 1 || paramInt > this.statement.getNumberOfColumns()) {
/*      */         
/* 1077 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 1078 */         sQLException.fillInStackTrace();
/* 1079 */         throw sQLException;
/*      */       } 
/*      */       
/* 1082 */       if (this.currentRow < 0) {
/* 1083 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 14);
/* 1084 */         sQLException.fillInStackTrace();
/* 1085 */         throw sQLException;
/*      */       } 
/* 1087 */       if (this.currentRow == this.fetchedRowCount) {
/* 1088 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 289);
/* 1089 */         sQLException.fillInStackTrace();
/* 1090 */         throw sQLException;
/*      */       } 
/* 1092 */       return this.statement.getURL(this.currentRow, paramInt);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public ARRAY getARRAY(int paramInt) throws SQLException {
/* 1099 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1107 */       if (this.closed) {
/* 1108 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 10, "getARRAY");
/* 1109 */         sQLException.fillInStackTrace();
/* 1110 */         throw sQLException;
/*      */       } 
/* 1112 */       if (this.statement.closed) {
/* 1113 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9, "getARRAY");
/* 1114 */         sQLException.fillInStackTrace();
/* 1115 */         throw sQLException;
/*      */       } 
/* 1117 */       if (paramInt < 1 || paramInt > this.statement.getNumberOfColumns()) {
/*      */         
/* 1119 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 1120 */         sQLException.fillInStackTrace();
/* 1121 */         throw sQLException;
/*      */       } 
/*      */       
/* 1124 */       if (this.currentRow < 0) {
/* 1125 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 14);
/* 1126 */         sQLException.fillInStackTrace();
/* 1127 */         throw sQLException;
/*      */       } 
/* 1129 */       if (this.currentRow == this.fetchedRowCount) {
/* 1130 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 289);
/* 1131 */         sQLException.fillInStackTrace();
/* 1132 */         throw sQLException;
/*      */       } 
/* 1134 */       return this.statement.getARRAY(this.currentRow, paramInt);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public BFILE getBFILE(int paramInt) throws SQLException {
/* 1141 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1149 */       if (this.closed) {
/* 1150 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 10, "getBFILE");
/* 1151 */         sQLException.fillInStackTrace();
/* 1152 */         throw sQLException;
/*      */       } 
/* 1154 */       if (this.statement.closed) {
/* 1155 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9, "getBFILE");
/* 1156 */         sQLException.fillInStackTrace();
/* 1157 */         throw sQLException;
/*      */       } 
/* 1159 */       if (paramInt < 1 || paramInt > this.statement.getNumberOfColumns()) {
/*      */         
/* 1161 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 1162 */         sQLException.fillInStackTrace();
/* 1163 */         throw sQLException;
/*      */       } 
/*      */       
/* 1166 */       if (this.currentRow < 0) {
/* 1167 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 14);
/* 1168 */         sQLException.fillInStackTrace();
/* 1169 */         throw sQLException;
/*      */       } 
/* 1171 */       if (this.currentRow == this.fetchedRowCount) {
/* 1172 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 289);
/* 1173 */         sQLException.fillInStackTrace();
/* 1174 */         throw sQLException;
/*      */       } 
/* 1176 */       return this.statement.getBFILE(this.currentRow, paramInt);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public BFILE getBfile(int paramInt) throws SQLException {
/* 1189 */     return getBFILE(paramInt);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public BLOB getBLOB(int paramInt) throws SQLException {
/* 1195 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1203 */       if (this.closed) {
/* 1204 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 10, "getBLOB");
/* 1205 */         sQLException.fillInStackTrace();
/* 1206 */         throw sQLException;
/*      */       } 
/* 1208 */       if (this.statement.closed) {
/* 1209 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9, "getBLOB");
/* 1210 */         sQLException.fillInStackTrace();
/* 1211 */         throw sQLException;
/*      */       } 
/* 1213 */       if (paramInt < 1 || paramInt > this.statement.getNumberOfColumns()) {
/*      */         
/* 1215 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 1216 */         sQLException.fillInStackTrace();
/* 1217 */         throw sQLException;
/*      */       } 
/*      */       
/* 1220 */       if (this.currentRow < 0) {
/* 1221 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 14);
/* 1222 */         sQLException.fillInStackTrace();
/* 1223 */         throw sQLException;
/*      */       } 
/* 1225 */       if (this.currentRow == this.fetchedRowCount) {
/* 1226 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 289);
/* 1227 */         sQLException.fillInStackTrace();
/* 1228 */         throw sQLException;
/*      */       } 
/* 1230 */       return this.statement.getBLOB(this.currentRow, paramInt);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public CHAR getCHAR(int paramInt) throws SQLException {
/* 1237 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1245 */       if (this.closed) {
/* 1246 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 10, "getCHAR");
/* 1247 */         sQLException.fillInStackTrace();
/* 1248 */         throw sQLException;
/*      */       } 
/* 1250 */       if (this.statement.closed) {
/* 1251 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9, "getCHAR");
/* 1252 */         sQLException.fillInStackTrace();
/* 1253 */         throw sQLException;
/*      */       } 
/* 1255 */       if (paramInt < 1 || paramInt > this.statement.getNumberOfColumns()) {
/*      */         
/* 1257 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 1258 */         sQLException.fillInStackTrace();
/* 1259 */         throw sQLException;
/*      */       } 
/*      */       
/* 1262 */       if (this.currentRow < 0) {
/* 1263 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 14);
/* 1264 */         sQLException.fillInStackTrace();
/* 1265 */         throw sQLException;
/*      */       } 
/* 1267 */       if (this.currentRow == this.fetchedRowCount) {
/* 1268 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 289);
/* 1269 */         sQLException.fillInStackTrace();
/* 1270 */         throw sQLException;
/*      */       } 
/* 1272 */       return this.statement.getCHAR(this.currentRow, paramInt);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public CLOB getCLOB(int paramInt) throws SQLException {
/* 1279 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1287 */       if (this.closed) {
/* 1288 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 10, "getCLOB");
/* 1289 */         sQLException.fillInStackTrace();
/* 1290 */         throw sQLException;
/*      */       } 
/* 1292 */       if (this.statement.closed) {
/* 1293 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9, "getCLOB");
/* 1294 */         sQLException.fillInStackTrace();
/* 1295 */         throw sQLException;
/*      */       } 
/* 1297 */       if (paramInt < 1 || paramInt > this.statement.getNumberOfColumns()) {
/*      */         
/* 1299 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 1300 */         sQLException.fillInStackTrace();
/* 1301 */         throw sQLException;
/*      */       } 
/*      */       
/* 1304 */       if (this.currentRow < 0) {
/* 1305 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 14);
/* 1306 */         sQLException.fillInStackTrace();
/* 1307 */         throw sQLException;
/*      */       } 
/* 1309 */       if (this.currentRow == this.fetchedRowCount) {
/* 1310 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 289);
/* 1311 */         sQLException.fillInStackTrace();
/* 1312 */         throw sQLException;
/*      */       } 
/* 1314 */       return this.statement.getCLOB(this.currentRow, paramInt);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public ResultSet getCursor(int paramInt) throws SQLException {
/* 1321 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1329 */       if (this.closed) {
/* 1330 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 10, "getCursor");
/* 1331 */         sQLException.fillInStackTrace();
/* 1332 */         throw sQLException;
/*      */       } 
/* 1334 */       if (this.statement.closed) {
/* 1335 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9, "getCursor");
/* 1336 */         sQLException.fillInStackTrace();
/* 1337 */         throw sQLException;
/*      */       } 
/* 1339 */       if (paramInt < 1 || paramInt > this.statement.getNumberOfColumns()) {
/*      */         
/* 1341 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 1342 */         sQLException.fillInStackTrace();
/* 1343 */         throw sQLException;
/*      */       } 
/*      */       
/* 1346 */       if (this.currentRow < 0) {
/* 1347 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 14);
/* 1348 */         sQLException.fillInStackTrace();
/* 1349 */         throw sQLException;
/*      */       } 
/* 1351 */       if (this.currentRow == this.fetchedRowCount) {
/* 1352 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 289);
/* 1353 */         sQLException.fillInStackTrace();
/* 1354 */         throw sQLException;
/*      */       } 
/* 1356 */       return this.statement.getCursor(this.currentRow, paramInt);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public DATE getDATE(int paramInt) throws SQLException {
/* 1363 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1371 */       if (this.closed) {
/* 1372 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 10, "getDATE");
/* 1373 */         sQLException.fillInStackTrace();
/* 1374 */         throw sQLException;
/*      */       } 
/* 1376 */       if (this.statement.closed) {
/* 1377 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9, "getDATE");
/* 1378 */         sQLException.fillInStackTrace();
/* 1379 */         throw sQLException;
/*      */       } 
/* 1381 */       if (paramInt < 1 || paramInt > this.statement.getNumberOfColumns()) {
/*      */         
/* 1383 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 1384 */         sQLException.fillInStackTrace();
/* 1385 */         throw sQLException;
/*      */       } 
/*      */       
/* 1388 */       if (this.currentRow < 0) {
/* 1389 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 14);
/* 1390 */         sQLException.fillInStackTrace();
/* 1391 */         throw sQLException;
/*      */       } 
/* 1393 */       if (this.currentRow == this.fetchedRowCount) {
/* 1394 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 289);
/* 1395 */         sQLException.fillInStackTrace();
/* 1396 */         throw sQLException;
/*      */       } 
/* 1398 */       return this.statement.getDATE(this.currentRow, paramInt);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public INTERVALDS getINTERVALDS(int paramInt) throws SQLException {
/* 1405 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1413 */       if (this.closed) {
/* 1414 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 10, "getINTERVALDS");
/* 1415 */         sQLException.fillInStackTrace();
/* 1416 */         throw sQLException;
/*      */       } 
/* 1418 */       if (this.statement.closed) {
/* 1419 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9, "getINTERVALDS");
/* 1420 */         sQLException.fillInStackTrace();
/* 1421 */         throw sQLException;
/*      */       } 
/* 1423 */       if (paramInt < 1 || paramInt > this.statement.getNumberOfColumns()) {
/*      */         
/* 1425 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 1426 */         sQLException.fillInStackTrace();
/* 1427 */         throw sQLException;
/*      */       } 
/*      */       
/* 1430 */       if (this.currentRow < 0) {
/* 1431 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 14);
/* 1432 */         sQLException.fillInStackTrace();
/* 1433 */         throw sQLException;
/*      */       } 
/* 1435 */       if (this.currentRow == this.fetchedRowCount) {
/* 1436 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 289);
/* 1437 */         sQLException.fillInStackTrace();
/* 1438 */         throw sQLException;
/*      */       } 
/* 1440 */       return this.statement.getINTERVALDS(this.currentRow, paramInt);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public INTERVALYM getINTERVALYM(int paramInt) throws SQLException {
/* 1447 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1455 */       if (this.closed) {
/* 1456 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 10, "getINTERVALYM");
/* 1457 */         sQLException.fillInStackTrace();
/* 1458 */         throw sQLException;
/*      */       } 
/* 1460 */       if (this.statement.closed) {
/* 1461 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9, "getINTERVALYM");
/* 1462 */         sQLException.fillInStackTrace();
/* 1463 */         throw sQLException;
/*      */       } 
/* 1465 */       if (paramInt < 1 || paramInt > this.statement.getNumberOfColumns()) {
/*      */         
/* 1467 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 1468 */         sQLException.fillInStackTrace();
/* 1469 */         throw sQLException;
/*      */       } 
/*      */       
/* 1472 */       if (this.currentRow < 0) {
/* 1473 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 14);
/* 1474 */         sQLException.fillInStackTrace();
/* 1475 */         throw sQLException;
/*      */       } 
/* 1477 */       if (this.currentRow == this.fetchedRowCount) {
/* 1478 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 289);
/* 1479 */         sQLException.fillInStackTrace();
/* 1480 */         throw sQLException;
/*      */       } 
/* 1482 */       return this.statement.getINTERVALYM(this.currentRow, paramInt);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public NUMBER getNUMBER(int paramInt) throws SQLException {
/* 1489 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1497 */       if (this.closed) {
/* 1498 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 10, "getNUMBER");
/* 1499 */         sQLException.fillInStackTrace();
/* 1500 */         throw sQLException;
/*      */       } 
/* 1502 */       if (this.statement.closed) {
/* 1503 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9, "getNUMBER");
/* 1504 */         sQLException.fillInStackTrace();
/* 1505 */         throw sQLException;
/*      */       } 
/* 1507 */       if (paramInt < 1 || paramInt > this.statement.getNumberOfColumns()) {
/*      */         
/* 1509 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 1510 */         sQLException.fillInStackTrace();
/* 1511 */         throw sQLException;
/*      */       } 
/*      */       
/* 1514 */       if (this.currentRow < 0) {
/* 1515 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 14);
/* 1516 */         sQLException.fillInStackTrace();
/* 1517 */         throw sQLException;
/*      */       } 
/* 1519 */       if (this.currentRow == this.fetchedRowCount) {
/* 1520 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 289);
/* 1521 */         sQLException.fillInStackTrace();
/* 1522 */         throw sQLException;
/*      */       } 
/* 1524 */       return this.statement.getNUMBER(this.currentRow, paramInt);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public OPAQUE getOPAQUE(int paramInt) throws SQLException {
/* 1531 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1539 */       if (this.closed) {
/* 1540 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 10, "getOPAQUE");
/* 1541 */         sQLException.fillInStackTrace();
/* 1542 */         throw sQLException;
/*      */       } 
/* 1544 */       if (this.statement.closed) {
/* 1545 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9, "getOPAQUE");
/* 1546 */         sQLException.fillInStackTrace();
/* 1547 */         throw sQLException;
/*      */       } 
/* 1549 */       if (paramInt < 1 || paramInt > this.statement.getNumberOfColumns()) {
/*      */         
/* 1551 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 1552 */         sQLException.fillInStackTrace();
/* 1553 */         throw sQLException;
/*      */       } 
/*      */       
/* 1556 */       if (this.currentRow < 0) {
/* 1557 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 14);
/* 1558 */         sQLException.fillInStackTrace();
/* 1559 */         throw sQLException;
/*      */       } 
/* 1561 */       if (this.currentRow == this.fetchedRowCount) {
/* 1562 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 289);
/* 1563 */         sQLException.fillInStackTrace();
/* 1564 */         throw sQLException;
/*      */       } 
/* 1566 */       return this.statement.getOPAQUE(this.currentRow, paramInt);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public Datum getOracleObject(int paramInt) throws SQLException {
/* 1573 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1581 */       if (this.closed) {
/* 1582 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 10, "getOracleObject");
/* 1583 */         sQLException.fillInStackTrace();
/* 1584 */         throw sQLException;
/*      */       } 
/* 1586 */       if (this.statement.closed) {
/* 1587 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9, "getOracleObject");
/* 1588 */         sQLException.fillInStackTrace();
/* 1589 */         throw sQLException;
/*      */       } 
/* 1591 */       if (paramInt < 1 || paramInt > this.statement.getNumberOfColumns()) {
/*      */         
/* 1593 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 1594 */         sQLException.fillInStackTrace();
/* 1595 */         throw sQLException;
/*      */       } 
/*      */       
/* 1598 */       if (this.currentRow < 0) {
/* 1599 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 14);
/* 1600 */         sQLException.fillInStackTrace();
/* 1601 */         throw sQLException;
/*      */       } 
/* 1603 */       if (this.currentRow == this.fetchedRowCount) {
/* 1604 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 289);
/* 1605 */         sQLException.fillInStackTrace();
/* 1606 */         throw sQLException;
/*      */       } 
/* 1608 */       return this.statement.getOracleObject(this.currentRow, paramInt);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public ORAData getORAData(int paramInt, ORADataFactory paramORADataFactory) throws SQLException {
/* 1615 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1623 */       if (this.closed) {
/* 1624 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 10, "getORAData");
/* 1625 */         sQLException.fillInStackTrace();
/* 1626 */         throw sQLException;
/*      */       } 
/* 1628 */       if (this.statement.closed) {
/* 1629 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9, "getORAData");
/* 1630 */         sQLException.fillInStackTrace();
/* 1631 */         throw sQLException;
/*      */       } 
/* 1633 */       if (paramInt < 1 || paramInt > this.statement.getNumberOfColumns()) {
/*      */         
/* 1635 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 1636 */         sQLException.fillInStackTrace();
/* 1637 */         throw sQLException;
/*      */       } 
/*      */       
/* 1640 */       if (this.currentRow < 0) {
/* 1641 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 14);
/* 1642 */         sQLException.fillInStackTrace();
/* 1643 */         throw sQLException;
/*      */       } 
/* 1645 */       if (this.currentRow == this.fetchedRowCount) {
/* 1646 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 289);
/* 1647 */         sQLException.fillInStackTrace();
/* 1648 */         throw sQLException;
/*      */       } 
/* 1650 */       return this.statement.getORAData(this.currentRow, paramInt, paramORADataFactory);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public Object getObject(int paramInt, OracleDataFactory paramOracleDataFactory) throws SQLException {
/* 1657 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1665 */       if (this.closed) {
/* 1666 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 10, "getObject");
/* 1667 */         sQLException.fillInStackTrace();
/* 1668 */         throw sQLException;
/*      */       } 
/* 1670 */       if (this.statement.closed) {
/* 1671 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9, "getObject");
/* 1672 */         sQLException.fillInStackTrace();
/* 1673 */         throw sQLException;
/*      */       } 
/* 1675 */       if (paramInt < 1 || paramInt > this.statement.getNumberOfColumns()) {
/*      */         
/* 1677 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 1678 */         sQLException.fillInStackTrace();
/* 1679 */         throw sQLException;
/*      */       } 
/*      */       
/* 1682 */       if (this.currentRow < 0) {
/* 1683 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 14);
/* 1684 */         sQLException.fillInStackTrace();
/* 1685 */         throw sQLException;
/*      */       } 
/* 1687 */       if (this.currentRow == this.fetchedRowCount) {
/* 1688 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 289);
/* 1689 */         sQLException.fillInStackTrace();
/* 1690 */         throw sQLException;
/*      */       } 
/* 1692 */       return this.statement.getObject(this.currentRow, paramInt, paramOracleDataFactory);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public RAW getRAW(int paramInt) throws SQLException {
/* 1699 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1707 */       if (this.closed) {
/* 1708 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 10, "getRAW");
/* 1709 */         sQLException.fillInStackTrace();
/* 1710 */         throw sQLException;
/*      */       } 
/* 1712 */       if (this.statement.closed) {
/* 1713 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9, "getRAW");
/* 1714 */         sQLException.fillInStackTrace();
/* 1715 */         throw sQLException;
/*      */       } 
/* 1717 */       if (paramInt < 1 || paramInt > this.statement.getNumberOfColumns()) {
/*      */         
/* 1719 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 1720 */         sQLException.fillInStackTrace();
/* 1721 */         throw sQLException;
/*      */       } 
/*      */       
/* 1724 */       if (this.currentRow < 0) {
/* 1725 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 14);
/* 1726 */         sQLException.fillInStackTrace();
/* 1727 */         throw sQLException;
/*      */       } 
/* 1729 */       if (this.currentRow == this.fetchedRowCount) {
/* 1730 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 289);
/* 1731 */         sQLException.fillInStackTrace();
/* 1732 */         throw sQLException;
/*      */       } 
/* 1734 */       return this.statement.getRAW(this.currentRow, paramInt);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public REF getREF(int paramInt) throws SQLException {
/* 1741 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1749 */       if (this.closed) {
/* 1750 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 10, "getREF");
/* 1751 */         sQLException.fillInStackTrace();
/* 1752 */         throw sQLException;
/*      */       } 
/* 1754 */       if (this.statement.closed) {
/* 1755 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9, "getREF");
/* 1756 */         sQLException.fillInStackTrace();
/* 1757 */         throw sQLException;
/*      */       } 
/* 1759 */       if (paramInt < 1 || paramInt > this.statement.getNumberOfColumns()) {
/*      */         
/* 1761 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 1762 */         sQLException.fillInStackTrace();
/* 1763 */         throw sQLException;
/*      */       } 
/*      */       
/* 1766 */       if (this.currentRow < 0) {
/* 1767 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 14);
/* 1768 */         sQLException.fillInStackTrace();
/* 1769 */         throw sQLException;
/*      */       } 
/* 1771 */       if (this.currentRow == this.fetchedRowCount) {
/* 1772 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 289);
/* 1773 */         sQLException.fillInStackTrace();
/* 1774 */         throw sQLException;
/*      */       } 
/* 1776 */       return this.statement.getREF(this.currentRow, paramInt);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public ROWID getROWID(int paramInt) throws SQLException {
/* 1783 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1791 */       if (this.closed) {
/* 1792 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 10, "getROWID");
/* 1793 */         sQLException.fillInStackTrace();
/* 1794 */         throw sQLException;
/*      */       } 
/* 1796 */       if (this.statement.closed) {
/* 1797 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9, "getROWID");
/* 1798 */         sQLException.fillInStackTrace();
/* 1799 */         throw sQLException;
/*      */       } 
/* 1801 */       if (paramInt < 1 || paramInt > this.statement.getNumberOfColumns()) {
/*      */         
/* 1803 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 1804 */         sQLException.fillInStackTrace();
/* 1805 */         throw sQLException;
/*      */       } 
/*      */       
/* 1808 */       if (this.currentRow < 0) {
/* 1809 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 14);
/* 1810 */         sQLException.fillInStackTrace();
/* 1811 */         throw sQLException;
/*      */       } 
/* 1813 */       if (this.currentRow == this.fetchedRowCount) {
/* 1814 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 289);
/* 1815 */         sQLException.fillInStackTrace();
/* 1816 */         throw sQLException;
/*      */       } 
/* 1818 */       return this.statement.getROWID(this.currentRow, paramInt);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public STRUCT getSTRUCT(int paramInt) throws SQLException {
/* 1825 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1833 */       if (this.closed) {
/* 1834 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 10, "getSTRUCT");
/* 1835 */         sQLException.fillInStackTrace();
/* 1836 */         throw sQLException;
/*      */       } 
/* 1838 */       if (this.statement.closed) {
/* 1839 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9, "getSTRUCT");
/* 1840 */         sQLException.fillInStackTrace();
/* 1841 */         throw sQLException;
/*      */       } 
/* 1843 */       if (paramInt < 1 || paramInt > this.statement.getNumberOfColumns()) {
/*      */         
/* 1845 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 1846 */         sQLException.fillInStackTrace();
/* 1847 */         throw sQLException;
/*      */       } 
/*      */       
/* 1850 */       if (this.currentRow < 0) {
/* 1851 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 14);
/* 1852 */         sQLException.fillInStackTrace();
/* 1853 */         throw sQLException;
/*      */       } 
/* 1855 */       if (this.currentRow == this.fetchedRowCount) {
/* 1856 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 289);
/* 1857 */         sQLException.fillInStackTrace();
/* 1858 */         throw sQLException;
/*      */       } 
/* 1860 */       return this.statement.getSTRUCT(this.currentRow, paramInt);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public TIMESTAMPLTZ getTIMESTAMPLTZ(int paramInt) throws SQLException {
/* 1867 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1875 */       if (this.closed) {
/* 1876 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 10, "getTIMESTAMPLTZ");
/* 1877 */         sQLException.fillInStackTrace();
/* 1878 */         throw sQLException;
/*      */       } 
/* 1880 */       if (this.statement.closed) {
/* 1881 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9, "getTIMESTAMPLTZ");
/* 1882 */         sQLException.fillInStackTrace();
/* 1883 */         throw sQLException;
/*      */       } 
/* 1885 */       if (paramInt < 1 || paramInt > this.statement.getNumberOfColumns()) {
/*      */         
/* 1887 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 1888 */         sQLException.fillInStackTrace();
/* 1889 */         throw sQLException;
/*      */       } 
/*      */       
/* 1892 */       if (this.currentRow < 0) {
/* 1893 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 14);
/* 1894 */         sQLException.fillInStackTrace();
/* 1895 */         throw sQLException;
/*      */       } 
/* 1897 */       if (this.currentRow == this.fetchedRowCount) {
/* 1898 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 289);
/* 1899 */         sQLException.fillInStackTrace();
/* 1900 */         throw sQLException;
/*      */       } 
/* 1902 */       return this.statement.getTIMESTAMPLTZ(this.currentRow, paramInt);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public TIMESTAMPTZ getTIMESTAMPTZ(int paramInt) throws SQLException {
/* 1909 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1917 */       if (this.closed) {
/* 1918 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 10, "getTIMESTAMPTZ");
/* 1919 */         sQLException.fillInStackTrace();
/* 1920 */         throw sQLException;
/*      */       } 
/* 1922 */       if (this.statement.closed) {
/* 1923 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9, "getTIMESTAMPTZ");
/* 1924 */         sQLException.fillInStackTrace();
/* 1925 */         throw sQLException;
/*      */       } 
/* 1927 */       if (paramInt < 1 || paramInt > this.statement.getNumberOfColumns()) {
/*      */         
/* 1929 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 1930 */         sQLException.fillInStackTrace();
/* 1931 */         throw sQLException;
/*      */       } 
/*      */       
/* 1934 */       if (this.currentRow < 0) {
/* 1935 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 14);
/* 1936 */         sQLException.fillInStackTrace();
/* 1937 */         throw sQLException;
/*      */       } 
/* 1939 */       if (this.currentRow == this.fetchedRowCount) {
/* 1940 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 289);
/* 1941 */         sQLException.fillInStackTrace();
/* 1942 */         throw sQLException;
/*      */       } 
/* 1944 */       return this.statement.getTIMESTAMPTZ(this.currentRow, paramInt);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public TIMESTAMP getTIMESTAMP(int paramInt) throws SQLException {
/* 1951 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1959 */       if (this.closed) {
/* 1960 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 10, "getTIMESTAMP");
/* 1961 */         sQLException.fillInStackTrace();
/* 1962 */         throw sQLException;
/*      */       } 
/* 1964 */       if (this.statement.closed) {
/* 1965 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9, "getTIMESTAMP");
/* 1966 */         sQLException.fillInStackTrace();
/* 1967 */         throw sQLException;
/*      */       } 
/* 1969 */       if (paramInt < 1 || paramInt > this.statement.getNumberOfColumns()) {
/*      */         
/* 1971 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 1972 */         sQLException.fillInStackTrace();
/* 1973 */         throw sQLException;
/*      */       } 
/*      */       
/* 1976 */       if (this.currentRow < 0) {
/* 1977 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 14);
/* 1978 */         sQLException.fillInStackTrace();
/* 1979 */         throw sQLException;
/*      */       } 
/* 1981 */       if (this.currentRow == this.fetchedRowCount) {
/* 1982 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 289);
/* 1983 */         sQLException.fillInStackTrace();
/* 1984 */         throw sQLException;
/*      */       } 
/* 1986 */       return this.statement.getTIMESTAMP(this.currentRow, paramInt);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public CustomDatum getCustomDatum(int paramInt, CustomDatumFactory paramCustomDatumFactory) throws SQLException {
/* 1993 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2001 */       if (this.closed) {
/* 2002 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 10, "getCustomDatum");
/* 2003 */         sQLException.fillInStackTrace();
/* 2004 */         throw sQLException;
/*      */       } 
/* 2006 */       if (this.statement.closed) {
/* 2007 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9, "getCustomDatum");
/* 2008 */         sQLException.fillInStackTrace();
/* 2009 */         throw sQLException;
/*      */       } 
/* 2011 */       if (paramInt < 1 || paramInt > this.statement.getNumberOfColumns()) {
/*      */         
/* 2013 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 2014 */         sQLException.fillInStackTrace();
/* 2015 */         throw sQLException;
/*      */       } 
/*      */       
/* 2018 */       if (this.currentRow < 0) {
/* 2019 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 14);
/* 2020 */         sQLException.fillInStackTrace();
/* 2021 */         throw sQLException;
/*      */       } 
/* 2023 */       if (this.currentRow == this.fetchedRowCount) {
/* 2024 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 289);
/* 2025 */         sQLException.fillInStackTrace();
/* 2026 */         throw sQLException;
/*      */       } 
/* 2028 */       return this.statement.getCustomDatum(this.currentRow, paramInt, paramCustomDatumFactory);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public InputStream getAsciiStream(int paramInt) throws SQLException {
/* 2035 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2043 */       if (this.closed) {
/* 2044 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 10, "getAsciiStream");
/* 2045 */         sQLException.fillInStackTrace();
/* 2046 */         throw sQLException;
/*      */       } 
/* 2048 */       if (this.statement.closed) {
/* 2049 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9, "getAsciiStream");
/* 2050 */         sQLException.fillInStackTrace();
/* 2051 */         throw sQLException;
/*      */       } 
/* 2053 */       if (paramInt < 1 || paramInt > this.statement.getNumberOfColumns()) {
/*      */         
/* 2055 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 2056 */         sQLException.fillInStackTrace();
/* 2057 */         throw sQLException;
/*      */       } 
/*      */       
/* 2060 */       if (this.currentRow < 0) {
/* 2061 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 14);
/* 2062 */         sQLException.fillInStackTrace();
/* 2063 */         throw sQLException;
/*      */       } 
/* 2065 */       if (this.currentRow == this.fetchedRowCount) {
/* 2066 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 289);
/* 2067 */         sQLException.fillInStackTrace();
/* 2068 */         throw sQLException;
/*      */       } 
/* 2070 */       return this.statement.getAsciiStream(this.currentRow, paramInt);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public InputStream getBinaryStream(int paramInt) throws SQLException {
/* 2077 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2085 */       if (this.closed) {
/* 2086 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 10, "getBinaryStream");
/* 2087 */         sQLException.fillInStackTrace();
/* 2088 */         throw sQLException;
/*      */       } 
/* 2090 */       if (this.statement.closed) {
/* 2091 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9, "getBinaryStream");
/* 2092 */         sQLException.fillInStackTrace();
/* 2093 */         throw sQLException;
/*      */       } 
/* 2095 */       if (paramInt < 1 || paramInt > this.statement.getNumberOfColumns()) {
/*      */         
/* 2097 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 2098 */         sQLException.fillInStackTrace();
/* 2099 */         throw sQLException;
/*      */       } 
/*      */       
/* 2102 */       if (this.currentRow < 0) {
/* 2103 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 14);
/* 2104 */         sQLException.fillInStackTrace();
/* 2105 */         throw sQLException;
/*      */       } 
/* 2107 */       if (this.currentRow == this.fetchedRowCount) {
/* 2108 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 289);
/* 2109 */         sQLException.fillInStackTrace();
/* 2110 */         throw sQLException;
/*      */       } 
/* 2112 */       return this.statement.getBinaryStream(this.currentRow, paramInt);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public Reader getCharacterStream(int paramInt) throws SQLException {
/* 2119 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2127 */       if (this.closed) {
/* 2128 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 10, "getCharacterStream");
/* 2129 */         sQLException.fillInStackTrace();
/* 2130 */         throw sQLException;
/*      */       } 
/* 2132 */       if (this.statement.closed) {
/* 2133 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9, "getCharacterStream");
/* 2134 */         sQLException.fillInStackTrace();
/* 2135 */         throw sQLException;
/*      */       } 
/* 2137 */       if (paramInt < 1 || paramInt > this.statement.getNumberOfColumns()) {
/*      */         
/* 2139 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 2140 */         sQLException.fillInStackTrace();
/* 2141 */         throw sQLException;
/*      */       } 
/*      */       
/* 2144 */       if (this.currentRow < 0) {
/* 2145 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 14);
/* 2146 */         sQLException.fillInStackTrace();
/* 2147 */         throw sQLException;
/*      */       } 
/* 2149 */       if (this.currentRow == this.fetchedRowCount) {
/* 2150 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 289);
/* 2151 */         sQLException.fillInStackTrace();
/* 2152 */         throw sQLException;
/*      */       } 
/* 2154 */       return this.statement.getCharacterStream(this.currentRow, paramInt);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public Reader getNCharacterStream(int paramInt) throws SQLException {
/* 2161 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2169 */       if (this.closed) {
/* 2170 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 10, "getNCharacterStream");
/* 2171 */         sQLException.fillInStackTrace();
/* 2172 */         throw sQLException;
/*      */       } 
/* 2174 */       if (this.statement.closed) {
/* 2175 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9, "getNCharacterStream");
/* 2176 */         sQLException.fillInStackTrace();
/* 2177 */         throw sQLException;
/*      */       } 
/* 2179 */       if (paramInt < 1 || paramInt > this.statement.getNumberOfColumns()) {
/*      */         
/* 2181 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 2182 */         sQLException.fillInStackTrace();
/* 2183 */         throw sQLException;
/*      */       } 
/*      */       
/* 2186 */       if (this.currentRow < 0) {
/* 2187 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 14);
/* 2188 */         sQLException.fillInStackTrace();
/* 2189 */         throw sQLException;
/*      */       } 
/* 2191 */       if (this.currentRow == this.fetchedRowCount) {
/* 2192 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 289);
/* 2193 */         sQLException.fillInStackTrace();
/* 2194 */         throw sQLException;
/*      */       } 
/* 2196 */       return this.statement.getNCharacterStream(this.currentRow, paramInt);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public InputStream getUnicodeStream(int paramInt) throws SQLException {
/* 2203 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2211 */       if (this.closed) {
/* 2212 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 10, "getUnicodeStream");
/* 2213 */         sQLException.fillInStackTrace();
/* 2214 */         throw sQLException;
/*      */       } 
/* 2216 */       if (this.statement.closed) {
/* 2217 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9, "getUnicodeStream");
/* 2218 */         sQLException.fillInStackTrace();
/* 2219 */         throw sQLException;
/*      */       } 
/* 2221 */       if (paramInt < 1 || paramInt > this.statement.getNumberOfColumns()) {
/*      */         
/* 2223 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 2224 */         sQLException.fillInStackTrace();
/* 2225 */         throw sQLException;
/*      */       } 
/*      */       
/* 2228 */       if (this.currentRow < 0) {
/* 2229 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 14);
/* 2230 */         sQLException.fillInStackTrace();
/* 2231 */         throw sQLException;
/*      */       } 
/* 2233 */       if (this.currentRow == this.fetchedRowCount) {
/* 2234 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 289);
/* 2235 */         sQLException.fillInStackTrace();
/* 2236 */         throw sQLException;
/*      */       } 
/* 2238 */       return this.statement.getUnicodeStream(this.currentRow, paramInt);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected OracleConnection getConnectionDuringExceptionHandling() {
/* 2255 */     return this.connection;
/*      */   }
/*      */ 
/*      */   
/* 2259 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*      */   public static final String BUILD_DATE = "Thu_Apr_04_15:09:24_PDT_2013";
/*      */   public static final boolean TRACE = false;
/*      */ }


/* Location:              C:\Users\olatu\OneDrive\Documents\Calypso\syncbase\sync_base.jar!\BOOT-INF\classes\ojdbc.jar!\oracle\jdbc\driver\GeneratedScrollableResultSet.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */