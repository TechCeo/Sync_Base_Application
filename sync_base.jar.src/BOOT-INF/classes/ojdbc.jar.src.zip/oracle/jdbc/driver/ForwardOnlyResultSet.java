/*    */ package oracle.jdbc.driver;
/*    */ 
/*    */ import java.sql.SQLException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class ForwardOnlyResultSet
/*    */   extends InsensitiveScrollableResultSet
/*    */ {
/*    */   ForwardOnlyResultSet(PhysicalConnection paramPhysicalConnection, OracleStatement paramOracleStatement) throws SQLException {
/* 25 */     super(paramPhysicalConnection, paramOracleStatement);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   protected boolean isForwardOnly() {
/* 31 */     return true;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public int getType() {
/* 41 */     return 1003;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/* 46 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*    */   public static final String BUILD_DATE = "Thu_Apr_04_15:09:24_PDT_2013";
/*    */   public static final boolean TRACE = false;
/*    */ }


/* Location:              C:\Users\olatu\OneDrive\Documents\Calypso\syncbase\sync_base.jar!\BOOT-INF\classes\ojdbc.jar!\oracle\jdbc\driver\ForwardOnlyResultSet.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */