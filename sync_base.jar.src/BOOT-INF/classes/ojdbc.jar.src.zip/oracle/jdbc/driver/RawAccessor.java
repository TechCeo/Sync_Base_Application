/*    */ package oracle.jdbc.driver;
/*    */ 
/*    */ import java.sql.SQLException;
/*    */ import oracle.jdbc.internal.OracleStatement;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class RawAccessor
/*    */   extends RawCommonAccessor
/*    */ {
/*    */   RawAccessor(OracleStatement paramOracleStatement, int paramInt1, short paramShort, int paramInt2, boolean paramBoolean) throws SQLException {
/* 21 */     super(paramOracleStatement, (paramOracleStatement.sqlKind == OracleStatement.SqlKind.PLSQL_BLOCK) ? Math.max(paramOracleStatement.connection.maxRawBytesPlsql, paramInt1) : paramOracleStatement.connection.maxRawLength, paramBoolean);
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 28 */     init(paramOracleStatement, 23, 15, paramShort, paramBoolean);
/* 29 */     initForDataAccess(paramInt2, paramInt1, (String)null);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   RawAccessor(OracleStatement paramOracleStatement, int paramInt1, boolean paramBoolean, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, short paramShort) throws SQLException {
/* 37 */     super(paramOracleStatement, (paramOracleStatement.sqlKind == OracleStatement.SqlKind.PLSQL_BLOCK) ? paramOracleStatement.connection.maxRawBytesPlsql : paramOracleStatement.connection.maxRawLength, false);
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 42 */     init(paramOracleStatement, 23, 15, paramShort, false);
/* 43 */     initForDescribe(23, paramInt1, paramBoolean, paramInt2, paramInt3, paramInt4, paramInt5, paramInt6, paramShort, null);
/*    */ 
/*    */     
/* 46 */     int i = paramOracleStatement.maxFieldSize;
/*    */     
/* 48 */     if (i > 0 && (paramInt1 == 0 || i < paramInt1)) {
/* 49 */       paramInt1 = i;
/*    */     }
/* 51 */     initForDataAccess(0, paramInt1, (String)null);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   void initForDataAccess(int paramInt1, int paramInt2, String paramString) throws SQLException {
/* 58 */     super.initForDataAccess(paramInt1, paramInt2, paramString);
/*    */     
/* 60 */     this.byteLength += 2;
/*    */   }
/*    */ 
/*    */   
/* 64 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*    */   public static final String BUILD_DATE = "Thu_Apr_04_15:09:24_PDT_2013";
/*    */   public static final boolean TRACE = false;
/*    */ }


/* Location:              C:\Users\olatu\OneDrive\Documents\Calypso\syncbase\sync_base.jar!\BOOT-INF\classes\ojdbc.jar!\oracle\jdbc\driver\RawAccessor.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */