/*     */ package oracle.jdbc.driver;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.sql.SQLException;
/*     */ import oracle.jdbc.OracleResultSetMetaData;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class T4CBinaryFloatAccessor
/*     */   extends BinaryFloatAccessor
/*     */ {
/*     */   T4CMAREngine mare;
/*     */   boolean underlyingLongRaw = false;
/*     */   
/*     */   T4CBinaryFloatAccessor(OracleStatement paramOracleStatement, int paramInt1, short paramShort, int paramInt2, boolean paramBoolean, T4CMAREngine paramT4CMAREngine) throws SQLException {
/*  40 */     super(paramOracleStatement, paramInt1, paramShort, paramInt2, paramBoolean);
/*     */     
/*  42 */     this.mare = paramT4CMAREngine;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   T4CBinaryFloatAccessor(OracleStatement paramOracleStatement, int paramInt1, boolean paramBoolean, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, short paramShort, int paramInt7, int paramInt8, T4CMAREngine paramT4CMAREngine) throws SQLException {
/*  51 */     super(paramOracleStatement, (paramInt1 == -1) ? paramInt8 : paramInt1, paramBoolean, paramInt2, paramInt3, paramInt4, paramInt5, paramInt6, paramShort);
/*     */ 
/*     */     
/*  54 */     this.mare = paramT4CMAREngine;
/*     */ 
/*     */     
/*  57 */     if (paramOracleStatement != null && paramOracleStatement.implicitDefineForLobPrefetchDone) {
/*     */       
/*  59 */       this.definedColumnType = 0;
/*  60 */       this.definedColumnSize = 0;
/*     */     }
/*     */     else {
/*     */       
/*  64 */       this.definedColumnType = paramInt7;
/*  65 */       this.definedColumnSize = paramInt8;
/*     */     } 
/*     */     
/*  68 */     if (paramInt1 == -1)
/*  69 */       this.underlyingLongRaw = true; 
/*     */   }
/*     */   
/*     */   public T4CMAREngine getMAREngine() {
/*  73 */     return this.mare;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void unmarshalColumnMetadata() throws SQLException, IOException {
/*  82 */     if (this.statement.statementType != 2 && !this.statement.sqlKind.isPlsqlOrCall() && this.securityAttribute == OracleResultSetMetaData.SecurityAttribute.ENABLED)
/*     */     {
/*     */       
/*  85 */       setRowMetadata(this.lastRowProcessed, (byte)this.mare.unmarshalUB1());
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void processIndicator(int paramInt) throws IOException, SQLException {
/*  92 */     if ((this.internalType == 1 && this.describeType == 112) || (this.internalType == 23 && this.describeType == 113)) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*  99 */       this.mare.unmarshalUB2();
/* 100 */       this.mare.unmarshalUB2();
/*     */     }
/* 102 */     else if (this.statement.connection.versionNumber < 9200) {
/*     */ 
/*     */ 
/*     */       
/* 106 */       this.mare.unmarshalSB2();
/*     */       
/* 108 */       if (!this.statement.sqlKind.isPlsqlOrCall()) {
/* 109 */         this.mare.unmarshalSB2();
/*     */       }
/* 111 */     } else if (this.statement.sqlKind.isPlsqlOrCall() || this.isDMLReturnedParam) {
/* 112 */       this.mare.processIndicator((paramInt <= 0), paramInt);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   int getPreviousRowProcessed() {
/* 118 */     if (this.previousRowProcessed == -1) this.previousRowProcessed = this.statement.rowPrefetchInLastFetch - 1; 
/* 119 */     return this.previousRowProcessed;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean unmarshalOneRow() throws SQLException, IOException {
/* 134 */     boolean bool = false;
/* 135 */     if (!isUseless())
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 141 */       if (isUnexpected()) {
/*     */ 
/*     */         
/* 144 */         long l = this.rowData.getPosition();
/* 145 */         unmarshalColumnMetadata();
/* 146 */         unmarshalBytes();
/* 147 */         this.rowData.setPosition(l);
/* 148 */         setNull(this.lastRowProcessed, true);
/*     */       }
/* 150 */       else if (isNullByDescribe()) {
/*     */ 
/*     */         
/* 153 */         setNull(this.lastRowProcessed, true);
/* 154 */         unmarshalColumnMetadata();
/* 155 */         if (this.statement.connection.versionNumber < 9200) processIndicator(0);
/*     */       
/*     */       } else {
/*     */         
/* 159 */         unmarshalColumnMetadata();
/* 160 */         bool = unmarshalBytes();
/*     */       }  } 
/* 162 */     this.previousRowProcessed = this.lastRowProcessed;
/* 163 */     this.lastRowProcessed++;
/* 164 */     return bool;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean unmarshalBytes() throws SQLException, IOException {
/*     */     int i;
/* 176 */     setOffset(this.lastRowProcessed);
/* 177 */     if (this.statement.maxFieldSize > 0) {
/* 178 */       i = ((DynamicByteArray)this.rowData).unmarshalCLR(this.mare, this.statement.maxFieldSize);
/*     */     } else {
/* 180 */       i = ((DynamicByteArray)this.rowData).unmarshalCLR(this.mare);
/* 181 */     }  processIndicator(i);
/* 182 */     setLength(this.lastRowProcessed, i);
/* 183 */     setNull(this.lastRowProcessed, (i == 0));
/* 184 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void copyRow() throws SQLException, IOException {
/* 193 */     if (this.isNullByDescribe) {
/* 194 */       setNull(this.lastRowProcessed, true);
/*     */     }
/* 196 */     else if (this.lastRowProcessed == 0) {
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 201 */       if (this.previousRowProcessed == -1)
/* 202 */         this.previousRowProcessed = this.statement.rowPrefetchInLastFetch - 1; 
/* 203 */       long l = getOffset(this.previousRowProcessed);
/* 204 */       setNull(this.lastRowProcessed, isNull(this.previousRowProcessed));
/* 205 */       this.rowMetadata[this.lastRowProcessed] = this.rowMetadata[this.previousRowProcessed];
/* 206 */       if (!isNull(this.previousRowProcessed)) {
/* 207 */         setOffset(this.lastRowProcessed);
/* 208 */         ((DynamicByteArray)this.rowData).copyLeft(l, getLength(this.previousRowProcessed));
/* 209 */         setLength(this.lastRowProcessed, getLength(this.previousRowProcessed));
/*     */       }
/*     */     
/*     */     } else {
/*     */       
/* 214 */       setNull(this.lastRowProcessed, isNull(this.previousRowProcessed));
/* 215 */       this.rowMetadata[this.lastRowProcessed] = this.rowMetadata[this.previousRowProcessed];
/* 216 */       setOffset(this.lastRowProcessed, getOffset(this.previousRowProcessed));
/* 217 */       setLength(this.lastRowProcessed, getLength(this.previousRowProcessed));
/*     */     } 
/* 219 */     this.previousRowProcessed = this.lastRowProcessed;
/* 220 */     this.lastRowProcessed++;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Object getObject(int paramInt) throws SQLException {
/* 228 */     if (this.definedColumnType == 0) {
/* 229 */       return super.getObject(paramInt);
/*     */     }
/*     */     
/* 232 */     if (isNull(paramInt)) return null;
/*     */     
/* 234 */     switch (this.definedColumnType) {
/*     */       case -15:
/*     */       case -9:
/*     */       case -1:
/*     */       case 1:
/*     */       case 12:
/* 240 */         return getString(paramInt);
/*     */       
/*     */       case 4:
/* 243 */         return Integer.valueOf(getInt(paramInt));
/*     */       
/*     */       case -6:
/* 246 */         return Byte.valueOf(getByte(paramInt));
/*     */       
/*     */       case 5:
/* 249 */         return Short.valueOf(getShort(paramInt));
/*     */       
/*     */       case 6:
/*     */       case 8:
/* 253 */         return Double.valueOf(getDouble(paramInt));
/*     */       
/*     */       case 2:
/*     */       case 3:
/* 257 */         return getBigDecimal(paramInt);
/*     */       
/*     */       case 7:
/* 260 */         return Float.valueOf(getFloat(paramInt));
/*     */       
/*     */       case 100:
/* 263 */         return getBINARY_FLOAT(paramInt);
/*     */       
/*     */       case -5:
/* 266 */         return Long.valueOf(getLong(paramInt));
/*     */       
/*     */       case -4:
/*     */       case -3:
/*     */       case -2:
/* 271 */         return getBytes(paramInt);
/*     */     } 
/*     */ 
/*     */     
/* 275 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4);
/* 276 */     sQLException.fillInStackTrace();
/* 277 */     throw sQLException;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 286 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*     */   public static final String BUILD_DATE = "Thu_Apr_04_15:09:24_PDT_2013";
/*     */   public static final boolean TRACE = false;
/*     */ }


/* Location:              C:\Users\olatu\OneDrive\Documents\Calypso\syncbase\sync_base.jar!\BOOT-INF\classes\ojdbc.jar!\oracle\jdbc\driver\T4CBinaryFloatAccessor.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */