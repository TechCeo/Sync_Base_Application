/*    */ package oracle.jdbc.driver;
/*    */ 
/*    */ import java.util.ResourceBundle;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class Message11
/*    */   implements Message
/*    */ {
/*    */   private static ResourceBundle bundle;
/*    */   private static final String messageFile = "oracle.jdbc.driver.Messages";
/*    */   
/*    */   public String msg(String paramString, Object paramObject) {
/* 31 */     if (bundle == null) {
/*    */       
/*    */       try {
/*    */         
/* 35 */         bundle = ResourceBundle.getBundle("oracle.jdbc.driver.Messages");
/*    */       }
/* 37 */       catch (Exception exception) {
/*    */ 
/*    */         
/* 40 */         return "Message file 'oracle.jdbc.driver.Messages' is missing.";
/*    */       } 
/*    */     }
/*    */ 
/*    */ 
/*    */     
/*    */     try {
/* 47 */       if (paramObject != null) {
/* 48 */         return bundle.getString(paramString) + ": " + paramObject;
/*    */       }
/* 50 */       return bundle.getString(paramString);
/*    */     }
/* 52 */     catch (Exception exception) {
/*    */       
/* 54 */       return "Message [" + paramString + "] not found in '" + "oracle.jdbc.driver.Messages" + "'.";
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */   
/* 60 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*    */   public static final String BUILD_DATE = "Thu_Apr_04_15:09:24_PDT_2013";
/*    */   public static final boolean TRACE = false;
/*    */ }


/* Location:              C:\Users\olatu\OneDrive\Documents\Calypso\syncbase\sync_base.jar!\BOOT-INF\classes\ojdbc.jar!\oracle\jdbc\driver\Message11.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */