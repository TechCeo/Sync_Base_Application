/*    */ package oracle.jdbc.driver;
/*    */ 
/*    */ import java.sql.SQLException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class T2CResultSetAccessor
/*    */   extends ResultSetAccessor
/*    */ {
/*    */   T2CResultSetAccessor(OracleStatement paramOracleStatement, int paramInt1, short paramShort, int paramInt2, boolean paramBoolean) throws SQLException {
/* 47 */     super(paramOracleStatement, paramInt1 * 2, paramShort, paramInt2, paramBoolean);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   T2CResultSetAccessor(OracleStatement paramOracleStatement, int paramInt1, boolean paramBoolean, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, short paramShort) throws SQLException {
/* 54 */     super(paramOracleStatement, paramInt1 * 2, paramBoolean, paramInt2, paramInt3, paramInt4, paramInt5, paramInt6, paramShort);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   byte[] getBytes(int paramInt) throws SQLException {
/* 68 */     byte[] arrayOfByte = null;
/*    */     
/* 70 */     if (isNull(paramInt)) return null;
/*    */     
/* 72 */     int i = getLength(paramInt);
/* 73 */     byte b = ((T2CConnection)this.statement.connection).byteAlign;
/* 74 */     long l = getOffset(paramInt) + (b - 1) & (b - 1 ^ 0xFFFFFFFF);
/*    */ 
/*    */ 
/*    */     
/* 78 */     this.rowData.setPosition(l);
/*    */     
/* 80 */     arrayOfByte = this.rowData.getBytes(i);
/*    */ 
/*    */     
/* 83 */     return arrayOfByte;
/*    */   }
/*    */ 
/*    */   
/* 87 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*    */   public static final String BUILD_DATE = "Thu_Apr_04_15:09:24_PDT_2013";
/*    */   public static final boolean TRACE = false;
/*    */ }


/* Location:              C:\Users\olatu\OneDrive\Documents\Calypso\syncbase\sync_base.jar!\BOOT-INF\classes\ojdbc.jar!\oracle\jdbc\driver\T2CResultSetAccessor.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */