/*     */ package oracle.jdbc.driver;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.nio.channels.SelectionKey;
/*     */ import java.nio.channels.Selector;
/*     */ import java.nio.channels.ServerSocketChannel;
/*     */ import java.nio.channels.SocketChannel;
/*     */ import java.util.Iterator;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class NTFListener
/*     */   extends Thread
/*     */ {
/*  47 */   private NTFConnection[] connections = null;
/*  48 */   private int nbOfConnections = 0;
/*     */   
/*     */   private boolean needsToBeClosed = false;
/*     */   
/*     */   NTFManager dcnManager;
/*     */   ServerSocketChannel ssChannel;
/*     */   int tcpport;
/*     */   
/*     */   NTFListener(NTFManager paramNTFManager, ServerSocketChannel paramServerSocketChannel, int paramInt) {
/*  57 */     this.dcnManager = paramNTFManager;
/*  58 */     this.connections = new NTFConnection[10];
/*  59 */     this.ssChannel = paramServerSocketChannel;
/*  60 */     this.tcpport = paramInt;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void run() {
/*     */     try {
/*  69 */       Selector selector = Selector.open();
/*  70 */       this.ssChannel.register(selector, 16);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       while (true) {
/*  77 */         selector.select();
/*  78 */         if (this.needsToBeClosed) {
/*     */           break;
/*     */         }
/*  81 */         Iterator<SelectionKey> iterator = selector.selectedKeys().iterator();
/*  82 */         while (iterator.hasNext()) {
/*     */           
/*  84 */           SelectionKey selectionKey = iterator.next();
/*     */           
/*  86 */           if ((selectionKey.readyOps() & 0x10) == 16) {
/*     */ 
/*     */ 
/*     */ 
/*     */             
/*  91 */             ServerSocketChannel serverSocketChannel = (ServerSocketChannel)selectionKey.channel();
/*     */             
/*  93 */             SocketChannel socketChannel = serverSocketChannel.accept();
/*  94 */             NTFConnection nTFConnection = new NTFConnection(this.dcnManager, socketChannel);
/*     */ 
/*     */             
/*  97 */             if (this.connections.length == this.nbOfConnections) {
/*     */ 
/*     */               
/* 100 */               NTFConnection[] arrayOfNTFConnection = new NTFConnection[this.connections.length * 2];
/* 101 */               System.arraycopy(this.connections, 0, arrayOfNTFConnection, 0, this.connections.length);
/* 102 */               this.connections = arrayOfNTFConnection;
/*     */             } 
/* 104 */             this.connections[this.nbOfConnections++] = nTFConnection;
/* 105 */             nTFConnection.start();
/* 106 */             iterator.remove();
/*     */           } 
/*     */         } 
/*     */       } 
/* 110 */       selector.close();
/* 111 */       this.ssChannel.close();
/*     */     }
/* 113 */     catch (IOException iOException) {}
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   synchronized void closeThisListener() {
/* 125 */     for (byte b = 0; b < this.nbOfConnections; b++) {
/*     */       
/* 127 */       this.connections[b].closeThisConnection();
/* 128 */       this.connections[b].interrupt();
/*     */     } 
/* 130 */     this.needsToBeClosed = true;
/*     */   }
/*     */ 
/*     */   
/* 134 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*     */   public static final String BUILD_DATE = "Thu_Apr_04_15:09:24_PDT_2013";
/*     */   public static final boolean TRACE = false;
/*     */ }


/* Location:              C:\Users\olatu\OneDrive\Documents\Calypso\syncbase\sync_base.jar!\BOOT-INF\classes\ojdbc.jar!\oracle\jdbc\driver\NTFListener.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */