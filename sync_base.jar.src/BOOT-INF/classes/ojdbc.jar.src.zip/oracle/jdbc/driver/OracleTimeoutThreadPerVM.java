/*     */ package oracle.jdbc.driver;
/*     */ 
/*     */ import java.sql.SQLException;
/*     */ import oracle.jdbc.internal.OracleConnection;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class OracleTimeoutThreadPerVM
/*     */   extends OracleTimeout
/*     */ {
/*  27 */   private static final OracleTimeoutPollingThread watchdog = new OracleTimeoutPollingThread();
/*     */ 
/*     */ 
/*     */   
/*     */   private OracleStatement statement;
/*     */ 
/*     */ 
/*     */   
/*     */   private long interruptAfter;
/*     */ 
/*     */ 
/*     */   
/*     */   private String name;
/*     */ 
/*     */ 
/*     */   
/*     */   OracleTimeoutThreadPerVM(String paramString) {
/*  44 */     this.name = paramString;
/*  45 */     this.interruptAfter = Long.MAX_VALUE;
/*  46 */     watchdog.addTimeout(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void close() {
/*  60 */     watchdog.removeTimeout(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   synchronized void setTimeout(long paramLong, OracleStatement paramOracleStatement) throws SQLException {
/*  79 */     if (this.interruptAfter != Long.MAX_VALUE) {
/*     */ 
/*     */ 
/*     */       
/*  83 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 131);
/*  84 */       sQLException.fillInStackTrace();
/*  85 */       throw sQLException;
/*     */     } 
/*     */ 
/*     */     
/*  89 */     this.statement = paramOracleStatement;
/*  90 */     this.interruptAfter = System.currentTimeMillis() + paramLong;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   synchronized void cancelTimeout() throws SQLException {
/* 114 */     this.statement = null;
/* 115 */     this.interruptAfter = Long.MAX_VALUE;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void interruptIfAppropriate(long paramLong) {
/* 142 */     if (paramLong > this.interruptAfter)
/*     */     {
/* 144 */       synchronized (this) {
/*     */         
/* 146 */         if (paramLong > this.interruptAfter) {
/*     */ 
/*     */           
/* 149 */           if (this.statement.connection.spawnNewThreadToCancel) {
/* 150 */             final OracleStatement s = this.statement;
/* 151 */             Thread thread = new Thread(new Runnable() {
/*     */                   public void run() {
/*     */                     try {
/* 154 */                       s.cancel();
/*     */                     }
/* 156 */                     catch (Throwable throwable) {}
/*     */                   }
/*     */                 });
/*     */ 
/*     */             
/* 161 */             thread.setName("interruptIfAppropriate_" + this);
/* 162 */             thread.setDaemon(true);
/* 163 */             thread.setPriority(10);
/* 164 */             thread.start();
/*     */           } else {
/*     */             
/*     */             try {
/* 168 */               this.statement.cancel();
/*     */             }
/* 170 */             catch (Throwable throwable) {}
/*     */           } 
/*     */ 
/*     */ 
/*     */           
/* 175 */           this.statement = null;
/* 176 */           this.interruptAfter = Long.MAX_VALUE;
/*     */         } 
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected OracleConnection getConnectionDuringExceptionHandling() {
/* 195 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 201 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*     */   public static final String BUILD_DATE = "Thu_Apr_04_15:09:24_PDT_2013";
/*     */   public static final boolean TRACE = false;
/*     */ }


/* Location:              C:\Users\olatu\OneDrive\Documents\Calypso\syncbase\sync_base.jar!\BOOT-INF\classes\ojdbc.jar!\oracle\jdbc\driver\OracleTimeoutThreadPerVM.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */