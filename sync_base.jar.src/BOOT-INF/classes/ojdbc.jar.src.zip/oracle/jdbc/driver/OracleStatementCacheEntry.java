/*    */ package oracle.jdbc.driver;
/*    */ 
/*    */ import java.sql.SQLException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class OracleStatementCacheEntry
/*    */ {
/* 45 */   protected OracleStatementCacheEntry applicationNext = null;
/* 46 */   protected OracleStatementCacheEntry applicationPrev = null;
/*    */ 
/*    */   
/* 49 */   protected OracleStatementCacheEntry explicitNext = null;
/* 50 */   protected OracleStatementCacheEntry explicitPrev = null;
/*    */ 
/*    */   
/* 53 */   protected OracleStatementCacheEntry implicitNext = null;
/* 54 */   protected OracleStatementCacheEntry implicitPrev = null;
/*    */ 
/*    */ 
/*    */   
/*    */   boolean onImplicit;
/*    */ 
/*    */   
/*    */   String sql;
/*    */ 
/*    */   
/*    */   int statementType;
/*    */ 
/*    */   
/*    */   int scrollType;
/*    */ 
/*    */   
/*    */   OraclePreparedStatement statement;
/*    */ 
/*    */ 
/*    */   
/*    */   public void print() throws SQLException {
/* 75 */     System.out.println("Cache entry " + this);
/* 76 */     System.out.println("  Key: " + this.sql + "$$" + this.statementType + "$$" + this.scrollType);
/*    */     
/* 78 */     System.out.println("  Statement: " + this.statement);
/* 79 */     System.out.println("  onImplicit: " + this.onImplicit);
/* 80 */     System.out.println("  applicationNext: " + this.applicationNext + "  applicationPrev: " + this.applicationPrev);
/*    */     
/* 82 */     System.out.println("  implicitNext: " + this.implicitNext + "  implicitPrev: " + this.implicitPrev);
/*    */     
/* 84 */     System.out.println("  explicitNext: " + this.explicitNext + "  explicitPrev: " + this.explicitPrev);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 92 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*    */   public static final String BUILD_DATE = "Thu_Apr_04_15:09:24_PDT_2013";
/*    */   public static final boolean TRACE = false;
/*    */ }


/* Location:              C:\Users\olatu\OneDrive\Documents\Calypso\syncbase\sync_base.jar!\BOOT-INF\classes\ojdbc.jar!\oracle\jdbc\driver\OracleStatementCacheEntry.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */