/*     */ package oracle.jdbc.driver;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import oracle.net.ns.BreakNetException;
/*     */ import oracle.net.ns.NetException;
/*     */ import oracle.net.ns.NetInputStream;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class T4CSocketInputStreamWrapper
/*     */   extends NetInputStream
/*     */ {
/*     */   static final int MAX_BUFFER_SIZE = 2048;
/*  50 */   NetInputStream is = null;
/*  51 */   T4CSocketOutputStreamWrapper os = null;
/*     */   
/*     */   boolean eof = false;
/*  54 */   byte[] buffer = new byte[2048];
/*     */   
/*  56 */   int bIndex = 0;
/*     */ 
/*     */   
/*     */   int bytesAvailable;
/*     */ 
/*     */ 
/*     */   
/*     */   T4CSocketInputStreamWrapper(NetInputStream paramNetInputStream, T4CSocketOutputStreamWrapper paramT4CSocketOutputStreamWrapper) throws IOException {
/*  64 */     this.is = paramNetInputStream;
/*  65 */     this.os = paramT4CSocketOutputStreamWrapper;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final int read() throws IOException {
/*  74 */     if (this.eof) {
/*  75 */       return -1;
/*     */     }
/*  77 */     if (this.bytesAvailable < 1) {
/*     */       
/*  79 */       readNextPacket();
/*  80 */       if (this.eof)
/*  81 */         return -1; 
/*     */     } 
/*  83 */     this.bytesAvailable--;
/*  84 */     return this.buffer[this.bIndex++] & 0xFF;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public final int read(byte[] paramArrayOfbyte, int paramInt1, int paramInt2) throws IOException {
/*  90 */     if (this.eof) {
/*  91 */       return 0;
/*     */     }
/*  93 */     if (this.bytesAvailable < paramInt2) {
/*     */       
/*  95 */       int i = this.bytesAvailable;
/*     */ 
/*     */       
/*  98 */       System.arraycopy(this.buffer, this.bIndex, paramArrayOfbyte, paramInt1, i);
/*  99 */       paramInt1 += i;
/* 100 */       this.bIndex += i;
/* 101 */       this.bytesAvailable -= i;
/*     */ 
/*     */       
/* 104 */       this.is.read(paramArrayOfbyte, paramInt1, paramInt2 - i);
/*     */     } else {
/*     */       
/* 107 */       System.arraycopy(this.buffer, this.bIndex, paramArrayOfbyte, paramInt1, paramInt2);
/* 108 */       this.bIndex += paramInt2;
/* 109 */       this.bytesAvailable -= paramInt2;
/*     */     } 
/*     */     
/* 112 */     return paramInt2;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void readNextPacket() throws IOException {
/* 119 */     this.os.flush();
/*     */ 
/*     */ 
/*     */     
/* 123 */     int i = this.is.read();
/*     */ 
/*     */     
/* 126 */     if (i == -1) {
/*     */       
/* 128 */       this.eof = true;
/*     */       
/*     */       return;
/*     */     } 
/* 132 */     this.buffer[0] = (byte)i;
/*     */     
/* 134 */     this.bytesAvailable = this.is.available() + 1;
/*     */ 
/*     */ 
/*     */     
/* 138 */     this.bytesAvailable = (this.bytesAvailable > 2048) ? 2048 : this.bytesAvailable;
/*     */ 
/*     */     
/* 141 */     if (this.bytesAvailable > 1) {
/* 142 */       this.is.read(this.buffer, 1, this.bytesAvailable - 1);
/*     */     }
/*     */     
/* 145 */     this.bIndex = 0;
/*     */   }
/*     */ 
/*     */   
/*     */   public int readB1() throws IOException {
/* 150 */     return read();
/*     */   }
/*     */ 
/*     */   
/*     */   public long readLongLSB(int paramInt) throws IOException {
/* 155 */     long l = 0L;
/* 156 */     boolean bool = false;
/*     */     
/* 158 */     if ((paramInt & 0x80) > 0) {
/*     */       
/* 160 */       paramInt &= 0x7F;
/* 161 */       bool = true;
/*     */     } 
/*     */     
/*     */     int i;
/*     */     byte b;
/* 166 */     for (i = paramInt, b = 0; i > 0; i--, b++) {
/*     */       
/* 168 */       if (this.bytesAvailable < 1)
/*     */       {
/* 170 */         readNextPacket();
/*     */       }
/* 172 */       l |= (this.buffer[this.bIndex++] & 0xFFL) << 8 * b;
/* 173 */       this.bytesAvailable--;
/*     */     } 
/*     */ 
/*     */     
/* 177 */     return (bool ? -1L : 1L) * l;
/*     */   }
/*     */ 
/*     */   
/*     */   public long readLongMSB(int paramInt) throws IOException {
/* 182 */     long l = 0L;
/* 183 */     boolean bool = false;
/*     */ 
/*     */     
/* 186 */     if ((paramInt & 0x80) > 0) {
/*     */       
/* 188 */       paramInt &= 0x7F;
/* 189 */       bool = true;
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 194 */     for (int i = paramInt; i > 0; i--) {
/*     */       
/* 196 */       if (this.bytesAvailable < 1)
/*     */       {
/* 198 */         readNextPacket();
/*     */       }
/* 200 */       l |= (this.buffer[this.bIndex++] & 0xFFL) << 8 * (i - 1);
/*     */       
/* 202 */       this.bytesAvailable--;
/*     */     } 
/*     */ 
/*     */     
/* 206 */     return (bool ? -1L : 1L) * l;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean readZeroCopyIO(byte[] paramArrayOfbyte, int paramInt, int[] paramArrayOfint) throws IOException, NetException, BreakNetException {
/* 212 */     this.os.flush();
/* 213 */     return this.is.readZeroCopyIO(paramArrayOfbyte, paramInt, paramArrayOfint);
/*     */   }
/*     */ }


/* Location:              C:\Users\olatu\OneDrive\Documents\Calypso\syncbase\sync_base.jar!\BOOT-INF\classes\ojdbc.jar!\oracle\jdbc\driver\T4CSocketInputStreamWrapper.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */