/*     */ package oracle.jdbc.driver;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.sql.SQLException;
/*     */ import java.util.ArrayList;
/*     */ import oracle.jdbc.internal.OracleConnection;
/*     */ import oracle.sql.TIMESTAMPTZ;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class T4CTTIokpn
/*     */   extends T4CTTIfun
/*     */ {
/*     */   static final int REGISTER_KPNDEF = 1;
/*     */   static final int UNREGISTER_KPNDEF = 2;
/*     */   static final int POST_KPNDEF = 3;
/*     */   static final int EXISTINGCLIENT_KPNDEF = 0;
/*     */   static final int NEWCLIENT_KPNDEF = 1;
/*     */   static final int CLIENTCON_KPNDEF = 4;
/*     */   static final int KPUN_PRS_RAW = 1;
/*     */   static final int KPUN_VER_10200 = 2;
/*     */   static final int KPUN_VER_11100 = 3;
/*     */   static final int KPUN_VER_11200 = 4;
/*     */   static final int OCI_SUBSCR_NAMESPACE_ANONYMOUS = 0;
/*     */   static final int OCI_SUBSCR_NAMESPACE_AQ = 1;
/*     */   static final int OCI_SUBSCR_NAMESPACE_DBCHANGE = 2;
/*     */   static final int OCI_SUBSCR_NAMESPACE_MAX = 3;
/*     */   static final int KPD_CHNF_OPFILTER = 1;
/*     */   static final int KPD_CHNF_INSERT = 2;
/*     */   static final int KPD_CHNF_UPDATE = 4;
/*     */   static final int KPD_CHNF_DELETE = 8;
/*     */   static final int KPD_CHNF_ROWID = 16;
/*     */   static final int KPD_CQ_QUERYNF = 32;
/*     */   static final int KPD_CQ_BEST_EFFORT = 64;
/*     */   static final int KPD_CQ_CLQRYCACHE = 128;
/*     */   static final int KPD_CHNF_INVALID_REGID = 0;
/*     */   static final int KPD_NTFN_CONNID_LEN = 29;
/*     */   static final int KKCN_CTX_RAW = 0;
/*     */   static final int SUBSCR_QOS_RELIABLE = 1;
/*     */   static final int SUBSCR_QOS_PAYLOAD = 2;
/*     */   static final int SUBSCR_QOS_REPLICATE = 4;
/*     */   static final int SUBSCR_QOS_SECURE = 8;
/*     */   static final int SUBSCR_QOS_PURGE_ON_NTFN = 16;
/*     */   static final int SUBSCR_QOS_MULTICBK = 32;
/*     */   static final int SUBSCR_QOS_ASYNC_DEQ = 512;
/*     */   static final int SUBSCR_QOS_TX_ACK = 2048;
/*     */   static final int SUBSCR_QOS_AUTO_ACK = 1024;
/*     */   static final byte SUBSCR_NTFN_GROUPING_CLASS_NONE = 0;
/*     */   static final byte SUBSCR_NTFN_GROUPING_CLASS_TIME = 1;
/*     */   static final byte SUBSCR_NTFN_GROUPING_TYPE_SUMMARY = 1;
/*     */   static final byte SUBSCR_NTFN_GROUPING_TYPE_LAST = 2;
/*     */   private int opcode;
/*     */   private int mode;
/*     */   private int nbOfRegistrationInfo;
/*     */   private String user;
/*     */   private String location;
/*     */   private String jmsClientId;
/*     */   private String[] databaseInstances;
/*     */   private int[] namespace;
/*     */   private int[] kpdnrgrpval;
/*     */   private int[] kpdnrgrprepcnt;
/*     */   private int[] payloadType;
/*     */   private int[] qosFlags;
/*     */   private int[] timeout;
/*     */   private int[] dbchangeOpFilter;
/*     */   private int[] dbchangeTxnLag;
/*     */   private byte[] kpncid;
/*     */   private byte[][] registeredAgentName;
/*     */   private byte[][] kpdnrcx;
/*     */   private byte[] kpdnrgrpcla;
/*     */   private byte[] kpdnrgrptyp;
/*     */   private TIMESTAMPTZ[] kpdnrgrpstatim;
/*     */   private long[] dbchangeRegistrationId;
/*     */   private byte[] userArr;
/*     */   private byte[] locationArr;
/*     */   private byte[] subscriberName;
/*     */   private long regid;
/*     */   private long[] registrationId;
/*     */   ArrayList<String> listenerAddresses;
/*     */   T4CTTIkpdnrri kpninst;
/*     */   T4CTTIkpdnrgnc kpngcret;
/*     */   
/*     */   T4CTTIokpn(T4CConnection paramT4CConnection) {
/* 261 */     super(paramT4CConnection, (byte)3);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 269 */     this.jmsClientId = null;
/* 270 */     this.databaseInstances = null;
/* 271 */     this.dbchangeTxnLag = null;
/*     */ 
/*     */     
/* 274 */     this.kpncid = null;
/* 275 */     this.registeredAgentName = (byte[][])null;
/* 276 */     this.kpdnrcx = (byte[][])null;
/* 277 */     this.kpdnrgrptyp = null;
/* 278 */     this.kpdnrgrpstatim = null;
/* 279 */     this.dbchangeRegistrationId = null;
/* 280 */     this.userArr = null;
/* 281 */     this.locationArr = null;
/* 282 */     this.subscriberName = null;
/*     */     
/* 284 */     this.regid = 0L;
/* 285 */     this.registrationId = null;
/*     */     
/* 287 */     this.listenerAddresses = new ArrayList<>();
/* 288 */     this.kpninst = null;
/* 289 */     this.kpngcret = null;
/*     */     setFunCode((short)125);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void doOKPN(int paramInt1, int paramInt2, String paramString1, String paramString2, int paramInt3, int[] paramArrayOfint1, String[] paramArrayOfString, byte[][] paramArrayOfbyte, int[] paramArrayOfint2, int[] paramArrayOfint3, int[] paramArrayOfint4, int[] paramArrayOfint5, int[] paramArrayOfint6, long[] paramArrayOflong1, byte[] paramArrayOfbyte1, int[] paramArrayOfint7, byte[] paramArrayOfbyte2, TIMESTAMPTZ[] paramArrayOfTIMESTAMPTZ, int[] paramArrayOfint8, long[] paramArrayOflong2) throws IOException, SQLException {
/* 317 */     this.opcode = paramInt1;
/* 318 */     this.mode = paramInt2;
/* 319 */     this.user = paramString1;
/* 320 */     this.location = paramString2;
/* 321 */     this.nbOfRegistrationInfo = paramInt3;
/* 322 */     this.namespace = paramArrayOfint1;
/* 323 */     this.kpdnrcx = paramArrayOfbyte;
/* 324 */     this.payloadType = paramArrayOfint2;
/* 325 */     this.qosFlags = paramArrayOfint3;
/* 326 */     this.timeout = paramArrayOfint4;
/* 327 */     this.dbchangeOpFilter = paramArrayOfint5;
/* 328 */     if (this.dbchangeOpFilter == null)
/*     */     {
/* 330 */       this.dbchangeOpFilter = new int[this.nbOfRegistrationInfo];
/*     */     }
/* 332 */     this.dbchangeTxnLag = paramArrayOfint6;
/* 333 */     if (this.dbchangeTxnLag == null)
/*     */     {
/* 335 */       this.dbchangeTxnLag = new int[this.nbOfRegistrationInfo];
/*     */     }
/* 337 */     this.dbchangeRegistrationId = paramArrayOflong1;
/* 338 */     if (this.dbchangeRegistrationId == null)
/*     */     {
/* 340 */       this.dbchangeRegistrationId = new long[this.nbOfRegistrationInfo];
/*     */     }
/* 342 */     this.kpdnrgrpcla = paramArrayOfbyte1;
/* 343 */     if (this.kpdnrgrpcla == null)
/*     */     {
/* 345 */       this.kpdnrgrpcla = new byte[this.nbOfRegistrationInfo];
/*     */     }
/* 347 */     this.kpdnrgrpval = paramArrayOfint7;
/* 348 */     if (this.kpdnrgrpval == null)
/*     */     {
/* 350 */       this.kpdnrgrpval = new int[this.nbOfRegistrationInfo];
/*     */     }
/* 352 */     this.kpdnrgrptyp = paramArrayOfbyte2;
/* 353 */     if (this.kpdnrgrptyp == null)
/*     */     {
/* 355 */       this.kpdnrgrptyp = new byte[this.nbOfRegistrationInfo];
/*     */     }
/* 357 */     this.kpdnrgrpstatim = paramArrayOfTIMESTAMPTZ;
/* 358 */     if (this.kpdnrgrpstatim == null)
/*     */     {
/* 360 */       this.kpdnrgrpstatim = new TIMESTAMPTZ[this.nbOfRegistrationInfo];
/*     */     }
/* 362 */     this.kpdnrgrprepcnt = paramArrayOfint8;
/* 363 */     if (this.kpdnrgrprepcnt == null)
/*     */     {
/* 365 */       this.kpdnrgrprepcnt = new int[this.nbOfRegistrationInfo];
/*     */     }
/* 367 */     this.registrationId = paramArrayOflong2;
/* 368 */     if (this.registrationId == null)
/*     */     {
/* 370 */       this.registrationId = new long[this.nbOfRegistrationInfo];
/*     */     }
/* 372 */     this.registeredAgentName = new byte[this.nbOfRegistrationInfo][];
/* 373 */     for (byte b = 0; b < this.nbOfRegistrationInfo; b++) {
/* 374 */       if (paramArrayOfString[b] != null)
/* 375 */         this.registeredAgentName[b] = this.meg.conv.StringToCharBytes(paramArrayOfString[b]); 
/*     */     } 
/* 377 */     if (this.user != null) {
/* 378 */       this.userArr = this.meg.conv.StringToCharBytes(this.user);
/*     */     } else {
/* 380 */       this.userArr = null;
/*     */     } 
/* 382 */     if (this.location != null) {
/* 383 */       this.locationArr = this.meg.conv.StringToCharBytes(this.location);
/*     */     } else {
/* 385 */       this.locationArr = null;
/*     */     } 
/*     */     
/* 388 */     this.regid = 0L;
/*     */     
/* 390 */     doRPC();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void marshal() throws IOException {
/* 398 */     boolean bool = true;
/* 399 */     byte b1 = 2;
/*     */ 
/*     */     
/* 402 */     this.meg.marshalUB1((short)(byte)this.opcode);
/*     */     
/* 404 */     this.meg.marshalUB4(this.mode);
/*     */     
/* 406 */     if (this.userArr != null) {
/*     */       
/* 408 */       this.meg.marshalPTR();
/* 409 */       this.meg.marshalUB4(this.userArr.length);
/*     */     }
/*     */     else {
/*     */       
/* 413 */       this.meg.marshalNULLPTR();
/* 414 */       this.meg.marshalUB4(0L);
/*     */     } 
/*     */ 
/*     */     
/* 418 */     if (this.locationArr != null) {
/*     */       
/* 420 */       this.meg.marshalPTR();
/* 421 */       this.meg.marshalUB4(this.locationArr.length);
/*     */     }
/*     */     else {
/*     */       
/* 425 */       this.meg.marshalNULLPTR();
/* 426 */       this.meg.marshalUB4(0L);
/*     */     } 
/*     */ 
/*     */     
/* 430 */     this.meg.marshalPTR();
/* 431 */     this.meg.marshalUB4(this.nbOfRegistrationInfo);
/*     */     
/* 433 */     this.meg.marshalUB2(bool);
/*     */     
/* 435 */     this.meg.marshalUB2(b1);
/* 436 */     if (this.connection.getTTCVersion() >= 4) {
/*     */ 
/*     */       
/* 439 */       this.meg.marshalNULLPTR();
/*     */       
/* 441 */       this.meg.marshalPTR();
/*     */       
/* 443 */       if (this.connection.getTTCVersion() >= 5) {
/*     */ 
/*     */         
/* 446 */         this.meg.marshalNULLPTR();
/*     */         
/* 448 */         this.meg.marshalPTR();
/* 449 */         if (this.connection.getTTCVersion() >= 7) {
/*     */           
/* 451 */           this.meg.marshalPTR();
/*     */           
/* 453 */           this.meg.marshalPTR();
/*     */           
/* 455 */           this.meg.marshalPTR();
/*     */           
/* 457 */           this.meg.marshalPTR();
/*     */           
/* 459 */           this.meg.marshalPTR();
/*     */           
/* 461 */           this.meg.marshalSWORD(29);
/*     */           
/* 463 */           this.meg.marshalPTR();
/*     */         } 
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 470 */     if (this.userArr != null)
/* 471 */       this.meg.marshalCHR(this.userArr); 
/* 472 */     if (this.locationArr != null) {
/* 473 */       this.meg.marshalCHR(this.locationArr);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 480 */     assert this.namespace != null && this.registeredAgentName != null && this.payloadType != null && this.qosFlags != null && this.timeout != null : " namespace : " + this.namespace + ", registeredAgentName : " + this.registeredAgentName + ", payloadType : " + this.payloadType + ", qosFlags : " + this.qosFlags + ", timeout : " + this.timeout;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 499 */     assert this.namespace.length == this.nbOfRegistrationInfo && this.registeredAgentName.length == this.nbOfRegistrationInfo && this.payloadType.length == this.nbOfRegistrationInfo && this.qosFlags.length == this.nbOfRegistrationInfo && this.timeout.length == this.nbOfRegistrationInfo && this.kpdnrcx.length == this.nbOfRegistrationInfo && this.dbchangeOpFilter.length == this.nbOfRegistrationInfo && this.dbchangeTxnLag.length == this.nbOfRegistrationInfo && this.kpdnrgrpcla.length == this.nbOfRegistrationInfo && this.kpdnrgrpval.length == this.nbOfRegistrationInfo && this.kpdnrgrptyp.length == this.nbOfRegistrationInfo && this.kpdnrgrpstatim.length == this.nbOfRegistrationInfo && this.kpdnrgrprepcnt.length == this.nbOfRegistrationInfo && this.registrationId.length == this.nbOfRegistrationInfo : " namespace.length = " + this.namespace.length + ", registeredAgentName.length = " + this.registeredAgentName.length + ", qosFlags.length = " + this.qosFlags.length + ", timeout.length = " + this.timeout.length + ", kpdnrcx.length = " + this.kpdnrcx.length + ", dbchangeOpFilter.length = " + this.dbchangeOpFilter.length + ", dbchangeTxnLag.length = " + this.dbchangeTxnLag.length + ", kpdnrgrpcla.length = " + this.kpdnrgrpcla.length + ", kpdnrgrpval.length = " + this.kpdnrgrpval.length + ", kpdnrgrptyp.length = " + this.kpdnrgrptyp.length + ", kpdnrgrpstatim.length = " + this.kpdnrgrpstatim.length + ", kpdnrgrprepcnt.length = " + this.kpdnrgrprepcnt.length + ", registrationId.length = " + this.registrationId.length;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 512 */     for (byte b2 = 0; b2 < this.nbOfRegistrationInfo; b2++) {
/*     */       
/* 514 */       this.meg.marshalUB4(this.namespace[b2]);
/*     */       
/* 516 */       byte[] arrayOfByte = this.registeredAgentName[b2];
/* 517 */       if (arrayOfByte != null && arrayOfByte.length > 0) {
/* 518 */         this.meg.marshalUB4(arrayOfByte.length);
/* 519 */         this.meg.marshalCLR(arrayOfByte, 0, arrayOfByte.length);
/*     */       } else {
/*     */         
/* 522 */         this.meg.marshalUB4(0L);
/*     */       } 
/* 524 */       if (this.kpdnrcx == null) {
/* 525 */         this.meg.marshalUB4(0L);
/*     */       }
/* 527 */       else if (this.kpdnrcx[b2] != null && (this.kpdnrcx[b2]).length > 0) {
/* 528 */         this.meg.marshalUB4((this.kpdnrcx[b2]).length);
/* 529 */         this.meg.marshalCLR(this.kpdnrcx[b2], 0, (this.kpdnrcx[b2]).length);
/*     */       } else {
/*     */         
/* 532 */         this.meg.marshalUB4(0L);
/*     */       } 
/* 534 */       this.meg.marshalUB4(this.payloadType[b2]);
/* 535 */       if (this.connection.getTTCVersion() >= 4) {
/*     */         
/* 537 */         this.meg.marshalUB4(this.qosFlags[b2]);
/* 538 */         byte[] arrayOfByte1 = new byte[0];
/* 539 */         this.meg.marshalUB4(arrayOfByte1.length);
/* 540 */         if (arrayOfByte1.length > 0) {
/* 541 */           this.meg.marshalCLR(arrayOfByte1, arrayOfByte1.length);
/*     */         }
/* 543 */         this.meg.marshalUB4(this.timeout[b2]);
/*     */         
/* 545 */         boolean bool1 = false;
/* 546 */         this.meg.marshalUB4(bool1);
/*     */         
/* 548 */         this.meg.marshalUB4(this.dbchangeOpFilter[b2]);
/*     */         
/* 550 */         this.meg.marshalUB4(this.dbchangeTxnLag[b2]);
/* 551 */         this.meg.marshalUB4((int)this.dbchangeRegistrationId[b2]);
/*     */         
/* 553 */         if (this.connection.getTTCVersion() >= 5) {
/* 554 */           this.meg.marshalUB1((short)this.kpdnrgrpcla[b2]);
/* 555 */           this.meg.marshalUB4(this.kpdnrgrpval[b2]);
/* 556 */           this.meg.marshalUB1((short)this.kpdnrgrptyp[b2]);
/* 557 */           if (this.kpdnrgrpstatim[b2] == null) {
/* 558 */             this.meg.marshalDALC(null);
/*     */           } else {
/* 560 */             this.meg.marshalDALC(this.kpdnrgrpstatim[b2].shareBytes());
/* 561 */           }  this.meg.marshalSB4(this.kpdnrgrprepcnt[b2]);
/*     */ 
/*     */           
/* 564 */           this.meg.marshalSB8(this.registrationId[b2]);
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   long getRegistrationId() {
/* 574 */     return this.regid;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void readRPA() throws IOException, SQLException {
/* 583 */     int i = (int)this.meg.unmarshalUB4();
/* 584 */     for (byte b = 0; b < i; b++)
/* 585 */       this.meg.unmarshalUB4(); 
/* 586 */     int[] arrayOfInt = new int[i]; int j;
/* 587 */     for (j = 0; j < i; j++)
/* 588 */       arrayOfInt[j] = (int)this.meg.unmarshalUB4(); 
/* 589 */     this.regid = arrayOfInt[0];
/* 590 */     if (this.connection.getTTCVersion() >= 5) {
/* 591 */       j = (int)this.meg.unmarshalUB4();
/* 592 */       this.registrationId = new long[j]; int k;
/* 593 */       for (k = 0; k < j; k++) {
/*     */ 
/*     */         
/* 596 */         this.registrationId[k] = this.meg.unmarshalSB8();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 602 */         if (this.connection.getTTCVersion() >= 7) {
/* 603 */           int m = (int)this.meg.unmarshalUB4();
/* 604 */           if (m > 0) {
/* 605 */             this.subscriberName = new byte[m];
/* 606 */             this.meg.unmarshalBuffer(this.subscriberName, 0, m);
/*     */           } 
/*     */         } 
/*     */       } 
/* 610 */       this.regid = this.registrationId[0];
/* 611 */       if (this.connection.getTTCVersion() >= 7) {
/*     */         
/* 613 */         k = (int)this.meg.unmarshalUB4();
/* 614 */         this.databaseInstances = new String[k]; int m;
/* 615 */         for (m = 0; m < k; m++) {
/*     */ 
/*     */           
/* 618 */           this.kpninst = new T4CTTIkpdnrri(this.connection);
/* 619 */           this.kpninst.receive();
/* 620 */           byte[] arrayOfByte = this.kpninst.getKpdnrrinm();
/* 621 */           if (arrayOfByte != null) {
/* 622 */             this.databaseInstances[m] = this.meg.conv.CharBytesToString(arrayOfByte, arrayOfByte.length);
/*     */           }
/*     */         } 
/* 625 */         m = (int)this.meg.unmarshalUB4();
/*     */         
/* 627 */         this.listenerAddresses = new ArrayList<>(); int n;
/* 628 */         for (n = 0; n < m; n++) {
/* 629 */           this.kpngcret = new T4CTTIkpdnrgnc(this.connection);
/* 630 */           this.kpngcret.receive();
/*     */           
/* 632 */           byte[] arrayOfByte = this.kpngcret.getKpdnrgnclsc();
/* 633 */           if (arrayOfByte != null) {
/*     */ 
/*     */ 
/*     */             
/* 637 */             String str = this.meg.conv.CharBytesToString(arrayOfByte, arrayOfByte.length);
/* 638 */             this.listenerAddresses.add(str);
/*     */           } 
/*     */         } 
/* 641 */         n = this.meg.unmarshalUB2();
/* 642 */         if (n > 0) {
/* 643 */           this.kpncid = new byte[n];
/* 644 */           this.kpncid = this.meg.unmarshalCHR(n);
/* 645 */           if (this.kpncid != null) {
/* 646 */             this.jmsClientId = this.meg.conv.CharBytesToString(this.kpncid, this.kpncid.length);
/*     */           }
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected OracleConnection getConnectionDuringExceptionHandling() {
/* 665 */     return this.connection;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   ArrayList<String> getListenerAddresses() {
/* 677 */     return this.listenerAddresses;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   String getListenerAddress() throws SQLException {
/* 684 */     SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException();
/* 685 */     sQLException.fillInStackTrace();
/* 686 */     throw sQLException;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   long[] getRegistrationIdArray() {
/* 696 */     return this.registrationId;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   String getJMSClientId() {
/* 705 */     return this.jmsClientId;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   String[] getDatabaseInstances() {
/* 714 */     return this.databaseInstances;
/*     */   }
/*     */ 
/*     */   
/* 718 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*     */   public static final String BUILD_DATE = "Thu_Apr_04_15:09:24_PDT_2013";
/*     */   public static final boolean TRACE = false;
/*     */ }


/* Location:              C:\Users\olatu\OneDrive\Documents\Calypso\syncbase\sync_base.jar!\BOOT-INF\classes\ojdbc.jar!\oracle\jdbc\driver\T4CTTIokpn.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */