/*     */ package oracle.jdbc.driver;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.sql.SQLException;
/*     */ import oracle.jdbc.internal.XSPrincipal;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class XSPrincipalI
/*     */   extends XSPrincipal
/*     */ {
/*  39 */   long kpxsprindbid = 0L;
/*  40 */   String kpxsprinname = null;
/*  41 */   byte[] kpxsprinnameBytes = null;
/*  42 */   byte[] kpxsprinuuid = null;
/*  43 */   XSPrincipal.Flag kpxsprinflg = XSPrincipal.Flag.KPXS_PRIN_EXT;
/*     */ 
/*     */   
/*     */   public void setDatabaseId(long paramLong) throws SQLException {
/*  47 */     this.kpxsprindbid = paramLong;
/*     */   }
/*     */   
/*     */   public void setName(String paramString) throws SQLException {
/*  51 */     this.kpxsprinname = paramString;
/*     */   }
/*     */   
/*     */   public void setUUID(byte[] paramArrayOfbyte) throws SQLException {
/*  55 */     this.kpxsprinuuid = paramArrayOfbyte;
/*     */   }
/*     */   
/*     */   public void setFlag(XSPrincipal.Flag paramFlag) throws SQLException {
/*  59 */     this.kpxsprinflg = paramFlag;
/*     */   }
/*     */ 
/*     */   
/*     */   public long getDatabaseId() {
/*  64 */     return this.kpxsprindbid;
/*     */   }
/*     */   
/*     */   public String getName() {
/*  68 */     return this.kpxsprinname;
/*     */   }
/*     */   
/*     */   public byte[] getUUID() {
/*  72 */     return this.kpxsprinuuid;
/*     */   }
/*     */   
/*     */   public XSPrincipal.Flag getFlag() {
/*  76 */     return this.kpxsprinflg;
/*     */   }
/*     */ 
/*     */   
/*     */   void doCharConversion(DBConversion paramDBConversion) throws SQLException {
/*  81 */     if (this.kpxsprinname != null) {
/*  82 */       this.kpxsprinnameBytes = paramDBConversion.StringToCharBytes(this.kpxsprinname);
/*     */     } else {
/*  84 */       this.kpxsprinnameBytes = null;
/*     */     } 
/*     */   }
/*     */   
/*     */   void marshal(T4CMAREngine paramT4CMAREngine) throws IOException {
/*  89 */     paramT4CMAREngine.marshalSB8(this.kpxsprindbid);
/*  90 */     if (this.kpxsprinnameBytes != null) {
/*     */       
/*  92 */       paramT4CMAREngine.marshalUB4(this.kpxsprinnameBytes.length);
/*  93 */       paramT4CMAREngine.marshalCLR(this.kpxsprinnameBytes, this.kpxsprinnameBytes.length);
/*     */     } else {
/*     */       
/*  96 */       paramT4CMAREngine.marshalUB4(0L);
/*     */     } 
/*  98 */     if (this.kpxsprinuuid != null) {
/*     */       
/* 100 */       paramT4CMAREngine.marshalUB4(this.kpxsprinuuid.length);
/* 101 */       paramT4CMAREngine.marshalCLR(this.kpxsprinuuid, this.kpxsprinuuid.length);
/*     */     } else {
/*     */       
/* 104 */       paramT4CMAREngine.marshalUB4(0L);
/*     */     } 
/* 106 */     paramT4CMAREngine.marshalUB4(this.kpxsprinflg.getMode());
/*     */   }
/*     */   static XSPrincipalI unmarshal(T4CMAREngine paramT4CMAREngine) throws SQLException, IOException {
/*     */     XSPrincipal.Flag flag;
/* 110 */     int[] arrayOfInt = new int[1];
/*     */     
/* 112 */     long l1 = paramT4CMAREngine.unmarshalSB8();
/*     */     
/* 114 */     String str = null;
/* 115 */     int i = (int)paramT4CMAREngine.unmarshalUB4();
/* 116 */     if (i > 0) {
/*     */       
/* 118 */       byte[] arrayOfByte1 = new byte[i];
/* 119 */       paramT4CMAREngine.unmarshalCLR(arrayOfByte1, 0, arrayOfInt);
/* 120 */       str = paramT4CMAREngine.conv.CharBytesToString(arrayOfByte1, arrayOfInt[0]);
/*     */     } 
/*     */     
/* 123 */     byte[] arrayOfByte = null;
/* 124 */     int j = (int)paramT4CMAREngine.unmarshalUB4();
/* 125 */     if (j > 0) {
/*     */       
/* 127 */       paramT4CMAREngine.unmarshalUB1();
/* 128 */       arrayOfByte = paramT4CMAREngine.unmarshalNBytes(j);
/*     */     } 
/*     */     
/* 131 */     long l2 = paramT4CMAREngine.unmarshalUB4();
/*     */     
/* 133 */     if (l2 == XSPrincipal.Flag.KPXS_PRIN_EXT.getMode()) {
/* 134 */       flag = XSPrincipal.Flag.KPXS_PRIN_EXT;
/*     */     } else {
/* 136 */       flag = XSPrincipal.Flag.KPXS_PRIN_USEDBID;
/*     */     } 
/* 138 */     XSPrincipalI xSPrincipalI = new XSPrincipalI();
/* 139 */     xSPrincipalI.setDatabaseId(l1);
/* 140 */     xSPrincipalI.setName(str);
/* 141 */     xSPrincipalI.setUUID(arrayOfByte);
/* 142 */     xSPrincipalI.setFlag(flag);
/* 143 */     return xSPrincipalI;
/*     */   }
/*     */ }


/* Location:              C:\Users\olatu\OneDrive\Documents\Calypso\syncbase\sync_base.jar!\BOOT-INF\classes\ojdbc.jar!\oracle\jdbc\driver\XSPrincipalI.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */