/*      */ package oracle.jdbc.driver;
/*      */ 
/*      */ import java.io.IOException;
/*      */ import java.security.AccessController;
/*      */ import java.security.PrivilegedAction;
/*      */ import java.sql.SQLException;
/*      */ import oracle.sql.CharacterSet;
/*      */ import oracle.sql.converter.CharacterConverter1Byte;
/*      */ import oracle.sql.converter.CharacterConverterJDBC;
/*      */ import oracle.sql.converter.JdbcCharacterConverters;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ final class DynamicByteArray
/*      */   extends ByteArray
/*      */ {
/*      */   static final int INITIAL_BLOCKS = 16;
/*      */   static final int GROWTH_FACTOR = 8;
/*      */   private final BlockSource source;
/*      */   private final long blockSize;
/*   66 */   private byte[][] blocks = new byte[16][];
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*   74 */   protected long length = 0L; private final int[] out_bytesRead; private static final char[] ISO_LATIN_1_TO_JAVA; private static final char[] WE8DEC_TO_JAVA; private static final char[] WE8MSWIN1252_TO_JAVA; private int globalBlockIndex; private int globalByteIndex; private int globalRemaining; private int globalBlockSize;
/*      */   private byte[] globalBytes;
/*      */   private static final char UTF16_REPLACEMENT_CHAR = '�';
/*      */   
/*      */   long length() {
/*   79 */     return this.length;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static DynamicByteArray createDynamicByteArray(BlockSource paramBlockSource) {
/*   91 */     return new DynamicByteArray(paramBlockSource);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void grow() {
/*  112 */     byte[][] arrayOfByte = new byte[this.blocks.length * 8][];
/*  113 */     System.arraycopy(this.blocks, 0, arrayOfByte, 0, this.blocks.length);
/*  114 */     this.blocks = arrayOfByte;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final int unmarshalCLR(T4CMAREngine paramT4CMAREngine) throws SQLException, IOException {
/*  131 */     return unmarshalCLR(paramT4CMAREngine, 2147483647);
/*      */   }
/*      */   
/*      */   private DynamicByteArray(BlockSource paramBlockSource)
/*      */   {
/*  136 */     this.out_bytesRead = new int[1];
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  594 */     this.globalBlockIndex = -1;
/*  595 */     this.globalByteIndex = -1;
/*  596 */     this.globalRemaining = -1;
/*  597 */     this.globalBlockSize = -1;
/*  598 */     this.globalBytes = null; assert paramBlockSource != null : "source is null"; this.source = paramBlockSource; this.blockSize = paramBlockSource.getBlockSize(); }
/*      */   final int unmarshalCLR(T4CMAREngine paramT4CMAREngine, int paramInt) throws SQLException, IOException { paramT4CMAREngine.unmarshalCLR(this, this.position, this.out_bytesRead, paramInt, 0); this.position += this.out_bytesRead[0]; this.length = Math.max(this.length, this.position + 1L); return this.out_bytesRead[0]; }
/*      */   final long unmarshalBuffer(T4CMAREngine paramT4CMAREngine, long paramLong, int paramInt) throws SQLException, IOException { assert paramLong >= 0L : "offset: " + paramLong; int i = (int)(paramLong / this.blockSize); int j = (int)(paramLong % this.blockSize); paramLong += paramInt; while (paramInt > 0) { for (; i >= this.blocks.length; grow()); if (this.blocks[i] == null) this.blocks[i] = this.source.get();  int k = Math.min(paramInt, (int)this.blockSize - j); paramT4CMAREngine.unmarshalNBytes(this.blocks[i], j, k); j = 0; i++; paramInt -= k; }  return paramLong; }
/*      */   final int unmarshalCLRforREFS(T4CMAREngine paramT4CMAREngine) throws SQLException, IOException { byte[] arrayOfByte = paramT4CMAREngine.unmarshalCLRforREFS(); if (arrayOfByte == null) return 0;  put(arrayOfByte); return arrayOfByte.length; }
/*  602 */   void copyLeft(long paramLong, int paramInt) { assert paramLong >= this.position && paramInt >= 0 && this.length >= this.position + paramInt : "this.position: " + this.position + " this.length: " + this.length + " srcOffset: " + paramLong + " length: " + paramInt; if (paramLong == this.position || paramInt == 0) { this.position += paramInt; return; }  assert paramLong > this.position && paramInt > 0; int i = (int)(this.position / this.blockSize); int j = (int)(this.position % this.blockSize); int k = (int)(paramLong / this.blockSize); int m = (int)(paramLong % this.blockSize); int n = (int)this.blockSize; int i1 = paramInt; while (i1 > 0) { int i2 = Math.min(i1, Math.min(n - m, n - j)); System.arraycopy(this.blocks[k], m, this.blocks[i], j, i2); m += i2; if (m == n) { k++; m = 0; }  j += i2; if (j == n) { i++; j = 0; }  i1 -= i2; }  this.position += paramInt; } void put(long paramLong, byte paramByte) { assert paramLong >= 0L : "index: " + paramLong; int i = (int)(paramLong / this.blockSize); int j = (int)(paramLong % this.blockSize); for (; i >= this.blocks.length; grow()); if (this.blocks[i] == null) this.blocks[i] = this.source.get();  this.blocks[i][j] = paramByte; this.length = Math.max(this.length, paramLong + 1L); } byte get(long paramLong) { assert paramLong >= 0L && paramLong < this.length; int i = (int)(paramLong / this.blockSize); int j = (int)(paramLong % this.blockSize); assert this.blocks.length >= i && this.blocks[i] != null : "invalid read--blocks.length: " + this.blocks.length + " blockIndex: " + i + ((i < this.blocks.length) ? (" blocks[" + i + "]: " + this.blocks[i]) : ""); return this.blocks[i][j]; } void put(long paramLong, byte[] paramArrayOfbyte, int paramInt1, int paramInt2) { assert paramArrayOfbyte != null : "src is null"; assert paramLong >= 0L && paramInt1 + paramInt2 <= paramArrayOfbyte.length : "offset: " + paramLong + " src.length: " + paramArrayOfbyte.length + " srcOffset: " + paramInt1 + " length: " + paramInt2; int i = (int)(paramLong / this.blockSize); int j = (int)(paramLong % this.blockSize); int k = (int)this.blockSize; int m = paramInt2; while (true) { for (; i >= this.blocks.length; grow()); if (this.blocks[i] == null) this.blocks[i] = this.source.get();  System.arraycopy(paramArrayOfbyte, paramInt1 + paramInt2 - m, this.blocks[i], j, Math.min(k - j, m)); i++; m -= k - j; j = 0; if (m <= 0) { this.length = Math.max(this.length, paramLong + paramInt2 + 1L); return; }  }  } void get(long paramLong, byte[] paramArrayOfbyte, int paramInt1, int paramInt2) { assert paramLong >= 0L && paramLong + paramInt2 <= this.length && paramInt1 >= 0 && paramInt1 + paramInt2 <= paramArrayOfbyte.length : " offset: " + paramLong + " this.length: " + this.length + " destOffset: " + paramInt1 + " length: " + paramInt2; int i = (int)(paramLong / this.blockSize); int j = (int)(paramLong % this.blockSize); int k = (int)this.blockSize; int m = paramInt2; do { System.arraycopy(this.blocks[i], j, paramArrayOfbyte, paramInt1 + paramInt2 - m, Math.min(k - j, m)); i++; m -= k - j; j = 0; } while (m > 0); } private final void setGlobals(long paramLong, int paramInt) { this.globalBlockIndex = (int)(paramLong / this.blockSize);
/*  603 */     this.globalByteIndex = (int)(paramLong % this.blockSize);
/*  604 */     this.globalRemaining = paramInt;
/*  605 */     this.globalBlockSize = (int)this.blockSize;
/*  606 */     this.globalBytes = (this.globalBlockIndex < this.blocks.length) ? this.blocks[this.globalBlockIndex++] : null; }
/*      */   void free() { for (byte b = 0; b < this.blocks.length; b++) { if (this.blocks[b] != null) { this.source.put(this.blocks[b]); this.blocks[b] = null; }  }  this.position = 0L; this.length = 0L; } long updateChecksum(long paramLong1, int paramInt, CRC64 paramCRC64, long paramLong2) { int i = (int)(paramLong1 / this.blockSize); int j = (int)(paramLong1 % this.blockSize); int k = paramInt; long l = paramLong2; while (k > 0) { int m = Math.min(k, (int)this.blockSize - j); l = CRC64.updateChecksum(l, this.blocks[i], j, m); k -= m; i++; j = 0; }  return l; } final char[] getChars(long paramLong, int paramInt, CharacterSet paramCharacterSet, int[] paramArrayOfint) throws SQLException { String str = getString(paramLong, paramInt, paramCharacterSet); char[] arrayOfChar = str.toCharArray(); paramArrayOfint[0] = arrayOfChar.length; return arrayOfChar; } final String getString(long paramLong, int paramInt, CharacterSet paramCharacterSet) throws SQLException { switch (paramCharacterSet.getOracleId()) { case 1: return getStringFromUS7ASCII(paramLong, paramInt);case 2: return getStringFrom1Byte(paramLong, paramInt, WE8DEC_TO_JAVA);case 31: return getStringFrom1Byte(paramLong, paramInt, ISO_LATIN_1_TO_JAVA);case 178: return getStringFrom1Byte(paramLong, paramInt, WE8MSWIN1252_TO_JAVA);case 2000: return getStringFromAL16UTF16(paramLong, paramInt);case 2002: return getStringFromAL16UTF16LE(paramLong, paramInt);case 871: return getStringFromUTF8(paramLong, paramInt);case 873: return getStringFromAL32UTF8(paramLong, paramInt); }  assert false : "charSet: " + paramCharacterSet.toString(); int i = (int)(paramLong / this.blockSize); int j = (int)(paramLong % this.blockSize); if (paramInt <= (int)this.blockSize - j) return paramCharacterSet.toString(this.blocks[i], j, paramInt);  byte[] arrayOfByte = get(paramLong, paramInt); return paramCharacterSet.toString(arrayOfByte, 0, arrayOfByte.length); } private final String getStringFromUS7ASCII(long paramLong, int paramInt) throws SQLException { assert paramLong >= 0L && paramInt >= 0 && this.length >= paramLong + paramInt : "this.length: " + this.length + " offset: " + paramLong + " lengthInBytes: " + paramInt; int i = (int)(paramLong / this.blockSize); int j = (int)(paramLong % this.blockSize); byte[] arrayOfByte = null; int k = paramInt; char[] arrayOfChar = new char[paramInt]; byte b = 0; while (k > 0) { arrayOfByte = this.blocks[i++]; int m = Math.min(j + k, arrayOfByte.length); k = k - m + j; for (; j < m; arrayOfChar[b++] = (char)arrayOfByte[j++]); j = 0; }  assert b == arrayOfChar.length : "charIndex: " + b + "\tchars.length: " + arrayOfChar.length; return new String(arrayOfChar); } private static final char[] intToChar(int[] paramArrayOfint) { char[] arrayOfChar = new char[paramArrayOfint.length]; for (byte b = 0; b < paramArrayOfint.length; ) { arrayOfChar[b] = (char)paramArrayOfint[b]; b++; }  return arrayOfChar; } static { final char[][] tmp = new char[3][]; AccessController.doPrivileged(new PrivilegedAction() {
/*      */           public Object run() { JdbcCharacterConverters jdbcCharacterConverters = CharacterConverterJDBC.getInstance(31); tmp[0] = DynamicByteArray.intToChar(((CharacterConverter1Byte)jdbcCharacterConverters).m_ucsChar); jdbcCharacterConverters = CharacterConverterJDBC.getInstance(2); tmp[1] = DynamicByteArray.intToChar(((CharacterConverter1Byte)jdbcCharacterConverters).m_ucsChar); jdbcCharacterConverters = CharacterConverterJDBC.getInstance(178); tmp[2] = DynamicByteArray.intToChar(((CharacterConverter1Byte)jdbcCharacterConverters).m_ucsChar); return null; }
/*  609 */         }); ISO_LATIN_1_TO_JAVA = arrayOfChar[0]; WE8DEC_TO_JAVA = arrayOfChar[1]; WE8MSWIN1252_TO_JAVA = arrayOfChar[2]; } private final String getStringFrom1Byte(long paramLong, int paramInt, char[] paramArrayOfchar) throws SQLException { assert paramLong >= 0L && paramInt >= 0 && this.length >= paramLong + paramInt : "this.length: " + this.length + " offset: " + paramLong + " lengthInBytes: " + paramInt; int i = (int)(paramLong / this.blockSize); int j = (int)(paramLong % this.blockSize); byte[] arrayOfByte = null; int k = paramInt; char[] arrayOfChar = new char[paramInt]; byte b = 0; while (k > 0) { arrayOfByte = this.blocks[i++]; int m = Math.min(j + k, arrayOfByte.length); k = k - m + j; for (; j < m; arrayOfChar[b++] = paramArrayOfchar[arrayOfByte[j++] & 0xFF]); j = 0; }  assert b == arrayOfChar.length : "charIndex: " + b + "\tchars.length: " + arrayOfChar.length; return new String(arrayOfChar); } private final byte next() { assert this.globalRemaining > 0 : "next overrun in DBA";
/*  610 */     byte b = this.globalBytes[this.globalByteIndex++];
/*  611 */     this.globalRemaining--;
/*  612 */     if (this.globalByteIndex >= this.globalBlockSize) {
/*  613 */       this.globalBytes = (this.globalBlockIndex < this.blocks.length) ? this.blocks[this.globalBlockIndex++] : null;
/*  614 */       this.globalByteIndex = 0;
/*      */     } 
/*      */     
/*  617 */     return b; }
/*      */   
/*      */   private final byte peek() {
/*  620 */     assert this.globalRemaining > 0 : "peek overrun in DBA";
/*  621 */     return this.globalBytes[this.globalByteIndex];
/*      */   }
/*      */   private final void back() {
/*  624 */     if (this.globalByteIndex == 0) {
/*  625 */       this.globalByteIndex = this.globalBlockSize;
/*  626 */       this.globalBlockIndex--;
/*  627 */       this.globalBytes = this.blocks[this.globalBlockIndex];
/*      */     } 
/*  629 */     this.globalByteIndex--;
/*  630 */     this.globalRemaining++;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final String getStringFromAL16UTF16(long paramLong, int paramInt) throws SQLException {
/*  642 */     assert paramLong >= 0L && paramInt >= 0 && this.length >= paramLong + paramInt : "this.length: " + this.length + " offset: " + paramLong + " lengthInBytes: " + paramInt;
/*  643 */     assert paramInt % 2 == 0 : "lengthInBytes: " + paramInt;
/*      */     
/*  645 */     setGlobals(paramLong, paramInt);
/*  646 */     char[] arrayOfChar = new char[paramInt / 2];
/*  647 */     byte b = 0;
/*      */     
/*  649 */     while (this.globalRemaining > 0) {
/*  650 */       int i = next() << 8;
/*  651 */       arrayOfChar[b++] = (char)(i | next() & 0xFF);
/*      */     } 
/*      */     
/*  654 */     assert b == arrayOfChar.length : "charIndex: " + b + "\tchars.length: " + arrayOfChar.length;
/*  655 */     return new String(arrayOfChar);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final String getStringFromAL16UTF16LE(long paramLong, int paramInt) throws SQLException {
/*  666 */     assert paramLong >= 0L && paramInt >= 0 && this.length >= paramLong + paramInt : "this.length: " + this.length + " offset: " + paramLong + " lengthInBytes: " + paramInt;
/*  667 */     assert paramInt % 2 == 0 : "lengthInBytes: " + paramInt;
/*      */     
/*  669 */     setGlobals(paramLong, paramInt);
/*  670 */     char[] arrayOfChar = new char[paramInt / 2];
/*  671 */     byte b = 0;
/*      */     
/*  673 */     while (this.globalRemaining > 0) {
/*  674 */       byte b1 = next();
/*  675 */       char c1 = (char)(next() << 8 | b1 & 0xFF);
/*  676 */       if (!isHiSurrogate(c1)) {
/*  677 */         arrayOfChar[b++] = c1;
/*      */         
/*      */         continue;
/*      */       } 
/*  681 */       if (this.globalRemaining == 0) {
/*  682 */         arrayOfChar[b++] = '�';
/*      */         
/*      */         break;
/*      */       } 
/*  686 */       b1 = next();
/*  687 */       char c2 = (char)(next() << 8 | b1 & 0xFF);
/*  688 */       if (isLoSurrogate(c2)) { arrayOfChar[b++] = c1; }
/*  689 */       else { arrayOfChar[b++] = '�'; }
/*  690 */        arrayOfChar[b++] = c2;
/*      */     } 
/*      */     
/*  693 */     assert b == arrayOfChar.length : "charIndex: " + b + "\tchars.length: " + arrayOfChar.length;
/*  694 */     return new String(arrayOfChar);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final String getStringFromUTF8(long paramLong, int paramInt) throws SQLException {
/*  705 */     assert paramLong >= 0L && paramInt >= 0 && this.length >= paramLong + paramInt : "this.length: " + this.length + " offset: " + paramLong + " lengthInBytes: " + paramInt;
/*      */     
/*  707 */     setGlobals(paramLong, paramInt);
/*  708 */     int i = (int)((paramLong + paramInt - 1L) / this.blockSize) + 1;
/*  709 */     int j = (int)((paramLong + paramInt - 1L) % this.blockSize) + 1;
/*  710 */     char[] arrayOfChar = new char[paramInt];
/*  711 */     byte b = 0;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  720 */     while (this.globalRemaining > 0) {
/*  721 */       byte b1 = next();
/*      */       
/*  723 */       if (b1 >= 0) {
/*      */ 
/*      */         
/*  726 */         arrayOfChar[b++] = (char)b1;
/*      */ 
/*      */         
/*  729 */         byte b3 = (this.globalBlockIndex == i) ? j : ((this.globalBlockIndex < i) ? (int)this.blockSize : 0);
/*      */ 
/*      */ 
/*      */         
/*  733 */         int m = this.globalByteIndex;
/*  734 */         while (m < b3) {
/*  735 */           b1 = this.globalBytes[m];
/*  736 */           if (b1 < 0)
/*      */             break; 
/*  738 */           arrayOfChar[b++] = (char)b1;
/*  739 */           m++;
/*      */         } 
/*  741 */         this.globalRemaining -= m - this.globalByteIndex;
/*  742 */         this.globalByteIndex = m;
/*  743 */         if (this.globalByteIndex >= this.globalBlockSize) {
/*  744 */           this.globalByteIndex = 0;
/*  745 */           this.globalBytes = (this.globalBlockIndex < this.blocks.length) ? this.blocks[this.globalBlockIndex++] : null;
/*      */         } 
/*      */         
/*      */         continue;
/*      */       } 
/*  750 */       int k = b1 & 0xF0;
/*  751 */       byte b2 = b1;
/*  752 */       b2 = (byte)(b2 << 2);
/*  753 */       if (b2 >= 0) {
/*      */         
/*  755 */         if (this.globalRemaining < 1) {
/*      */ 
/*      */           
/*  758 */           arrayOfChar[b++] = '�';
/*      */           
/*      */           continue;
/*      */         } 
/*      */         
/*  763 */         char c = conv2ByteUTFtoUTF16(b1, next());
/*  764 */         arrayOfChar[b++] = c;
/*      */         
/*      */         continue;
/*      */       } 
/*      */       
/*  769 */       b2 = (byte)(b2 << 1);
/*  770 */       if (b2 >= 0) {
/*      */         
/*  772 */         if (this.globalRemaining < 2) {
/*      */ 
/*      */           
/*  775 */           arrayOfChar[b++] = '�';
/*      */           
/*      */           continue;
/*      */         } 
/*      */         
/*  780 */         byte b3 = next();
/*  781 */         byte b4 = next();
/*  782 */         char c = conv3ByteUTFtoUTF16(b1, b3, b4);
/*      */ 
/*      */         
/*  785 */         if (isHiSurrogate(c) && this.globalRemaining > 0) {
/*  786 */           b1 = peek();
/*  787 */           if ((byte)(b1 & 0xF0) != -32) {
/*      */ 
/*      */ 
/*      */             
/*  791 */             arrayOfChar[b++] = '�';
/*      */             continue;
/*      */           } 
/*  794 */           next();
/*      */           
/*  796 */           if (this.globalRemaining < 2) {
/*      */ 
/*      */             
/*  799 */             arrayOfChar[b++] = '�';
/*      */             
/*      */             continue;
/*      */           } 
/*      */           
/*  804 */           b3 = next();
/*  805 */           b4 = next();
/*  806 */           char c1 = conv3ByteUTFtoUTF16(b1, b3, b4);
/*      */           
/*  808 */           if (isLoSurrogate(c1)) {
/*      */             
/*  810 */             arrayOfChar[b++] = c;
/*      */           
/*      */           }
/*      */           else {
/*      */             
/*  815 */             arrayOfChar[b++] = '�';
/*      */           } 
/*      */           
/*  818 */           arrayOfChar[b++] = c1;
/*      */           
/*      */           continue;
/*      */         } 
/*  822 */         arrayOfChar[b++] = c;
/*      */ 
/*      */         
/*      */         continue;
/*      */       } 
/*      */ 
/*      */       
/*  829 */       arrayOfChar[b++] = '�';
/*      */     } 
/*      */ 
/*      */     
/*  833 */     return new String(arrayOfChar, 0, b);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final String getStringFromAL32UTF8(long paramLong, int paramInt) throws SQLException {
/*  844 */     assert paramLong >= 0L && paramInt >= 0 && this.length >= paramLong + paramInt : "this.length: " + this.length + " offset: " + paramLong + " lengthInBytes: " + paramInt;
/*      */     
/*  846 */     setGlobals(paramLong, paramInt);
/*  847 */     int i = (int)((paramLong + paramInt - 1L) / this.blockSize) + 1;
/*  848 */     int j = (int)((paramLong + paramInt - 1L) % this.blockSize) + 1;
/*  849 */     char[] arrayOfChar = new char[paramInt];
/*  850 */     int k = 0;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  856 */     while (this.globalRemaining > 0) {
/*  857 */       byte b = next();
/*      */       
/*  859 */       if (b >= 0) {
/*      */         
/*  861 */         arrayOfChar[k++] = (char)b;
/*      */ 
/*      */         
/*  864 */         byte b2 = (this.globalBlockIndex == i) ? j : ((this.globalBlockIndex < i) ? (int)this.blockSize : 0);
/*      */ 
/*      */ 
/*      */         
/*  868 */         int m = this.globalByteIndex;
/*  869 */         while (m < b2) {
/*  870 */           b = this.globalBytes[m];
/*  871 */           if (b < 0)
/*      */             break; 
/*  873 */           arrayOfChar[k++] = (char)b;
/*  874 */           m++;
/*      */         } 
/*  876 */         this.globalRemaining -= m - this.globalByteIndex;
/*  877 */         this.globalByteIndex = m;
/*  878 */         if (this.globalByteIndex >= this.globalBlockSize) {
/*  879 */           this.globalByteIndex = 0;
/*  880 */           this.globalBytes = (this.globalBlockIndex < this.blocks.length) ? this.blocks[this.globalBlockIndex++] : null;
/*      */         } 
/*      */         
/*      */         continue;
/*      */       } 
/*  885 */       byte b1 = b;
/*  886 */       b1 = (byte)(b1 << 2);
/*  887 */       if (b1 >= 0) {
/*      */         
/*  889 */         if (this.globalRemaining < 1) {
/*      */ 
/*      */           
/*  892 */           arrayOfChar[k++] = '�';
/*      */           
/*      */           continue;
/*      */         } 
/*      */         
/*  897 */         arrayOfChar[k++] = conv2ByteUTFtoUTF16(b, next());
/*      */         
/*      */         continue;
/*      */       } 
/*      */       
/*  902 */       b1 = (byte)(b1 << 1);
/*  903 */       if (b1 >= 0) {
/*      */         
/*  905 */         if (this.globalRemaining < 2) {
/*      */ 
/*      */           
/*  908 */           arrayOfChar[k++] = '�';
/*      */           
/*      */           continue;
/*      */         } 
/*      */         
/*  913 */         arrayOfChar[k++] = conv3ByteAL32UTF8toUTF16(b, next(), next());
/*      */         
/*      */         continue;
/*      */       } 
/*  917 */       b1 = (byte)(b1 << 1);
/*  918 */       if (b1 >= 0) {
/*      */         
/*  920 */         if (this.globalRemaining < 3) {
/*      */ 
/*      */           
/*  923 */           arrayOfChar[k++] = '�';
/*      */           
/*      */           continue;
/*      */         } 
/*  927 */         k = conv4ByteAL32UTF8toUTF16(b, next(), next(), next(), arrayOfChar, k);
/*      */         
/*      */         continue;
/*      */       } 
/*  931 */       arrayOfChar[k++] = '�';
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  937 */     return new String(arrayOfChar, 0, k);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final boolean isHiSurrogate(char paramChar) {
/*  953 */     return ((char)(paramChar & 0xFC00) == '?');
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final boolean isLoSurrogate(char paramChar) {
/*  968 */     return ((char)(paramChar & 0xFC00) == '?');
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final boolean check80toBF(byte paramByte) {
/*  982 */     return ((paramByte & 0xFFFFFFC0) == -128);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final boolean check80to8F(byte paramByte) {
/*  995 */     return ((paramByte & 0xFFFFFFF0) == -128);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final boolean check80to9F(byte paramByte) {
/* 1008 */     return ((paramByte & 0xFFFFFFE0) == -128);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final boolean checkA0toBF(byte paramByte) {
/* 1021 */     return ((paramByte & 0xFFFFFFE0) == -96);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final boolean check90toBF(byte paramByte) {
/* 1034 */     return ((paramByte & 0xFFFFFFC0) == -128 && (paramByte & 0x30) != 0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final char conv2ByteUTFtoUTF16(byte paramByte1, byte paramByte2) {
/* 1050 */     if (paramByte1 < -62 || paramByte1 > -33 || !check80toBF(paramByte2)) {
/*      */       
/* 1052 */       back();
/* 1053 */       return '�';
/*      */     } 
/*      */     
/* 1056 */     return (char)((paramByte1 & 0x1F) << 6 | paramByte2 & 0x3F);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final char conv3ByteUTFtoUTF16(byte paramByte1, byte paramByte2, byte paramByte3) {
/* 1076 */     if ((paramByte1 != -32 || !checkA0toBF(paramByte2) || !check80toBF(paramByte3)) && (paramByte1 < -31 || paramByte1 > -17 || !check80toBF(paramByte2) || !check80toBF(paramByte3))) {
/*      */ 
/*      */ 
/*      */       
/* 1080 */       back();
/* 1081 */       back();
/* 1082 */       return '�';
/*      */     } 
/*      */     
/* 1085 */     return (char)((paramByte1 & 0xF) << 12 | (paramByte2 & 0x3F) << 6 | paramByte3 & 0x3F);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final char conv3ByteAL32UTF8toUTF16(byte paramByte1, byte paramByte2, byte paramByte3) {
/* 1109 */     if ((paramByte1 != -32 || !checkA0toBF(paramByte2) || !check80toBF(paramByte3)) && (paramByte1 < -31 || paramByte1 > -20 || !check80toBF(paramByte2) || !check80toBF(paramByte3)) && (paramByte1 != -19 || !check80to9F(paramByte2) || !check80toBF(paramByte3)) && (paramByte1 < -18 || paramByte1 > -17 || !check80toBF(paramByte2) || !check80toBF(paramByte3))) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1116 */       back();
/* 1117 */       back();
/* 1118 */       return '�';
/*      */     } 
/*      */ 
/*      */     
/* 1122 */     return (char)((paramByte1 & 0xF) << 12 | (paramByte2 & 0x3F) << 6 | paramByte3 & 0x3F);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final int conv4ByteAL32UTF8toUTF16(byte paramByte1, byte paramByte2, byte paramByte3, byte paramByte4, char[] paramArrayOfchar, int paramInt) {
/* 1141 */     boolean bool = false;
/*      */     
/* 1143 */     if ((paramByte1 != -16 || !check90toBF(paramByte2) || !check80toBF(paramByte3) || !check80toBF(paramByte4)) && (paramByte1 < -15 || paramByte1 > -13 || !check80toBF(paramByte2) || !check80toBF(paramByte3) || !check80toBF(paramByte4)) && (paramByte1 != -12 || !check80to8F(paramByte2) || !check80toBF(paramByte3) || !check80toBF(paramByte4))) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1148 */       back();
/* 1149 */       back();
/* 1150 */       back();
/* 1151 */       paramArrayOfchar[paramInt++] = '�';
/*      */     }
/*      */     else {
/*      */       
/* 1155 */       paramArrayOfchar[paramInt++] = (char)((((paramByte1 & 0x7) << 2 | paramByte2 >>> 4 & 0x3) - 1 & 0xF) << 6 | (paramByte2 & 0xF) << 2 | paramByte3 >>> 4 & 0x3 | 0xD800);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1161 */       paramArrayOfchar[paramInt++] = (char)((paramByte3 & 0xF) << 6 | paramByte4 & 0x3F | 0xDC00);
/*      */     } 
/* 1163 */     return paramInt;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   byte[] getBlockBasic(long paramLong, int[] paramArrayOfint) {
/* 1179 */     int i = (int)(paramLong / this.blockSize);
/* 1180 */     paramArrayOfint[0] = (int)(paramLong % this.blockSize);
/* 1181 */     if (i >= this.blocks.length) return null; 
/* 1182 */     return this.blocks[i];
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static String escape(String paramString) {
/* 1189 */     StringBuilder stringBuilder = new StringBuilder(paramString.length() * 6);
/* 1190 */     for (char c : paramString.toCharArray()) {
/* 1191 */       stringBuilder.append("\\u");
/* 1192 */       byte b = (byte)(c >> 8);
/* 1193 */       String str = "00" + Integer.toHexString(b & 0xFF);
/* 1194 */       stringBuilder.append(str, str.length() - 2, str.length());
/* 1195 */       str = "00" + Integer.toHexString((byte)c & 0xFF);
/* 1196 */       stringBuilder.append(str, str.length() - 2, str.length());
/*      */     } 
/* 1198 */     return stringBuilder.toString();
/*      */   }
/*      */ 
/*      */   
/* 1202 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*      */   public static final String BUILD_DATE = "Thu_Apr_04_15:09:24_PDT_2013";
/*      */   public static final boolean TRACE = false;
/*      */ }


/* Location:              C:\Users\olatu\OneDrive\Documents\Calypso\syncbase\sync_base.jar!\BOOT-INF\classes\ojdbc.jar!\oracle\jdbc\driver\DynamicByteArray.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */