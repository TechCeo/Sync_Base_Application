/*     */ package oracle.jdbc.driver;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.sql.SQLException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class T4CTTIkpdnrdeq
/*     */   extends T4CTTIfun
/*     */ {
/*     */   static final short COMMIT_KPNAQDEQ = 1;
/*     */   static final short ROLLBACK_KPNAQDEQ = 2;
/*     */   long registrationId;
/*  40 */   byte[] clientIdBytes = null;
/*  41 */   byte[] messageId = null;
/*     */   short opCode;
/*     */   T4CMAREngine mar;
/*     */   T4CConnection connection;
/*     */   String queue;
/*  46 */   byte[] queueNameBytes = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  52 */   int noOfAck = 1;
/*     */   
/*     */   T4CTTIkpdnrdeq(T4CConnection paramT4CConnection) {
/*  55 */     super(paramT4CConnection, (byte)3);
/*  56 */     this.mar = paramT4CConnection.mare;
/*  57 */     this.connection = paramT4CConnection;
/*  58 */     setFunCode((short)186);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void doOAQEMNDEQ(String paramString1, short paramShort, byte[] paramArrayOfbyte, long paramLong, String paramString2) throws SQLException, IOException {
/*  66 */     assert paramString1 != null && paramString2 != null : "cliendId is " + paramString1 + ", queue is " + paramString2;
/*  67 */     this.clientIdBytes = this.mar.conv.StringToCharBytes(paramString1);
/*  68 */     this.messageId = paramArrayOfbyte;
/*  69 */     this.opCode = paramShort;
/*  70 */     this.registrationId = paramLong;
/*  71 */     this.queueNameBytes = this.mar.conv.StringToCharBytes(paramString2);
/*  72 */     doRPC();
/*     */   }
/*     */   void marshal() throws IOException {
/*  75 */     if (this.clientIdBytes != null && this.clientIdBytes.length != 0) {
/*  76 */       this.mar.marshalPTR();
/*  77 */       this.mar.marshalSWORD(this.clientIdBytes.length);
/*     */     } else {
/*     */       
/*  80 */       this.mar.marshalNULLPTR();
/*  81 */       this.mar.marshalSWORD(0);
/*     */     } 
/*  83 */     this.mar.marshalUB1(this.opCode);
/*     */     
/*  85 */     if (this.noOfAck > 0) {
/*  86 */       this.mar.marshalPTR();
/*  87 */       this.mar.marshalUB4(this.noOfAck);
/*     */     } else {
/*     */       
/*  90 */       this.mar.marshalNULLPTR();
/*  91 */       this.mar.marshalUB4(0L);
/*     */     } 
/*     */ 
/*     */     
/*  95 */     if (this.clientIdBytes != null && this.clientIdBytes.length != 0) {
/*  96 */       this.mar.marshalCHR(this.clientIdBytes);
/*     */     }
/*     */     
/*  99 */     for (byte b = 0; b < this.noOfAck; b++) {
/*     */       
/* 101 */       T4CTTIkpdnrack t4CTTIkpdnrack = new T4CTTIkpdnrack(this.connection);
/* 102 */       t4CTTIkpdnrack.send(this.queueNameBytes, this.registrationId, this.messageId);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\olatu\OneDrive\Documents\Calypso\syncbase\sync_base.jar!\BOOT-INF\classes\ojdbc.jar!\oracle\jdbc\driver\T4CTTIkpdnrdeq.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */