/*    */ package oracle.jdbc.driver;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class ByteArrayKey
/*    */ {
/*    */   private byte[] theBytes;
/* 22 */   private int cachedHashCode = -1;
/*    */ 
/*    */   
/*    */   public ByteArrayKey(byte[] paramArrayOfbyte) {
/* 26 */     this.theBytes = paramArrayOfbyte;
/* 27 */     for (byte b : this.theBytes) {
/* 28 */       this.cachedHashCode = this.cachedHashCode << 1 & ((this.cachedHashCode < 0) ? 1 : 0) ^ b;
/*    */     }
/*    */   }
/*    */   
/*    */   public boolean equals(Object paramObject) {
/* 33 */     if (paramObject == this) {
/* 34 */       return true;
/*    */     }
/* 36 */     if (!(paramObject instanceof ByteArrayKey))
/*    */     {
/*    */       
/* 39 */       return false;
/*    */     }
/*    */     
/* 42 */     byte[] arrayOfByte = ((ByteArrayKey)paramObject).theBytes;
/*    */     
/* 44 */     if (this.theBytes.length != arrayOfByte.length) {
/* 45 */       return false;
/*    */     }
/* 47 */     for (byte b = 0; b < this.theBytes.length; b++) {
/* 48 */       if (this.theBytes[b] != arrayOfByte[b])
/* 49 */         return false; 
/*    */     } 
/* 51 */     return true;
/*    */   }
/*    */ 
/*    */   
/*    */   public int hashCode() {
/* 56 */     return this.cachedHashCode;
/*    */   }
/*    */ 
/*    */   
/* 60 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*    */   public static final String BUILD_DATE = "Thu_Apr_04_15:09:24_PDT_2013";
/*    */   public static final boolean TRACE = false;
/*    */ }


/* Location:              C:\Users\olatu\OneDrive\Documents\Calypso\syncbase\sync_base.jar!\BOOT-INF\classes\ojdbc.jar!\oracle\jdbc\driver\ByteArrayKey.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */