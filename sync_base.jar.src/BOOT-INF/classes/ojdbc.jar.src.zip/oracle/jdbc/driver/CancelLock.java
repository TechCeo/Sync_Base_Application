/*    */ package oracle.jdbc.driver;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class CancelLock
/*    */ {
/*    */   private enum State
/*    */   {
/* 45 */     IDLE, EXECUTING, CANCELING;
/*    */   }
/* 47 */   private State state = State.IDLE;
/*    */   
/*    */   boolean isIdle() {
/* 50 */     return (this.state == State.IDLE);
/*    */   }
/*    */ 
/*    */   
/*    */   synchronized void enterExecuting() {
/* 55 */     assert this.state == State.IDLE;
/* 56 */     this.state = State.EXECUTING;
/*    */   }
/*    */ 
/*    */   
/*    */   synchronized void exitExecuting() {
/* 61 */     while (this.state != State.EXECUTING) {
/*    */       
/* 63 */       assert this.state == State.CANCELING;
/*    */       try {
/* 65 */         wait();
/* 66 */       } catch (InterruptedException interruptedException) {}
/*    */     } 
/* 68 */     this.state = State.IDLE;
/*    */   }
/*    */ 
/*    */   
/*    */   synchronized boolean enterCanceling() {
/* 73 */     if (this.state == State.EXECUTING) {
/*    */       
/* 75 */       this.state = State.CANCELING;
/* 76 */       return true;
/*    */     } 
/*    */     
/* 79 */     return false;
/*    */   }
/*    */ 
/*    */   
/*    */   synchronized void exitCanceling() {
/* 84 */     assert this.state == State.CANCELING;
/* 85 */     this.state = State.EXECUTING;
/* 86 */     notify();
/*    */   }
/*    */ }


/* Location:              C:\Users\olatu\OneDrive\Documents\Calypso\syncbase\sync_base.jar!\BOOT-INF\classes\ojdbc.jar!\oracle\jdbc\driver\CancelLock.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */