/*    */ package oracle.jdbc.driver;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.sql.SQLException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class T4CTTIidc
/*    */   extends T4CTTIMsg
/*    */ {
/*    */   T4CTTIkscn kpdqidcscn;
/*    */   T4CTTIqcinv[] kpdqidccinv;
/*    */   T4CTTIqcinv[] kpdqidcusr;
/*    */   long kpdqidcflg;
/*    */   
/*    */   T4CTTIidc(T4CConnection paramT4CConnection) {
/* 61 */     super(paramT4CConnection, (byte)0);
/*    */   }
/*    */   
/*    */   void unmarshal() throws SQLException, IOException {
/* 65 */     this.kpdqidcscn = new T4CTTIkscn(this.connection);
/* 66 */     this.kpdqidcscn.unmarshal();
/* 67 */     int i = this.meg.unmarshalSWORD();
/* 68 */     byte b = (byte)this.meg.unmarshalUB1();
/* 69 */     if (i > 0) {
/*    */       
/* 71 */       this.kpdqidccinv = new T4CTTIqcinv[i];
/* 72 */       for (byte b1 = 0; b1 < i; b1++) {
/*    */         
/* 74 */         this.kpdqidccinv[b1] = new T4CTTIqcinv(this.connection);
/* 75 */         this.kpdqidccinv[b1].unmarshal();
/*    */       } 
/*    */     } else {
/*    */       
/* 79 */       this.kpdqidccinv = null;
/*    */     } 
/* 81 */     int j = this.meg.unmarshalSWORD();
/* 82 */     if (j > 0) {
/*    */       
/* 84 */       this.kpdqidcusr = new T4CTTIqcinv[j];
/* 85 */       for (byte b1 = 0; b1 < j; b1++) {
/*    */         
/* 87 */         this.kpdqidcusr[b1] = new T4CTTIqcinv(this.connection);
/* 88 */         this.kpdqidcusr[b1].unmarshal();
/*    */       } 
/*    */     } else {
/*    */       
/* 92 */       this.kpdqidcusr = null;
/* 93 */     }  this.kpdqidcflg = this.meg.unmarshalUB4();
/*    */   }
/*    */ }


/* Location:              C:\Users\olatu\OneDrive\Documents\Calypso\syncbase\sync_base.jar!\BOOT-INF\classes\ojdbc.jar!\oracle\jdbc\driver\T4CTTIidc.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */