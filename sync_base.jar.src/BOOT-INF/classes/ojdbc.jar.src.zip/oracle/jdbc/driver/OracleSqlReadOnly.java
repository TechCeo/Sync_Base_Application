/*      */ package oracle.jdbc.driver;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ class OracleSqlReadOnly
/*      */ {
/*      */   private static final int BASE = 0;
/*      */   private static final int BASE_1 = 1;
/*      */   private static final int BASE_2 = 2;
/*      */   private static final int B_STRING = 3;
/*      */   private static final int B_NAME = 4;
/*      */   private static final int B_C_COMMENT = 5;
/*      */   private static final int B_C_COMMENT_1 = 6;
/*      */   private static final int B_COMMENT = 7;
/*      */   private static final int PARAMETER = 8;
/*      */   private static final int TOKEN = 9;
/*      */   private static final int B_EGIN = 10;
/*      */   private static final int BE_GIN = 11;
/*      */   private static final int BEG_IN = 12;
/*      */   private static final int BEGI_N = 13;
/*      */   private static final int BEGIN_ = 14;
/*      */   private static final int C_ALL = 15;
/*      */   private static final int CA_LL = 16;
/*      */   private static final int CAL_L = 17;
/*      */   private static final int CALL_ = 18;
/*      */   private static final int D_Eetc = 19;
/*      */   private static final int DE_etc = 20;
/*      */   private static final int DEC_LARE = 21;
/*      */   private static final int DECL_ARE = 22;
/*      */   private static final int DECLA_RE = 23;
/*      */   private static final int DECLAR_E = 24;
/*      */   private static final int DECLARE_ = 25;
/*      */   private static final int DEL_ETE = 26;
/*      */   private static final int DELE_TE = 27;
/*      */   private static final int DELET_E = 28;
/*      */   private static final int DELETE_ = 29;
/*      */   private static final int I_NSERT = 30;
/*      */   private static final int IN_SERT = 31;
/*      */   private static final int INS_ERT = 32;
/*      */   private static final int INSE_RT = 33;
/*      */   private static final int INSER_T = 34;
/*      */   private static final int INSERT_ = 35;
/*      */   private static final int S_ELECT = 36;
/*      */   private static final int SE_LECT = 37;
/*      */   private static final int SEL_ECT = 38;
/*      */   private static final int SELE_CT = 39;
/*      */   private static final int SELEC_T = 40;
/*      */   private static final int SELECT_ = 41;
/*      */   private static final int U_PDATE = 42;
/*      */   private static final int UP_DATE = 43;
/*      */   private static final int UPD_ATE = 44;
/*      */   private static final int UPDA_TE = 45;
/*      */   private static final int UPDAT_E = 46;
/*      */   private static final int UPDATE_ = 47;
/*      */   private static final int M_ERGE = 48;
/*      */   private static final int ME_RGE = 49;
/*      */   private static final int MER_GE = 50;
/*      */   private static final int MERG_E = 51;
/*      */   private static final int MERGE_ = 52;
/*      */   private static final int W_ITH = 53;
/*      */   private static final int WI_TH = 54;
/*      */   private static final int WIT_H = 55;
/*      */   private static final int WITH_ = 56;
/*      */   private static final int KNOW_KIND = 57;
/*      */   private static final int KNOW_KIND_1 = 58;
/*      */   private static final int KNOW_KIND_2 = 59;
/*      */   private static final int K_STRING = 60;
/*      */   private static final int K_NAME = 61;
/*      */   private static final int K_C_COMMENT = 62;
/*      */   private static final int K_C_COMMENT_1 = 63;
/*      */   private static final int K_COMMENT = 64;
/*      */   private static final int K_PARAMETER = 65;
/*      */   private static final int TOKEN_KK = 66;
/*      */   private static final int W_HERE = 67;
/*      */   private static final int WH_ERE = 68;
/*      */   private static final int WHE_RE = 69;
/*      */   private static final int WHER_E = 70;
/*      */   private static final int WHERE_ = 71;
/*      */   private static final int O_RDER_BY = 72;
/*      */   private static final int OR_DER_BY = 73;
/*      */   private static final int ORD_ER_BY = 74;
/*      */   private static final int ORDE_R_BY = 75;
/*      */   private static final int ORDER__BY = 76;
/*      */   private static final int ORDER_xBY = 77;
/*      */   private static final int ORDER_B_Y = 78;
/*      */   private static final int ORDER_BY_ = 79;
/*      */   private static final int ORDER_xBY_CC_1 = 80;
/*      */   private static final int ORDER_xBY_CC_2 = 81;
/*      */   private static final int ORDER_xBY_CC_3 = 82;
/*      */   private static final int ORDER_xBY_C_1 = 83;
/*      */   private static final int ORDER_xBY_C_2 = 84;
/*      */   private static final int F_OR_UPDATE = 85;
/*      */   private static final int FO_R_UPDATE = 86;
/*      */   private static final int FOR__UPDATE = 87;
/*      */   private static final int FOR_xUPDATE = 88;
/*      */   private static final int FOR_U_PDATE = 89;
/*      */   private static final int FOR_UP_DATE = 90;
/*      */   private static final int FOR_UPD_ATE = 91;
/*      */   private static final int FOR_UPDA_TE = 92;
/*      */   private static final int FOR_UPDAT_E = 93;
/*      */   private static final int FOR_UPDATE_ = 94;
/*      */   private static final int FOR_xUPDATE_CC_1 = 95;
/*      */   private static final int FOR_xUPDATE_CC_2 = 96;
/*      */   private static final int FOR_xUPDATE_CC_3 = 97;
/*      */   private static final int FOR_xUPDATE_C_1 = 98;
/*      */   private static final int FOR_xUPDATE_C_2 = 99;
/*      */   private static final int B_N_tick = 100;
/*      */   private static final int B_NCHAR = 101;
/*      */   private static final int K_N_tick = 102;
/*      */   private static final int K_NCHAR = 103;
/*      */   private static final int K_NCHAR_tick = 104;
/*      */   private static final int B_Q_tickDelimiterCharDelimiterTick = 105;
/*      */   private static final int B_QTick_delimiterCharDelimiterTick = 106;
/*      */   private static final int B_QTickDelimiter_charDelimiterTick = 107;
/*      */   private static final int B_QTickDelimiterChar_delimiterTick = 108;
/*      */   private static final int B_QTickDelimiterCharDelimiter_tick = 109;
/*      */   private static final int K_Q_tickDelimiterCharDelimiterTick = 110;
/*      */   private static final int K_QTick_delimiterCharDelimiterTick = 111;
/*      */   private static final int K_QTickDelimiter_charDelimiterTick = 112;
/*      */   private static final int K_QTickDelimiterChar_delimiterTick = 113;
/*      */   private static final int K_QTickDelimiterCharDelimiter_tick = 114;
/*      */   private static final int K_EscEtc = 115;
/*      */   private static final int K_EscQuestion = 116;
/*      */   private static final int K_EscC_ALL = 117;
/*      */   private static final int K_EscCA_LL = 118;
/*      */   private static final int K_EscCAL_L = 119;
/*      */   private static final int K_EscCALL_ = 120;
/*      */   private static final int K_EscT = 121;
/*      */   private static final int K_EscTS_ = 122;
/*      */   private static final int K_EscD_ = 123;
/*      */   private static final int K_EscE_SCAPE = 124;
/*      */   private static final int K_EscES_CAPE = 125;
/*      */   private static final int K_EscESC_APE = 126;
/*      */   private static final int K_EscESCA_PE = 127;
/*      */   private static final int K_EscESCAP_E = 128;
/*      */   private static final int K_EscESCAPE_ = 129;
/*      */   private static final int K_EscF_N = 130;
/*      */   private static final int K_EscFN_ = 131;
/*      */   private static final int K_EscL_IMIT = 132;
/*      */   private static final int K_EscLI_MIT = 133;
/*      */   private static final int K_EscLIM_IT = 134;
/*      */   private static final int K_EscLIMI_T = 135;
/*      */   private static final int K_EscLIMIT_ = 136;
/*      */   private static final int K_EscO_J = 137;
/*      */   private static final int K_EscOJ_ = 138;
/*      */   private static final int SKIP_PARAMETER_WHITESPACE = 139;
/*      */   private static final int A_LTER_SESSION = 140;
/*      */   private static final int AL_TER_SESSION = 141;
/*      */   private static final int ALT_ER_SESSION = 142;
/*      */   private static final int ALTE_R_SESSION = 143;
/*      */   private static final int ALTER__SESSION = 144;
/*      */   private static final int ALTER_xSESSION = 145;
/*      */   private static final int ALTER_S_ESSION = 146;
/*      */   private static final int ALTER_SE_SSION = 147;
/*      */   private static final int ALTER_SES_SION = 148;
/*      */   private static final int ALTER_SESS_ION = 149;
/*      */   private static final int ALTER_SESSI_ON = 150;
/*      */   private static final int ALTER_SESSIO_N = 151;
/*      */   private static final int ALTER_SESSION_ = 152;
/*      */   private static final int ALTER_xSESSION_CC_1 = 153;
/*      */   private static final int ALTER_xSESSION_CC_2 = 154;
/*      */   private static final int ALTER_xSESSION_CC_3 = 155;
/*      */   private static final int ALTER_xSESSION_C_1 = 156;
/*      */   private static final int ALTER_xSESSION_C_2 = 157;
/*      */   private static final int R_ETURNING = 158;
/*      */   private static final int RE_TURNING = 159;
/*      */   private static final int RET_URNING = 160;
/*      */   private static final int RETU_RNING = 161;
/*      */   private static final int RETUR_NING = 162;
/*      */   private static final int RETURN_ING = 163;
/*      */   private static final int RETURNI_NG = 164;
/*      */   private static final int RETURNIN_G = 165;
/*      */   private static final int RETURNING_ = 166;
/*      */   private static final int I_NTO = 167;
/*      */   private static final int IN_TO = 168;
/*      */   private static final int INT_O = 169;
/*      */   private static final int INTO_ = 170;
/*      */   private static final int LAST_STATE = 171;
/*      */   private static final int EOKTSS_LAST_STATE = 171;
/* 2379 */   public static final String[] PARSER_STATE_NAME = new String[] { "BASE", "BASE_1", "BASE_2", "B_STRING", "B_NAME", "B_C_COMMENT", "B_C_COMMENT_1", "B_COMMENT", "PARAMETER", "TOKEN", "B_EGIN", "BE_GIN", "BEG_IN", "BEGI_N", "BEGIN_", "C_ALL", "CA_LL", "CAL_L", "CALL_", "D_Eetc", "DE_etc", "DEC_LARE", "DECL_ARE", "DECLA_RE", "DECLAR_E", "DECLARE_", "DEL_ETE", "DELE_TE", "DELET_E", "DELETE_", "I_NSERT", "IN_SERT", "INS_ERT", "INSE_RT", "INSER_T", "INSERT_", "S_ELECT", "SE_LECT", "SEL_ECT", "SELE_CT", "SELEC_T", "SELECT_", "U_PDATE", "UP_DATE", "UPD_ATE", "UPDA_TE", "UPDAT_E", "UPDATE_", "M_ERGE", "ME_RGE", "MER_GE", "MERG_E", "MERGE_", "W_ITH", "WI_TH", "WIT_H", "WITH_", "KNOW_KIND", "KNOW_KIND_1", "KNOW_KIND_2", "K_STRING", "K_NAME", "K_C_COMMENT", "K_C_COMMENT_1", "K_COMMENT", "K_PARAMETER", "TOKEN_KK", "W_HERE", "WH_ERE", "WHE_RE", "WHER_E", "WHERE_", "O_RDER_BY", "OR_DER_BY", "ORD_ER_BY", "ORDE_R_BY", "ORDER__BY", "ORDER_xBY", "ORDER_B_Y", "ORDER_BY_", "ORDER_xBY_CC_1", "ORDER_xBY_CC_2", "ORDER_xBY_CC_3", "ORDER_xBY_C_1 ", "ORDER_xBY_C_2 ", "F_OR_UPDATE", "FO_R_UPDATE", "FOR__UPDATE", "FOR_xUPDATE", "FOR_U_PDATE", "FOR_UP_DATE", "FOR_UPD_ATE", "FOR_UPDA_TE", "FOR_UPDAT_E", "FOR_UPDATE_", "FOR_xUPDATE_CC_1", "FOR_xUPDATE_CC_2", "FOR_xUPDATE_CC_3", "FOR_xUPDATE_C_1 ", "FOR_xUPDATE_C_2 ", "B_N_tick", "B_NCHAR", "K_N_tick", "K_NCHAR", "K_NCHAR_tick", "B_Q_tickDelimiterCharDelimiterTick", "B_QTick_delimiterCharDelimiterTick", "B_QTickDelimiter_charDelimiterTick", "B_QTickDelimiterChar_delimiterTick", "B_QTickDelimiterCharDelimiter_tick", "K_Q_tickDelimiterCharDelimiterTick", "K_QTick_delimiterCharDelimiterTick", "K_QTickDelimiter_charDelimiterTick", "K_QTickDelimiterChar_delimiterTick", "K_QTickDelimiterCharDelimiter_tick", "K_EscEtc", "K_EscQuestion", "K_EscC_ALL", "K_EscCA_LL", "K_EscCAL_L", "K_EscCALL_", "K_EscT", "K_EscTS_", "K_EscD_", "K_EscE_SCAPE", "K_EscES_CAPE", "K_EscESC_APE", "K_EscESCA_PE", "K_EscESCAP_E", "K_EscESCAPE_", "K_EscF_N", "K_EscFN_", "K_EscL_IMIT", "K_EscLI_MIT", "K_EscLIM_IT", "K_EscLIMI_T", "K_EscLIMIT_", "K_EscO_J", "K_EscOJ_", "SKIP_PARAMETER_WHITESPACE", "A_LTER_SESSION", "AL_TER_SESSION", "ALT_ER_SESSION", "ALTE_R_SESSION", "ALTER__SESSION", "ALTER_xSESSION", "ALTER_S_ESSION", "ALTER_SE_SSION", "ALTER_SES_SION", "ALTER_SESS_ION", "ALTER_SESSI_ON", "ALTER_SESSIO_N", "ALTER_SESSION_", "ALTER_xSESSION_CC_1", "ALTER_xSESSION_CC_2", "ALTER_xSESSION_CC_3", "ALTER_xSESSION_C_1 ", "ALTER_xSESSION_C_2 ", "R_ETURNING", "RE_TURNING", "RET_URNING", "RETU_RNING", "RETUR_NING", "RETURN_ING", "RETURNI_NG", "RETURNIN_G", "RETURNING_", "I_NTO", "IN_TO", "INT_O", "INTO_", "LAST_STATE" };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 2576 */   static final int[][] TRANSITION = new int[171][];
/*      */   
/*      */   static final int NO_ACTION = 0;
/*      */   
/*      */   static final int DELETE_ACTION = 1;
/*      */   static final int INSERT_ACTION = 2;
/*      */   static final int MERGE_ACTION = 3;
/*      */   static final int UPDATE_ACTION = 4;
/*      */   static final int PLSQL_ACTION = 5;
/*      */   static final int CALL_ACTION = 6;
/*      */   static final int SELECT_ACTION = 7;
/*      */   static final int OTHER_ACTION = 8;
/*      */   static final int WHERE_ACTION = 9;
/*      */   static final int ORDER_ACTION = 10;
/*      */   static final int ORDER_BY_ACTION = 11;
/*      */   static final int FOR_ACTION = 12;
/*      */   static final int FOR_UPDATE_ACTION = 13;
/*      */   static final int QUESTION_ACTION = 14;
/*      */   static final int PARAMETER_ACTION = 15;
/*      */   static final int END_PARAMETER_ACTION = 16;
/*      */   static final int START_NCHAR_LITERAL_ACTION = 17;
/*      */   static final int END_NCHAR_LITERAL_ACTION = 18;
/*      */   static final int SAVE_DELIMITER_ACTION = 19;
/*      */   static final int LOOK_FOR_DELIMITER_ACTION = 20;
/*      */   static final int ALTER_SESSION_ACTION = 21;
/*      */   static final int RETURNING_ACTION = 22;
/*      */   static final int INTO_ACTION = 23;
/* 2603 */   public static final String[] CBI_ACTION_NAME = new String[] { "NO_ACTION", "DELETE_ACTION", "INSERT_ACTION", "MERGE_ACTION", "UPDATE_ACTION", "PLSQL_ACTION", "CALL_ACTION", "SELECT_ACTION", "OTHER_ACTION", "WHERE_ACTION", "ORDER_ACTION", "ORDER_BY_ACTION", "FOR_ACTION", "FOR_UPDATE_ACTION", "QUESTION_ACTION", "PARAMETER_ACTION", "END_PARAMETER_ACTION", "START_NCHAR_LITERAL_ACTION", "END_NCHAR_LITERAL_ACTION", "SAVE_DELIMITER_ACTION", "LOOK_FOR_DELIMITER_ACTION", "ALTER_SESSION_ACTION", "RETURNING_ACTION", "INTO_ACTION" };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 2635 */   static final int[][] ACTION = new int[171][];
/*      */ 
/*      */   
/*      */   static final int INITIAL_STATE = 0;
/*      */   
/*      */   static final int RESTART_STATE = 66;
/*      */ 
/*      */   
/*      */   enum ODBCAction
/*      */   {
/* 2645 */     NONE,
/* 2646 */     COPY,
/* 2647 */     QUESTION,
/* 2648 */     SAVE_DELIMITER,
/* 2649 */     LOOK_FOR_DELIMITER,
/* 2650 */     FUNCTION,
/* 2651 */     CALL,
/* 2652 */     TIME,
/* 2653 */     TIMESTAMP,
/* 2654 */     DATE,
/* 2655 */     ESCAPE,
/* 2656 */     SCALAR_FUNCTION,
/* 2657 */     OUTER_JOIN,
/* 2658 */     UNKNOWN_ESCAPE,
/* 2659 */     END_ODBC_ESCAPE,
/* 2660 */     COMMA,
/* 2661 */     OPEN_PAREN,
/* 2662 */     CLOSE_PAREN,
/* 2663 */     BEGIN,
/* 2664 */     LIMIT;
/*      */   }
/*      */   
/* 2667 */   static final ODBCAction[][] ODBC_ACTION = new ODBCAction[171][];
/*      */   static final int cMax = 127;
/*      */   private static final int cMaxLength = 128;
/*      */   
/*      */   private static final int[] copy(int[] paramArrayOfint) {
/* 2672 */     int[] arrayOfInt = new int[paramArrayOfint.length];
/* 2673 */     System.arraycopy(paramArrayOfint, 0, arrayOfInt, 0, paramArrayOfint.length);
/* 2674 */     return arrayOfInt;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static final ODBCAction[] copy(ODBCAction[] paramArrayOfODBCAction) {
/* 2681 */     ODBCAction[] arrayOfODBCAction = new ODBCAction[paramArrayOfODBCAction.length];
/* 2682 */     System.arraycopy(paramArrayOfODBCAction, 0, arrayOfODBCAction, 0, paramArrayOfODBCAction.length);
/* 2683 */     return arrayOfODBCAction;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private static final int[] newArray(int paramInt1, int paramInt2) {
/* 2689 */     int[] arrayOfInt = new int[paramInt1];
/*      */     
/* 2691 */     for (byte b = 0; b < paramInt1; b++) {
/* 2692 */       arrayOfInt[b] = paramInt2;
/*      */     }
/* 2694 */     return arrayOfInt;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private static final ODBCAction[] newArray(int paramInt, ODBCAction paramODBCAction) {
/* 2700 */     ODBCAction[] arrayOfODBCAction = new ODBCAction[paramInt];
/*      */     
/* 2702 */     for (byte b = 0; b < paramInt; b++) {
/* 2703 */       arrayOfODBCAction[b] = paramODBCAction;
/*      */     }
/* 2705 */     return arrayOfODBCAction;
/*      */   }
/*      */ 
/*      */   
/*      */   private static final int[] copyReplacing(int[] paramArrayOfint, int paramInt1, int paramInt2) {
/* 2710 */     int[] arrayOfInt = new int[paramArrayOfint.length];
/*      */     
/* 2712 */     for (byte b = 0; b < arrayOfInt.length; b++) {
/*      */       
/* 2714 */       int i = paramArrayOfint[b];
/*      */       
/* 2716 */       if (i == paramInt1) {
/* 2717 */         arrayOfInt[b] = paramInt2;
/*      */       } else {
/* 2719 */         arrayOfInt[b] = i;
/*      */       } 
/*      */     } 
/* 2722 */     return arrayOfInt;
/*      */   }
/*      */ 
/*      */   
/*      */   private static final ODBCAction[] copyReplacing(ODBCAction[] paramArrayOfODBCAction, ODBCAction paramODBCAction1, ODBCAction paramODBCAction2) {
/* 2727 */     ODBCAction[] arrayOfODBCAction = new ODBCAction[paramArrayOfODBCAction.length];
/*      */     
/* 2729 */     for (byte b = 0; b < arrayOfODBCAction.length; b++) {
/*      */       
/* 2731 */       ODBCAction oDBCAction = paramArrayOfODBCAction[b];
/*      */       
/* 2733 */       if (oDBCAction == paramODBCAction1) {
/* 2734 */         arrayOfODBCAction[b] = paramODBCAction2;
/*      */       } else {
/* 2736 */         arrayOfODBCAction[b] = oDBCAction;
/*      */       } 
/*      */     } 
/* 2739 */     return arrayOfODBCAction;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static {
/*      */     try {
/* 2754 */       int[] arrayOfInt1 = { 57, 57, 57, 57, 57, 57, 57, 57, 57, 57, 57, 57, 57, 57, 57, 57, 57, 57, 57, 57, 57, 57, 57, 57, 57, 57, 57, 57, 57, 57, 57, 57, 57, 57, 57, 9, 9, 57, 57, 57, 57, 57, 57, 57, 57, 57, 57, 57, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 57, 57, 57, 57, 57, 57, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 57, 57, 57, 57, 9, 57, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 57, 57, 57, 57, 57 };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2791 */       int[] arrayOfInt2 = copy(arrayOfInt1);
/* 2792 */       arrayOfInt2[34] = 4;
/* 2793 */       arrayOfInt2[39] = 3;
/* 2794 */       arrayOfInt2[45] = 2;
/* 2795 */       arrayOfInt2[47] = 1;
/* 2796 */       arrayOfInt2[58] = 8;
/* 2797 */       arrayOfInt2[123] = 115;
/*      */ 
/*      */ 
/*      */       
/* 2801 */       int[] arrayOfInt3 = copyReplacing(arrayOfInt2, 57, 0);
/* 2802 */       arrayOfInt3[65] = 140;
/* 2803 */       arrayOfInt3[97] = 140;
/* 2804 */       arrayOfInt3[66] = 10;
/* 2805 */       arrayOfInt3[98] = 10;
/* 2806 */       arrayOfInt3[67] = 15;
/* 2807 */       arrayOfInt3[99] = 15;
/* 2808 */       arrayOfInt3[68] = 19;
/* 2809 */       arrayOfInt3[100] = 19;
/* 2810 */       arrayOfInt3[73] = 30;
/* 2811 */       arrayOfInt3[105] = 30;
/* 2812 */       arrayOfInt3[109] = 48;
/* 2813 */       arrayOfInt3[77] = 48;
/* 2814 */       arrayOfInt3[78] = 100;
/* 2815 */       arrayOfInt3[110] = 100;
/* 2816 */       arrayOfInt3[81] = 105;
/* 2817 */       arrayOfInt3[113] = 105;
/* 2818 */       arrayOfInt3[83] = 36;
/* 2819 */       arrayOfInt3[115] = 36;
/* 2820 */       arrayOfInt3[85] = 42;
/* 2821 */       arrayOfInt3[117] = 42;
/* 2822 */       arrayOfInt3[87] = 53;
/* 2823 */       arrayOfInt3[119] = 53;
/*      */ 
/*      */       
/* 2826 */       int[] arrayOfInt4 = copyReplacing(arrayOfInt2, 9, 66);
/* 2827 */       arrayOfInt4[34] = 61;
/* 2828 */       arrayOfInt4[39] = 60;
/* 2829 */       arrayOfInt4[45] = 59;
/* 2830 */       arrayOfInt4[47] = 58;
/* 2831 */       arrayOfInt4[58] = 139;
/* 2832 */       arrayOfInt4[32] = 57;
/* 2833 */       arrayOfInt4[9] = 57;
/* 2834 */       arrayOfInt4[10] = 57;
/* 2835 */       arrayOfInt4[13] = 57;
/* 2836 */       arrayOfInt4[61] = 57;
/*      */ 
/*      */       
/* 2839 */       int[] arrayOfInt5 = copyReplacing(arrayOfInt4, 9, 66);
/* 2840 */       arrayOfInt5[78] = 102;
/* 2841 */       arrayOfInt5[110] = 102;
/* 2842 */       arrayOfInt5[81] = 110;
/* 2843 */       arrayOfInt5[113] = 110;
/* 2844 */       arrayOfInt5[87] = 67;
/* 2845 */       arrayOfInt5[119] = 67;
/* 2846 */       arrayOfInt5[79] = 72;
/* 2847 */       arrayOfInt5[111] = 72;
/* 2848 */       arrayOfInt5[70] = 85;
/* 2849 */       arrayOfInt5[102] = 85;
/* 2850 */       arrayOfInt5[82] = 158;
/* 2851 */       arrayOfInt5[114] = 158;
/* 2852 */       arrayOfInt5[73] = 167;
/* 2853 */       arrayOfInt5[105] = 167;
/*      */ 
/*      */ 
/*      */       
/* 2857 */       int[] arrayOfInt6 = copyReplacing(arrayOfInt5, 57, 115);
/*      */       
/* 2859 */       arrayOfInt6[63] = 116;
/* 2860 */       arrayOfInt6[99] = 117;
/* 2861 */       arrayOfInt6[67] = 117;
/* 2862 */       arrayOfInt6[116] = 121;
/* 2863 */       arrayOfInt6[84] = 121;
/* 2864 */       arrayOfInt6[100] = 123;
/* 2865 */       arrayOfInt6[68] = 123;
/* 2866 */       arrayOfInt6[101] = 124;
/* 2867 */       arrayOfInt6[69] = 124;
/* 2868 */       arrayOfInt6[102] = 130;
/* 2869 */       arrayOfInt6[70] = 130;
/* 2870 */       arrayOfInt6[111] = 137;
/* 2871 */       arrayOfInt6[79] = 137;
/*      */ 
/*      */ 
/*      */       
/* 2875 */       TRANSITION[0] = arrayOfInt3;
/* 2876 */       TRANSITION[1] = copy(arrayOfInt3);
/* 2877 */       TRANSITION[1][42] = 5;
/* 2878 */       TRANSITION[2] = copy(arrayOfInt3);
/* 2879 */       TRANSITION[2][45] = 7;
/* 2880 */       TRANSITION[3] = newArray(128, 3);
/* 2881 */       TRANSITION[3][39] = 0;
/* 2882 */       TRANSITION[100] = copy(arrayOfInt2);
/* 2883 */       TRANSITION[100][39] = 101;
/* 2884 */       TRANSITION[101] = newArray(128, 101);
/* 2885 */       TRANSITION[101][39] = 0;
/*      */       
/* 2887 */       TRANSITION[105] = copy(arrayOfInt2);
/* 2888 */       TRANSITION[105][39] = 106;
/* 2889 */       TRANSITION[106] = newArray(128, 107);
/* 2890 */       TRANSITION[107] = newArray(128, 107);
/*      */       
/* 2892 */       TRANSITION[108] = newArray(128, 109);
/* 2893 */       TRANSITION[109] = newArray(128, 107);
/* 2894 */       TRANSITION[109][39] = 0;
/*      */ 
/*      */       
/* 2897 */       TRANSITION[4] = newArray(128, 4);
/* 2898 */       TRANSITION[4][34] = 0;
/* 2899 */       TRANSITION[5] = newArray(128, 5);
/* 2900 */       TRANSITION[5][42] = 6;
/* 2901 */       TRANSITION[6] = newArray(128, 5);
/* 2902 */       TRANSITION[6][42] = 6;
/* 2903 */       TRANSITION[6][47] = 0;
/* 2904 */       TRANSITION[7] = newArray(128, 7);
/* 2905 */       TRANSITION[7][10] = 0;
/* 2906 */       TRANSITION[8] = copyReplacing(arrayOfInt2, 9, 8);
/* 2907 */       TRANSITION[9] = arrayOfInt2;
/* 2908 */       TRANSITION[10] = copy(arrayOfInt2);
/* 2909 */       TRANSITION[10][69] = 11;
/* 2910 */       TRANSITION[10][101] = 11;
/* 2911 */       TRANSITION[11] = copy(arrayOfInt2);
/* 2912 */       TRANSITION[11][71] = 12;
/* 2913 */       TRANSITION[11][103] = 12;
/* 2914 */       TRANSITION[12] = copy(arrayOfInt2);
/* 2915 */       TRANSITION[12][73] = 13;
/* 2916 */       TRANSITION[12][105] = 13;
/* 2917 */       TRANSITION[13] = copy(arrayOfInt2);
/* 2918 */       TRANSITION[13][78] = 14;
/* 2919 */       TRANSITION[13][110] = 14;
/* 2920 */       TRANSITION[14] = arrayOfInt5;
/* 2921 */       TRANSITION[15] = copy(arrayOfInt2);
/* 2922 */       TRANSITION[15][65] = 16;
/* 2923 */       TRANSITION[15][97] = 16;
/* 2924 */       TRANSITION[16] = copy(arrayOfInt2);
/* 2925 */       TRANSITION[16][76] = 17;
/* 2926 */       TRANSITION[16][108] = 17;
/* 2927 */       TRANSITION[17] = copy(arrayOfInt2);
/* 2928 */       TRANSITION[17][76] = 18;
/* 2929 */       TRANSITION[17][108] = 18;
/* 2930 */       TRANSITION[18] = arrayOfInt5;
/* 2931 */       TRANSITION[19] = copy(arrayOfInt2);
/* 2932 */       TRANSITION[19][69] = 20;
/* 2933 */       TRANSITION[19][101] = 20;
/* 2934 */       TRANSITION[20] = copy(arrayOfInt2);
/* 2935 */       TRANSITION[20][67] = 21;
/* 2936 */       TRANSITION[20][99] = 21;
/* 2937 */       TRANSITION[20][76] = 26;
/* 2938 */       TRANSITION[20][108] = 26;
/* 2939 */       TRANSITION[21] = copy(arrayOfInt2);
/* 2940 */       TRANSITION[21][76] = 22;
/* 2941 */       TRANSITION[21][108] = 22;
/* 2942 */       TRANSITION[22] = copy(arrayOfInt2);
/* 2943 */       TRANSITION[22][65] = 23;
/* 2944 */       TRANSITION[22][97] = 23;
/* 2945 */       TRANSITION[23] = copy(arrayOfInt2);
/* 2946 */       TRANSITION[23][82] = 24;
/* 2947 */       TRANSITION[23][114] = 24;
/* 2948 */       TRANSITION[24] = copy(arrayOfInt2);
/* 2949 */       TRANSITION[24][69] = 25;
/* 2950 */       TRANSITION[24][101] = 25;
/* 2951 */       TRANSITION[25] = arrayOfInt5;
/* 2952 */       TRANSITION[26] = copy(arrayOfInt2);
/* 2953 */       TRANSITION[26][69] = 27;
/* 2954 */       TRANSITION[26][101] = 27;
/* 2955 */       TRANSITION[27] = copy(arrayOfInt2);
/* 2956 */       TRANSITION[27][84] = 28;
/* 2957 */       TRANSITION[27][116] = 28;
/* 2958 */       TRANSITION[28] = copy(arrayOfInt2);
/* 2959 */       TRANSITION[28][69] = 29;
/* 2960 */       TRANSITION[28][101] = 29;
/* 2961 */       TRANSITION[29] = arrayOfInt5;
/* 2962 */       TRANSITION[30] = copy(arrayOfInt2);
/* 2963 */       TRANSITION[30][78] = 31;
/* 2964 */       TRANSITION[30][110] = 31;
/* 2965 */       TRANSITION[31] = copy(arrayOfInt2);
/* 2966 */       TRANSITION[31][83] = 32;
/* 2967 */       TRANSITION[31][115] = 32;
/* 2968 */       TRANSITION[32] = copy(arrayOfInt2);
/* 2969 */       TRANSITION[32][69] = 33;
/* 2970 */       TRANSITION[32][101] = 33;
/* 2971 */       TRANSITION[33] = copy(arrayOfInt2);
/* 2972 */       TRANSITION[33][82] = 34;
/* 2973 */       TRANSITION[33][114] = 34;
/* 2974 */       TRANSITION[34] = copy(arrayOfInt2);
/* 2975 */       TRANSITION[34][84] = 35;
/* 2976 */       TRANSITION[34][116] = 35;
/* 2977 */       TRANSITION[35] = arrayOfInt5;
/* 2978 */       TRANSITION[36] = copy(arrayOfInt2);
/* 2979 */       TRANSITION[36][69] = 37;
/* 2980 */       TRANSITION[36][101] = 37;
/* 2981 */       TRANSITION[37] = copy(arrayOfInt2);
/* 2982 */       TRANSITION[37][76] = 38;
/* 2983 */       TRANSITION[37][108] = 38;
/* 2984 */       TRANSITION[38] = copy(arrayOfInt2);
/* 2985 */       TRANSITION[38][69] = 39;
/* 2986 */       TRANSITION[38][101] = 39;
/* 2987 */       TRANSITION[39] = copy(arrayOfInt2);
/* 2988 */       TRANSITION[39][67] = 40;
/* 2989 */       TRANSITION[39][99] = 40;
/* 2990 */       TRANSITION[40] = copy(arrayOfInt2);
/* 2991 */       TRANSITION[40][84] = 41;
/* 2992 */       TRANSITION[40][116] = 41;
/* 2993 */       TRANSITION[41] = arrayOfInt5;
/* 2994 */       TRANSITION[42] = copy(arrayOfInt2);
/* 2995 */       TRANSITION[42][80] = 43;
/* 2996 */       TRANSITION[42][112] = 43;
/* 2997 */       TRANSITION[43] = copy(arrayOfInt2);
/* 2998 */       TRANSITION[43][68] = 44;
/* 2999 */       TRANSITION[43][100] = 44;
/* 3000 */       TRANSITION[44] = copy(arrayOfInt2);
/* 3001 */       TRANSITION[44][65] = 45;
/* 3002 */       TRANSITION[44][97] = 45;
/* 3003 */       TRANSITION[45] = copy(arrayOfInt2);
/* 3004 */       TRANSITION[45][84] = 46;
/* 3005 */       TRANSITION[45][116] = 46;
/* 3006 */       TRANSITION[46] = copy(arrayOfInt2);
/* 3007 */       TRANSITION[46][69] = 47;
/* 3008 */       TRANSITION[46][101] = 47;
/* 3009 */       TRANSITION[47] = arrayOfInt5;
/* 3010 */       TRANSITION[48] = copy(arrayOfInt2);
/* 3011 */       TRANSITION[48][69] = 49;
/* 3012 */       TRANSITION[48][101] = 49;
/* 3013 */       TRANSITION[49] = copy(arrayOfInt2);
/* 3014 */       TRANSITION[49][82] = 50;
/* 3015 */       TRANSITION[49][114] = 50;
/* 3016 */       TRANSITION[50] = copy(arrayOfInt2);
/* 3017 */       TRANSITION[50][71] = 51;
/* 3018 */       TRANSITION[50][103] = 51;
/* 3019 */       TRANSITION[51] = copy(arrayOfInt2);
/* 3020 */       TRANSITION[51][69] = 52;
/* 3021 */       TRANSITION[51][101] = 52;
/* 3022 */       TRANSITION[52] = arrayOfInt5;
/* 3023 */       TRANSITION[53] = copy(arrayOfInt2);
/* 3024 */       TRANSITION[53][73] = 54;
/* 3025 */       TRANSITION[53][105] = 54;
/* 3026 */       TRANSITION[54] = copy(arrayOfInt2);
/* 3027 */       TRANSITION[54][84] = 55;
/* 3028 */       TRANSITION[54][116] = 55;
/* 3029 */       TRANSITION[55] = copy(arrayOfInt2);
/* 3030 */       TRANSITION[55][72] = 56;
/* 3031 */       TRANSITION[55][104] = 56;
/* 3032 */       TRANSITION[56] = arrayOfInt5;
/* 3033 */       TRANSITION[66] = arrayOfInt4;
/* 3034 */       TRANSITION[58] = copy(arrayOfInt5);
/* 3035 */       TRANSITION[58][42] = 62;
/* 3036 */       TRANSITION[59] = copy(arrayOfInt5);
/* 3037 */       TRANSITION[59][45] = 64;
/* 3038 */       TRANSITION[62] = newArray(128, 62);
/* 3039 */       TRANSITION[62][42] = 63;
/* 3040 */       TRANSITION[63] = newArray(128, 62);
/* 3041 */       TRANSITION[63][42] = 63;
/* 3042 */       TRANSITION[63][47] = 57;
/* 3043 */       TRANSITION[64] = newArray(128, 64);
/* 3044 */       TRANSITION[64][10] = 57;
/* 3045 */       TRANSITION[61] = newArray(128, 61);
/* 3046 */       TRANSITION[61][34] = 57;
/* 3047 */       TRANSITION[60] = newArray(128, 60);
/* 3048 */       TRANSITION[60][39] = 57;
/* 3049 */       TRANSITION[65] = copyReplacing(arrayOfInt4, 66, 65);
/* 3050 */       TRANSITION[139] = copyReplacing(arrayOfInt4, 66, 65);
/* 3051 */       TRANSITION[139][32] = 139;
/* 3052 */       TRANSITION[139][10] = 139;
/* 3053 */       TRANSITION[139][13] = 139;
/* 3054 */       TRANSITION[139][9] = 139;
/*      */ 
/*      */       
/* 3057 */       TRANSITION[57] = arrayOfInt5;
/* 3058 */       TRANSITION[67] = copy(arrayOfInt4);
/* 3059 */       TRANSITION[67][72] = 68;
/* 3060 */       TRANSITION[67][104] = 68;
/* 3061 */       TRANSITION[68] = copy(arrayOfInt4);
/* 3062 */       TRANSITION[68][69] = 69;
/* 3063 */       TRANSITION[68][101] = 69;
/* 3064 */       TRANSITION[69] = copy(arrayOfInt4);
/* 3065 */       TRANSITION[69][82] = 70;
/* 3066 */       TRANSITION[69][114] = 70;
/* 3067 */       TRANSITION[70] = copy(arrayOfInt4);
/* 3068 */       TRANSITION[70][69] = 71;
/* 3069 */       TRANSITION[70][101] = 71;
/* 3070 */       TRANSITION[71] = arrayOfInt5;
/*      */       
/* 3072 */       TRANSITION[72] = copy(arrayOfInt4);
/* 3073 */       TRANSITION[72][82] = 73;
/* 3074 */       TRANSITION[72][114] = 73;
/* 3075 */       TRANSITION[73] = copy(arrayOfInt4);
/* 3076 */       TRANSITION[73][68] = 74;
/* 3077 */       TRANSITION[73][100] = 74;
/* 3078 */       TRANSITION[74] = copy(arrayOfInt4);
/* 3079 */       TRANSITION[74][69] = 75;
/* 3080 */       TRANSITION[74][101] = 75;
/* 3081 */       TRANSITION[75] = copy(arrayOfInt4);
/* 3082 */       TRANSITION[75][82] = 76;
/* 3083 */       TRANSITION[75][114] = 76;
/* 3084 */       TRANSITION[76] = copyReplacing(arrayOfInt5, 57, 77);
/* 3085 */       TRANSITION[76][47] = 80;
/* 3086 */       TRANSITION[76][45] = 83;
/*      */       
/* 3088 */       TRANSITION[77] = copyReplacing(arrayOfInt5, 57, 77);
/* 3089 */       TRANSITION[77][47] = 80;
/* 3090 */       TRANSITION[80] = copy(arrayOfInt5);
/* 3091 */       TRANSITION[80][42] = 81;
/* 3092 */       TRANSITION[81] = newArray(128, 81);
/* 3093 */       TRANSITION[81][42] = 82;
/* 3094 */       TRANSITION[82] = newArray(128, 81);
/* 3095 */       TRANSITION[82][47] = 77;
/*      */       
/* 3097 */       TRANSITION[77][45] = 83;
/* 3098 */       TRANSITION[83] = copy(arrayOfInt5);
/* 3099 */       TRANSITION[83][45] = 84;
/* 3100 */       TRANSITION[84] = newArray(128, 84);
/* 3101 */       TRANSITION[84][10] = 77;
/*      */ 
/*      */       
/* 3104 */       TRANSITION[77][66] = 78;
/* 3105 */       TRANSITION[77][98] = 78;
/* 3106 */       TRANSITION[78] = copy(arrayOfInt4);
/* 3107 */       TRANSITION[78][89] = 79;
/* 3108 */       TRANSITION[78][121] = 79;
/* 3109 */       TRANSITION[79] = arrayOfInt5;
/*      */       
/* 3111 */       TRANSITION[85] = copy(arrayOfInt5);
/* 3112 */       TRANSITION[85][79] = 86;
/* 3113 */       TRANSITION[85][111] = 86;
/* 3114 */       TRANSITION[86] = copy(arrayOfInt5);
/* 3115 */       TRANSITION[86][82] = 87;
/* 3116 */       TRANSITION[86][114] = 87;
/* 3117 */       TRANSITION[87] = copyReplacing(arrayOfInt4, 57, 88);
/* 3118 */       TRANSITION[87][47] = 95;
/* 3119 */       TRANSITION[87][45] = 98;
/*      */       
/* 3121 */       TRANSITION[88] = copyReplacing(arrayOfInt4, 57, 88);
/* 3122 */       TRANSITION[88][47] = 95;
/* 3123 */       TRANSITION[95] = copy(arrayOfInt5);
/* 3124 */       TRANSITION[95][42] = 96;
/* 3125 */       TRANSITION[96] = newArray(128, 96);
/* 3126 */       TRANSITION[96][42] = 97;
/* 3127 */       TRANSITION[97] = newArray(128, 96);
/* 3128 */       TRANSITION[97][47] = 88;
/*      */       
/* 3130 */       TRANSITION[88][45] = 98;
/* 3131 */       TRANSITION[98] = copy(arrayOfInt5);
/* 3132 */       TRANSITION[98][45] = 99;
/* 3133 */       TRANSITION[99] = newArray(128, 99);
/* 3134 */       TRANSITION[99][10] = 88;
/*      */ 
/*      */       
/* 3137 */       TRANSITION[88][85] = 89;
/* 3138 */       TRANSITION[88][117] = 89;
/* 3139 */       TRANSITION[89] = copy(arrayOfInt5);
/* 3140 */       TRANSITION[89][80] = 90;
/* 3141 */       TRANSITION[89][112] = 90;
/* 3142 */       TRANSITION[90] = copy(arrayOfInt5);
/* 3143 */       TRANSITION[90][68] = 91;
/* 3144 */       TRANSITION[90][100] = 91;
/* 3145 */       TRANSITION[91] = copy(arrayOfInt5);
/* 3146 */       TRANSITION[91][65] = 92;
/* 3147 */       TRANSITION[91][97] = 92;
/* 3148 */       TRANSITION[92] = copy(arrayOfInt5);
/* 3149 */       TRANSITION[92][84] = 93;
/* 3150 */       TRANSITION[92][116] = 93;
/* 3151 */       TRANSITION[93] = copy(arrayOfInt5);
/* 3152 */       TRANSITION[93][69] = 94;
/* 3153 */       TRANSITION[93][101] = 94;
/* 3154 */       TRANSITION[94] = arrayOfInt5;
/*      */       
/* 3156 */       TRANSITION[158] = copy(arrayOfInt5);
/* 3157 */       TRANSITION[158][69] = 159;
/* 3158 */       TRANSITION[158][101] = 159;
/* 3159 */       TRANSITION[159] = copy(arrayOfInt5);
/* 3160 */       TRANSITION[159][84] = 160;
/* 3161 */       TRANSITION[159][116] = 160;
/* 3162 */       TRANSITION[160] = copy(arrayOfInt5);
/* 3163 */       TRANSITION[160][85] = 161;
/* 3164 */       TRANSITION[160][117] = 161;
/* 3165 */       TRANSITION[161] = copy(arrayOfInt5);
/* 3166 */       TRANSITION[161][82] = 162;
/* 3167 */       TRANSITION[161][114] = 162;
/* 3168 */       TRANSITION[162] = copy(arrayOfInt5);
/* 3169 */       TRANSITION[162][78] = 163;
/* 3170 */       TRANSITION[162][110] = 163;
/* 3171 */       TRANSITION[163] = copy(arrayOfInt5);
/* 3172 */       TRANSITION[163][73] = 164;
/* 3173 */       TRANSITION[163][105] = 164;
/* 3174 */       TRANSITION[164] = copy(arrayOfInt5);
/* 3175 */       TRANSITION[164][78] = 165;
/* 3176 */       TRANSITION[164][110] = 165;
/* 3177 */       TRANSITION[165] = copy(arrayOfInt5);
/* 3178 */       TRANSITION[165][71] = 166;
/* 3179 */       TRANSITION[165][103] = 166;
/* 3180 */       TRANSITION[166] = arrayOfInt5;
/*      */       
/* 3182 */       TRANSITION[167] = copy(arrayOfInt5);
/* 3183 */       TRANSITION[167][78] = 168;
/* 3184 */       TRANSITION[167][110] = 168;
/* 3185 */       TRANSITION[168] = copy(arrayOfInt5);
/* 3186 */       TRANSITION[168][84] = 169;
/* 3187 */       TRANSITION[168][116] = 169;
/* 3188 */       TRANSITION[169] = copy(arrayOfInt5);
/* 3189 */       TRANSITION[169][79] = 170;
/* 3190 */       TRANSITION[169][111] = 170;
/* 3191 */       TRANSITION[170] = copy(arrayOfInt5);
/*      */ 
/*      */       
/* 3194 */       TRANSITION[102] = copy(arrayOfInt4);
/* 3195 */       TRANSITION[102][39] = 103;
/* 3196 */       TRANSITION[103] = newArray(128, 103);
/* 3197 */       TRANSITION[103][39] = 104;
/*      */       
/* 3199 */       TRANSITION[104] = newArray(128, 57);
/* 3200 */       TRANSITION[104][39] = 103;
/*      */       
/* 3202 */       TRANSITION[110] = copy(arrayOfInt5);
/* 3203 */       TRANSITION[110][39] = 111;
/* 3204 */       TRANSITION[111] = newArray(128, 112);
/* 3205 */       TRANSITION[112] = newArray(128, 112);
/*      */       
/* 3207 */       TRANSITION[113] = newArray(128, 114);
/* 3208 */       TRANSITION[114] = newArray(128, 112);
/* 3209 */       TRANSITION[114][39] = 57;
/*      */ 
/*      */       
/* 3212 */       TRANSITION[115] = arrayOfInt6;
/* 3213 */       TRANSITION[116] = arrayOfInt5;
/* 3214 */       TRANSITION[117] = copy(arrayOfInt5);
/* 3215 */       TRANSITION[117][97] = 118;
/* 3216 */       TRANSITION[117][65] = 118;
/* 3217 */       TRANSITION[118] = copy(arrayOfInt5);
/* 3218 */       TRANSITION[118][108] = 119;
/* 3219 */       TRANSITION[118][76] = 119;
/* 3220 */       TRANSITION[119] = copy(arrayOfInt5);
/* 3221 */       TRANSITION[119][108] = 120;
/* 3222 */       TRANSITION[119][76] = 120;
/* 3223 */       TRANSITION[120] = arrayOfInt5;
/* 3224 */       TRANSITION[121] = copy(arrayOfInt5);
/* 3225 */       TRANSITION[121][115] = 122;
/* 3226 */       TRANSITION[121][83] = 122;
/* 3227 */       TRANSITION[122] = arrayOfInt5;
/* 3228 */       TRANSITION[123] = arrayOfInt5;
/* 3229 */       TRANSITION[124] = copy(arrayOfInt5);
/* 3230 */       TRANSITION[124][115] = 125;
/* 3231 */       TRANSITION[124][83] = 125;
/* 3232 */       TRANSITION[125] = copy(arrayOfInt5);
/* 3233 */       TRANSITION[125][99] = 126;
/* 3234 */       TRANSITION[125][67] = 126;
/* 3235 */       TRANSITION[126] = copy(arrayOfInt5);
/* 3236 */       TRANSITION[126][97] = 127;
/* 3237 */       TRANSITION[126][65] = 127;
/* 3238 */       TRANSITION[127] = copy(arrayOfInt5);
/* 3239 */       TRANSITION[127][112] = 128;
/* 3240 */       TRANSITION[127][80] = 128;
/* 3241 */       TRANSITION[128] = copy(arrayOfInt5);
/* 3242 */       TRANSITION[128][101] = 129;
/* 3243 */       TRANSITION[128][69] = 129;
/* 3244 */       TRANSITION[129] = arrayOfInt5;
/* 3245 */       TRANSITION[130] = copy(arrayOfInt5);
/* 3246 */       TRANSITION[130][110] = 131;
/* 3247 */       TRANSITION[130][78] = 131;
/* 3248 */       TRANSITION[131] = arrayOfInt5;
/* 3249 */       TRANSITION[132] = copy(arrayOfInt5);
/* 3250 */       TRANSITION[132][105] = 133;
/* 3251 */       TRANSITION[132][73] = 133;
/* 3252 */       TRANSITION[133] = copy(arrayOfInt5);
/* 3253 */       TRANSITION[133][109] = 134;
/* 3254 */       TRANSITION[133][77] = 134;
/* 3255 */       TRANSITION[134] = copy(arrayOfInt5);
/* 3256 */       TRANSITION[134][105] = 135;
/* 3257 */       TRANSITION[134][73] = 135;
/* 3258 */       TRANSITION[135] = copy(arrayOfInt5);
/* 3259 */       TRANSITION[135][116] = 136;
/* 3260 */       TRANSITION[135][84] = 136;
/* 3261 */       TRANSITION[136] = arrayOfInt5;
/* 3262 */       TRANSITION[137] = copy(arrayOfInt5);
/* 3263 */       TRANSITION[137][106] = 138;
/* 3264 */       TRANSITION[137][74] = 138;
/* 3265 */       TRANSITION[138] = arrayOfInt5;
/* 3266 */       TRANSITION[140] = copy(arrayOfInt2);
/* 3267 */       TRANSITION[140][76] = 141;
/* 3268 */       TRANSITION[140][108] = 141;
/* 3269 */       TRANSITION[141] = copy(arrayOfInt2);
/* 3270 */       TRANSITION[141][84] = 142;
/* 3271 */       TRANSITION[141][116] = 142;
/* 3272 */       TRANSITION[142] = copy(arrayOfInt2);
/* 3273 */       TRANSITION[142][69] = 143;
/* 3274 */       TRANSITION[142][101] = 143;
/* 3275 */       TRANSITION[143] = copy(arrayOfInt2);
/* 3276 */       TRANSITION[143][82] = 144;
/* 3277 */       TRANSITION[143][114] = 144;
/* 3278 */       TRANSITION[144] = copyReplacing(arrayOfInt4, 57, 145);
/* 3279 */       TRANSITION[144][47] = 153;
/* 3280 */       TRANSITION[144][45] = 156;
/*      */       
/* 3282 */       TRANSITION[145] = copyReplacing(arrayOfInt4, 57, 145);
/* 3283 */       TRANSITION[145][47] = 153;
/* 3284 */       TRANSITION[153] = copy(arrayOfInt5);
/* 3285 */       TRANSITION[153][42] = 154;
/* 3286 */       TRANSITION[154] = newArray(128, 154);
/* 3287 */       TRANSITION[154][42] = 155;
/* 3288 */       TRANSITION[155] = newArray(128, 154);
/* 3289 */       TRANSITION[155][47] = 145;
/*      */       
/* 3291 */       TRANSITION[145][45] = 156;
/* 3292 */       TRANSITION[156] = copy(arrayOfInt5);
/* 3293 */       TRANSITION[156][45] = 157;
/* 3294 */       TRANSITION[157] = newArray(128, 157);
/* 3295 */       TRANSITION[157][10] = 145;
/* 3296 */       TRANSITION[145][83] = 146;
/* 3297 */       TRANSITION[145][115] = 146;
/*      */       
/* 3299 */       TRANSITION[146] = copy(arrayOfInt2);
/* 3300 */       TRANSITION[146][69] = 147;
/* 3301 */       TRANSITION[146][101] = 147;
/* 3302 */       TRANSITION[147] = copy(arrayOfInt2);
/* 3303 */       TRANSITION[147][83] = 148;
/* 3304 */       TRANSITION[147][115] = 148;
/* 3305 */       TRANSITION[148] = copy(arrayOfInt2);
/* 3306 */       TRANSITION[148][83] = 149;
/* 3307 */       TRANSITION[148][115] = 149;
/* 3308 */       TRANSITION[149] = copy(arrayOfInt2);
/* 3309 */       TRANSITION[149][73] = 150;
/* 3310 */       TRANSITION[149][105] = 150;
/* 3311 */       TRANSITION[150] = copy(arrayOfInt2);
/* 3312 */       TRANSITION[150][79] = 151;
/* 3313 */       TRANSITION[150][111] = 151;
/* 3314 */       TRANSITION[151] = copy(arrayOfInt2);
/* 3315 */       TRANSITION[151][78] = 152;
/* 3316 */       TRANSITION[151][110] = 152;
/* 3317 */       TRANSITION[152] = arrayOfInt5;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 3324 */       int[] arrayOfInt7 = newArray(128, 0);
/*      */       
/* 3326 */       int[] arrayOfInt8 = copy(arrayOfInt7);
/* 3327 */       arrayOfInt8[63] = 14;
/*      */       
/* 3329 */       int[] arrayOfInt9 = copy(arrayOfInt8);
/* 3330 */       arrayOfInt9[123] = 5;
/*      */       
/* 3332 */       int[] arrayOfInt10 = new int[128];
/*      */       
/* 3334 */       for (byte b1 = 0; b1 < arrayOfInt10.length; b1++) {
/* 3335 */         if (TRANSITION[8][b1] == 8) {
/* 3336 */           arrayOfInt10[b1] = 15;
/*      */         } else {
/* 3338 */           arrayOfInt10[b1] = 16;
/*      */         } 
/* 3340 */       }  int[] arrayOfInt11 = new int[128];
/*      */       
/* 3342 */       for (byte b2 = 0; b2 < arrayOfInt11.length; b2++) {
/* 3343 */         if (TRANSITION[65][b2] == 65) {
/* 3344 */           arrayOfInt11[b2] = 15;
/*      */         } else {
/* 3346 */           arrayOfInt11[b2] = 16;
/*      */         } 
/* 3348 */       }  int[] arrayOfInt12 = copy(arrayOfInt11);
/* 3349 */       arrayOfInt12[32] = 0;
/* 3350 */       arrayOfInt12[10] = 0;
/* 3351 */       arrayOfInt12[9] = 0;
/* 3352 */       arrayOfInt12[13] = 0;
/*      */       
/* 3354 */       int[] arrayOfInt13 = copy(arrayOfInt7);
/*      */       
/* 3356 */       for (byte b3 = 0; b3 < arrayOfInt13.length; b3++) {
/* 3357 */         if (arrayOfInt4[b3] != 66)
/* 3358 */           arrayOfInt13[b3] = 5; 
/*      */       } 
/* 3360 */       int[] arrayOfInt14 = copyReplacing(arrayOfInt13, 5, 6);
/* 3361 */       int[] arrayOfInt15 = copyReplacing(arrayOfInt13, 5, 1);
/* 3362 */       int[] arrayOfInt16 = copyReplacing(arrayOfInt13, 5, 2);
/* 3363 */       int[] arrayOfInt17 = copyReplacing(arrayOfInt13, 5, 3);
/* 3364 */       int[] arrayOfInt18 = copyReplacing(arrayOfInt13, 5, 4);
/* 3365 */       int[] arrayOfInt19 = copyReplacing(arrayOfInt13, 5, 7);
/* 3366 */       int[] arrayOfInt20 = copyReplacing(arrayOfInt13, 5, 8);
/* 3367 */       arrayOfInt20[123] = 6;
/*      */       
/* 3369 */       int[] arrayOfInt21 = copyReplacing(arrayOfInt13, 5, 10);
/*      */       
/* 3371 */       for (byte b6 = 0; b6 < arrayOfInt21.length; b6++) {
/* 3372 */         if (arrayOfInt21[b6] == 8) {
/* 3373 */           arrayOfInt21[b6] = 0;
/*      */         }
/*      */       } 
/* 3376 */       int[] arrayOfInt22 = copyReplacing(arrayOfInt21, 10, 11);
/* 3377 */       int[] arrayOfInt23 = copyReplacing(arrayOfInt21, 10, 9);
/* 3378 */       int[] arrayOfInt24 = copyReplacing(arrayOfInt21, 10, 12);
/* 3379 */       int[] arrayOfInt25 = copyReplacing(arrayOfInt21, 10, 13);
/* 3380 */       int[] arrayOfInt26 = copyReplacing(arrayOfInt21, 10, 21);
/* 3381 */       int[] arrayOfInt27 = copyReplacing(arrayOfInt21, 10, 22);
/* 3382 */       int[] arrayOfInt28 = copyReplacing(arrayOfInt21, 10, 23);
/*      */       
/* 3384 */       int[] arrayOfInt29 = copy(arrayOfInt7);
/* 3385 */       arrayOfInt29[39] = 17;
/*      */       
/* 3387 */       int[] arrayOfInt30 = copyReplacing(arrayOfInt7, 0, 18);
/* 3388 */       arrayOfInt30[39] = 0;
/*      */       
/* 3390 */       int[] arrayOfInt31 = copyReplacing(arrayOfInt7, 0, 19);
/*      */       
/* 3392 */       int[] arrayOfInt32 = copyReplacing(arrayOfInt7, 0, 20);
/*      */       
/* 3394 */       int[] arrayOfInt33 = copy(arrayOfInt32);
/* 3395 */       arrayOfInt33[39] = 0;
/*      */       
/* 3397 */       ACTION[0] = arrayOfInt9;
/* 3398 */       ACTION[1] = arrayOfInt9;
/* 3399 */       ACTION[2] = arrayOfInt9;
/* 3400 */       ACTION[3] = arrayOfInt7;
/* 3401 */       ACTION[4] = arrayOfInt7;
/* 3402 */       ACTION[5] = arrayOfInt7;
/* 3403 */       ACTION[6] = arrayOfInt7;
/* 3404 */       ACTION[7] = arrayOfInt7;
/* 3405 */       ACTION[8] = arrayOfInt10;
/* 3406 */       ACTION[139] = arrayOfInt12;
/* 3407 */       ACTION[100] = arrayOfInt29;
/* 3408 */       ACTION[101] = arrayOfInt30;
/* 3409 */       ACTION[105] = arrayOfInt7;
/* 3410 */       ACTION[106] = arrayOfInt31;
/* 3411 */       ACTION[107] = arrayOfInt32;
/* 3412 */       ACTION[108] = null;
/* 3413 */       ACTION[109] = arrayOfInt33;
/* 3414 */       ACTION[9] = arrayOfInt20;
/* 3415 */       ACTION[10] = arrayOfInt20;
/* 3416 */       ACTION[11] = arrayOfInt20;
/* 3417 */       ACTION[12] = arrayOfInt20;
/* 3418 */       ACTION[13] = arrayOfInt20;
/* 3419 */       ACTION[14] = arrayOfInt13;
/* 3420 */       ACTION[15] = arrayOfInt20;
/* 3421 */       ACTION[16] = arrayOfInt20;
/* 3422 */       ACTION[17] = arrayOfInt20;
/* 3423 */       ACTION[18] = arrayOfInt14;
/* 3424 */       ACTION[19] = arrayOfInt20;
/* 3425 */       ACTION[20] = arrayOfInt20;
/* 3426 */       ACTION[21] = arrayOfInt20;
/* 3427 */       ACTION[22] = arrayOfInt20;
/* 3428 */       ACTION[23] = arrayOfInt20;
/* 3429 */       ACTION[24] = arrayOfInt20;
/* 3430 */       ACTION[25] = arrayOfInt13;
/* 3431 */       ACTION[26] = arrayOfInt20;
/* 3432 */       ACTION[27] = arrayOfInt20;
/* 3433 */       ACTION[28] = arrayOfInt20;
/* 3434 */       ACTION[29] = arrayOfInt15;
/* 3435 */       ACTION[30] = arrayOfInt20;
/* 3436 */       ACTION[31] = arrayOfInt20;
/* 3437 */       ACTION[32] = arrayOfInt20;
/* 3438 */       ACTION[33] = arrayOfInt20;
/* 3439 */       ACTION[34] = arrayOfInt20;
/* 3440 */       ACTION[35] = arrayOfInt16;
/* 3441 */       ACTION[36] = arrayOfInt20;
/* 3442 */       ACTION[37] = arrayOfInt20;
/* 3443 */       ACTION[38] = arrayOfInt20;
/* 3444 */       ACTION[39] = arrayOfInt20;
/* 3445 */       ACTION[40] = arrayOfInt20;
/* 3446 */       ACTION[41] = arrayOfInt19;
/* 3447 */       ACTION[42] = arrayOfInt20;
/* 3448 */       ACTION[43] = arrayOfInt20;
/* 3449 */       ACTION[44] = arrayOfInt20;
/* 3450 */       ACTION[45] = arrayOfInt20;
/* 3451 */       ACTION[46] = arrayOfInt20;
/* 3452 */       ACTION[47] = arrayOfInt18;
/* 3453 */       ACTION[48] = arrayOfInt20;
/* 3454 */       ACTION[49] = arrayOfInt20;
/* 3455 */       ACTION[50] = arrayOfInt20;
/* 3456 */       ACTION[51] = arrayOfInt20;
/* 3457 */       ACTION[52] = arrayOfInt17;
/* 3458 */       ACTION[53] = arrayOfInt20;
/* 3459 */       ACTION[54] = arrayOfInt20;
/* 3460 */       ACTION[55] = arrayOfInt20;
/* 3461 */       ACTION[56] = arrayOfInt19;
/* 3462 */       ACTION[66] = arrayOfInt8;
/* 3463 */       ACTION[58] = arrayOfInt8;
/* 3464 */       ACTION[59] = arrayOfInt8;
/* 3465 */       ACTION[60] = arrayOfInt7;
/* 3466 */       ACTION[61] = arrayOfInt7;
/* 3467 */       ACTION[62] = arrayOfInt7;
/* 3468 */       ACTION[63] = arrayOfInt7;
/* 3469 */       ACTION[64] = arrayOfInt7;
/* 3470 */       ACTION[65] = arrayOfInt11;
/* 3471 */       ACTION[102] = arrayOfInt29;
/* 3472 */       ACTION[103] = arrayOfInt7;
/* 3473 */       ACTION[104] = arrayOfInt30;
/* 3474 */       ACTION[110] = arrayOfInt7;
/* 3475 */       ACTION[111] = arrayOfInt31;
/* 3476 */       ACTION[112] = arrayOfInt32;
/* 3477 */       ACTION[113] = null;
/* 3478 */       ACTION[114] = arrayOfInt33;
/*      */       
/* 3480 */       ACTION[57] = arrayOfInt8;
/*      */       
/* 3482 */       ACTION[67] = arrayOfInt7;
/* 3483 */       ACTION[68] = arrayOfInt7;
/* 3484 */       ACTION[69] = arrayOfInt7;
/* 3485 */       ACTION[70] = arrayOfInt7;
/* 3486 */       ACTION[71] = arrayOfInt23;
/*      */       
/* 3488 */       ACTION[72] = arrayOfInt7;
/* 3489 */       ACTION[73] = arrayOfInt7;
/* 3490 */       ACTION[74] = arrayOfInt7;
/* 3491 */       ACTION[75] = arrayOfInt7;
/* 3492 */       ACTION[76] = arrayOfInt21;
/*      */       
/* 3494 */       ACTION[77] = arrayOfInt7;
/* 3495 */       ACTION[78] = arrayOfInt7;
/* 3496 */       ACTION[79] = arrayOfInt22;
/*      */       
/* 3498 */       ACTION[80] = arrayOfInt7;
/* 3499 */       ACTION[81] = arrayOfInt7;
/* 3500 */       ACTION[82] = arrayOfInt7;
/* 3501 */       ACTION[83] = arrayOfInt7;
/* 3502 */       ACTION[84] = arrayOfInt7;
/*      */       
/* 3504 */       ACTION[85] = arrayOfInt7;
/* 3505 */       ACTION[86] = arrayOfInt7;
/* 3506 */       ACTION[87] = arrayOfInt24;
/*      */       
/* 3508 */       ACTION[88] = arrayOfInt8;
/* 3509 */       ACTION[89] = arrayOfInt7;
/* 3510 */       ACTION[90] = arrayOfInt7;
/* 3511 */       ACTION[91] = arrayOfInt7;
/* 3512 */       ACTION[92] = arrayOfInt7;
/* 3513 */       ACTION[93] = arrayOfInt7;
/* 3514 */       ACTION[94] = arrayOfInt25;
/*      */       
/* 3516 */       ACTION[95] = arrayOfInt7;
/* 3517 */       ACTION[96] = arrayOfInt7;
/* 3518 */       ACTION[97] = arrayOfInt7;
/* 3519 */       ACTION[98] = arrayOfInt7;
/* 3520 */       ACTION[99] = arrayOfInt7;
/*      */       
/* 3522 */       ACTION[115] = copy(arrayOfInt7);
/* 3523 */       ACTION[115][63] = 14;
/* 3524 */       ACTION[116] = arrayOfInt7;
/* 3525 */       ACTION[117] = arrayOfInt7;
/* 3526 */       ACTION[118] = arrayOfInt7;
/* 3527 */       ACTION[119] = arrayOfInt7;
/* 3528 */       ACTION[120] = arrayOfInt7;
/* 3529 */       ACTION[121] = arrayOfInt7;
/* 3530 */       ACTION[122] = arrayOfInt7;
/* 3531 */       ACTION[123] = arrayOfInt7;
/* 3532 */       ACTION[124] = arrayOfInt7;
/* 3533 */       ACTION[125] = arrayOfInt7;
/* 3534 */       ACTION[126] = arrayOfInt7;
/* 3535 */       ACTION[127] = arrayOfInt7;
/* 3536 */       ACTION[128] = arrayOfInt7;
/* 3537 */       ACTION[129] = arrayOfInt7;
/* 3538 */       ACTION[130] = arrayOfInt7;
/* 3539 */       ACTION[131] = arrayOfInt7;
/* 3540 */       ACTION[132] = arrayOfInt7;
/* 3541 */       ACTION[133] = arrayOfInt7;
/* 3542 */       ACTION[134] = arrayOfInt7;
/* 3543 */       ACTION[135] = arrayOfInt7;
/* 3544 */       ACTION[136] = arrayOfInt7;
/* 3545 */       ACTION[137] = arrayOfInt7;
/* 3546 */       ACTION[138] = arrayOfInt7;
/*      */       
/* 3548 */       ACTION[140] = arrayOfInt7;
/* 3549 */       ACTION[141] = arrayOfInt7;
/* 3550 */       ACTION[142] = arrayOfInt7;
/* 3551 */       ACTION[143] = arrayOfInt7;
/* 3552 */       ACTION[144] = arrayOfInt20;
/*      */       
/* 3554 */       ACTION[145] = arrayOfInt8;
/* 3555 */       ACTION[146] = arrayOfInt7;
/* 3556 */       ACTION[147] = arrayOfInt7;
/* 3557 */       ACTION[148] = arrayOfInt7;
/* 3558 */       ACTION[149] = arrayOfInt7;
/* 3559 */       ACTION[150] = arrayOfInt7;
/* 3560 */       ACTION[151] = arrayOfInt7;
/* 3561 */       ACTION[152] = arrayOfInt26;
/*      */       
/* 3563 */       ACTION[153] = arrayOfInt7;
/* 3564 */       ACTION[154] = arrayOfInt7;
/* 3565 */       ACTION[155] = arrayOfInt7;
/* 3566 */       ACTION[156] = arrayOfInt7;
/* 3567 */       ACTION[157] = arrayOfInt7;
/*      */       
/* 3569 */       ACTION[158] = arrayOfInt7;
/* 3570 */       ACTION[159] = arrayOfInt7;
/* 3571 */       ACTION[160] = arrayOfInt7;
/* 3572 */       ACTION[161] = arrayOfInt7;
/* 3573 */       ACTION[162] = arrayOfInt7;
/* 3574 */       ACTION[163] = arrayOfInt7;
/* 3575 */       ACTION[164] = arrayOfInt7;
/* 3576 */       ACTION[165] = arrayOfInt7;
/* 3577 */       ACTION[166] = arrayOfInt27;
/*      */       
/* 3579 */       ACTION[167] = arrayOfInt7;
/* 3580 */       ACTION[168] = arrayOfInt7;
/* 3581 */       ACTION[169] = arrayOfInt7;
/* 3582 */       ACTION[170] = arrayOfInt28;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 3590 */       ODBCAction[] arrayOfODBCAction1 = newArray(128, ODBCAction.NONE);
/*      */       
/* 3592 */       ODBCAction[] arrayOfODBCAction2 = newArray(128, ODBCAction.COPY);
/*      */       
/* 3594 */       ODBCAction[] arrayOfODBCAction3 = copy(arrayOfODBCAction2);
/* 3595 */       arrayOfODBCAction3[123] = ODBCAction.NONE;
/* 3596 */       arrayOfODBCAction3[63] = ODBCAction.QUESTION;
/* 3597 */       arrayOfODBCAction3[125] = ODBCAction.END_ODBC_ESCAPE;
/* 3598 */       arrayOfODBCAction3[44] = ODBCAction.COMMA;
/* 3599 */       arrayOfODBCAction3[40] = ODBCAction.OPEN_PAREN;
/* 3600 */       arrayOfODBCAction3[41] = ODBCAction.CLOSE_PAREN;
/*      */       
/* 3602 */       ODBCAction[] arrayOfODBCAction4 = copyReplacing(arrayOfODBCAction2, ODBCAction.COPY, ODBCAction.SAVE_DELIMITER);
/*      */       
/* 3604 */       ODBCAction[] arrayOfODBCAction5 = copyReplacing(arrayOfODBCAction2, ODBCAction.COPY, ODBCAction.LOOK_FOR_DELIMITER);
/*      */       
/* 3606 */       ODBCAction[] arrayOfODBCAction6 = copy(arrayOfODBCAction5);
/* 3607 */       arrayOfODBCAction6[39] = ODBCAction.COPY;
/*      */       
/* 3609 */       ODBCAction[] arrayOfODBCAction7 = newArray(128, ODBCAction.UNKNOWN_ESCAPE);
/*      */       
/* 3611 */       ODBCAction[] arrayOfODBCAction8 = copy(arrayOfODBCAction1);
/* 3612 */       for (byte b4 = 0; b4 < arrayOfInt1.length; b4++) {
/* 3613 */         if (arrayOfInt1[b4] == 9) arrayOfODBCAction8[b4] = ODBCAction.UNKNOWN_ESCAPE;
/*      */       
/*      */       } 
/* 3616 */       ODBCAction[] arrayOfODBCAction9 = copy(arrayOfODBCAction3);
/* 3617 */       for (byte b5 = 0; b5 < arrayOfInt1.length; b5++) {
/* 3618 */         if (arrayOfInt1[b5] != 9) arrayOfODBCAction9[b5] = ODBCAction.BEGIN;
/*      */       
/*      */       } 
/* 3621 */       ODBC_ACTION[0] = arrayOfODBCAction3;
/* 3622 */       ODBC_ACTION[1] = arrayOfODBCAction3;
/* 3623 */       ODBC_ACTION[2] = arrayOfODBCAction3;
/* 3624 */       ODBC_ACTION[3] = arrayOfODBCAction2;
/* 3625 */       ODBC_ACTION[4] = arrayOfODBCAction3;
/* 3626 */       ODBC_ACTION[5] = arrayOfODBCAction2;
/* 3627 */       ODBC_ACTION[6] = arrayOfODBCAction2;
/* 3628 */       ODBC_ACTION[7] = arrayOfODBCAction2;
/* 3629 */       ODBC_ACTION[8] = arrayOfODBCAction3;
/* 3630 */       ODBC_ACTION[139] = arrayOfODBCAction3;
/* 3631 */       ODBC_ACTION[100] = arrayOfODBCAction2;
/* 3632 */       ODBC_ACTION[101] = arrayOfODBCAction2;
/* 3633 */       ODBC_ACTION[105] = arrayOfODBCAction2;
/* 3634 */       ODBC_ACTION[106] = arrayOfODBCAction4;
/* 3635 */       ODBC_ACTION[107] = arrayOfODBCAction5;
/* 3636 */       ODBC_ACTION[108] = null;
/* 3637 */       ODBC_ACTION[109] = arrayOfODBCAction6;
/* 3638 */       ODBC_ACTION[9] = arrayOfODBCAction3;
/* 3639 */       ODBC_ACTION[10] = arrayOfODBCAction3;
/* 3640 */       ODBC_ACTION[11] = arrayOfODBCAction3;
/* 3641 */       ODBC_ACTION[12] = arrayOfODBCAction3;
/* 3642 */       ODBC_ACTION[13] = arrayOfODBCAction3;
/* 3643 */       ODBC_ACTION[14] = arrayOfODBCAction9;
/* 3644 */       ODBC_ACTION[15] = arrayOfODBCAction3;
/* 3645 */       ODBC_ACTION[16] = arrayOfODBCAction3;
/* 3646 */       ODBC_ACTION[17] = arrayOfODBCAction3;
/* 3647 */       ODBC_ACTION[18] = arrayOfODBCAction3;
/* 3648 */       ODBC_ACTION[19] = arrayOfODBCAction3;
/* 3649 */       ODBC_ACTION[20] = arrayOfODBCAction3;
/* 3650 */       ODBC_ACTION[21] = arrayOfODBCAction3;
/* 3651 */       ODBC_ACTION[22] = arrayOfODBCAction3;
/* 3652 */       ODBC_ACTION[23] = arrayOfODBCAction3;
/* 3653 */       ODBC_ACTION[24] = arrayOfODBCAction3;
/* 3654 */       ODBC_ACTION[25] = arrayOfODBCAction3;
/* 3655 */       ODBC_ACTION[26] = arrayOfODBCAction3;
/* 3656 */       ODBC_ACTION[27] = arrayOfODBCAction3;
/* 3657 */       ODBC_ACTION[28] = arrayOfODBCAction3;
/* 3658 */       ODBC_ACTION[29] = arrayOfODBCAction3;
/* 3659 */       ODBC_ACTION[30] = arrayOfODBCAction3;
/* 3660 */       ODBC_ACTION[31] = arrayOfODBCAction3;
/* 3661 */       ODBC_ACTION[32] = arrayOfODBCAction3;
/* 3662 */       ODBC_ACTION[33] = arrayOfODBCAction3;
/* 3663 */       ODBC_ACTION[34] = arrayOfODBCAction3;
/* 3664 */       ODBC_ACTION[35] = arrayOfODBCAction3;
/* 3665 */       ODBC_ACTION[36] = arrayOfODBCAction3;
/* 3666 */       ODBC_ACTION[37] = arrayOfODBCAction3;
/* 3667 */       ODBC_ACTION[38] = arrayOfODBCAction3;
/* 3668 */       ODBC_ACTION[39] = arrayOfODBCAction3;
/* 3669 */       ODBC_ACTION[40] = arrayOfODBCAction3;
/* 3670 */       ODBC_ACTION[41] = arrayOfODBCAction3;
/* 3671 */       ODBC_ACTION[42] = arrayOfODBCAction3;
/* 3672 */       ODBC_ACTION[43] = arrayOfODBCAction3;
/* 3673 */       ODBC_ACTION[44] = arrayOfODBCAction3;
/* 3674 */       ODBC_ACTION[45] = arrayOfODBCAction3;
/* 3675 */       ODBC_ACTION[46] = arrayOfODBCAction3;
/* 3676 */       ODBC_ACTION[47] = arrayOfODBCAction3;
/* 3677 */       ODBC_ACTION[48] = arrayOfODBCAction3;
/* 3678 */       ODBC_ACTION[49] = arrayOfODBCAction3;
/* 3679 */       ODBC_ACTION[50] = arrayOfODBCAction3;
/* 3680 */       ODBC_ACTION[51] = arrayOfODBCAction3;
/* 3681 */       ODBC_ACTION[52] = arrayOfODBCAction3;
/* 3682 */       ODBC_ACTION[53] = arrayOfODBCAction3;
/* 3683 */       ODBC_ACTION[54] = arrayOfODBCAction3;
/* 3684 */       ODBC_ACTION[55] = arrayOfODBCAction3;
/* 3685 */       ODBC_ACTION[56] = arrayOfODBCAction3;
/* 3686 */       ODBC_ACTION[66] = arrayOfODBCAction3;
/* 3687 */       ODBC_ACTION[58] = arrayOfODBCAction3;
/* 3688 */       ODBC_ACTION[59] = arrayOfODBCAction3;
/* 3689 */       ODBC_ACTION[60] = arrayOfODBCAction2;
/* 3690 */       ODBC_ACTION[61] = arrayOfODBCAction2;
/* 3691 */       ODBC_ACTION[62] = arrayOfODBCAction2;
/* 3692 */       ODBC_ACTION[63] = arrayOfODBCAction2;
/* 3693 */       ODBC_ACTION[64] = arrayOfODBCAction2;
/* 3694 */       ODBC_ACTION[65] = arrayOfODBCAction3;
/* 3695 */       ODBC_ACTION[102] = arrayOfODBCAction2;
/* 3696 */       ODBC_ACTION[103] = arrayOfODBCAction2;
/* 3697 */       ODBC_ACTION[104] = arrayOfODBCAction2;
/* 3698 */       ODBC_ACTION[110] = arrayOfODBCAction2;
/* 3699 */       ODBC_ACTION[111] = arrayOfODBCAction4;
/* 3700 */       ODBC_ACTION[112] = arrayOfODBCAction5;
/* 3701 */       ODBC_ACTION[113] = null;
/* 3702 */       ODBC_ACTION[114] = arrayOfODBCAction6;
/*      */       
/* 3704 */       ODBC_ACTION[57] = arrayOfODBCAction3;
/*      */       
/* 3706 */       ODBC_ACTION[67] = arrayOfODBCAction3;
/* 3707 */       ODBC_ACTION[68] = arrayOfODBCAction3;
/* 3708 */       ODBC_ACTION[69] = arrayOfODBCAction3;
/* 3709 */       ODBC_ACTION[70] = arrayOfODBCAction3;
/* 3710 */       ODBC_ACTION[71] = arrayOfODBCAction3;
/*      */       
/* 3712 */       ODBC_ACTION[72] = arrayOfODBCAction3;
/* 3713 */       ODBC_ACTION[73] = arrayOfODBCAction3;
/* 3714 */       ODBC_ACTION[74] = arrayOfODBCAction3;
/* 3715 */       ODBC_ACTION[75] = arrayOfODBCAction3;
/* 3716 */       ODBC_ACTION[76] = arrayOfODBCAction3;
/*      */       
/* 3718 */       ODBC_ACTION[77] = arrayOfODBCAction3;
/* 3719 */       ODBC_ACTION[78] = arrayOfODBCAction3;
/* 3720 */       ODBC_ACTION[79] = arrayOfODBCAction3;
/*      */       
/* 3722 */       ODBC_ACTION[80] = arrayOfODBCAction3;
/* 3723 */       ODBC_ACTION[81] = arrayOfODBCAction3;
/* 3724 */       ODBC_ACTION[82] = arrayOfODBCAction3;
/* 3725 */       ODBC_ACTION[83] = arrayOfODBCAction3;
/* 3726 */       ODBC_ACTION[84] = arrayOfODBCAction3;
/*      */       
/* 3728 */       ODBC_ACTION[85] = arrayOfODBCAction3;
/* 3729 */       ODBC_ACTION[86] = arrayOfODBCAction3;
/* 3730 */       ODBC_ACTION[87] = arrayOfODBCAction3;
/*      */       
/* 3732 */       ODBC_ACTION[88] = arrayOfODBCAction3;
/* 3733 */       ODBC_ACTION[89] = arrayOfODBCAction3;
/* 3734 */       ODBC_ACTION[90] = arrayOfODBCAction3;
/* 3735 */       ODBC_ACTION[91] = arrayOfODBCAction3;
/* 3736 */       ODBC_ACTION[92] = arrayOfODBCAction3;
/* 3737 */       ODBC_ACTION[93] = arrayOfODBCAction3;
/* 3738 */       ODBC_ACTION[94] = arrayOfODBCAction3;
/*      */       
/* 3740 */       ODBC_ACTION[95] = arrayOfODBCAction3;
/* 3741 */       ODBC_ACTION[96] = arrayOfODBCAction3;
/* 3742 */       ODBC_ACTION[97] = arrayOfODBCAction3;
/* 3743 */       ODBC_ACTION[98] = arrayOfODBCAction3;
/* 3744 */       ODBC_ACTION[99] = arrayOfODBCAction3;
/*      */       
/* 3746 */       ODBC_ACTION[115] = copy(arrayOfODBCAction8);
/* 3747 */       ODBC_ACTION[115][63] = ODBCAction.NONE;
/* 3748 */       ODBC_ACTION[115][99] = ODBCAction.NONE;
/* 3749 */       ODBC_ACTION[115][67] = ODBCAction.NONE;
/* 3750 */       ODBC_ACTION[115][116] = ODBCAction.NONE;
/* 3751 */       ODBC_ACTION[115][84] = ODBCAction.NONE;
/* 3752 */       ODBC_ACTION[115][100] = ODBCAction.NONE;
/* 3753 */       ODBC_ACTION[115][68] = ODBCAction.NONE;
/* 3754 */       ODBC_ACTION[115][101] = ODBCAction.NONE;
/* 3755 */       ODBC_ACTION[115][69] = ODBCAction.NONE;
/* 3756 */       ODBC_ACTION[115][102] = ODBCAction.NONE;
/* 3757 */       ODBC_ACTION[115][70] = ODBCAction.NONE;
/* 3758 */       ODBC_ACTION[115][111] = ODBCAction.NONE;
/* 3759 */       ODBC_ACTION[115][79] = ODBCAction.NONE;
/* 3760 */       ODBC_ACTION[116] = newArray(128, ODBCAction.FUNCTION);
/* 3761 */       ODBC_ACTION[117] = copy(arrayOfODBCAction7);
/* 3762 */       ODBC_ACTION[117][97] = ODBCAction.NONE;
/* 3763 */       ODBC_ACTION[117][65] = ODBCAction.NONE;
/* 3764 */       ODBC_ACTION[118] = copy(arrayOfODBCAction7);
/* 3765 */       ODBC_ACTION[118][108] = ODBCAction.NONE;
/* 3766 */       ODBC_ACTION[118][76] = ODBCAction.NONE;
/* 3767 */       ODBC_ACTION[119] = copy(arrayOfODBCAction7);
/* 3768 */       ODBC_ACTION[119][108] = ODBCAction.NONE;
/* 3769 */       ODBC_ACTION[119][76] = ODBCAction.NONE;
/* 3770 */       ODBC_ACTION[120] = copyReplacing(arrayOfODBCAction8, ODBCAction.NONE, ODBCAction.CALL);
/* 3771 */       ODBC_ACTION[121] = copyReplacing(arrayOfODBCAction8, ODBCAction.NONE, ODBCAction.TIME);
/* 3772 */       ODBC_ACTION[121][115] = ODBCAction.NONE;
/* 3773 */       ODBC_ACTION[121][83] = ODBCAction.NONE;
/* 3774 */       ODBC_ACTION[122] = copyReplacing(arrayOfODBCAction8, ODBCAction.NONE, ODBCAction.TIMESTAMP);
/* 3775 */       ODBC_ACTION[123] = copyReplacing(arrayOfODBCAction8, ODBCAction.NONE, ODBCAction.DATE);
/* 3776 */       ODBC_ACTION[124] = copy(arrayOfODBCAction7);
/* 3777 */       ODBC_ACTION[124][115] = ODBCAction.NONE;
/* 3778 */       ODBC_ACTION[124][83] = ODBCAction.NONE;
/* 3779 */       ODBC_ACTION[125] = copy(arrayOfODBCAction7);
/* 3780 */       ODBC_ACTION[125][99] = ODBCAction.NONE;
/* 3781 */       ODBC_ACTION[125][67] = ODBCAction.NONE;
/* 3782 */       ODBC_ACTION[126] = copy(arrayOfODBCAction7);
/* 3783 */       ODBC_ACTION[126][97] = ODBCAction.NONE;
/* 3784 */       ODBC_ACTION[126][65] = ODBCAction.NONE;
/* 3785 */       ODBC_ACTION[127] = copy(arrayOfODBCAction7);
/* 3786 */       ODBC_ACTION[127][112] = ODBCAction.NONE;
/* 3787 */       ODBC_ACTION[127][80] = ODBCAction.NONE;
/* 3788 */       ODBC_ACTION[128] = copy(arrayOfODBCAction7);
/* 3789 */       ODBC_ACTION[128][101] = ODBCAction.NONE;
/* 3790 */       ODBC_ACTION[128][69] = ODBCAction.NONE;
/* 3791 */       ODBC_ACTION[129] = copyReplacing(arrayOfODBCAction8, ODBCAction.NONE, ODBCAction.ESCAPE);
/* 3792 */       ODBC_ACTION[130] = copy(arrayOfODBCAction7);
/* 3793 */       ODBC_ACTION[130][110] = ODBCAction.NONE;
/* 3794 */       ODBC_ACTION[130][78] = ODBCAction.NONE;
/* 3795 */       ODBC_ACTION[131] = copyReplacing(arrayOfODBCAction8, ODBCAction.NONE, ODBCAction.SCALAR_FUNCTION);
/* 3796 */       ODBC_ACTION[132] = copy(arrayOfODBCAction7);
/* 3797 */       ODBC_ACTION[132][105] = ODBCAction.NONE;
/* 3798 */       ODBC_ACTION[132][73] = ODBCAction.NONE;
/* 3799 */       ODBC_ACTION[133] = copy(arrayOfODBCAction7);
/* 3800 */       ODBC_ACTION[133][109] = ODBCAction.NONE;
/* 3801 */       ODBC_ACTION[133][77] = ODBCAction.NONE;
/* 3802 */       ODBC_ACTION[134] = copy(arrayOfODBCAction7);
/* 3803 */       ODBC_ACTION[134][105] = ODBCAction.NONE;
/* 3804 */       ODBC_ACTION[134][73] = ODBCAction.NONE;
/* 3805 */       ODBC_ACTION[135] = copy(arrayOfODBCAction7);
/* 3806 */       ODBC_ACTION[135][116] = ODBCAction.NONE;
/* 3807 */       ODBC_ACTION[135][84] = ODBCAction.NONE;
/* 3808 */       ODBC_ACTION[136] = copyReplacing(arrayOfODBCAction8, ODBCAction.NONE, ODBCAction.LIMIT);
/* 3809 */       ODBC_ACTION[137] = copy(arrayOfODBCAction7);
/* 3810 */       ODBC_ACTION[137][106] = ODBCAction.NONE;
/* 3811 */       ODBC_ACTION[137][74] = ODBCAction.NONE;
/* 3812 */       ODBC_ACTION[138] = copyReplacing(arrayOfODBCAction8, ODBCAction.NONE, ODBCAction.OUTER_JOIN);
/*      */       
/* 3814 */       ODBC_ACTION[140] = arrayOfODBCAction3;
/* 3815 */       ODBC_ACTION[141] = arrayOfODBCAction3;
/* 3816 */       ODBC_ACTION[142] = arrayOfODBCAction3;
/* 3817 */       ODBC_ACTION[143] = arrayOfODBCAction3;
/* 3818 */       ODBC_ACTION[144] = arrayOfODBCAction3;
/*      */       
/* 3820 */       ODBC_ACTION[145] = arrayOfODBCAction3;
/* 3821 */       ODBC_ACTION[146] = arrayOfODBCAction3;
/* 3822 */       ODBC_ACTION[147] = arrayOfODBCAction3;
/* 3823 */       ODBC_ACTION[148] = arrayOfODBCAction3;
/* 3824 */       ODBC_ACTION[149] = arrayOfODBCAction3;
/* 3825 */       ODBC_ACTION[150] = arrayOfODBCAction3;
/* 3826 */       ODBC_ACTION[151] = arrayOfODBCAction3;
/* 3827 */       ODBC_ACTION[152] = arrayOfODBCAction3;
/*      */       
/* 3829 */       ODBC_ACTION[153] = arrayOfODBCAction3;
/* 3830 */       ODBC_ACTION[154] = arrayOfODBCAction3;
/* 3831 */       ODBC_ACTION[155] = arrayOfODBCAction3;
/* 3832 */       ODBC_ACTION[156] = arrayOfODBCAction3;
/* 3833 */       ODBC_ACTION[157] = arrayOfODBCAction3;
/*      */       
/* 3835 */       ODBC_ACTION[158] = arrayOfODBCAction3;
/* 3836 */       ODBC_ACTION[159] = arrayOfODBCAction3;
/* 3837 */       ODBC_ACTION[160] = arrayOfODBCAction3;
/* 3838 */       ODBC_ACTION[161] = arrayOfODBCAction3;
/* 3839 */       ODBC_ACTION[162] = arrayOfODBCAction3;
/* 3840 */       ODBC_ACTION[163] = arrayOfODBCAction3;
/* 3841 */       ODBC_ACTION[164] = arrayOfODBCAction3;
/* 3842 */       ODBC_ACTION[165] = arrayOfODBCAction3;
/* 3843 */       ODBC_ACTION[166] = arrayOfODBCAction3;
/*      */       
/* 3845 */       ODBC_ACTION[167] = arrayOfODBCAction3;
/* 3846 */       ODBC_ACTION[168] = arrayOfODBCAction3;
/* 3847 */       ODBC_ACTION[169] = arrayOfODBCAction3;
/* 3848 */       ODBC_ACTION[170] = arrayOfODBCAction3;
/*      */     } catch (Throwable throwable) {
/* 3850 */       throwable.printStackTrace();
/*      */     } 
/*      */   }
/*      */ }


/* Location:              C:\Users\olatu\OneDrive\Documents\Calypso\syncbase\sync_base.jar!\BOOT-INF\classes\ojdbc.jar!\oracle\jdbc\driver\OracleSqlReadOnly.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */