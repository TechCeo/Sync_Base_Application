/*     */ package oracle.jdbc.driver;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ import java.sql.SQLException;
/*     */ import oracle.jdbc.internal.OracleClob;
/*     */ import oracle.jdbc.internal.OracleConnection;
/*     */ import oracle.sql.CLOB;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class OracleClobOutputStream
/*     */   extends OutputStream
/*     */ {
/*     */   long lobOffset;
/*     */   OracleClob clob;
/*     */   byte[] buf;
/*     */   int count;
/*     */   int bufSize;
/*     */   boolean isClosed;
/*     */   
/*     */   public OracleClobOutputStream(CLOB paramCLOB, int paramInt) throws SQLException {
/*  46 */     this((OracleClob)paramCLOB, paramInt);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public OracleClobOutputStream(OracleClob paramOracleClob, int paramInt) throws SQLException {
/*  57 */     this(paramOracleClob, paramInt, 1L);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public OracleClobOutputStream(CLOB paramCLOB, int paramInt, long paramLong) throws SQLException {
/*  71 */     this((OracleClob)paramCLOB, paramInt, paramLong);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public OracleClobOutputStream(OracleClob paramOracleClob, int paramInt, long paramLong) throws SQLException {
/*  85 */     if (paramOracleClob == null || paramInt <= 0 || paramLong < 1L)
/*     */     {
/*  87 */       throw new IllegalArgumentException();
/*     */     }
/*     */     
/*  90 */     this.clob = paramOracleClob;
/*  91 */     this.lobOffset = paramLong;
/*     */     
/*  93 */     PhysicalConnection physicalConnection = (PhysicalConnection)paramOracleClob.getInternalConnection();
/*  94 */     synchronized (physicalConnection) {
/*  95 */       this.buf = physicalConnection.getByteBuffer(paramInt);
/*     */     } 
/*  97 */     this.count = 0;
/*  98 */     this.bufSize = paramInt;
/*     */     
/* 100 */     this.isClosed = false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void write(int paramInt) throws IOException {
/* 119 */     ensureOpen();
/*     */     
/* 121 */     if (this.count >= this.bufSize) {
/* 122 */       flushBuffer();
/*     */     }
/* 124 */     this.buf[this.count++] = (byte)paramInt;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void write(byte[] paramArrayOfbyte, int paramInt1, int paramInt2) throws IOException {
/* 146 */     ensureOpen();
/*     */     
/* 148 */     int i = paramInt1;
/* 149 */     int j = Math.min(paramInt2, paramArrayOfbyte.length - paramInt1);
/*     */     
/* 151 */     if (j >= 2 * this.bufSize) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 158 */       if (this.count > 0) flushBuffer();
/*     */       
/*     */       try {
/* 161 */         char[] arrayOfChar = new char[j];
/*     */         
/* 163 */         for (byte b = 0; b < j; b++) {
/* 164 */           arrayOfChar[b] = (char)paramArrayOfbyte[b + paramInt1];
/*     */         }
/* 166 */         this.lobOffset += this.clob.putChars(this.lobOffset, arrayOfChar);
/*     */       }
/* 168 */       catch (SQLException sQLException) {
/*     */ 
/*     */         
/* 171 */         IOException iOException = DatabaseError.createIOException(sQLException);
/* 172 */         iOException.fillInStackTrace();
/* 173 */         throw iOException;
/*     */       } 
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/* 179 */     int k = i + j;
/*     */     
/* 181 */     while (i < k) {
/*     */       
/* 183 */       int m = Math.min(this.bufSize - this.count, k - i);
/*     */       
/* 185 */       System.arraycopy(paramArrayOfbyte, i, this.buf, this.count, m);
/*     */       
/* 187 */       i += m;
/* 188 */       this.count += m;
/*     */       
/* 190 */       if (this.count >= this.bufSize) {
/* 191 */         flushBuffer();
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void flush() throws IOException {
/* 213 */     ensureOpen();
/*     */     
/* 215 */     flushBuffer();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void close() throws IOException {
/* 234 */     if (this.isClosed) {
/*     */       return;
/*     */     }
/*     */     
/*     */     try {
/* 239 */       this.isClosed = true;
/* 240 */       flushBuffer();
/*     */     } finally {
/*     */ 
/*     */       
/*     */       try {
/* 245 */         PhysicalConnection physicalConnection = (PhysicalConnection)this.clob.getInternalConnection();
/* 246 */         synchronized (physicalConnection) {
/*     */           
/* 248 */           if (this.buf != null) {
/*     */             
/* 250 */             physicalConnection.cacheBuffer(this.buf);
/* 251 */             this.buf = null;
/*     */           } 
/*     */         } 
/* 254 */       } catch (SQLException sQLException) {
/*     */ 
/*     */         
/* 257 */         IOException iOException = DatabaseError.createIOException(sQLException);
/* 258 */         iOException.fillInStackTrace();
/* 259 */         throw iOException;
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void flushBuffer() throws IOException {
/*     */     try {
/* 277 */       if (this.count > 0)
/*     */       {
/* 279 */         char[] arrayOfChar = new char[this.count];
/*     */         
/* 281 */         for (byte b = 0; b < this.count; b++) {
/* 282 */           arrayOfChar[b] = (char)this.buf[b];
/*     */         }
/* 284 */         this.lobOffset += this.clob.putChars(this.lobOffset, arrayOfChar);
/*     */         
/* 286 */         this.count = 0;
/*     */       }
/*     */     
/* 289 */     } catch (SQLException sQLException) {
/*     */ 
/*     */       
/* 292 */       IOException iOException = DatabaseError.createIOException(sQLException);
/* 293 */       iOException.fillInStackTrace();
/* 294 */       throw iOException;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void ensureOpen() throws IOException {
/*     */     try {
/* 311 */       if (this.isClosed)
/*     */       {
/* 313 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 57, (Object)null);
/* 314 */         sQLException.fillInStackTrace();
/* 315 */         throw sQLException;
/*     */       }
/*     */     
/* 318 */     } catch (SQLException sQLException) {
/*     */ 
/*     */       
/* 321 */       IOException iOException = DatabaseError.createIOException(sQLException);
/* 322 */       iOException.fillInStackTrace();
/* 323 */       throw iOException;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected OracleConnection getConnectionDuringExceptionHandling() {
/*     */     try {
/* 343 */       return this.clob.getInternalConnection();
/*     */     }
/* 345 */     catch (Exception exception) {
/*     */       
/* 347 */       return null;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 354 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*     */   public static final String BUILD_DATE = "Thu_Apr_04_15:09:24_PDT_2013";
/*     */   public static final boolean TRACE = false;
/*     */ }


/* Location:              C:\Users\olatu\OneDrive\Documents\Calypso\syncbase\sync_base.jar!\BOOT-INF\classes\ojdbc.jar!\oracle\jdbc\driver\OracleClobOutputStream.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */