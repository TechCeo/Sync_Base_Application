/*     */ package oracle.jdbc.driver;
/*     */ 
/*     */ import java.sql.SQLException;
/*     */ import java.util.EventListener;
/*     */ import java.util.Properties;
/*     */ import java.util.concurrent.Executor;
/*     */ import oracle.jdbc.internal.JMSNotificationListener;
/*     */ import oracle.jdbc.internal.JMSNotificationRegistration;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class NTFJMSRegistration
/*     */   extends NTFRegistration
/*     */   implements JMSNotificationRegistration
/*     */ {
/*     */   private final String name;
/*     */   private final String clientId;
/*     */   private long jmsRegistrationId;
/*     */   private int qosFlag;
/*     */   
/*     */   NTFJMSRegistration(long paramLong, boolean paramBoolean, String paramString1, String paramString2, Properties paramProperties, String paramString3, short paramShort, String paramString4) {
/*  47 */     super((int)paramLong, 1, paramBoolean, paramString1, null, 0, paramProperties, paramString2, paramShort);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  57 */     this.name = paramString3;
/*  58 */     this.clientId = paramString4;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addListener(JMSNotificationListener paramJMSNotificationListener, Executor paramExecutor) throws SQLException {
/*  76 */     NTFEventListener nTFEventListener = new NTFEventListener(paramJMSNotificationListener);
/*  77 */     nTFEventListener.setExecutor(paramExecutor);
/*  78 */     addListener(nTFEventListener);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addListener(JMSNotificationListener paramJMSNotificationListener) throws SQLException {
/*  95 */     NTFEventListener nTFEventListener = new NTFEventListener(paramJMSNotificationListener);
/*  96 */     addListener(nTFEventListener);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void removeListener(JMSNotificationListener paramJMSNotificationListener) throws SQLException {
/* 113 */     removeListener((EventListener)paramJMSNotificationListener);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getQueueName() {
/* 129 */     return this.name;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getClientId() {
/* 144 */     return this.clientId;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   long getJMSRegistrationId() {
/* 155 */     return this.jmsRegistrationId;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void setJMSRegistrationId(long paramLong) {
/* 165 */     this.jmsRegistrationId = paramLong;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getQOSFlag() {
/* 174 */     return this.qosFlag;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setQOSFlag(int paramInt) {
/* 183 */     this.qosFlag = paramInt;
/*     */   }
/*     */ 
/*     */   
/* 187 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*     */   public static final String BUILD_DATE = "Thu_Apr_04_15:09:24_PDT_2013";
/*     */   public static final boolean TRACE = false;
/*     */ }


/* Location:              C:\Users\olatu\OneDrive\Documents\Calypso\syncbase\sync_base.jar!\BOOT-INF\classes\ojdbc.jar!\oracle\jdbc\driver\NTFJMSRegistration.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */