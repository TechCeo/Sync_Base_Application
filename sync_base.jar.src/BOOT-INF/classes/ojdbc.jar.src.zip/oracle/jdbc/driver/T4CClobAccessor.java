/*     */ package oracle.jdbc.driver;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.sql.SQLException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.LinkedList;
/*     */ import oracle.jdbc.OracleResultSetMetaData;
/*     */ import oracle.sql.CLOB;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class T4CClobAccessor
/*     */   extends ClobAccessor
/*     */ {
/*     */   T4CMAREngine mare;
/*  26 */   short[] prefetchedClobCharset = null;
/*     */ 
/*     */   
/*  29 */   boolean[] prefetchedClobDBVary = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   final int[] meta;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   ArrayList<LinkedList<CLOB>> registeredCLOBs;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   T4CClobAccessor(OracleStatement paramOracleStatement, int paramInt1, short paramShort, int paramInt2, boolean paramBoolean, T4CMAREngine paramT4CMAREngine) throws SQLException
/*     */   {
/*  49 */     super(paramOracleStatement, 4000, paramShort, paramInt2, paramBoolean);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 127 */     this.meta = new int[1];
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 239 */     this.registeredCLOBs = new ArrayList<>(10); this.mare = paramT4CMAREngine; } public T4CMAREngine getMAREngine() { return this.mare; } public void unmarshalColumnMetadata() throws SQLException, IOException { if (this.statement.statementType != 2 && !this.statement.sqlKind.isPlsqlOrCall() && this.securityAttribute == OracleResultSetMetaData.SecurityAttribute.ENABLED) setRowMetadata(this.lastRowProcessed, (byte)this.mare.unmarshalUB1());  } T4CClobAccessor(OracleStatement paramOracleStatement, int paramInt1, boolean paramBoolean, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, short paramShort, int paramInt7, int paramInt8, T4CMAREngine paramT4CMAREngine) throws SQLException { super(paramOracleStatement, 4000, paramBoolean, paramInt2, paramInt3, paramInt4, paramInt5, paramInt6, paramShort); this.meta = new int[1]; this.registeredCLOBs = new ArrayList<>(10); this.mare = paramT4CMAREngine; this.definedColumnType = paramInt7; this.definedColumnSize = paramInt8; }
/*     */   public void processIndicator(int paramInt) throws IOException, SQLException { if ((this.internalType == 1 && this.describeType == 112) || (this.internalType == 23 && this.describeType == 113)) { this.mare.unmarshalUB2(); this.mare.unmarshalUB2(); }
/*     */     else if (this.statement.connection.versionNumber < 9200)
/*     */     { this.mare.unmarshalSB2(); if (!this.statement.sqlKind.isPlsqlOrCall())
/*     */         this.mare.unmarshalSB2();  }
/*     */     else if (this.statement.sqlKind.isPlsqlOrCall() || this.isDMLReturnedParam)
/*     */     { this.mare.processIndicator((paramInt <= 0), paramInt); }
/*     */      }
/*     */   int getPreviousRowProcessed() { if (this.previousRowProcessed == -1)
/* 248 */       this.previousRowProcessed = this.statement.rowPrefetchInLastFetch - 1;  return this.previousRowProcessed; } private void saveCLOBReference(int paramInt, CLOB paramCLOB) { LinkedList<CLOB> linkedList = null;
/* 249 */     if (this.registeredCLOBs.size() > paramInt) {
/*     */       
/* 251 */       linkedList = this.registeredCLOBs.get(paramInt);
/*     */     }
/*     */     else {
/*     */       
/* 255 */       linkedList = new LinkedList();
/* 256 */       while (this.registeredCLOBs.size() < paramInt)
/* 257 */         this.registeredCLOBs.add(new LinkedList<>()); 
/* 258 */       this.registeredCLOBs.add(paramInt, linkedList);
/*     */     } 
/*     */     
/* 261 */     if (linkedList == null) linkedList = new LinkedList<>(); 
/* 262 */     linkedList.add(paramCLOB); } boolean unmarshalOneRow() throws SQLException, IOException { boolean bool = false; if (!isUseless())
/*     */       if (isUnexpected()) { long l = this.rowData.getPosition(); unmarshalColumnMetadata(); unmarshalBytes(); this.rowData.setPosition(l); setNull(this.lastRowProcessed, true); }
/*     */       else if (isNullByDescribe())
/*     */       { setNull(this.lastRowProcessed, true); unmarshalColumnMetadata(); if (this.statement.connection.versionNumber < 9200)
/*     */           processIndicator(0);  }
/*     */       else
/*     */       { unmarshalColumnMetadata(); bool = unmarshalBytes(); }
/*     */         this.previousRowProcessed = this.lastRowProcessed; this.lastRowProcessed++; return bool; }
/*     */   void copyRow() throws SQLException, IOException { throw new NoSuchMethodError("oracle.jdbc.driver.T4C_lobAccessor.copyRow"); }
/* 271 */   Object getObject(int paramInt) throws SQLException { if (this.definedColumnType == 0) {
/* 272 */       return super.getObject(paramInt);
/*     */     }
/* 274 */     if (isNull(paramInt)) return null;
/*     */     
/* 276 */     switch (this.definedColumnType) {
/*     */       
/*     */       case 2011:
/* 279 */         return getNCLOB(paramInt);
/*     */       
/*     */       case 2005:
/* 282 */         return getCLOB(paramInt);
/*     */       
/*     */       case -1:
/*     */       case 1:
/*     */       case 12:
/* 287 */         return getString(paramInt);
/*     */       
/*     */       case -4:
/*     */       case -3:
/*     */       case -2:
/* 292 */         return getBytes(paramInt);
/*     */     } 
/*     */ 
/*     */     
/* 296 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4);
/* 297 */     sQLException.fillInStackTrace();
/* 298 */     throw sQLException; } boolean unmarshalBytes() throws IOException, SQLException { int i = (int)this.mare.unmarshalUB4(); if (i == 0) { setNull(this.lastRowProcessed, true); processIndicator(0); }
/*     */     else { if (isPrefetched())
/*     */         unmarshalPrefetchData();  setOffset(this.lastRowProcessed); int j = ((DynamicByteArray)this.rowData).unmarshalCLR(this.mare); setNull(this.lastRowProcessed, (j == 0)); setLength(this.lastRowProcessed, j); processIndicator(j); }
/*     */      return false; }
/*     */   void unmarshalPrefetchData() throws SQLException, IOException { setPrefetchedLength(this.lastRowProcessed, this.mare.unmarshalSB8()); setPrefetchedChunkSize(this.lastRowProcessed, (int)this.mare.unmarshalUB4()); if (this.lobPrefetchSizeForThisColumn > 0) {
/*     */       boolean bool = ((byte)this.mare.unmarshalUB1() == 1) ? true : false; if (bool) {
/*     */         setPrefetchedDataCharset(this.lastRowProcessed, this.mare.unmarshalUB2());
/*     */       } else {
/*     */         setPrefetchedDataCharset(this.lastRowProcessed, 0);
/*     */       }  setPrefetchedDataFormOfUse(this.lastRowProcessed, this.mare.unmarshalUB1()); setPrefetchedDataOffset(this.lastRowProcessed); setPrefetchedDataLength(this.lastRowProcessed, ((DynamicByteArray)this.rowData).unmarshalCLR(this.mare));
/*     */     }  }
/* 309 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*     */   public static final String BUILD_DATE = "Thu_Apr_04_15:09:24_PDT_2013";
/*     */   public static final boolean TRACE = false;
/*     */ }


/* Location:              C:\Users\olatu\OneDrive\Documents\Calypso\syncbase\sync_base.jar!\BOOT-INF\classes\ojdbc.jar!\oracle\jdbc\driver\T4CClobAccessor.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */