/*     */ package oracle.jdbc.driver;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.sql.SQLException;
/*     */ import oracle.jdbc.internal.KeywordValue;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class T4CTTIocsessret
/*     */   extends T4CTTIfun
/*     */ {
/*     */   int sessretokvn;
/*     */   KeywordValue[] sessretokv;
/*     */   long sessretflags;
/*     */   long sessretidx;
/*     */   int sessretser;
/*     */   
/*     */   T4CTTIocsessret(T4CConnection paramT4CConnection) {
/*  65 */     super(paramT4CConnection, (byte)3);
/*     */     
/*  67 */     setFunCode((short)4);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void marshal() throws IOException {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void receive() throws SQLException, IOException {
/*  91 */     int i = this.meg.unmarshalUB2();
/*  92 */     i = this.meg.unmarshalUB1();
/*     */     
/*  94 */     this.sessretokvn = this.meg.unmarshalUB2();
/*  95 */     if (this.sessretokvn > 0) {
/*  96 */       i = this.meg.unmarshalUB1();
/*  97 */       this.sessretokv = new KeywordValue[this.sessretokvn];
/*  98 */       for (byte b = 0; b < this.sessretokvn; b++) {
/*  99 */         this.sessretokv[b] = KeywordValueI.unmarshal(this.meg);
/*     */       }
/* 101 */       this.connection.updateSessionProperties(this.sessretokv);
/*     */     } 
/*     */     
/* 104 */     this.sessretflags = this.meg.unmarshalUB4();
/* 105 */     this.sessretidx = this.meg.unmarshalUB4();
/* 106 */     this.sessretser = this.meg.unmarshalUB2();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/* 111 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*     */   public static final String BUILD_DATE = "Thu_Apr_04_15:09:24_PDT_2013";
/*     */   public static final boolean TRACE = false;
/*     */ }


/* Location:              C:\Users\olatu\OneDrive\Documents\Calypso\syncbase\sync_base.jar!\BOOT-INF\classes\ojdbc.jar!\oracle\jdbc\driver\T4CTTIocsessret.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */