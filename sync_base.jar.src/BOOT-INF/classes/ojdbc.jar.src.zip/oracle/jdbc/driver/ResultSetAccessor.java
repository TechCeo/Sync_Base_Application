/*     */ package oracle.jdbc.driver;
/*     */ 
/*     */ import java.sql.ResultSet;
/*     */ import java.sql.SQLException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class ResultSetAccessor
/*     */   extends Accessor
/*     */ {
/*     */   static final int MAXLENGTH = 16;
/*     */   OracleStatement currentStmt;
/*     */   
/*     */   ResultSetAccessor(OracleStatement paramOracleStatement, int paramInt1, short paramShort, int paramInt2, boolean paramBoolean) throws SQLException {
/*  25 */     super(Representation.RESULT_SET, paramOracleStatement, 16, paramBoolean);
/*     */     
/*  27 */     init(paramOracleStatement, 102, 116, paramShort, paramBoolean);
/*  28 */     initForDataAccess(paramInt2, paramInt1, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   ResultSetAccessor(OracleStatement paramOracleStatement, int paramInt1, boolean paramBoolean, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, short paramShort) throws SQLException {
/*  36 */     super(Representation.RESULT_SET, paramOracleStatement, 16, false);
/*     */     
/*  38 */     init(paramOracleStatement, 102, 116, paramShort, false);
/*  39 */     initForDescribe(102, paramInt1, paramBoolean, paramInt2, paramInt3, paramInt4, paramInt5, paramInt6, paramShort, null);
/*     */     
/*  41 */     initForDataAccess(0, paramInt1, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   ResultSet getCursor(int paramInt) throws SQLException {
/*  61 */     if (this.currentStmt != null && this.currentStmt.refCursorRowNumber == paramInt && this.currentStmt.currentResultSet != null)
/*     */     {
/*     */ 
/*     */       
/*  65 */       return (ResultSet)this.currentStmt.currentResultSet;
/*     */     }
/*     */     
/*  68 */     byte[] arrayOfByte = getBytes(paramInt);
/*     */     
/*  70 */     OracleStatement oracleStatement = this.statement.connection.RefCursorBytesToStatement(arrayOfByte, this.statement);
/*     */ 
/*     */     
/*  73 */     oracleStatement.refCursorRowNumber = paramInt;
/*     */     
/*  75 */     oracleStatement.doDescribe(false);
/*  76 */     if (oracleStatement.numberOfDefinePositions > 0) oracleStatement.prepareAccessors(); 
/*  77 */     oracleStatement.setPrefetchInternal(this.statement.getFetchSize(), false, false);
/*  78 */     oracleStatement.closeOnCompletion();
/*     */     
/*  80 */     OracleResultSet oracleResultSet = OracleResultSet.createResultSet(oracleStatement);
/*     */     
/*  82 */     oracleStatement.currentResultSet = oracleResultSet;
/*  83 */     this.currentStmt = oracleStatement;
/*     */     
/*  85 */     return (ResultSet)oracleResultSet;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Object getObject(int paramInt) throws SQLException {
/* 100 */     return getCursor(paramInt);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/* 105 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*     */   public static final String BUILD_DATE = "Thu_Apr_04_15:09:24_PDT_2013";
/*     */   public static final boolean TRACE = false;
/*     */ }


/* Location:              C:\Users\olatu\OneDrive\Documents\Calypso\syncbase\sync_base.jar!\BOOT-INF\classes\ojdbc.jar!\oracle\jdbc\driver\ResultSetAccessor.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */