/*     */ package oracle.jdbc.driver;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class OracleTimeoutPollingThread
/*     */   extends Thread
/*     */ {
/*     */   protected static final String threadName = "OracleTimeoutPollingThread";
/*     */   public static final String pollIntervalProperty = "oracle.jdbc.TimeoutPollInterval";
/*     */   public static final String pollIntervalDefault = "1000";
/*     */   private OracleTimeoutThreadPerVM[] knownTimeouts;
/*     */   private int count;
/*     */   private long sleepMillis;
/*     */   
/*     */   public OracleTimeoutPollingThread() {
/*  69 */     super("OracleTimeoutPollingThread");
/*     */     
/*  71 */     setDaemon(true);
/*  72 */     setPriority(10);
/*     */     
/*  74 */     this.knownTimeouts = new OracleTimeoutThreadPerVM[2];
/*  75 */     this.count = 0;
/*  76 */     this.sleepMillis = Long.parseLong(PhysicalConnection.getSystemPropertyPollInterval());
/*     */ 
/*     */     
/*  79 */     start();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized void addTimeout(OracleTimeoutThreadPerVM paramOracleTimeoutThreadPerVM) {
/*  90 */     int i = 0;
/*     */     
/*  92 */     if (this.count >= this.knownTimeouts.length) {
/*     */ 
/*     */ 
/*     */       
/*  96 */       OracleTimeoutThreadPerVM[] arrayOfOracleTimeoutThreadPerVM = new OracleTimeoutThreadPerVM[this.knownTimeouts.length * 4];
/*     */ 
/*     */       
/*  99 */       System.arraycopy(this.knownTimeouts, 0, arrayOfOracleTimeoutThreadPerVM, 0, this.knownTimeouts.length);
/*     */       
/* 101 */       i = this.knownTimeouts.length;
/* 102 */       this.knownTimeouts = arrayOfOracleTimeoutThreadPerVM;
/*     */     } 
/*     */     
/* 105 */     for (; i < this.knownTimeouts.length; i++) {
/*     */       
/* 107 */       if (this.knownTimeouts[i] == null) {
/*     */         
/* 109 */         this.knownTimeouts[i] = paramOracleTimeoutThreadPerVM;
/* 110 */         this.count++;
/*     */         break;
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized void removeTimeout(OracleTimeoutThreadPerVM paramOracleTimeoutThreadPerVM) {
/* 126 */     for (byte b = 0; b < this.knownTimeouts.length; b++) {
/*     */       
/* 128 */       if (this.knownTimeouts[b] == paramOracleTimeoutThreadPerVM) {
/*     */         
/* 130 */         this.knownTimeouts[b] = null;
/* 131 */         this.count--;
/*     */         break;
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void run() {
/*     */     while (true) {
/*     */       try {
/* 148 */         Thread.sleep(this.sleepMillis);
/*     */       }
/* 150 */       catch (InterruptedException interruptedException) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 156 */       pollOnce();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void pollOnce() {
/* 193 */     if (this.count > 0) {
/*     */       
/* 195 */       long l = System.currentTimeMillis();
/*     */       
/* 197 */       for (byte b = 0; b < this.knownTimeouts.length; b++) {
/*     */ 
/*     */         
/*     */         try {
/* 201 */           if (this.knownTimeouts[b] != null) {
/* 202 */             this.knownTimeouts[b].interruptIfAppropriate(l);
/*     */           }
/* 204 */         } catch (NullPointerException nullPointerException) {}
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 215 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*     */   public static final String BUILD_DATE = "Thu_Apr_04_15:09:24_PDT_2013";
/*     */   public static final boolean TRACE = false;
/*     */ }


/* Location:              C:\Users\olatu\OneDrive\Documents\Calypso\syncbase\sync_base.jar!\BOOT-INF\classes\ojdbc.jar!\oracle\jdbc\driver\OracleTimeoutPollingThread.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */