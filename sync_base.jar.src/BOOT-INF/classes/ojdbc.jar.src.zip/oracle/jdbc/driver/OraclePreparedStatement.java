/*       */ package oracle.jdbc.driver;
/*       */ 
/*       */ import java.io.BufferedInputStream;
/*       */ import java.io.BufferedReader;
/*       */ import java.io.ByteArrayInputStream;
/*       */ import java.io.IOException;
/*       */ import java.io.InputStream;
/*       */ import java.io.Reader;
/*       */ import java.io.StringReader;
/*       */ import java.math.BigDecimal;
/*       */ import java.math.BigInteger;
/*       */ import java.net.URL;
/*       */ import java.security.AccessController;
/*       */ import java.security.PrivilegedAction;
/*       */ import java.sql.Array;
/*       */ import java.sql.BatchUpdateException;
/*       */ import java.sql.Blob;
/*       */ import java.sql.Clob;
/*       */ import java.sql.Connection;
/*       */ import java.sql.Date;
/*       */ import java.sql.NClob;
/*       */ import java.sql.ParameterMetaData;
/*       */ import java.sql.Ref;
/*       */ import java.sql.ResultSet;
/*       */ import java.sql.ResultSetMetaData;
/*       */ import java.sql.RowId;
/*       */ import java.sql.SQLException;
/*       */ import java.sql.SQLXML;
/*       */ import java.sql.Statement;
/*       */ import java.sql.Time;
/*       */ import java.sql.Timestamp;
/*       */ import java.util.Calendar;
/*       */ import java.util.Locale;
/*       */ import java.util.TimeZone;
/*       */ import oracle.jdbc.OracleConnection;
/*       */ import oracle.jdbc.OracleData;
/*       */ import oracle.jdbc.OracleParameterMetaData;
/*       */ import oracle.jdbc.internal.OraclePreparedStatement;
/*       */ import oracle.jdbc.internal.OracleStatement;
/*       */ import oracle.jdbc.oracore.OracleTypeADT;
/*       */ import oracle.jdbc.oracore.OracleTypeCOLLECTION;
/*       */ import oracle.jdbc.oracore.OracleTypeNUMBER;
/*       */ import oracle.jdbc.proxy.ProxyFactory;
/*       */ import oracle.jdbc.proxy._Proxy_;
/*       */ import oracle.sql.ARRAY;
/*       */ import oracle.sql.ArrayDescriptor;
/*       */ import oracle.sql.BFILE;
/*       */ import oracle.sql.BINARY_DOUBLE;
/*       */ import oracle.sql.BINARY_FLOAT;
/*       */ import oracle.sql.BLOB;
/*       */ import oracle.sql.CHAR;
/*       */ import oracle.sql.CLOB;
/*       */ import oracle.sql.CharacterSet;
/*       */ import oracle.sql.CustomDatum;
/*       */ import oracle.sql.DATE;
/*       */ import oracle.sql.Datum;
/*       */ import oracle.sql.INTERVALDS;
/*       */ import oracle.sql.INTERVALYM;
/*       */ import oracle.sql.NUMBER;
/*       */ import oracle.sql.OPAQUE;
/*       */ import oracle.sql.ORAData;
/*       */ import oracle.sql.OpaqueDescriptor;
/*       */ import oracle.sql.RAW;
/*       */ import oracle.sql.REF;
/*       */ import oracle.sql.ROWID;
/*       */ import oracle.sql.STRUCT;
/*       */ import oracle.sql.StructDescriptor;
/*       */ import oracle.sql.TIMESTAMP;
/*       */ import oracle.sql.TIMESTAMPLTZ;
/*       */ import oracle.sql.TIMESTAMPTZ;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ abstract class OraclePreparedStatement
/*       */   extends OracleStatement
/*       */   implements OraclePreparedStatement
/*       */ {
/*       */   int numberOfBindRowsAllocated;
/*   117 */   static Binder theStaticVarnumCopyingBinder = OraclePreparedStatementReadOnly.theStaticVarnumCopyingBinder;
/*       */   
/*   119 */   static Binder theStaticVarnumNullBinder = OraclePreparedStatementReadOnly.theStaticVarnumNullBinder;
/*       */   
/*   121 */   Binder theVarnumNullBinder = theStaticVarnumNullBinder;
/*       */   
/*   123 */   static Binder theStaticBooleanBinder = OraclePreparedStatementReadOnly.theStaticBooleanBinder;
/*       */   
/*   125 */   Binder theBooleanBinder = theStaticBooleanBinder;
/*       */   
/*   127 */   static Binder theStaticByteBinder = OraclePreparedStatementReadOnly.theStaticByteBinder;
/*       */   
/*   129 */   Binder theByteBinder = theStaticByteBinder;
/*       */   
/*   131 */   static Binder theStaticShortBinder = OraclePreparedStatementReadOnly.theStaticShortBinder;
/*       */   
/*   133 */   Binder theShortBinder = theStaticShortBinder;
/*       */   
/*   135 */   static Binder theStaticIntBinder = OraclePreparedStatementReadOnly.theStaticIntBinder;
/*       */   
/*   137 */   Binder theIntBinder = theStaticIntBinder;
/*       */   
/*   139 */   static Binder theStaticLongBinder = OraclePreparedStatementReadOnly.theStaticLongBinder;
/*       */   
/*   141 */   Binder theLongBinder = theStaticLongBinder;
/*       */   
/*   143 */   static Binder theStaticFloatBinder = OraclePreparedStatementReadOnly.theStaticFloatBinder;
/*       */   
/*   145 */   Binder theFloatBinder = null;
/*       */   
/*   147 */   static Binder theStaticDoubleBinder = OraclePreparedStatementReadOnly.theStaticDoubleBinder;
/*       */   
/*   149 */   Binder theDoubleBinder = null;
/*       */   
/*   151 */   static Binder theStaticBigDecimalBinder = OraclePreparedStatementReadOnly.theStaticBigDecimalBinder;
/*       */   
/*   153 */   Binder theBigDecimalBinder = theStaticBigDecimalBinder;
/*       */   
/*   155 */   static Binder theStaticVarcharCopyingBinder = OraclePreparedStatementReadOnly.theStaticVarcharCopyingBinder;
/*       */   
/*   157 */   static Binder theStaticVarcharNullBinder = OraclePreparedStatementReadOnly.theStaticVarcharNullBinder;
/*       */   
/*   159 */   Binder theVarcharNullBinder = theStaticVarcharNullBinder;
/*       */   
/*   161 */   static Binder theStaticStringBinder = OraclePreparedStatementReadOnly.theStaticStringBinder;
/*       */   
/*   163 */   Binder theStringBinder = theStaticStringBinder;
/*       */   
/*   165 */   static Binder theStaticSetCHARCopyingBinder = OraclePreparedStatementReadOnly.theStaticSetCHARCopyingBinder;
/*       */   
/*   167 */   static Binder theStaticSetCHARBinder = OraclePreparedStatementReadOnly.theStaticSetCHARBinder;
/*       */   
/*   169 */   static Binder theStaticLittleEndianSetCHARBinder = OraclePreparedStatementReadOnly.theStaticLittleEndianSetCHARBinder;
/*       */   
/*   171 */   static Binder theStaticSetCHARNullBinder = OraclePreparedStatementReadOnly.theStaticSetCHARNullBinder;
/*       */   
/*       */   Binder theSetCHARBinder;
/*   174 */   Binder theSetCHARNullBinder = theStaticSetCHARNullBinder;
/*       */   
/*   176 */   static Binder theStaticFixedCHARCopyingBinder = OraclePreparedStatementReadOnly.theStaticFixedCHARCopyingBinder;
/*       */   
/*   178 */   static Binder theStaticFixedCHARBinder = OraclePreparedStatementReadOnly.theStaticFixedCHARBinder;
/*       */   
/*   180 */   static Binder theStaticFixedCHARNullBinder = OraclePreparedStatementReadOnly.theStaticFixedCHARNullBinder;
/*       */   
/*   182 */   Binder theFixedCHARBinder = theStaticFixedCHARBinder;
/*   183 */   Binder theFixedCHARNullBinder = theStaticFixedCHARNullBinder;
/*       */   
/*   185 */   static Binder theStaticDateCopyingBinder = OraclePreparedStatementReadOnly.theStaticDateCopyingBinder;
/*       */   
/*   187 */   static Binder theStaticDateBinder = OraclePreparedStatementReadOnly.theStaticDateBinder;
/*       */   
/*   189 */   static Binder theStaticDateNullBinder = OraclePreparedStatementReadOnly.theStaticDateNullBinder;
/*       */   
/*   191 */   Binder theDateBinder = theStaticDateBinder;
/*   192 */   Binder theDateNullBinder = theStaticDateNullBinder;
/*       */   
/*   194 */   static Binder theStaticTimeCopyingBinder = OraclePreparedStatementReadOnly.theStaticTimeCopyingBinder;
/*       */   
/*   196 */   static Binder theStaticTimeBinder = OraclePreparedStatementReadOnly.theStaticTimeBinder;
/*       */   
/*   198 */   Binder theTimeBinder = theStaticTimeBinder;
/*       */   
/*   200 */   static Binder theStaticTimestampCopyingBinder = OraclePreparedStatementReadOnly.theStaticTimestampCopyingBinder;
/*       */   
/*   202 */   static Binder theStaticTimestampBinder = OraclePreparedStatementReadOnly.theStaticTimestampBinder;
/*       */   
/*   204 */   static Binder theStaticTimestampNullBinder = OraclePreparedStatementReadOnly.theStaticTimestampNullBinder;
/*       */   
/*   206 */   Binder theTimestampBinder = theStaticTimestampBinder;
/*   207 */   Binder theTimestampNullBinder = theStaticTimestampNullBinder;
/*       */   
/*   209 */   static Binder theStaticOracleNumberBinder = OraclePreparedStatementReadOnly.theStaticOracleNumberBinder;
/*       */   
/*   211 */   Binder theOracleNumberBinder = theStaticOracleNumberBinder;
/*       */   
/*   213 */   static Binder theStaticOracleDateBinder = OraclePreparedStatementReadOnly.theStaticOracleDateBinder;
/*       */   
/*   215 */   Binder theOracleDateBinder = theStaticOracleDateBinder;
/*       */   
/*   217 */   static Binder theStaticOracleTimestampBinder = OraclePreparedStatementReadOnly.theStaticOracleTimestampBinder;
/*       */   
/*   219 */   Binder theOracleTimestampBinder = theStaticOracleTimestampBinder;
/*       */   
/*   221 */   static Binder theStaticTSTZCopyingBinder = OraclePreparedStatementReadOnly.theStaticTSTZCopyingBinder;
/*       */   
/*   223 */   static Binder theStaticTSTZBinder = OraclePreparedStatementReadOnly.theStaticTSTZBinder;
/*       */   
/*   225 */   static Binder theStaticTSTZNullBinder = OraclePreparedStatementReadOnly.theStaticTSTZNullBinder;
/*       */   
/*   227 */   Binder theTSTZBinder = theStaticTSTZBinder;
/*   228 */   Binder theTSTZNullBinder = theStaticTSTZNullBinder;
/*       */   
/*   230 */   static Binder theStaticTSLTZCopyingBinder = OraclePreparedStatementReadOnly.theStaticTSLTZCopyingBinder;
/*       */   
/*   232 */   static Binder theStaticTSLTZBinder = OraclePreparedStatementReadOnly.theStaticTSLTZBinder;
/*       */   
/*   234 */   static Binder theStaticTSLTZNullBinder = OraclePreparedStatementReadOnly.theStaticTSLTZNullBinder;
/*       */   
/*   236 */   Binder theTSLTZBinder = theStaticTSLTZBinder;
/*   237 */   Binder theTSLTZNullBinder = theStaticTSLTZNullBinder;
/*       */   
/*   239 */   static Binder theStaticRowidCopyingBinder = OraclePreparedStatementReadOnly.theStaticRowidCopyingBinder;
/*       */   
/*   241 */   static Binder theStaticRowidBinder = OraclePreparedStatementReadOnly.theStaticRowidBinder;
/*       */   
/*   243 */   static Binder theStaticLittleEndianRowidBinder = OraclePreparedStatementReadOnly.theStaticLittleEndianRowidBinder;
/*       */   
/*   245 */   static Binder theStaticRowidNullBinder = OraclePreparedStatementReadOnly.theStaticRowidNullBinder;
/*       */   
/*   247 */   static Binder theStaticURowidNullBinder = OraclePreparedStatementReadOnly.theStaticURowidNullBinder;
/*       */   
/*       */   Binder theRowidBinder;
/*   250 */   Binder theRowidNullBinder = theStaticRowidNullBinder;
/*       */   
/*       */   Binder theURowidBinder;
/*   253 */   Binder theURowidNullBinder = theStaticURowidNullBinder;
/*       */   
/*   255 */   static Binder theStaticIntervalDSCopyingBinder = OraclePreparedStatementReadOnly.theStaticIntervalDSCopyingBinder;
/*       */   
/*   257 */   static Binder theStaticIntervalDSBinder = OraclePreparedStatementReadOnly.theStaticIntervalDSBinder;
/*       */   
/*   259 */   static Binder theStaticIntervalDSNullBinder = OraclePreparedStatementReadOnly.theStaticIntervalDSNullBinder;
/*       */   
/*   261 */   Binder theIntervalDSBinder = theStaticIntervalDSBinder;
/*   262 */   Binder theIntervalDSNullBinder = theStaticIntervalDSNullBinder;
/*       */   
/*   264 */   static Binder theStaticIntervalYMCopyingBinder = OraclePreparedStatementReadOnly.theStaticIntervalYMCopyingBinder;
/*       */   
/*   266 */   static Binder theStaticIntervalYMBinder = OraclePreparedStatementReadOnly.theStaticIntervalYMBinder;
/*       */   
/*   268 */   static Binder theStaticIntervalYMNullBinder = OraclePreparedStatementReadOnly.theStaticIntervalYMNullBinder;
/*       */   
/*   270 */   Binder theIntervalYMBinder = theStaticIntervalYMBinder;
/*   271 */   Binder theIntervalYMNullBinder = theStaticIntervalYMNullBinder;
/*       */   
/*   273 */   static Binder theStaticBfileCopyingBinder = OraclePreparedStatementReadOnly.theStaticBfileCopyingBinder;
/*       */   
/*   275 */   static Binder theStaticBfileBinder = OraclePreparedStatementReadOnly.theStaticBfileBinder;
/*       */   
/*   277 */   static Binder theStaticBfileNullBinder = OraclePreparedStatementReadOnly.theStaticBfileNullBinder;
/*       */   
/*   279 */   Binder theBfileBinder = theStaticBfileBinder;
/*   280 */   Binder theBfileNullBinder = theStaticBfileNullBinder;
/*       */   
/*   282 */   static Binder theStaticBlobCopyingBinder = OraclePreparedStatementReadOnly.theStaticBlobCopyingBinder;
/*       */   
/*   284 */   static Binder theStaticBlobBinder = OraclePreparedStatementReadOnly.theStaticBlobBinder;
/*       */   
/*   286 */   static Binder theStaticBlobNullBinder = OraclePreparedStatementReadOnly.theStaticBlobNullBinder;
/*       */   
/*   288 */   Binder theBlobBinder = theStaticBlobBinder;
/*   289 */   Binder theBlobNullBinder = theStaticBlobNullBinder;
/*       */   
/*   291 */   static Binder theStaticClobCopyingBinder = OraclePreparedStatementReadOnly.theStaticClobCopyingBinder;
/*       */   
/*   293 */   static Binder theStaticClobBinder = OraclePreparedStatementReadOnly.theStaticClobBinder;
/*       */   
/*   295 */   static Binder theStaticClobNullBinder = OraclePreparedStatementReadOnly.theStaticClobNullBinder;
/*       */   
/*   297 */   Binder theClobBinder = theStaticClobBinder;
/*   298 */   Binder theClobNullBinder = theStaticClobNullBinder;
/*       */   
/*   300 */   static Binder theStaticRawCopyingBinder = OraclePreparedStatementReadOnly.theStaticRawCopyingBinder;
/*       */   
/*   302 */   static Binder theStaticRawBinder = OraclePreparedStatementReadOnly.theStaticRawBinder;
/*       */   
/*   304 */   static Binder theStaticRawNullBinder = OraclePreparedStatementReadOnly.theStaticRawNullBinder;
/*       */   
/*   306 */   Binder theRawBinder = theStaticRawBinder;
/*   307 */   Binder theRawNullBinder = theStaticRawNullBinder;
/*       */   
/*   309 */   static Binder theStaticPlsqlRawCopyingBinder = OraclePreparedStatementReadOnly.theStaticPlsqlRawCopyingBinder;
/*       */   
/*   311 */   static Binder theStaticPlsqlRawBinder = OraclePreparedStatementReadOnly.theStaticPlsqlRawBinder;
/*       */   
/*   313 */   Binder thePlsqlRawBinder = theStaticPlsqlRawBinder;
/*       */   
/*   315 */   static Binder theStaticBinaryFloatCopyingBinder = OraclePreparedStatementReadOnly.theStaticBinaryFloatCopyingBinder;
/*       */   
/*   317 */   static Binder theStaticBinaryFloatBinder = OraclePreparedStatementReadOnly.theStaticBinaryFloatBinder;
/*       */   
/*   319 */   static Binder theStaticBinaryFloatNullBinder = OraclePreparedStatementReadOnly.theStaticBinaryFloatNullBinder;
/*       */   
/*   321 */   Binder theBinaryFloatBinder = theStaticBinaryFloatBinder;
/*   322 */   Binder theBinaryFloatNullBinder = theStaticBinaryFloatNullBinder;
/*       */   
/*   324 */   static Binder theStaticBINARY_FLOATCopyingBinder = OraclePreparedStatementReadOnly.theStaticBINARY_FLOATCopyingBinder;
/*       */   
/*   326 */   static Binder theStaticBINARY_FLOATBinder = OraclePreparedStatementReadOnly.theStaticBINARY_FLOATBinder;
/*       */   
/*   328 */   static Binder theStaticBINARY_FLOATNullBinder = OraclePreparedStatementReadOnly.theStaticBINARY_FLOATNullBinder;
/*       */   
/*   330 */   Binder theBINARY_FLOATBinder = theStaticBINARY_FLOATBinder;
/*   331 */   Binder theBINARY_FLOATNullBinder = theStaticBINARY_FLOATNullBinder;
/*       */   
/*   333 */   static Binder theStaticBinaryDoubleCopyingBinder = OraclePreparedStatementReadOnly.theStaticBinaryDoubleCopyingBinder;
/*       */   
/*   335 */   static Binder theStaticBinaryDoubleBinder = OraclePreparedStatementReadOnly.theStaticBinaryDoubleBinder;
/*       */   
/*   337 */   static Binder theStaticBinaryDoubleNullBinder = OraclePreparedStatementReadOnly.theStaticBinaryDoubleNullBinder;
/*       */   
/*   339 */   Binder theBinaryDoubleBinder = theStaticBinaryDoubleBinder;
/*   340 */   Binder theBinaryDoubleNullBinder = theStaticBinaryDoubleNullBinder;
/*       */   
/*   342 */   static Binder theStaticBINARY_DOUBLECopyingBinder = OraclePreparedStatementReadOnly.theStaticBINARY_DOUBLECopyingBinder;
/*       */   
/*   344 */   static Binder theStaticBINARY_DOUBLEBinder = OraclePreparedStatementReadOnly.theStaticBINARY_DOUBLEBinder;
/*       */   
/*   346 */   static Binder theStaticBINARY_DOUBLENullBinder = OraclePreparedStatementReadOnly.theStaticBINARY_DOUBLENullBinder;
/*       */   
/*   348 */   Binder theBINARY_DOUBLEBinder = theStaticBINARY_DOUBLEBinder;
/*   349 */   Binder theBINARY_DOUBLENullBinder = theStaticBINARY_DOUBLENullBinder;
/*       */   
/*   351 */   static Binder theStaticLongStreamBinder = OraclePreparedStatementReadOnly.theStaticLongStreamBinder;
/*       */   
/*   353 */   Binder theLongStreamBinder = theStaticLongStreamBinder;
/*       */   
/*   355 */   static Binder theStaticLongStreamForStringBinder = OraclePreparedStatementReadOnly.theStaticLongStreamForStringBinder;
/*       */   
/*   357 */   Binder theLongStreamForStringBinder = theStaticLongStreamForStringBinder;
/*   358 */   static Binder theStaticLongStreamForStringCopyingBinder = OraclePreparedStatementReadOnly.theStaticLongStreamForStringCopyingBinder;
/*       */ 
/*       */   
/*   361 */   static Binder theStaticLongRawStreamBinder = OraclePreparedStatementReadOnly.theStaticLongRawStreamBinder;
/*       */   
/*   363 */   Binder theLongRawStreamBinder = theStaticLongRawStreamBinder;
/*       */   
/*   365 */   static Binder theStaticLongRawStreamForBytesBinder = OraclePreparedStatementReadOnly.theStaticLongRawStreamForBytesBinder;
/*       */   
/*   367 */   Binder theLongRawStreamForBytesBinder = theStaticLongRawStreamForBytesBinder;
/*   368 */   static Binder theStaticLongRawStreamForBytesCopyingBinder = OraclePreparedStatementReadOnly.theStaticLongRawStreamForBytesCopyingBinder;
/*       */ 
/*       */   
/*   371 */   static Binder theStaticNamedTypeCopyingBinder = OraclePreparedStatementReadOnly.theStaticNamedTypeCopyingBinder;
/*       */   
/*   373 */   static Binder theStaticNamedTypeBinder = OraclePreparedStatementReadOnly.theStaticNamedTypeBinder;
/*       */   
/*   375 */   static Binder theStaticNamedTypeNullBinder = OraclePreparedStatementReadOnly.theStaticNamedTypeNullBinder;
/*       */   
/*   377 */   Binder theNamedTypeBinder = theStaticNamedTypeBinder;
/*   378 */   Binder theNamedTypeNullBinder = theStaticNamedTypeNullBinder;
/*       */   
/*   380 */   static Binder theStaticRefTypeCopyingBinder = OraclePreparedStatementReadOnly.theStaticRefTypeCopyingBinder;
/*       */   
/*   382 */   static Binder theStaticRefTypeBinder = OraclePreparedStatementReadOnly.theStaticRefTypeBinder;
/*       */   
/*   384 */   static Binder theStaticRefTypeNullBinder = OraclePreparedStatementReadOnly.theStaticRefTypeNullBinder;
/*       */   
/*   386 */   Binder theRefTypeBinder = theStaticRefTypeBinder;
/*   387 */   Binder theRefTypeNullBinder = theStaticRefTypeNullBinder;
/*       */   
/*   389 */   static Binder theStaticPlsqlIbtCopyingBinder = OraclePreparedStatementReadOnly.theStaticPlsqlIbtCopyingBinder;
/*       */   
/*   391 */   static Binder theStaticPlsqlIbtBinder = OraclePreparedStatementReadOnly.theStaticPlsqlIbtBinder;
/*       */   
/*   393 */   static Binder theStaticPlsqlIbtNullBinder = OraclePreparedStatementReadOnly.theStaticPlsqlIbtNullBinder;
/*       */   
/*   395 */   Binder thePlsqlIbtBinder = theStaticPlsqlIbtBinder;
/*   396 */   Binder thePlsqlNullBinder = theStaticPlsqlIbtNullBinder;
/*       */   
/*   398 */   static Binder theStaticOutBinder = OraclePreparedStatementReadOnly.theStaticOutBinder;
/*       */   
/*   400 */   Binder theOutBinder = theStaticOutBinder;
/*       */   
/*   402 */   static Binder theStaticReturnParamBinder = OraclePreparedStatementReadOnly.theStaticReturnParamBinder;
/*       */   
/*   404 */   Binder theReturnParamBinder = theStaticReturnParamBinder;
/*       */   
/*   406 */   static Binder theStaticT4CRowidBinder = OraclePreparedStatementReadOnly.theStaticT4CRowidBinder;
/*       */   
/*   408 */   static Binder theStaticT4CURowidBinder = OraclePreparedStatementReadOnly.theStaticT4CURowidBinder;
/*       */   
/*   410 */   static Binder theStaticT4CRowidNullBinder = OraclePreparedStatementReadOnly.theStaticT4CRowidNullBinder;
/*       */   
/*   412 */   static Binder theStaticT4CURowidNullBinder = OraclePreparedStatementReadOnly.theStaticT4CURowidNullBinder;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*   419 */   private static final TimeZone UTC_TIME_ZONE = TimeZone.getTimeZone("UTC");
/*   420 */   private static final Calendar UTC_US_CALENDAR = Calendar.getInstance(UTC_TIME_ZONE, Locale.US);
/*       */   
/*   422 */   protected Calendar cachedUTCUSCalendar = (Calendar)UTC_US_CALENDAR.clone();
/*       */   
/*       */   public static final int TypeBinder_BYTELEN = 24;
/*       */   
/*   426 */   char[] digits = new char[20];
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   Binder[][] binders;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   int[][] parameterInt;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   long[][] parameterLong;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   float[][] parameterFloat;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   double[][] parameterDouble;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   BigDecimal[][] parameterBigDecimal;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   String[][] parameterString;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   Date[][] parameterDate;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   Time[][] parameterTime;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   Timestamp[][] parameterTimestamp;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   byte[][][] parameterDatum;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   OracleTypeADT[][] parameterOtype;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   CLOB[] lastBoundClobs;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   BLOB[] lastBoundBlobs;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   PlsqlIbtBindInfo[][] parameterPlsqlIbt;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   Binder[] currentRowBinders;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   int[] currentRowByteLens;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   int[] currentRowCharLens;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   Accessor[] currentRowBindAccessors;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   short[] currentRowFormOfUse;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   boolean currentRowNeedToPrepareBinds = true;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   int[] currentBatchByteLens;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   int[] currentBatchCharLens;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   Accessor[] currentBatchBindAccessors;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   short[] currentBatchFormOfUse;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   boolean currentBatchNeedToPrepareBinds;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   int currentBatchAccumulatedBindsSize;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   static final int BATCH_SIZE_THRESHOLD = 2097152;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   PushedBatch pushedBatches;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   PushedBatch pushedBatchesTail;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   class PushedBatch
/*       */   {
/*       */     int[] currentBatchByteLens;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     int[] currentBatchCharLens;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     int[] lastBoundByteLens;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     int[] lastBoundCharLens;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     Accessor[] currentBatchBindAccessors;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     boolean lastBoundNeeded;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     boolean need_to_parse;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     boolean current_batch_need_to_prepare_binds;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     int first_row_in_batch;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     int number_of_rows_to_be_bound;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     PushedBatch next;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*   907 */   int cachedBindByteSize = 0;
/*   908 */   int cachedBindCharSize = 0;
/*   909 */   int cachedBindIndicatorSize = 0;
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   int totalBindByteLength;
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   int totalBindCharLength;
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   int totalBindIndicatorLength;
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   static final int BIND_METADATA_NUMBER_OF_BIND_POSITIONS_OFFSET = 0;
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   static final int BIND_METADATA_BIND_BUFFER_CAPACITY_OFFSET_HI = 1;
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   static final int BIND_METADATA_BIND_BUFFER_CAPACITY_OFFSET_LO = 2;
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   static final int BIND_METADATA_NUMBER_OF_BOUND_ROWS_OFFSET_HI = 3;
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   static final int BIND_METADATA_NUMBER_OF_BOUND_ROWS_OFFSET_LO = 4;
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   static final int BIND_METADATA_PER_POSITION_DATA_OFFSET = 5;
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   static final int BIND_METADATA_TYPE_OFFSET = 0;
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   static final int BIND_METADATA_BYTE_PITCH_OFFSET = 1;
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   static final int BIND_METADATA_CHAR_PITCH_OFFSET = 2;
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   static final int BIND_METADATA_VALUE_DATA_OFFSET_HI = 3;
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   static final int BIND_METADATA_VALUE_DATA_OFFSET_LO = 4;
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   static final int BIND_METADATA_NULL_INDICATORS_OFFSET_HI = 5;
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   static final int BIND_METADATA_NULL_INDICATORS_OFFSET_LO = 6;
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   static final int BIND_METADATA_VALUE_LENGTHS_OFFSET_HI = 7;
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   static final int BIND_METADATA_VALUE_LENGTHS_OFFSET_LO = 8;
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   static final int BIND_METADATA_FORM_OF_USE_OFFSET = 9;
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   static final int BIND_METADATA_PER_POSITION_SIZE = 10;
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   static final int SETLOB_NO_LENGTH = -1;
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   int bindBufferCapacity;
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   int numberOfBoundRows;
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   int indicatorsOffset;
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   int valueLengthsOffset;
/*       */ 
/*       */ 
/*       */   
/*       */   boolean preparedAllBinds;
/*       */ 
/*       */ 
/*       */   
/*       */   boolean preparedByteBinds;
/*       */ 
/*       */ 
/*       */   
/*       */   boolean preparedCharBinds;
/*       */ 
/*       */ 
/*       */   
/*       */   Binder[] lastBinders;
/*       */ 
/*       */ 
/*       */   
/*       */   byte[] lastBoundBytes;
/*       */ 
/*       */ 
/*       */   
/*       */   int lastBoundByteOffset;
/*       */ 
/*       */ 
/*       */   
/*       */   char[] lastBoundChars;
/*       */ 
/*       */ 
/*       */   
/*       */   int lastBoundCharOffset;
/*       */ 
/*       */ 
/*       */   
/*       */   int[] lastBoundByteOffsets;
/*       */ 
/*       */ 
/*       */   
/*       */   int[] lastBoundCharOffsets;
/*       */ 
/*       */ 
/*       */   
/*       */   int[] lastBoundByteLens;
/*       */ 
/*       */ 
/*       */   
/*       */   int[] lastBoundCharLens;
/*       */ 
/*       */ 
/*       */   
/*       */   short[] lastBoundInds;
/*       */ 
/*       */ 
/*       */   
/*       */   short[] lastBoundLens;
/*       */ 
/*       */ 
/*       */   
/*       */   boolean lastBoundNeeded = false;
/*       */ 
/*       */ 
/*       */   
/*       */   byte[][] lastBoundTypeBytes;
/*       */ 
/*       */ 
/*       */   
/*       */   OracleTypeADT[] lastBoundTypeOtypes;
/*       */ 
/*       */ 
/*       */   
/*       */   InputStream[] lastBoundStream;
/*       */ 
/*       */ 
/*       */   
/*       */   private static final int STREAM_MAX_BYTES_SQL = 2147483647;
/*       */ 
/*       */ 
/*       */   
/*       */   int maxRawBytesSql;
/*       */ 
/*       */ 
/*       */   
/*       */   int maxRawBytesPlsql;
/*       */ 
/*       */ 
/*       */   
/*       */   int maxVcsCharsSql;
/*       */ 
/*       */ 
/*       */   
/*       */   int maxVcsNCharsSql;
/*       */ 
/*       */ 
/*       */   
/*       */   int maxVcsBytesPlsql;
/*       */ 
/*       */ 
/*       */   
/*  1134 */   private int maxCharSize = 0;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*  1140 */   private int maxNCharSize = 0;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*  1148 */   private int charMaxCharsSql = 0;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*  1156 */   private int charMaxNCharsSql = 0;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*  1163 */   protected int maxVcsCharsPlsql = 0;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*  1170 */   private int maxVcsNCharsPlsql = 0;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*  1176 */   int maxIbtVarcharElementLength = 0;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*  1184 */   private int maxStreamCharsSql = 0;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*  1192 */   private int maxStreamNCharsSql = 0; protected boolean isServerCharSetFixedWidth = false; private boolean isServerNCharSetFixedWidth = false; int minVcsBindSize; int prematureBatchCount; boolean checkBindTypes = true; boolean scrollRsetTypeSolved; private static final double MIN_NUMBER = 1.0E-130D; private static final double MAX_NUMBER = 1.0E126D; int SetBigStringTryClob; static final int BSTYLE_UNKNOWN = 0; static final int BSTYLE_ORACLE = 1; static final int BSTYLE_JDBC = 2; int m_batchStyle; void allocBinds(int paramInt) throws SQLException { boolean bool = (paramInt > this.numberOfBindRowsAllocated) ? true : false; initializeIndicatorSubRange(); int i = this.bindIndicatorSubRange + 5 + this.numberOfBindPositions * 10; int j = paramInt * this.numberOfBindPositions; int k = i + 2 * j; if (k > this.totalBindIndicatorLength) { short[] arrayOfShort = this.bindIndicators; int i2 = this.bindIndicatorOffset; this.bindIndicatorOffset = 0; this.bindIndicators = new short[k]; this.totalBindIndicatorLength = k; if (arrayOfShort != null && bool)
/*       */         System.arraycopy(arrayOfShort, i2, this.bindIndicators, this.bindIndicatorOffset, i);  }  this.bindIndicatorSubRange += this.bindIndicatorOffset; this.bindIndicators[this.bindIndicatorSubRange + 0] = (short)this.numberOfBindPositions; this.indicatorsOffset = this.bindIndicatorOffset + i; this.valueLengthsOffset = this.indicatorsOffset + j; int m = this.indicatorsOffset; int n = this.valueLengthsOffset; int i1 = this.bindIndicatorSubRange + 5; for (byte b = 0; b < this.numberOfBindPositions; b++) { this.bindIndicators[i1 + 5] = (short)(m >> 16); this.bindIndicators[i1 + 6] = (short)(m & 0xFFFF); this.bindIndicators[i1 + 7] = (short)(n >> 16); this.bindIndicators[i1 + 8] = (short)(n & 0xFFFF); m += paramInt; n += paramInt; i1 += 10; }  } void initializeBinds() throws SQLException { this.numberOfBindPositions = this.sqlObject.getParameterCount(); this.numReturnParams = this.sqlObject.getReturnParameterCount(); if (this.numberOfBindPositions == 0) { this.currentRowNeedToPrepareBinds = false; return; }  this.numberOfBindRowsAllocated = this.batch; this.binders = new Binder[this.numberOfBindRowsAllocated][this.numberOfBindPositions]; this.currentRowBinders = this.binders[0]; this.currentRowByteLens = new int[this.numberOfBindPositions]; this.currentBatchByteLens = new int[this.numberOfBindPositions]; this.currentRowCharLens = new int[this.numberOfBindPositions]; this.currentBatchCharLens = new int[this.numberOfBindPositions]; this.currentRowFormOfUse = new short[this.numberOfBindPositions]; this.currentBatchFormOfUse = new short[this.numberOfBindPositions]; this.lastBoundClobs = new CLOB[this.numberOfBindPositions]; this.lastBoundBlobs = new BLOB[this.numberOfBindPositions]; byte b1 = 1; if (this.connection.defaultnchar)
/*       */       b1 = 2;  for (byte b2 = 0; b2 < this.numberOfBindPositions; b2++) { this.currentRowFormOfUse[b2] = b1; this.currentBatchFormOfUse[b2] = b1; }  this.lastBinders = new Binder[this.numberOfBindPositions]; this.lastBoundCharLens = new int[this.numberOfBindPositions]; this.lastBoundByteOffsets = new int[this.numberOfBindPositions]; this.lastBoundCharOffsets = new int[this.numberOfBindPositions]; this.lastBoundByteLens = new int[this.numberOfBindPositions]; this.lastBoundInds = new short[this.numberOfBindPositions]; this.lastBoundLens = new short[this.numberOfBindPositions]; this.lastBoundTypeBytes = new byte[this.numberOfBindPositions][]; this.lastBoundTypeOtypes = new OracleTypeADT[this.numberOfBindPositions]; allocBinds(this.numberOfBindRowsAllocated); } void growBinds(int paramInt) throws SQLException { Binder[][] arrayOfBinder = this.binders; this.binders = new Binder[paramInt][]; if (arrayOfBinder != null)
/*       */       System.arraycopy(arrayOfBinder, 0, this.binders, 0, this.numberOfBindRowsAllocated);  int i; for (i = this.numberOfBindRowsAllocated; i < paramInt; i++)
/*       */       this.binders[i] = new Binder[this.numberOfBindPositions];  allocBinds(paramInt); if (this.parameterInt != null) { int[][] arrayOfInt = this.parameterInt; this.parameterInt = new int[paramInt][]; System.arraycopy(arrayOfInt, 0, this.parameterInt, 0, this.numberOfBindRowsAllocated); i = this.numberOfBindRowsAllocated; for (; i < paramInt; i++)
/*       */         this.parameterInt[i] = new int[this.numberOfBindPositions];  }  if (this.parameterLong != null) { long[][] arrayOfLong = this.parameterLong; this.parameterLong = new long[paramInt][]; System.arraycopy(arrayOfLong, 0, this.parameterLong, 0, this.numberOfBindRowsAllocated); i = this.numberOfBindRowsAllocated; for (; i < paramInt; i++)
/*       */         this.parameterLong[i] = new long[this.numberOfBindPositions];  }  if (this.parameterFloat != null) { float[][] arrayOfFloat = this.parameterFloat; this.parameterFloat = new float[paramInt][]; System.arraycopy(arrayOfFloat, 0, this.parameterFloat, 0, this.numberOfBindRowsAllocated); i = this.numberOfBindRowsAllocated; for (; i < paramInt; i++)
/*       */         this.parameterFloat[i] = new float[this.numberOfBindPositions];  }  if (this.parameterDouble != null) { double[][] arrayOfDouble = this.parameterDouble; this.parameterDouble = new double[paramInt][]; System.arraycopy(arrayOfDouble, 0, this.parameterDouble, 0, this.numberOfBindRowsAllocated); i = this.numberOfBindRowsAllocated; for (; i < paramInt; i++)
/*       */         this.parameterDouble[i] = new double[this.numberOfBindPositions];  }  if (this.parameterBigDecimal != null) { BigDecimal[][] arrayOfBigDecimal = this.parameterBigDecimal; this.parameterBigDecimal = new BigDecimal[paramInt][]; System.arraycopy(arrayOfBigDecimal, 0, this.parameterBigDecimal, 0, this.numberOfBindRowsAllocated); i = this.numberOfBindRowsAllocated; for (; i < paramInt; i++)
/*       */         this.parameterBigDecimal[i] = new BigDecimal[this.numberOfBindPositions];  }  if (this.parameterString != null) { String[][] arrayOfString = this.parameterString; this.parameterString = new String[paramInt][]; System.arraycopy(arrayOfString, 0, this.parameterString, 0, this.numberOfBindRowsAllocated); i = this.numberOfBindRowsAllocated; for (; i < paramInt; i++)
/*       */         this.parameterString[i] = new String[this.numberOfBindPositions];  }  if (this.parameterDate != null) { Date[][] arrayOfDate = this.parameterDate; this.parameterDate = new Date[paramInt][]; System.arraycopy(arrayOfDate, 0, this.parameterDate, 0, this.numberOfBindRowsAllocated); i = this.numberOfBindRowsAllocated; for (; i < paramInt; i++)
/*       */         this.parameterDate[i] = new Date[this.numberOfBindPositions];  }  if (this.parameterTime != null) { Time[][] arrayOfTime = this.parameterTime; this.parameterTime = new Time[paramInt][]; System.arraycopy(arrayOfTime, 0, this.parameterTime, 0, this.numberOfBindRowsAllocated); i = this.numberOfBindRowsAllocated; for (; i < paramInt; i++)
/*       */         this.parameterTime[i] = new Time[this.numberOfBindPositions];  }  if (this.parameterTimestamp != null) { Timestamp[][] arrayOfTimestamp = this.parameterTimestamp; this.parameterTimestamp = new Timestamp[paramInt][]; System.arraycopy(arrayOfTimestamp, 0, this.parameterTimestamp, 0, this.numberOfBindRowsAllocated); i = this.numberOfBindRowsAllocated; for (; i < paramInt; i++)
/*       */         this.parameterTimestamp[i] = new Timestamp[this.numberOfBindPositions];  }  if (this.parameterDatum != null) { byte[][][] arrayOfByte = this.parameterDatum; this.parameterDatum = new byte[paramInt][][]; System.arraycopy(arrayOfByte, 0, this.parameterDatum, 0, this.numberOfBindRowsAllocated); i = this.numberOfBindRowsAllocated; for (; i < paramInt; i++)
/*       */         this.parameterDatum[i] = new byte[this.numberOfBindPositions][];  }  if (this.parameterOtype != null) { OracleTypeADT[][] arrayOfOracleTypeADT = this.parameterOtype; this.parameterOtype = new OracleTypeADT[paramInt][]; System.arraycopy(arrayOfOracleTypeADT, 0, this.parameterOtype, 0, this.numberOfBindRowsAllocated); i = this.numberOfBindRowsAllocated; for (; i < paramInt; i++)
/*       */         this.parameterOtype[i] = new OracleTypeADT[this.numberOfBindPositions];  }  if (this.parameterStream != null) { InputStream[][] arrayOfInputStream = this.parameterStream; this.parameterStream = new InputStream[paramInt][]; System.arraycopy(arrayOfInputStream, 0, this.parameterStream, 0, this.numberOfBindRowsAllocated); i = this.numberOfBindRowsAllocated; for (; i < paramInt; i++)
/*       */         this.parameterStream[i] = new InputStream[this.numberOfBindPositions];  }  if (this.userStream != null) { Object[][] arrayOfObject = this.userStream; this.userStream = new Object[paramInt][]; System.arraycopy(arrayOfObject, 0, this.userStream, 0, this.numberOfBindRowsAllocated); i = this.numberOfBindRowsAllocated; for (; i < paramInt; i++)
/*       */         this.userStream[i] = new Object[this.numberOfBindPositions];  }  if (this.parameterPlsqlIbt != null) { PlsqlIbtBindInfo[][] arrayOfPlsqlIbtBindInfo = this.parameterPlsqlIbt; this.parameterPlsqlIbt = new PlsqlIbtBindInfo[paramInt][]; System.arraycopy(arrayOfPlsqlIbtBindInfo, 0, this.parameterPlsqlIbt, 0, this.numberOfBindRowsAllocated); i = this.numberOfBindRowsAllocated; for (; i < paramInt; i++)
/*       */         this.parameterPlsqlIbt[i] = new PlsqlIbtBindInfo[this.numberOfBindPositions];  }  this.numberOfBindRowsAllocated = paramInt; this.currentRowNeedToPrepareBinds = true; } void processCompletedBindRow(int paramInt, boolean paramBoolean) throws SQLException { // Byte code:
/*       */     //   0: aload_0
/*       */     //   1: getfield numberOfBindPositions : I
/*       */     //   4: ifne -> 8
/*       */     //   7: return
/*       */     //   8: iconst_0
/*       */     //   9: istore #4
/*       */     //   11: iconst_0
/*       */     //   12: istore #5
/*       */     //   14: iconst_0
/*       */     //   15: istore #6
/*       */     //   17: aload_0
/*       */     //   18: getfield currentRank : I
/*       */     //   21: aload_0
/*       */     //   22: getfield firstRowInBatch : I
/*       */     //   25: if_icmpne -> 32
/*       */     //   28: iconst_1
/*       */     //   29: goto -> 33
/*       */     //   32: iconst_0
/*       */     //   33: istore #7
/*       */     //   35: aload_0
/*       */     //   36: getfield currentRank : I
/*       */     //   39: ifne -> 62
/*       */     //   42: aload_0
/*       */     //   43: getfield lastBinders : [Loracle/jdbc/driver/Binder;
/*       */     //   46: iconst_0
/*       */     //   47: aaload
/*       */     //   48: ifnonnull -> 55
/*       */     //   51: aconst_null
/*       */     //   52: goto -> 73
/*       */     //   55: aload_0
/*       */     //   56: getfield lastBinders : [Loracle/jdbc/driver/Binder;
/*       */     //   59: goto -> 73
/*       */     //   62: aload_0
/*       */     //   63: getfield binders : [[Loracle/jdbc/driver/Binder;
/*       */     //   66: aload_0
/*       */     //   67: getfield currentRank : I
/*       */     //   70: iconst_1
/*       */     //   71: isub
/*       */     //   72: aaload
/*       */     //   73: astore #8
/*       */     //   75: aload_0
/*       */     //   76: getfield currentRowBindAccessors : [Loracle/jdbc/driver/Accessor;
/*       */     //   79: ifnonnull -> 605
/*       */     //   82: aload_0
/*       */     //   83: getfield isAutoGeneratedKey : Z
/*       */     //   86: ifeq -> 100
/*       */     //   89: aload_0
/*       */     //   90: getfield clearParameters : Z
/*       */     //   93: ifeq -> 100
/*       */     //   96: iconst_1
/*       */     //   97: goto -> 101
/*       */     //   100: iconst_0
/*       */     //   101: istore #9
/*       */     //   103: aload #8
/*       */     //   105: ifnonnull -> 174
/*       */     //   108: iconst_0
/*       */     //   109: istore_3
/*       */     //   110: iload_3
/*       */     //   111: aload_0
/*       */     //   112: getfield numberOfBindPositions : I
/*       */     //   115: if_icmpge -> 579
/*       */     //   118: aload_0
/*       */     //   119: getfield currentRowBinders : [Loracle/jdbc/driver/Binder;
/*       */     //   122: iload_3
/*       */     //   123: aaload
/*       */     //   124: ifnonnull -> 168
/*       */     //   127: iload #9
/*       */     //   129: ifeq -> 142
/*       */     //   132: aload_0
/*       */     //   133: invokevirtual registerReturnParamsForAutoKey : ()V
/*       */     //   136: iconst_0
/*       */     //   137: istore #9
/*       */     //   139: goto -> 168
/*       */     //   142: aload_0
/*       */     //   143: invokevirtual getConnectionDuringExceptionHandling : ()Loracle/jdbc/internal/OracleConnection;
/*       */     //   146: bipush #41
/*       */     //   148: iload_3
/*       */     //   149: iconst_1
/*       */     //   150: iadd
/*       */     //   151: invokestatic valueOf : (I)Ljava/lang/Integer;
/*       */     //   154: invokestatic createSqlException : (Loracle/jdbc/internal/OracleConnection;ILjava/lang/Object;)Ljava/sql/SQLException;
/*       */     //   157: astore #10
/*       */     //   159: aload #10
/*       */     //   161: invokevirtual fillInStackTrace : ()Ljava/lang/Throwable;
/*       */     //   164: pop
/*       */     //   165: aload #10
/*       */     //   167: athrow
/*       */     //   168: iinc #3, 1
/*       */     //   171: goto -> 110
/*       */     //   174: aload_0
/*       */     //   175: getfield checkBindTypes : Z
/*       */     //   178: ifeq -> 469
/*       */     //   181: aload_0
/*       */     //   182: getfield currentRank : I
/*       */     //   185: ifne -> 195
/*       */     //   188: aload_0
/*       */     //   189: getfield lastBoundTypeOtypes : [Loracle/jdbc/oracore/OracleTypeADT;
/*       */     //   192: goto -> 217
/*       */     //   195: aload_0
/*       */     //   196: getfield parameterOtype : [[Loracle/jdbc/oracore/OracleTypeADT;
/*       */     //   199: ifnonnull -> 206
/*       */     //   202: aconst_null
/*       */     //   203: goto -> 217
/*       */     //   206: aload_0
/*       */     //   207: getfield parameterOtype : [[Loracle/jdbc/oracore/OracleTypeADT;
/*       */     //   210: aload_0
/*       */     //   211: getfield currentRank : I
/*       */     //   214: iconst_1
/*       */     //   215: isub
/*       */     //   216: aaload
/*       */     //   217: astore #10
/*       */     //   219: iconst_0
/*       */     //   220: istore_3
/*       */     //   221: iload_3
/*       */     //   222: aload_0
/*       */     //   223: getfield numberOfBindPositions : I
/*       */     //   226: if_icmpge -> 466
/*       */     //   229: aload_0
/*       */     //   230: getfield currentRowBinders : [Loracle/jdbc/driver/Binder;
/*       */     //   233: iload_3
/*       */     //   234: aaload
/*       */     //   235: ifnonnull -> 250
/*       */     //   238: iload #9
/*       */     //   240: ifeq -> 250
/*       */     //   243: aload_0
/*       */     //   244: invokevirtual registerReturnParamsForAutoKey : ()V
/*       */     //   247: iconst_0
/*       */     //   248: istore #9
/*       */     //   250: aload_0
/*       */     //   251: getfield currentRowBinders : [Loracle/jdbc/driver/Binder;
/*       */     //   254: iload_3
/*       */     //   255: aaload
/*       */     //   256: astore #11
/*       */     //   258: aload #11
/*       */     //   260: ifnonnull -> 347
/*       */     //   263: aload_0
/*       */     //   264: getfield clearParameters : Z
/*       */     //   267: ifeq -> 296
/*       */     //   270: aload_0
/*       */     //   271: invokevirtual getConnectionDuringExceptionHandling : ()Loracle/jdbc/internal/OracleConnection;
/*       */     //   274: bipush #41
/*       */     //   276: iload_3
/*       */     //   277: iconst_1
/*       */     //   278: iadd
/*       */     //   279: invokestatic valueOf : (I)Ljava/lang/Integer;
/*       */     //   282: invokestatic createSqlException : (Loracle/jdbc/internal/OracleConnection;ILjava/lang/Object;)Ljava/sql/SQLException;
/*       */     //   285: astore #12
/*       */     //   287: aload #12
/*       */     //   289: invokevirtual fillInStackTrace : ()Ljava/lang/Throwable;
/*       */     //   292: pop
/*       */     //   293: aload #12
/*       */     //   295: athrow
/*       */     //   296: aload_0
/*       */     //   297: getfield currentRowBinders : [Loracle/jdbc/driver/Binder;
/*       */     //   300: iload_3
/*       */     //   301: aload #8
/*       */     //   303: iload_3
/*       */     //   304: aaload
/*       */     //   305: invokevirtual copyingBinder : ()Loracle/jdbc/driver/Binder;
/*       */     //   308: aastore
/*       */     //   309: aload_0
/*       */     //   310: getfield currentRank : I
/*       */     //   313: ifne -> 327
/*       */     //   316: aload_0
/*       */     //   317: getfield currentRowBinders : [Loracle/jdbc/driver/Binder;
/*       */     //   320: iload_3
/*       */     //   321: aaload
/*       */     //   322: aload_0
/*       */     //   323: iload_3
/*       */     //   324: invokevirtual lastBoundValueCleanup : (Loracle/jdbc/driver/OraclePreparedStatement;I)V
/*       */     //   327: aload_0
/*       */     //   328: getfield currentRowByteLens : [I
/*       */     //   331: iload_3
/*       */     //   332: iconst_m1
/*       */     //   333: iastore
/*       */     //   334: aload_0
/*       */     //   335: getfield currentRowCharLens : [I
/*       */     //   338: iload_3
/*       */     //   339: iconst_m1
/*       */     //   340: iastore
/*       */     //   341: iconst_1
/*       */     //   342: istore #5
/*       */     //   344: goto -> 442
/*       */     //   347: aload #11
/*       */     //   349: getfield type : S
/*       */     //   352: istore #12
/*       */     //   354: iload #12
/*       */     //   356: aload #8
/*       */     //   358: iload_3
/*       */     //   359: aaload
/*       */     //   360: getfield type : S
/*       */     //   363: if_icmpne -> 439
/*       */     //   366: iload #12
/*       */     //   368: bipush #109
/*       */     //   370: if_icmpeq -> 380
/*       */     //   373: iload #12
/*       */     //   375: bipush #111
/*       */     //   377: if_icmpne -> 401
/*       */     //   380: aload_0
/*       */     //   381: getfield parameterOtype : [[Loracle/jdbc/oracore/OracleTypeADT;
/*       */     //   384: aload_0
/*       */     //   385: getfield currentRank : I
/*       */     //   388: aaload
/*       */     //   389: iload_3
/*       */     //   390: aaload
/*       */     //   391: aload #10
/*       */     //   393: iload_3
/*       */     //   394: aaload
/*       */     //   395: invokevirtual isInHierarchyOf : (Loracle/jdbc/oracore/OracleType;)Z
/*       */     //   398: ifeq -> 439
/*       */     //   401: iload #12
/*       */     //   403: bipush #9
/*       */     //   405: if_icmpne -> 442
/*       */     //   408: aload #11
/*       */     //   410: getfield bytelen : I
/*       */     //   413: ifne -> 420
/*       */     //   416: iconst_1
/*       */     //   417: goto -> 421
/*       */     //   420: iconst_0
/*       */     //   421: aload #8
/*       */     //   423: iload_3
/*       */     //   424: aaload
/*       */     //   425: getfield bytelen : I
/*       */     //   428: ifne -> 435
/*       */     //   431: iconst_1
/*       */     //   432: goto -> 436
/*       */     //   435: iconst_0
/*       */     //   436: if_icmpeq -> 442
/*       */     //   439: iconst_1
/*       */     //   440: istore #4
/*       */     //   442: aload_0
/*       */     //   443: getfield currentBatchFormOfUse : [S
/*       */     //   446: iload_3
/*       */     //   447: saload
/*       */     //   448: aload_0
/*       */     //   449: getfield currentRowFormOfUse : [S
/*       */     //   452: iload_3
/*       */     //   453: saload
/*       */     //   454: if_icmpeq -> 460
/*       */     //   457: iconst_1
/*       */     //   458: istore #4
/*       */     //   460: iinc #3, 1
/*       */     //   463: goto -> 221
/*       */     //   466: goto -> 579
/*       */     //   469: iconst_0
/*       */     //   470: istore_3
/*       */     //   471: iload_3
/*       */     //   472: aload_0
/*       */     //   473: getfield numberOfBindPositions : I
/*       */     //   476: if_icmpge -> 579
/*       */     //   479: aload_0
/*       */     //   480: getfield currentRowBinders : [Loracle/jdbc/driver/Binder;
/*       */     //   483: iload_3
/*       */     //   484: aaload
/*       */     //   485: astore #10
/*       */     //   487: aload #10
/*       */     //   489: ifnonnull -> 573
/*       */     //   492: aload_0
/*       */     //   493: getfield clearParameters : Z
/*       */     //   496: ifeq -> 525
/*       */     //   499: aload_0
/*       */     //   500: invokevirtual getConnectionDuringExceptionHandling : ()Loracle/jdbc/internal/OracleConnection;
/*       */     //   503: bipush #41
/*       */     //   505: iload_3
/*       */     //   506: iconst_1
/*       */     //   507: iadd
/*       */     //   508: invokestatic valueOf : (I)Ljava/lang/Integer;
/*       */     //   511: invokestatic createSqlException : (Loracle/jdbc/internal/OracleConnection;ILjava/lang/Object;)Ljava/sql/SQLException;
/*       */     //   514: astore #11
/*       */     //   516: aload #11
/*       */     //   518: invokevirtual fillInStackTrace : ()Ljava/lang/Throwable;
/*       */     //   521: pop
/*       */     //   522: aload #11
/*       */     //   524: athrow
/*       */     //   525: aload_0
/*       */     //   526: getfield currentRowBinders : [Loracle/jdbc/driver/Binder;
/*       */     //   529: iload_3
/*       */     //   530: aload #8
/*       */     //   532: iload_3
/*       */     //   533: aaload
/*       */     //   534: invokevirtual copyingBinder : ()Loracle/jdbc/driver/Binder;
/*       */     //   537: aastore
/*       */     //   538: aload_0
/*       */     //   539: getfield currentRank : I
/*       */     //   542: ifne -> 556
/*       */     //   545: aload_0
/*       */     //   546: getfield currentRowBinders : [Loracle/jdbc/driver/Binder;
/*       */     //   549: iload_3
/*       */     //   550: aaload
/*       */     //   551: aload_0
/*       */     //   552: iload_3
/*       */     //   553: invokevirtual lastBoundValueCleanup : (Loracle/jdbc/driver/OraclePreparedStatement;I)V
/*       */     //   556: aload_0
/*       */     //   557: getfield currentRowByteLens : [I
/*       */     //   560: iload_3
/*       */     //   561: iconst_m1
/*       */     //   562: iastore
/*       */     //   563: aload_0
/*       */     //   564: getfield currentRowCharLens : [I
/*       */     //   567: iload_3
/*       */     //   568: iconst_m1
/*       */     //   569: iastore
/*       */     //   570: iconst_1
/*       */     //   571: istore #5
/*       */     //   573: iinc #3, 1
/*       */     //   576: goto -> 471
/*       */     //   579: iload #5
/*       */     //   581: ifeq -> 602
/*       */     //   584: iload #7
/*       */     //   586: ifne -> 597
/*       */     //   589: aload_0
/*       */     //   590: getfield m_batchStyle : I
/*       */     //   593: iconst_2
/*       */     //   594: if_icmpne -> 602
/*       */     //   597: aload_0
/*       */     //   598: iconst_1
/*       */     //   599: putfield lastBoundNeeded : Z
/*       */     //   602: goto -> 1260
/*       */     //   605: aload #8
/*       */     //   607: ifnonnull -> 716
/*       */     //   610: iconst_0
/*       */     //   611: istore_3
/*       */     //   612: iload_3
/*       */     //   613: aload_0
/*       */     //   614: getfield numberOfBindPositions : I
/*       */     //   617: if_icmpge -> 1245
/*       */     //   620: aload_0
/*       */     //   621: getfield currentRowBinders : [Loracle/jdbc/driver/Binder;
/*       */     //   624: iload_3
/*       */     //   625: aaload
/*       */     //   626: astore #9
/*       */     //   628: aload_0
/*       */     //   629: getfield currentRowBindAccessors : [Loracle/jdbc/driver/Accessor;
/*       */     //   632: iload_3
/*       */     //   633: aaload
/*       */     //   634: astore #10
/*       */     //   636: aload #9
/*       */     //   638: ifnonnull -> 685
/*       */     //   641: aload #10
/*       */     //   643: ifnonnull -> 672
/*       */     //   646: aload_0
/*       */     //   647: invokevirtual getConnectionDuringExceptionHandling : ()Loracle/jdbc/internal/OracleConnection;
/*       */     //   650: bipush #41
/*       */     //   652: iload_3
/*       */     //   653: iconst_1
/*       */     //   654: iadd
/*       */     //   655: invokestatic valueOf : (I)Ljava/lang/Integer;
/*       */     //   658: invokestatic createSqlException : (Loracle/jdbc/internal/OracleConnection;ILjava/lang/Object;)Ljava/sql/SQLException;
/*       */     //   661: astore #11
/*       */     //   663: aload #11
/*       */     //   665: invokevirtual fillInStackTrace : ()Ljava/lang/Throwable;
/*       */     //   668: pop
/*       */     //   669: aload #11
/*       */     //   671: athrow
/*       */     //   672: aload_0
/*       */     //   673: getfield currentRowBinders : [Loracle/jdbc/driver/Binder;
/*       */     //   676: iload_3
/*       */     //   677: aload_0
/*       */     //   678: getfield theOutBinder : Loracle/jdbc/driver/Binder;
/*       */     //   681: aastore
/*       */     //   682: goto -> 710
/*       */     //   685: aload #10
/*       */     //   687: ifnull -> 710
/*       */     //   690: aload_0
/*       */     //   691: aload #10
/*       */     //   693: getfield defineType : I
/*       */     //   696: aload #9
/*       */     //   698: getfield type : S
/*       */     //   701: invokespecial isDefineTypeCompatibleWithBindType : (II)Z
/*       */     //   704: ifne -> 710
/*       */     //   707: iconst_1
/*       */     //   708: istore #6
/*       */     //   710: iinc #3, 1
/*       */     //   713: goto -> 612
/*       */     //   716: aload_0
/*       */     //   717: getfield checkBindTypes : Z
/*       */     //   720: ifeq -> 1111
/*       */     //   723: aload_0
/*       */     //   724: getfield currentRank : I
/*       */     //   727: ifne -> 737
/*       */     //   730: aload_0
/*       */     //   731: getfield lastBoundTypeOtypes : [Loracle/jdbc/oracore/OracleTypeADT;
/*       */     //   734: goto -> 759
/*       */     //   737: aload_0
/*       */     //   738: getfield parameterOtype : [[Loracle/jdbc/oracore/OracleTypeADT;
/*       */     //   741: ifnonnull -> 748
/*       */     //   744: aconst_null
/*       */     //   745: goto -> 759
/*       */     //   748: aload_0
/*       */     //   749: getfield parameterOtype : [[Loracle/jdbc/oracore/OracleTypeADT;
/*       */     //   752: aload_0
/*       */     //   753: getfield currentRank : I
/*       */     //   756: iconst_1
/*       */     //   757: isub
/*       */     //   758: aaload
/*       */     //   759: astore #9
/*       */     //   761: iconst_0
/*       */     //   762: istore_3
/*       */     //   763: iload_3
/*       */     //   764: aload_0
/*       */     //   765: getfield numberOfBindPositions : I
/*       */     //   768: if_icmpge -> 1108
/*       */     //   771: aload_0
/*       */     //   772: getfield currentRowBinders : [Loracle/jdbc/driver/Binder;
/*       */     //   775: iload_3
/*       */     //   776: aaload
/*       */     //   777: astore #10
/*       */     //   779: aload_0
/*       */     //   780: getfield currentRowBindAccessors : [Loracle/jdbc/driver/Accessor;
/*       */     //   783: iload_3
/*       */     //   784: aaload
/*       */     //   785: astore #11
/*       */     //   787: aload #10
/*       */     //   789: ifnonnull -> 879
/*       */     //   792: aload_0
/*       */     //   793: getfield clearParameters : Z
/*       */     //   796: ifeq -> 836
/*       */     //   799: aload #8
/*       */     //   801: iload_3
/*       */     //   802: aaload
/*       */     //   803: aload_0
/*       */     //   804: getfield theOutBinder : Loracle/jdbc/driver/Binder;
/*       */     //   807: if_acmpeq -> 836
/*       */     //   810: aload_0
/*       */     //   811: invokevirtual getConnectionDuringExceptionHandling : ()Loracle/jdbc/internal/OracleConnection;
/*       */     //   814: bipush #41
/*       */     //   816: iload_3
/*       */     //   817: iconst_1
/*       */     //   818: iadd
/*       */     //   819: invokestatic valueOf : (I)Ljava/lang/Integer;
/*       */     //   822: invokestatic createSqlException : (Loracle/jdbc/internal/OracleConnection;ILjava/lang/Object;)Ljava/sql/SQLException;
/*       */     //   825: astore #12
/*       */     //   827: aload #12
/*       */     //   829: invokevirtual fillInStackTrace : ()Ljava/lang/Throwable;
/*       */     //   832: pop
/*       */     //   833: aload #12
/*       */     //   835: athrow
/*       */     //   836: aload #8
/*       */     //   838: iload_3
/*       */     //   839: aaload
/*       */     //   840: astore #10
/*       */     //   842: aload_0
/*       */     //   843: getfield currentRowBinders : [Loracle/jdbc/driver/Binder;
/*       */     //   846: iload_3
/*       */     //   847: aload #10
/*       */     //   849: aastore
/*       */     //   850: aload_0
/*       */     //   851: getfield currentRowByteLens : [I
/*       */     //   854: iload_3
/*       */     //   855: iconst_m1
/*       */     //   856: iastore
/*       */     //   857: aload_0
/*       */     //   858: getfield currentRowCharLens : [I
/*       */     //   861: iload_3
/*       */     //   862: iconst_m1
/*       */     //   863: iastore
/*       */     //   864: aload #10
/*       */     //   866: aload_0
/*       */     //   867: getfield theOutBinder : Loracle/jdbc/driver/Binder;
/*       */     //   870: if_acmpeq -> 974
/*       */     //   873: iconst_1
/*       */     //   874: istore #5
/*       */     //   876: goto -> 974
/*       */     //   879: aload #10
/*       */     //   881: getfield type : S
/*       */     //   884: istore #12
/*       */     //   886: iload #12
/*       */     //   888: aload #8
/*       */     //   890: iload_3
/*       */     //   891: aaload
/*       */     //   892: getfield type : S
/*       */     //   895: if_icmpne -> 971
/*       */     //   898: iload #12
/*       */     //   900: bipush #109
/*       */     //   902: if_icmpeq -> 912
/*       */     //   905: iload #12
/*       */     //   907: bipush #111
/*       */     //   909: if_icmpne -> 933
/*       */     //   912: aload_0
/*       */     //   913: getfield parameterOtype : [[Loracle/jdbc/oracore/OracleTypeADT;
/*       */     //   916: aload_0
/*       */     //   917: getfield currentRank : I
/*       */     //   920: aaload
/*       */     //   921: iload_3
/*       */     //   922: aaload
/*       */     //   923: aload #9
/*       */     //   925: iload_3
/*       */     //   926: aaload
/*       */     //   927: invokevirtual isInHierarchyOf : (Loracle/jdbc/oracore/OracleType;)Z
/*       */     //   930: ifeq -> 971
/*       */     //   933: iload #12
/*       */     //   935: bipush #9
/*       */     //   937: if_icmpne -> 974
/*       */     //   940: aload #10
/*       */     //   942: getfield bytelen : I
/*       */     //   945: ifne -> 952
/*       */     //   948: iconst_1
/*       */     //   949: goto -> 953
/*       */     //   952: iconst_0
/*       */     //   953: aload #8
/*       */     //   955: iload_3
/*       */     //   956: aaload
/*       */     //   957: getfield bytelen : I
/*       */     //   960: ifne -> 967
/*       */     //   963: iconst_1
/*       */     //   964: goto -> 968
/*       */     //   967: iconst_0
/*       */     //   968: if_icmpeq -> 974
/*       */     //   971: iconst_1
/*       */     //   972: istore #4
/*       */     //   974: aload_0
/*       */     //   975: getfield currentBatchFormOfUse : [S
/*       */     //   978: iload_3
/*       */     //   979: saload
/*       */     //   980: aload_0
/*       */     //   981: getfield currentRowFormOfUse : [S
/*       */     //   984: iload_3
/*       */     //   985: saload
/*       */     //   986: if_icmpeq -> 992
/*       */     //   989: iconst_1
/*       */     //   990: istore #4
/*       */     //   992: aload_0
/*       */     //   993: getfield currentBatchBindAccessors : [Loracle/jdbc/driver/Accessor;
/*       */     //   996: iload_3
/*       */     //   997: aaload
/*       */     //   998: astore #12
/*       */     //   1000: aload #11
/*       */     //   1002: ifnonnull -> 1020
/*       */     //   1005: aload #12
/*       */     //   1007: astore #11
/*       */     //   1009: aload_0
/*       */     //   1010: getfield currentRowBindAccessors : [Loracle/jdbc/driver/Accessor;
/*       */     //   1013: iload_3
/*       */     //   1014: aload #11
/*       */     //   1016: aastore
/*       */     //   1017: goto -> 1041
/*       */     //   1020: aload #12
/*       */     //   1022: ifnull -> 1041
/*       */     //   1025: aload #11
/*       */     //   1027: getfield defineType : I
/*       */     //   1030: aload #12
/*       */     //   1032: getfield defineType : I
/*       */     //   1035: if_icmpeq -> 1041
/*       */     //   1038: iconst_1
/*       */     //   1039: istore #4
/*       */     //   1041: aload #11
/*       */     //   1043: ifnull -> 1102
/*       */     //   1046: aload #10
/*       */     //   1048: aload_0
/*       */     //   1049: getfield theOutBinder : Loracle/jdbc/driver/Binder;
/*       */     //   1052: if_acmpeq -> 1102
/*       */     //   1055: aload #11
/*       */     //   1057: getfield defineType : I
/*       */     //   1060: aload #10
/*       */     //   1062: getfield type : S
/*       */     //   1065: if_icmpeq -> 1102
/*       */     //   1068: aload_0
/*       */     //   1069: getfield connection : Loracle/jdbc/driver/PhysicalConnection;
/*       */     //   1072: getfield permitTimestampDateMismatch : Z
/*       */     //   1075: ifeq -> 1099
/*       */     //   1078: aload #10
/*       */     //   1080: getfield type : S
/*       */     //   1083: sipush #180
/*       */     //   1086: if_icmpne -> 1099
/*       */     //   1089: aload #11
/*       */     //   1091: getfield defineType : I
/*       */     //   1094: bipush #12
/*       */     //   1096: if_icmpeq -> 1102
/*       */     //   1099: iconst_1
/*       */     //   1100: istore #6
/*       */     //   1102: iinc #3, 1
/*       */     //   1105: goto -> 763
/*       */     //   1108: goto -> 1245
/*       */     //   1111: iconst_0
/*       */     //   1112: istore_3
/*       */     //   1113: iload_3
/*       */     //   1114: aload_0
/*       */     //   1115: getfield numberOfBindPositions : I
/*       */     //   1118: if_icmpge -> 1245
/*       */     //   1121: aload_0
/*       */     //   1122: getfield currentRowBinders : [Loracle/jdbc/driver/Binder;
/*       */     //   1125: iload_3
/*       */     //   1126: aaload
/*       */     //   1127: astore #9
/*       */     //   1129: aload #9
/*       */     //   1131: ifnonnull -> 1218
/*       */     //   1134: aload_0
/*       */     //   1135: getfield clearParameters : Z
/*       */     //   1138: ifeq -> 1178
/*       */     //   1141: aload #8
/*       */     //   1143: iload_3
/*       */     //   1144: aaload
/*       */     //   1145: aload_0
/*       */     //   1146: getfield theOutBinder : Loracle/jdbc/driver/Binder;
/*       */     //   1149: if_acmpeq -> 1178
/*       */     //   1152: aload_0
/*       */     //   1153: invokevirtual getConnectionDuringExceptionHandling : ()Loracle/jdbc/internal/OracleConnection;
/*       */     //   1156: bipush #41
/*       */     //   1158: iload_3
/*       */     //   1159: iconst_1
/*       */     //   1160: iadd
/*       */     //   1161: invokestatic valueOf : (I)Ljava/lang/Integer;
/*       */     //   1164: invokestatic createSqlException : (Loracle/jdbc/internal/OracleConnection;ILjava/lang/Object;)Ljava/sql/SQLException;
/*       */     //   1167: astore #10
/*       */     //   1169: aload #10
/*       */     //   1171: invokevirtual fillInStackTrace : ()Ljava/lang/Throwable;
/*       */     //   1174: pop
/*       */     //   1175: aload #10
/*       */     //   1177: athrow
/*       */     //   1178: aload #8
/*       */     //   1180: iload_3
/*       */     //   1181: aaload
/*       */     //   1182: astore #9
/*       */     //   1184: aload_0
/*       */     //   1185: getfield currentRowBinders : [Loracle/jdbc/driver/Binder;
/*       */     //   1188: iload_3
/*       */     //   1189: aload #9
/*       */     //   1191: aastore
/*       */     //   1192: aload_0
/*       */     //   1193: getfield currentRowByteLens : [I
/*       */     //   1196: iload_3
/*       */     //   1197: iconst_m1
/*       */     //   1198: iastore
/*       */     //   1199: aload_0
/*       */     //   1200: getfield currentRowCharLens : [I
/*       */     //   1203: iload_3
/*       */     //   1204: iconst_m1
/*       */     //   1205: iastore
/*       */     //   1206: aload #9
/*       */     //   1208: aload_0
/*       */     //   1209: getfield theOutBinder : Loracle/jdbc/driver/Binder;
/*       */     //   1212: if_acmpeq -> 1218
/*       */     //   1215: iconst_1
/*       */     //   1216: istore #5
/*       */     //   1218: aload_0
/*       */     //   1219: getfield currentRowBindAccessors : [Loracle/jdbc/driver/Accessor;
/*       */     //   1222: iload_3
/*       */     //   1223: aaload
/*       */     //   1224: ifnonnull -> 1239
/*       */     //   1227: aload_0
/*       */     //   1228: getfield currentRowBindAccessors : [Loracle/jdbc/driver/Accessor;
/*       */     //   1231: iload_3
/*       */     //   1232: aload_0
/*       */     //   1233: getfield currentBatchBindAccessors : [Loracle/jdbc/driver/Accessor;
/*       */     //   1236: iload_3
/*       */     //   1237: aaload
/*       */     //   1238: aastore
/*       */     //   1239: iinc #3, 1
/*       */     //   1242: goto -> 1113
/*       */     //   1245: iload #5
/*       */     //   1247: ifeq -> 1260
/*       */     //   1250: iload #7
/*       */     //   1252: ifeq -> 1260
/*       */     //   1255: aload_0
/*       */     //   1256: iconst_1
/*       */     //   1257: putfield lastBoundNeeded : Z
/*       */     //   1260: iload #4
/*       */     //   1262: ifeq -> 1361
/*       */     //   1265: iload #7
/*       */     //   1267: ifne -> 1343
/*       */     //   1270: aload_0
/*       */     //   1271: getfield m_batchStyle : I
/*       */     //   1274: iconst_2
/*       */     //   1275: if_icmpne -> 1286
/*       */     //   1278: aload_0
/*       */     //   1279: iconst_0
/*       */     //   1280: invokevirtual pushBatch : (Z)V
/*       */     //   1283: goto -> 1343
/*       */     //   1286: aload_0
/*       */     //   1287: getfield validRows : I
/*       */     //   1290: istore #9
/*       */     //   1292: aload_0
/*       */     //   1293: aload_0
/*       */     //   1294: invokevirtual sendBatch : ()I
/*       */     //   1297: putfield prematureBatchCount : I
/*       */     //   1300: aload_0
/*       */     //   1301: iload #9
/*       */     //   1303: putfield validRows : I
/*       */     //   1306: iconst_0
/*       */     //   1307: istore_3
/*       */     //   1308: iload_3
/*       */     //   1309: aload_0
/*       */     //   1310: getfield numberOfBindPositions : I
/*       */     //   1313: if_icmpge -> 1333
/*       */     //   1316: aload_0
/*       */     //   1317: getfield currentRowBinders : [Loracle/jdbc/driver/Binder;
/*       */     //   1320: iload_3
/*       */     //   1321: aaload
/*       */     //   1322: aload_0
/*       */     //   1323: iload_3
/*       */     //   1324: invokevirtual lastBoundValueCleanup : (Loracle/jdbc/driver/OraclePreparedStatement;I)V
/*       */     //   1327: iinc #3, 1
/*       */     //   1330: goto -> 1308
/*       */     //   1333: iload #5
/*       */     //   1335: ifeq -> 1343
/*       */     //   1338: aload_0
/*       */     //   1339: iconst_1
/*       */     //   1340: putfield lastBoundNeeded : Z
/*       */     //   1343: aload_0
/*       */     //   1344: iconst_1
/*       */     //   1345: putfield needToParse : Z
/*       */     //   1348: aload_0
/*       */     //   1349: iconst_1
/*       */     //   1350: putfield currentRowNeedToPrepareBinds : Z
/*       */     //   1353: aload_0
/*       */     //   1354: iconst_1
/*       */     //   1355: putfield needToPrepareDefineBuffer : Z
/*       */     //   1358: goto -> 1380
/*       */     //   1361: iload_2
/*       */     //   1362: ifeq -> 1380
/*       */     //   1365: aload_0
/*       */     //   1366: iconst_0
/*       */     //   1367: invokevirtual pushBatch : (Z)V
/*       */     //   1370: aload_0
/*       */     //   1371: iconst_0
/*       */     //   1372: putfield needToParse : Z
/*       */     //   1375: aload_0
/*       */     //   1376: iconst_0
/*       */     //   1377: putfield currentBatchNeedToPrepareBinds : Z
/*       */     //   1380: aload_0
/*       */     //   1381: getfield currentBatchAccumulatedBindsSize : I
/*       */     //   1384: ldc_w 2097152
/*       */     //   1387: if_icmple -> 1408
/*       */     //   1390: aload_0
/*       */     //   1391: getfield m_batchStyle : I
/*       */     //   1394: iconst_2
/*       */     //   1395: if_icmpne -> 1408
/*       */     //   1398: aload_0
/*       */     //   1399: iconst_0
/*       */     //   1400: invokevirtual pushBatch : (Z)V
/*       */     //   1403: aload_0
/*       */     //   1404: iconst_0
/*       */     //   1405: putfield needToParse : Z
/*       */     //   1408: iconst_0
/*       */     //   1409: istore_3
/*       */     //   1410: iload_3
/*       */     //   1411: aload_0
/*       */     //   1412: getfield numberOfBindPositions : I
/*       */     //   1415: if_icmpge -> 1504
/*       */     //   1418: aload_0
/*       */     //   1419: getfield currentRowCharLens : [I
/*       */     //   1422: iload_3
/*       */     //   1423: iaload
/*       */     //   1424: istore #9
/*       */     //   1426: iload #9
/*       */     //   1428: iconst_m1
/*       */     //   1429: if_icmpne -> 1451
/*       */     //   1432: aload_0
/*       */     //   1433: getfield currentRank : I
/*       */     //   1436: aload_0
/*       */     //   1437: getfield firstRowInBatch : I
/*       */     //   1440: if_icmpne -> 1451
/*       */     //   1443: aload_0
/*       */     //   1444: getfield lastBoundCharLens : [I
/*       */     //   1447: iload_3
/*       */     //   1448: iaload
/*       */     //   1449: istore #9
/*       */     //   1451: aload_0
/*       */     //   1452: getfield currentRowByteLens : [I
/*       */     //   1455: iload_3
/*       */     //   1456: iaload
/*       */     //   1457: istore #10
/*       */     //   1459: iload #10
/*       */     //   1461: iconst_m1
/*       */     //   1462: if_icmpne -> 1484
/*       */     //   1465: aload_0
/*       */     //   1466: getfield currentRank : I
/*       */     //   1469: aload_0
/*       */     //   1470: getfield firstRowInBatch : I
/*       */     //   1473: if_icmpne -> 1484
/*       */     //   1476: aload_0
/*       */     //   1477: getfield lastBoundByteLens : [I
/*       */     //   1480: iload_3
/*       */     //   1481: iaload
/*       */     //   1482: istore #10
/*       */     //   1484: aload_0
/*       */     //   1485: dup
/*       */     //   1486: getfield currentBatchAccumulatedBindsSize : I
/*       */     //   1489: iload #9
/*       */     //   1491: iload #10
/*       */     //   1493: iadd
/*       */     //   1494: iadd
/*       */     //   1495: putfield currentBatchAccumulatedBindsSize : I
/*       */     //   1498: iinc #3, 1
/*       */     //   1501: goto -> 1410
/*       */     //   1504: iload #6
/*       */     //   1506: ifeq -> 1529
/*       */     //   1509: aload_0
/*       */     //   1510: invokevirtual getConnectionDuringExceptionHandling : ()Loracle/jdbc/internal/OracleConnection;
/*       */     //   1513: bipush #12
/*       */     //   1515: invokestatic createSqlException : (Loracle/jdbc/internal/OracleConnection;I)Ljava/sql/SQLException;
/*       */     //   1518: astore #9
/*       */     //   1520: aload #9
/*       */     //   1522: invokevirtual fillInStackTrace : ()Ljava/lang/Throwable;
/*       */     //   1525: pop
/*       */     //   1526: aload #9
/*       */     //   1528: athrow
/*       */     //   1529: iconst_0
/*       */     //   1530: istore_3
/*       */     //   1531: iload_3
/*       */     //   1532: aload_0
/*       */     //   1533: getfield numberOfBindPositions : I
/*       */     //   1536: if_icmpge -> 1675
/*       */     //   1539: aload_0
/*       */     //   1540: getfield currentRowByteLens : [I
/*       */     //   1543: iload_3
/*       */     //   1544: iaload
/*       */     //   1545: istore #9
/*       */     //   1547: iload #9
/*       */     //   1549: iconst_m1
/*       */     //   1550: if_icmpne -> 1572
/*       */     //   1553: aload_0
/*       */     //   1554: getfield currentRank : I
/*       */     //   1557: aload_0
/*       */     //   1558: getfield firstRowInBatch : I
/*       */     //   1561: if_icmpne -> 1572
/*       */     //   1564: aload_0
/*       */     //   1565: getfield lastBoundByteLens : [I
/*       */     //   1568: iload_3
/*       */     //   1569: iaload
/*       */     //   1570: istore #9
/*       */     //   1572: aload_0
/*       */     //   1573: getfield currentBatchByteLens : [I
/*       */     //   1576: iload_3
/*       */     //   1577: iaload
/*       */     //   1578: iload #9
/*       */     //   1580: if_icmpge -> 1591
/*       */     //   1583: aload_0
/*       */     //   1584: getfield currentBatchByteLens : [I
/*       */     //   1587: iload_3
/*       */     //   1588: iload #9
/*       */     //   1590: iastore
/*       */     //   1591: aload_0
/*       */     //   1592: getfield currentRowCharLens : [I
/*       */     //   1595: iload_3
/*       */     //   1596: iaload
/*       */     //   1597: istore #10
/*       */     //   1599: iload #10
/*       */     //   1601: iconst_m1
/*       */     //   1602: if_icmpne -> 1624
/*       */     //   1605: aload_0
/*       */     //   1606: getfield currentRank : I
/*       */     //   1609: aload_0
/*       */     //   1610: getfield firstRowInBatch : I
/*       */     //   1613: if_icmpne -> 1624
/*       */     //   1616: aload_0
/*       */     //   1617: getfield lastBoundCharLens : [I
/*       */     //   1620: iload_3
/*       */     //   1621: iaload
/*       */     //   1622: istore #10
/*       */     //   1624: aload_0
/*       */     //   1625: getfield currentBatchCharLens : [I
/*       */     //   1628: iload_3
/*       */     //   1629: iaload
/*       */     //   1630: iload #10
/*       */     //   1632: if_icmpge -> 1643
/*       */     //   1635: aload_0
/*       */     //   1636: getfield currentBatchCharLens : [I
/*       */     //   1639: iload_3
/*       */     //   1640: iload #10
/*       */     //   1642: iastore
/*       */     //   1643: aload_0
/*       */     //   1644: getfield currentRowByteLens : [I
/*       */     //   1647: iload_3
/*       */     //   1648: iconst_0
/*       */     //   1649: iastore
/*       */     //   1650: aload_0
/*       */     //   1651: getfield currentRowCharLens : [I
/*       */     //   1654: iload_3
/*       */     //   1655: iconst_0
/*       */     //   1656: iastore
/*       */     //   1657: aload_0
/*       */     //   1658: getfield currentBatchFormOfUse : [S
/*       */     //   1661: iload_3
/*       */     //   1662: aload_0
/*       */     //   1663: getfield currentRowFormOfUse : [S
/*       */     //   1666: iload_3
/*       */     //   1667: saload
/*       */     //   1668: sastore
/*       */     //   1669: iinc #3, 1
/*       */     //   1672: goto -> 1531
/*       */     //   1675: aload_0
/*       */     //   1676: getfield currentRowNeedToPrepareBinds : Z
/*       */     //   1679: ifeq -> 1687
/*       */     //   1682: aload_0
/*       */     //   1683: iconst_1
/*       */     //   1684: putfield currentBatchNeedToPrepareBinds : Z
/*       */     //   1687: aload_0
/*       */     //   1688: getfield currentRowBindAccessors : [Loracle/jdbc/driver/Accessor;
/*       */     //   1691: ifnull -> 1752
/*       */     //   1694: aload_0
/*       */     //   1695: getfield currentBatchBindAccessors : [Loracle/jdbc/driver/Accessor;
/*       */     //   1698: astore #9
/*       */     //   1700: aload_0
/*       */     //   1701: aload_0
/*       */     //   1702: getfield currentRowBindAccessors : [Loracle/jdbc/driver/Accessor;
/*       */     //   1705: putfield currentBatchBindAccessors : [Loracle/jdbc/driver/Accessor;
/*       */     //   1708: aload #9
/*       */     //   1710: ifnonnull -> 1725
/*       */     //   1713: aload_0
/*       */     //   1714: getfield numberOfBindPositions : I
/*       */     //   1717: anewarray oracle/jdbc/driver/Accessor
/*       */     //   1720: astore #9
/*       */     //   1722: goto -> 1746
/*       */     //   1725: iconst_0
/*       */     //   1726: istore_3
/*       */     //   1727: iload_3
/*       */     //   1728: aload_0
/*       */     //   1729: getfield numberOfBindPositions : I
/*       */     //   1732: if_icmpge -> 1746
/*       */     //   1735: aload #9
/*       */     //   1737: iload_3
/*       */     //   1738: aconst_null
/*       */     //   1739: aastore
/*       */     //   1740: iinc #3, 1
/*       */     //   1743: goto -> 1727
/*       */     //   1746: aload_0
/*       */     //   1747: aload #9
/*       */     //   1749: putfield currentRowBindAccessors : [Loracle/jdbc/driver/Accessor;
/*       */     //   1752: aload_0
/*       */     //   1753: getfield currentRank : I
/*       */     //   1756: iconst_1
/*       */     //   1757: iadd
/*       */     //   1758: istore #9
/*       */     //   1760: iload #9
/*       */     //   1762: iload_1
/*       */     //   1763: if_icmpge -> 1836
/*       */     //   1766: iload #9
/*       */     //   1768: aload_0
/*       */     //   1769: getfield numberOfBindRowsAllocated : I
/*       */     //   1772: if_icmplt -> 1822
/*       */     //   1775: aload_0
/*       */     //   1776: getfield numberOfBindRowsAllocated : I
/*       */     //   1779: iconst_1
/*       */     //   1780: ishl
/*       */     //   1781: istore #10
/*       */     //   1783: iload #10
/*       */     //   1785: iload #9
/*       */     //   1787: if_icmpgt -> 1796
/*       */     //   1790: iload #9
/*       */     //   1792: iconst_1
/*       */     //   1793: iadd
/*       */     //   1794: istore #10
/*       */     //   1796: aload_0
/*       */     //   1797: iload #10
/*       */     //   1799: invokevirtual growBinds : (I)V
/*       */     //   1802: aload_0
/*       */     //   1803: iconst_1
/*       */     //   1804: putfield currentBatchNeedToPrepareBinds : Z
/*       */     //   1807: aload_0
/*       */     //   1808: getfield pushedBatches : Loracle/jdbc/driver/OraclePreparedStatement$PushedBatch;
/*       */     //   1811: ifnull -> 1822
/*       */     //   1814: aload_0
/*       */     //   1815: getfield pushedBatches : Loracle/jdbc/driver/OraclePreparedStatement$PushedBatch;
/*       */     //   1818: iconst_1
/*       */     //   1819: putfield current_batch_need_to_prepare_binds : Z
/*       */     //   1822: aload_0
/*       */     //   1823: aload_0
/*       */     //   1824: getfield binders : [[Loracle/jdbc/driver/Binder;
/*       */     //   1827: iload #9
/*       */     //   1829: aaload
/*       */     //   1830: putfield currentRowBinders : [Loracle/jdbc/driver/Binder;
/*       */     //   1833: goto -> 1852
/*       */     //   1836: aload_0
/*       */     //   1837: iconst_0
/*       */     //   1838: iload_1
/*       */     //   1839: invokevirtual setupBindBuffers : (II)V
/*       */     //   1842: aload_0
/*       */     //   1843: aload_0
/*       */     //   1844: getfield binders : [[Loracle/jdbc/driver/Binder;
/*       */     //   1847: iconst_0
/*       */     //   1848: aaload
/*       */     //   1849: putfield currentRowBinders : [Loracle/jdbc/driver/Binder;
/*       */     //   1852: aload_0
/*       */     //   1853: iconst_0
/*       */     //   1854: putfield currentRowNeedToPrepareBinds : Z
/*       */     //   1857: aload_0
/*       */     //   1858: iconst_0
/*       */     //   1859: putfield clearParameters : Z
/*       */     //   1862: return
/*       */     // Line number table:
/*       */     //   Java source line number -> byte code offset
/*       */     //   #1839	-> 0
/*       */     //   #1842	-> 7
/*       */     //   #1845	-> 8
/*       */     //   #1846	-> 11
/*       */     //   #1847	-> 14
/*       */     //   #1848	-> 17
/*       */     //   #1855	-> 35
/*       */     //   #1859	-> 75
/*       */     //   #1861	-> 82
/*       */     //   #1864	-> 103
/*       */     //   #1868	-> 108
/*       */     //   #1869	-> 118
/*       */     //   #1871	-> 127
/*       */     //   #1873	-> 132
/*       */     //   #1874	-> 136
/*       */     //   #1877	-> 142
/*       */     //   #1878	-> 159
/*       */     //   #1879	-> 165
/*       */     //   #1868	-> 168
/*       */     //   #1883	-> 174
/*       */     //   #1888	-> 181
/*       */     //   #1892	-> 219
/*       */     //   #1894	-> 229
/*       */     //   #1896	-> 243
/*       */     //   #1897	-> 247
/*       */     //   #1899	-> 250
/*       */     //   #1901	-> 258
/*       */     //   #1906	-> 263
/*       */     //   #1908	-> 270
/*       */     //   #1909	-> 287
/*       */     //   #1910	-> 293
/*       */     //   #1919	-> 296
/*       */     //   #1922	-> 309
/*       */     //   #1923	-> 316
/*       */     //   #1930	-> 327
/*       */     //   #1931	-> 334
/*       */     //   #1937	-> 341
/*       */     //   #1941	-> 347
/*       */     //   #1943	-> 354
/*       */     //   #1952	-> 439
/*       */     //   #1955	-> 442
/*       */     //   #1959	-> 457
/*       */     //   #1892	-> 460
/*       */     //   #1962	-> 466
/*       */     //   #1968	-> 469
/*       */     //   #1970	-> 479
/*       */     //   #1972	-> 487
/*       */     //   #1977	-> 492
/*       */     //   #1979	-> 499
/*       */     //   #1980	-> 516
/*       */     //   #1981	-> 522
/*       */     //   #1990	-> 525
/*       */     //   #1993	-> 538
/*       */     //   #1994	-> 545
/*       */     //   #2000	-> 556
/*       */     //   #2001	-> 563
/*       */     //   #2007	-> 570
/*       */     //   #1968	-> 573
/*       */     //   #2012	-> 579
/*       */     //   #2014	-> 597
/*       */     //   #2015	-> 602
/*       */     //   #2020	-> 605
/*       */     //   #2026	-> 610
/*       */     //   #2028	-> 620
/*       */     //   #2029	-> 628
/*       */     //   #2031	-> 636
/*       */     //   #2036	-> 641
/*       */     //   #2041	-> 646
/*       */     //   #2042	-> 663
/*       */     //   #2043	-> 669
/*       */     //   #2049	-> 672
/*       */     //   #2051	-> 685
/*       */     //   #2056	-> 707
/*       */     //   #2026	-> 710
/*       */     //   #2060	-> 716
/*       */     //   #2067	-> 723
/*       */     //   #2071	-> 761
/*       */     //   #2073	-> 771
/*       */     //   #2074	-> 779
/*       */     //   #2076	-> 787
/*       */     //   #2082	-> 792
/*       */     //   #2085	-> 810
/*       */     //   #2086	-> 827
/*       */     //   #2087	-> 833
/*       */     //   #2098	-> 836
/*       */     //   #2099	-> 842
/*       */     //   #2100	-> 850
/*       */     //   #2101	-> 857
/*       */     //   #2103	-> 864
/*       */     //   #2109	-> 873
/*       */     //   #2113	-> 879
/*       */     //   #2115	-> 886
/*       */     //   #2124	-> 971
/*       */     //   #2127	-> 974
/*       */     //   #2131	-> 989
/*       */     //   #2133	-> 992
/*       */     //   #2135	-> 1000
/*       */     //   #2141	-> 1005
/*       */     //   #2142	-> 1009
/*       */     //   #2144	-> 1020
/*       */     //   #2149	-> 1038
/*       */     //   #2151	-> 1041
/*       */     //   #2160	-> 1068
/*       */     //   #2164	-> 1099
/*       */     //   #2071	-> 1102
/*       */     //   #2168	-> 1108
/*       */     //   #2175	-> 1111
/*       */     //   #2177	-> 1121
/*       */     //   #2179	-> 1129
/*       */     //   #2185	-> 1134
/*       */     //   #2187	-> 1152
/*       */     //   #2188	-> 1169
/*       */     //   #2189	-> 1175
/*       */     //   #2199	-> 1178
/*       */     //   #2200	-> 1184
/*       */     //   #2201	-> 1192
/*       */     //   #2202	-> 1199
/*       */     //   #2204	-> 1206
/*       */     //   #2210	-> 1215
/*       */     //   #2213	-> 1218
/*       */     //   #2218	-> 1227
/*       */     //   #2175	-> 1239
/*       */     //   #2230	-> 1245
/*       */     //   #2231	-> 1255
/*       */     //   #2234	-> 1260
/*       */     //   #2238	-> 1265
/*       */     //   #2244	-> 1270
/*       */     //   #2251	-> 1278
/*       */     //   #2260	-> 1286
/*       */     //   #2262	-> 1292
/*       */     //   #2263	-> 1300
/*       */     //   #2268	-> 1306
/*       */     //   #2269	-> 1316
/*       */     //   #2268	-> 1327
/*       */     //   #2273	-> 1333
/*       */     //   #2274	-> 1338
/*       */     //   #2280	-> 1343
/*       */     //   #2284	-> 1348
/*       */     //   #2287	-> 1353
/*       */     //   #2289	-> 1361
/*       */     //   #2295	-> 1365
/*       */     //   #2299	-> 1370
/*       */     //   #2307	-> 1375
/*       */     //   #2317	-> 1380
/*       */     //   #2320	-> 1398
/*       */     //   #2321	-> 1403
/*       */     //   #2326	-> 1408
/*       */     //   #2329	-> 1418
/*       */     //   #2330	-> 1426
/*       */     //   #2331	-> 1443
/*       */     //   #2333	-> 1451
/*       */     //   #2334	-> 1459
/*       */     //   #2335	-> 1476
/*       */     //   #2337	-> 1484
/*       */     //   #2326	-> 1498
/*       */     //   #2340	-> 1504
/*       */     //   #2347	-> 1509
/*       */     //   #2348	-> 1520
/*       */     //   #2349	-> 1526
/*       */     //   #2361	-> 1529
/*       */     //   #2363	-> 1539
/*       */     //   #2365	-> 1547
/*       */     //   #2366	-> 1564
/*       */     //   #2368	-> 1572
/*       */     //   #2369	-> 1583
/*       */     //   #2371	-> 1591
/*       */     //   #2372	-> 1599
/*       */     //   #2373	-> 1616
/*       */     //   #2375	-> 1624
/*       */     //   #2376	-> 1635
/*       */     //   #2378	-> 1643
/*       */     //   #2379	-> 1650
/*       */     //   #2380	-> 1657
/*       */     //   #2361	-> 1669
/*       */     //   #2385	-> 1675
/*       */     //   #2386	-> 1682
/*       */     //   #2395	-> 1687
/*       */     //   #2397	-> 1694
/*       */     //   #2399	-> 1700
/*       */     //   #2401	-> 1708
/*       */     //   #2402	-> 1713
/*       */     //   #2404	-> 1725
/*       */     //   #2405	-> 1735
/*       */     //   #2404	-> 1740
/*       */     //   #2407	-> 1746
/*       */     //   #2410	-> 1752
/*       */     //   #2412	-> 1760
/*       */     //   #2417	-> 1766
/*       */     //   #2423	-> 1775
/*       */     //   #2425	-> 1783
/*       */     //   #2426	-> 1790
/*       */     //   #2428	-> 1796
/*       */     //   #2430	-> 1802
/*       */     //   #2432	-> 1807
/*       */     //   #2433	-> 1814
/*       */     //   #2437	-> 1822
/*       */     //   #2446	-> 1836
/*       */     //   #2453	-> 1842
/*       */     //   #2458	-> 1852
/*       */     //   #2460	-> 1857
/*       */     //   #2462	-> 1862 } private boolean isDefineTypeCompatibleWithBindType(int paramInt1, int paramInt2) { boolean bool = false; if (paramInt1 == paramInt2) { bool = true; } else if (this.connection.permitTimestampDateMismatch && paramInt2 == 180 && paramInt1 == 12) { bool = true; }  return bool; } void processPlsqlIndexTabBinds(int paramInt) throws SQLException { byte b1 = 0; int i = 0; int j = 0; int k = 0; Binder[] arrayOfBinder = this.binders[paramInt]; PlsqlIbtBindInfo[] arrayOfPlsqlIbtBindInfo = (this.parameterPlsqlIbt == null) ? null : this.parameterPlsqlIbt[paramInt]; int m; for (m = 0; m < this.numberOfBindPositions; m++) { Binder binder = arrayOfBinder[m]; Accessor accessor = (this.currentBatchBindAccessors == null) ? null : this.currentBatchBindAccessors[m]; PlsqlIbtBindInfo plsqlIbtBindInfo1 = (accessor == null) ? null : accessor.plsqlIndexTableBindInfo(); PlsqlIbtBindInfo plsqlIbtBindInfo2 = plsqlIbtBindInfo1; if (binder.type == 998) { plsqlIbtBindInfo2 = arrayOfPlsqlIbtBindInfo[m]; if (plsqlIbtBindInfo1 != null) { if (plsqlIbtBindInfo2.element_internal_type != plsqlIbtBindInfo1.element_internal_type) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 12); sQLException.fillInStackTrace(); throw sQLException; }  if (plsqlIbtBindInfo2.maxLen < plsqlIbtBindInfo1.maxLen)
/*       */             plsqlIbtBindInfo2.maxLen = plsqlIbtBindInfo1.maxLen;  if (plsqlIbtBindInfo2.elemMaxLen < plsqlIbtBindInfo1.elemMaxLen)
/*       */             plsqlIbtBindInfo2.elemMaxLen = plsqlIbtBindInfo1.elemMaxLen;  if (plsqlIbtBindInfo2.ibtByteLength > 0) { plsqlIbtBindInfo2.ibtByteLength = plsqlIbtBindInfo2.elemMaxLen * plsqlIbtBindInfo2.maxLen; } else { plsqlIbtBindInfo2.ibtCharLength = plsqlIbtBindInfo2.elemMaxLen * plsqlIbtBindInfo2.maxLen; }  }  }  if (plsqlIbtBindInfo2 != null) { b1++; j += plsqlIbtBindInfo2.ibtByteLength; k += plsqlIbtBindInfo2.ibtCharLength; i += plsqlIbtBindInfo2.maxLen; }  }  if (b1 == 0)
/*       */       return;  this.ibtBindIndicatorSize = 6 + b1 * 8 + i * 2; this.ibtBindIndicators = new short[this.ibtBindIndicatorSize]; this.ibtBindIndicatorOffset = 0; if (j > 0)
/*       */       this.ibtBindBytes = new byte[j];  this.ibtBindByteOffset = 0; if (k > 0)
/*       */       this.ibtBindChars = new char[k];  this.ibtBindCharOffset = 0; m = this.ibtBindByteOffset; int n = this.ibtBindCharOffset; int i1 = this.ibtBindIndicatorOffset; int i2 = i1 + 6 + b1 * 8; this.ibtBindIndicators[i1++] = (short)(b1 >> 16); this.ibtBindIndicators[i1++] = (short)(b1 & 0xFFFF); this.ibtBindIndicators[i1++] = (short)(j >> 16); this.ibtBindIndicators[i1++] = (short)(j & 0xFFFF); this.ibtBindIndicators[i1++] = (short)(k >> 16); this.ibtBindIndicators[i1++] = (short)(k & 0xFFFF); for (byte b2 = 0; b2 < this.numberOfBindPositions; b2++) { Binder binder = arrayOfBinder[b2]; Accessor accessor = (this.currentBatchBindAccessors == null) ? null : this.currentBatchBindAccessors[b2]; PlsqlIbtBindInfo plsqlIbtBindInfo1 = (accessor == null) ? null : accessor.plsqlIndexTableBindInfo(); PlsqlIbtBindInfo plsqlIbtBindInfo2 = plsqlIbtBindInfo1; if (binder.type == 998)
/*       */         plsqlIbtBindInfo2 = arrayOfPlsqlIbtBindInfo[b2];  if (plsqlIbtBindInfo2 != null) { int i3, i4 = plsqlIbtBindInfo2.maxLen; this.ibtBindIndicators[i1++] = (short)plsqlIbtBindInfo2.element_internal_type; this.ibtBindIndicators[i1++] = (short)plsqlIbtBindInfo2.elemMaxLen; this.ibtBindIndicators[i1++] = (short)(i4 >> 16); this.ibtBindIndicators[i1++] = (short)(i4 & 0xFFFF); this.ibtBindIndicators[i1++] = (short)(plsqlIbtBindInfo2.curLen >> 16); this.ibtBindIndicators[i1++] = (short)(plsqlIbtBindInfo2.curLen & 0xFFFF); if (plsqlIbtBindInfo2.ibtByteLength > 0) { i3 = m; m += plsqlIbtBindInfo2.ibtByteLength; } else { i3 = n; n += plsqlIbtBindInfo2.ibtCharLength; }  this.ibtBindIndicators[i1++] = (short)(i3 >> 16); this.ibtBindIndicators[i1++] = (short)(i3 & 0xFFFF); plsqlIbtBindInfo2.ibtValueIndex = i3; plsqlIbtBindInfo2.ibtIndicatorIndex = i2; plsqlIbtBindInfo2.ibtLengthIndex = i2 + i4; if (plsqlIbtBindInfo1 != null) { if (plsqlIbtBindInfo1 != plsqlIbtBindInfo2) { plsqlIbtBindInfo1.ibtIndicatorIndex = plsqlIbtBindInfo2.ibtIndicatorIndex; plsqlIbtBindInfo1.ibtLengthIndex = plsqlIbtBindInfo2.ibtLengthIndex; plsqlIbtBindInfo1.ibtValueIndex = i3; }  initializePlsqlIndexByTableAccessor(accessor, i1); }  i2 += 2 * i4; }  }  }
/*       */   void initializePlsqlIndexByTableAccessor(Accessor paramAccessor, int paramInt) {}
/*       */   void initializeBindSubRanges(int paramInt1, int paramInt2) { this.bindByteSubRange = 0; this.bindCharSubRange = 0; }
/*       */   int calculateIndicatorSubRangeSize() { return 0; }
/*       */   short getInoutIndicator(int paramInt) { return 0; }
/*       */   void initializeIndicatorSubRange() { this.bindIndicatorSubRange = calculateIndicatorSubRangeSize(); }
/*       */   void prepareBindPreambles(int paramInt1, int paramInt2) {}
/*       */   protected void configureBindData() throws SQLException {}
/*       */   void setupBindBuffers(int paramInt1, int paramInt2) throws SQLException { if (this.bindIndicators == null)
/*       */       allocBinds(paramInt2);  try { if (this.numberOfBindPositions == 0) { if (paramInt2 != 0) { this.numberOfBoundRows = paramInt2; this.bindIndicators[this.bindIndicatorSubRange + 3] = (short)((this.numberOfBoundRows & 0xFFFF0000) >> 16); this.bindIndicators[this.bindIndicatorSubRange + 4] = (short)(this.numberOfBoundRows & 0xFFFF); }  return; }  this.preparedAllBinds = this.currentBatchNeedToPrepareBinds; this.preparedByteBinds = false; this.preparedCharBinds = false; this.currentBatchNeedToPrepareBinds = false; this.numberOfBoundRows = paramInt2; this.bindIndicators[this.bindIndicatorSubRange + 3] = (short)((this.numberOfBoundRows & 0xFFFF0000) >> 16); this.bindIndicators[this.bindIndicatorSubRange + 4] = (short)(this.numberOfBoundRows & 0xFFFF); int i = this.bindBufferCapacity; if (this.numberOfBoundRows > this.bindBufferCapacity) { i = this.numberOfBoundRows; this.preparedAllBinds = true; }  if (this.currentBatchBindAccessors != null) { if (this.outBindAccessors == null)
/*       */           this.outBindAccessors = new Accessor[this.numberOfBindPositions];  for (byte b1 = 0; b1 < this.numberOfBindPositions; b1++) { Accessor accessor = this.currentBatchBindAccessors[b1]; this.outBindAccessors[b1] = accessor; if (accessor != null) { int i8 = accessor.byteLength; int i9 = accessor.charLength; if (this.currentBatchByteLens[b1] < i8)
/*       */               this.currentBatchByteLens[b1] = i8;  if (i9 == 0 || this.currentBatchCharLens[b1] < i9)
/*       */               this.currentBatchCharLens[b1] = i9;  }  }  }  int j = 0; int k = 0; int m = this.bindIndicatorSubRange + 5; int n = m; if (this.preparedAllBinds) { this.preparedByteBinds = true; this.preparedCharBinds = true; Binder[] arrayOfBinder1 = this.binders[paramInt1]; for (byte b1 = 0; b1 < this.numberOfBindPositions; b1++) { short s; Binder binder = arrayOfBinder1[b1]; int i8 = this.currentBatchByteLens[b1]; int i9 = this.currentBatchCharLens[b1]; if (binder == this.theOutBinder) { Accessor accessor = this.currentBatchBindAccessors[b1]; s = (short)accessor.defineType; } else { s = binder.type; }  k += i8; j += i9; this.bindIndicators[n + 0] = s; this.bindIndicators[n + 1] = (short)i8; this.bindIndicators[n + 2] = (short)i9; this.bindIndicators[n + 9] = this.currentBatchFormOfUse[b1]; n += 10; }  } else if ((this.preparedByteBinds | this.preparedCharBinds) != 0) { for (byte b1 = 0; b1 < this.numberOfBindPositions; b1++) { int i8 = this.currentBatchByteLens[b1]; int i9 = this.currentBatchCharLens[b1]; k += i8; j += i9; this.bindIndicators[n + 1] = (short)i8; this.bindIndicators[n + 2] = (short)i9; n += 10; }  } else { for (byte b1 = 0; b1 < this.numberOfBindPositions; b1++) { int i8 = n + 1; int i9 = n + 2; int i10 = this.currentBatchByteLens[b1]; int i11 = this.currentBatchCharLens[b1]; short s1 = this.bindIndicators[i8]; short s2 = this.bindIndicators[i9]; int i12 = (this.bindIndicators[n + 5] << 16) + (this.bindIndicators[n + 6] & 0xFFFF); boolean bool1 = (this.bindIndicators[i12] == -1) ? true : false; if (bool1 && i10 > 1)
/*       */             this.preparedByteBinds = true;  if (s1 >= i10 && !this.preparedByteBinds) { this.currentBatchByteLens[b1] = s1; k += s1; } else { this.bindIndicators[i8] = (short)i10; k += i10; this.preparedByteBinds = true; }  if (bool1 && i11 > 1)
/*       */             this.preparedCharBinds = true;  if (s2 >= i11 && !this.preparedCharBinds) { this.currentBatchCharLens[b1] = s2; j += s2; } else { this.bindIndicators[i9] = (short)i11; j += i11; this.preparedCharBinds = true; }  n += 10; }  }  if ((this.preparedByteBinds | this.preparedCharBinds) != 0)
/*       */         initializeBindSubRanges(this.numberOfBoundRows, i);  if (this.preparedByteBinds) { int i8 = this.bindByteSubRange + k * i; if (this.lastBoundNeeded || i8 > this.totalBindByteLength) { this.bindByteOffset = 0; this.bindBytes = this.connection.getByteBuffer(i8); this.totalBindByteLength = i8; }  this.bindBufferCapacity = i; this.bindIndicators[this.bindIndicatorSubRange + 1] = (short)((this.bindBufferCapacity & 0xFFFF0000) >> 16); this.bindIndicators[this.bindIndicatorSubRange + 2] = (short)(this.bindBufferCapacity & 0xFFFF); }  if (this.preparedCharBinds) { int i8 = this.bindCharSubRange + j * this.bindBufferCapacity; if (this.lastBoundNeeded || i8 > this.totalBindCharLength) { this.bindCharOffset = 0; this.bindChars = this.connection.getCharBuffer(i8); this.totalBindCharLength = i8; }  this.bindByteSubRange += this.bindByteOffset; this.bindCharSubRange += this.bindCharOffset; }  int i1 = this.bindByteSubRange; int i2 = this.bindCharSubRange; int i3 = this.indicatorsOffset; int i4 = this.valueLengthsOffset; n = m; if ((this.preparedByteBinds | this.preparedCharBinds) != 0) { if (this.currentBatchBindAccessors == null) { for (byte b1 = 0; b1 < this.numberOfBindPositions; b1++) { int i8 = this.currentBatchByteLens[b1]; int i9 = this.currentBatchCharLens[b1]; int i10 = (i9 == 0) ? i1 : i2; this.bindIndicators[n + 3] = (short)(i10 >> 16); this.bindIndicators[n + 4] = (short)(i10 & 0xFFFF); i1 += i8 * this.bindBufferCapacity; i2 += i9 * this.bindBufferCapacity; n += 10; }  } else { for (byte b1 = 0; b1 < this.numberOfBindPositions; b1++) { int i8 = this.currentBatchByteLens[b1]; int i9 = this.currentBatchCharLens[b1]; int i10 = (i9 == 0) ? i1 : i2; this.bindIndicators[n + 3] = (short)(i10 >> 16); this.bindIndicators[n + 4] = (short)(i10 & 0xFFFF); Accessor accessor = this.currentBatchBindAccessors[b1]; if (accessor != null) { if (i9 > 0) { accessor.columnDataOffset = i2; accessor.charLength = i9; } else { accessor.columnDataOffset = i1; accessor.byteLength = i8; }
/*       */                accessor.lengthIndex = i4; accessor.indicatorIndex = i3; accessor.rowSpaceIndicator = this.bindIndicators; accessor.setCapacity(this.bindBufferCapacity); }
/*       */              i1 += i8 * this.bindBufferCapacity; i2 += i9 * this.bindBufferCapacity; i3 += this.numberOfBindRowsAllocated; i4 += this.numberOfBindRowsAllocated; n += 10; }
/*       */            }
/*       */          i1 = this.bindByteSubRange; i2 = this.bindCharSubRange; i3 = this.indicatorsOffset; i4 = this.valueLengthsOffset; n = m; }
/*       */        int i5 = this.bindBufferCapacity - this.numberOfBoundRows; int i6 = this.numberOfBoundRows - 1; int i7 = i6 + paramInt1; Binder[] arrayOfBinder = this.binders[i7]; if (this.parameterOtype != null) { System.arraycopy(this.parameterDatum[i7], 0, this.lastBoundTypeBytes, 0, this.numberOfBindPositions); System.arraycopy(this.parameterOtype[i7], 0, this.lastBoundTypeOtypes, 0, this.numberOfBindPositions); }
/*       */        if (this.hasIbtBind)
/*       */         processPlsqlIndexTabBinds(paramInt1);  if (this.numReturnParams > 0 && (this.accessors == null || this.accessors.length < this.numReturnParams)) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 173); sQLException.fillInStackTrace(); throw sQLException; }
/*       */        if (this.numReturnParams > 0)
/*       */         processDmlReturningBind();  boolean bool = (!this.sqlKind.isPlsqlOrCall() || this.currentRowBindAccessors == null) ? true : false; this.localCheckSum = this.checkSum; for (byte b = 0; b < this.numberOfBindPositions; b++) { int i8 = this.currentBatchByteLens[b]; int i9 = this.currentBatchCharLens[b]; this.lastBinders[b] = arrayOfBinder[b]; this.lastBoundByteLens[b] = i8; for (byte b1 = 0; b1 < this.numberOfBoundRows; b1++) { int i10 = paramInt1 + b1; this.localCheckSum = this.binders[i10][b].bind(this, b, b1, i10, this.bindBytes, this.bindChars, this.bindIndicators, i8, i9, i1, i2, i4 + b1, i3 + b1, bool, this.localCheckSum); this.binders[i10][b] = null; if (this.userStream != null)
/*       */             this.userStream[b1][b] = null;  i1 += i8; i2 += i9; }
/*       */          if (this.bindChecksumListener != null) { boolean bool1 = this.bindChecksumListener.shouldContinue(this.checkSum); this.bindChecksumListener = null; if (!bool1) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 290); sQLException.fillInStackTrace(); throw sQLException; }
/*       */            }
/*       */          this.lastBoundByteOffsets[b] = i1 - i8; this.lastBoundCharOffsets[b] = i2 - i9; this.lastBoundInds[b] = this.bindIndicators[i3 + i6]; this.lastBoundLens[b] = this.bindIndicators[i4 + i6]; this.lastBoundByteLens[b] = 0; this.lastBoundCharLens[b] = 0; i1 += i5 * i8; i2 += i5 * i9; i3 += this.numberOfBindRowsAllocated; i4 += this.numberOfBindRowsAllocated; n += 10; }
/*       */        this.checkSum = this.localCheckSum; this.lastBoundBytes = this.bindBytes; this.lastBoundByteOffset = this.bindByteOffset; this.lastBoundChars = this.bindChars; this.lastBoundCharOffset = this.bindCharOffset; if (this.parameterStream != null)
/*       */         this.lastBoundStream = this.parameterStream[paramInt1 + this.numberOfBoundRows - 1];  int[] arrayOfInt1 = this.currentBatchByteLens; this.currentBatchByteLens = this.lastBoundByteLens; this.lastBoundByteLens = arrayOfInt1; int[] arrayOfInt2 = this.currentBatchCharLens; this.currentBatchCharLens = this.lastBoundCharLens; this.lastBoundCharLens = arrayOfInt2; this.lastBoundNeeded = false; prepareBindPreambles(this.numberOfBoundRows, this.bindBufferCapacity); configureBindData(); this.checkSum = this.localCheckSum; this.localCheckSum = 0L; }
/*       */     catch (NullPointerException nullPointerException) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 89, (Object)null, nullPointerException); sQLException.fillInStackTrace(); throw sQLException; }
/*       */      }
/*       */   void releaseBuffers() { super.releaseBuffers(); this.parameterStream = (InputStream[][])null; this.parameterInt = (int[][])null; this.parameterLong = (long[][])null; this.parameterFloat = (float[][])null; this.parameterDouble = (double[][])null; this.parameterBigDecimal = (BigDecimal[][])null; this.parameterString = (String[][])null; this.parameterDate = (Date[][])null; this.parameterTime = (Time[][])null; this.parameterTimestamp = (Timestamp[][])null; this.parameterDatum = (byte[][][])null; this.parameterOtype = (OracleTypeADT[][])null; this.connection.cacheBuffer(this.bindBytes); this.bindBytes = null; this.totalBindByteLength = 0; this.connection.cacheBuffer(this.bindChars); this.bindChars = null; this.totalBindCharLength = 0; this.bindIndicators = null; this.totalBindIndicatorLength = 0; this.bindBufferCapacity = 0; this.numberOfBindRowsAllocated = 1; this.lastBoundStream = null; this.userStream = (Object[][])null; try { clearParameters(); }
/*       */     catch (SQLException sQLException) {} }
/*       */   public void enterImplicitCache() throws SQLException { alwaysOnClose(); if (!this.connection.isClosed())
/*       */       cleanAllTempLobs();  if (this.connection.clearStatementMetaData) { this.lastBoundBytes = null; this.lastBoundChars = null; }
/*       */      this.cacheState = 2; this.creationState = 1; this.currentResultSet = null; this.lastIndex = 0; this.queryTimeout = 0; this.rowPrefetchChanged = false; this.currentRank = 0; this.currentBatchAccumulatedBindsSize = 0; this.validRows = 0; this.maxRows = 0; this.maxFieldSize = 0; this.gotLastBatch = false; this.clearParameters = true; this.defaultTimeZone = null; this.defaultCalendar = null; this.checkSum = 0L; this.checkSumComputationFailure = false; if (this.sqlKind.isOTHER()) { this.needToParse = true; this.needToPrepareDefineBuffer = true; this.columnsDefinedByUser = false; }
/*       */      releaseBuffers(); this.definedColumnType = null; this.definedColumnSize = null; this.definedColumnFormOfUse = null; if (this.accessors != null) { int i = this.accessors.length; for (byte b = 0; b < i; b++) { if (this.accessors[b] != null) { (this.accessors[b]).rowSpaceIndicator = null; if (this.columnsDefinedByUser)
/*       */             (this.accessors[b]).externalType = 0;  }
/*       */          }
/*       */        }
/*       */      this.fixedString = this.connection.getDefaultFixedString(); this.defaultRowPrefetch = this.rowPrefetch; this.rowPrefetchInLastFetch = -1; if (this.connection.clearStatementMetaData) { this.needToParse = true; this.needToPrepareDefineBuffer = true; this.columnsDefinedByUser = false; if (this.userRsetType == OracleResultSet.ResultSetType.UNKNOWN) { this.userRsetType = DEFAULT_RESULT_SET_TYPE; this.realRsetType = OracleResultSet.ResultSetType.FORWARD_READ_ONLY; }
/*       */        this.currentRowNeedToPrepareBinds = true; }
/*       */      }
/*       */   public void enterExplicitCache() throws SQLException { this.cacheState = 2; this.creationState = 2; this.defaultTimeZone = null; alwaysOnClose(); }
/*       */   public void exitImplicitCacheToActive() throws SQLException { this.cacheState = 1; this.closed = false; if (this.rowPrefetch != this.connection.getDefaultRowPrefetch())
/*       */       if (this.streamList == null) { this.rowPrefetch = this.connection.getDefaultRowPrefetch(); this.defaultRowPrefetch = this.rowPrefetch; this.rowPrefetchChanged = true; }
/*       */         if (this.batch != this.connection.getDefaultExecuteBatch())
/*       */       resetBatch();  this.processEscapes = this.connection.processEscapes; if (this.accessors != null)
/*       */       doInitializationAfterDefineBufferRestore();  if (this.cachedBindCharSize != 0 || this.cachedBindByteSize != 0) { if (this.cachedBindByteSize > 0)
/*       */         this.bindBytes = this.connection.getByteBuffer(this.cachedBindByteSize);  if (this.cachedBindCharSize > 0)
/*       */         this.bindChars = this.connection.getCharBuffer(this.cachedBindCharSize);  doLocalInitialization(); }
/*       */      }
/*       */   void doLocalInitialization() {}
/*       */   void doInitializationAfterDefineBufferRestore() {}
/*       */   public void exitExplicitCacheToActive() throws SQLException { this.cacheState = 1; this.closed = false; }
/*       */   public void exitImplicitCacheToClose() throws SQLException { this.cacheState = 0; this.closed = false; synchronized (this.connection) { hardClose(); }
/*       */      }
/*       */   public void exitExplicitCacheToClose() throws SQLException { this.cacheState = 0; this.closed = false; synchronized (this.connection) { hardClose(); }
/*       */      }
/*       */   public void closeWithKey(String paramString) throws SQLException { synchronized (this.connection) { closeOrCache(paramString); }
/*       */      }
/*       */   int executeInternal() throws SQLException { this.noMoreUpdateCounts = false; this.checkSum = 0L; this.checkSumComputationFailure = false; ensureOpen(); if (this.currentRank > 0 && this.m_batchStyle == 2) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 81, "batch must be either executed or cleared"); sQLException.fillInStackTrace(); throw sQLException; }
/*       */      boolean bool1 = (this.userRsetType == DEFAULT_RESULT_SET_TYPE) ? true : false; prepareForNewResults(true, false, true); processCompletedBindRow(this.sqlKind.isSELECT() ? 1 : this.batch, false); if (!bool1 && !this.scrollRsetTypeSolved)
/*       */       return doScrollPstmtExecuteUpdate() + this.prematureBatchCount;  doExecuteWithTimeout(); boolean bool2 = (this.prematureBatchCount != 0 && this.validRows > 0) ? true : false; if (!bool1) { computeOffsetOfFirstUserColumn(); this.currentResultSet = OracleResultSet.createResultSet(this); if (!this.connection.accumulateBatchResult)
/*       */         bool2 = false;  }
/*       */      if (bool2) { this.validRows += this.prematureBatchCount; this.prematureBatchCount = 0; }
/*       */      if (this.sqlKind.isOTHER())
/*       */       this.needToParse = true;  return this.validRows; }
/*       */   public ResultSet executeQuery() throws SQLException { synchronized (this.connection) { this.executeDoneForDefines = true; this.executionType = 1; executeInternal(); computeOffsetOfFirstUserColumn(); this.currentResultSet = OracleResultSet.createResultSet(this); return (ResultSet)this.currentResultSet; }
/*       */      }
/*  1288 */   OraclePreparedStatement(PhysicalConnection paramPhysicalConnection, String paramString, int paramInt1, int paramInt2) throws SQLException { this(paramPhysicalConnection, paramString, paramInt1, paramInt2, 1003, 1007);
/*       */ 
/*       */     
/*  1291 */     this.cacheState = 1; }
/*       */   public int executeUpdate() throws SQLException { synchronized (this.connection) { this.executionType = 2; return executeInternal(); }  }
/*       */   public boolean execute() throws SQLException { synchronized (this.connection) { this.executeDoneForDefines = true; this.executionType = 3; executeInternal(); return this.sqlKind.isSELECT(); }  }
/*       */   void slideDownCurrentRow(int paramInt) { if (this.binders != null) { this.binders[paramInt] = this.binders[0]; this.binders[0] = this.currentRowBinders; }  if (this.parameterInt != null) { int[] arrayOfInt = this.parameterInt[0]; this.parameterInt[0] = this.parameterInt[paramInt]; this.parameterInt[paramInt] = arrayOfInt; }  if (this.parameterLong != null) { long[] arrayOfLong = this.parameterLong[0]; this.parameterLong[0] = this.parameterLong[paramInt]; this.parameterLong[paramInt] = arrayOfLong; }  if (this.parameterFloat != null) { float[] arrayOfFloat = this.parameterFloat[0]; this.parameterFloat[0] = this.parameterFloat[paramInt]; this.parameterFloat[paramInt] = arrayOfFloat; }  if (this.parameterDouble != null) { double[] arrayOfDouble = this.parameterDouble[0]; this.parameterDouble[0] = this.parameterDouble[paramInt]; this.parameterDouble[paramInt] = arrayOfDouble; }  if (this.parameterBigDecimal != null) { BigDecimal[] arrayOfBigDecimal = this.parameterBigDecimal[0]; this.parameterBigDecimal[0] = this.parameterBigDecimal[paramInt]; this.parameterBigDecimal[paramInt] = arrayOfBigDecimal; }  if (this.parameterString != null) { String[] arrayOfString = this.parameterString[0]; this.parameterString[0] = this.parameterString[paramInt]; this.parameterString[paramInt] = arrayOfString; }  if (this.parameterDate != null) { Date[] arrayOfDate = this.parameterDate[0]; this.parameterDate[0] = this.parameterDate[paramInt]; this.parameterDate[paramInt] = arrayOfDate; }  if (this.parameterTime != null) { Time[] arrayOfTime = this.parameterTime[0]; this.parameterTime[0] = this.parameterTime[paramInt]; this.parameterTime[paramInt] = arrayOfTime; }  if (this.parameterTimestamp != null) { Timestamp[] arrayOfTimestamp = this.parameterTimestamp[0]; this.parameterTimestamp[0] = this.parameterTimestamp[paramInt]; this.parameterTimestamp[paramInt] = arrayOfTimestamp; }  if (this.parameterDatum != null) { byte[][] arrayOfByte = this.parameterDatum[0]; this.parameterDatum[0] = this.parameterDatum[paramInt]; this.parameterDatum[paramInt] = arrayOfByte; }  if (this.parameterOtype != null) { OracleTypeADT[] arrayOfOracleTypeADT = this.parameterOtype[0]; this.parameterOtype[0] = this.parameterOtype[paramInt]; this.parameterOtype[paramInt] = arrayOfOracleTypeADT; }  if (this.parameterStream != null) { InputStream[] arrayOfInputStream = this.parameterStream[0]; this.parameterStream[0] = this.parameterStream[paramInt]; this.parameterStream[paramInt] = arrayOfInputStream; }  if (this.userStream != null) { Object[] arrayOfObject = this.userStream[0]; this.userStream[0] = this.userStream[paramInt]; this.userStream[paramInt] = arrayOfObject; }  }
/*       */   void resetBatch() { this.batch = this.connection.getDefaultExecuteBatch(); }
/*       */   public int sendBatch() throws SQLException { if (isJdbcBatchStyle()) return 0;  synchronized (this.connection) { if (!this.connection.isUsable() || this.bsendBatchInProgress) { clearBatch(); this.bsendBatchInProgress = false; return 0; }  try { ensureOpen(); if (this.currentRank <= 0) return this.connection.accumulateBatchResult ? 0 : this.validRows;  int i = this.batch; this.bsendBatchInProgress = true; try { int j = this.currentRank; if (this.batch != this.currentRank) this.batch = this.currentRank;  setupBindBuffers(0, this.currentRank); this.currentRank--; doExecuteWithTimeout(); slideDownCurrentRow(j); } finally { if (this.batch != i) this.batch = i;  }  if (this.connection.accumulateBatchResult) { this.validRows += this.prematureBatchCount; this.prematureBatchCount = 0; }  return this.validRows; } finally { this.currentRank = 0; this.bsendBatchInProgress = false; }  }  }
/*       */   public void setExecuteBatch(int paramInt) throws SQLException { synchronized (this.connection) { if (paramInt <= 0) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 42); sQLException.fillInStackTrace(); throw sQLException; }  setOracleBatchStyle(); set_execute_batch(paramInt); }  }
/*       */   void set_execute_batch(int paramInt) throws SQLException { synchronized (this.connection) { if (paramInt <= 0) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 42); sQLException.fillInStackTrace(); throw sQLException; }  if (paramInt == this.batch) return;  if (this.currentRank > 0) { int j = this.validRows; this.prematureBatchCount = sendBatch(); this.validRows = j; }  int i = this.batch; this.batch = paramInt; if (this.numberOfBindRowsAllocated < this.batch) growBinds(this.batch);  }  }
/*       */   public final int getExecuteBatch() { return this.batch; }
/*       */   public void defineParameterTypeBytes(int paramInt1, int paramInt2, int paramInt3) throws SQLException { synchronized (this.connection) { SQLException sQLException; if (paramInt3 < 0) { SQLException sQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 53); sQLException1.fillInStackTrace(); throw sQLException1; }  if (paramInt1 < 1) { SQLException sQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3); sQLException1.fillInStackTrace(); throw sQLException1; }  switch (paramInt2) { case -7: case -6: case -5: case 2: case 3: case 4: case 5: case 6: case 7: case 8: paramInt2 = 6; break;case 1: paramInt2 = 96; break;case 12: paramInt2 = 1; break;case 91: case 92: paramInt2 = 12; break;case -103: paramInt2 = 182; break;case -104: paramInt2 = 183; break;case -100: case 93: paramInt2 = 180; break;case -101: paramInt2 = 181; break;case -102: paramInt2 = 231; break;case -3: case -2: paramInt2 = 23; break;case 100: paramInt2 = 100; break;case 101: paramInt2 = 101; break;case -8: paramInt2 = 104; break;case 2004: paramInt2 = 113; break;case 2005: paramInt2 = 112; break;case -13: paramInt2 = 114; break;case -10: paramInt2 = 102; break;case 0: sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4); sQLException.fillInStackTrace(); throw sQLException;default: sQLException = DatabaseError.createUnsupportedFeatureSqlException(); sQLException.fillInStackTrace(); throw sQLException; }  }  }
/*       */   public void defineParameterTypeChars(int paramInt1, int paramInt2, int paramInt3) throws SQLException { synchronized (this.connection) { int i = this.connection.getNlsRatio(); if (paramInt2 == 1 || paramInt2 == 12) { defineParameterTypeBytes(paramInt1, paramInt2, paramInt3 * i); } else { defineParameterTypeBytes(paramInt1, paramInt2, paramInt3); }  }  }
/*       */   public void defineParameterType(int paramInt1, int paramInt2, int paramInt3) throws SQLException { synchronized (this.connection) { defineParameterTypeBytes(paramInt1, paramInt2, paramInt3); }  }
/*  1303 */   public ResultSetMetaData getMetaData() throws SQLException { ensureOpen(); if (this.sqlKind.isSELECT()) return getResultSetMetaData();  return null; } public void setNull(int paramInt1, int paramInt2, String paramString) throws SQLException { setNullInternal(paramInt1, paramInt2, paramString); } void setNullInternal(int paramInt1, int paramInt2, String paramString) throws SQLException { int i = paramInt1 - 1; if (i < 0 || paramInt1 > this.numberOfBindPositions) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3); sQLException.fillInStackTrace(); throw sQLException; }  if (paramInt2 == 2002 || paramInt2 == 2008 || paramInt2 == 2003 || paramInt2 == 2007 || paramInt2 == 2009 || paramInt2 == 2006) { synchronized (this.connection) { setNullCritical(i, paramInt2, paramString); }  } else { setNullInternal(paramInt1, paramInt2); return; }  } void setNullInternal(int paramInt1, int paramInt2) throws SQLException { synchronized (this.connection) { setNullCritical(paramInt1, paramInt2); }  } void setNullCritical(int paramInt1, int paramInt2, String paramString) throws SQLException { OracleTypeCOLLECTION oracleTypeCOLLECTION; OracleTypeADT oracleTypeADT1; StructDescriptor structDescriptor; ArrayDescriptor arrayDescriptor; OpaqueDescriptor opaqueDescriptor; OracleTypeADT oracleTypeADT2 = null; Binder binder = this.theNamedTypeNullBinder; switch (paramInt2) { case 2006: binder = this.theRefTypeNullBinder;case 2002: case 2008: structDescriptor = StructDescriptor.createDescriptor(paramString, (Connection)this.connection); oracleTypeADT2 = structDescriptor.getOracleTypeADT(); break;case 2003: arrayDescriptor = ArrayDescriptor.createDescriptor(paramString, (Connection)this.connection); oracleTypeCOLLECTION = arrayDescriptor.getOracleTypeCOLLECTION(); break;case 2007: case 2009: opaqueDescriptor = OpaqueDescriptor.createDescriptor(paramString, (Connection)this.connection); oracleTypeADT1 = (OracleTypeADT)opaqueDescriptor.getPickler(); break; }  this.currentRowBinders[paramInt1] = binder; if (this.parameterDatum == null) this.parameterDatum = new byte[this.numberOfBindRowsAllocated][this.numberOfBindPositions][];  this.parameterDatum[this.currentRank][paramInt1] = null; if (oracleTypeADT1 != null) oracleTypeADT1.getTOID();  if (this.parameterOtype == null) this.parameterOtype = new OracleTypeADT[this.numberOfBindRowsAllocated][this.numberOfBindPositions];  this.parameterOtype[this.currentRank][paramInt1] = oracleTypeADT1; this.currentRowByteLens[paramInt1] = binder.bytelen; this.currentRowCharLens[paramInt1] = 0; } public void setNullAtName(String paramString1, int paramInt, String paramString2) throws SQLException { if (paramString1 == null) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68); sQLException.fillInStackTrace(); throw sQLException; }  String str = paramString1.intern(); String[] arrayOfString = this.sqlObject.getParameterList(); boolean bool = false; int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length); for (byte b = 0; b < i; b++) { if (arrayOfString[b] == str) { setNullInternal(b + 1, paramInt, paramString2); bool = true; }  }  if (!bool) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString1); sQLException.fillInStackTrace(); throw sQLException; }  } public void setNull(int paramInt1, int paramInt2) throws SQLException { synchronized (this.connection) { setNullCritical(paramInt1, paramInt2); }  } void setNullCritical(int paramInt1, int paramInt2) throws SQLException { SQLException sQLException; int i = paramInt1 - 1; if (i < 0 || paramInt1 > this.numberOfBindPositions) { SQLException sQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3); sQLException1.fillInStackTrace(); throw sQLException1; }  Binder binder = null; int j = getInternalType(paramInt2); boolean bool = true; switch (j) { case 6: binder = this.theVarnumNullBinder; break;case 1: case 8: case 96: case 995: binder = this.theVarcharNullBinder; bool = false; break;case 999: binder = this.theFixedCHARNullBinder; bool = false; break;case 12: binder = this.theDateNullBinder; break;case 180: binder = this.theTimestampNullBinder; break;case 181: binder = this.theTSTZNullBinder; break;case 231: binder = this.theTSLTZNullBinder; break;case 104: binder = getRowidNullBinder(i); break;case 183: binder = this.theIntervalDSNullBinder; break;case 182: binder = this.theIntervalYMNullBinder; break;case 23: case 24: binder = this.theRawNullBinder; break;case 100: binder = this.theBinaryFloatNullBinder; break;case 101: binder = this.theBinaryDoubleNullBinder; break;case 113: binder = this.theBlobNullBinder; break;case 112: binder = this.theClobNullBinder; break;case 114: binder = this.theBfileNullBinder; break;case 109: case 111: sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "sqlType=" + paramInt2); sQLException.fillInStackTrace(); throw sQLException;default: sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 23, "sqlType=" + paramInt2); sQLException.fillInStackTrace(); throw sQLException; }  this.currentRowBinders[i] = binder; if (bool) { this.currentRowByteLens[i] = binder.bytelen; this.currentRowCharLens[i] = 0; } else { this.currentRowByteLens[i] = 0; this.currentRowCharLens[i] = 1; }  } Binder getRowidNullBinder(int paramInt) { return this.theRowidNullBinder; } public void setNullAtName(String paramString, int paramInt) throws SQLException { if (paramString == null) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68); sQLException.fillInStackTrace(); throw sQLException; }  String str = paramString.intern(); String[] arrayOfString = this.sqlObject.getParameterList(); boolean bool = false; int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length); for (byte b = 0; b < i; b++) { if (arrayOfString[b] == str) { setNull(b + 1, paramInt); bool = true; }  }  if (!bool) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString); sQLException.fillInStackTrace(); throw sQLException; }  } public void setBoolean(int paramInt, boolean paramBoolean) throws SQLException { synchronized (this.connection) { setBooleanInternal(paramInt, paramBoolean); }  } void setBooleanInternal(int paramInt, boolean paramBoolean) throws SQLException { int i = paramInt - 1; if (i < 0 || paramInt > this.numberOfBindPositions) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3); sQLException.fillInStackTrace(); throw sQLException; }  this.currentRowBinders[i] = this.theBooleanBinder; this.currentRowByteLens[i] = (this.currentRowBinders[i]).bytelen; this.currentRowCharLens[i] = 0; if (this.parameterInt == null) this.parameterInt = new int[this.numberOfBindRowsAllocated][this.numberOfBindPositions];  this.parameterInt[this.currentRank][i] = paramBoolean ? 1 : 0; } public void setByte(int paramInt, byte paramByte) throws SQLException { synchronized (this.connection) { setByteInternal(paramInt, paramByte); }  } void setByteInternal(int paramInt, byte paramByte) throws SQLException { int i = paramInt - 1; if (i < 0 || paramInt > this.numberOfBindPositions) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3); sQLException.fillInStackTrace(); throw sQLException; }  this.currentRowBinders[i] = this.theByteBinder; this.currentRowByteLens[i] = (this.currentRowBinders[i]).bytelen; this.currentRowCharLens[i] = 0; if (this.parameterInt == null) this.parameterInt = new int[this.numberOfBindRowsAllocated][this.numberOfBindPositions];  this.parameterInt[this.currentRank][i] = paramByte; } public void setShort(int paramInt, short paramShort) throws SQLException { synchronized (this.connection) { setShortInternal(paramInt, paramShort); }  } void setShortInternal(int paramInt, short paramShort) throws SQLException { int i = paramInt - 1; if (i < 0 || paramInt > this.numberOfBindPositions) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3); sQLException.fillInStackTrace(); throw sQLException; }  this.currentRowBinders[i] = this.theShortBinder; this.currentRowByteLens[i] = (this.currentRowBinders[i]).bytelen; this.currentRowCharLens[i] = 0; if (this.parameterInt == null) this.parameterInt = new int[this.numberOfBindRowsAllocated][this.numberOfBindPositions];  this.parameterInt[this.currentRank][i] = paramShort; } public void setInt(int paramInt1, int paramInt2) throws SQLException { synchronized (this.connection) { setIntInternal(paramInt1, paramInt2); }  } void setIntInternal(int paramInt1, int paramInt2) throws SQLException { int i = paramInt1 - 1; if (i < 0 || paramInt1 > this.numberOfBindPositions) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3); sQLException.fillInStackTrace(); throw sQLException; }  this.currentRowBinders[i] = this.theIntBinder; this.currentRowByteLens[i] = (this.currentRowBinders[i]).bytelen; this.currentRowCharLens[i] = 0; if (this.parameterInt == null) this.parameterInt = new int[this.numberOfBindRowsAllocated][this.numberOfBindPositions];  this.parameterInt[this.currentRank][i] = paramInt2; } public void setLong(int paramInt, long paramLong) throws SQLException { synchronized (this.connection) { setLongInternal(paramInt, paramLong); }  } void setLongInternal(int paramInt, long paramLong) throws SQLException { int i = paramInt - 1; if (i < 0 || paramInt > this.numberOfBindPositions) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3); sQLException.fillInStackTrace(); throw sQLException; }  this.currentRowBinders[i] = this.theLongBinder; this.currentRowByteLens[i] = (this.currentRowBinders[i]).bytelen; this.currentRowCharLens[i] = 0; if (this.parameterLong == null) this.parameterLong = new long[this.numberOfBindRowsAllocated][this.numberOfBindPositions];  this.parameterLong[this.currentRank][i] = paramLong; } public void setFloat(int paramInt, float paramFloat) throws SQLException { synchronized (this.connection) { setFloatInternal(paramInt, paramFloat); }  } void setFloatInternal(int paramInt, float paramFloat) throws SQLException { int i = paramInt - 1; if (i < 0 || paramInt > this.numberOfBindPositions) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3); sQLException.fillInStackTrace(); throw sQLException; }  if (!this.connection.setFloatAndDoubleUseBinary) if (Float.isNaN(paramFloat)) throw new IllegalArgumentException("NaN");   if (this.theFloatBinder == null) { this.theFloatBinder = theStaticFloatBinder; if (this.connection.setFloatAndDoubleUseBinary) this.theFloatBinder = theStaticBinaryFloatBinder;  }  this.currentRowBinders[i] = this.theFloatBinder; this.currentRowByteLens[i] = (this.currentRowBinders[i]).bytelen; this.currentRowCharLens[i] = 0; if (this.theFloatBinder == theStaticFloatBinder) { if (this.parameterDouble == null) this.parameterDouble = new double[this.numberOfBindRowsAllocated][this.numberOfBindPositions];  this.parameterDouble[this.currentRank][i] = paramFloat; } else { if (this.parameterFloat == null) this.parameterFloat = new float[this.numberOfBindRowsAllocated][this.numberOfBindPositions];  this.parameterFloat[this.currentRank][i] = paramFloat; }  } public void setBinaryFloat(int paramInt, float paramFloat) throws SQLException { synchronized (this.connection) { setBinaryFloatInternal(paramInt, paramFloat); }  } void setBinaryFloatInternal(int paramInt, float paramFloat) throws SQLException { int i = paramInt - 1; if (i < 0 || paramInt > this.numberOfBindPositions) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3); sQLException.fillInStackTrace(); throw sQLException; }  this.currentRowBinders[i] = this.theBinaryFloatBinder; this.currentRowByteLens[i] = (this.currentRowBinders[i]).bytelen; this.currentRowCharLens[i] = 0; if (this.parameterFloat == null) this.parameterFloat = new float[this.numberOfBindRowsAllocated][this.numberOfBindPositions];  this.parameterFloat[this.currentRank][i] = paramFloat; } public void setBinaryFloat(int paramInt, BINARY_FLOAT paramBINARY_FLOAT) throws SQLException { synchronized (this.connection) { setBinaryFloatInternal(paramInt, paramBINARY_FLOAT); }  } void setBinaryFloatInternal(int paramInt, BINARY_FLOAT paramBINARY_FLOAT) throws SQLException { int i = paramInt - 1; if (i < 0 || paramInt > this.numberOfBindPositions) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3); sQLException.fillInStackTrace(); throw sQLException; }  if (paramBINARY_FLOAT == null) { this.currentRowBinders[i] = this.theBINARY_FLOATNullBinder; } else { this.currentRowBinders[i] = this.theBINARY_FLOATBinder; if (this.parameterDatum == null) this.parameterDatum = new byte[this.numberOfBindRowsAllocated][this.numberOfBindPositions][];  this.parameterDatum[this.currentRank][i] = paramBINARY_FLOAT.getBytes(); }  this.currentRowByteLens[i] = (this.currentRowBinders[i]).bytelen; this.currentRowCharLens[i] = 0; } public void setBinaryDouble(int paramInt, double paramDouble) throws SQLException { synchronized (this.connection) { setBinaryDoubleInternal(paramInt, paramDouble); }  } void setBinaryDoubleInternal(int paramInt, double paramDouble) throws SQLException { int i = paramInt - 1; if (i < 0 || paramInt > this.numberOfBindPositions) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3); sQLException.fillInStackTrace(); throw sQLException; }  this.currentRowBinders[i] = this.theBinaryDoubleBinder; if (this.parameterDouble == null) this.parameterDouble = new double[this.numberOfBindRowsAllocated][this.numberOfBindPositions];  this.currentRowByteLens[i] = (this.currentRowBinders[i]).bytelen; this.currentRowCharLens[i] = 0; this.parameterDouble[this.currentRank][i] = paramDouble; } public void setBinaryDouble(int paramInt, BINARY_DOUBLE paramBINARY_DOUBLE) throws SQLException { synchronized (this.connection) { setBinaryDoubleInternal(paramInt, paramBINARY_DOUBLE); }  } void setBinaryDoubleInternal(int paramInt, BINARY_DOUBLE paramBINARY_DOUBLE) throws SQLException { int i = paramInt - 1; if (i < 0 || paramInt > this.numberOfBindPositions) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3); sQLException.fillInStackTrace(); throw sQLException; }  if (paramBINARY_DOUBLE == null) { this.currentRowBinders[i] = this.theBINARY_DOUBLENullBinder; } else { this.currentRowBinders[i] = this.theBINARY_DOUBLEBinder; if (this.parameterDatum == null) this.parameterDatum = new byte[this.numberOfBindRowsAllocated][this.numberOfBindPositions][];  this.parameterDatum[this.currentRank][i] = paramBINARY_DOUBLE.getBytes(); }  this.currentRowByteLens[i] = (this.currentRowBinders[i]).bytelen; this.currentRowCharLens[i] = 0; } public void setDouble(int paramInt, double paramDouble) throws SQLException { synchronized (this.connection) { setDoubleInternal(paramInt, paramDouble); }  } void setDoubleInternal(int paramInt, double paramDouble) throws SQLException { int i = paramInt - 1; if (i < 0 || paramInt > this.numberOfBindPositions) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3); sQLException.fillInStackTrace(); throw sQLException; }  if (!this.connection.setFloatAndDoubleUseBinary) { if (Double.isNaN(paramDouble)) throw new IllegalArgumentException("NaN");  double d = Math.abs(paramDouble); if (d != 0.0D && d < 1.0E-130D) throw new IllegalArgumentException("Underflow");  if (d >= 1.0E126D) throw new IllegalArgumentException("Overflow");  }  if (this.theDoubleBinder == null) { this.theDoubleBinder = theStaticDoubleBinder; if (this.connection.setFloatAndDoubleUseBinary) this.theDoubleBinder = theStaticBinaryDoubleBinder;  }  this.currentRowBinders[i] = this.theDoubleBinder; this.currentRowByteLens[i] = (this.currentRowBinders[i]).bytelen; this.currentRowCharLens[i] = 0; if (this.parameterDouble == null) this.parameterDouble = new double[this.numberOfBindRowsAllocated][this.numberOfBindPositions];  this.parameterDouble[this.currentRank][i] = paramDouble; } public void setBigDecimal(int paramInt, BigDecimal paramBigDecimal) throws SQLException { synchronized (this.connection) { setBigDecimalInternal(paramInt, paramBigDecimal); }  } void setBigDecimalInternal(int paramInt, BigDecimal paramBigDecimal) throws SQLException { int i = paramInt - 1; if (i < 0 || paramInt > this.numberOfBindPositions) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3); sQLException.fillInStackTrace(); throw sQLException; }  if (paramBigDecimal == null) { this.currentRowBinders[i] = this.theVarnumNullBinder; } else { this.currentRowBinders[i] = this.theBigDecimalBinder; if (this.parameterBigDecimal == null) this.parameterBigDecimal = new BigDecimal[this.numberOfBindRowsAllocated][this.numberOfBindPositions];  this.parameterBigDecimal[this.currentRank][i] = paramBigDecimal; }  this.currentRowByteLens[i] = (this.currentRowBinders[i]).bytelen; this.currentRowCharLens[i] = 0; } public void setString(int paramInt, String paramString) throws SQLException { setStringInternal(paramInt, paramString); } void setStringInternal(int paramInt, String paramString) throws SQLException { int i = paramInt - 1; if (i < 0 || paramInt > this.numberOfBindPositions) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3); sQLException.fillInStackTrace(); throw sQLException; }  byte b = (paramString != null) ? paramString.length() : 0; if (!b) { setNull(paramInt, 12); } else if (this.currentRowFormOfUse[paramInt - 1] == 1) { if (this.sqlKind.isPlsqlOrCall()) { if (b > this.maxVcsBytesPlsql || (b > this.maxVcsCharsPlsql && this.isServerCharSetFixedWidth)) { setStringForClobCritical(paramInt, paramString); } else if (b > this.maxVcsCharsPlsql) { int j = this.connection.conversion.encodedByteLength(paramString, false); if (j > this.maxVcsBytesPlsql) { setStringForClobCritical(paramInt, paramString); } else { basicBindString(paramInt, paramString); }  } else { basicBindString(paramInt, paramString); }  } else if (b <= this.maxVcsCharsSql) { basicBindString(paramInt, paramString); } else if (b <= this.maxStreamCharsSql) { basicBindCharacterStream(paramInt, new StringReader(paramString), b, true); } else { setStringForClobCritical(paramInt, paramString); }  } else if (this.sqlKind.isPlsqlOrCall()) { if (b > this.maxVcsBytesPlsql || (b > this.maxVcsNCharsPlsql && this.isServerNCharSetFixedWidth)) { setStringForClobCritical(paramInt, paramString); } else if (b > this.maxVcsNCharsPlsql) { int j = this.connection.conversion.encodedByteLength(paramString, true); if (j > this.maxVcsBytesPlsql) { setStringForClobCritical(paramInt, paramString); } else { basicBindString(paramInt, paramString); }  } else { basicBindString(paramInt, paramString); }  } else if (b <= this.maxVcsCharsSql) { basicBindString(paramInt, paramString); } else { setStringForClobCritical(paramInt, paramString); }  } void basicBindNullString(int paramInt) throws SQLException { synchronized (this.connection) { int i = paramInt - 1; this.currentRowBinders[i] = this.theVarcharNullBinder; if (this.sqlKind.isPlsqlOrCall()) { this.currentRowCharLens[i] = this.minVcsBindSize; } else { this.currentRowCharLens[i] = 1; }  this.currentRowByteLens[i] = 0; }  } void basicBindString(int paramInt, String paramString) throws SQLException { synchronized (this.connection) { int i = paramInt - 1; this.currentRowBinders[i] = this.theStringBinder; int j = paramString.length(); if (this.sqlKind.isPlsqlOrCall()) { int k = this.connection.minVcsBindSize; int m = j + 1; this.currentRowCharLens[i] = (m < k) ? k : m; } else { this.currentRowCharLens[i] = j + 1; }  if (this.parameterString == null) this.parameterString = new String[this.numberOfBindRowsAllocated][this.numberOfBindPositions];  this.parameterString[this.currentRank][i] = paramString; this.currentRowByteLens[i] = 0; }  } public void setStringForClob(int paramInt, String paramString) throws SQLException { if (paramString == null) { setNull(paramInt, 1); return; }  int i = paramString.length(); if (i == 0) { setNull(paramInt, 1); return; }  if (this.sqlKind.isPlsqlOrCall()) { if (i <= this.maxVcsCharsPlsql) { setStringInternal(paramInt, paramString); } else { setStringForClobCritical(paramInt, paramString); }  } else if (i <= this.maxVcsCharsSql) { setStringInternal(paramInt, paramString); } else { setStringForClobCritical(paramInt, paramString); }  } void setStringForClobCritical(int paramInt, String paramString) throws SQLException { synchronized (this.connection) { CLOB cLOB = CLOB.createTemporary((Connection)this.connection, true, 10, this.currentRowFormOfUse[paramInt - 1]); cLOB.setString(1L, paramString); addToTempLobsToFree(cLOB); this.lastBoundClobs[paramInt - 1] = cLOB; setCLOBInternal(paramInt, cLOB); }  } void setReaderContentsForClobCritical(int paramInt, Reader paramReader, long paramLong, boolean paramBoolean) throws SQLException { synchronized (this.connection) { try { if ((paramReader = isReaderEmpty(paramReader)) == null) { if (paramBoolean) throw new IOException(paramLong + " char of CLOB data cannot be read");  setCLOBInternal(paramInt, (CLOB)null); return; }  } catch (IOException iOException) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException); sQLException.fillInStackTrace(); throw sQLException; }  CLOB cLOB = CLOB.createTemporary((Connection)this.connection, true, 10, this.currentRowFormOfUse[paramInt - 1]); OracleClobWriter oracleClobWriter = (OracleClobWriter)cLOB.setCharacterStream(1L); int i = cLOB.getBufferSize(); char[] arrayOfChar = new char[i]; long l = 0L; int j = 0; l = paramBoolean ? paramLong : Long.MAX_VALUE; try { while (l > 0L) { if (l >= i) { j = paramReader.read(arrayOfChar); } else { j = paramReader.read(arrayOfChar, 0, (int)l); }  if (j == -1) { if (paramBoolean) throw new IOException(l + " char of CLOB data cannot be read");  break; }  oracleClobWriter.write(arrayOfChar, 0, j); l -= j; }  oracleClobWriter.flush(); } catch (IOException iOException) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException); sQLException.fillInStackTrace(); throw sQLException; }  addToTempLobsToFree(cLOB); this.lastBoundClobs[paramInt - 1] = cLOB; setCLOBInternal(paramInt, cLOB); }  } OraclePreparedStatement(PhysicalConnection paramPhysicalConnection, String paramString, int paramInt1, int paramInt2, int paramInt3, int paramInt4) throws SQLException { super(paramPhysicalConnection, paramInt1, paramInt2, paramInt3, paramInt4);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*  5709 */     this.SetBigStringTryClob = 0;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/* 10685 */     this.m_batchStyle = 0; this.cacheState = 1; if (paramInt1 > 1) setOracleBatchStyle();  this.theSetCHARBinder = paramPhysicalConnection.useLittleEndianSetCHARBinder() ? theStaticLittleEndianSetCHARBinder : theStaticSetCHARBinder; this.theURowidBinder = this.theRowidBinder = paramPhysicalConnection.useLittleEndianSetCHARBinder() ? theStaticLittleEndianRowidBinder : theStaticRowidBinder; this.statementType = 1; this.needToParse = true; this.processEscapes = paramPhysicalConnection.processEscapes; this.sqlObject.initialize(paramString); this.sqlKind = this.sqlObject.getSqlKind(); this.clearParameters = true; this.scrollRsetTypeSolved = false; this.prematureBatchCount = 0; initializeBinds(); this.minVcsBindSize = paramPhysicalConnection.minVcsBindSize; this.maxRawBytesSql = paramPhysicalConnection.maxRawBytesSql; this.maxRawBytesPlsql = paramPhysicalConnection.maxRawBytesPlsql; this.maxVcsCharsSql = paramPhysicalConnection.maxVcsCharsSql; this.maxVcsNCharsSql = paramPhysicalConnection.maxVcsNCharsSql; this.maxVcsBytesPlsql = paramPhysicalConnection.maxVcsBytesPlsql; this.maxIbtVarcharElementLength = paramPhysicalConnection.maxIbtVarcharElementLength; this.maxCharSize = this.connection.conversion.sMaxCharSize; this.maxNCharSize = this.connection.conversion.maxNCharSize; this.maxVcsCharsPlsql = this.maxVcsBytesPlsql / this.maxCharSize; this.maxVcsNCharsPlsql = this.maxVcsBytesPlsql / this.maxNCharSize; this.maxStreamCharsSql = Integer.MAX_VALUE / this.maxCharSize; this.maxStreamNCharsSql = this.maxRawBytesSql / this.maxNCharSize; this.isServerCharSetFixedWidth = this.connection.conversion.isServerCharSetFixedWidth; this.isServerNCharSetFixedWidth = this.connection.conversion.isServerNCharSetFixedWidth; }
/*       */   void setAsciiStreamContentsForClobCritical(int paramInt, InputStream paramInputStream, long paramLong, boolean paramBoolean) throws SQLException { synchronized (this.connection) { try { if ((paramInputStream = isInputStreamEmpty(paramInputStream)) == null) { if (paramBoolean) throw new IOException(paramLong + " byte of CLOB data cannot be read");  setCLOBInternal(paramInt, (CLOB)null); return; }  } catch (IOException iOException) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException); sQLException.fillInStackTrace(); throw sQLException; }  CLOB cLOB = CLOB.createTemporary((Connection)this.connection, true, 10, this.currentRowFormOfUse[paramInt - 1]); OracleClobWriter oracleClobWriter = (OracleClobWriter)cLOB.setCharacterStream(1L); int i = cLOB.getBufferSize(); byte[] arrayOfByte = new byte[i]; char[] arrayOfChar = new char[i]; int j = 0; long l = paramBoolean ? paramLong : Long.MAX_VALUE; try { while (l > 0L) { if (l >= i) { j = paramInputStream.read(arrayOfByte); } else { j = paramInputStream.read(arrayOfByte, 0, (int)l); }  if (j == -1) { if (paramBoolean) throw new IOException(l + " byte of CLOB data cannot be read");  break; }  DBConversion.asciiBytesToJavaChars(arrayOfByte, j, arrayOfChar); oracleClobWriter.write(arrayOfChar, 0, j); l -= j; }  oracleClobWriter.flush(); } catch (IOException iOException) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException); sQLException.fillInStackTrace(); throw sQLException; }  addToTempLobsToFree(cLOB); this.lastBoundClobs[paramInt - 1] = cLOB; setCLOBInternal(paramInt, cLOB); }  }
/*       */   public void setStringForClobAtName(String paramString1, String paramString2) throws SQLException { if (paramString1 == null) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68); sQLException.fillInStackTrace(); throw sQLException; }  String str = paramString1.intern(); String[] arrayOfString = this.sqlObject.getParameterList(); boolean bool = false; int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length); for (byte b = 0; b < i; b++) { if (arrayOfString[b] == str) { setStringForClob(b + 1, paramString2); bool = true; }  }  if (!bool) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString1); sQLException.fillInStackTrace(); throw sQLException; }  }
/*       */   public void setFixedCHAR(int paramInt, String paramString) throws SQLException { synchronized (this.connection) { setFixedCHARInternal(paramInt, paramString); }  }
/*       */   void setFixedCHARInternal(int paramInt, String paramString) throws SQLException { int i = paramInt - 1; if (i < 0 || paramInt > this.numberOfBindPositions) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3); sQLException.fillInStackTrace(); throw sQLException; }  int j = 0; if (paramString != null) j = paramString.length();  if (j > 32766) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 157); sQLException.fillInStackTrace(); throw sQLException; }  if (paramString == null) { this.currentRowBinders[i] = this.theFixedCHARNullBinder; this.currentRowCharLens[i] = 1; } else { this.currentRowBinders[i] = this.theFixedCHARBinder; this.currentRowCharLens[i] = j + 1; if (this.parameterString == null) this.parameterString = new String[this.numberOfBindRowsAllocated][this.numberOfBindPositions];  this.parameterString[this.currentRank][i] = paramString; }  this.currentRowByteLens[i] = 0; }
/*       */   public void setCursor(int paramInt, ResultSet paramResultSet) throws SQLException { synchronized (this.connection) { setCursorInternal(paramInt, paramResultSet); }  }
/*       */   void setCursorInternal(int paramInt, ResultSet paramResultSet) throws SQLException { SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException(); sQLException.fillInStackTrace(); throw sQLException; }
/*       */   public void setROWID(int paramInt, ROWID paramROWID) throws SQLException { synchronized (this.connection) { setROWIDInternal(paramInt, paramROWID); }  }
/*       */   void setROWIDInternal(int paramInt, ROWID paramROWID) throws SQLException { if (this.sqlKind == OracleStatement.SqlKind.CALL_BLOCK) { if (paramROWID == null) { setNull(paramInt, 12); } else { setStringInternal(paramInt, paramROWID.stringValue()); }  return; }  int i = paramInt - 1; if (i < 0 || paramInt > this.numberOfBindPositions) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3); sQLException.fillInStackTrace(); throw sQLException; }  if (paramROWID == null || paramROWID.shareBytes() == null) { this.currentRowBinders[i] = this.theRowidNullBinder; this.currentRowByteLens[i] = (this.currentRowBinders[i]).bytelen; } else { this.currentRowBinders[i] = T4CRowidAccessor.isUROWID(paramROWID.shareBytes(), 0) ? this.theURowidBinder : this.theRowidBinder; if (this.parameterDatum == null) this.parameterDatum = new byte[this.numberOfBindRowsAllocated][this.numberOfBindPositions][];  byte[] arrayOfByte = paramROWID.getBytes(); this.parameterDatum[this.currentRank][i] = arrayOfByte; this.currentRowByteLens[i] = arrayOfByte.length + 2; }  this.currentRowCharLens[i] = 0; }
/*       */   public void setArray(int paramInt, Array paramArray) throws SQLException { setARRAYInternal(paramInt, (ARRAY)paramArray); }
/*       */   void setArrayInternal(int paramInt, Array paramArray) throws SQLException { setARRAYInternal(paramInt, (ARRAY)paramArray); }
/* 10696 */   public void setARRAY(int paramInt, ARRAY paramARRAY) throws SQLException { setARRAYInternal(paramInt, paramARRAY); } void setARRAYInternal(int paramInt, ARRAY paramARRAY) throws SQLException { int i = paramInt - 1; if (i < 0 || paramInt > this.numberOfBindPositions) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3); sQLException.fillInStackTrace(); throw sQLException; }  if (paramARRAY == null) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68); sQLException.fillInStackTrace(); throw sQLException; }  synchronized (this.connection) { setArrayCritical(i, paramARRAY); this.currentRowCharLens[i] = 0; }  } void setArrayCritical(int paramInt, ARRAY paramARRAY) throws SQLException { ArrayDescriptor arrayDescriptor = paramARRAY.getDescriptor(); if (arrayDescriptor == null) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 61); sQLException.fillInStackTrace(); throw sQLException; }  this.currentRowBinders[paramInt] = this.theNamedTypeBinder; this.currentRowByteLens[paramInt] = (this.currentRowBinders[paramInt]).bytelen; this.currentRowCharLens[paramInt] = 0; if (this.parameterDatum == null) this.parameterDatum = new byte[this.numberOfBindRowsAllocated][this.numberOfBindPositions][];  this.parameterDatum[this.currentRank][paramInt] = paramARRAY.toBytes(); OracleTypeCOLLECTION oracleTypeCOLLECTION = arrayDescriptor.getOracleTypeCOLLECTION(); oracleTypeCOLLECTION.getTOID(); if (this.parameterOtype == null) this.parameterOtype = new OracleTypeADT[this.numberOfBindRowsAllocated][this.numberOfBindPositions];  this.parameterOtype[this.currentRank][paramInt] = (OracleTypeADT)oracleTypeCOLLECTION; } public void setOPAQUE(int paramInt, OPAQUE paramOPAQUE) throws SQLException { setOPAQUEInternal(paramInt, paramOPAQUE); } void setOPAQUEInternal(int paramInt, OPAQUE paramOPAQUE) throws SQLException { int i = paramInt - 1; if (i < 0 || paramInt > this.numberOfBindPositions) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3); sQLException.fillInStackTrace(); throw sQLException; }  if (paramOPAQUE == null) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68); sQLException.fillInStackTrace(); throw sQLException; }  synchronized (this.connection) { setOPAQUECritical(i, paramOPAQUE); this.currentRowCharLens[i] = 0; }  } void setOPAQUECritical(int paramInt, OPAQUE paramOPAQUE) throws SQLException { OpaqueDescriptor opaqueDescriptor = paramOPAQUE.getDescriptor(); if (opaqueDescriptor == null) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 61); sQLException.fillInStackTrace(); throw sQLException; }  this.currentRowBinders[paramInt] = this.theNamedTypeBinder; this.currentRowByteLens[paramInt] = (this.currentRowBinders[paramInt]).bytelen; this.currentRowCharLens[paramInt] = 0; if (this.parameterDatum == null) this.parameterDatum = new byte[this.numberOfBindRowsAllocated][this.numberOfBindPositions][];  this.parameterDatum[this.currentRank][paramInt] = paramOPAQUE.toBytes(); OracleTypeADT oracleTypeADT = (OracleTypeADT)opaqueDescriptor.getPickler(); oracleTypeADT.getTOID(); if (this.parameterOtype == null) this.parameterOtype = new OracleTypeADT[this.numberOfBindRowsAllocated][this.numberOfBindPositions];  this.parameterOtype[this.currentRank][paramInt] = oracleTypeADT; } void setSQLXMLInternal(int paramInt, SQLXML paramSQLXML) throws SQLException { if (paramSQLXML == null) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68); sQLException.fillInStackTrace(); throw sQLException; }  setOPAQUEInternal(paramInt, (OPAQUE)paramSQLXML); } public void setStructDescriptor(int paramInt, StructDescriptor paramStructDescriptor) throws SQLException { setStructDescriptorInternal(paramInt, paramStructDescriptor); } void setStructDescriptorInternal(int paramInt, StructDescriptor paramStructDescriptor) throws SQLException { int i = paramInt - 1; if (i < 0 || paramInt > this.numberOfBindPositions) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3); sQLException.fillInStackTrace(); throw sQLException; }  if (paramStructDescriptor == null) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68); sQLException.fillInStackTrace(); throw sQLException; }  synchronized (this.connection) { setStructDescriptorCritical(i, paramStructDescriptor); this.currentRowCharLens[i] = 0; }  } void setStructDescriptorCritical(int paramInt, StructDescriptor paramStructDescriptor) throws SQLException { this.currentRowBinders[paramInt] = this.theNamedTypeBinder; this.currentRowByteLens[paramInt] = (this.currentRowBinders[paramInt]).bytelen; this.currentRowCharLens[paramInt] = 0; if (this.parameterDatum == null) this.parameterDatum = new byte[this.numberOfBindRowsAllocated][this.numberOfBindPositions][];  OracleTypeADT oracleTypeADT = paramStructDescriptor.getOracleTypeADT(); oracleTypeADT.getTOID(); if (this.parameterOtype == null) this.parameterOtype = new OracleTypeADT[this.numberOfBindRowsAllocated][this.numberOfBindPositions];  this.parameterOtype[this.currentRank][paramInt] = oracleTypeADT; } public void setStructDescriptorAtName(String paramString, StructDescriptor paramStructDescriptor) throws SQLException { if (paramString == null) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68); sQLException.fillInStackTrace(); throw sQLException; }  String str = paramString.intern(); String[] arrayOfString = this.sqlObject.getParameterList(); boolean bool = false; int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length); for (byte b = 0; b < i; b++) { if (arrayOfString[b] == str) { setStructDescriptorInternal(b + 1, paramStructDescriptor); bool = true; }  }  if (!bool) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString); sQLException.fillInStackTrace(); throw sQLException; }  } void setPreBindsCompelete() throws SQLException {} public void setSTRUCT(int paramInt, STRUCT paramSTRUCT) throws SQLException { setSTRUCTInternal(paramInt, paramSTRUCT); } void setSTRUCTInternal(int paramInt, STRUCT paramSTRUCT) throws SQLException { int i = paramInt - 1; if (i < 0 || paramInt > this.numberOfBindPositions) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3); sQLException.fillInStackTrace(); throw sQLException; }  if (paramSTRUCT == null) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68); sQLException.fillInStackTrace(); throw sQLException; }  synchronized (this.connection) { setSTRUCTCritical(i, paramSTRUCT); this.currentRowCharLens[i] = 0; }  } void setSTRUCTCritical(int paramInt, STRUCT paramSTRUCT) throws SQLException { StructDescriptor structDescriptor = paramSTRUCT.getDescriptor(); if (structDescriptor == null) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 61); sQLException.fillInStackTrace(); throw sQLException; }  this.currentRowBinders[paramInt] = this.theNamedTypeBinder; this.currentRowByteLens[paramInt] = (this.currentRowBinders[paramInt]).bytelen; this.currentRowCharLens[paramInt] = 0; if (this.parameterDatum == null) this.parameterDatum = new byte[this.numberOfBindRowsAllocated][this.numberOfBindPositions][];  this.parameterDatum[this.currentRank][paramInt] = paramSTRUCT.toBytes(); OracleTypeADT oracleTypeADT = structDescriptor.getOracleTypeADT(); oracleTypeADT.getTOID(); if (this.parameterOtype == null) this.parameterOtype = new OracleTypeADT[this.numberOfBindRowsAllocated][this.numberOfBindPositions];  this.parameterOtype[this.currentRank][paramInt] = oracleTypeADT; } final void setOracleBatchStyle() throws SQLException { if (this.m_batchStyle == 2) {
/*       */ 
/*       */       
/* 10699 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "operation cannot be mixed with JDBC-2.0-style batching");
/* 10700 */       sQLException.fillInStackTrace();
/* 10701 */       throw sQLException;
/*       */     } 
/*       */     
/* 10704 */     if (this.m_batchStyle == 0);
/*       */ 
/*       */ 
/*       */ 
/*       */     
/* 10709 */     this.m_batchStyle = 1; } public void setRAW(int paramInt, RAW paramRAW) throws SQLException { setRAWInternal(paramInt, paramRAW); } void setRAWInternal(int paramInt, RAW paramRAW) throws SQLException { boolean bool = false; synchronized (this.connection) { int i = paramInt - 1; if (i < 0 || paramInt > this.numberOfBindPositions) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3); sQLException.fillInStackTrace(); throw sQLException; }  if (paramRAW == null) { this.currentRowBinders[i] = this.theRawNullBinder; this.currentRowByteLens[i] = (this.currentRowBinders[i]).bytelen; this.currentRowCharLens[i] = 0; } else { bool = true; }  }  if (bool) setBytesInternal(paramInt, paramRAW.getBytes());  } public void setCHAR(int paramInt, CHAR paramCHAR) throws SQLException { synchronized (this.connection) { setCHARInternal(paramInt, paramCHAR); }  } void setCHARInternal(int paramInt, CHAR paramCHAR) throws SQLException { int i = paramInt - 1; if (i < 0 || paramInt > this.numberOfBindPositions) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3); sQLException.fillInStackTrace(); throw sQLException; }  if (paramCHAR == null || paramCHAR.getLength() == 0L) { this.currentRowBinders[i] = this.theSetCHARNullBinder; this.currentRowCharLens[i] = 1; } else { byte[] arrayOfByte; short s = (short)paramCHAR.oracleId(); this.currentRowBinders[i] = this.theSetCHARBinder; if (this.parameterDatum == null) this.parameterDatum = new byte[this.numberOfBindRowsAllocated][this.numberOfBindPositions][];  CharacterSet characterSet = (this.currentRowFormOfUse[i] == 2) ? this.connection.setCHARNCharSetObj : this.connection.setCHARCharSetObj; if (characterSet != null && characterSet.getOracleId() != s) { byte[] arrayOfByte1 = paramCHAR.shareBytes(); arrayOfByte = characterSet.convert(paramCHAR.getCharacterSet(), arrayOfByte1, 0, arrayOfByte1.length); } else { arrayOfByte = paramCHAR.getBytes(); }  this.parameterDatum[this.currentRank][i] = arrayOfByte; this.currentRowCharLens[i] = (arrayOfByte.length + 1 >> 1) + 1; }  if (this.sqlKind.isPlsqlOrCall()) if (this.currentRowCharLens[i] < this.minVcsBindSize) this.currentRowCharLens[i] = this.minVcsBindSize;   this.currentRowByteLens[i] = 0; } public void setDATE(int paramInt, DATE paramDATE) throws SQLException { synchronized (this.connection) { setDATEInternal(paramInt, paramDATE); }  } void setDATEInternal(int paramInt, DATE paramDATE) throws SQLException { int i = paramInt - 1; if (i < 0 || paramInt > this.numberOfBindPositions) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3); sQLException.fillInStackTrace(); throw sQLException; }  if (paramDATE == null) { this.currentRowBinders[i] = this.theDateNullBinder; } else { this.currentRowBinders[i] = this.theOracleDateBinder; if (this.parameterDatum == null) this.parameterDatum = new byte[this.numberOfBindRowsAllocated][this.numberOfBindPositions][];  this.parameterDatum[this.currentRank][i] = paramDATE.getBytes(); }  this.currentRowByteLens[i] = (this.currentRowBinders[i]).bytelen; this.currentRowCharLens[i] = 0; } public void setNUMBER(int paramInt, NUMBER paramNUMBER) throws SQLException { synchronized (this.connection) { setNUMBERInternal(paramInt, paramNUMBER); }  } void setNUMBERInternal(int paramInt, NUMBER paramNUMBER) throws SQLException { int i = paramInt - 1; if (i < 0 || paramInt > this.numberOfBindPositions) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3); sQLException.fillInStackTrace(); throw sQLException; }  if (paramNUMBER == null) { this.currentRowBinders[i] = this.theVarnumNullBinder; } else { this.currentRowBinders[i] = this.theOracleNumberBinder; if (this.parameterDatum == null) this.parameterDatum = new byte[this.numberOfBindRowsAllocated][this.numberOfBindPositions][];  this.parameterDatum[this.currentRank][i] = paramNUMBER.getBytes(); }  this.currentRowByteLens[i] = (this.currentRowBinders[i]).bytelen; this.currentRowCharLens[i] = 0; } public void setBLOB(int paramInt, BLOB paramBLOB) throws SQLException { synchronized (this.connection) { setBLOBInternal(paramInt, paramBLOB); }  } void setBLOBInternal(int paramInt, BLOB paramBLOB) throws SQLException { int i = paramInt - 1; if (i < 0 || paramInt > this.numberOfBindPositions) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3); sQLException.fillInStackTrace(); throw sQLException; }  if (paramBLOB == null) { this.currentRowBinders[i] = this.theBlobNullBinder; } else { this.currentRowBinders[i] = this.theBlobBinder; if (this.parameterDatum == null) this.parameterDatum = new byte[this.numberOfBindRowsAllocated][this.numberOfBindPositions][];  this.parameterDatum[this.currentRank][i] = paramBLOB.getBytes(); }  this.currentRowByteLens[i] = (this.currentRowBinders[i]).bytelen; this.currentRowCharLens[i] = 0; } public void setBlob(int paramInt, Blob paramBlob) throws SQLException { synchronized (this.connection) { setBLOBInternal(paramInt, (BLOB)paramBlob); }  } void setBlobInternal(int paramInt, Blob paramBlob) throws SQLException { setBLOBInternal(paramInt, (BLOB)paramBlob); } public void setCLOB(int paramInt, CLOB paramCLOB) throws SQLException { synchronized (this.connection) { setCLOBInternal(paramInt, paramCLOB); }  } void setCLOBInternal(int paramInt, CLOB paramCLOB) throws SQLException { int i = paramInt - 1; if (i < 0 || paramInt > this.numberOfBindPositions) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3); sQLException.fillInStackTrace(); throw sQLException; }  if (paramCLOB == null) { this.currentRowBinders[i] = this.theClobNullBinder; } else { this.currentRowBinders[i] = this.theClobBinder; if (this.parameterDatum == null) this.parameterDatum = new byte[this.numberOfBindRowsAllocated][this.numberOfBindPositions][];  this.parameterDatum[this.currentRank][i] = paramCLOB.getBytes(); }  this.currentRowByteLens[i] = (this.currentRowBinders[i]).bytelen; this.currentRowCharLens[i] = 0; } public void setClob(int paramInt, Clob paramClob) throws SQLException { synchronized (this.connection) { setCLOBInternal(paramInt, (CLOB)paramClob); }  } void setClobInternal(int paramInt, Clob paramClob) throws SQLException { setCLOBInternal(paramInt, (CLOB)paramClob); } public void setBFILE(int paramInt, BFILE paramBFILE) throws SQLException { synchronized (this.connection) { setBFILEInternal(paramInt, paramBFILE); }  } void setBFILEInternal(int paramInt, BFILE paramBFILE) throws SQLException { int i = paramInt - 1; if (i < 0 || paramInt > this.numberOfBindPositions) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3); sQLException.fillInStackTrace(); throw sQLException; }  if (paramBFILE == null) { this.currentRowBinders[i] = this.theBfileNullBinder; } else { this.currentRowBinders[i] = this.theBfileBinder; if (this.parameterDatum == null) this.parameterDatum = new byte[this.numberOfBindRowsAllocated][this.numberOfBindPositions][];  this.parameterDatum[this.currentRank][i] = paramBFILE.getBytes(); }  this.currentRowByteLens[i] = (this.currentRowBinders[i]).bytelen; this.currentRowCharLens[i] = 0; } public void setBfile(int paramInt, BFILE paramBFILE) throws SQLException { synchronized (this.connection) { setBFILEInternal(paramInt, paramBFILE); }  } void setBfileInternal(int paramInt, BFILE paramBFILE) throws SQLException { setBFILEInternal(paramInt, paramBFILE); } public void setBytes(int paramInt, byte[] paramArrayOfbyte) throws SQLException { setBytesInternal(paramInt, paramArrayOfbyte); } void setBytesInternal(int paramInt, byte[] paramArrayOfbyte) throws SQLException { int i = paramInt - 1; if (i < 0 || paramInt > this.numberOfBindPositions) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3); sQLException.fillInStackTrace(); throw sQLException; }  byte b = (paramArrayOfbyte != null) ? paramArrayOfbyte.length : 0; if (!b) { setNullInternal(paramInt, -2); } else if (this.sqlKind == OracleStatement.SqlKind.PLSQL_BLOCK) { if (b > this.maxRawBytesPlsql) { setBytesForBlobCritical(paramInt, paramArrayOfbyte); } else { basicBindBytes(paramInt, paramArrayOfbyte); }  } else if (this.sqlKind == OracleStatement.SqlKind.CALL_BLOCK) { if (b > this.maxRawBytesPlsql) { setBytesForBlobCritical(paramInt, paramArrayOfbyte); } else { basicBindBytes(paramInt, paramArrayOfbyte); }  } else if (b > this.maxRawBytesSql) { bindBytesAsStream(paramInt, paramArrayOfbyte); } else { basicBindBytes(paramInt, paramArrayOfbyte); }  } void bindBytesAsStream(int paramInt, byte[] paramArrayOfbyte) throws SQLException { int i = paramArrayOfbyte.length; byte[] arrayOfByte = new byte[i]; System.arraycopy(paramArrayOfbyte, 0, arrayOfByte, 0, i); set_execute_batch(1); basicBindBinaryStream(paramInt, new ByteArrayInputStream(arrayOfByte), i, true); } void basicBindBytes(int paramInt, byte[] paramArrayOfbyte) throws SQLException { synchronized (this.connection) { int i = paramInt - 1; Binder binder = this.sqlKind.isPlsqlOrCall() ? this.thePlsqlRawBinder : this.theRawBinder; this.currentRowBinders[i] = binder; if (this.parameterDatum == null) this.parameterDatum = new byte[this.numberOfBindRowsAllocated][this.numberOfBindPositions][];  this.parameterDatum[this.currentRank][i] = paramArrayOfbyte; this.currentRowByteLens[i] = paramArrayOfbyte.length; this.currentRowCharLens[i] = 0; }  } void basicBindBinaryStream(int paramInt1, InputStream paramInputStream, int paramInt2) throws SQLException { basicBindBinaryStream(paramInt1, paramInputStream, paramInt2, false); } void basicBindBinaryStream(int paramInt1, InputStream paramInputStream, int paramInt2, boolean paramBoolean) throws SQLException { synchronized (this.connection) { int i = paramInt1 - 1; if (paramBoolean) { this.currentRowBinders[i] = this.theLongRawStreamForBytesBinder; } else { this.currentRowBinders[i] = this.theLongRawStreamBinder; }  if (this.parameterStream == null) this.parameterStream = new InputStream[this.numberOfBindRowsAllocated][this.numberOfBindPositions];  this.parameterStream[this.currentRank][i] = paramBoolean ? this.connection.conversion.ConvertStreamInternal(paramInputStream, 6, paramInt2) : this.connection.conversion.ConvertStream(paramInputStream, 6, paramInt2); this.currentRowByteLens[i] = 0; this.currentRowCharLens[i] = 0; }  } public void setBytesForBlob(int paramInt, byte[] paramArrayOfbyte) throws SQLException { if (paramArrayOfbyte == null) { setNull(paramInt, -2); return; }  int i = paramArrayOfbyte.length; if (i == 0) { setNull(paramInt, -2); return; }  if (this.sqlKind.isPlsqlOrCall()) { if (i <= this.maxRawBytesPlsql) { setBytes(paramInt, paramArrayOfbyte); } else { setBytesForBlobCritical(paramInt, paramArrayOfbyte); }  } else if (i <= this.maxRawBytesSql) { setBytes(paramInt, paramArrayOfbyte); } else { setBytesForBlobCritical(paramInt, paramArrayOfbyte); }  } void setBytesForBlobCritical(int paramInt, byte[] paramArrayOfbyte) throws SQLException { BLOB bLOB = BLOB.createTemporary((Connection)this.connection, true, 10); bLOB.putBytes(1L, paramArrayOfbyte); addToTempLobsToFree(bLOB); this.lastBoundBlobs[paramInt - 1] = bLOB; setBLOBInternal(paramInt, bLOB); } void setBinaryStreamContentsForBlobCritical(int paramInt, InputStream paramInputStream, long paramLong, boolean paramBoolean) throws SQLException { synchronized (this.connection) { try { if ((paramInputStream = isInputStreamEmpty(paramInputStream)) == null) { if (paramBoolean) throw new IOException(paramLong + " byte of BLOB data cannot be read");  setBLOBInternal(paramInt, (BLOB)null); return; }  } catch (IOException iOException) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException); sQLException.fillInStackTrace(); throw sQLException; }  BLOB bLOB = BLOB.createTemporary((Connection)this.connection, true, 10); OracleBlobOutputStream oracleBlobOutputStream = (OracleBlobOutputStream)bLOB.setBinaryStream(1L); int i = bLOB.getBufferSize(); byte[] arrayOfByte = new byte[i]; long l = 0L; int j = 0; l = paramBoolean ? paramLong : Long.MAX_VALUE; try { while (l > 0L) { if (l >= i) { j = paramInputStream.read(arrayOfByte); } else { j = paramInputStream.read(arrayOfByte, 0, (int)l); }  if (j == -1) { if (paramBoolean) throw new IOException(l + " byte of BLOB data cannot be read");  break; }  oracleBlobOutputStream.write(arrayOfByte, 0, j); l -= j; }  oracleBlobOutputStream.flush(); } catch (IOException iOException) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException); sQLException.fillInStackTrace(); throw sQLException; }  addToTempLobsToFree(bLOB); this.lastBoundBlobs[paramInt - 1] = bLOB; setBLOBInternal(paramInt, bLOB); }  } public void setBytesForBlobAtName(String paramString, byte[] paramArrayOfbyte) throws SQLException { if (paramString == null) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68); sQLException.fillInStackTrace(); throw sQLException; }  String str = paramString.intern(); String[] arrayOfString = this.sqlObject.getParameterList(); boolean bool = false; int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length); for (byte b = 0; b < i; b++) { if (arrayOfString[b] == str) { setBytesForBlob(b + 1, paramArrayOfbyte); bool = true; }  }  if (!bool) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString); sQLException.fillInStackTrace(); throw sQLException; }  } public void setInternalBytes(int paramInt1, byte[] paramArrayOfbyte, int paramInt2) throws SQLException { synchronized (this.connection) { setInternalBytesInternal(paramInt1, paramArrayOfbyte, paramInt2); }  } void setInternalBytesInternal(int paramInt1, byte[] paramArrayOfbyte, int paramInt2) throws SQLException { SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException(); sQLException.fillInStackTrace(); throw sQLException; } public void setDate(int paramInt, Date paramDate) throws SQLException { synchronized (this.connection) { setDATEInternal(paramInt, (paramDate == null) ? null : new DATE(paramDate, getDefaultCalendar())); }  } void setDateInternal(int paramInt, Date paramDate) throws SQLException { setDATEInternal(paramInt, (paramDate == null) ? null : new DATE(paramDate, getDefaultCalendar())); } public void setTime(int paramInt, Time paramTime) throws SQLException { synchronized (this.connection) { setTimeInternal(paramInt, paramTime); }  } void setTimeInternal(int paramInt, Time paramTime) throws SQLException { int i = paramInt - 1; if (i < 0 || paramInt > this.numberOfBindPositions) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3); sQLException.fillInStackTrace(); throw sQLException; }  if (paramTime == null) { this.currentRowBinders[i] = this.theDateNullBinder; } else { this.currentRowBinders[i] = this.theTimeBinder; if (this.parameterTime == null) this.parameterTime = new Time[this.numberOfBindRowsAllocated][this.numberOfBindPositions];  this.parameterTime[this.currentRank][i] = paramTime; }  this.currentRowByteLens[i] = (this.currentRowBinders[i]).bytelen; this.currentRowCharLens[i] = 0; } public void setTimestamp(int paramInt, Timestamp paramTimestamp) throws SQLException { synchronized (this.connection) { setTimestampInternal(paramInt, paramTimestamp); }  } void setTimestampInternal(int paramInt, Timestamp paramTimestamp) throws SQLException { int i = paramInt - 1; if (i < 0 || paramInt > this.numberOfBindPositions) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3); sQLException.fillInStackTrace(); throw sQLException; }  if (paramTimestamp == null) { this.currentRowBinders[i] = this.theTimestampNullBinder; } else { this.currentRowBinders[i] = this.theTimestampBinder; if (this.parameterTimestamp == null) this.parameterTimestamp = new Timestamp[this.numberOfBindRowsAllocated][this.numberOfBindPositions];  this.parameterTimestamp[this.currentRank][i] = paramTimestamp; }  this.currentRowByteLens[i] = (this.currentRowBinders[i]).bytelen; this.currentRowCharLens[i] = 0; } public void setINTERVALYM(int paramInt, INTERVALYM paramINTERVALYM) throws SQLException { synchronized (this.connection) { setINTERVALYMInternal(paramInt, paramINTERVALYM); }  } void setINTERVALYMInternal(int paramInt, INTERVALYM paramINTERVALYM) throws SQLException { int i = paramInt - 1; if (i < 0 || paramInt > this.numberOfBindPositions) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3); sQLException.fillInStackTrace(); throw sQLException; }  if (paramINTERVALYM == null) { this.currentRowBinders[i] = this.theIntervalYMNullBinder; } else { this.currentRowBinders[i] = this.theIntervalYMBinder; if (this.parameterDatum == null) this.parameterDatum = new byte[this.numberOfBindRowsAllocated][this.numberOfBindPositions][];  this.parameterDatum[this.currentRank][i] = paramINTERVALYM.getBytes(); }  this.currentRowByteLens[i] = (this.currentRowBinders[i]).bytelen; this.currentRowCharLens[i] = 0; } public void setINTERVALDS(int paramInt, INTERVALDS paramINTERVALDS) throws SQLException { synchronized (this.connection) { setINTERVALDSInternal(paramInt, paramINTERVALDS); }  } void setINTERVALDSInternal(int paramInt, INTERVALDS paramINTERVALDS) throws SQLException { int i = paramInt - 1; if (i < 0 || paramInt > this.numberOfBindPositions) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3); sQLException.fillInStackTrace(); throw sQLException; }  if (paramINTERVALDS == null) { this.currentRowBinders[i] = this.theIntervalDSNullBinder; } else { this.currentRowBinders[i] = this.theIntervalDSBinder; if (this.parameterDatum == null) this.parameterDatum = new byte[this.numberOfBindRowsAllocated][this.numberOfBindPositions][];  this.parameterDatum[this.currentRank][i] = paramINTERVALDS.getBytes(); }  this.currentRowByteLens[i] = (this.currentRowBinders[i]).bytelen; this.currentRowCharLens[i] = 0; } public void setTIMESTAMP(int paramInt, TIMESTAMP paramTIMESTAMP) throws SQLException { synchronized (this.connection) { setTIMESTAMPInternal(paramInt, paramTIMESTAMP); }  } void setTIMESTAMPInternal(int paramInt, TIMESTAMP paramTIMESTAMP) throws SQLException { int i = paramInt - 1; if (i < 0 || paramInt > this.numberOfBindPositions) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3); sQLException.fillInStackTrace(); throw sQLException; }  if (paramTIMESTAMP == null) { this.currentRowBinders[i] = this.theTimestampNullBinder; } else { this.currentRowBinders[i] = this.theOracleTimestampBinder; if (this.parameterDatum == null) this.parameterDatum = new byte[this.numberOfBindRowsAllocated][this.numberOfBindPositions][];  this.parameterDatum[this.currentRank][i] = paramTIMESTAMP.getBytes(); }  this.currentRowByteLens[i] = (this.currentRowBinders[i]).bytelen; this.currentRowCharLens[i] = 0; } public void setTIMESTAMPTZ(int paramInt, TIMESTAMPTZ paramTIMESTAMPTZ) throws SQLException { synchronized (this.connection) { setTIMESTAMPTZInternal(paramInt, paramTIMESTAMPTZ); }  } void setTIMESTAMPTZInternal(int paramInt, TIMESTAMPTZ paramTIMESTAMPTZ) throws SQLException { int i = paramInt - 1; if (i < 0 || paramInt > this.numberOfBindPositions) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3); sQLException.fillInStackTrace(); throw sQLException; }  if (paramTIMESTAMPTZ == null) { this.currentRowBinders[i] = this.theTSTZNullBinder; } else { this.currentRowBinders[i] = this.theTSTZBinder; if (this.parameterDatum == null) this.parameterDatum = new byte[this.numberOfBindRowsAllocated][this.numberOfBindPositions][];  this.parameterDatum[this.currentRank][i] = paramTIMESTAMPTZ.getBytes(); }  this.currentRowByteLens[i] = (this.currentRowBinders[i]).bytelen; this.currentRowCharLens[i] = 0; }
/*       */   public void setTIMESTAMPLTZ(int paramInt, TIMESTAMPLTZ paramTIMESTAMPLTZ) throws SQLException { synchronized (this.connection) { setTIMESTAMPLTZInternal(paramInt, paramTIMESTAMPLTZ); }  }
/*       */   void setTIMESTAMPLTZInternal(int paramInt, TIMESTAMPLTZ paramTIMESTAMPLTZ) throws SQLException { if (this.connection.getSessionTimeZone() == null) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 105); sQLException.fillInStackTrace(); throw sQLException; }  int i = paramInt - 1; if (i < 0 || paramInt > this.numberOfBindPositions) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3); sQLException.fillInStackTrace(); throw sQLException; }  if (paramTIMESTAMPLTZ == null) { this.currentRowBinders[i] = this.theTSLTZNullBinder; } else { this.currentRowBinders[i] = this.theTSLTZBinder; if (this.parameterDatum == null) this.parameterDatum = new byte[this.numberOfBindRowsAllocated][this.numberOfBindPositions][];  this.parameterDatum[this.currentRank][i] = paramTIMESTAMPLTZ.getBytes(); }  this.currentRowByteLens[i] = (this.currentRowBinders[i]).bytelen; this.currentRowCharLens[i] = 0; }
/*       */   private Reader isReaderEmpty(Reader paramReader) throws IOException { if (!paramReader.markSupported()) paramReader = new BufferedReader(paramReader, 4096);  paramReader.mark(10); if (paramReader.read() == -1) return null;  paramReader.reset(); return paramReader; }
/*       */   private InputStream isInputStreamEmpty(InputStream paramInputStream) throws IOException { if (!paramInputStream.markSupported()) paramInputStream = new BufferedInputStream(paramInputStream, 4096);  paramInputStream.mark(10); if (paramInputStream.read() == -1) return null;  paramInputStream.reset(); return paramInputStream; }
/*       */   public void setAsciiStream(int paramInt1, InputStream paramInputStream, int paramInt2) throws SQLException { synchronized (this.connection) { setAsciiStreamInternal(paramInt1, paramInputStream, paramInt2); }  }
/*       */   void setAsciiStreamInternal(int paramInt1, InputStream paramInputStream, int paramInt2) throws SQLException { setAsciiStreamInternal(paramInt1, paramInputStream, paramInt2, true); }
/* 10716 */   boolean isOracleBatchStyle() { return (this.m_batchStyle == 1); } void setAsciiStreamInternal(int paramInt, InputStream paramInputStream, long paramLong, boolean paramBoolean) throws SQLException { int i = paramInt - 1; if (i < 0 || paramInt > this.numberOfBindPositions) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3); sQLException.fillInStackTrace(); throw sQLException; }  set_execute_batch(1); checkUserStreamForDuplicates(paramInputStream, i); if (paramInputStream == null) { basicBindNullString(paramInt); } else { if (this.userRsetType != DEFAULT_RESULT_SET_TYPE && (paramLong > this.maxVcsCharsSql || !paramBoolean)) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 169); sQLException.fillInStackTrace(); throw sQLException; }  if (!paramBoolean) { setAsciiStreamContentsForClobCritical(paramInt, paramInputStream, paramLong, paramBoolean); } else if (this.currentRowFormOfUse[i] == 1) { if (this.sqlKind.isPlsqlOrCall()) { if (paramLong <= this.maxVcsCharsPlsql) { setAsciiStreamContentsForStringInternal(paramInt, paramInputStream, (int)paramLong); } else { setAsciiStreamContentsForClobCritical(paramInt, paramInputStream, paramLong, paramBoolean); }  } else if (paramLong <= this.maxVcsCharsSql) { setAsciiStreamContentsForStringInternal(paramInt, paramInputStream, (int)paramLong); } else if (paramLong > 2147483647L) { setAsciiStreamContentsForClobCritical(paramInt, paramInputStream, paramLong, paramBoolean); } else { basicBindAsciiStream(paramInt, paramInputStream, (int)paramLong); }  } else if (this.sqlKind.isPlsqlOrCall()) { if (paramLong <= this.maxVcsNCharsPlsql) { setAsciiStreamContentsForStringInternal(paramInt, paramInputStream, (int)paramLong); } else { setAsciiStreamContentsForClobCritical(paramInt, paramInputStream, paramLong, paramBoolean); }  } else if (paramLong <= this.maxVcsNCharsSql) { setAsciiStreamContentsForStringInternal(paramInt, paramInputStream, (int)paramLong); } else { setAsciiStreamContentsForClobCritical(paramInt, paramInputStream, paramLong, paramBoolean); }  }  } void basicBindAsciiStream(int paramInt1, InputStream paramInputStream, int paramInt2) throws SQLException { synchronized (this.connection) { if (this.userRsetType != DEFAULT_RESULT_SET_TYPE) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 169); sQLException.fillInStackTrace(); throw sQLException; }  int i = paramInt1 - 1; this.currentRowBinders[i] = this.theLongStreamBinder; if (this.parameterStream == null) this.parameterStream = new InputStream[this.numberOfBindRowsAllocated][this.numberOfBindPositions];  this.parameterStream[this.currentRank][i] = this.connection.conversion.ConvertStream(paramInputStream, 5, paramInt2); this.currentRowByteLens[i] = (this.currentRowBinders[i]).bytelen; this.currentRowCharLens[i] = 0; }  } void setAsciiStreamContentsForStringInternal(int paramInt1, InputStream paramInputStream, int paramInt2) throws SQLException { byte[] arrayOfByte = new byte[paramInt2]; int i = 0; int j = paramInt2; try { int k; while (j > 0 && (k = paramInputStream.read(arrayOfByte, i, j)) != -1) { i += k; j -= k; }  } catch (IOException iOException) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException); sQLException.fillInStackTrace(); throw sQLException; }  char[] arrayOfChar = new char[paramInt2]; DBConversion.asciiBytesToJavaChars(arrayOfByte, i, arrayOfChar); basicBindString(paramInt1, new String(arrayOfChar)); } public void setBinaryStream(int paramInt1, InputStream paramInputStream, int paramInt2) throws SQLException { setBinaryStreamInternal(paramInt1, paramInputStream, paramInt2); } void setBinaryStreamInternal(int paramInt1, InputStream paramInputStream, int paramInt2) throws SQLException { setBinaryStreamInternal(paramInt1, paramInputStream, paramInt2, true); } void checkUserStreamForDuplicates(Object paramObject, int paramInt) throws SQLException { if (paramObject == null) return;  if (this.userStream != null) { for (Object[] arrayOfObject : this.userStream) { for (Object object : arrayOfObject) { if (object == paramObject) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 270, Integer.valueOf(paramInt + 1)); sQLException.fillInStackTrace(); throw sQLException; }  }  }  } else { this.userStream = new Object[this.numberOfBindRowsAllocated][this.numberOfBindPositions]; }  this.userStream[this.currentRank][paramInt] = paramObject; } void setBinaryStreamInternal(int paramInt, InputStream paramInputStream, long paramLong, boolean paramBoolean) throws SQLException { synchronized (this.connection) { int i = paramInt - 1; if (i < 0 || paramInt > this.numberOfBindPositions) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3); sQLException.fillInStackTrace(); throw sQLException; }  set_execute_batch(1); checkUserStreamForDuplicates(paramInputStream, i); if (paramInputStream == null) { setRAWInternal(paramInt, (RAW)null); } else { if (this.userRsetType != DEFAULT_RESULT_SET_TYPE && (paramLong > this.maxRawBytesSql || !paramBoolean)) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 169); sQLException.fillInStackTrace(); throw sQLException; }  if (!paramBoolean) { setBinaryStreamContentsForBlobCritical(paramInt, paramInputStream, paramLong, paramBoolean); } else if (this.sqlKind.isPlsqlOrCall()) { if (paramLong > this.maxRawBytesPlsql) { setBinaryStreamContentsForBlobCritical(paramInt, paramInputStream, paramLong, paramBoolean); } else { setBinaryStreamContentsForByteArrayInternal(paramInt, paramInputStream, (int)paramLong); }  } else if (paramLong > 2147483647L) { setBinaryStreamContentsForBlobCritical(paramInt, paramInputStream, paramLong, paramBoolean); } else if (paramLong > this.maxRawBytesSql) { basicBindBinaryStream(paramInt, paramInputStream, (int)paramLong); } else { setBinaryStreamContentsForByteArrayInternal(paramInt, paramInputStream, (int)paramLong); }  }  }  } void setBinaryStreamContentsForByteArrayInternal(int paramInt1, InputStream paramInputStream, int paramInt2) throws SQLException { byte[] arrayOfByte = new byte[paramInt2]; int i = 0; int j = paramInt2; try { int k; while (j > 0 && (k = paramInputStream.read(arrayOfByte, i, j)) != -1) { i += k; j -= k; }  } catch (IOException iOException) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException); sQLException.fillInStackTrace(); throw sQLException; }  if (i != paramInt2) { byte[] arrayOfByte1 = new byte[i]; System.arraycopy(arrayOfByte, 0, arrayOfByte1, 0, i); arrayOfByte = arrayOfByte1; }  setBytesInternal(paramInt1, arrayOfByte); } public void setUnicodeStream(int paramInt1, InputStream paramInputStream, int paramInt2) throws SQLException { setUnicodeStreamInternal(paramInt1, paramInputStream, paramInt2); } void setUnicodeStreamInternal(int paramInt1, InputStream paramInputStream, int paramInt2) throws SQLException { synchronized (this.connection) { int i = paramInt1 - 1; if (i < 0 || paramInt1 > this.numberOfBindPositions) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3); sQLException.fillInStackTrace(); throw sQLException; }  set_execute_batch(1); checkUserStreamForDuplicates(paramInputStream, i); if (paramInputStream == null) { setStringInternal(paramInt1, (String)null); } else { if (this.userRsetType != DEFAULT_RESULT_SET_TYPE && paramInt2 > this.maxVcsCharsSql) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 169); sQLException.fillInStackTrace(); throw sQLException; }  if (this.sqlKind.isPlsqlOrCall() || paramInt2 <= this.maxVcsCharsSql) { byte[] arrayOfByte = new byte[paramInt2]; int j = 0; int k = paramInt2; try { int m; while (k > 0 && (m = paramInputStream.read(arrayOfByte, j, k)) != -1) { j += m; k -= m; }  } catch (IOException iOException) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException); sQLException.fillInStackTrace(); throw sQLException; }  char[] arrayOfChar = new char[j >> 1]; DBConversion.ucs2BytesToJavaChars(arrayOfByte, j, arrayOfChar); setStringInternal(paramInt1, new String(arrayOfChar)); } else { this.currentRowBinders[i] = this.theLongStreamBinder; if (this.parameterStream == null) this.parameterStream = new InputStream[this.numberOfBindRowsAllocated][this.numberOfBindPositions];  this.parameterStream[this.currentRank][i] = this.connection.conversion.ConvertStream(paramInputStream, 4, paramInt2); this.currentRowByteLens[i] = 0; this.currentRowCharLens[i] = 0; }  }  }  } public void setCustomDatum(int paramInt, CustomDatum paramCustomDatum) throws SQLException { synchronized (this.connection) { setObjectInternal(paramInt, this.connection.toDatum(paramCustomDatum)); }  } void setCustomDatumInternal(int paramInt, CustomDatum paramCustomDatum) throws SQLException { synchronized (this.connection) { Datum datum = this.connection.toDatum(paramCustomDatum); int i = sqlTypeForObject(datum); setObjectCritical(paramInt, datum, i, 0); }  } public void setORAData(int paramInt, ORAData paramORAData) throws SQLException { setORADataInternal(paramInt, paramORAData); } void setORADataInternal(int paramInt, ORAData paramORAData) throws SQLException { synchronized (this.connection) { Datum datum = paramORAData.toDatum((Connection)this.connection); int i = sqlTypeForObject(datum); setObjectCritical(paramInt, datum, i, 0); if (i == 2002 || i == 2008 || i == 2003) this.currentRowCharLens[paramInt - 1] = 0;  }  } void setOracleDataInternal(int paramInt, OracleData paramOracleData) throws SQLException { synchronized (this.connection) { Object object = paramOracleData.toJDBCObject((Connection)this.connection); if (object instanceof _Proxy_) { final _Proxy_ proxiedJDBCObject = (_Proxy_)object; object = AccessController.doPrivileged(new PrivilegedAction() { public Object run() { return ProxyFactory.extractDelegate(proxiedJDBCObject); } }
/*       */           ); }  int i = sqlTypeForObject(object); setObjectCritical(paramInt, object, i, 0); if (i == 2002 || i == 2008 || i == 2003) this.currentRowCharLens[paramInt - 1] = 0;  }  }
/*       */   public void setObject(int paramInt1, Object paramObject, int paramInt2, int paramInt3) throws SQLException { synchronized (this.connection) { setObjectInternal(paramInt1, paramObject, paramInt2, paramInt3); }  }
/*       */   void setObjectInternal(int paramInt1, Object paramObject, int paramInt2, int paramInt3) throws SQLException { if (paramObject == null && paramInt2 != 2002 && paramInt2 != 2008 && paramInt2 != 2003 && paramInt2 != 2007 && paramInt2 != 2006 && paramInt2 != 2009) { setNullInternal(paramInt1, paramInt2); } else if (paramInt2 == 2002 || paramInt2 == 2008 || paramInt2 == 2003 || paramInt2 == 2009) { setObjectCritical(paramInt1, paramObject, paramInt2, paramInt3); this.currentRowCharLens[paramInt1 - 1] = 0; } else { setObjectCritical(paramInt1, paramObject, paramInt2, paramInt3); }  }
/*       */   void setObjectCritical(int paramInt1, Object paramObject, int paramInt2, int paramInt3) throws SQLException { switch (paramInt2) { case -15: setFormOfUse(paramInt1, (short)2);case 1: if (paramObject instanceof CHAR) { setCHARInternal(paramInt1, (CHAR)paramObject); } else if (paramObject instanceof String) { setStringInternal(paramInt1, (String)paramObject); } else if (paramObject instanceof Boolean) { setStringInternal(paramInt1, "" + (((Boolean)paramObject).booleanValue() ? 1 : 0)); } else if (paramObject instanceof Integer) { setStringInternal(paramInt1, "" + ((Integer)paramObject).intValue()); } else if (paramObject instanceof Long) { setStringInternal(paramInt1, "" + ((Long)paramObject).longValue()); } else if (paramObject instanceof Float) { setStringInternal(paramInt1, "" + ((Float)paramObject).floatValue()); } else if (paramObject instanceof Double) { setStringInternal(paramInt1, "" + ((Double)paramObject).doubleValue()); } else if (paramObject instanceof BigDecimal) { setStringInternal(paramInt1, ((BigDecimal)paramObject).toString()); } else if (paramObject instanceof Date) { setStringInternal(paramInt1, "" + ((Date)paramObject).toString()); } else if (paramObject instanceof Time) { setStringInternal(paramInt1, "" + ((Time)paramObject).toString()); } else if (paramObject instanceof Timestamp) { setStringInternal(paramInt1, "" + ((Timestamp)paramObject).toString()); } else if (paramObject instanceof URL) { setStringInternal(paramInt1, "" + ((URL)paramObject).toString()); } else { SQLException sQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 132); sQLException1.fillInStackTrace(); throw sQLException1; }  return;case -9: setFormOfUse(paramInt1, (short)2);case 12: if (paramObject instanceof String) { setStringInternal(paramInt1, (String)paramObject); } else if (paramObject instanceof Boolean) { setStringInternal(paramInt1, "" + (((Boolean)paramObject).booleanValue() ? 1 : 0)); } else if (paramObject instanceof Integer) { setStringInternal(paramInt1, "" + ((Integer)paramObject).intValue()); } else if (paramObject instanceof Long) { setStringInternal(paramInt1, "" + ((Long)paramObject).longValue()); } else if (paramObject instanceof Float) { setStringInternal(paramInt1, "" + ((Float)paramObject).floatValue()); } else if (paramObject instanceof Double) { setStringInternal(paramInt1, "" + ((Double)paramObject).doubleValue()); } else if (paramObject instanceof BigDecimal) { setStringInternal(paramInt1, ((BigDecimal)paramObject).toString()); } else if (paramObject instanceof Date) { setStringInternal(paramInt1, "" + ((Date)paramObject).toString()); } else if (paramObject instanceof Time) { setStringInternal(paramInt1, "" + ((Time)paramObject).toString()); } else if (paramObject instanceof Timestamp) { setStringInternal(paramInt1, "" + ((Timestamp)paramObject).toString()); } else if (paramObject instanceof URL) { setStringInternal(paramInt1, "" + ((URL)paramObject).toString()); } else { SQLException sQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 132); sQLException1.fillInStackTrace(); throw sQLException1; }  return;case 999: setFixedCHARInternal(paramInt1, (String)paramObject); return;case -16: setFormOfUse(paramInt1, (short)2);case -1: if (paramObject instanceof String) { setStringInternal(paramInt1, (String)paramObject); } else if (paramObject instanceof Boolean) { setStringInternal(paramInt1, "" + (((Boolean)paramObject).booleanValue() ? 1 : 0)); } else if (paramObject instanceof Integer) { setStringInternal(paramInt1, "" + ((Integer)paramObject).intValue()); } else if (paramObject instanceof Long) { setStringInternal(paramInt1, "" + ((Long)paramObject).longValue()); } else if (paramObject instanceof Float) { setStringInternal(paramInt1, "" + ((Float)paramObject).floatValue()); } else if (paramObject instanceof Double) { setStringInternal(paramInt1, "" + ((Double)paramObject).doubleValue()); } else if (paramObject instanceof BigDecimal) { setStringInternal(paramInt1, ((BigDecimal)paramObject).toString()); } else if (paramObject instanceof Date) { setStringInternal(paramInt1, "" + ((Date)paramObject).toString()); } else if (paramObject instanceof Time) { setStringInternal(paramInt1, "" + ((Time)paramObject).toString()); } else if (paramObject instanceof Timestamp) { setStringInternal(paramInt1, "" + ((Timestamp)paramObject).toString()); } else if (paramObject instanceof URL) { setStringInternal(paramInt1, "" + ((URL)paramObject).toString()); } else { SQLException sQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 132); sQLException1.fillInStackTrace(); throw sQLException1; }  return;case 2: if (paramObject instanceof NUMBER) { setNUMBERInternal(paramInt1, (NUMBER)paramObject); } else if (paramObject instanceof Integer) { setIntInternal(paramInt1, ((Integer)paramObject).intValue()); } else if (paramObject instanceof Long) { setLongInternal(paramInt1, ((Long)paramObject).longValue()); } else if (paramObject instanceof Float) { setFloatInternal(paramInt1, ((Float)paramObject).floatValue()); } else if (paramObject instanceof Double) { setDoubleInternal(paramInt1, ((Double)paramObject).doubleValue()); } else if (paramObject instanceof BigDecimal) { setBigDecimalInternal(paramInt1, (BigDecimal)paramObject); } else if (paramObject instanceof BigInteger) { setBigDecimalInternal(paramInt1, new BigDecimal((BigInteger)paramObject)); } else if (paramObject instanceof String) { setNUMBERInternal(paramInt1, new NUMBER((String)paramObject, paramInt3)); } else if (paramObject instanceof Boolean) { setIntInternal(paramInt1, ((Boolean)paramObject).booleanValue() ? 1 : 0); } else if (paramObject instanceof Short) { setShortInternal(paramInt1, ((Short)paramObject).shortValue()); } else if (paramObject instanceof Byte) { setByteInternal(paramInt1, ((Byte)paramObject).byteValue()); } else { SQLException sQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 132); sQLException1.fillInStackTrace(); throw sQLException1; }  return;case 3: if (paramObject instanceof BigDecimal) { setBigDecimalInternal(paramInt1, (BigDecimal)paramObject); } else if (paramObject instanceof Number) { setBigDecimalInternal(paramInt1, new BigDecimal(((Number)paramObject).doubleValue())); } else if (paramObject instanceof NUMBER) { setBigDecimalInternal(paramInt1, ((NUMBER)paramObject).bigDecimalValue()); } else if (paramObject instanceof String) { setBigDecimalInternal(paramInt1, new BigDecimal((String)paramObject)); } else if (paramObject instanceof Boolean) { setBigDecimalInternal(paramInt1, new BigDecimal(((Boolean)paramObject).booleanValue() ? 1.0D : 0.0D)); } else { SQLException sQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 132); sQLException1.fillInStackTrace(); throw sQLException1; }  return;case -7: if (paramObject instanceof Boolean) { setByteInternal(paramInt1, (byte)(((Boolean)paramObject).booleanValue() ? 1 : 0)); } else if (paramObject instanceof String) { setByteInternal(paramInt1, (byte)(("true".equalsIgnoreCase((String)paramObject) || "1".equals(paramObject)) ? 1 : 0)); } else if (paramObject instanceof Number) { setIntInternal(paramInt1, (((Number)paramObject).byteValue() != 0) ? 1 : 0); } else { SQLException sQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 132); sQLException1.fillInStackTrace(); throw sQLException1; }  return;case -6: if (paramObject instanceof Number) { setByteInternal(paramInt1, ((Number)paramObject).byteValue()); } else if (paramObject instanceof String) { setByteInternal(paramInt1, Byte.parseByte((String)paramObject)); } else if (paramObject instanceof Boolean) { setByteInternal(paramInt1, (byte)(((Boolean)paramObject).booleanValue() ? 1 : 0)); } else { SQLException sQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 132); sQLException1.fillInStackTrace(); throw sQLException1; }  return;case 5: if (paramObject instanceof Number) { setShortInternal(paramInt1, ((Number)paramObject).shortValue()); } else if (paramObject instanceof String) { setShortInternal(paramInt1, Short.parseShort((String)paramObject)); } else if (paramObject instanceof Boolean) { setShortInternal(paramInt1, (short)(((Boolean)paramObject).booleanValue() ? 1 : 0)); } else { SQLException sQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 132); sQLException1.fillInStackTrace(); throw sQLException1; }  return;case 4: if (paramObject instanceof Number) { setIntInternal(paramInt1, ((Number)paramObject).intValue()); } else if (paramObject instanceof String) { setIntInternal(paramInt1, Integer.parseInt((String)paramObject)); } else if (paramObject instanceof Boolean) { setIntInternal(paramInt1, ((Boolean)paramObject).booleanValue() ? 1 : 0); } else { SQLException sQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 132); sQLException1.fillInStackTrace(); throw sQLException1; }  return;case -5: if (paramObject instanceof Number) { setLongInternal(paramInt1, ((Number)paramObject).longValue()); } else if (paramObject instanceof String) { setLongInternal(paramInt1, Long.parseLong((String)paramObject)); } else if (paramObject instanceof Boolean) { setLongInternal(paramInt1, ((Boolean)paramObject).booleanValue() ? 1L : 0L); } else { SQLException sQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 132); sQLException1.fillInStackTrace(); throw sQLException1; }  return;case 7: if (paramObject instanceof Number) { setFloatInternal(paramInt1, ((Number)paramObject).floatValue()); } else if (paramObject instanceof String) { setFloatInternal(paramInt1, Float.valueOf((String)paramObject).floatValue()); } else if (paramObject instanceof Boolean) { setFloatInternal(paramInt1, ((Boolean)paramObject).booleanValue() ? 1.0F : 0.0F); } else { SQLException sQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 132); sQLException1.fillInStackTrace(); throw sQLException1; }  return;case 6: case 8: if (paramObject instanceof Number) { setDoubleInternal(paramInt1, ((Number)paramObject).doubleValue()); } else if (paramObject instanceof String) { setDoubleInternal(paramInt1, Double.valueOf((String)paramObject).doubleValue()); } else if (paramObject instanceof Boolean) { setDoubleInternal(paramInt1, ((Boolean)paramObject).booleanValue() ? 1.0D : 0.0D); } else { SQLException sQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 132); sQLException1.fillInStackTrace(); throw sQLException1; }  return;case -2: if (paramObject instanceof RAW) { setRAWInternal(paramInt1, (RAW)paramObject); } else { setBytesInternal(paramInt1, (byte[])paramObject); }  return;case -3: setBytesInternal(paramInt1, (byte[])paramObject); return;case -4: setBytesInternal(paramInt1, (byte[])paramObject); return;case 91: if (paramObject instanceof DATE) { setDATEInternal(paramInt1, (DATE)paramObject); } else if (paramObject instanceof Date) { setDATEInternal(paramInt1, new DATE(paramObject, getDefaultCalendar())); } else if (paramObject instanceof Timestamp) { setDATEInternal(paramInt1, new DATE((Timestamp)paramObject)); } else if (paramObject instanceof String) { setDateInternal(paramInt1, Date.valueOf((String)paramObject)); } else { SQLException sQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 132); sQLException1.fillInStackTrace(); throw sQLException1; }  return;case 92: if (paramObject instanceof Time) { setTimeInternal(paramInt1, (Time)paramObject); } else if (paramObject instanceof Timestamp) { setTimeInternal(paramInt1, new Time(((Timestamp)paramObject).getTime())); } else if (paramObject instanceof Date) { setTimeInternal(paramInt1, new Time(((Date)paramObject).getTime())); } else if (paramObject instanceof String) { setTimeInternal(paramInt1, Time.valueOf((String)paramObject)); } else { SQLException sQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 132); sQLException1.fillInStackTrace(); throw sQLException1; }  return;case 93: if (paramObject instanceof TIMESTAMP) { setTIMESTAMPInternal(paramInt1, (TIMESTAMP)paramObject); } else if (paramObject instanceof Timestamp) { setTimestampInternal(paramInt1, (Timestamp)paramObject); } else if (paramObject instanceof Date) { setTIMESTAMPInternal(paramInt1, new TIMESTAMP((Date)paramObject)); } else if (paramObject instanceof DATE) { setTIMESTAMPInternal(paramInt1, new TIMESTAMP(((DATE)paramObject).timestampValue())); } else if (paramObject instanceof String) { setTimestampInternal(paramInt1, Timestamp.valueOf((String)paramObject)); } else { SQLException sQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 132); sQLException1.fillInStackTrace(); throw sQLException1; }  return;case -100: setTIMESTAMPInternal(paramInt1, (TIMESTAMP)paramObject); return;case -101: setTIMESTAMPTZInternal(paramInt1, (TIMESTAMPTZ)paramObject); return;case -102: setTIMESTAMPLTZInternal(paramInt1, (TIMESTAMPLTZ)paramObject); return;case -103: setINTERVALYMInternal(paramInt1, (INTERVALYM)paramObject); return;case -104: setINTERVALDSInternal(paramInt1, (INTERVALDS)paramObject); return;case -8: setROWIDInternal(paramInt1, (ROWID)paramObject); return;case 100: setBinaryFloatInternal(paramInt1, (BINARY_FLOAT)paramObject); return;case 101: setBinaryDoubleInternal(paramInt1, (BINARY_DOUBLE)paramObject); return;case 2004: setBLOBInternal(paramInt1, (BLOB)paramObject); return;case 2005: case 2011: setCLOBInternal(paramInt1, (CLOB)paramObject); if (((CLOB)paramObject).isNCLOB()) setFormOfUse(paramInt1, (short)2);  return;case -13: setBFILEInternal(paramInt1, (BFILE)paramObject); return;case 2002: case 2008: setSTRUCTInternal(paramInt1, STRUCT.toSTRUCT(paramObject, (OracleConnection)this.connection)); return;case 2003: setARRAYInternal(paramInt1, ARRAY.toARRAY(paramObject, (OracleConnection)this.connection)); return;case 2007: setOPAQUEInternal(paramInt1, (OPAQUE)paramObject); return;case 2006: setREFInternal(paramInt1, (REF)paramObject); return;case 2009: setSQLXMLInternal(paramInt1, (SQLXML)paramObject); return; }  SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4); sQLException.fillInStackTrace(); throw sQLException; }
/*       */   public void setObjectAtName(String paramString, Object paramObject, int paramInt1, int paramInt2) throws SQLException { if (paramString == null) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68); sQLException.fillInStackTrace(); throw sQLException; }  String str = paramString.intern(); String[] arrayOfString = this.sqlObject.getParameterList(); boolean bool = false; int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length); for (byte b = 0; b < i; b++) { if (arrayOfString[b] == str) { setObjectInternal(b + 1, paramObject); bool = true; }  }  if (!bool) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString); sQLException.fillInStackTrace(); throw sQLException; }  }
/*       */   public void setObject(int paramInt1, Object paramObject, int paramInt2) throws SQLException { setObjectInternal(paramInt1, paramObject, paramInt2, 0); }
/*       */   void setObjectInternal(int paramInt1, Object paramObject, int paramInt2) throws SQLException { setObjectInternal(paramInt1, paramObject, paramInt2, 0); }
/*       */   public void setRefType(int paramInt, REF paramREF) throws SQLException { setREFInternal(paramInt, paramREF); }
/*       */   void setRefTypeInternal(int paramInt, REF paramREF) throws SQLException { setREFInternal(paramInt, paramREF); }
/*       */   public void setRef(int paramInt, Ref paramRef) throws SQLException { setREFInternal(paramInt, (REF)paramRef); }
/*       */   void setRefInternal(int paramInt, Ref paramRef) throws SQLException { setREFInternal(paramInt, (REF)paramRef); }
/*       */   public void setREF(int paramInt, REF paramREF) throws SQLException { setREFInternal(paramInt, paramREF); }
/* 10729 */   final void setJdbcBatchStyle() throws SQLException { if (this.m_batchStyle == 1) {
/*       */ 
/*       */       
/* 10732 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "operation cannot be mixed with Oracle-style batching");
/* 10733 */       sQLException.fillInStackTrace();
/* 10734 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */     
/* 10738 */     this.m_batchStyle = 2; } void setREFInternal(int paramInt, REF paramREF) throws SQLException { int i = paramInt - 1; if (i < 0 || paramInt > this.numberOfBindPositions) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3); sQLException.fillInStackTrace(); throw sQLException; }  if (paramREF == null) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68); sQLException.fillInStackTrace(); throw sQLException; }  setREFCritical(i, paramREF); this.currentRowCharLens[i] = 0; } void setREFCritical(int paramInt, REF paramREF) throws SQLException { StructDescriptor structDescriptor = paramREF.getDescriptor(); if (structDescriptor == null) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 52); sQLException.fillInStackTrace(); throw sQLException; }  this.currentRowBinders[paramInt] = this.theRefTypeBinder; if (this.parameterDatum == null) this.parameterDatum = new byte[this.numberOfBindRowsAllocated][this.numberOfBindPositions][];  this.parameterDatum[this.currentRank][paramInt] = paramREF.getBytes(); OracleTypeADT oracleTypeADT = structDescriptor.getOracleTypeADT(); oracleTypeADT.getTOID(); if (this.parameterOtype == null) this.parameterOtype = new OracleTypeADT[this.numberOfBindRowsAllocated][this.numberOfBindPositions];  this.parameterOtype[this.currentRank][paramInt] = oracleTypeADT; this.currentRowByteLens[paramInt] = (this.currentRowBinders[paramInt]).bytelen; this.currentRowCharLens[paramInt] = 0; } public void setObject(int paramInt, Object paramObject) throws SQLException { setObjectInternal(paramInt, paramObject); } void setObjectInternal(int paramInt, Object paramObject) throws SQLException { if (paramObject instanceof ORAData) { setORADataInternal(paramInt, (ORAData)paramObject); } else if (paramObject instanceof CustomDatum) { setCustomDatumInternal(paramInt, (CustomDatum)paramObject); } else if (paramObject instanceof OracleData) { setOracleDataInternal(paramInt, (OracleData)paramObject); } else { int i = sqlTypeForObject(paramObject); setObjectInternal(paramInt, paramObject, i, 0); }  } public void setOracleObject(int paramInt, Datum paramDatum) throws SQLException { setObjectInternal(paramInt, paramDatum); } void setOracleObjectInternal(int paramInt, Datum paramDatum) throws SQLException { setObjectInternal(paramInt, paramDatum); } public void setPlsqlIndexTable(int paramInt1, Object paramObject, int paramInt2, int paramInt3, int paramInt4, int paramInt5) throws SQLException { synchronized (this.connection) { setPlsqlIndexTableInternal(paramInt1, paramObject, paramInt2, paramInt3, paramInt4, paramInt5); }  } void setPlsqlIndexTableInternal(int paramInt1, Object paramObject, int paramInt2, int paramInt3, int paramInt4, int paramInt5) throws SQLException { Datum[] arrayOfDatum; String[] arrayOfString2; SQLException sQLException; int k, i = paramInt1 - 1; if (i < 0 || paramInt1 > this.numberOfBindPositions) { SQLException sQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3); sQLException1.fillInStackTrace(); throw sQLException1; }  if (paramObject == null) { SQLException sQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 271); sQLException1.fillInStackTrace(); throw sQLException1; }  int j = getInternalType(paramInt4); String[] arrayOfString1 = null; switch (j) { case 1: case 96: arrayOfString2 = null; k = 0; if (paramObject instanceof CHAR[]) { CHAR[] arrayOfCHAR = (CHAR[])paramObject; k = arrayOfCHAR.length; arrayOfString2 = new String[k]; for (byte b = 0; b < k; b++) { CHAR cHAR = arrayOfCHAR[b]; if (cHAR != null) arrayOfString2[b] = cHAR.getString();  }  } else if (paramObject instanceof String[]) { arrayOfString2 = (String[])paramObject; k = arrayOfString2.length; } else { SQLException sQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 97); sQLException1.fillInStackTrace(); throw sQLException1; }  if (paramInt5 == 0 && arrayOfString2 != null) for (byte b = 0; b < k; b++) { String str = arrayOfString2[b]; if (str != null && paramInt5 < str.length()) paramInt5 = str.length();  }   arrayOfString1 = arrayOfString2; break;case 2: case 6: arrayOfDatum = OracleTypeNUMBER.toNUMBERArray(paramObject, this.connection, 1L, paramInt3); if (paramInt5 == 0 && arrayOfDatum != null) paramInt5 = 22;  this.currentRowCharLens[i] = 0; break;default: sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 97); sQLException.fillInStackTrace(); throw sQLException; }  if (arrayOfDatum.length == 0 && paramInt2 == 0) { sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 272); sQLException.fillInStackTrace(); throw sQLException; }  this.currentRowBinders[i] = this.thePlsqlIbtBinder; this.currentRowByteLens[i] = (this.currentRowBinders[i]).bytelen; this.currentRowCharLens[i] = 0; if (this.parameterPlsqlIbt == null) this.parameterPlsqlIbt = new PlsqlIbtBindInfo[this.numberOfBindRowsAllocated][this.numberOfBindPositions];  this.parameterPlsqlIbt[this.currentRank][i] = new PlsqlIbtBindInfo(this, (Object[])arrayOfDatum, paramInt2, paramInt3, j, paramInt5); this.hasIbtBind = true; } public void setPlsqlIndexTableAtName(String paramString, Object paramObject, int paramInt1, int paramInt2, int paramInt3, int paramInt4) throws SQLException { synchronized (this.connection) { if (paramString == null) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68); sQLException.fillInStackTrace(); throw sQLException; }  String str = paramString.intern(); String[] arrayOfString = this.sqlObject.getParameterList(); boolean bool = false; int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length); for (byte b = 0; b < i; b++) { if (arrayOfString[b] == str) { setPlsqlIndexTableInternal(b + 1, paramObject, paramInt1, paramInt2, paramInt3, paramInt4); bool = true; }  }  if (!bool) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString); sQLException.fillInStackTrace(); throw sQLException; }  }  } void endOfResultSet(boolean paramBoolean) throws SQLException { if (!paramBoolean) prepareForNewResults(false, false, false);  this.rowPrefetchInLastFetch = -1; } int sqlTypeForObject(Object paramObject) { if (paramObject == null) return 0;  if (!(paramObject instanceof Datum)) { if (paramObject instanceof String) return this.fixedString ? 999 : 12;  if (paramObject instanceof BigDecimal) return 2;  if (paramObject instanceof BigInteger) return 2;  if (paramObject instanceof Boolean) return -7;  if (paramObject instanceof Integer) return 4;  if (paramObject instanceof Long) return -5;  if (paramObject instanceof Float) return 7;  if (paramObject instanceof Double) return 8;  if (paramObject instanceof byte[]) return -3;  if (paramObject instanceof Short) return 5;  if (paramObject instanceof Byte) return -6;  if (paramObject instanceof Date) return 91;  if (paramObject instanceof Time) return 92;  if (paramObject instanceof Timestamp) return 93;  if (paramObject instanceof java.sql.SQLData) return 2002;  if (paramObject instanceof oracle.jdbc.internal.ObjectData) return 2002;  if (paramObject instanceof URL) return this.fixedString ? 999 : 12;  } else { if (paramObject instanceof BINARY_FLOAT) return 100;  if (paramObject instanceof BINARY_DOUBLE) return 101;  if (paramObject instanceof BLOB) return 2004;  if (paramObject instanceof CLOB) return 2005;  if (paramObject instanceof BFILE) return -13;  if (paramObject instanceof ROWID) return -8;  if (paramObject instanceof NUMBER) return 2;  if (paramObject instanceof DATE) return 91;  if (paramObject instanceof TIMESTAMP) return 93;  if (paramObject instanceof TIMESTAMPTZ) return -101;  if (paramObject instanceof TIMESTAMPLTZ) return -102;  if (paramObject instanceof REF) return 2006;  if (paramObject instanceof CHAR) return 1;  if (paramObject instanceof RAW) return -2;  if (paramObject instanceof ARRAY) return 2003;  if (paramObject instanceof STRUCT) return 2002;  if (paramObject instanceof OPAQUE) return 2007;  if (paramObject instanceof INTERVALYM) return -103;  if (paramObject instanceof INTERVALDS) return -104;  if (paramObject instanceof SQLXML) return 2009;  }  return 1111; }
/*       */   public void clearParameters() throws SQLException { synchronized (this.connection) { this.clearParameters = true; for (byte b = 0; b < this.numberOfBindPositions; b++) this.currentRowBinders[b] = null;  }  }
/*       */   void printByteArray(byte[] paramArrayOfbyte) { if (paramArrayOfbyte != null) { int i = paramArrayOfbyte.length; for (byte b = 0; b < i; b++) { int j = paramArrayOfbyte[b] & 0xFF; if (j < 16); }  }  }
/*       */   public void setCharacterStream(int paramInt1, Reader paramReader, int paramInt2) throws SQLException { setCharacterStreamInternal(paramInt1, paramReader, paramInt2); }
/*       */   void setCharacterStreamInternal(int paramInt1, Reader paramReader, int paramInt2) throws SQLException { setCharacterStreamInternal(paramInt1, paramReader, paramInt2, true); }
/*       */   void setCharacterStreamInternal(int paramInt, Reader paramReader, long paramLong, boolean paramBoolean) throws SQLException { int i = paramInt - 1; if (i < 0 || paramInt > this.numberOfBindPositions) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3); sQLException.fillInStackTrace(); throw sQLException; }  set_execute_batch(1); checkUserStreamForDuplicates(paramReader, i); if (paramReader == null) { basicBindNullString(paramInt); } else { if (this.userRsetType != DEFAULT_RESULT_SET_TYPE && (paramLong > this.maxVcsCharsSql || !paramBoolean)) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 169); sQLException.fillInStackTrace(); throw sQLException; }  if (!paramBoolean) { setReaderContentsForClobCritical(paramInt, paramReader, paramLong, paramBoolean); } else if (this.currentRowFormOfUse[i] == 1) { if (this.sqlKind.isPlsqlOrCall()) { if (paramLong > this.maxVcsBytesPlsql || (paramLong > this.maxVcsCharsPlsql && this.isServerCharSetFixedWidth)) { setReaderContentsForClobCritical(paramInt, paramReader, paramLong, paramBoolean); } else if (paramLong <= this.maxVcsCharsPlsql) { setReaderContentsForStringInternal(paramInt, paramReader, (int)paramLong); } else { setReaderContentsForStringOrClobInVariableWidthCase(paramInt, paramReader, (int)paramLong, false); }  } else if (paramLong <= this.maxVcsCharsSql) { setReaderContentsForStringInternal(paramInt, paramReader, (int)paramLong); } else if (paramLong > 2147483647L) { setReaderContentsForClobCritical(paramInt, paramReader, paramLong, paramBoolean); } else { basicBindCharacterStream(paramInt, paramReader, (int)paramLong, false); }  } else if (this.sqlKind.isPlsqlOrCall()) { if (paramLong > this.maxVcsBytesPlsql || (paramLong > this.maxVcsNCharsPlsql && this.isServerCharSetFixedWidth)) { setReaderContentsForClobCritical(paramInt, paramReader, paramLong, paramBoolean); } else if (paramLong <= this.maxVcsNCharsPlsql) { setReaderContentsForStringInternal(paramInt, paramReader, (int)paramLong); } else { setReaderContentsForStringOrClobInVariableWidthCase(paramInt, paramReader, (int)paramLong, true); }  } else if (paramLong <= this.maxVcsNCharsSql) { setReaderContentsForStringInternal(paramInt, paramReader, (int)paramLong); } else { setReaderContentsForClobCritical(paramInt, paramReader, paramLong, paramBoolean); }  }  }
/*       */   void basicBindCharacterStream(int paramInt1, Reader paramReader, int paramInt2, boolean paramBoolean) throws SQLException { synchronized (this.connection) { int i = paramInt1 - 1; if (paramBoolean) { this.currentRowBinders[i] = this.theLongStreamForStringBinder; } else { this.currentRowBinders[i] = this.theLongStreamBinder; }  if (this.parameterStream == null) this.parameterStream = new InputStream[this.numberOfBindRowsAllocated][this.numberOfBindPositions];  this.parameterStream[this.currentRank][i] = paramBoolean ? this.connection.conversion.ConvertStreamInternal(paramReader, 7, paramInt2, this.currentRowFormOfUse[i]) : this.connection.conversion.ConvertStream(paramReader, 7, paramInt2, this.currentRowFormOfUse[i]); this.currentRowByteLens[i] = 0; this.currentRowCharLens[i] = 0; }  }
/*       */   void setReaderContentsForStringOrClobInVariableWidthCase(int paramInt1, Reader paramReader, int paramInt2, boolean paramBoolean) throws SQLException { char[] arrayOfChar = new char[paramInt2]; int i = 0; int j = paramInt2; try { int m; while (j > 0 && (m = paramReader.read(arrayOfChar, i, j)) != -1) { i += m; j -= m; }  } catch (IOException iOException) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException); sQLException.fillInStackTrace(); throw sQLException; }  if (i != paramInt2) { char[] arrayOfChar1 = new char[i]; System.arraycopy(arrayOfChar, 0, arrayOfChar1, 0, i); arrayOfChar = arrayOfChar1; }  int k = this.connection.conversion.encodedByteLength(arrayOfChar, paramBoolean); if (k < this.maxVcsBytesPlsql) { setStringInternal(paramInt1, new String(arrayOfChar)); } else { setStringForClobCritical(paramInt1, new String(arrayOfChar)); }  }
/*       */   void setReaderContentsForStringInternal(int paramInt1, Reader paramReader, int paramInt2) throws SQLException { char[] arrayOfChar = new char[paramInt2]; int i = 0; int j = paramInt2; try { int k; while (j > 0 && (k = paramReader.read(arrayOfChar, i, j)) != -1) { i += k; j -= k; }  } catch (IOException iOException) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException); sQLException.fillInStackTrace(); throw sQLException; }  if (i != paramInt2) { char[] arrayOfChar1 = new char[i]; System.arraycopy(arrayOfChar, 0, arrayOfChar1, 0, i); arrayOfChar = arrayOfChar1; }  setStringInternal(paramInt1, new String(arrayOfChar)); }
/*       */   public void setDate(int paramInt, Date paramDate, Calendar paramCalendar) throws SQLException { setDATEInternal(paramInt, (paramDate == null) ? null : new DATE(paramDate, paramCalendar)); }
/*       */   void setDateInternal(int paramInt, Date paramDate, Calendar paramCalendar) throws SQLException { setDATEInternal(paramInt, (paramDate == null) ? null : new DATE(paramDate, paramCalendar)); }
/*       */   public void setTime(int paramInt, Time paramTime, Calendar paramCalendar) throws SQLException { setDATEInternal(paramInt, (paramTime == null) ? null : new DATE(paramTime, paramCalendar)); }
/*       */   void setTimeInternal(int paramInt, Time paramTime, Calendar paramCalendar) throws SQLException { setDATEInternal(paramInt, (paramTime == null) ? null : new DATE(paramTime, paramCalendar)); }
/*       */   public void setTimestamp(int paramInt, Timestamp paramTimestamp, Calendar paramCalendar) throws SQLException { setTimestampInternal(paramInt, paramTimestamp, paramCalendar); }
/*       */   void setTimestampInternal(int paramInt, Timestamp paramTimestamp, Calendar paramCalendar) throws SQLException { setTIMESTAMPInternal(paramInt, (paramTimestamp == null) ? null : new TIMESTAMP(paramTimestamp, paramCalendar)); }
/*       */   public void setCheckBindTypes(boolean paramBoolean) { this.checkBindTypes = paramBoolean; }
/* 10754 */   final void checkIfJdbcBatchExists() throws SQLException { if (doesJdbcBatchExist()) {
/*       */ 
/*       */       
/* 10757 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 81, "batch must be either executed or cleared");
/* 10758 */       sQLException.fillInStackTrace();
/* 10759 */       throw sQLException;
/*       */     }  }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   boolean doesJdbcBatchExist() {
/* 10768 */     if (this.currentRank > 0 && this.m_batchStyle == 2) {
/* 10769 */       return true;
/*       */     }
/* 10771 */     return false;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   boolean isJdbcBatchStyle() {
/* 10778 */     return (this.m_batchStyle == 2);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   boolean isBatchStyleSet() {
/* 10785 */     return !(this.m_batchStyle == 0);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void addBatch() throws SQLException {
/* 10806 */     synchronized (this.connection) {
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/* 10826 */       setJdbcBatchStyle();
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/* 10836 */       processCompletedBindRow(this.currentRank + 2, (this.currentRank > 0 && this.sqlKind.isPlsqlOrCall()));
/*       */ 
/*       */ 
/*       */       
/* 10840 */       this.currentRank++;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void addBatch(String paramString) throws SQLException {
/* 10850 */     synchronized (this.connection) {
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/* 10858 */       SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException();
/* 10859 */       sQLException.fillInStackTrace();
/* 10860 */       throw sQLException;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void clearBatch() throws SQLException {
/* 10879 */     synchronized (this.connection) {
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/* 10886 */       for (int i = this.currentRank - 1; i >= 0; i--) {
/* 10887 */         for (byte b = 0; b < this.numberOfBindPositions; b++)
/* 10888 */           this.binders[i][b] = null; 
/*       */       } 
/* 10890 */       this.currentRank = 0;
/*       */       
/* 10892 */       this.pushedBatches = null;
/* 10893 */       this.pushedBatchesTail = null;
/* 10894 */       this.firstRowInBatch = 0;
/* 10895 */       this.currentBatchAccumulatedBindsSize = 0;
/*       */       
/* 10897 */       releaseBuffers();
/* 10898 */       if (this.binders != null) {
/* 10899 */         this.currentRowBinders = this.binders[0];
/*       */       }
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   void executeForRowsWithTimeout(boolean paramBoolean) throws SQLException {
/* 10913 */     if (this.queryTimeout > 0) {
/*       */ 
/*       */       
/*       */       try {
/* 10917 */         this.connection.getTimeout().setTimeout((this.queryTimeout * 1000), this);
/* 10918 */         this.cancelLock.enterExecuting();
/* 10919 */         executeForRows(paramBoolean);
/*       */       }
/*       */       finally {
/*       */         
/* 10923 */         this.connection.getTimeout().cancelTimeout();
/* 10924 */         this.cancelLock.exitExecuting();
/*       */       } 
/*       */     } else {
/*       */ 
/*       */       
/*       */       try {
/*       */         
/* 10931 */         this.cancelLock.enterExecuting();
/* 10932 */         executeForRows(paramBoolean);
/*       */       }
/*       */       finally {
/*       */         
/* 10936 */         this.cancelLock.exitExecuting();
/*       */       } 
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public int[] executeBatch() throws SQLException {
/* 10963 */     synchronized (this.connection) {
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/* 10971 */       int[] arrayOfInt = new int[this.currentRank];
/* 10972 */       this.checkSum = 0L;
/* 10973 */       this.checkSumComputationFailure = false;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/* 10979 */       byte b = 0;
/*       */       
/* 10981 */       cleanOldTempLobs();
/* 10982 */       setJdbcBatchStyle();
/*       */       
/* 10984 */       if (this.currentRank > 0) {
/*       */ 
/*       */ 
/*       */         
/* 10988 */         ensureOpen();
/*       */ 
/*       */         
/* 10991 */         prepareForNewResults(true, true, true);
/*       */         
/* 10993 */         if (this.sqlKind.isSELECT()) {
/*       */ 
/*       */           
/* 10996 */           BatchUpdateException batchUpdateException = DatabaseError.createBatchUpdateException(80, 0, (int[])null);
/* 10997 */           batchUpdateException.fillInStackTrace();
/* 10998 */           throw batchUpdateException;
/*       */         } 
/*       */ 
/*       */ 
/*       */         
/* 11003 */         this.noMoreUpdateCounts = false;
/*       */         
/* 11005 */         int i = 0;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         try {
/* 11017 */           this.connection.registerHeartbeat();
/*       */           
/* 11019 */           this.connection.needLine();
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */           
/* 11025 */           if (!this.isOpen) {
/*       */             
/* 11027 */             this.connection.open(this);
/*       */             
/* 11029 */             this.isOpen = true;
/*       */           } 
/*       */ 
/*       */ 
/*       */ 
/*       */           
/* 11035 */           int j = this.currentRank;
/*       */           
/* 11037 */           if (this.pushedBatches == null) {
/*       */ 
/*       */ 
/*       */ 
/*       */             
/* 11042 */             setupBindBuffers(0, this.currentRank);
/* 11043 */             executeForRowsWithTimeout(false);
/*       */             
/* 11045 */             i = this.validRows;
/*       */             
/* 11047 */             if (this.batchRowsUpdatedArray != null)
/*       */             {
/* 11049 */               assert arrayOfInt.length == this.batchRowsUpdatedArray.length;
/* 11050 */               arrayOfInt = this.batchRowsUpdatedArray;
/*       */             }
/*       */             else
/*       */             {
/* 11054 */               for (b = 0; b < arrayOfInt.length; b++)
/*       */               {
/* 11056 */                 arrayOfInt[b] = -2;
/*       */               
/*       */               }
/*       */             
/*       */             }
/*       */ 
/*       */           
/*       */           }
/*       */           else {
/*       */             
/* 11066 */             if (this.currentRank > this.firstRowInBatch)
/*       */             {
/*       */ 
/*       */               
/* 11070 */               pushBatch(true);
/*       */             }
/* 11072 */             boolean bool = this.needToParse;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */             
/*       */             do {
/* 11080 */               PushedBatch pushedBatch = this.pushedBatches;
/*       */               
/* 11082 */               this.currentBatchByteLens = pushedBatch.currentBatchByteLens;
/* 11083 */               this.lastBoundByteLens = pushedBatch.lastBoundByteLens;
/* 11084 */               this.currentBatchCharLens = pushedBatch.currentBatchCharLens;
/* 11085 */               this.lastBoundCharLens = pushedBatch.lastBoundCharLens;
/* 11086 */               this.lastBoundNeeded = pushedBatch.lastBoundNeeded;
/* 11087 */               this.currentBatchBindAccessors = pushedBatch.currentBatchBindAccessors;
/* 11088 */               this.needToParse = pushedBatch.need_to_parse;
/* 11089 */               this.currentBatchNeedToPrepareBinds = pushedBatch.current_batch_need_to_prepare_binds;
/*       */               
/* 11091 */               this.firstRowInBatch = pushedBatch.first_row_in_batch;
/*       */               
/* 11093 */               setupBindBuffers(pushedBatch.first_row_in_batch, pushedBatch.number_of_rows_to_be_bound);
/*       */ 
/*       */ 
/*       */ 
/*       */               
/* 11098 */               this.currentRank = pushedBatch.number_of_rows_to_be_bound;
/*       */               
/* 11100 */               executeForRowsWithTimeout(false);
/*       */               
/* 11102 */               i += this.validRows;
/*       */               
/* 11104 */               if (this.batchRowsUpdatedArray != null) {
/*       */                 
/* 11106 */                 assert this.batchRowsUpdatedArray.length == this.currentRank;
/* 11107 */                 System.arraycopy(this.batchRowsUpdatedArray, 0, arrayOfInt, this.firstRowInBatch, this.currentRank);
/*       */ 
/*       */               
/*       */               }
/* 11111 */               else if (this.sqlKind.isPlsqlOrCall()) {
/*       */                 
/* 11113 */                 arrayOfInt[b++] = this.validRows;
/*       */               }
/*       */               else {
/*       */                 
/* 11117 */                 for (byte b1 = 0; b1 < this.currentRank; b1++)
/*       */                 {
/* 11119 */                   arrayOfInt[this.firstRowInBatch + b1] = -2;
/*       */                 }
/*       */               } 
/*       */ 
/*       */               
/* 11124 */               this.pushedBatches = pushedBatch.next;
/*       */             
/*       */             }
/* 11127 */             while (this.pushedBatches != null);
/*       */ 
/*       */             
/* 11130 */             this.pushedBatchesTail = null;
/* 11131 */             this.firstRowInBatch = 0;
/*       */             
/* 11133 */             this.needToParse = bool;
/*       */           } 
/*       */ 
/*       */ 
/*       */           
/* 11138 */           slideDownCurrentRow(j);
/*       */ 
/*       */         
/*       */         }
/* 11142 */         catch (SQLException sQLException) {
/*       */ 
/*       */           
/* 11145 */           this.needToParse = true;
/*       */           
/* 11147 */           if (!this.sqlKind.isPlsqlOrCall())
/*       */           {
/*       */             
/* 11150 */             if (this.batchRowsUpdatedArray != null) {
/*       */               
/* 11152 */               if (this.firstRowInBatch == 0)
/*       */               {
/* 11154 */                 arrayOfInt = this.batchRowsUpdatedArray;
/*       */               }
/*       */               else
/*       */               {
/* 11158 */                 int[] arrayOfInt1 = new int[this.firstRowInBatch + this.batchRowsUpdatedArray.length];
/* 11159 */                 System.arraycopy(arrayOfInt, 0, arrayOfInt1, 0, this.firstRowInBatch);
/* 11160 */                 System.arraycopy(this.batchRowsUpdatedArray, 0, arrayOfInt1, this.firstRowInBatch, this.batchRowsUpdatedArray.length);
/* 11161 */                 arrayOfInt = arrayOfInt1;
/*       */ 
/*       */ 
/*       */               
/*       */               }
/*       */ 
/*       */ 
/*       */             
/*       */             }
/* 11170 */             else if (this.numberOfExecutedElementsInBatch != -1 && this.numberOfExecutedElementsInBatch != this.currentRank) {
/*       */ 
/*       */ 
/*       */ 
/*       */               
/* 11175 */               arrayOfInt = new int[this.numberOfExecutedElementsInBatch];
/* 11176 */               for (b = 0; b < this.numberOfExecutedElementsInBatch; b++) {
/* 11177 */                 arrayOfInt[b] = -2;
/*       */               }
/*       */             } else {
/* 11180 */               for (b = 0; b < arrayOfInt.length; b++) {
/* 11181 */                 arrayOfInt[b] = -3;
/*       */               }
/*       */             } 
/*       */           }
/* 11185 */           clearBatch();
/* 11186 */           resetCurrentRowBinders();
/*       */ 
/*       */           
/* 11189 */           BatchUpdateException batchUpdateException = DatabaseError.createBatchUpdateException(sQLException, this.sqlKind.isPlsqlOrCall() ? b : arrayOfInt.length, arrayOfInt);
/* 11190 */           batchUpdateException.fillInStackTrace();
/* 11191 */           throw batchUpdateException;
/*       */         
/*       */         }
/*       */         finally {
/*       */           
/* 11196 */           if (this.sqlKind.isPlsqlOrCall() || i > this.validRows) {
/* 11197 */             this.validRows = i;
/*       */           }
/* 11199 */           checkValidRowsStatus();
/* 11200 */           this.currentBatchAccumulatedBindsSize = 0;
/* 11201 */           this.currentRank = 0;
/*       */         } 
/*       */         
/* 11204 */         if (this.validRows < 0) {
/*       */           
/* 11206 */           for (b = 0; b < arrayOfInt.length; b++) {
/* 11207 */             arrayOfInt[b] = -3;
/*       */           }
/*       */           
/* 11210 */           BatchUpdateException batchUpdateException = DatabaseError.createBatchUpdateException(81, 0, arrayOfInt);
/* 11211 */           batchUpdateException.fillInStackTrace();
/* 11212 */           throw batchUpdateException;
/*       */         } 
/*       */       } 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/* 11221 */       this.connection.registerHeartbeat();
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/* 11227 */       return arrayOfInt;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   void pushBatch(boolean paramBoolean) {
/* 11237 */     PushedBatch pushedBatch = new PushedBatch();
/*       */     
/* 11239 */     pushedBatch.currentBatchByteLens = new int[this.numberOfBindPositions];
/*       */     
/* 11241 */     System.arraycopy(this.currentBatchByteLens, 0, pushedBatch.currentBatchByteLens, 0, this.numberOfBindPositions);
/*       */ 
/*       */     
/* 11244 */     pushedBatch.currentBatchCharLens = new int[this.numberOfBindPositions];
/*       */     
/* 11246 */     System.arraycopy(this.currentBatchCharLens, 0, pushedBatch.currentBatchCharLens, 0, this.numberOfBindPositions);
/*       */ 
/*       */     
/* 11249 */     pushedBatch.lastBoundByteLens = new int[this.numberOfBindPositions];
/*       */     
/* 11251 */     System.arraycopy(this.lastBoundByteLens, 0, pushedBatch.lastBoundByteLens, 0, this.numberOfBindPositions);
/*       */ 
/*       */     
/* 11254 */     pushedBatch.lastBoundCharLens = new int[this.numberOfBindPositions];
/*       */     
/* 11256 */     System.arraycopy(this.lastBoundCharLens, 0, pushedBatch.lastBoundCharLens, 0, this.numberOfBindPositions);
/*       */ 
/*       */     
/* 11259 */     if (this.currentBatchBindAccessors != null) {
/*       */       
/* 11261 */       pushedBatch.currentBatchBindAccessors = new Accessor[this.numberOfBindPositions];
/*       */       
/* 11263 */       System.arraycopy(this.currentBatchBindAccessors, 0, pushedBatch.currentBatchBindAccessors, 0, this.numberOfBindPositions);
/*       */     } 
/*       */ 
/*       */     
/* 11267 */     pushedBatch.lastBoundNeeded = this.lastBoundNeeded;
/* 11268 */     pushedBatch.need_to_parse = this.needToParse;
/* 11269 */     pushedBatch.current_batch_need_to_prepare_binds = this.currentBatchNeedToPrepareBinds;
/* 11270 */     pushedBatch.first_row_in_batch = this.firstRowInBatch;
/* 11271 */     pushedBatch.number_of_rows_to_be_bound = this.currentRank - this.firstRowInBatch;
/*       */     
/* 11273 */     if (this.pushedBatches == null) {
/* 11274 */       this.pushedBatches = pushedBatch;
/*       */     } else {
/* 11276 */       this.pushedBatchesTail.next = pushedBatch;
/*       */     } 
/* 11278 */     this.pushedBatchesTail = pushedBatch;
/*       */     
/* 11280 */     this.currentBatchAccumulatedBindsSize = 0;
/*       */     
/* 11282 */     if (!paramBoolean) {
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/* 11288 */       int[] arrayOfInt = this.currentBatchByteLens;
/*       */       
/* 11290 */       this.currentBatchByteLens = this.lastBoundByteLens;
/* 11291 */       this.lastBoundByteLens = arrayOfInt;
/*       */       byte b;
/* 11293 */       for (b = 0; b < this.numberOfBindPositions; b++) {
/* 11294 */         this.currentBatchByteLens[b] = 0;
/*       */       }
/* 11296 */       arrayOfInt = this.currentBatchCharLens;
/*       */       
/* 11298 */       this.currentBatchCharLens = this.lastBoundCharLens;
/* 11299 */       this.lastBoundCharLens = arrayOfInt;
/*       */       
/* 11301 */       for (b = 0; b < this.numberOfBindPositions; b++) {
/* 11302 */         this.currentBatchCharLens[b] = 0;
/*       */       }
/* 11304 */       this.lastBoundNeeded = false;
/*       */       
/* 11306 */       this.firstRowInBatch = this.currentRank;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   int doScrollPstmtExecuteUpdate() throws SQLException {
/* 11314 */     doScrollExecuteCommon();
/*       */     
/* 11316 */     if (this.sqlKind.isSELECT()) {
/* 11317 */       this.scrollRsetTypeSolved = true;
/*       */     }
/* 11319 */     return this.validRows;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public int copyBinds(Statement paramStatement, int paramInt) throws SQLException {
/* 11334 */     if (this.numberOfBindPositions > 0) {
/*       */       
/* 11336 */       OraclePreparedStatement oraclePreparedStatement = (OraclePreparedStatement)paramStatement;
/*       */       
/* 11338 */       int i = this.bindIndicatorSubRange + 5;
/*       */       
/* 11340 */       int j = this.bindByteSubRange;
/* 11341 */       int k = this.bindCharSubRange;
/* 11342 */       int m = this.indicatorsOffset;
/* 11343 */       int n = this.valueLengthsOffset;
/*       */       
/* 11345 */       for (byte b = 0; b < this.numberOfBindPositions; b++) {
/*       */         
/* 11347 */         short s1 = this.bindIndicators[i + 0];
/*       */         
/* 11349 */         short s2 = this.bindIndicators[i + 1];
/*       */         
/* 11351 */         short s3 = this.bindIndicators[i + 2];
/*       */ 
/*       */         
/* 11354 */         int i1 = b + paramInt;
/*       */ 
/*       */ 
/*       */         
/* 11358 */         if (oraclePreparedStatement.parameterDatum == null) {
/* 11359 */           oraclePreparedStatement.parameterDatum = new byte[oraclePreparedStatement.numberOfBindRowsAllocated][oraclePreparedStatement.numberOfBindPositions][];
/*       */         }
/*       */         
/* 11362 */         if (oraclePreparedStatement.parameterOtype == null) {
/* 11363 */           oraclePreparedStatement.parameterOtype = new OracleTypeADT[oraclePreparedStatement.numberOfBindRowsAllocated][oraclePreparedStatement.numberOfBindPositions];
/*       */         }
/*       */         
/* 11366 */         if (this.bindIndicators[m] == -1) {
/*       */           
/* 11368 */           oraclePreparedStatement.currentRowBinders[i1] = copiedNullBinder(s1, s2);
/*       */           
/* 11370 */           if (s3 > 0) {
/* 11371 */             oraclePreparedStatement.currentRowCharLens[i1] = 1;
/*       */           }
/* 11373 */         } else if (s1 == 109 || s1 == 111) {
/*       */           
/* 11375 */           oraclePreparedStatement.currentRowBinders[i1] = (s1 == 109) ? this.theNamedTypeBinder : this.theRefTypeBinder;
/*       */ 
/*       */ 
/*       */ 
/*       */           
/* 11380 */           byte[] arrayOfByte1 = this.parameterDatum[0][b];
/* 11381 */           int i2 = arrayOfByte1.length;
/* 11382 */           byte[] arrayOfByte2 = new byte[i2];
/*       */           
/* 11384 */           oraclePreparedStatement.parameterDatum[0][i1] = arrayOfByte2;
/*       */           
/* 11386 */           System.arraycopy(arrayOfByte1, 0, arrayOfByte2, 0, i2);
/*       */           
/* 11388 */           oraclePreparedStatement.parameterOtype[0][i1] = this.parameterOtype[0][b];
/* 11389 */           oraclePreparedStatement.currentRowByteLens[i1] = s2;
/*       */         }
/* 11391 */         else if (s2 > 0) {
/*       */           
/* 11393 */           oraclePreparedStatement.currentRowBinders[i1] = copiedByteBinder(s1, this.bindBytes, j, s2, this.bindIndicators[n]);
/*       */           
/* 11395 */           oraclePreparedStatement.currentRowByteLens[i1] = s2;
/*       */         }
/* 11397 */         else if (s3 > 0) {
/*       */           
/* 11399 */           oraclePreparedStatement.currentRowBinders[i1] = copiedCharBinder(s1, this.bindChars, k, s3, this.bindIndicators[n], getInoutIndicator(b));
/*       */           
/* 11401 */           oraclePreparedStatement.currentRowCharLens[i1] = s3;
/*       */         }
/*       */         else {
/*       */           
/* 11405 */           SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 89, "copyBinds doesn't understand type " + s1);
/* 11406 */           sQLException.fillInStackTrace();
/* 11407 */           throw sQLException;
/*       */         } 
/*       */         
/* 11410 */         j += this.bindBufferCapacity * s2;
/* 11411 */         k += this.bindBufferCapacity * s3;
/* 11412 */         m += this.numberOfBindRowsAllocated;
/* 11413 */         n += this.numberOfBindRowsAllocated;
/* 11414 */         i += 10;
/*       */       } 
/*       */     } 
/*       */     
/* 11418 */     return this.numberOfBindPositions;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   Binder copiedNullBinder(short paramShort, int paramInt) throws SQLException {
/* 11425 */     return new CopiedNullBinder(paramShort, paramInt);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   Binder copiedByteBinder(short paramShort1, byte[] paramArrayOfbyte, int paramInt1, int paramInt2, short paramShort2) throws SQLException {
/* 11433 */     byte[] arrayOfByte = new byte[paramInt2];
/*       */     
/* 11435 */     System.arraycopy(paramArrayOfbyte, paramInt1, arrayOfByte, 0, paramInt2);
/*       */     
/* 11437 */     return new CopiedByteBinder(paramShort1, paramInt2, arrayOfByte, paramShort2);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   Binder copiedCharBinder(short paramShort1, char[] paramArrayOfchar, int paramInt1, int paramInt2, short paramShort2, short paramShort3) throws SQLException {
/* 11445 */     char[] arrayOfChar = new char[paramInt2];
/*       */     
/* 11447 */     System.arraycopy(paramArrayOfchar, paramInt1, arrayOfChar, 0, paramInt2);
/*       */     
/* 11449 */     return new CopiedCharBinder(paramShort1, arrayOfChar, paramShort2, paramShort3);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   protected void hardClose() throws SQLException {
/* 11457 */     super.hardClose();
/*       */     
/* 11459 */     releaseBuffers();
/*       */ 
/*       */ 
/*       */ 
/*       */     
/* 11464 */     if (!this.connection.isClosed())
/*       */     {
/* 11466 */       cleanAllTempLobs();
/*       */     }
/*       */     
/* 11469 */     this.lastBoundBytes = null;
/* 11470 */     this.lastBoundChars = null;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   protected void alwaysOnClose() throws SQLException {
/* 11482 */     if (this.currentRank > 0)
/*       */     {
/* 11484 */       if (this.m_batchStyle == 2) {
/* 11485 */         clearBatch();
/*       */       
/*       */       }
/*       */       else {
/*       */ 
/*       */         
/* 11491 */         int i = this.validRows;
/*       */         
/* 11493 */         this.prematureBatchCount = sendBatch();
/* 11494 */         this.validRows = i;
/*       */       } 
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/* 11509 */     if (this.sqlKind.isSELECT()) {
/* 11510 */       OracleStatement oracleStatement = this.children;
/*       */       
/* 11512 */       while (oracleStatement != null) {
/* 11513 */         OracleStatement oracleStatement1 = oracleStatement.nextChild;
/*       */ 
/*       */         
/* 11516 */         if (oracleStatement.serverCursor) {
/* 11517 */           oracleStatement.cursorId = 0;
/*       */         }
/* 11519 */         oracleStatement = oracleStatement1;
/*       */       } 
/*       */     } 
/*       */     
/* 11523 */     super.alwaysOnClose();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setDisableStmtCaching(boolean paramBoolean) {
/* 11536 */     synchronized (this.connection) {
/*       */       
/* 11538 */       if (paramBoolean == true) {
/* 11539 */         this.cacheState = 3;
/*       */       }
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setFormOfUse(int paramInt, short paramShort) {
/* 11549 */     synchronized (this.connection) {
/*       */ 
/*       */       
/* 11552 */       int i = paramInt - 1;
/*       */       
/* 11554 */       if (this.currentRowFormOfUse[i] != paramShort) {
/*       */         
/* 11556 */         this.currentRowFormOfUse[i] = paramShort;
/*       */ 
/*       */ 
/*       */         
/* 11560 */         if (this.currentRowBindAccessors != null) {
/*       */           
/* 11562 */           Accessor accessor = this.currentRowBindAccessors[i];
/*       */           
/* 11564 */           if (accessor != null) {
/* 11565 */             accessor.setFormOfUse(paramShort);
/*       */           }
/*       */         } 
/*       */         
/* 11569 */         if (this.accessors != null) {
/*       */           
/* 11571 */           Accessor accessor = this.accessors[i];
/*       */           
/* 11573 */           if (accessor != null) {
/* 11574 */             accessor.setFormOfUse(paramShort);
/*       */           }
/*       */         } 
/*       */       } 
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setURL(int paramInt, URL paramURL) throws SQLException {
/* 11601 */     setURLInternal(paramInt, paramURL);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   void setURLInternal(int paramInt, URL paramURL) throws SQLException {
/* 11608 */     if (paramURL == null) {
/* 11609 */       setNull(paramInt, 1);
/*       */     } else {
/*       */       
/* 11612 */       setStringInternal(paramInt, paramURL.toString());
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public ParameterMetaData getParameterMetaData() throws SQLException {
/* 11620 */     ensureOpen();
/* 11621 */     return OracleParameterMetaData.getParameterMetaData(this.sqlObject, (Connection)this.connection);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public OracleParameterMetaData OracleGetParameterMetaData() throws SQLException {
/* 11644 */     SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException();
/* 11645 */     sQLException.fillInStackTrace();
/* 11646 */     throw sQLException;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void registerReturnParameter(int paramInt1, int paramInt2) throws SQLException {
/* 11656 */     if (this.numberOfBindPositions <= 0) {
/*       */       
/* 11658 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90);
/* 11659 */       sQLException.fillInStackTrace();
/* 11660 */       throw sQLException;
/*       */     } 
/*       */     
/* 11663 */     if (this.numReturnParams <= 0) {
/*       */       
/* 11665 */       this.numReturnParams = this.sqlObject.getReturnParameterCount();
/* 11666 */       if (this.numReturnParams <= 0) {
/*       */         
/* 11668 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90);
/* 11669 */         sQLException.fillInStackTrace();
/* 11670 */         throw sQLException;
/*       */       } 
/*       */     } 
/*       */     
/* 11674 */     int i = paramInt1 - 1;
/* 11675 */     if (i < this.numberOfBindPositions - this.numReturnParams || paramInt1 > this.numberOfBindPositions) {
/*       */ 
/*       */       
/* 11678 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 11679 */       sQLException.fillInStackTrace();
/* 11680 */       throw sQLException;
/*       */     } 
/*       */     
/* 11683 */     int j = getInternalTypeForDmlReturning(paramInt2);
/*       */     
/* 11685 */     short s = 0;
/* 11686 */     if (this.currentRowFormOfUse != null && this.currentRowFormOfUse[i] != 0) {
/* 11687 */       s = this.currentRowFormOfUse[i];
/*       */     }
/* 11689 */     registerReturnParameterInternal(i, j, paramInt2, -1, s, (String)null);
/*       */ 
/*       */     
/* 11692 */     this.currentRowBinders[i] = this.theReturnParamBinder;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void registerReturnParameter(int paramInt1, int paramInt2, int paramInt3) throws SQLException {
/* 11703 */     if (this.numberOfBindPositions <= 0) {
/*       */       
/* 11705 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90);
/* 11706 */       sQLException.fillInStackTrace();
/* 11707 */       throw sQLException;
/*       */     } 
/*       */     
/* 11710 */     int i = paramInt1 - 1;
/* 11711 */     if (i < 0 || paramInt1 > this.numberOfBindPositions) {
/*       */       
/* 11713 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 11714 */       sQLException.fillInStackTrace();
/* 11715 */       throw sQLException;
/*       */     } 
/*       */     
/* 11718 */     if (paramInt2 != 1 && paramInt2 != 12 && paramInt2 != -1 && paramInt2 != -2 && paramInt2 != -3 && paramInt2 != -4 && paramInt2 != 12) {
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/* 11727 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/* 11728 */       sQLException.fillInStackTrace();
/* 11729 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */     
/* 11733 */     if (paramInt3 <= 0) {
/*       */ 
/*       */       
/* 11736 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/* 11737 */       sQLException.fillInStackTrace();
/* 11738 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */     
/* 11742 */     int j = getInternalTypeForDmlReturning(paramInt2);
/*       */     
/* 11744 */     short s = 0;
/* 11745 */     if (this.currentRowFormOfUse != null && this.currentRowFormOfUse[i] != 0) {
/* 11746 */       s = this.currentRowFormOfUse[i];
/*       */     }
/* 11748 */     registerReturnParameterInternal(i, j, paramInt2, paramInt3, s, (String)null);
/*       */ 
/*       */     
/* 11751 */     this.currentRowBinders[i] = this.theReturnParamBinder;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void registerReturnParameter(int paramInt1, int paramInt2, String paramString) throws SQLException {
/* 11762 */     if (this.numberOfBindPositions <= 0) {
/*       */       
/* 11764 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90);
/* 11765 */       sQLException.fillInStackTrace();
/* 11766 */       throw sQLException;
/*       */     } 
/*       */     
/* 11769 */     int i = paramInt1 - 1;
/* 11770 */     if (i < 0 || paramInt1 > this.numberOfBindPositions) {
/*       */       
/* 11772 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 11773 */       sQLException.fillInStackTrace();
/* 11774 */       throw sQLException;
/*       */     } 
/*       */     
/* 11777 */     int j = getInternalTypeForDmlReturning(paramInt2);
/* 11778 */     if (j != 111 && j != 109) {
/*       */ 
/*       */ 
/*       */       
/* 11782 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/* 11783 */       sQLException.fillInStackTrace();
/* 11784 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */     
/* 11788 */     registerReturnParameterInternal(i, j, paramInt2, -1, (short)0, paramString);
/*       */ 
/*       */     
/* 11791 */     this.currentRowBinders[i] = this.theReturnParamBinder;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public ResultSet getReturnResultSet() throws SQLException {
/* 11799 */     if (this.closed) {
/*       */       
/* 11801 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 11802 */       sQLException.fillInStackTrace();
/* 11803 */       throw sQLException;
/*       */     } 
/*       */     
/* 11806 */     if (this.accessors == null || this.numReturnParams == 0) {
/*       */       
/* 11808 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 144);
/* 11809 */       sQLException.fillInStackTrace();
/* 11810 */       throw sQLException;
/*       */     } 
/*       */     
/* 11813 */     if (this.currentResultSet == null || this.numReturnParams == 0 || !this.isOpen) {
/*       */ 
/*       */ 
/*       */       
/* 11817 */       this.isComplete = true;
/* 11818 */       computeOffsetOfFirstUserColumn();
/* 11819 */       this.currentResultSet = OracleResultSet.createResultSet(this);
/*       */     } 
/*       */     
/* 11822 */     return (ResultSet)this.currentResultSet;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   int getInternalTypeForDmlReturning(int paramInt) throws SQLException {
/* 11836 */     char c = Character.MIN_VALUE;
/*       */     
/* 11838 */     switch (paramInt) {
/*       */       
/*       */       case -7:
/*       */       case -6:
/*       */       case -5:
/*       */       case 2:
/*       */       case 3:
/*       */       case 4:
/*       */       case 5:
/*       */       case 6:
/*       */       case 7:
/*       */       case 8:
/* 11850 */         c = '\006';
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/* 11952 */         return c;case 100: c = 'd'; return c;case 101: c = 'e'; return c;case -15: case 1: c = '`'; return c;case -9: case 12: c = '\001'; return c;case -16: case -1: c = '\b'; return c;case 91: case 92: c = '\f'; return c;case 93: c = '´'; return c;case -101: c = 'µ'; return c;case -102: c = 'ç'; return c;case -103: c = '¶'; return c;case -104: c = '·'; return c;case -3: case -2: c = '\027'; return c;case -4: c = '\030'; return c;case -8: c = 'h'; return c;case 2004: c = 'q'; return c;case 2005: case 2011: c = 'p'; return c;case -13: c = 'r'; return c;case 2002: case 2003: case 2007: case 2008: case 2009: c = 'm'; return c;case 2006: c = 'o'; return c;case 70: c = '\001'; return c;
/*       */     } 
/*       */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4);
/*       */     sQLException.fillInStackTrace();
/*       */     throw sQLException;
/*       */   }
/*       */   
/*       */   void registerReturnParamsForAutoKey() throws SQLException {
/* 11960 */     int[] arrayOfInt1 = this.autoKeyInfo.returnTypes;
/* 11961 */     short[] arrayOfShort = this.autoKeyInfo.tableFormOfUses;
/* 11962 */     int[] arrayOfInt2 = this.autoKeyInfo.columnIndexes;
/*       */     
/* 11964 */     int i = arrayOfInt1.length;
/*       */ 
/*       */     
/* 11967 */     int j = this.numberOfBindPositions - i;
/* 11968 */     this.offsetOfFirstUserColumn = j - 1;
/*       */ 
/*       */     
/* 11971 */     for (byte b = 0; b < i; b++) {
/*       */       
/* 11973 */       int k = j + b;
/* 11974 */       this.currentRowBinders[k] = this.theReturnParamBinder;
/*       */       
/* 11976 */       byte b1 = this.connection.defaultnchar ? 2 : 1;
/*       */ 
/*       */       
/* 11979 */       if (arrayOfShort != null && arrayOfInt2 != null)
/*       */       {
/* 11981 */         if (arrayOfShort[arrayOfInt2[b] - 1] == 2) {
/*       */ 
/*       */           
/* 11984 */           b1 = 2;
/* 11985 */           setFormOfUse(k + 1, b1);
/*       */         } 
/*       */       }
/*       */       
/* 11989 */       checkTypeForAutoKey(arrayOfInt1[b]);
/*       */       
/* 11991 */       String str = null;
/* 11992 */       if (arrayOfInt1[b] == 111) {
/* 11993 */         str = this.autoKeyInfo.tableTypeNames[arrayOfInt2[b] - 1];
/*       */       }
/* 11995 */       registerReturnParameterInternal(k, arrayOfInt1[b], arrayOfInt1[b], -1, b1, str);
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   void cleanOldTempLobs() {
/* 12005 */     if (this.m_batchStyle != 1 || this.currentRank == this.batch - 1)
/*       */     {
/* 12007 */       super.cleanOldTempLobs();
/*       */     }
/*       */   }
/*       */ 
/*       */ 
/*       */   
/*       */   void resetOnExceptionDuringExecute() {
/* 12014 */     super.resetOnExceptionDuringExecute();
/* 12015 */     this.currentRank = 0;
/* 12016 */     this.currentBatchNeedToPrepareBinds = true;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   void resetCurrentRowBinders() {
/* 12025 */     Binder[] arrayOfBinder = this.currentRowBinders;
/* 12026 */     if (this.binders != null && this.currentRowBinders != null && arrayOfBinder != this.binders[0]) {
/*       */ 
/*       */ 
/*       */       
/* 12030 */       this.currentRowBinders = this.binders[0];
/* 12031 */       this.binders[this.numberOfBoundRows] = arrayOfBinder;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setAsciiStream(int paramInt, InputStream paramInputStream) throws SQLException {
/* 12052 */     setAsciiStreamInternal(paramInt, paramInputStream);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setAsciiStream(int paramInt, InputStream paramInputStream, long paramLong) throws SQLException {
/* 12072 */     setAsciiStreamInternal(paramInt, paramInputStream, paramLong);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setBinaryStream(int paramInt, InputStream paramInputStream) throws SQLException {
/* 12091 */     setBinaryStreamInternal(paramInt, paramInputStream);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setBinaryStream(int paramInt, InputStream paramInputStream, long paramLong) throws SQLException {
/* 12111 */     setBinaryStreamInternal(paramInt, paramInputStream, paramLong);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setBlob(int paramInt, InputStream paramInputStream) throws SQLException {
/* 12129 */     setBlobInternal(paramInt, paramInputStream);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setBlob(int paramInt, InputStream paramInputStream, long paramLong) throws SQLException {
/* 12148 */     if (paramLong < 0L) {
/*       */       
/* 12150 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68, "length for setBlob() cannot be negative");
/* 12151 */       sQLException.fillInStackTrace();
/* 12152 */       throw sQLException;
/*       */     } 
/* 12154 */     setBlobInternal(paramInt, paramInputStream, paramLong);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setCharacterStream(int paramInt, Reader paramReader) throws SQLException {
/* 12173 */     setCharacterStreamInternal(paramInt, paramReader);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setCharacterStream(int paramInt, Reader paramReader, long paramLong) throws SQLException {
/* 12193 */     setCharacterStreamInternal(paramInt, paramReader, paramLong);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setClob(int paramInt, Reader paramReader, long paramLong) throws SQLException {
/* 12212 */     if (paramLong < 0L) {
/*       */       
/* 12214 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68, "length for setClob() cannot be negative");
/* 12215 */       sQLException.fillInStackTrace();
/* 12216 */       throw sQLException;
/*       */     } 
/* 12218 */     setClobInternal(paramInt, paramReader, paramLong);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setClob(int paramInt, Reader paramReader) throws SQLException {
/* 12237 */     setClobInternal(paramInt, paramReader);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setRowId(int paramInt, RowId paramRowId) throws SQLException {
/* 12257 */     setRowIdInternal(paramInt, paramRowId);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setNCharacterStream(int paramInt, Reader paramReader) throws SQLException {
/* 12278 */     setNCharacterStreamInternal(paramInt, paramReader);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setNCharacterStream(int paramInt, Reader paramReader, long paramLong) throws SQLException {
/* 12299 */     setNCharacterStreamInternal(paramInt, paramReader, paramLong);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setNClob(int paramInt, NClob paramNClob) throws SQLException {
/* 12319 */     setNClobInternal(paramInt, paramNClob);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setNClob(int paramInt, Reader paramReader, long paramLong) throws SQLException {
/* 12340 */     setNClobInternal(paramInt, paramReader, paramLong);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setNClob(int paramInt, Reader paramReader) throws SQLException {
/* 12360 */     setNClobInternal(paramInt, paramReader);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setSQLXML(int paramInt, SQLXML paramSQLXML) throws SQLException {
/* 12372 */     setSQLXMLInternal(paramInt, paramSQLXML);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setNString(int paramInt, String paramString) throws SQLException {
/* 12392 */     setNStringInternal(paramInt, paramString);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   void setAsciiStreamInternal(int paramInt, InputStream paramInputStream) throws SQLException {
/* 12400 */     setAsciiStreamInternal(paramInt, paramInputStream, 0L, false);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   void setAsciiStreamInternal(int paramInt, InputStream paramInputStream, long paramLong) throws SQLException {
/* 12408 */     setAsciiStreamInternal(paramInt, paramInputStream, paramLong, true);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   void setBinaryStreamInternal(int paramInt, InputStream paramInputStream) throws SQLException {
/* 12416 */     setBinaryStreamInternal(paramInt, paramInputStream, 0L, false);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   void setBinaryStreamInternal(int paramInt, InputStream paramInputStream, long paramLong) throws SQLException {
/* 12424 */     setBinaryStreamInternal(paramInt, paramInputStream, paramLong, true);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   void setBlobInternal(int paramInt, InputStream paramInputStream, long paramLong) throws SQLException {
/* 12433 */     int i = paramInt - 1;
/*       */     
/* 12435 */     if (i < 0 || paramInt > this.numberOfBindPositions) {
/*       */       
/* 12437 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 12438 */       sQLException.fillInStackTrace();
/* 12439 */       throw sQLException;
/*       */     } 
/*       */     
/* 12442 */     if (paramInputStream == null) {
/* 12443 */       setNullInternal(paramInt, 2004);
/*       */     } else {
/* 12445 */       setBinaryStreamContentsForBlobCritical(paramInt, paramInputStream, paramLong, !(paramLong == -1L));
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   void setBlobInternal(int paramInt, InputStream paramInputStream) throws SQLException {
/* 12454 */     setBlobInternal(paramInt, paramInputStream, -1L);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   void setCharacterStreamInternal(int paramInt, Reader paramReader) throws SQLException {
/* 12462 */     setCharacterStreamInternal(paramInt, paramReader, 0L, false);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   void setCharacterStreamInternal(int paramInt, Reader paramReader, long paramLong) throws SQLException {
/* 12470 */     setCharacterStreamInternal(paramInt, paramReader, paramLong, true);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   void setClobInternal(int paramInt, Reader paramReader) throws SQLException {
/* 12478 */     setClobInternal(paramInt, paramReader, -1L);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   void setClobInternal(int paramInt, Reader paramReader, long paramLong) throws SQLException {
/* 12486 */     int i = paramInt - 1;
/*       */     
/* 12488 */     if (i < 0 || paramInt > this.numberOfBindPositions) {
/*       */       
/* 12490 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 12491 */       sQLException.fillInStackTrace();
/* 12492 */       throw sQLException;
/*       */     } 
/*       */     
/* 12495 */     if (paramReader == null) {
/* 12496 */       setNullInternal(paramInt, 2005);
/*       */     } else {
/* 12498 */       setReaderContentsForClobCritical(paramInt, paramReader, paramLong, !(paramLong == -1L));
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   void setNCharacterStreamInternal(int paramInt, Reader paramReader) throws SQLException {
/* 12506 */     setFormOfUse(paramInt, (short)2);
/* 12507 */     setCharacterStreamInternal(paramInt, paramReader, 0L, false);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   void setNCharacterStreamInternal(int paramInt, Reader paramReader, long paramLong) throws SQLException {
/* 12515 */     setFormOfUse(paramInt, (short)2);
/* 12516 */     setCharacterStreamInternal(paramInt, paramReader, paramLong);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   void setNClobInternal(int paramInt, NClob paramNClob) throws SQLException {
/* 12524 */     setFormOfUse(paramInt, (short)2);
/* 12525 */     setClobInternal(paramInt, paramNClob);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   void setNClobInternal(int paramInt, Reader paramReader) throws SQLException {
/* 12533 */     setFormOfUse(paramInt, (short)2);
/* 12534 */     setClobInternal(paramInt, paramReader);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   void setNClobInternal(int paramInt, Reader paramReader, long paramLong) throws SQLException {
/* 12542 */     setFormOfUse(paramInt, (short)2);
/* 12543 */     setClobInternal(paramInt, paramReader, paramLong);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   void setNStringInternal(int paramInt, String paramString) throws SQLException {
/* 12551 */     setFormOfUse(paramInt, (short)2);
/* 12552 */     setStringInternal(paramInt, paramString);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   void setRowIdInternal(int paramInt, RowId paramRowId) throws SQLException {
/* 12560 */     setROWIDInternal(paramInt, (ROWID)paramRowId);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setArrayAtName(String paramString, Array paramArray) throws SQLException {
/* 12584 */     if (paramString == null) {
/*       */       
/* 12586 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/* 12587 */       sQLException.fillInStackTrace();
/* 12588 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */ 
/*       */     
/* 12593 */     String str = paramString.intern();
/* 12594 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 12595 */     boolean bool = false;
/* 12596 */     int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 12598 */     for (byte b = 0; b < i; b++) {
/* 12599 */       if (arrayOfString[b] == str) {
/* 12600 */         setArray(b + 1, paramArray);
/*       */         
/* 12602 */         bool = true;
/*       */       } 
/*       */     } 
/*       */     
/* 12606 */     if (!bool) {
/*       */       
/* 12608 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 12609 */       sQLException.fillInStackTrace();
/* 12610 */       throw sQLException;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setBigDecimalAtName(String paramString, BigDecimal paramBigDecimal) throws SQLException {
/* 12630 */     if (paramString == null) {
/*       */       
/* 12632 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/* 12633 */       sQLException.fillInStackTrace();
/* 12634 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */ 
/*       */     
/* 12639 */     String str = paramString.intern();
/* 12640 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 12641 */     boolean bool = false;
/* 12642 */     int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 12644 */     for (byte b = 0; b < i; b++) {
/* 12645 */       if (arrayOfString[b] == str) {
/* 12646 */         setBigDecimal(b + 1, paramBigDecimal);
/*       */         
/* 12648 */         bool = true;
/*       */       } 
/*       */     } 
/*       */     
/* 12652 */     if (!bool) {
/*       */       
/* 12654 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 12655 */       sQLException.fillInStackTrace();
/* 12656 */       throw sQLException;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setBlobAtName(String paramString, Blob paramBlob) throws SQLException {
/* 12676 */     if (paramString == null) {
/*       */       
/* 12678 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/* 12679 */       sQLException.fillInStackTrace();
/* 12680 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */ 
/*       */     
/* 12685 */     String str = paramString.intern();
/* 12686 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 12687 */     boolean bool = false;
/* 12688 */     int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 12690 */     for (byte b = 0; b < i; b++) {
/* 12691 */       if (arrayOfString[b] == str) {
/* 12692 */         setBlob(b + 1, paramBlob);
/*       */         
/* 12694 */         bool = true;
/*       */       } 
/*       */     } 
/*       */     
/* 12698 */     if (!bool) {
/*       */       
/* 12700 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 12701 */       sQLException.fillInStackTrace();
/* 12702 */       throw sQLException;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setBooleanAtName(String paramString, boolean paramBoolean) throws SQLException {
/* 12722 */     if (paramString == null) {
/*       */       
/* 12724 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/* 12725 */       sQLException.fillInStackTrace();
/* 12726 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */ 
/*       */     
/* 12731 */     String str = paramString.intern();
/* 12732 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 12733 */     boolean bool = false;
/* 12734 */     int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 12736 */     for (byte b = 0; b < i; b++) {
/* 12737 */       if (arrayOfString[b] == str) {
/* 12738 */         setBoolean(b + 1, paramBoolean);
/*       */         
/* 12740 */         bool = true;
/*       */       } 
/*       */     } 
/*       */     
/* 12744 */     if (!bool) {
/*       */       
/* 12746 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 12747 */       sQLException.fillInStackTrace();
/* 12748 */       throw sQLException;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setByteAtName(String paramString, byte paramByte) throws SQLException {
/* 12768 */     if (paramString == null) {
/*       */       
/* 12770 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/* 12771 */       sQLException.fillInStackTrace();
/* 12772 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */ 
/*       */     
/* 12777 */     String str = paramString.intern();
/* 12778 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 12779 */     boolean bool = false;
/* 12780 */     int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 12782 */     for (byte b = 0; b < i; b++) {
/* 12783 */       if (arrayOfString[b] == str) {
/* 12784 */         setByte(b + 1, paramByte);
/*       */         
/* 12786 */         bool = true;
/*       */       } 
/*       */     } 
/*       */     
/* 12790 */     if (!bool) {
/*       */       
/* 12792 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 12793 */       sQLException.fillInStackTrace();
/* 12794 */       throw sQLException;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setBytesAtName(String paramString, byte[] paramArrayOfbyte) throws SQLException {
/* 12814 */     if (paramString == null) {
/*       */       
/* 12816 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/* 12817 */       sQLException.fillInStackTrace();
/* 12818 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */ 
/*       */     
/* 12823 */     String str = paramString.intern();
/* 12824 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 12825 */     boolean bool = false;
/* 12826 */     int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 12828 */     for (byte b = 0; b < i; b++) {
/* 12829 */       if (arrayOfString[b] == str) {
/* 12830 */         setBytes(b + 1, paramArrayOfbyte);
/*       */         
/* 12832 */         bool = true;
/*       */       } 
/*       */     } 
/*       */     
/* 12836 */     if (!bool) {
/*       */       
/* 12838 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 12839 */       sQLException.fillInStackTrace();
/* 12840 */       throw sQLException;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setClobAtName(String paramString, Clob paramClob) throws SQLException {
/* 12860 */     if (paramString == null) {
/*       */       
/* 12862 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/* 12863 */       sQLException.fillInStackTrace();
/* 12864 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */ 
/*       */     
/* 12869 */     String str = paramString.intern();
/* 12870 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 12871 */     boolean bool = false;
/* 12872 */     int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 12874 */     for (byte b = 0; b < i; b++) {
/* 12875 */       if (arrayOfString[b] == str) {
/* 12876 */         setClob(b + 1, paramClob);
/*       */         
/* 12878 */         bool = true;
/*       */       } 
/*       */     } 
/*       */     
/* 12882 */     if (!bool) {
/*       */       
/* 12884 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 12885 */       sQLException.fillInStackTrace();
/* 12886 */       throw sQLException;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setDateAtName(String paramString, Date paramDate) throws SQLException {
/* 12906 */     if (paramString == null) {
/*       */       
/* 12908 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/* 12909 */       sQLException.fillInStackTrace();
/* 12910 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */ 
/*       */     
/* 12915 */     String str = paramString.intern();
/* 12916 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 12917 */     boolean bool = false;
/* 12918 */     int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 12920 */     for (byte b = 0; b < i; b++) {
/* 12921 */       if (arrayOfString[b] == str) {
/* 12922 */         setDate(b + 1, paramDate);
/*       */         
/* 12924 */         bool = true;
/*       */       } 
/*       */     } 
/*       */     
/* 12928 */     if (!bool) {
/*       */       
/* 12930 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 12931 */       sQLException.fillInStackTrace();
/* 12932 */       throw sQLException;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setDateAtName(String paramString, Date paramDate, Calendar paramCalendar) throws SQLException {
/* 12952 */     if (paramString == null) {
/*       */       
/* 12954 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/* 12955 */       sQLException.fillInStackTrace();
/* 12956 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */ 
/*       */     
/* 12961 */     String str = paramString.intern();
/* 12962 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 12963 */     boolean bool = false;
/* 12964 */     int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 12966 */     for (byte b = 0; b < i; b++) {
/* 12967 */       if (arrayOfString[b] == str) {
/* 12968 */         setDate(b + 1, paramDate, paramCalendar);
/*       */         
/* 12970 */         bool = true;
/*       */       } 
/*       */     } 
/*       */     
/* 12974 */     if (!bool) {
/*       */       
/* 12976 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 12977 */       sQLException.fillInStackTrace();
/* 12978 */       throw sQLException;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setDoubleAtName(String paramString, double paramDouble) throws SQLException {
/* 12998 */     if (paramString == null) {
/*       */       
/* 13000 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/* 13001 */       sQLException.fillInStackTrace();
/* 13002 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */ 
/*       */     
/* 13007 */     String str = paramString.intern();
/* 13008 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 13009 */     boolean bool = false;
/* 13010 */     int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 13012 */     for (byte b = 0; b < i; b++) {
/* 13013 */       if (arrayOfString[b] == str) {
/* 13014 */         setDouble(b + 1, paramDouble);
/*       */         
/* 13016 */         bool = true;
/*       */       } 
/*       */     } 
/*       */     
/* 13020 */     if (!bool) {
/*       */       
/* 13022 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 13023 */       sQLException.fillInStackTrace();
/* 13024 */       throw sQLException;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setFloatAtName(String paramString, float paramFloat) throws SQLException {
/* 13044 */     if (paramString == null) {
/*       */       
/* 13046 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/* 13047 */       sQLException.fillInStackTrace();
/* 13048 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */ 
/*       */     
/* 13053 */     String str = paramString.intern();
/* 13054 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 13055 */     boolean bool = false;
/* 13056 */     int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 13058 */     for (byte b = 0; b < i; b++) {
/* 13059 */       if (arrayOfString[b] == str) {
/* 13060 */         setFloat(b + 1, paramFloat);
/*       */         
/* 13062 */         bool = true;
/*       */       } 
/*       */     } 
/*       */     
/* 13066 */     if (!bool) {
/*       */       
/* 13068 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 13069 */       sQLException.fillInStackTrace();
/* 13070 */       throw sQLException;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setIntAtName(String paramString, int paramInt) throws SQLException {
/* 13090 */     if (paramString == null) {
/*       */       
/* 13092 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/* 13093 */       sQLException.fillInStackTrace();
/* 13094 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */ 
/*       */     
/* 13099 */     String str = paramString.intern();
/* 13100 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 13101 */     boolean bool = false;
/* 13102 */     int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 13104 */     for (byte b = 0; b < i; b++) {
/* 13105 */       if (arrayOfString[b] == str) {
/* 13106 */         setInt(b + 1, paramInt);
/*       */         
/* 13108 */         bool = true;
/*       */       } 
/*       */     } 
/*       */     
/* 13112 */     if (!bool) {
/*       */       
/* 13114 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 13115 */       sQLException.fillInStackTrace();
/* 13116 */       throw sQLException;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setLongAtName(String paramString, long paramLong) throws SQLException {
/* 13136 */     if (paramString == null) {
/*       */       
/* 13138 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/* 13139 */       sQLException.fillInStackTrace();
/* 13140 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */ 
/*       */     
/* 13145 */     String str = paramString.intern();
/* 13146 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 13147 */     boolean bool = false;
/* 13148 */     int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 13150 */     for (byte b = 0; b < i; b++) {
/* 13151 */       if (arrayOfString[b] == str) {
/* 13152 */         setLong(b + 1, paramLong);
/*       */         
/* 13154 */         bool = true;
/*       */       } 
/*       */     } 
/*       */     
/* 13158 */     if (!bool) {
/*       */       
/* 13160 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 13161 */       sQLException.fillInStackTrace();
/* 13162 */       throw sQLException;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setNClobAtName(String paramString, NClob paramNClob) throws SQLException {
/* 13182 */     if (paramString == null) {
/*       */       
/* 13184 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/* 13185 */       sQLException.fillInStackTrace();
/* 13186 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */ 
/*       */     
/* 13191 */     String str = paramString.intern();
/* 13192 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 13193 */     boolean bool = false;
/* 13194 */     int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 13196 */     for (byte b = 0; b < i; b++) {
/* 13197 */       if (arrayOfString[b] == str) {
/* 13198 */         setNClob(b + 1, paramNClob);
/*       */         
/* 13200 */         bool = true;
/*       */       } 
/*       */     } 
/*       */     
/* 13204 */     if (!bool) {
/*       */       
/* 13206 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 13207 */       sQLException.fillInStackTrace();
/* 13208 */       throw sQLException;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setNStringAtName(String paramString1, String paramString2) throws SQLException {
/* 13228 */     if (paramString1 == null) {
/*       */       
/* 13230 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/* 13231 */       sQLException.fillInStackTrace();
/* 13232 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */ 
/*       */     
/* 13237 */     String str = paramString1.intern();
/* 13238 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 13239 */     boolean bool = false;
/* 13240 */     int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 13242 */     for (byte b = 0; b < i; b++) {
/* 13243 */       if (arrayOfString[b] == str) {
/* 13244 */         setNString(b + 1, paramString2);
/*       */         
/* 13246 */         bool = true;
/*       */       } 
/*       */     } 
/*       */     
/* 13250 */     if (!bool) {
/*       */       
/* 13252 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString1);
/* 13253 */       sQLException.fillInStackTrace();
/* 13254 */       throw sQLException;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setObjectAtName(String paramString, Object paramObject) throws SQLException {
/* 13274 */     if (paramString == null) {
/*       */       
/* 13276 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/* 13277 */       sQLException.fillInStackTrace();
/* 13278 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */ 
/*       */     
/* 13283 */     String str = paramString.intern();
/* 13284 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 13285 */     boolean bool = false;
/* 13286 */     int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 13288 */     for (byte b = 0; b < i; b++) {
/* 13289 */       if (arrayOfString[b] == str) {
/* 13290 */         setObject(b + 1, paramObject);
/*       */         
/* 13292 */         bool = true;
/*       */       } 
/*       */     } 
/*       */     
/* 13296 */     if (!bool) {
/*       */       
/* 13298 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 13299 */       sQLException.fillInStackTrace();
/* 13300 */       throw sQLException;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setObjectAtName(String paramString, Object paramObject, int paramInt) throws SQLException {
/* 13320 */     if (paramString == null) {
/*       */       
/* 13322 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/* 13323 */       sQLException.fillInStackTrace();
/* 13324 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */ 
/*       */     
/* 13329 */     String str = paramString.intern();
/* 13330 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 13331 */     boolean bool = false;
/* 13332 */     int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 13334 */     for (byte b = 0; b < i; b++) {
/* 13335 */       if (arrayOfString[b] == str) {
/* 13336 */         setObject(b + 1, paramObject, paramInt);
/*       */         
/* 13338 */         bool = true;
/*       */       } 
/*       */     } 
/*       */     
/* 13342 */     if (!bool) {
/*       */       
/* 13344 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 13345 */       sQLException.fillInStackTrace();
/* 13346 */       throw sQLException;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setRefAtName(String paramString, Ref paramRef) throws SQLException {
/* 13366 */     if (paramString == null) {
/*       */       
/* 13368 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/* 13369 */       sQLException.fillInStackTrace();
/* 13370 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */ 
/*       */     
/* 13375 */     String str = paramString.intern();
/* 13376 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 13377 */     boolean bool = false;
/* 13378 */     int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 13380 */     for (byte b = 0; b < i; b++) {
/* 13381 */       if (arrayOfString[b] == str) {
/* 13382 */         setRef(b + 1, paramRef);
/*       */         
/* 13384 */         bool = true;
/*       */       } 
/*       */     } 
/*       */     
/* 13388 */     if (!bool) {
/*       */       
/* 13390 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 13391 */       sQLException.fillInStackTrace();
/* 13392 */       throw sQLException;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setRowIdAtName(String paramString, RowId paramRowId) throws SQLException {
/* 13412 */     if (paramString == null) {
/*       */       
/* 13414 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/* 13415 */       sQLException.fillInStackTrace();
/* 13416 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */ 
/*       */     
/* 13421 */     String str = paramString.intern();
/* 13422 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 13423 */     boolean bool = false;
/* 13424 */     int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 13426 */     for (byte b = 0; b < i; b++) {
/* 13427 */       if (arrayOfString[b] == str) {
/* 13428 */         setRowId(b + 1, paramRowId);
/*       */         
/* 13430 */         bool = true;
/*       */       } 
/*       */     } 
/*       */     
/* 13434 */     if (!bool) {
/*       */       
/* 13436 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 13437 */       sQLException.fillInStackTrace();
/* 13438 */       throw sQLException;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setShortAtName(String paramString, short paramShort) throws SQLException {
/* 13458 */     if (paramString == null) {
/*       */       
/* 13460 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/* 13461 */       sQLException.fillInStackTrace();
/* 13462 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */ 
/*       */     
/* 13467 */     String str = paramString.intern();
/* 13468 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 13469 */     boolean bool = false;
/* 13470 */     int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 13472 */     for (byte b = 0; b < i; b++) {
/* 13473 */       if (arrayOfString[b] == str) {
/* 13474 */         setShort(b + 1, paramShort);
/*       */         
/* 13476 */         bool = true;
/*       */       } 
/*       */     } 
/*       */     
/* 13480 */     if (!bool) {
/*       */       
/* 13482 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 13483 */       sQLException.fillInStackTrace();
/* 13484 */       throw sQLException;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setSQLXMLAtName(String paramString, SQLXML paramSQLXML) throws SQLException {
/* 13504 */     if (paramString == null) {
/*       */       
/* 13506 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/* 13507 */       sQLException.fillInStackTrace();
/* 13508 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */ 
/*       */     
/* 13513 */     String str = paramString.intern();
/* 13514 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 13515 */     boolean bool = false;
/* 13516 */     int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 13518 */     for (byte b = 0; b < i; b++) {
/* 13519 */       if (arrayOfString[b] == str) {
/* 13520 */         setSQLXML(b + 1, paramSQLXML);
/*       */         
/* 13522 */         bool = true;
/*       */       } 
/*       */     } 
/*       */     
/* 13526 */     if (!bool) {
/*       */       
/* 13528 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 13529 */       sQLException.fillInStackTrace();
/* 13530 */       throw sQLException;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setStringAtName(String paramString1, String paramString2) throws SQLException {
/* 13550 */     if (paramString1 == null) {
/*       */       
/* 13552 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/* 13553 */       sQLException.fillInStackTrace();
/* 13554 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */ 
/*       */     
/* 13559 */     String str = paramString1.intern();
/* 13560 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 13561 */     boolean bool = false;
/* 13562 */     int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 13564 */     for (byte b = 0; b < i; b++) {
/* 13565 */       if (arrayOfString[b] == str) {
/* 13566 */         setString(b + 1, paramString2);
/*       */         
/* 13568 */         bool = true;
/*       */       } 
/*       */     } 
/*       */     
/* 13572 */     if (!bool) {
/*       */       
/* 13574 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString1);
/* 13575 */       sQLException.fillInStackTrace();
/* 13576 */       throw sQLException;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setTimeAtName(String paramString, Time paramTime) throws SQLException {
/* 13596 */     if (paramString == null) {
/*       */       
/* 13598 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/* 13599 */       sQLException.fillInStackTrace();
/* 13600 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */ 
/*       */     
/* 13605 */     String str = paramString.intern();
/* 13606 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 13607 */     boolean bool = false;
/* 13608 */     int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 13610 */     for (byte b = 0; b < i; b++) {
/* 13611 */       if (arrayOfString[b] == str) {
/* 13612 */         setTime(b + 1, paramTime);
/*       */         
/* 13614 */         bool = true;
/*       */       } 
/*       */     } 
/*       */     
/* 13618 */     if (!bool) {
/*       */       
/* 13620 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 13621 */       sQLException.fillInStackTrace();
/* 13622 */       throw sQLException;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setTimeAtName(String paramString, Time paramTime, Calendar paramCalendar) throws SQLException {
/* 13642 */     if (paramString == null) {
/*       */       
/* 13644 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/* 13645 */       sQLException.fillInStackTrace();
/* 13646 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */ 
/*       */     
/* 13651 */     String str = paramString.intern();
/* 13652 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 13653 */     boolean bool = false;
/* 13654 */     int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 13656 */     for (byte b = 0; b < i; b++) {
/* 13657 */       if (arrayOfString[b] == str) {
/* 13658 */         setTime(b + 1, paramTime, paramCalendar);
/*       */         
/* 13660 */         bool = true;
/*       */       } 
/*       */     } 
/*       */     
/* 13664 */     if (!bool) {
/*       */       
/* 13666 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 13667 */       sQLException.fillInStackTrace();
/* 13668 */       throw sQLException;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setTimestampAtName(String paramString, Timestamp paramTimestamp) throws SQLException {
/* 13688 */     if (paramString == null) {
/*       */       
/* 13690 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/* 13691 */       sQLException.fillInStackTrace();
/* 13692 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */ 
/*       */     
/* 13697 */     String str = paramString.intern();
/* 13698 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 13699 */     boolean bool = false;
/* 13700 */     int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 13702 */     for (byte b = 0; b < i; b++) {
/* 13703 */       if (arrayOfString[b] == str) {
/* 13704 */         setTimestamp(b + 1, paramTimestamp);
/*       */         
/* 13706 */         bool = true;
/*       */       } 
/*       */     } 
/*       */     
/* 13710 */     if (!bool) {
/*       */       
/* 13712 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 13713 */       sQLException.fillInStackTrace();
/* 13714 */       throw sQLException;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setTimestampAtName(String paramString, Timestamp paramTimestamp, Calendar paramCalendar) throws SQLException {
/* 13734 */     if (paramString == null) {
/*       */       
/* 13736 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/* 13737 */       sQLException.fillInStackTrace();
/* 13738 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */ 
/*       */     
/* 13743 */     String str = paramString.intern();
/* 13744 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 13745 */     boolean bool = false;
/* 13746 */     int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 13748 */     for (byte b = 0; b < i; b++) {
/* 13749 */       if (arrayOfString[b] == str) {
/* 13750 */         setTimestamp(b + 1, paramTimestamp, paramCalendar);
/*       */         
/* 13752 */         bool = true;
/*       */       } 
/*       */     } 
/*       */     
/* 13756 */     if (!bool) {
/*       */       
/* 13758 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 13759 */       sQLException.fillInStackTrace();
/* 13760 */       throw sQLException;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setURLAtName(String paramString, URL paramURL) throws SQLException {
/* 13780 */     if (paramString == null) {
/*       */       
/* 13782 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/* 13783 */       sQLException.fillInStackTrace();
/* 13784 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */ 
/*       */     
/* 13789 */     String str = paramString.intern();
/* 13790 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 13791 */     boolean bool = false;
/* 13792 */     int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 13794 */     for (byte b = 0; b < i; b++) {
/* 13795 */       if (arrayOfString[b] == str) {
/* 13796 */         setURL(b + 1, paramURL);
/*       */         
/* 13798 */         bool = true;
/*       */       } 
/*       */     } 
/*       */     
/* 13802 */     if (!bool) {
/*       */       
/* 13804 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 13805 */       sQLException.fillInStackTrace();
/* 13806 */       throw sQLException;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setARRAYAtName(String paramString, ARRAY paramARRAY) throws SQLException {
/* 13826 */     if (paramString == null) {
/*       */       
/* 13828 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/* 13829 */       sQLException.fillInStackTrace();
/* 13830 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */ 
/*       */     
/* 13835 */     String str = paramString.intern();
/* 13836 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 13837 */     boolean bool = false;
/* 13838 */     int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 13840 */     for (byte b = 0; b < i; b++) {
/* 13841 */       if (arrayOfString[b] == str) {
/* 13842 */         setARRAY(b + 1, paramARRAY);
/*       */         
/* 13844 */         bool = true;
/*       */       } 
/*       */     } 
/*       */     
/* 13848 */     if (!bool) {
/*       */       
/* 13850 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 13851 */       sQLException.fillInStackTrace();
/* 13852 */       throw sQLException;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setBFILEAtName(String paramString, BFILE paramBFILE) throws SQLException {
/* 13872 */     if (paramString == null) {
/*       */       
/* 13874 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/* 13875 */       sQLException.fillInStackTrace();
/* 13876 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */ 
/*       */     
/* 13881 */     String str = paramString.intern();
/* 13882 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 13883 */     boolean bool = false;
/* 13884 */     int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 13886 */     for (byte b = 0; b < i; b++) {
/* 13887 */       if (arrayOfString[b] == str) {
/* 13888 */         setBFILE(b + 1, paramBFILE);
/*       */         
/* 13890 */         bool = true;
/*       */       } 
/*       */     } 
/*       */     
/* 13894 */     if (!bool) {
/*       */       
/* 13896 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 13897 */       sQLException.fillInStackTrace();
/* 13898 */       throw sQLException;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setBfileAtName(String paramString, BFILE paramBFILE) throws SQLException {
/* 13918 */     if (paramString == null) {
/*       */       
/* 13920 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/* 13921 */       sQLException.fillInStackTrace();
/* 13922 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */ 
/*       */     
/* 13927 */     String str = paramString.intern();
/* 13928 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 13929 */     boolean bool = false;
/* 13930 */     int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 13932 */     for (byte b = 0; b < i; b++) {
/* 13933 */       if (arrayOfString[b] == str) {
/* 13934 */         setBfile(b + 1, paramBFILE);
/*       */         
/* 13936 */         bool = true;
/*       */       } 
/*       */     } 
/*       */     
/* 13940 */     if (!bool) {
/*       */       
/* 13942 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 13943 */       sQLException.fillInStackTrace();
/* 13944 */       throw sQLException;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setBinaryFloatAtName(String paramString, float paramFloat) throws SQLException {
/* 13964 */     if (paramString == null) {
/*       */       
/* 13966 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/* 13967 */       sQLException.fillInStackTrace();
/* 13968 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */ 
/*       */     
/* 13973 */     String str = paramString.intern();
/* 13974 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 13975 */     boolean bool = false;
/* 13976 */     int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 13978 */     for (byte b = 0; b < i; b++) {
/* 13979 */       if (arrayOfString[b] == str) {
/* 13980 */         setBinaryFloat(b + 1, paramFloat);
/*       */         
/* 13982 */         bool = true;
/*       */       } 
/*       */     } 
/*       */     
/* 13986 */     if (!bool) {
/*       */       
/* 13988 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 13989 */       sQLException.fillInStackTrace();
/* 13990 */       throw sQLException;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setBinaryFloatAtName(String paramString, BINARY_FLOAT paramBINARY_FLOAT) throws SQLException {
/* 14010 */     if (paramString == null) {
/*       */       
/* 14012 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/* 14013 */       sQLException.fillInStackTrace();
/* 14014 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */ 
/*       */     
/* 14019 */     String str = paramString.intern();
/* 14020 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 14021 */     boolean bool = false;
/* 14022 */     int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 14024 */     for (byte b = 0; b < i; b++) {
/* 14025 */       if (arrayOfString[b] == str) {
/* 14026 */         setBinaryFloat(b + 1, paramBINARY_FLOAT);
/*       */         
/* 14028 */         bool = true;
/*       */       } 
/*       */     } 
/*       */     
/* 14032 */     if (!bool) {
/*       */       
/* 14034 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 14035 */       sQLException.fillInStackTrace();
/* 14036 */       throw sQLException;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setBinaryDoubleAtName(String paramString, double paramDouble) throws SQLException {
/* 14056 */     if (paramString == null) {
/*       */       
/* 14058 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/* 14059 */       sQLException.fillInStackTrace();
/* 14060 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */ 
/*       */     
/* 14065 */     String str = paramString.intern();
/* 14066 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 14067 */     boolean bool = false;
/* 14068 */     int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 14070 */     for (byte b = 0; b < i; b++) {
/* 14071 */       if (arrayOfString[b] == str) {
/* 14072 */         setBinaryDouble(b + 1, paramDouble);
/*       */         
/* 14074 */         bool = true;
/*       */       } 
/*       */     } 
/*       */     
/* 14078 */     if (!bool) {
/*       */       
/* 14080 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 14081 */       sQLException.fillInStackTrace();
/* 14082 */       throw sQLException;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setBinaryDoubleAtName(String paramString, BINARY_DOUBLE paramBINARY_DOUBLE) throws SQLException {
/* 14102 */     if (paramString == null) {
/*       */       
/* 14104 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/* 14105 */       sQLException.fillInStackTrace();
/* 14106 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */ 
/*       */     
/* 14111 */     String str = paramString.intern();
/* 14112 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 14113 */     boolean bool = false;
/* 14114 */     int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 14116 */     for (byte b = 0; b < i; b++) {
/* 14117 */       if (arrayOfString[b] == str) {
/* 14118 */         setBinaryDouble(b + 1, paramBINARY_DOUBLE);
/*       */         
/* 14120 */         bool = true;
/*       */       } 
/*       */     } 
/*       */     
/* 14124 */     if (!bool) {
/*       */       
/* 14126 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 14127 */       sQLException.fillInStackTrace();
/* 14128 */       throw sQLException;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setBLOBAtName(String paramString, BLOB paramBLOB) throws SQLException {
/* 14148 */     if (paramString == null) {
/*       */       
/* 14150 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/* 14151 */       sQLException.fillInStackTrace();
/* 14152 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */ 
/*       */     
/* 14157 */     String str = paramString.intern();
/* 14158 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 14159 */     boolean bool = false;
/* 14160 */     int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 14162 */     for (byte b = 0; b < i; b++) {
/* 14163 */       if (arrayOfString[b] == str) {
/* 14164 */         setBLOB(b + 1, paramBLOB);
/*       */         
/* 14166 */         bool = true;
/*       */       } 
/*       */     } 
/*       */     
/* 14170 */     if (!bool) {
/*       */       
/* 14172 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 14173 */       sQLException.fillInStackTrace();
/* 14174 */       throw sQLException;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setCHARAtName(String paramString, CHAR paramCHAR) throws SQLException {
/* 14194 */     if (paramString == null) {
/*       */       
/* 14196 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/* 14197 */       sQLException.fillInStackTrace();
/* 14198 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */ 
/*       */     
/* 14203 */     String str = paramString.intern();
/* 14204 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 14205 */     boolean bool = false;
/* 14206 */     int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 14208 */     for (byte b = 0; b < i; b++) {
/* 14209 */       if (arrayOfString[b] == str) {
/* 14210 */         setCHAR(b + 1, paramCHAR);
/*       */         
/* 14212 */         bool = true;
/*       */       } 
/*       */     } 
/*       */     
/* 14216 */     if (!bool) {
/*       */       
/* 14218 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 14219 */       sQLException.fillInStackTrace();
/* 14220 */       throw sQLException;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setCLOBAtName(String paramString, CLOB paramCLOB) throws SQLException {
/* 14240 */     if (paramString == null) {
/*       */       
/* 14242 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/* 14243 */       sQLException.fillInStackTrace();
/* 14244 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */ 
/*       */     
/* 14249 */     String str = paramString.intern();
/* 14250 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 14251 */     boolean bool = false;
/* 14252 */     int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 14254 */     for (byte b = 0; b < i; b++) {
/* 14255 */       if (arrayOfString[b] == str) {
/* 14256 */         setCLOB(b + 1, paramCLOB);
/*       */         
/* 14258 */         bool = true;
/*       */       } 
/*       */     } 
/*       */     
/* 14262 */     if (!bool) {
/*       */       
/* 14264 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 14265 */       sQLException.fillInStackTrace();
/* 14266 */       throw sQLException;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setCursorAtName(String paramString, ResultSet paramResultSet) throws SQLException {
/* 14286 */     if (paramString == null) {
/*       */       
/* 14288 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/* 14289 */       sQLException.fillInStackTrace();
/* 14290 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */ 
/*       */     
/* 14295 */     String str = paramString.intern();
/* 14296 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 14297 */     boolean bool = false;
/* 14298 */     int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 14300 */     for (byte b = 0; b < i; b++) {
/* 14301 */       if (arrayOfString[b] == str) {
/* 14302 */         setCursor(b + 1, paramResultSet);
/*       */         
/* 14304 */         bool = true;
/*       */       } 
/*       */     } 
/*       */     
/* 14308 */     if (!bool) {
/*       */       
/* 14310 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 14311 */       sQLException.fillInStackTrace();
/* 14312 */       throw sQLException;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setDATEAtName(String paramString, DATE paramDATE) throws SQLException {
/* 14332 */     if (paramString == null) {
/*       */       
/* 14334 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/* 14335 */       sQLException.fillInStackTrace();
/* 14336 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */ 
/*       */     
/* 14341 */     String str = paramString.intern();
/* 14342 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 14343 */     boolean bool = false;
/* 14344 */     int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 14346 */     for (byte b = 0; b < i; b++) {
/* 14347 */       if (arrayOfString[b] == str) {
/* 14348 */         setDATE(b + 1, paramDATE);
/*       */         
/* 14350 */         bool = true;
/*       */       } 
/*       */     } 
/*       */     
/* 14354 */     if (!bool) {
/*       */       
/* 14356 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 14357 */       sQLException.fillInStackTrace();
/* 14358 */       throw sQLException;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setFixedCHARAtName(String paramString1, String paramString2) throws SQLException {
/* 14378 */     if (paramString1 == null) {
/*       */       
/* 14380 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/* 14381 */       sQLException.fillInStackTrace();
/* 14382 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */ 
/*       */     
/* 14387 */     String str = paramString1.intern();
/* 14388 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 14389 */     boolean bool = false;
/* 14390 */     int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 14392 */     for (byte b = 0; b < i; b++) {
/* 14393 */       if (arrayOfString[b] == str) {
/* 14394 */         setFixedCHAR(b + 1, paramString2);
/*       */         
/* 14396 */         bool = true;
/*       */       } 
/*       */     } 
/*       */     
/* 14400 */     if (!bool) {
/*       */       
/* 14402 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString1);
/* 14403 */       sQLException.fillInStackTrace();
/* 14404 */       throw sQLException;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setINTERVALDSAtName(String paramString, INTERVALDS paramINTERVALDS) throws SQLException {
/* 14424 */     if (paramString == null) {
/*       */       
/* 14426 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/* 14427 */       sQLException.fillInStackTrace();
/* 14428 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */ 
/*       */     
/* 14433 */     String str = paramString.intern();
/* 14434 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 14435 */     boolean bool = false;
/* 14436 */     int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 14438 */     for (byte b = 0; b < i; b++) {
/* 14439 */       if (arrayOfString[b] == str) {
/* 14440 */         setINTERVALDS(b + 1, paramINTERVALDS);
/*       */         
/* 14442 */         bool = true;
/*       */       } 
/*       */     } 
/*       */     
/* 14446 */     if (!bool) {
/*       */       
/* 14448 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 14449 */       sQLException.fillInStackTrace();
/* 14450 */       throw sQLException;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setINTERVALYMAtName(String paramString, INTERVALYM paramINTERVALYM) throws SQLException {
/* 14470 */     if (paramString == null) {
/*       */       
/* 14472 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/* 14473 */       sQLException.fillInStackTrace();
/* 14474 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */ 
/*       */     
/* 14479 */     String str = paramString.intern();
/* 14480 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 14481 */     boolean bool = false;
/* 14482 */     int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 14484 */     for (byte b = 0; b < i; b++) {
/* 14485 */       if (arrayOfString[b] == str) {
/* 14486 */         setINTERVALYM(b + 1, paramINTERVALYM);
/*       */         
/* 14488 */         bool = true;
/*       */       } 
/*       */     } 
/*       */     
/* 14492 */     if (!bool) {
/*       */       
/* 14494 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 14495 */       sQLException.fillInStackTrace();
/* 14496 */       throw sQLException;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setNUMBERAtName(String paramString, NUMBER paramNUMBER) throws SQLException {
/* 14516 */     if (paramString == null) {
/*       */       
/* 14518 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/* 14519 */       sQLException.fillInStackTrace();
/* 14520 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */ 
/*       */     
/* 14525 */     String str = paramString.intern();
/* 14526 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 14527 */     boolean bool = false;
/* 14528 */     int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 14530 */     for (byte b = 0; b < i; b++) {
/* 14531 */       if (arrayOfString[b] == str) {
/* 14532 */         setNUMBER(b + 1, paramNUMBER);
/*       */         
/* 14534 */         bool = true;
/*       */       } 
/*       */     } 
/*       */     
/* 14538 */     if (!bool) {
/*       */       
/* 14540 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 14541 */       sQLException.fillInStackTrace();
/* 14542 */       throw sQLException;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setOPAQUEAtName(String paramString, OPAQUE paramOPAQUE) throws SQLException {
/* 14562 */     if (paramString == null) {
/*       */       
/* 14564 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/* 14565 */       sQLException.fillInStackTrace();
/* 14566 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */ 
/*       */     
/* 14571 */     String str = paramString.intern();
/* 14572 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 14573 */     boolean bool = false;
/* 14574 */     int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 14576 */     for (byte b = 0; b < i; b++) {
/* 14577 */       if (arrayOfString[b] == str) {
/* 14578 */         setOPAQUE(b + 1, paramOPAQUE);
/*       */         
/* 14580 */         bool = true;
/*       */       } 
/*       */     } 
/*       */     
/* 14584 */     if (!bool) {
/*       */       
/* 14586 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 14587 */       sQLException.fillInStackTrace();
/* 14588 */       throw sQLException;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setOracleObjectAtName(String paramString, Datum paramDatum) throws SQLException {
/* 14608 */     if (paramString == null) {
/*       */       
/* 14610 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/* 14611 */       sQLException.fillInStackTrace();
/* 14612 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */ 
/*       */     
/* 14617 */     String str = paramString.intern();
/* 14618 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 14619 */     boolean bool = false;
/* 14620 */     int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 14622 */     for (byte b = 0; b < i; b++) {
/* 14623 */       if (arrayOfString[b] == str) {
/* 14624 */         setOracleObject(b + 1, paramDatum);
/*       */         
/* 14626 */         bool = true;
/*       */       } 
/*       */     } 
/*       */     
/* 14630 */     if (!bool) {
/*       */       
/* 14632 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 14633 */       sQLException.fillInStackTrace();
/* 14634 */       throw sQLException;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setORADataAtName(String paramString, ORAData paramORAData) throws SQLException {
/* 14654 */     if (paramString == null) {
/*       */       
/* 14656 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/* 14657 */       sQLException.fillInStackTrace();
/* 14658 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */ 
/*       */     
/* 14663 */     String str = paramString.intern();
/* 14664 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 14665 */     boolean bool = false;
/* 14666 */     int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 14668 */     for (byte b = 0; b < i; b++) {
/* 14669 */       if (arrayOfString[b] == str) {
/* 14670 */         setORAData(b + 1, paramORAData);
/*       */         
/* 14672 */         bool = true;
/*       */       } 
/*       */     } 
/*       */     
/* 14676 */     if (!bool) {
/*       */       
/* 14678 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 14679 */       sQLException.fillInStackTrace();
/* 14680 */       throw sQLException;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setRAWAtName(String paramString, RAW paramRAW) throws SQLException {
/* 14700 */     if (paramString == null) {
/*       */       
/* 14702 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/* 14703 */       sQLException.fillInStackTrace();
/* 14704 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */ 
/*       */     
/* 14709 */     String str = paramString.intern();
/* 14710 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 14711 */     boolean bool = false;
/* 14712 */     int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 14714 */     for (byte b = 0; b < i; b++) {
/* 14715 */       if (arrayOfString[b] == str) {
/* 14716 */         setRAW(b + 1, paramRAW);
/*       */         
/* 14718 */         bool = true;
/*       */       } 
/*       */     } 
/*       */     
/* 14722 */     if (!bool) {
/*       */       
/* 14724 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 14725 */       sQLException.fillInStackTrace();
/* 14726 */       throw sQLException;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setREFAtName(String paramString, REF paramREF) throws SQLException {
/* 14746 */     if (paramString == null) {
/*       */       
/* 14748 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/* 14749 */       sQLException.fillInStackTrace();
/* 14750 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */ 
/*       */     
/* 14755 */     String str = paramString.intern();
/* 14756 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 14757 */     boolean bool = false;
/* 14758 */     int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 14760 */     for (byte b = 0; b < i; b++) {
/* 14761 */       if (arrayOfString[b] == str) {
/* 14762 */         setREF(b + 1, paramREF);
/*       */         
/* 14764 */         bool = true;
/*       */       } 
/*       */     } 
/*       */     
/* 14768 */     if (!bool) {
/*       */       
/* 14770 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 14771 */       sQLException.fillInStackTrace();
/* 14772 */       throw sQLException;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setRefTypeAtName(String paramString, REF paramREF) throws SQLException {
/* 14792 */     if (paramString == null) {
/*       */       
/* 14794 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/* 14795 */       sQLException.fillInStackTrace();
/* 14796 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */ 
/*       */     
/* 14801 */     String str = paramString.intern();
/* 14802 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 14803 */     boolean bool = false;
/* 14804 */     int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 14806 */     for (byte b = 0; b < i; b++) {
/* 14807 */       if (arrayOfString[b] == str) {
/* 14808 */         setRefType(b + 1, paramREF);
/*       */         
/* 14810 */         bool = true;
/*       */       } 
/*       */     } 
/*       */     
/* 14814 */     if (!bool) {
/*       */       
/* 14816 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 14817 */       sQLException.fillInStackTrace();
/* 14818 */       throw sQLException;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setROWIDAtName(String paramString, ROWID paramROWID) throws SQLException {
/* 14838 */     if (paramString == null) {
/*       */       
/* 14840 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/* 14841 */       sQLException.fillInStackTrace();
/* 14842 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */ 
/*       */     
/* 14847 */     String str = paramString.intern();
/* 14848 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 14849 */     boolean bool = false;
/* 14850 */     int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 14852 */     for (byte b = 0; b < i; b++) {
/* 14853 */       if (arrayOfString[b] == str) {
/* 14854 */         setROWID(b + 1, paramROWID);
/*       */         
/* 14856 */         bool = true;
/*       */       } 
/*       */     } 
/*       */     
/* 14860 */     if (!bool) {
/*       */       
/* 14862 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 14863 */       sQLException.fillInStackTrace();
/* 14864 */       throw sQLException;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setSTRUCTAtName(String paramString, STRUCT paramSTRUCT) throws SQLException {
/* 14884 */     if (paramString == null) {
/*       */       
/* 14886 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/* 14887 */       sQLException.fillInStackTrace();
/* 14888 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */ 
/*       */     
/* 14893 */     String str = paramString.intern();
/* 14894 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 14895 */     boolean bool = false;
/* 14896 */     int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 14898 */     for (byte b = 0; b < i; b++) {
/* 14899 */       if (arrayOfString[b] == str) {
/* 14900 */         setSTRUCT(b + 1, paramSTRUCT);
/*       */         
/* 14902 */         bool = true;
/*       */       } 
/*       */     } 
/*       */     
/* 14906 */     if (!bool) {
/*       */       
/* 14908 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 14909 */       sQLException.fillInStackTrace();
/* 14910 */       throw sQLException;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setTIMESTAMPLTZAtName(String paramString, TIMESTAMPLTZ paramTIMESTAMPLTZ) throws SQLException {
/* 14930 */     if (paramString == null) {
/*       */       
/* 14932 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/* 14933 */       sQLException.fillInStackTrace();
/* 14934 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */ 
/*       */     
/* 14939 */     String str = paramString.intern();
/* 14940 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 14941 */     boolean bool = false;
/* 14942 */     int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 14944 */     for (byte b = 0; b < i; b++) {
/* 14945 */       if (arrayOfString[b] == str) {
/* 14946 */         setTIMESTAMPLTZ(b + 1, paramTIMESTAMPLTZ);
/*       */         
/* 14948 */         bool = true;
/*       */       } 
/*       */     } 
/*       */     
/* 14952 */     if (!bool) {
/*       */       
/* 14954 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 14955 */       sQLException.fillInStackTrace();
/* 14956 */       throw sQLException;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setTIMESTAMPTZAtName(String paramString, TIMESTAMPTZ paramTIMESTAMPTZ) throws SQLException {
/* 14976 */     if (paramString == null) {
/*       */       
/* 14978 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/* 14979 */       sQLException.fillInStackTrace();
/* 14980 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */ 
/*       */     
/* 14985 */     String str = paramString.intern();
/* 14986 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 14987 */     boolean bool = false;
/* 14988 */     int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 14990 */     for (byte b = 0; b < i; b++) {
/* 14991 */       if (arrayOfString[b] == str) {
/* 14992 */         setTIMESTAMPTZ(b + 1, paramTIMESTAMPTZ);
/*       */         
/* 14994 */         bool = true;
/*       */       } 
/*       */     } 
/*       */     
/* 14998 */     if (!bool) {
/*       */       
/* 15000 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 15001 */       sQLException.fillInStackTrace();
/* 15002 */       throw sQLException;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setTIMESTAMPAtName(String paramString, TIMESTAMP paramTIMESTAMP) throws SQLException {
/* 15022 */     if (paramString == null) {
/*       */       
/* 15024 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/* 15025 */       sQLException.fillInStackTrace();
/* 15026 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */ 
/*       */     
/* 15031 */     String str = paramString.intern();
/* 15032 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 15033 */     boolean bool = false;
/* 15034 */     int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 15036 */     for (byte b = 0; b < i; b++) {
/* 15037 */       if (arrayOfString[b] == str) {
/* 15038 */         setTIMESTAMP(b + 1, paramTIMESTAMP);
/*       */         
/* 15040 */         bool = true;
/*       */       } 
/*       */     } 
/*       */     
/* 15044 */     if (!bool) {
/*       */       
/* 15046 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 15047 */       sQLException.fillInStackTrace();
/* 15048 */       throw sQLException;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setCustomDatumAtName(String paramString, CustomDatum paramCustomDatum) throws SQLException {
/* 15068 */     if (paramString == null) {
/*       */       
/* 15070 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/* 15071 */       sQLException.fillInStackTrace();
/* 15072 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */ 
/*       */     
/* 15077 */     String str = paramString.intern();
/* 15078 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 15079 */     boolean bool = false;
/* 15080 */     int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 15082 */     for (byte b = 0; b < i; b++) {
/* 15083 */       if (arrayOfString[b] == str) {
/* 15084 */         setCustomDatum(b + 1, paramCustomDatum);
/*       */         
/* 15086 */         bool = true;
/*       */       } 
/*       */     } 
/*       */     
/* 15090 */     if (!bool) {
/*       */       
/* 15092 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 15093 */       sQLException.fillInStackTrace();
/* 15094 */       throw sQLException;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setBlobAtName(String paramString, InputStream paramInputStream) throws SQLException {
/* 15116 */     if (paramString == null) {
/*       */       
/* 15118 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/* 15119 */       sQLException.fillInStackTrace();
/* 15120 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */ 
/*       */     
/* 15125 */     String str = paramString.intern();
/* 15126 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 15127 */     int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/* 15128 */     boolean bool = true;
/*       */     
/* 15130 */     for (byte b = 0; b < i; b++) {
/* 15131 */       if (arrayOfString[b] == str) {
/* 15132 */         if (bool) {
/* 15133 */           setBlob(b + 1, paramInputStream);
/*       */           
/* 15135 */           bool = false;
/*       */         }
/*       */         else {
/*       */           
/* 15139 */           SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 135);
/* 15140 */           sQLException.fillInStackTrace();
/* 15141 */           throw sQLException;
/*       */         } 
/*       */       }
/*       */     } 
/*       */     
/* 15146 */     if (bool) {
/*       */       
/* 15148 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 15149 */       sQLException.fillInStackTrace();
/* 15150 */       throw sQLException;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setBlobAtName(String paramString, InputStream paramInputStream, long paramLong) throws SQLException {
/* 15170 */     if (paramString == null) {
/*       */       
/* 15172 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/* 15173 */       sQLException.fillInStackTrace();
/* 15174 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */ 
/*       */     
/* 15179 */     String str = paramString.intern();
/* 15180 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 15181 */     int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/* 15182 */     boolean bool = true;
/*       */     
/* 15184 */     for (byte b = 0; b < i; b++) {
/* 15185 */       if (arrayOfString[b] == str) {
/* 15186 */         if (bool) {
/* 15187 */           setBlob(b + 1, paramInputStream, paramLong);
/*       */           
/* 15189 */           bool = false;
/*       */         }
/*       */         else {
/*       */           
/* 15193 */           SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 135);
/* 15194 */           sQLException.fillInStackTrace();
/* 15195 */           throw sQLException;
/*       */         } 
/*       */       }
/*       */     } 
/*       */     
/* 15200 */     if (bool) {
/*       */       
/* 15202 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 15203 */       sQLException.fillInStackTrace();
/* 15204 */       throw sQLException;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setClobAtName(String paramString, Reader paramReader) throws SQLException {
/* 15224 */     if (paramString == null) {
/*       */       
/* 15226 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/* 15227 */       sQLException.fillInStackTrace();
/* 15228 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */ 
/*       */     
/* 15233 */     String str = paramString.intern();
/* 15234 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 15235 */     int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/* 15236 */     boolean bool = true;
/*       */     
/* 15238 */     for (byte b = 0; b < i; b++) {
/* 15239 */       if (arrayOfString[b] == str) {
/* 15240 */         if (bool) {
/* 15241 */           setClob(b + 1, paramReader);
/*       */           
/* 15243 */           bool = false;
/*       */         }
/*       */         else {
/*       */           
/* 15247 */           SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 135);
/* 15248 */           sQLException.fillInStackTrace();
/* 15249 */           throw sQLException;
/*       */         } 
/*       */       }
/*       */     } 
/*       */     
/* 15254 */     if (bool) {
/*       */       
/* 15256 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 15257 */       sQLException.fillInStackTrace();
/* 15258 */       throw sQLException;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setClobAtName(String paramString, Reader paramReader, long paramLong) throws SQLException {
/* 15278 */     if (paramString == null) {
/*       */       
/* 15280 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/* 15281 */       sQLException.fillInStackTrace();
/* 15282 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */ 
/*       */     
/* 15287 */     String str = paramString.intern();
/* 15288 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 15289 */     int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/* 15290 */     boolean bool = true;
/*       */     
/* 15292 */     for (byte b = 0; b < i; b++) {
/* 15293 */       if (arrayOfString[b] == str) {
/* 15294 */         if (bool) {
/* 15295 */           setClob(b + 1, paramReader, paramLong);
/*       */           
/* 15297 */           bool = false;
/*       */         }
/*       */         else {
/*       */           
/* 15301 */           SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 135);
/* 15302 */           sQLException.fillInStackTrace();
/* 15303 */           throw sQLException;
/*       */         } 
/*       */       }
/*       */     } 
/*       */     
/* 15308 */     if (bool) {
/*       */       
/* 15310 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 15311 */       sQLException.fillInStackTrace();
/* 15312 */       throw sQLException;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setNClobAtName(String paramString, Reader paramReader) throws SQLException {
/* 15332 */     if (paramString == null) {
/*       */       
/* 15334 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/* 15335 */       sQLException.fillInStackTrace();
/* 15336 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */ 
/*       */     
/* 15341 */     String str = paramString.intern();
/* 15342 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 15343 */     int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/* 15344 */     boolean bool = true;
/*       */     
/* 15346 */     for (byte b = 0; b < i; b++) {
/* 15347 */       if (arrayOfString[b] == str) {
/* 15348 */         if (bool) {
/* 15349 */           setNClob(b + 1, paramReader);
/*       */           
/* 15351 */           bool = false;
/*       */         }
/*       */         else {
/*       */           
/* 15355 */           SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 135);
/* 15356 */           sQLException.fillInStackTrace();
/* 15357 */           throw sQLException;
/*       */         } 
/*       */       }
/*       */     } 
/*       */     
/* 15362 */     if (bool) {
/*       */       
/* 15364 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 15365 */       sQLException.fillInStackTrace();
/* 15366 */       throw sQLException;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setNClobAtName(String paramString, Reader paramReader, long paramLong) throws SQLException {
/* 15386 */     if (paramString == null) {
/*       */       
/* 15388 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/* 15389 */       sQLException.fillInStackTrace();
/* 15390 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */ 
/*       */     
/* 15395 */     String str = paramString.intern();
/* 15396 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 15397 */     int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/* 15398 */     boolean bool = true;
/*       */     
/* 15400 */     for (byte b = 0; b < i; b++) {
/* 15401 */       if (arrayOfString[b] == str) {
/* 15402 */         if (bool) {
/* 15403 */           setNClob(b + 1, paramReader, paramLong);
/*       */           
/* 15405 */           bool = false;
/*       */         }
/*       */         else {
/*       */           
/* 15409 */           SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 135);
/* 15410 */           sQLException.fillInStackTrace();
/* 15411 */           throw sQLException;
/*       */         } 
/*       */       }
/*       */     } 
/*       */     
/* 15416 */     if (bool) {
/*       */       
/* 15418 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 15419 */       sQLException.fillInStackTrace();
/* 15420 */       throw sQLException;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setAsciiStreamAtName(String paramString, InputStream paramInputStream) throws SQLException {
/* 15440 */     if (paramString == null) {
/*       */       
/* 15442 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/* 15443 */       sQLException.fillInStackTrace();
/* 15444 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */ 
/*       */     
/* 15449 */     String str = paramString.intern();
/* 15450 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 15451 */     int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/* 15452 */     boolean bool = true;
/*       */     
/* 15454 */     for (byte b = 0; b < i; b++) {
/* 15455 */       if (arrayOfString[b] == str) {
/* 15456 */         if (bool) {
/* 15457 */           setAsciiStream(b + 1, paramInputStream);
/*       */           
/* 15459 */           bool = false;
/*       */         }
/*       */         else {
/*       */           
/* 15463 */           SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 135);
/* 15464 */           sQLException.fillInStackTrace();
/* 15465 */           throw sQLException;
/*       */         } 
/*       */       }
/*       */     } 
/*       */     
/* 15470 */     if (bool) {
/*       */       
/* 15472 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 15473 */       sQLException.fillInStackTrace();
/* 15474 */       throw sQLException;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setAsciiStreamAtName(String paramString, InputStream paramInputStream, int paramInt) throws SQLException {
/* 15494 */     if (paramString == null) {
/*       */       
/* 15496 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/* 15497 */       sQLException.fillInStackTrace();
/* 15498 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */ 
/*       */     
/* 15503 */     String str = paramString.intern();
/* 15504 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 15505 */     int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/* 15506 */     boolean bool = true;
/*       */     
/* 15508 */     for (byte b = 0; b < i; b++) {
/* 15509 */       if (arrayOfString[b] == str) {
/* 15510 */         if (bool) {
/* 15511 */           setAsciiStream(b + 1, paramInputStream, paramInt);
/*       */           
/* 15513 */           bool = false;
/*       */         }
/*       */         else {
/*       */           
/* 15517 */           SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 135);
/* 15518 */           sQLException.fillInStackTrace();
/* 15519 */           throw sQLException;
/*       */         } 
/*       */       }
/*       */     } 
/*       */     
/* 15524 */     if (bool) {
/*       */       
/* 15526 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 15527 */       sQLException.fillInStackTrace();
/* 15528 */       throw sQLException;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setAsciiStreamAtName(String paramString, InputStream paramInputStream, long paramLong) throws SQLException {
/* 15548 */     if (paramString == null) {
/*       */       
/* 15550 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/* 15551 */       sQLException.fillInStackTrace();
/* 15552 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */ 
/*       */     
/* 15557 */     String str = paramString.intern();
/* 15558 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 15559 */     int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/* 15560 */     boolean bool = true;
/*       */     
/* 15562 */     for (byte b = 0; b < i; b++) {
/* 15563 */       if (arrayOfString[b] == str) {
/* 15564 */         if (bool) {
/* 15565 */           setAsciiStream(b + 1, paramInputStream, paramLong);
/*       */           
/* 15567 */           bool = false;
/*       */         }
/*       */         else {
/*       */           
/* 15571 */           SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 135);
/* 15572 */           sQLException.fillInStackTrace();
/* 15573 */           throw sQLException;
/*       */         } 
/*       */       }
/*       */     } 
/*       */     
/* 15578 */     if (bool) {
/*       */       
/* 15580 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 15581 */       sQLException.fillInStackTrace();
/* 15582 */       throw sQLException;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setBinaryStreamAtName(String paramString, InputStream paramInputStream) throws SQLException {
/* 15602 */     if (paramString == null) {
/*       */       
/* 15604 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/* 15605 */       sQLException.fillInStackTrace();
/* 15606 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */ 
/*       */     
/* 15611 */     String str = paramString.intern();
/* 15612 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 15613 */     int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/* 15614 */     boolean bool = true;
/*       */     
/* 15616 */     for (byte b = 0; b < i; b++) {
/* 15617 */       if (arrayOfString[b] == str) {
/* 15618 */         if (bool) {
/* 15619 */           setBinaryStream(b + 1, paramInputStream);
/*       */           
/* 15621 */           bool = false;
/*       */         }
/*       */         else {
/*       */           
/* 15625 */           SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 135);
/* 15626 */           sQLException.fillInStackTrace();
/* 15627 */           throw sQLException;
/*       */         } 
/*       */       }
/*       */     } 
/*       */     
/* 15632 */     if (bool) {
/*       */       
/* 15634 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 15635 */       sQLException.fillInStackTrace();
/* 15636 */       throw sQLException;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setBinaryStreamAtName(String paramString, InputStream paramInputStream, int paramInt) throws SQLException {
/* 15656 */     if (paramString == null) {
/*       */       
/* 15658 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/* 15659 */       sQLException.fillInStackTrace();
/* 15660 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */ 
/*       */     
/* 15665 */     String str = paramString.intern();
/* 15666 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 15667 */     int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/* 15668 */     boolean bool = true;
/*       */     
/* 15670 */     for (byte b = 0; b < i; b++) {
/* 15671 */       if (arrayOfString[b] == str) {
/* 15672 */         if (bool) {
/* 15673 */           setBinaryStream(b + 1, paramInputStream, paramInt);
/*       */           
/* 15675 */           bool = false;
/*       */         }
/*       */         else {
/*       */           
/* 15679 */           SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 135);
/* 15680 */           sQLException.fillInStackTrace();
/* 15681 */           throw sQLException;
/*       */         } 
/*       */       }
/*       */     } 
/*       */     
/* 15686 */     if (bool) {
/*       */       
/* 15688 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 15689 */       sQLException.fillInStackTrace();
/* 15690 */       throw sQLException;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setBinaryStreamAtName(String paramString, InputStream paramInputStream, long paramLong) throws SQLException {
/* 15710 */     if (paramString == null) {
/*       */       
/* 15712 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/* 15713 */       sQLException.fillInStackTrace();
/* 15714 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */ 
/*       */     
/* 15719 */     String str = paramString.intern();
/* 15720 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 15721 */     int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/* 15722 */     boolean bool = true;
/*       */     
/* 15724 */     for (byte b = 0; b < i; b++) {
/* 15725 */       if (arrayOfString[b] == str) {
/* 15726 */         if (bool) {
/* 15727 */           setBinaryStream(b + 1, paramInputStream, paramLong);
/*       */           
/* 15729 */           bool = false;
/*       */         }
/*       */         else {
/*       */           
/* 15733 */           SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 135);
/* 15734 */           sQLException.fillInStackTrace();
/* 15735 */           throw sQLException;
/*       */         } 
/*       */       }
/*       */     } 
/*       */     
/* 15740 */     if (bool) {
/*       */       
/* 15742 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 15743 */       sQLException.fillInStackTrace();
/* 15744 */       throw sQLException;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setCharacterStreamAtName(String paramString, Reader paramReader) throws SQLException {
/* 15764 */     if (paramString == null) {
/*       */       
/* 15766 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/* 15767 */       sQLException.fillInStackTrace();
/* 15768 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */ 
/*       */     
/* 15773 */     String str = paramString.intern();
/* 15774 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 15775 */     int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/* 15776 */     boolean bool = true;
/*       */     
/* 15778 */     for (byte b = 0; b < i; b++) {
/* 15779 */       if (arrayOfString[b] == str) {
/* 15780 */         if (bool) {
/* 15781 */           setCharacterStream(b + 1, paramReader);
/*       */           
/* 15783 */           bool = false;
/*       */         }
/*       */         else {
/*       */           
/* 15787 */           SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 135);
/* 15788 */           sQLException.fillInStackTrace();
/* 15789 */           throw sQLException;
/*       */         } 
/*       */       }
/*       */     } 
/*       */     
/* 15794 */     if (bool) {
/*       */       
/* 15796 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 15797 */       sQLException.fillInStackTrace();
/* 15798 */       throw sQLException;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setCharacterStreamAtName(String paramString, Reader paramReader, int paramInt) throws SQLException {
/* 15818 */     if (paramString == null) {
/*       */       
/* 15820 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/* 15821 */       sQLException.fillInStackTrace();
/* 15822 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */ 
/*       */     
/* 15827 */     String str = paramString.intern();
/* 15828 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 15829 */     int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/* 15830 */     boolean bool = true;
/*       */     
/* 15832 */     for (byte b = 0; b < i; b++) {
/* 15833 */       if (arrayOfString[b] == str) {
/* 15834 */         if (bool) {
/* 15835 */           setCharacterStream(b + 1, paramReader, paramInt);
/*       */           
/* 15837 */           bool = false;
/*       */         }
/*       */         else {
/*       */           
/* 15841 */           SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 135);
/* 15842 */           sQLException.fillInStackTrace();
/* 15843 */           throw sQLException;
/*       */         } 
/*       */       }
/*       */     } 
/*       */     
/* 15848 */     if (bool) {
/*       */       
/* 15850 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 15851 */       sQLException.fillInStackTrace();
/* 15852 */       throw sQLException;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setCharacterStreamAtName(String paramString, Reader paramReader, long paramLong) throws SQLException {
/* 15872 */     if (paramString == null) {
/*       */       
/* 15874 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/* 15875 */       sQLException.fillInStackTrace();
/* 15876 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */ 
/*       */     
/* 15881 */     String str = paramString.intern();
/* 15882 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 15883 */     int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/* 15884 */     boolean bool = true;
/*       */     
/* 15886 */     for (byte b = 0; b < i; b++) {
/* 15887 */       if (arrayOfString[b] == str) {
/* 15888 */         if (bool) {
/* 15889 */           setCharacterStream(b + 1, paramReader, paramLong);
/*       */           
/* 15891 */           bool = false;
/*       */         }
/*       */         else {
/*       */           
/* 15895 */           SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 135);
/* 15896 */           sQLException.fillInStackTrace();
/* 15897 */           throw sQLException;
/*       */         } 
/*       */       }
/*       */     } 
/*       */     
/* 15902 */     if (bool) {
/*       */       
/* 15904 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 15905 */       sQLException.fillInStackTrace();
/* 15906 */       throw sQLException;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setNCharacterStreamAtName(String paramString, Reader paramReader) throws SQLException {
/* 15926 */     if (paramString == null) {
/*       */       
/* 15928 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/* 15929 */       sQLException.fillInStackTrace();
/* 15930 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */ 
/*       */     
/* 15935 */     String str = paramString.intern();
/* 15936 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 15937 */     int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/* 15938 */     boolean bool = true;
/*       */     
/* 15940 */     for (byte b = 0; b < i; b++) {
/* 15941 */       if (arrayOfString[b] == str) {
/* 15942 */         if (bool) {
/* 15943 */           setNCharacterStream(b + 1, paramReader);
/*       */           
/* 15945 */           bool = false;
/*       */         }
/*       */         else {
/*       */           
/* 15949 */           SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 135);
/* 15950 */           sQLException.fillInStackTrace();
/* 15951 */           throw sQLException;
/*       */         } 
/*       */       }
/*       */     } 
/*       */     
/* 15956 */     if (bool) {
/*       */       
/* 15958 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 15959 */       sQLException.fillInStackTrace();
/* 15960 */       throw sQLException;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setNCharacterStreamAtName(String paramString, Reader paramReader, long paramLong) throws SQLException {
/* 15980 */     if (paramString == null) {
/*       */       
/* 15982 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/* 15983 */       sQLException.fillInStackTrace();
/* 15984 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */ 
/*       */     
/* 15989 */     String str = paramString.intern();
/* 15990 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 15991 */     int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/* 15992 */     boolean bool = true;
/*       */     
/* 15994 */     for (byte b = 0; b < i; b++) {
/* 15995 */       if (arrayOfString[b] == str) {
/* 15996 */         if (bool) {
/* 15997 */           setNCharacterStream(b + 1, paramReader, paramLong);
/*       */           
/* 15999 */           bool = false;
/*       */         }
/*       */         else {
/*       */           
/* 16003 */           SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 135);
/* 16004 */           sQLException.fillInStackTrace();
/* 16005 */           throw sQLException;
/*       */         } 
/*       */       }
/*       */     } 
/*       */     
/* 16010 */     if (bool) {
/*       */       
/* 16012 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 16013 */       sQLException.fillInStackTrace();
/* 16014 */       throw sQLException;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setUnicodeStreamAtName(String paramString, InputStream paramInputStream, int paramInt) throws SQLException {
/* 16034 */     if (paramString == null) {
/*       */       
/* 16036 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/* 16037 */       sQLException.fillInStackTrace();
/* 16038 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */ 
/*       */     
/* 16043 */     String str = paramString.intern();
/* 16044 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 16045 */     int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/* 16046 */     boolean bool = true;
/*       */     
/* 16048 */     for (byte b = 0; b < i; b++) {
/* 16049 */       if (arrayOfString[b] == str) {
/* 16050 */         if (bool) {
/* 16051 */           setUnicodeStream(b + 1, paramInputStream, paramInt);
/*       */           
/* 16053 */           bool = false;
/*       */         }
/*       */         else {
/*       */           
/* 16057 */           SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 135);
/* 16058 */           sQLException.fillInStackTrace();
/* 16059 */           throw sQLException;
/*       */         } 
/*       */       }
/*       */     } 
/*       */     
/* 16064 */     if (bool) {
/*       */       
/* 16066 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 16067 */       sQLException.fillInStackTrace();
/* 16068 */       throw sQLException;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/* 16078 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*       */   public static final String BUILD_DATE = "Thu_Apr_04_15:09:24_PDT_2013";
/*       */   public static final boolean TRACE = false;
/*       */ }


/* Location:              C:\Users\olatu\OneDrive\Documents\Calypso\syncbase\sync_base.jar!\BOOT-INF\classes\ojdbc.jar!\oracle\jdbc\driver\OraclePreparedStatement.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */