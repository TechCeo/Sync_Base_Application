/*     */ package oracle.jdbc.driver;
/*     */ 
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.InputStream;
/*     */ import java.io.Reader;
/*     */ import java.io.StringReader;
/*     */ import java.math.BigDecimal;
/*     */ import java.net.MalformedURLException;
/*     */ import java.net.URL;
/*     */ import java.sql.Date;
/*     */ import java.sql.SQLException;
/*     */ import java.sql.Time;
/*     */ import java.sql.Timestamp;
/*     */ import java.text.ParseException;
/*     */ import java.text.SimpleDateFormat;
/*     */ import java.util.Calendar;
/*     */ import java.util.Date;
/*     */ import java.util.Map;
/*     */ import oracle.jdbc.internal.OracleConnection;
/*     */ import oracle.sql.CHAR;
/*     */ import oracle.sql.CharacterSet;
/*     */ import oracle.sql.Datum;
/*     */ import oracle.sql.ROWID;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ abstract class CharCommonAccessor
/*     */   extends Accessor
/*     */ {
/*     */   CharCommonAccessor(OracleStatement paramOracleStatement, int paramInt, short paramShort, boolean paramBoolean) {
/*  43 */     super((paramShort == 2) ? Representation.NVARCHAR : Representation.VARCHAR, paramOracleStatement, paramInt, paramBoolean);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void init(OracleStatement paramOracleStatement, int paramInt1, int paramInt2, int paramInt3, short paramShort, int paramInt4, boolean paramBoolean, int paramInt5) throws SQLException {
/*  54 */     if (paramBoolean) {
/*     */       
/*  56 */       if (paramInt1 != 23) {
/*  57 */         paramInt1 = 1;
/*     */       }
/*  59 */       if (paramOracleStatement.maxFieldSize > 0 && (paramInt3 == -1 || paramInt3 < paramOracleStatement.maxFieldSize)) {
/*  60 */         paramInt3 = paramOracleStatement.maxFieldSize;
/*     */       }
/*     */     } 
/*  63 */     init(paramOracleStatement, paramInt1, paramInt2, paramShort, paramBoolean);
/*     */ 
/*     */     
/*  66 */     if (paramBoolean && paramOracleStatement.connection.defaultnchar) {
/*  67 */       this.formOfUse = 2;
/*     */     }
/*  69 */     initForDataAccess(paramInt4, paramInt3, (String)null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void init(OracleStatement paramOracleStatement, int paramInt1, int paramInt2, int paramInt3, boolean paramBoolean, int paramInt4, int paramInt5, int paramInt6, int paramInt7, int paramInt8, short paramShort, int paramInt9) throws SQLException {
/*  78 */     init(paramOracleStatement, paramInt1, paramInt2, paramShort, false);
/*  79 */     initForDescribe(paramInt1, paramInt3, paramBoolean, paramInt4, paramInt5, paramInt6, paramInt7, paramInt8, paramShort, null);
/*     */ 
/*     */     
/*  82 */     int i = paramOracleStatement.maxFieldSize;
/*     */     
/*  84 */     if (i != 0 && i <= paramInt3) {
/*  85 */       paramInt3 = i;
/*     */     }
/*  87 */     initForDataAccess(0, paramInt3, (String)null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void initForDataAccess(int paramInt1, int paramInt2, String paramString) throws SQLException {
/*  95 */     if (paramInt1 != 0) {
/*  96 */       this.externalType = paramInt1;
/*     */     }
/*  98 */     this.charLength = this.isNullByDescribe ? 0 : ((paramInt2 >= 0 && (paramInt2 < this.representationMaxLength || this.statement.isFetchStreams)) ? (paramInt2 + 1) : (this.representationMaxLength + 1));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   int getInt(int paramInt) throws SQLException {
/* 110 */     if (isNull(paramInt)) return 0;
/*     */     
/* 112 */     String str = getString(paramInt);
/*     */     try {
/* 114 */       return Integer.parseInt(str);
/*     */     }
/* 116 */     catch (NumberFormatException numberFormatException) {
/*     */       try {
/* 118 */         return Double.valueOf(str).intValue();
/*     */       }
/* 120 */       catch (NumberFormatException numberFormatException1) {
/*     */         
/* 122 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 59);
/* 123 */         sQLException.fillInStackTrace();
/* 124 */         throw sQLException;
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean getBoolean(int paramInt) throws SQLException {
/* 161 */     String str = getString(paramInt);
/*     */     
/* 163 */     if (str == null || str.trim().equals("0") || str.trim().compareToIgnoreCase("f") == 0 || str.trim().compareToIgnoreCase("false") == 0 || str.trim().compareToIgnoreCase("n") == 0 || str.trim().compareToIgnoreCase("no") == 0)
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 170 */       return false;
/*     */     }
/* 172 */     if (str.trim().equals("1") || str.trim().compareToIgnoreCase("t") == 0 || str.trim().compareToIgnoreCase("true") == 0 || str.trim().compareToIgnoreCase("y") == 0 || str.trim().compareToIgnoreCase("yes") == 0)
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 178 */       return true;
/*     */     }
/*     */ 
/*     */     
/* 182 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 59);
/* 183 */     sQLException.fillInStackTrace();
/* 184 */     throw sQLException;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   short getShort(int paramInt) throws SQLException {
/* 193 */     if (isNull(paramInt)) return 0;
/*     */     
/* 195 */     String str = getString(paramInt);
/*     */     try {
/* 197 */       return Short.valueOf(str).shortValue();
/*     */     }
/* 199 */     catch (NumberFormatException numberFormatException) {
/*     */       try {
/* 201 */         return Double.valueOf(str).shortValue();
/*     */       }
/* 203 */       catch (NumberFormatException numberFormatException1) {
/*     */         
/* 205 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 59);
/* 206 */         sQLException.fillInStackTrace();
/* 207 */         throw sQLException;
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   byte getByte(int paramInt) throws SQLException {
/* 219 */     if (isNull(paramInt)) return 0;
/*     */     
/* 221 */     String str = getString(paramInt);
/*     */     try {
/* 223 */       return Byte.valueOf(str).byteValue();
/*     */     }
/* 225 */     catch (NumberFormatException numberFormatException) {
/*     */       try {
/* 227 */         return Double.valueOf(str).byteValue();
/*     */       }
/* 229 */       catch (NumberFormatException numberFormatException1) {
/*     */         
/* 231 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 59);
/* 232 */         sQLException.fillInStackTrace();
/* 233 */         throw sQLException;
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   long getLong(int paramInt) throws SQLException {
/* 245 */     if (isNull(paramInt)) return 0L;
/*     */     
/* 247 */     String str = getString(paramInt);
/*     */     try {
/* 249 */       return Long.valueOf(str).longValue();
/*     */     }
/* 251 */     catch (NumberFormatException numberFormatException) {
/*     */       try {
/* 253 */         return Double.valueOf(str).longValue();
/*     */       }
/* 255 */       catch (NumberFormatException numberFormatException1) {
/*     */         
/* 257 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 59);
/* 258 */         sQLException.fillInStackTrace();
/* 259 */         throw sQLException;
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   float getFloat(int paramInt) throws SQLException {
/* 271 */     if (isNull(paramInt)) return 0.0F;
/*     */     
/* 273 */     String str = getString(paramInt);
/*     */     try {
/* 275 */       return Float.valueOf(str).floatValue();
/*     */     }
/* 277 */     catch (NumberFormatException numberFormatException) {
/*     */       try {
/* 279 */         return Double.valueOf(str).floatValue();
/*     */       }
/* 281 */       catch (NumberFormatException numberFormatException1) {
/*     */         
/* 283 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 59);
/* 284 */         sQLException.fillInStackTrace();
/* 285 */         throw sQLException;
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   double getDouble(int paramInt) throws SQLException {
/* 297 */     if (isNull(paramInt)) return 0.0D;
/*     */     
/*     */     try {
/* 300 */       return Double.valueOf(getString(paramInt)).doubleValue();
/*     */     }
/* 302 */     catch (NumberFormatException numberFormatException) {
/*     */       
/* 304 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 59);
/* 305 */       sQLException.fillInStackTrace();
/* 306 */       throw sQLException;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   BigDecimal getBigDecimal(int paramInt) throws SQLException {
/* 317 */     if (isNull(paramInt)) return null;
/*     */     
/*     */     try {
/* 320 */       return new BigDecimal(getString(paramInt).trim());
/*     */     }
/* 322 */     catch (NumberFormatException numberFormatException) {
/*     */       
/* 324 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 59);
/* 325 */       sQLException.fillInStackTrace();
/* 326 */       throw sQLException;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   BigDecimal getBigDecimal(int paramInt1, int paramInt2) throws SQLException {
/* 337 */     BigDecimal bigDecimal = getBigDecimal(paramInt1);
/*     */     
/* 339 */     if (bigDecimal != null) {
/* 340 */       bigDecimal.setScale(paramInt2, 6);
/*     */     }
/* 342 */     return bigDecimal;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   String getString(int paramInt) throws SQLException {
/* 350 */     if (isNull(paramInt)) return null;
/*     */     
/* 352 */     String str = this.rowData.getString(getOffset(paramInt), getLength(paramInt), this.statement.connection.conversion.getCharacterSet(this.formOfUse));
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 357 */     if (str.length() > this.charLength - 1)
/* 358 */       str = str.substring(0, this.charLength - 1); 
/* 359 */     return str;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Date getDate(int paramInt) throws SQLException {
/* 368 */     if (isNull(paramInt)) return null;
/*     */     
/* 370 */     Date date = null; try {
/* 371 */       date = Date.valueOf(getString(paramInt).trim());
/* 372 */     } catch (IllegalArgumentException illegalArgumentException) {
/*     */ 
/*     */       
/* 375 */       SQLException sQLException = DatabaseError.createSqlException((OracleConnection)null, 132, (Object)null, illegalArgumentException);
/* 376 */       sQLException.fillInStackTrace();
/* 377 */       throw sQLException;
/*     */     } 
/*     */ 
/*     */     
/* 381 */     return date;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Time getTime(int paramInt) throws SQLException {
/* 390 */     if (isNull(paramInt)) return null;
/*     */     
/* 392 */     Time time = null; try {
/* 393 */       time = Time.valueOf(getString(paramInt).trim());
/* 394 */     } catch (IllegalArgumentException illegalArgumentException) {
/*     */ 
/*     */       
/* 397 */       SQLException sQLException = DatabaseError.createSqlException((OracleConnection)null, 132, (Object)null, illegalArgumentException);
/* 398 */       sQLException.fillInStackTrace();
/* 399 */       throw sQLException;
/*     */     } 
/*     */ 
/*     */     
/* 403 */     return time;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Timestamp getTimestamp(int paramInt) throws SQLException {
/* 412 */     if (isNull(paramInt)) return null;
/*     */     
/* 414 */     Timestamp timestamp = null; try {
/* 415 */       timestamp = Timestamp.valueOf(getString(paramInt).trim());
/* 416 */     } catch (IllegalArgumentException illegalArgumentException) {
/*     */ 
/*     */       
/* 419 */       SQLException sQLException = DatabaseError.createSqlException((OracleConnection)null, 132, (Object)null, illegalArgumentException);
/* 420 */       sQLException.fillInStackTrace();
/* 421 */       throw sQLException;
/*     */     } 
/*     */ 
/*     */     
/* 425 */     return timestamp;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 433 */   protected static final String[] DATE_FORMATS = new String[] { "yyyy-MM-dd HH:mm:ss z", "EEE MMM dd HH:mm:ss z yyyy", "yyyy-MM-dd HH:mm:ss", "yyyy-MM-dd", "HH:mm:ss z", "HH:mm:ss" };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Date getJavaUtilDate(int paramInt) throws SQLException {
/* 445 */     if (isNull(paramInt)) return null;
/*     */     
/* 447 */     Date date = null; String[] arrayOfString; int i; byte b;
/* 448 */     for (arrayOfString = DATE_FORMATS, i = arrayOfString.length, b = 0; b < i; ) { String str = arrayOfString[b];
/* 449 */       SimpleDateFormat simpleDateFormat = new SimpleDateFormat(str);
/*     */       try {
/* 451 */         date = simpleDateFormat.parse(getString(paramInt).trim());
/*     */       }
/* 453 */       catch (ParseException parseException) {}
/*     */ 
/*     */ 
/*     */       
/* 457 */       return date; }
/*     */ 
/*     */     
/* 460 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 132);
/* 461 */     sQLException.fillInStackTrace();
/* 462 */     throw sQLException;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Calendar getCalendar(int paramInt) throws SQLException {
/* 472 */     if (isNull(paramInt)) return null;
/*     */     
/* 474 */     Calendar calendar = (Calendar)this.statement.getDefaultCalendar().clone();
/* 475 */     calendar.setTime(getJavaUtilDate(paramInt));
/* 476 */     return calendar;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   InputStream getAsciiStream(int paramInt) throws SQLException {
/* 493 */     if (isNull(paramInt)) return null;
/*     */ 
/*     */ 
/*     */     
/* 497 */     DBConversion dBConversion = this.statement.connection.conversion;
/* 498 */     int[] arrayOfInt = new int[1];
/* 499 */     char[] arrayOfChar = this.rowData.getChars(getOffset(paramInt), getLength(paramInt), dBConversion.getCharacterSet(this.formOfUse), arrayOfInt);
/*     */ 
/*     */ 
/*     */     
/* 503 */     return dBConversion.CharsToStream(arrayOfChar, 0, arrayOfInt[0], 10);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   InputStream getUnicodeStream(int paramInt) throws SQLException {
/* 521 */     if (isNull(paramInt)) return null;
/*     */ 
/*     */ 
/*     */     
/* 525 */     DBConversion dBConversion = this.statement.connection.conversion;
/* 526 */     int[] arrayOfInt = new int[1];
/* 527 */     char[] arrayOfChar = this.rowData.getChars(getOffset(paramInt), getLength(paramInt), dBConversion.getCharacterSet(this.formOfUse), arrayOfInt);
/*     */ 
/*     */ 
/*     */     
/* 531 */     return dBConversion.CharsToStream(arrayOfChar, 0, arrayOfInt[0] << 1, 11);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Reader getCharacterStream(int paramInt) throws SQLException {
/* 550 */     if (isNull(paramInt)) return null; 
/* 551 */     return new StringReader(getString(paramInt));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   InputStream getBinaryStream(int paramInt) throws SQLException {
/* 565 */     if (isNull(paramInt)) return null; 
/* 566 */     return new ByteArrayInputStream(getBytes(paramInt));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Object getObject(int paramInt) throws SQLException {
/* 580 */     return getString(paramInt);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Object getObject(int paramInt, Map paramMap) throws SQLException {
/* 595 */     return getString(paramInt);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Datum getOracleObject(int paramInt) throws SQLException {
/* 609 */     return (Datum)getCHAR(paramInt);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   CHAR getCHAR(int paramInt) throws SQLException {
/* 623 */     byte[] arrayOfByte = getBytes(paramInt);
/*     */ 
/*     */     
/* 626 */     if (arrayOfByte == null || arrayOfByte.length == 0)
/*     */     {
/* 628 */       return null;
/*     */     }
/*     */     
/* 631 */     CharacterSet characterSet = this.statement.connection.conversion.getCharacterSet(this.formOfUse);
/* 632 */     return new CHAR(arrayOfByte, characterSet);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   URL getURL(int paramInt) throws SQLException {
/* 646 */     if (isNull(paramInt)) return null;
/*     */ 
/*     */     
/*     */     try {
/* 650 */       return new URL(getString(paramInt));
/*     */     }
/* 652 */     catch (MalformedURLException malformedURLException) {
/*     */ 
/*     */       
/* 655 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 136);
/* 656 */       sQLException.fillInStackTrace();
/* 657 */       throw sQLException;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   ROWID getROWID(int paramInt) throws SQLException {
/* 668 */     if (isNull(paramInt)) return null;
/*     */     
/* 670 */     byte[] arrayOfByte = getBytesInternal(paramInt);
/* 671 */     ROWID rOWID = null;
/* 672 */     if (arrayOfByte != null) {
/* 673 */       rOWID = new ROWID(arrayOfByte);
/*     */     }
/* 675 */     return rOWID;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   byte[] getBytesFromHexChars(int paramInt) throws SQLException {
/* 683 */     if (isNull(paramInt)) return null;
/*     */     
/* 685 */     byte[] arrayOfByte = this.rowData.getBytesFromHex(getOffset(paramInt), getLength(paramInt), this.statement.connection.conversion.getCharacterSet(this.formOfUse));
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 690 */     if (arrayOfByte.length > this.charLength - 1) {
/* 691 */       byte[] arrayOfByte1 = new byte[this.charLength - 1];
/* 692 */       System.arraycopy(arrayOfByte, 0, arrayOfByte1, 0, arrayOfByte1.length);
/* 693 */       arrayOfByte = arrayOfByte1;
/*     */     } 
/* 695 */     return arrayOfByte;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 701 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*     */   public static final String BUILD_DATE = "Thu_Apr_04_15:09:24_PDT_2013";
/*     */   public static final boolean TRACE = false;
/*     */ }


/* Location:              C:\Users\olatu\OneDrive\Documents\Calypso\syncbase\sync_base.jar!\BOOT-INF\classes\ojdbc.jar!\oracle\jdbc\driver\CharCommonAccessor.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */