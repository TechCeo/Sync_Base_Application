/*    */ package oracle.jdbc.driver;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.sql.SQLException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class T4CTTIosessrls
/*    */   extends T4CTTIfun
/*    */ {
/*    */   String sessrlstag;
/*    */   long sessrlsmode;
/*    */   static final int SESSRLS_DROPSESS = 1;
/*    */   static final int SESSRLS_DEAUTHENTICATE = 2;
/*    */   static final int SESSRLS_RETAG = 4;
/*    */   
/*    */   T4CTTIosessrls(T4CConnection paramT4CConnection) {
/* 44 */     super(paramT4CConnection, (byte)26);
/*    */     
/* 46 */     setFunCode((short)163);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   void marshal() throws IOException {
/*    */     try {
/* 56 */       byte[] arrayOfByte = null;
/* 57 */       this.sessrlsmode = 0L;
/*    */       
/* 59 */       if (this.connection.drcpTagName != null) {
/*    */         
/* 61 */         arrayOfByte = this.meg.conv.StringToCharBytes(this.connection.drcpTagName);
/* 62 */         this.meg.marshalPTR();
/* 63 */         this.meg.marshalSWORD(arrayOfByte.length);
/* 64 */         this.sessrlsmode |= 0x4L;
/*    */       } else {
/*    */         
/* 67 */         this.meg.marshalSWORD(0);
/* 68 */         this.meg.marshalNULLPTR();
/*    */       } 
/*    */       
/* 71 */       this.meg.marshalUB4(this.sessrlsmode);
/* 72 */       if (arrayOfByte != null)
/* 73 */         this.meg.marshalCHR(arrayOfByte); 
/* 74 */     } catch (SQLException sQLException) {}
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   void receive() throws SQLException, IOException {
/* 83 */     int i = this.meg.unmarshalSWORD();
/* 84 */     if (i > 0) {
/*    */       
/* 86 */       byte[] arrayOfByte = this.meg.unmarshalCHR(i);
/* 87 */       this.sessrlstag = new String(arrayOfByte);
/*    */     } 
/* 89 */     this.sessrlsmode = this.meg.unmarshalUB4();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 99 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*    */   public static final String BUILD_DATE = "Thu_Apr_04_15:09:24_PDT_2013";
/*    */   public static final boolean TRACE = false;
/*    */ }


/* Location:              C:\Users\olatu\OneDrive\Documents\Calypso\syncbase\sync_base.jar!\BOOT-INF\classes\ojdbc.jar!\oracle\jdbc\driver\T4CTTIosessrls.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */