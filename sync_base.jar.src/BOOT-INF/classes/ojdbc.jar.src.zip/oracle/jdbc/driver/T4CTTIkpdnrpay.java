/*     */ package oracle.jdbc.driver;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.sql.SQLException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class T4CTTIkpdnrpay
/*     */ {
/*     */   private int payloadType;
/*     */   private int payloadFlag;
/*     */   private int chunkNumber;
/*  46 */   private byte[] rawPayload = null;
/*     */ 
/*     */   
/*  49 */   T4CConnection connection = null;
/*     */   
/*     */   T4CMAREngine mar;
/*     */ 
/*     */   
/*     */   T4CTTIkpdnrpay(T4CConnection paramT4CConnection) {
/*  55 */     this.mar = paramT4CConnection.mare;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void receive() throws SQLException, IOException {
/*  67 */     this.payloadType = (int)this.mar.unmarshalUB4();
/*     */ 
/*     */     
/*  70 */     this.payloadFlag = (int)this.mar.unmarshalUB4();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  79 */     this.chunkNumber = (int)this.mar.unmarshalUB4();
/*     */ 
/*     */     
/*  82 */     int i = this.mar.unmarshalSWORD();
/*  83 */     if (i > 0) {
/*     */       
/*  85 */       this.rawPayload = new byte[i];
/*  86 */       int[] arrayOfInt = new int[1];
/*     */ 
/*     */       
/*  89 */       this.mar.unmarshalCLR(this.rawPayload, 0, arrayOfInt, this.rawPayload.length);
/*  90 */       i = arrayOfInt[0];
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/*  95 */     int j = this.mar.unmarshalSWORD();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] getRawPayload() {
/* 102 */     return this.rawPayload;
/*     */   }
/*     */ 
/*     */   
/* 106 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*     */   public static final String BUILD_DATE = "Thu_Apr_04_15:09:24_PDT_2013";
/*     */   public static final boolean TRACE = false;
/*     */ }


/* Location:              C:\Users\olatu\OneDrive\Documents\Calypso\syncbase\sync_base.jar!\BOOT-INF\classes\ojdbc.jar!\oracle\jdbc\driver\T4CTTIkpdnrpay.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */