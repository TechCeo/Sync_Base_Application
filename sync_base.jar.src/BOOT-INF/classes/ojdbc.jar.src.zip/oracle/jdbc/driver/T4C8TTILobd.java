/*     */ package oracle.jdbc.driver;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.net.SocketTimeoutException;
/*     */ import java.sql.SQLException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class T4C8TTILobd
/*     */   extends T4CTTIMsg
/*     */ {
/*     */   static final int LOBD_STATE0 = 0;
/*     */   static final int LOBD_STATE1 = 1;
/*     */   static final int LOBD_STATE2 = 2;
/*     */   static final int LOBD_STATE3 = 3;
/*     */   static final int LOBD_STATE_EXIT = 4;
/*     */   static final short TTCG_LNG = 254;
/*     */   static final short LOBDATALENGTH = 252;
/* 129 */   static byte[] ucs2Char = new byte[2];
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   T4C8TTILobd(T4CConnection paramT4CConnection) {
/* 142 */     super(paramT4CConnection, (byte)14);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void marshalLobData(byte[] paramArrayOfbyte, long paramLong1, long paramLong2, boolean paramBoolean) throws IOException {
/* 160 */     long l = paramLong2;
/*     */ 
/*     */     
/* 163 */     marshalTTCcode();
/* 164 */     if (paramBoolean) {
/*     */       
/* 166 */       this.meg.writeZeroCopyIO(paramArrayOfbyte, (int)paramLong1, (int)paramLong2);
/*     */     }
/*     */     else {
/*     */       
/* 170 */       this.meg.marshalCLR(paramArrayOfbyte, (int)paramLong1, (int)paramLong2);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void marshalClobUB2_For9iDB(byte[] paramArrayOfbyte, long paramLong1, long paramLong2) throws IOException {
/* 183 */     long l1 = paramLong2;
/* 184 */     boolean bool = false;
/*     */     
/* 186 */     marshalTTCcode();
/*     */ 
/*     */     
/* 189 */     if (l1 > 84L) {
/*     */       
/* 191 */       bool = true;
/*     */       
/* 193 */       this.meg.marshalUB1((short)254);
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 199 */     long l2 = 0L;
/*     */     
/* 201 */     for (; l1 > 84L; l2++, l1 -= 84L) {
/*     */ 
/*     */ 
/*     */       
/* 205 */       this.meg.marshalUB1((short)252);
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 210 */       for (byte b = 0; b < 84; b++) {
/*     */ 
/*     */ 
/*     */         
/* 214 */         this.meg.marshalUB1((short)2);
/*     */ 
/*     */         
/* 217 */         this.meg.marshalB1Array(paramArrayOfbyte, (int)(paramLong1 + l2 * 168L + (b * 2)), 2);
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 223 */     if (l1 > 0L) {
/*     */ 
/*     */ 
/*     */       
/* 227 */       long l = l1 * 3L;
/*     */       
/* 229 */       this.meg.marshalUB1((short)(int)l);
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 234 */       for (byte b = 0; b < l1; b++) {
/*     */ 
/*     */ 
/*     */         
/* 238 */         this.meg.marshalUB1((short)2);
/*     */ 
/*     */         
/* 241 */         this.meg.marshalB1Array(paramArrayOfbyte, (int)(paramLong1 + l2 * 168L + (b * 2)), 2);
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 248 */     if (bool == true) {
/* 249 */       this.meg.marshalUB1((short)0);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   long unmarshalLobData(byte[] paramArrayOfbyte, int paramInt, boolean paramBoolean) throws SQLException, IOException {
/* 270 */     int i = 0;
/* 271 */     if (paramBoolean) {
/*     */       
/* 273 */       int j = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 278 */       int[] arrayOfInt = new int[1];
/*     */ 
/*     */       
/* 281 */       boolean bool = false;
/* 282 */       while (!bool) {
/*     */         
/*     */         try {
/* 285 */           bool = this.meg.readZeroCopyIO(paramArrayOfbyte, paramInt + j, arrayOfInt);
/*     */ 
/*     */ 
/*     */         
/*     */         }
/* 290 */         catch (SocketTimeoutException socketTimeoutException) {
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 295 */           this.connection.doAsynchronousClose();
/*     */ 
/*     */           
/* 298 */           throw socketTimeoutException;
/*     */         } 
/*     */         
/* 301 */         j += arrayOfInt[0];
/*     */       } 
/* 303 */       i = j;
/*     */     
/*     */     }
/*     */     else {
/*     */       
/* 308 */       int j = paramInt;
/* 309 */       boolean bool = false;
/*     */       
/* 311 */       int[] arrayOfInt = new int[1];
/* 312 */       this.meg.unmarshalCLR(paramArrayOfbyte, j, arrayOfInt);
/*     */       
/* 314 */       i = arrayOfInt[0];
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 320 */     return i;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   long unmarshalClobUB2_For9iDB(byte[] paramArrayOfbyte, int paramInt) throws SQLException, IOException {
/* 354 */     long l1 = 0L;
/* 355 */     long l2 = paramInt;
/* 356 */     short s = 0;
/* 357 */     int i = 0;
/* 358 */     int j = 0;
/*     */ 
/*     */     
/* 361 */     byte b = 0;
/*     */ 
/*     */     
/* 364 */     while (b != 4) {
/*     */       
/* 366 */       switch (b) {
/*     */ 
/*     */ 
/*     */         
/*     */         case false:
/* 371 */           s = this.meg.unmarshalUB1();
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 376 */           if (s == 254) {
/* 377 */             b = 2;
/*     */ 
/*     */             
/*     */             continue;
/*     */           } 
/*     */           
/* 383 */           b = 1;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         case true:
/* 393 */           for (i = 0; i < s; i += j, l2 += 2L, l1 += 2L)
/*     */           {
/* 395 */             j = this.meg.unmarshalUCS2(paramArrayOfbyte, l2);
/*     */           }
/*     */           
/* 398 */           b = 4;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         case true:
/* 409 */           s = this.meg.unmarshalUB1();
/*     */ 
/*     */           
/* 412 */           if (s > 0) {
/* 413 */             b = 3;
/*     */             
/*     */             continue;
/*     */           } 
/*     */           
/* 418 */           b = 4;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         case true:
/* 430 */           for (i = 0; i < s; i += j, l2 += 2L, l1 += 2L)
/*     */           {
/* 432 */             j = this.meg.unmarshalUCS2(paramArrayOfbyte, l2);
/*     */           }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 439 */           b = 2;
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     } 
/* 452 */     return l1;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/* 457 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*     */   public static final String BUILD_DATE = "Thu_Apr_04_15:09:24_PDT_2013";
/*     */   public static final boolean TRACE = false;
/*     */ }


/* Location:              C:\Users\olatu\OneDrive\Documents\Calypso\syncbase\sync_base.jar!\BOOT-INF\classes\ojdbc.jar!\oracle\jdbc\driver\T4C8TTILobd.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */