/*     */ package oracle.jdbc.driver;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.sql.SQLException;
/*     */ import oracle.jdbc.internal.KeywordValue;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class T4CTTIkvarr
/*     */   extends T4CTTIMsg
/*     */ {
/* 104 */   KeywordValue[] kpdkvarrptr = null;
/*     */   long kpdkvarrflg;
/*     */   
/*     */   T4CTTIkvarr(T4CConnection paramT4CConnection) {
/* 108 */     super(paramT4CConnection, (byte)0);
/*     */   }
/*     */   
/*     */   void unmarshal() throws SQLException, IOException {
/* 112 */     int i = (int)this.meg.unmarshalUB4();
/* 113 */     byte b = (byte)this.meg.unmarshalUB1();
/* 114 */     if (i > 0) {
/*     */       
/* 116 */       this.kpdkvarrptr = (KeywordValue[])new KeywordValueI[i];
/* 117 */       for (byte b1 = 0; b1 < i; b1++)
/* 118 */         this.kpdkvarrptr[b1] = KeywordValueI.unmarshal(this.meg); 
/* 119 */       this.connection.updateSessionProperties(this.kpdkvarrptr);
/*     */     } else {
/*     */       
/* 122 */       this.kpdkvarrptr = null;
/* 123 */     }  this.kpdkvarrflg = this.meg.unmarshalUB4();
/*     */   }
/*     */ }


/* Location:              C:\Users\olatu\OneDrive\Documents\Calypso\syncbase\sync_base.jar!\BOOT-INF\classes\ojdbc.jar!\oracle\jdbc\driver\T4CTTIkvarr.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */