/*     */ package oracle.jdbc.driver;
/*     */ 
/*     */ import java.sql.SQLException;
/*     */ import oracle.sql.CharacterSet;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class T2CCharByteArray
/*     */   extends AggregateByteArray
/*     */ {
/*     */   char[] charArray;
/*     */   DBConversion conversion;
/*     */   
/*     */   T2CCharByteArray(char[] paramArrayOfchar, ByteArray paramByteArray) {
/*  47 */     super(PhysicalConnection.EMPTY_BYTE_ARRAY, paramByteArray);
/*  48 */     this.charArray = paramArrayOfchar;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   long length() {
/*  54 */     return this.charArray.length + this.extension.length();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   void setChars(char[] paramArrayOfchar) {
/*  60 */     this.charArray = paramArrayOfchar;
/*     */   }
/*     */ 
/*     */   
/*     */   void setDBConversion(DBConversion paramDBConversion) {
/*  65 */     this.conversion = paramDBConversion;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   char[] getChars(long paramLong, int paramInt, CharacterSet paramCharacterSet, int[] paramArrayOfint) throws SQLException {
/*  90 */     if (paramLong < this.charArray.length) {
/*     */       
/*  92 */       char[] arrayOfChar = new char[paramInt];
/*     */       
/*  94 */       System.arraycopy(this.charArray, (int)paramLong, arrayOfChar, 0, paramInt);
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*  99 */       paramArrayOfint[0] = paramInt;
/* 100 */       return arrayOfChar;
/*     */     } 
/*     */     
/* 103 */     return this.extension.getChars(paramLong - this.charArray.length, paramInt, paramCharacterSet, paramArrayOfint);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void get(long paramLong, byte[] paramArrayOfbyte, int paramInt1, int paramInt2) {
/* 123 */     if (paramLong < this.charArray.length) {
/*     */       
/*     */       try {
/* 126 */         int i = this.conversion.javaCharsToCHARBytes(this.charArray, (int)paramLong, paramArrayOfbyte, paramInt1, paramInt2);
/*     */ 
/*     */ 
/*     */       
/*     */       }
/* 131 */       catch (SQLException sQLException) {}
/*     */     }
/*     */     else {
/*     */       
/* 135 */       this.extension.get(paramLong - this.charArray.length, paramArrayOfbyte, paramInt1, paramInt2);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   byte get(long paramLong) {
/* 150 */     if (paramLong < this.charArray.length) return (byte)(this.charArray[(int)paramLong] & 0xFF); 
/* 151 */     return this.extension.get(paramLong - this.charArray.length);
/*     */   }
/*     */ 
/*     */   
/* 155 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*     */   public static final String BUILD_DATE = "Thu_Apr_04_15:09:24_PDT_2013";
/*     */   public static final boolean TRACE = false;
/*     */ }


/* Location:              C:\Users\olatu\OneDrive\Documents\Calypso\syncbase\sync_base.jar!\BOOT-INF\classes\ojdbc.jar!\oracle\jdbc\driver\T2CCharByteArray.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */