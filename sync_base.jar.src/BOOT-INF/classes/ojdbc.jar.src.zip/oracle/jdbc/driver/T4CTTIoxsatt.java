/*     */ package oracle.jdbc.driver;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.sql.SQLException;
/*     */ import oracle.jdbc.internal.KeywordValueLong;
/*     */ import oracle.jdbc.internal.XSKeyval;
/*     */ import oracle.jdbc.internal.XSNamespace;
/*     */ import oracle.jdbc.internal.XSPrincipal;
/*     */ import oracle.jdbc.internal.XSSecureId;
/*     */ import oracle.sql.TIMESTAMPTZ;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class T4CTTIoxsatt
/*     */   extends T4CTTIfun
/*     */ {
/*     */   private int opcode;
/*     */   private byte[] sessionId;
/*     */   private XSSecureId sidp;
/*     */   private byte[] cookie;
/*     */   private XSPrincipal username;
/*     */   private byte[][] disabledRolesBytes;
/*     */   private byte[][] enabledRolesBytes;
/*     */   private byte[][] externalRolesBytes;
/*     */   private XSNamespace[] namespaces;
/*     */   private XSNamespace[] cacheNamespace;
/*     */   private XSNamespace[] deleteNamespace;
/*     */   private TIMESTAMPTZ midTierTimestamp;
/*     */   private TIMESTAMPTZ authtime;
/*     */   private int roleVersion;
/*     */   private long inputFlag;
/*     */   private XSKeyval kv;
/*     */   private int[] roleVersionOutput;
/*     */   
/*     */   T4CTTIoxsatt(T4CConnection paramT4CConnection) {
/* 117 */     super(paramT4CConnection, (byte)3);
/* 118 */     setFunCode((short)180);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void doOXSATT(int paramInt1, byte[] paramArrayOfbyte1, XSSecureId paramXSSecureId, byte[] paramArrayOfbyte2, XSPrincipal paramXSPrincipal, String[] paramArrayOfString1, String[] paramArrayOfString2, String[] paramArrayOfString3, XSNamespace[] paramArrayOfXSNamespace1, XSNamespace[] paramArrayOfXSNamespace2, XSNamespace[] paramArrayOfXSNamespace3, TIMESTAMPTZ paramTIMESTAMPTZ1, TIMESTAMPTZ paramTIMESTAMPTZ2, int paramInt2, long paramLong, XSKeyval paramXSKeyval, int[] paramArrayOfint) throws IOException, SQLException {
/* 142 */     this.opcode = paramInt1;
/* 143 */     this.sessionId = paramArrayOfbyte1;
/* 144 */     this.sidp = paramXSSecureId;
/* 145 */     this.cookie = paramArrayOfbyte2;
/* 146 */     this.username = paramXSPrincipal;
/* 147 */     if (paramXSPrincipal != null) {
/* 148 */       ((XSPrincipalI)paramXSPrincipal).doCharConversion(this.meg.conv);
/*     */     }
/* 150 */     if (paramArrayOfString1 != null && paramArrayOfString1.length > 0) {
/* 151 */       this.disabledRolesBytes = new byte[paramArrayOfString1.length][];
/* 152 */       for (byte b = 0; b < paramArrayOfString1.length; b++) {
/* 153 */         if (paramArrayOfString1[b] != null && paramArrayOfString1[b].length() > 0) {
/* 154 */           this.disabledRolesBytes[b] = this.meg.conv.StringToCharBytes(paramArrayOfString1[b]);
/*     */         } else {
/* 156 */           this.disabledRolesBytes[b] = null;
/*     */         } 
/*     */       } 
/*     */     } else {
/*     */       
/* 161 */       this.disabledRolesBytes = (byte[][])null;
/*     */     } 
/*     */     
/* 164 */     if (paramArrayOfString2 != null && paramArrayOfString2.length > 0) {
/* 165 */       this.enabledRolesBytes = new byte[paramArrayOfString2.length][];
/* 166 */       for (byte b = 0; b < paramArrayOfString2.length; b++) {
/* 167 */         if (paramArrayOfString2[b] != null && paramArrayOfString2[b].length() > 0) {
/* 168 */           this.enabledRolesBytes[b] = this.meg.conv.StringToCharBytes(paramArrayOfString2[b]);
/*     */         } else {
/* 170 */           this.enabledRolesBytes[b] = null;
/*     */         } 
/*     */       } 
/*     */     } else {
/* 174 */       this.enabledRolesBytes = (byte[][])null;
/*     */     } 
/*     */     
/* 177 */     if (paramArrayOfString3 != null && paramArrayOfString3.length > 0) {
/* 178 */       this.externalRolesBytes = new byte[paramArrayOfString3.length][];
/* 179 */       for (byte b = 0; b < paramArrayOfString3.length; b++) {
/* 180 */         if (paramArrayOfString3[b] != null && paramArrayOfString3[b].length() > 0) {
/* 181 */           this.externalRolesBytes[b] = this.meg.conv.StringToCharBytes(paramArrayOfString3[b]);
/*     */         } else {
/* 183 */           this.externalRolesBytes[b] = null;
/*     */         } 
/*     */       } 
/*     */     } else {
/* 187 */       this.externalRolesBytes = (byte[][])null;
/*     */     } 
/*     */     
/* 190 */     this.namespaces = paramArrayOfXSNamespace1;
/* 191 */     if (paramArrayOfXSNamespace1 != null)
/* 192 */       for (byte b = 0; b < paramArrayOfXSNamespace1.length; b++)
/* 193 */         ((XSNamespaceI)paramArrayOfXSNamespace1[b]).doCharConversion(this.meg.conv);  
/* 194 */     this.cacheNamespace = paramArrayOfXSNamespace2;
/* 195 */     if (paramArrayOfXSNamespace2 != null)
/* 196 */       for (byte b = 0; b < paramArrayOfXSNamespace2.length; b++)
/* 197 */         ((XSNamespaceI)paramArrayOfXSNamespace2[b]).doCharConversion(this.meg.conv);  
/* 198 */     this.deleteNamespace = paramArrayOfXSNamespace3;
/* 199 */     if (paramArrayOfXSNamespace3 != null) {
/* 200 */       for (byte b = 0; b < paramArrayOfXSNamespace3.length; b++) {
/* 201 */         ((XSNamespaceI)paramArrayOfXSNamespace3[b]).doCharConversion(this.meg.conv);
/*     */       }
/*     */     }
/* 204 */     this.midTierTimestamp = paramTIMESTAMPTZ1;
/* 205 */     this.authtime = paramTIMESTAMPTZ2;
/* 206 */     this.roleVersion = paramInt2;
/* 207 */     this.inputFlag = paramLong;
/* 208 */     this.kv = paramXSKeyval;
/* 209 */     if (paramXSKeyval != null) {
/* 210 */       KeywordValueLong[] arrayOfKeywordValueLong = paramXSKeyval.getKeyval();
/* 211 */       if (arrayOfKeywordValueLong != null)
/* 212 */         for (byte b = 0; b < arrayOfKeywordValueLong.length; b++) {
/* 213 */           ((KeywordValueLongI)arrayOfKeywordValueLong[b]).doCharConversion(this.meg.conv);
/*     */         } 
/*     */     } 
/* 216 */     this.roleVersionOutput = paramArrayOfint;
/*     */     
/* 218 */     doRPC();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void marshal() throws IOException {
/* 225 */     this.meg.marshalUB4(this.opcode);
/*     */     
/* 227 */     boolean bool1 = false;
/* 228 */     if (this.sessionId != null && this.sessionId.length > 0) {
/* 229 */       bool1 = true;
/* 230 */       this.meg.marshalPTR();
/* 231 */       this.meg.marshalUB4(this.sessionId.length);
/*     */     } else {
/* 233 */       this.meg.marshalNULLPTR();
/* 234 */       this.meg.marshalUB4(0L);
/*     */     } 
/* 236 */     boolean bool2 = false;
/* 237 */     if (this.sidp != null) {
/* 238 */       bool2 = true;
/* 239 */       this.meg.marshalPTR();
/*     */     } else {
/* 241 */       this.meg.marshalNULLPTR();
/*     */     } 
/* 243 */     boolean bool3 = false;
/* 244 */     if (this.cookie != null && this.cookie.length > 0) {
/* 245 */       bool3 = true;
/* 246 */       this.meg.marshalPTR();
/* 247 */       this.meg.marshalUB4(this.cookie.length);
/*     */     } else {
/* 249 */       this.meg.marshalNULLPTR();
/* 250 */       this.meg.marshalUB4(0L);
/*     */     } 
/* 252 */     boolean bool4 = false;
/* 253 */     if (this.username == null) {
/* 254 */       this.meg.marshalNULLPTR();
/*     */     } else {
/* 256 */       bool4 = true;
/* 257 */       this.meg.marshalPTR();
/*     */     } 
/* 259 */     if (this.disabledRolesBytes != null && this.disabledRolesBytes.length > 0) {
/* 260 */       this.meg.marshalPTR();
/* 261 */       this.meg.marshalUB4(this.disabledRolesBytes.length);
/*     */     } else {
/* 263 */       this.meg.marshalNULLPTR();
/* 264 */       this.meg.marshalUB4(0L);
/*     */     } 
/* 266 */     if (this.enabledRolesBytes != null && this.enabledRolesBytes.length > 0) {
/* 267 */       this.meg.marshalPTR();
/* 268 */       this.meg.marshalUB4(this.enabledRolesBytes.length);
/*     */     } else {
/* 270 */       this.meg.marshalNULLPTR();
/* 271 */       this.meg.marshalUB4(0L);
/*     */     } 
/* 273 */     if (this.externalRolesBytes != null && this.externalRolesBytes.length > 0) {
/* 274 */       this.meg.marshalPTR();
/* 275 */       this.meg.marshalUB4(this.externalRolesBytes.length);
/*     */     } else {
/* 277 */       this.meg.marshalNULLPTR();
/* 278 */       this.meg.marshalUB4(0L);
/*     */     } 
/* 280 */     boolean bool5 = false;
/* 281 */     this.meg.marshalPTR();
/* 282 */     if (this.namespaces != null && this.namespaces.length > 0) {
/* 283 */       bool5 = true;
/* 284 */       this.meg.marshalUB4(this.namespaces.length);
/*     */     } else {
/* 286 */       this.meg.marshalUB4(0L);
/*     */     } 
/* 288 */     boolean bool6 = false;
/* 289 */     this.meg.marshalPTR();
/* 290 */     if (this.cacheNamespace != null && this.cacheNamespace.length > 0) {
/* 291 */       bool6 = true;
/* 292 */       this.meg.marshalUB4(this.cacheNamespace.length);
/*     */     } else {
/* 294 */       this.meg.marshalUB4(0L);
/*     */     } 
/* 296 */     boolean bool7 = false;
/* 297 */     this.meg.marshalPTR();
/* 298 */     if (this.deleteNamespace != null && this.deleteNamespace.length > 0) {
/* 299 */       bool7 = true;
/* 300 */       this.meg.marshalUB4(this.deleteNamespace.length);
/*     */     } else {
/* 302 */       this.meg.marshalUB4(0L);
/*     */     } 
/* 304 */     if (this.midTierTimestamp != null) {
/* 305 */       this.meg.marshalPTR();
/*     */     } else {
/* 307 */       this.meg.marshalNULLPTR();
/*     */     } 
/* 309 */     if (this.authtime != null) {
/* 310 */       this.meg.marshalPTR();
/*     */     } else {
/* 312 */       this.meg.marshalNULLPTR();
/* 313 */     }  this.meg.marshalPTR();
/* 314 */     this.meg.marshalUB4(this.inputFlag);
/* 315 */     boolean bool8 = false;
/* 316 */     if (this.kv != null) {
/* 317 */       bool8 = true;
/* 318 */       this.meg.marshalPTR();
/*     */     } else {
/*     */       
/* 321 */       this.meg.marshalNULLPTR();
/*     */     } 
/* 323 */     if (bool1)
/* 324 */       this.meg.marshalB1Array(this.sessionId); 
/* 325 */     if (bool2)
/* 326 */       ((XSSecureIdI)this.sidp).marshal(this.meg); 
/* 327 */     if (bool3)
/* 328 */       this.meg.marshalB1Array(this.cookie); 
/* 329 */     if (bool4)
/* 330 */       ((XSPrincipalI)this.username).marshal(this.meg); 
/* 331 */     if (this.disabledRolesBytes != null && this.disabledRolesBytes.length > 0) {
/* 332 */       for (byte b = 0; b < this.disabledRolesBytes.length; b++) {
/* 333 */         if (this.disabledRolesBytes[b] == null) {
/* 334 */           this.meg.marshalUB4(0L);
/*     */         } else {
/* 336 */           this.meg.marshalUB4((this.disabledRolesBytes[b]).length);
/* 337 */           this.meg.marshalCLR(this.disabledRolesBytes[b], (this.disabledRolesBytes[b]).length);
/*     */         } 
/*     */       } 
/*     */     }
/*     */     
/* 342 */     if (this.enabledRolesBytes != null && this.enabledRolesBytes.length > 0) {
/* 343 */       for (byte b = 0; b < this.enabledRolesBytes.length; b++) {
/* 344 */         if (this.enabledRolesBytes[b] == null) {
/* 345 */           this.meg.marshalUB4(0L);
/*     */         } else {
/* 347 */           this.meg.marshalUB4((this.enabledRolesBytes[b]).length);
/*     */           
/* 349 */           this.meg.marshalCLR(this.enabledRolesBytes[b], (this.enabledRolesBytes[b]).length);
/*     */         } 
/*     */       } 
/*     */     }
/* 353 */     if (this.externalRolesBytes != null && this.externalRolesBytes.length > 0) {
/* 354 */       for (byte b = 0; b < this.externalRolesBytes.length; b++) {
/* 355 */         if (this.externalRolesBytes[b] == null) {
/* 356 */           this.meg.marshalUB4(0L);
/*     */         } else {
/* 358 */           this.meg.marshalUB4((this.externalRolesBytes[b]).length);
/*     */           
/* 360 */           this.meg.marshalCLR(this.externalRolesBytes[b], (this.externalRolesBytes[b]).length);
/*     */         } 
/*     */       } 
/*     */     }
/*     */     
/* 365 */     if (bool5)
/* 366 */       for (byte b = 0; b < this.namespaces.length; b++) {
/* 367 */         ((XSNamespaceI)this.namespaces[b]).marshal(this.meg);
/*     */       } 
/* 369 */     if (bool6)
/* 370 */       for (byte b = 0; b < this.cacheNamespace.length; b++) {
/* 371 */         ((XSNamespaceI)this.cacheNamespace[b]).marshal(this.meg);
/*     */       } 
/* 373 */     if (bool7) {
/* 374 */       for (byte b = 0; b < this.deleteNamespace.length; b++) {
/* 375 */         ((XSNamespaceI)this.deleteNamespace[b]).marshal(this.meg);
/*     */       }
/*     */     }
/* 378 */     if (this.midTierTimestamp != null)
/* 379 */       this.meg.marshalB1Array(this.midTierTimestamp.getBytes()); 
/* 380 */     if (this.authtime != null)
/* 381 */       this.meg.marshalB1Array(this.authtime.getBytes()); 
/* 382 */     this.meg.marshalUB4(this.roleVersion);
/* 383 */     if (bool8) {
/* 384 */       ((XSKeyvalI)this.kv).marshal(this.meg);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   void readRPA() throws SQLException, IOException {
/* 391 */     int i = (int)this.meg.unmarshalUB4();
/* 392 */     if (this.roleVersionOutput != null && this.roleVersionOutput.length == 1) {
/* 393 */       this.roleVersionOutput[0] = i;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/* 399 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*     */   public static final String BUILD_DATE = "Thu_Apr_04_15:09:24_PDT_2013";
/*     */   public static final boolean TRACE = false;
/*     */ }


/* Location:              C:\Users\olatu\OneDrive\Documents\Calypso\syncbase\sync_base.jar!\BOOT-INF\classes\ojdbc.jar!\oracle\jdbc\driver\T4CTTIoxsatt.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */