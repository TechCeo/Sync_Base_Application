/*     */ package oracle.jdbc.driver;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.sql.SQLException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class T4C8TTIuds
/*     */   extends T4CTTIMsg
/*     */ {
/*     */   T4CTTIoac udsoac;
/*     */   boolean udsnull;
/*     */   short udscnl;
/*     */   byte optimizeOAC;
/*     */   byte[] udscolnm;
/*     */   short udscolnl;
/*     */   byte[] udssnm;
/*     */   long udssnl;
/*     */   int[] snnumchar;
/*     */   byte[] udstnm;
/*     */   long udstnl;
/*     */   int[] tnnumchar;
/*     */   int[] numBytes;
/*     */   short udskpos;
/*     */   int udsflg;
/*     */   static final int UDSFCOLSEC_ENABLED = 1;
/*     */   static final int UDSFCOLSEC_UNKNOWN = 2;
/*     */   static final int UDSFCOLSEC_UNAUTH_DATA_NULL = 4;
/*     */   static final int UDSFCOL_IS_INVISIBLE = 8;
/*     */   
/*     */   T4C8TTIuds(T4CConnection paramT4CConnection) {
/* 120 */     super(paramT4CConnection, (byte)0);
/*     */     
/* 122 */     this.udskpos = -1;
/* 123 */     this.udsoac = new T4CTTIoac(paramT4CConnection);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void unmarshal() throws IOException, SQLException {
/* 139 */     this.udsoac.unmarshal();
/*     */     
/* 141 */     short s = this.meg.unmarshalUB1();
/* 142 */     this.udsnull = (s > 0);
/* 143 */     this.udscnl = this.meg.unmarshalUB1();
/*     */     
/* 145 */     this.numBytes = new int[1];
/* 146 */     this.udscolnm = this.meg.unmarshalDALC(this.numBytes);
/*     */ 
/*     */     
/* 149 */     this.snnumchar = new int[1];
/* 150 */     this.udssnm = this.meg.unmarshalDALC(this.snnumchar);
/* 151 */     this.udssnl = this.udssnm.length;
/*     */ 
/*     */     
/* 154 */     this.tnnumchar = new int[1];
/* 155 */     this.udstnm = this.meg.unmarshalDALC(this.tnnumchar);
/* 156 */     this.udstnl = this.udstnm.length;
/*     */ 
/*     */     
/* 159 */     if (this.connection.getTTCVersion() >= 3) {
/*     */       
/* 161 */       this.udskpos = (short)this.meg.unmarshalUB2();
/*     */       
/* 163 */       if (this.connection.getTTCVersion() >= 6) {
/* 164 */         this.udsflg = (int)this.meg.unmarshalUB4();
/*     */       }
/*     */     } else {
/*     */       
/* 168 */       this.udskpos = -1;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   short getKernelPosition() {
/* 185 */     return this.udskpos;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   byte[] getColumName() {
/* 192 */     return this.udscolnm;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   byte[] getTypeName() {
/* 199 */     return this.udstnm;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   byte[] getSchemaName() {
/* 206 */     return this.udssnm;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   short getTypeCharLength() {
/* 213 */     return (short)this.tnnumchar[0];
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   short getColumNameByteLength() {
/* 220 */     return (short)this.numBytes[0];
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   short getSchemaCharLength() {
/* 227 */     return (short)this.snnumchar[0];
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void print() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 276 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*     */   public static final String BUILD_DATE = "Thu_Apr_04_15:09:24_PDT_2013";
/*     */   public static final boolean TRACE = false;
/*     */ }


/* Location:              C:\Users\olatu\OneDrive\Documents\Calypso\syncbase\sync_base.jar!\BOOT-INF\classes\ojdbc.jar!\oracle\jdbc\driver\T4C8TTIuds.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */