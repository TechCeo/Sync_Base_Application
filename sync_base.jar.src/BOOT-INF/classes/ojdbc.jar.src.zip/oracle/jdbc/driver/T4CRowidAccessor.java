/*      */ package oracle.jdbc.driver;
/*      */ 
/*      */ import java.io.IOException;
/*      */ import java.sql.SQLException;
/*      */ import oracle.jdbc.OracleResultSetMetaData;
/*      */ import oracle.jdbc.internal.OracleConnection;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ class T4CRowidAccessor
/*      */   extends RowidAccessor
/*      */ {
/*      */   T4CMAREngine mare;
/*      */   final int[] meta;
/*      */   static final int KGRD_EXTENDED_OBJECT = 6;
/*      */   static final int KGRD_EXTENDED_BLOCK = 6;
/*      */   static final int KGRD_EXTENDED_FILE = 3;
/*      */   static final int KGRD_EXTENDED_SLOT = 3;
/*      */   static final int kd4_ubridtype_physical = 1;
/*      */   static final int kd4_ubridtype_logical = 2;
/*      */   static final int kd4_ubridtype_remote = 3;
/*      */   static final int kd4_ubridtype_exttab = 4;
/*      */   static final int kd4_ubridtype_future2 = 5;
/*      */   static final int kd4_ubridtype_max = 5;
/*      */   static final int kd4_ubridlen_typeind = 1;
/*      */   
/*      */   T4CRowidAccessor(OracleStatement paramOracleStatement, int paramInt1, short paramShort, int paramInt2, boolean paramBoolean, T4CMAREngine paramT4CMAREngine) throws SQLException {
/*   35 */     super(paramOracleStatement, paramInt1, paramShort, paramInt2, paramBoolean);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  194 */     this.meta = new int[1]; this.mare = paramT4CMAREngine; this.defineType = 104; } T4CRowidAccessor(OracleStatement paramOracleStatement, int paramInt1, boolean paramBoolean, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, short paramShort, int paramInt7, int paramInt8, T4CMAREngine paramT4CMAREngine) throws SQLException { super(paramOracleStatement, paramInt1, paramBoolean, paramInt2, paramInt3, paramInt4, paramInt5, paramInt6, paramShort); this.meta = new int[1];
/*      */     this.mare = paramT4CMAREngine;
/*      */     this.definedColumnType = paramInt7;
/*      */     this.definedColumnSize = paramInt8;
/*      */     this.defineType = 104; }
/*      */ 
/*      */   
/*      */   public T4CMAREngine getMAREngine() {
/*      */     return this.mare;
/*      */   }
/*      */   boolean unmarshalBytes() throws SQLException, IOException { int i;
/*  205 */     setOffset(this.lastRowProcessed);
/*      */     
/*  207 */     this.rowData.putShort((short)0);
/*  208 */     if (this.describeType == 208) {
/*      */       
/*  210 */       i = (int)this.mare.unmarshalUB4();
/*  211 */       if (i > 0) {
/*  212 */         ((DynamicByteArray)this.rowData).unmarshalCLR(this.mare, i);
/*      */       }
/*      */     } else {
/*      */       
/*  216 */       i = this.mare.unmarshalUB1();
/*      */ 
/*      */       
/*  219 */       if (i > 0) {
/*  220 */         this.rowData.putInt((int)this.mare.unmarshalUB4());
/*  221 */         this.rowData.putShort((short)this.mare.unmarshalUB2());
/*  222 */         this.rowData.put((byte)this.mare.unmarshalUB1());
/*  223 */         this.rowData.putInt((int)this.mare.unmarshalUB4());
/*  224 */         this.rowData.putShort((short)this.mare.unmarshalUB2());
/*      */       } 
/*      */     } 
/*  227 */     processIndicator(i);
/*  228 */     this.rowData.putShort(getOffset(this.lastRowProcessed), (short)i);
/*  229 */     setLength(this.lastRowProcessed, (int)(this.rowData.getPosition() - getOffset(this.lastRowProcessed)));
/*  230 */     setNull(this.lastRowProcessed, (i == 0));
/*  231 */     return false; }
/*      */   public void unmarshalColumnMetadata() throws SQLException, IOException { if (this.statement.statementType != 2 && !this.statement.sqlKind.isPlsqlOrCall() && this.securityAttribute == OracleResultSetMetaData.SecurityAttribute.ENABLED)
/*      */       setRowMetadata(this.lastRowProcessed, (byte)this.mare.unmarshalUB1());  }
/*      */   public void processIndicator(int paramInt) throws IOException, SQLException { if ((this.internalType == 1 && this.describeType == 112) || (this.internalType == 23 && this.describeType == 113)) { this.mare.unmarshalUB2(); this.mare.unmarshalUB2(); } else if (this.statement.connection.versionNumber < 9200) { this.mare.unmarshalSB2(); if (!this.statement.sqlKind.isPlsqlOrCall())
/*      */         this.mare.unmarshalSB2();  }
/*      */     else if (this.statement.sqlKind.isPlsqlOrCall() || this.isDMLReturnedParam) { this.mare.processIndicator((paramInt <= 0), paramInt); }
/*      */      }
/*      */   int getPreviousRowProcessed() { if (this.previousRowProcessed == -1)
/*  239 */       this.previousRowProcessed = this.statement.rowPrefetchInLastFetch - 1;  return this.previousRowProcessed; } byte[] getDecodedBytes(int paramInt) throws SQLException { this.rowData.setPosition(getOffset(paramInt));
/*  240 */     int i = this.rowData.getShort();
/*  241 */     if (this.describeType == 208) {
/*      */       
/*  243 */       byte[] arrayOfByte3 = getBytesInternal(paramInt);
/*  244 */       byte[] arrayOfByte4 = new byte[4096];
/*  245 */       i = kgrdub2c(arrayOfByte3, i, 2, arrayOfByte4, 2);
/*  246 */       arrayOfByte4[0] = (byte)(i >> 8 & 0xFF);
/*  247 */       arrayOfByte4[1] = (byte)(i & 0xFF);
/*  248 */       byte[] arrayOfByte5 = new byte[i + 2];
/*  249 */       System.arraycopy(arrayOfByte4, 0, arrayOfByte5, 0, arrayOfByte5.length);
/*  250 */       return arrayOfByte5;
/*      */     } 
/*      */ 
/*      */     
/*  254 */     short s = (short)i;
/*  255 */     long l1 = 0L;
/*  256 */     int j = 0;
/*  257 */     short s1 = 0;
/*  258 */     long l2 = 0L;
/*  259 */     int k = 0;
/*      */ 
/*      */ 
/*      */     
/*  263 */     if (s > 0) {
/*  264 */       l1 = this.rowData.getInt() & 0xFFFFFFFFL;
/*  265 */       j = this.rowData.getShort() & 0xFFFF;
/*  266 */       s1 = (short)(this.rowData.get() & 0xFF);
/*  267 */       l2 = this.rowData.getInt() & 0xFFFFFFFFL;
/*  268 */       k = this.rowData.getShort() & 0xFFFF;
/*      */     } 
/*      */ 
/*      */     
/*  272 */     if (l1 == 0L && j == 0 && s1 == 0 && l2 == 0L && k == 0)
/*      */     {
/*  274 */       return null;
/*      */     }
/*      */     
/*  277 */     long[] arrayOfLong = { l1, j, l2, k };
/*      */ 
/*      */ 
/*      */     
/*  281 */     byte[] arrayOfByte1 = rowidToString(arrayOfLong);
/*  282 */     int m = 18;
/*      */     
/*  284 */     if (this.byteLength - 2 < 18)
/*  285 */       m = this.byteLength - 2; 
/*  286 */     byte[] arrayOfByte2 = new byte[m + 2];
/*  287 */     System.arraycopy(arrayOfByte1, 0, arrayOfByte2, 2, m);
/*  288 */     arrayOfByte2[0] = (byte)((m & 0xFF00) >> 8);
/*  289 */     arrayOfByte2[1] = (byte)(m & 0xFF);
/*  290 */     return arrayOfByte2; } boolean unmarshalOneRow() throws SQLException, IOException { boolean bool = false; if (!isUseless())
/*      */       if (isUnexpected()) {
/*      */         long l = this.rowData.getPosition(); unmarshalColumnMetadata(); unmarshalBytes(); this.rowData.setPosition(l); setNull(this.lastRowProcessed, true);
/*      */       } else if (isNullByDescribe()) {
/*      */         setNull(this.lastRowProcessed, true); unmarshalColumnMetadata();
/*      */         if (this.statement.connection.versionNumber < 9200)
/*      */           processIndicator(0); 
/*      */       } else {
/*      */         unmarshalColumnMetadata();
/*      */         bool = unmarshalBytes();
/*      */       }  
/*      */     this.previousRowProcessed = this.lastRowProcessed;
/*      */     this.lastRowProcessed++;
/*      */     return bool; }
/*  304 */   String getString(int paramInt) throws SQLException { if (isNull(paramInt)) return null;
/*      */     
/*  306 */     long l = getOffset(paramInt);
/*      */     
/*  308 */     if (this.describeType == 208 && this.rowData.get(l) != 1) {
/*      */ 
/*      */       
/*  311 */       byte[] arrayOfByte1 = getDecodedBytes(paramInt);
/*  312 */       if (arrayOfByte1 == null)
/*  313 */         return null; 
/*  314 */       int j = (arrayOfByte1[0] & 0xFF) << 8 | arrayOfByte1[1] & 0xFF;
/*  315 */       return new String(arrayOfByte1, 2, j);
/*      */     } 
/*      */     
/*  318 */     int i = getLength(paramInt);
/*  319 */     byte[] arrayOfByte = getDecodedBytes(paramInt);
/*  320 */     if (arrayOfByte == null)
/*  321 */       return null; 
/*  322 */     String str = new String(arrayOfByte, 2, arrayOfByte.length - 2);
/*  323 */     long[] arrayOfLong = stringToRowid(str.getBytes(), 0, str.length());
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  328 */     return new String(rowidToString(arrayOfLong)); } void copyRow() throws SQLException, IOException { if (this.isNullByDescribe) {
/*      */       setNull(this.lastRowProcessed, true);
/*      */     } else if (this.lastRowProcessed == 0) {
/*      */       if (this.previousRowProcessed == -1)
/*      */         this.previousRowProcessed = this.statement.rowPrefetchInLastFetch - 1;  long l = getOffset(this.previousRowProcessed); setNull(this.lastRowProcessed, isNull(this.previousRowProcessed)); this.rowMetadata[this.lastRowProcessed] = this.rowMetadata[this.previousRowProcessed]; if (!isNull(this.previousRowProcessed)) {
/*      */         setOffset(this.lastRowProcessed); ((DynamicByteArray)this.rowData).copyLeft(l, getLength(this.previousRowProcessed)); setLength(this.lastRowProcessed, getLength(this.previousRowProcessed));
/*      */       } 
/*      */     } else {
/*      */       setNull(this.lastRowProcessed, isNull(this.previousRowProcessed)); this.rowMetadata[this.lastRowProcessed] = this.rowMetadata[this.previousRowProcessed]; setOffset(this.lastRowProcessed, getOffset(this.previousRowProcessed)); setLength(this.lastRowProcessed, getLength(this.previousRowProcessed));
/*      */     }  this.previousRowProcessed = this.lastRowProcessed;
/*      */     this.lastRowProcessed++; }
/*  339 */   Object getObject(int paramInt) throws SQLException { if (this.definedColumnType == 0) {
/*  340 */       return super.getObject(paramInt);
/*      */     }
/*  342 */     if (isNull(paramInt)) return null;
/*      */     
/*  344 */     switch (this.definedColumnType) {
/*      */       
/*      */       case -15:
/*      */       case -9:
/*      */       case -1:
/*      */       case 1:
/*      */       case 12:
/*  351 */         return getString(paramInt);
/*      */       
/*      */       case -8:
/*  354 */         return getROWID(paramInt);
/*      */     } 
/*      */ 
/*      */     
/*  358 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4);
/*  359 */     sQLException.fillInStackTrace();
/*  360 */     throw sQLException; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   byte[] getBytes(int paramInt) throws SQLException {
/*  371 */     if (isNull(paramInt)) return null;
/*      */     
/*  373 */     byte[] arrayOfByte1 = getDecodedBytes(paramInt);
/*  374 */     if (arrayOfByte1 == null)
/*  375 */       return null; 
/*  376 */     byte[] arrayOfByte2 = new byte[arrayOfByte1.length - 2];
/*  377 */     System.arraycopy(arrayOfByte1, 2, arrayOfByte2, 0, arrayOfByte2.length);
/*  378 */     return arrayOfByte2;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static final byte[] rowidToString(long[] paramArrayOflong) {
/*  390 */     long l1 = paramArrayOflong[0];
/*      */ 
/*      */     
/*  393 */     long l2 = paramArrayOflong[1];
/*      */ 
/*      */     
/*  396 */     long l3 = paramArrayOflong[2];
/*      */ 
/*      */     
/*  399 */     long l4 = paramArrayOflong[3];
/*      */     
/*  401 */     byte b = 18;
/*      */ 
/*      */ 
/*      */     
/*  405 */     byte[] arrayOfByte = new byte[b];
/*  406 */     int i = 0;
/*      */     
/*  408 */     i = kgrd42b(arrayOfByte, l1, 6, i);
/*      */ 
/*      */     
/*  411 */     i = kgrd42b(arrayOfByte, l2, 3, i);
/*      */ 
/*      */     
/*  414 */     i = kgrd42b(arrayOfByte, l3, 6, i);
/*      */ 
/*      */     
/*  417 */     i = kgrd42b(arrayOfByte, l4, 3, i);
/*      */ 
/*      */ 
/*      */     
/*  421 */     return arrayOfByte;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static final long[] rcToRowid(byte[] paramArrayOfbyte, int paramInt1, int paramInt2) throws SQLException {
/*  437 */     byte b = 18;
/*      */     
/*  439 */     if (paramInt2 != b)
/*      */     {
/*  441 */       throw new SQLException("Rowid size incorrect.");
/*      */     }
/*      */     
/*  444 */     long[] arrayOfLong = new long[3];
/*  445 */     String str = new String(paramArrayOfbyte, paramInt1, paramInt2);
/*      */ 
/*      */     
/*  448 */     long l1 = Long.parseLong(str.substring(0, 8), 16);
/*  449 */     long l2 = Long.parseLong(str.substring(9, 13), 16);
/*  450 */     long l3 = Long.parseLong(str.substring(14, 8), 16);
/*      */     
/*  452 */     arrayOfLong[0] = l3;
/*  453 */     arrayOfLong[1] = l1;
/*  454 */     arrayOfLong[2] = l2;
/*      */     
/*  456 */     return arrayOfLong;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static final void kgrdr2rc(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, byte[] paramArrayOfbyte, int paramInt6) throws SQLException {
/*  476 */     paramInt6 = lmx42h(paramArrayOfbyte, paramInt4, 8, paramInt6);
/*  477 */     paramArrayOfbyte[paramInt6++] = 46;
/*      */     
/*  479 */     paramInt6 = lmx42h(paramArrayOfbyte, paramInt5, 4, paramInt6);
/*  480 */     paramArrayOfbyte[paramInt6++] = 46;
/*      */     
/*  482 */     paramInt6 = lmx42h(paramArrayOfbyte, paramInt2, 4, paramInt6);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static final int lmx42h(byte[] paramArrayOfbyte, long paramLong, int paramInt1, int paramInt2) {
/*  497 */     String str = Long.toHexString(paramLong).toUpperCase();
/*      */ 
/*      */     
/*  500 */     int i = paramInt1;
/*  501 */     byte b = 0;
/*      */ 
/*      */     
/*      */     do {
/*  505 */       if (b < str.length())
/*      */       {
/*  507 */         paramArrayOfbyte[paramInt2 + paramInt1 - 1] = (byte)str.charAt(str.length() - b - 1);
/*      */         
/*  509 */         b++;
/*      */       }
/*      */       else
/*      */       {
/*  513 */         paramArrayOfbyte[paramInt2 + paramInt1 - 1] = 48;
/*      */       }
/*      */     
/*  516 */     } while (--paramInt1 > 0);
/*      */     
/*  518 */     return i + paramInt2;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static final int kgrdc2ub(byte[] paramArrayOfbyte1, int paramInt1, byte[] paramArrayOfbyte2, int paramInt2, int paramInt3) throws SQLException {
/*  535 */     byte b = getRowidType(paramArrayOfbyte1, paramInt1);
/*  536 */     byte[] arrayOfByte1 = paramArrayOfbyte2;
/*  537 */     int i = paramInt3 - 1;
/*  538 */     int j = 0;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  543 */     byte[] arrayOfByte2 = kgrd_index_64;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  550 */     int k = 1 + 3 * (paramInt3 - 1) / 4 + (((paramInt3 - 1) % 4 != 0) ? ((paramInt3 - 1) % 4 - 1) : 0);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  556 */     if (i == 0) {
/*      */ 
/*      */       
/*  559 */       SQLException sQLException = DatabaseError.createSqlException((OracleConnection)null, 132);
/*  560 */       sQLException.fillInStackTrace();
/*  561 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  566 */     arrayOfByte1[paramInt2 + 0] = b;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  574 */     j = paramInt1 + 1;
/*  575 */     byte b1 = 1;
/*      */     
/*  577 */     while (i > 0) {
/*      */ 
/*      */       
/*  580 */       if (i == 1) {
/*      */ 
/*      */         
/*  583 */         SQLException sQLException = DatabaseError.createSqlException((OracleConnection)null, 132);
/*  584 */         sQLException.fillInStackTrace();
/*  585 */         throw sQLException;
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/*  590 */       byte b2 = arrayOfByte2[paramArrayOfbyte1[j]];
/*  591 */       if (b2 == -1) {
/*      */ 
/*      */         
/*  594 */         SQLException sQLException = DatabaseError.createSqlException((OracleConnection)null, 132);
/*  595 */         sQLException.fillInStackTrace();
/*  596 */         throw sQLException;
/*      */       } 
/*      */ 
/*      */       
/*  600 */       j++;
/*  601 */       byte b3 = arrayOfByte2[paramArrayOfbyte1[j]];
/*  602 */       if (b3 == -1) {
/*      */ 
/*      */         
/*  605 */         SQLException sQLException = DatabaseError.createSqlException((OracleConnection)null, 132);
/*  606 */         sQLException.fillInStackTrace();
/*  607 */         throw sQLException;
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  615 */       arrayOfByte1[paramInt2 + b1] = (byte)((b2 & 0xFF) << 2 | (b3 & 0x30) >> 4);
/*      */ 
/*      */       
/*  618 */       if (i == 2) {
/*      */         break;
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  625 */       b1++;
/*  626 */       b2 = b3;
/*  627 */       j++;
/*  628 */       b3 = arrayOfByte2[paramArrayOfbyte1[j]];
/*  629 */       if (b3 == -1) {
/*      */ 
/*      */         
/*  632 */         SQLException sQLException = DatabaseError.createSqlException((OracleConnection)null, 132);
/*  633 */         sQLException.fillInStackTrace();
/*  634 */         throw sQLException;
/*      */       } 
/*      */ 
/*      */       
/*  638 */       arrayOfByte1[paramInt2 + b1] = (byte)((b2 & 0xFF) << 4 | (b3 & 0x3C) >> 2);
/*      */ 
/*      */       
/*  641 */       if (i == 3) {
/*      */         break;
/*      */       }
/*      */ 
/*      */       
/*  646 */       b1++;
/*  647 */       b2 = b3;
/*  648 */       j++;
/*  649 */       b3 = arrayOfByte2[paramArrayOfbyte1[j]];
/*  650 */       if (b3 == -1) {
/*      */ 
/*      */         
/*  653 */         SQLException sQLException = DatabaseError.createSqlException((OracleConnection)null, 132);
/*  654 */         sQLException.fillInStackTrace();
/*  655 */         throw sQLException;
/*      */       } 
/*      */       
/*  658 */       arrayOfByte1[paramInt2 + b1] = (byte)((b2 & 0x3) << 6 | b3);
/*      */ 
/*      */ 
/*      */       
/*  662 */       i -= 4;
/*  663 */       j++;
/*  664 */       b1++;
/*      */     } 
/*      */     
/*  667 */     return k;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static final long[] stringToRowid(byte[] paramArrayOfbyte, int paramInt1, int paramInt2) throws SQLException {
/*  677 */     byte b = 18;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  682 */     if (paramInt2 != b)
/*      */     {
/*  684 */       throw new SQLException("Rowid size incorrect.");
/*      */     }
/*      */     
/*  687 */     long[] arrayOfLong = new long[4];
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     try {
/*  693 */       arrayOfLong[0] = kgrdb42(paramArrayOfbyte, 6, paramInt1);
/*      */ 
/*      */       
/*  696 */       paramInt1 += 6;
/*      */ 
/*      */       
/*  699 */       arrayOfLong[1] = kgrdb42(paramArrayOfbyte, 3, paramInt1);
/*      */ 
/*      */       
/*  702 */       paramInt1 += 3;
/*      */ 
/*      */       
/*  705 */       arrayOfLong[2] = kgrdb42(paramArrayOfbyte, 6, paramInt1);
/*      */ 
/*      */       
/*  708 */       paramInt1 += 6;
/*      */ 
/*      */       
/*  711 */       arrayOfLong[3] = kgrdb42(paramArrayOfbyte, 3, paramInt1);
/*      */ 
/*      */       
/*  714 */       paramInt1 += 3;
/*      */     }
/*  716 */     catch (Exception exception) {
/*      */       
/*  718 */       arrayOfLong[0] = 0L;
/*  719 */       arrayOfLong[1] = 0L;
/*  720 */       arrayOfLong[2] = 0L;
/*  721 */       arrayOfLong[3] = 0L;
/*      */     } 
/*      */     
/*  724 */     return arrayOfLong;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static final int kgrd42b(byte[] paramArrayOfbyte, long paramLong, int paramInt1, int paramInt2) {
/*  736 */     int i = paramInt1;
/*  737 */     long l = paramLong;
/*      */     
/*  739 */     for (; paramInt1 > 0; paramInt1--) {
/*      */       
/*  741 */       paramArrayOfbyte[paramInt2 + paramInt1 - 1] = kgrd_basis_64[(int)l & 0x3F];
/*  742 */       l = l >>> 6L & 0x3FFFFFFL;
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  748 */     return i + paramInt2;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static final long kgrdb42(byte[] paramArrayOfbyte, int paramInt1, int paramInt2) throws SQLException {
/*  759 */     long l = 0L;
/*      */     
/*  761 */     for (byte b = 0; b < paramInt1; b++) {
/*      */       
/*  763 */       byte b1 = paramArrayOfbyte[paramInt2 + b];
/*      */       
/*  765 */       b1 = kgrd_index_64[b1];
/*      */       
/*  767 */       if (b1 == -1) {
/*  768 */         throw new SQLException("Char data to rowid conversion failed.");
/*      */       }
/*  770 */       l <<= 6L;
/*  771 */       l |= b1;
/*      */     } 
/*      */     
/*  774 */     return l;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static final void kgrdr2ec(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, byte[] paramArrayOfbyte, int paramInt6) throws SQLException {
/*  787 */     paramInt6 = kgrd42b(paramInt1, paramArrayOfbyte, paramInt6, 6);
/*  788 */     paramInt6 = kgrd42b(paramInt2, paramArrayOfbyte, paramInt6, 3);
/*  789 */     paramInt6 = kgrd42b(paramInt4, paramArrayOfbyte, paramInt6, 6);
/*  790 */     paramInt6 = kgrd42b(paramInt5, paramArrayOfbyte, paramInt6, 3);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static final int kgrd42b(int paramInt1, byte[] paramArrayOfbyte, int paramInt2, int paramInt3) throws SQLException {
/*  801 */     int i = paramInt3;
/*  802 */     while (paramInt3 > 0) {
/*      */       
/*  804 */       paramInt3--;
/*  805 */       paramArrayOfbyte[paramInt2 + paramInt3] = kgrd_basis_64[paramInt1 & 0x3F];
/*      */       
/*  807 */       paramInt1 >>= 6;
/*      */     } 
/*      */     
/*  810 */     return paramInt2 + i;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static final int kgrdub2c(byte[] paramArrayOfbyte1, int paramInt1, int paramInt2, byte[] paramArrayOfbyte2, int paramInt3) throws SQLException {
/*  823 */     byte b = -1;
/*  824 */     byte b1 = paramArrayOfbyte1[paramInt2];
/*      */     
/*  826 */     if (b1 == 1) {
/*      */ 
/*      */ 
/*      */       
/*  830 */       int[] arrayOfInt = new int[paramArrayOfbyte1.length]; int i;
/*  831 */       for (i = 0; i < paramArrayOfbyte1.length; ) { arrayOfInt[i] = paramArrayOfbyte1[i] & 0xFF; i++; }
/*      */       
/*  833 */       i = paramInt2 + 1;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  841 */       int j = (((arrayOfInt[i + 0] << 8) + arrayOfInt[i + 1] << 8) + arrayOfInt[i + 2] << 8) + arrayOfInt[i + 3];
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  846 */       i = paramInt2 + 5;
/*      */       
/*  848 */       int k = (arrayOfInt[i + 0] << 8) + arrayOfInt[i + 1];
/*  849 */       boolean bool = false;
/*      */ 
/*      */       
/*  852 */       i = paramInt2 + 7;
/*  853 */       int m = (((arrayOfInt[i + 0] << 8) + arrayOfInt[i + 1] << 8) + arrayOfInt[i + 2] << 8) + arrayOfInt[i + 3];
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  858 */       i = paramInt2 + 11;
/*      */       
/*  860 */       int n = (arrayOfInt[i + 0] << 8) + arrayOfInt[i + 1];
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  869 */       if (j == 0) {
/*  870 */         kgrdr2rc(j, k, bool, m, n, paramArrayOfbyte2, paramInt3);
/*      */ 
/*      */       
/*      */       }
/*      */       else {
/*      */ 
/*      */ 
/*      */         
/*  878 */         kgrdr2ec(j, k, bool, m, n, paramArrayOfbyte2, paramInt3);
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  886 */       b = 18;
/*      */     
/*      */     }
/*      */     else {
/*      */ 
/*      */       
/*  892 */       byte b2 = 0;
/*  893 */       int i = paramInt1 - 1;
/*  894 */       int j = 4 * paramInt1 / 3 + ((paramInt1 % 3 == 0) ? (paramInt1 % 3 + 1) : 0);
/*      */       
/*  896 */       int k = 1 + j - 1;
/*      */       
/*  898 */       if (k != 0) {
/*      */         
/*  900 */         paramArrayOfbyte2[paramInt3 + 0] = kgrd_indbyte_char[b1 - 1];
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  914 */         int m = paramInt2 + 1;
/*      */         
/*  916 */         b2 = 1;
/*      */         
/*  918 */         byte b3 = 0;
/*      */         
/*  920 */         while (i > 0) {
/*      */           
/*  922 */           paramArrayOfbyte2[paramInt3 + b2++] = kgrd_basis_64[(paramArrayOfbyte1[m] & 0xFF) >> 2];
/*      */ 
/*      */ 
/*      */           
/*  926 */           if (i == 1) {
/*      */ 
/*      */ 
/*      */             
/*  930 */             paramArrayOfbyte2[paramInt3 + b2++] = kgrd_basis_64[(paramArrayOfbyte1[m] & 0x3) << 4];
/*      */ 
/*      */             
/*      */             break;
/*      */           } 
/*      */ 
/*      */           
/*  937 */           b3 = (byte)(paramArrayOfbyte1[m + 1] & 0xFF);
/*      */           
/*  939 */           paramArrayOfbyte2[paramInt3 + b2++] = kgrd_basis_64[(paramArrayOfbyte1[m] & 0x3) << 4 | (b3 & 0xF0) >> 4];
/*      */ 
/*      */ 
/*      */           
/*  943 */           if (i == 2) {
/*      */             
/*  945 */             paramArrayOfbyte2[paramInt3 + b2++] = kgrd_basis_64[(b3 & 0xF) << 2];
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*      */             break;
/*      */           } 
/*      */ 
/*      */ 
/*      */           
/*  955 */           m += 2;
/*  956 */           paramArrayOfbyte2[paramInt3 + b2++] = kgrd_basis_64[(b3 & 0xF) << 2 | (paramArrayOfbyte1[m] & 0xC0) >> 6];
/*      */ 
/*      */ 
/*      */           
/*  960 */           paramArrayOfbyte2[paramInt3 + b2] = kgrd_basis_64[paramArrayOfbyte1[m] & 0x3F];
/*      */ 
/*      */ 
/*      */           
/*  964 */           i -= 3;
/*  965 */           m++;
/*  966 */           b2++;
/*      */         } 
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/*  972 */       b = b2;
/*      */     } 
/*      */     
/*  975 */     return b;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   static final boolean isUROWID(byte[] paramArrayOfbyte, int paramInt) {
/*  981 */     return (getRowidType(paramArrayOfbyte, paramInt) == 2);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   static final byte getRowidType(byte[] paramArrayOfbyte, int paramInt) {
/*  987 */     byte b = 5;
/*  988 */     switch (paramArrayOfbyte[paramInt]) {
/*      */       
/*      */       case 65:
/*  991 */         b = 1;
/*      */         break;
/*      */       
/*      */       case 42:
/*  995 */         b = 2;
/*      */         break;
/*      */       
/*      */       case 45:
/*  999 */         b = 3;
/*      */         break;
/*      */       
/*      */       case 40:
/* 1003 */         b = 4;
/*      */         break;
/*      */       
/*      */       case 41:
/* 1007 */         b = 5;
/*      */         break;
/*      */     } 
/*      */     
/* 1011 */     return b;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1039 */   static final byte[] kgrd_indbyte_char = new byte[] { 65, 42, 45, 40, 41 };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1046 */   static final byte[] kgrd_basis_64 = new byte[] { 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 43, 47 };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1061 */   static final byte[] kgrd_index_64 = new byte[] { -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 62, -1, -1, -1, 63, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, -1, -1, -1, -1, -1, -1, -1, 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, -1, -1, -1, -1, -1, -1, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, -1, -1, -1, -1, -1 };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1087 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*      */   public static final String BUILD_DATE = "Thu_Apr_04_15:09:24_PDT_2013";
/*      */   public static final boolean TRACE = false;
/*      */ }


/* Location:              C:\Users\olatu\OneDrive\Documents\Calypso\syncbase\sync_base.jar!\BOOT-INF\classes\ojdbc.jar!\oracle\jdbc\driver\T4CRowidAccessor.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */