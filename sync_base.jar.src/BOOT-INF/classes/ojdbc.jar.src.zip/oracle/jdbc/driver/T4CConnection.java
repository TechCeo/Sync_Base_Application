/*      */ package oracle.jdbc.driver;
/*      */ 
/*      */ import java.io.IOException;
/*      */ import java.io.InputStream;
/*      */ import java.io.OutputStream;
/*      */ import java.io.Reader;
/*      */ import java.io.UnsupportedEncodingException;
/*      */ import java.io.Writer;
/*      */ import java.lang.reflect.Field;
/*      */ import java.net.SocketException;
/*      */ import java.security.NoSuchAlgorithmException;
/*      */ import java.security.spec.InvalidKeySpecException;
/*      */ import java.sql.Connection;
/*      */ import java.sql.SQLException;
/*      */ import java.util.ArrayList;
/*      */ import java.util.EnumSet;
/*      */ import java.util.HashMap;
/*      */ import java.util.Hashtable;
/*      */ import java.util.Iterator;
/*      */ import java.util.Map;
/*      */ import java.util.Properties;
/*      */ import java.util.concurrent.Executor;
/*      */ import java.util.zip.CRC32;
/*      */ import oracle.jdbc.LogicalTransactionId;
/*      */ import oracle.jdbc.LogicalTransactionIdEventListener;
/*      */ import oracle.jdbc.NotificationRegistration;
/*      */ import oracle.jdbc.OracleConnection;
/*      */ import oracle.jdbc.aq.AQDequeueOptions;
/*      */ import oracle.jdbc.aq.AQEnqueueOptions;
/*      */ import oracle.jdbc.internal.JMSDequeueOptions;
/*      */ import oracle.jdbc.internal.JMSEnqueueOptions;
/*      */ import oracle.jdbc.internal.JMSMessageProperties;
/*      */ import oracle.jdbc.internal.JMSNotificationRegistration;
/*      */ import oracle.jdbc.internal.KeywordValue;
/*      */ import oracle.jdbc.internal.KeywordValueLong;
/*      */ import oracle.jdbc.internal.OracleBfile;
/*      */ import oracle.jdbc.internal.OracleBlob;
/*      */ import oracle.jdbc.internal.OracleClob;
/*      */ import oracle.jdbc.internal.OracleConnection;
/*      */ import oracle.jdbc.internal.OracleStatement;
/*      */ import oracle.jdbc.internal.PDBChangeEventListener;
/*      */ import oracle.jdbc.internal.ReplayContext;
/*      */ import oracle.jdbc.internal.XSEventListener;
/*      */ import oracle.jdbc.internal.XSKeyval;
/*      */ import oracle.jdbc.internal.XSNamespace;
/*      */ import oracle.jdbc.internal.XSPrincipal;
/*      */ import oracle.jdbc.internal.XSSecureId;
/*      */ import oracle.jdbc.internal.XSSessionParameters;
/*      */ import oracle.jdbc.pool.OraclePooledConnection;
/*      */ import oracle.net.ns.Communication;
/*      */ import oracle.net.ns.NSProtocolNIO;
/*      */ import oracle.net.ns.NSProtocolStream;
/*      */ import oracle.net.ns.NetException;
/*      */ import oracle.sql.BFILE;
/*      */ import oracle.sql.BLOB;
/*      */ import oracle.sql.BfileDBAccess;
/*      */ import oracle.sql.BlobDBAccess;
/*      */ import oracle.sql.CLOB;
/*      */ import oracle.sql.ClobDBAccess;
/*      */ import oracle.sql.LobPlsqlUtil;
/*      */ import oracle.sql.TIMESTAMPTZ;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ class T4CConnection
/*      */   extends PhysicalConnection
/*      */   implements BfileDBAccess, BlobDBAccess, ClobDBAccess
/*      */ {
/*      */   static final short MIN_TTCVER_SUPPORTED = 4;
/*      */   static final short V8_TTCVER_SUPPORTED = 5;
/*      */   static final short MAX_TTCVER_SUPPORTED = 6;
/*      */   static final int DEFAULT_LONG_PREFETCH_SIZE = 4080;
/*      */   static final String DEFAULT_CONNECT_STRING = "localhost:1521:orcl";
/*      */   static final int REFCURSOR_SIZE = 5;
/*  119 */   long LOGON_MODE = 0L;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   boolean isLoggedOn;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean useZeroCopyIO;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   boolean useLobPrefetch;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private String password;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   Communication net;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   int eocs;
/*      */ 
/*      */ 
/*      */   
/*  153 */   private NTFEventListener[] ltxidListeners = new NTFEventListener[0];
/*      */   
/*  155 */   private NTFEventListener[] xsListeners = new NTFEventListener[0];
/*      */ 
/*      */ 
/*      */   
/*  159 */   NTFEventListener pdbChangeListener = null;
/*      */   
/*      */   boolean readAsNonStream;
/*      */   
/*      */   T4CTTIoer oer;
/*      */   
/*      */   T4CMAREngine mare;
/*      */   
/*      */   T4C8TTIpro pro;
/*      */   
/*      */   T4CTTIrxd rxd;
/*      */   
/*      */   T4CTTIsto sto;
/*      */   
/*      */   T4CTTIspfp spfp;
/*      */   
/*      */   T4CTTIoauthenticate auth;
/*      */   
/*      */   T4C8Odscrarr describe;
/*      */   
/*      */   T4C8Oall all8;
/*      */   T4C8Oclose close8;
/*      */   T4C7Ocommoncall commoncall;
/*      */   T4Caqe aqe;
/*      */   T4Caqdq aqdq;
/*      */   T4CTTIoaqenq oaqenq;
/*      */   T4CTTIoaqdeq oaqdeq;
/*      */   T4CTTIkpdnrdeq kpdnrdeq;
/*      */   T4C8TTIBfile bfileMsg;
/*      */   T4C8TTIBlob blobMsg;
/*      */   T4C8TTIClob clobMsg;
/*      */   T4CTTIoses oses;
/*      */   T4CTTIoping oping;
/*      */   T4CTTIokpn okpn;
/*  193 */   byte[] EMPTY_BYTE = new byte[0];
/*      */   
/*      */   T4CTTIOtxen otxen;
/*      */   
/*      */   T4CTTIOtxse otxse;
/*      */   
/*      */   T4CTTIk2rpc k2rpc;
/*      */   T4CTTIoscid oscid;
/*      */   T4CTTIokeyval okeyval;
/*      */   T4CTTIoxsscs oxsscs;
/*      */   T4CTTIoxssro oxssro;
/*      */   T4CTTIoxsspo oxsspo;
/*      */   T4CTTIxsnsop xsnsop;
/*      */   T4CTTIosesstate osesstate;
/*      */   T4CTTIoappcontreplay oappcontreplay;
/*      */   T4CTTIoxsns xsnsop2;
/*      */   T4CTTIoxscre oxscre;
/*      */   T4CTTIoxsdes oxsdes;
/*      */   T4CTTIoxsdet oxsdet;
/*      */   T4CTTIoxsatt oxsatt;
/*      */   T4CTTIoxsset oxsset;
/*      */   T4CTTIosessrls osessrls;
/*      */   T4CTTIosessget osessget;
/*      */   T4CTTIocsessret ocsessret;
/*      */   int[] cursorToClose;
/*      */   int cursorToCloseOffset;
/*      */   int[] queryToClose;
/*      */   int queryToCloseOffset;
/*      */   int[] lusFunctionId2;
/*      */   byte[][] lusSessionId2;
/*      */   KeywordValueLong[][] lusInKeyVal2;
/*      */   int[] lusInFlags2;
/*      */   int lusOffset2;
/*      */   long ossestateOperations;
/*      */   static final int DIRECTIVE_REPLAY_ENABLED = 4;
/*      */   EnumSet<ReplayMode> replayModes;
/*      */   OracleConnection.EndReplayCallback endReplayCallback;
/*      */   ReplayContext[] oappcontreplayContextsArr;
/*      */   int oappcontreplayOffset;
/*      */   int sessionId;
/*      */   int serialNumber;
/*      */   byte negotiatedTTCversion;
/*      */   byte[] serverRuntimeCapabilities;
/*      */   byte[] serverCompileTimeCapabilities;
/*      */   Hashtable namespaces;
/*      */   byte[] internalName;
/*      */   byte[] externalName;
/*      */   static final int FREE = -1;
/*      */   static final int SEND = 1;
/*      */   static final int RECEIVE = 2;
/*      */   
/*      */   enum ReplayMode
/*      */   {
/*  246 */     RUNTIME_REPLAY_ENABLED,
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  251 */     RUNTIME_OR_REPLAYING_STATIC,
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  260 */     NONREQUEST,
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  268 */     REPLAYING;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  305 */   int pipeState = -1;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   boolean sentCancel = false;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   String currentSchema;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   int maxNonStreamBindByteSize;
/*      */ 
/*      */ 
/*      */   
/*      */   boolean cancelInProgressFlag = false;
/*      */ 
/*      */ 
/*      */   
/*      */   boolean statementCancel = true;
/*      */ 
/*      */ 
/*      */   
/*      */   String databaseUniqueIdentifier;
/*      */ 
/*      */ 
/*      */   
/*  336 */   static final Map<String, String[]> cachedVersionTable = (Map)new Hashtable<>();
/*      */ 
/*      */   
/*  339 */   byte currentTTCSeqNumber = 0;
/*      */ 
/*      */   
/*      */   short[] ttiList;
/*      */ 
/*      */   
/*  345 */   short executingRPCFunctionCode = 0; String executingRPCSQL; private final CRC32 checksumEngine;
/*      */   private final Hashtable<Long, Integer> tempLobRefCount;
/*      */   static final int MAX_SIZE_VSESSION_OSUSER = 30;
/*      */   static final int MAX_SIZE_VSESSION_PROCESS = 24;
/*      */   static final int MAX_SIZE_VSESSION_MACHINE = 64;
/*      */   static final int MAX_SIZE_VSESSION_TERMINAL = 30;
/*      */   static final int MAX_SIZE_VSESSION_PROGRAM = 48;
/*      */   
/*      */   public short getExecutingRPCFunctionCode() {
/*  354 */     return this.executingRPCFunctionCode;
/*      */   }
/*      */ 
/*      */   
/*      */   void setExecutingRPCFunctionCode(short paramShort) {
/*  359 */     this.executingRPCFunctionCode = paramShort;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void setExecutingRPCSQL(String paramString) {
/*  366 */     this.executingRPCSQL = paramString;
/*      */   }
/*      */   void additionalInitialization() throws SQLException { this.cursorToClose = new int[4]; this.cursorToCloseOffset = 0; this.queryToClose = new int[10]; this.queryToCloseOffset = 0; this.lusFunctionId2 = new int[10]; this.lusSessionId2 = new byte[10][]; this.lusInKeyVal2 = new KeywordValueLong[10][]; this.lusInFlags2 = new int[10]; this.lusOffset2 = 0; this.replayModes = EnumSet.noneOf(ReplayMode.class); this.ossestateOperations = -1L; this.endReplayCallback = null; this.oappcontreplayOffset = 0; this.oappcontreplayContextsArr = null; this.minVcsBindSize = 0; this.namespaces = new Hashtable<>(5); this.currentSchema = null; this.ttiList = new short[128]; }
/*      */   final void initializePassword(String paramString) throws SQLException { this.password = paramString; }
/*  370 */   void logon() throws SQLException { SQLException sQLException = null; try { if (this.isLoggedOn) { SQLException sQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 428); sQLException1.fillInStackTrace(); throw sQLException1; }  if (this.database == null) this.database = "localhost:1521:orcl";  connect(this.database); this.all8 = new T4C8Oall(this); this.okpn = new T4CTTIokpn(this); this.close8 = new T4C8Oclose(this); this.sto = new T4CTTIsto(this); this.spfp = new T4CTTIspfp(this); this.commoncall = new T4C7Ocommoncall(this); this.describe = new T4C8Odscrarr(this); this.bfileMsg = new T4C8TTIBfile(this); this.blobMsg = new T4C8TTIBlob(this); this.clobMsg = new T4C8TTIClob(this); this.otxen = new T4CTTIOtxen(this); this.otxse = new T4CTTIOtxse(this); this.oping = new T4CTTIoping(this); this.k2rpc = new T4CTTIk2rpc(this); this.oses = new T4CTTIoses(this); this.okeyval = new T4CTTIokeyval(this); this.oxssro = new T4CTTIoxssro(this); this.oxsspo = new T4CTTIoxsspo(this); this.oxsscs = new T4CTTIoxsscs(this); this.oxscre = new T4CTTIoxscre(this); this.oxsdes = new T4CTTIoxsdes(this); this.oxsatt = new T4CTTIoxsatt(this); this.xsnsop = new T4CTTIxsnsop(this); this.xsnsop2 = new T4CTTIoxsns(this); this.oxsdet = new T4CTTIoxsdet(this); this.oxsset = new T4CTTIoxsset(this); this.aqe = new T4Caqe(this); this.aqdq = new T4Caqdq(this); this.oscid = new T4CTTIoscid(this); this.osessrls = new T4CTTIosessrls(this); this.ocsessret = new T4CTTIocsessret(this); this.osessget = new T4CTTIosessget(this); this.oaqenq = new T4CTTIoaqenq(this); this.oaqdeq = new T4CTTIoaqdeq(this); this.kpdnrdeq = new T4CTTIkpdnrdeq(this); this.osesstate = new T4CTTIosesstate(this); this.oappcontreplay = new T4CTTIoappcontreplay(this); this.LOGON_MODE = 0L; if (this.internalLogon != null) if (this.internalLogon.equalsIgnoreCase("sysoper")) { this.LOGON_MODE = 64L; } else if (this.internalLogon.equalsIgnoreCase("sysdba")) { this.LOGON_MODE = 32L; } else if (this.internalLogon.equalsIgnoreCase("sysasm")) { this.LOGON_MODE = 4194304L; } else if (this.internalLogon.equalsIgnoreCase("sysbackup")) { this.LOGON_MODE = 16777216L; } else if (this.internalLogon.equalsIgnoreCase("sysdg")) { this.LOGON_MODE = 33554432L; } else if (this.internalLogon.equalsIgnoreCase("syskm")) { this.LOGON_MODE = 67108864L; }   if (this.prelimAuth) this.LOGON_MODE |= 0x80L;  this.auth = new T4CTTIoauthenticate(this, this.resourceManagerId, this.serverCompileTimeCapabilities); if (this.userName != null && this.userName.length() != 0) try { this.auth.doOSESSKEY(this.userName, this.LOGON_MODE); } catch (SQLException sQLException1) { if (sQLException1.getErrorCode() == 1017) { sQLException = sQLException1; this.userName = null; } else { throw sQLException1; }  }   this.auth.doOAUTH(this.userName, this.password, this.LOGON_MODE); this.sessionId = getSessionId(); this.serialNumber = getSerialNumber(); this.internalName = this.auth.internalName; this.externalName = this.auth.externalName; this.instanceName = this.sessionProperties.getProperty("AUTH_INSTANCENAME"); this.dbName = this.sessionProperties.getProperty("AUTH_DBNAME"); this.databaseUniqueIdentifier = this.sessionProperties.getProperty("AUTH_DB_ID"); String str = (String)this.sessionProperties.get("AUTH_SC_INSTANCE_START_TIME"); String[] arrayOfString = null; if (this.drcpEnabled && this.databaseUniqueIdentifier != null) arrayOfString = cachedVersionTable.get(this.databaseUniqueIdentifier + str);  if (!this.prelimAuth && !this.jmsNotificationConnection && arrayOfString == null) { T4C7Oversion t4C7Oversion = new T4C7Oversion(this); t4C7Oversion.doOVERSION(); byte[] arrayOfByte = t4C7Oversion.getVersion(); try { this.databaseProductVersion = new String(arrayOfByte, "UTF8"); } catch (UnsupportedEncodingException unsupportedEncodingException) { SQLException sQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), unsupportedEncodingException); sQLException1.fillInStackTrace(); throw sQLException1; }  this.versionNumber = t4C7Oversion.getVersionNumber(); if (this.drcpEnabled && this.databaseUniqueIdentifier != null) { arrayOfString = new String[] { this.databaseProductVersion, String.valueOf(this.versionNumber) }; cachedVersionTable.put(this.databaseUniqueIdentifier + str, arrayOfString); detachServerConnection((String)null); }  } else if (arrayOfString == null) { this.versionNumber = 0; } else { this.databaseProductVersion = arrayOfString[0]; this.versionNumber = Short.parseShort(arrayOfString[1]); }  this.isLoggedOn = true; if (getVersionNumber() < 11000) this.enableTempLobRefCnt = false;  } catch (NetException netException) { SQLException sQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), (IOException)netException); sQLException1.fillInStackTrace(); throw sQLException1; } catch (IOException iOException) { handleIOException(iOException); SQLException sQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException); sQLException1.fillInStackTrace(); throw sQLException1; } catch (SQLException sQLException1) { if (sQLException != null) sQLException1.initCause(sQLException);  try { this.net.disconnect(); } catch (Exception exception) {} this.isLoggedOn = false; throw sQLException1; }  } void handleIOException(IOException paramIOException) throws SQLException { try { this.pipeState = -1; this.net.disconnect(); this.net = null; } catch (Exception exception) {} this.isLoggedOn = false; this.lifecycle = 4; } synchronized void logoff() throws SQLException { try { assertLoggedOn("T4CConnection.logoff"); if (this.lifecycle == 8) return;  this.commoncall.doOLOGOFF(); this.net.disconnect(); this.net = null; } catch (IOException iOException) { handleIOException(iOException); if (this.lifecycle != 8) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException); sQLException.fillInStackTrace(); throw sQLException; }  } finally { try { if (this.net != null) this.net.disconnect();  } catch (Exception exception) {} this.isLoggedOn = false; }  } T4CMAREngine getMarshalEngine() { return this.mare; } synchronized void doCommit(int paramInt) throws SQLException { assertLoggedOn("T4CConnection.do_commit"); try { if (paramInt == 0) { this.commoncall.doOCOMMIT(); } else { int i = 0; if ((paramInt & OracleConnection.CommitOption.WRITEBATCH.getCode()) != 0) { i = i | 0x2 | 0x1; } else if ((paramInt & OracleConnection.CommitOption.WRITEIMMED.getCode()) != 0) { i |= 0x2; }  if ((paramInt & OracleConnection.CommitOption.NOWAIT.getCode()) != 0) { i = i | 0x8 | 0x4; } else if ((paramInt & OracleConnection.CommitOption.WAIT.getCode()) != 0) { i |= 0x8; }  this.otxen.doOTXEN(1, null, null, 0, 0, 0, 0, 4, i); int j = this.otxen.getOutStateFromServer(); if (j == 2 || j != 4); }  } catch (IOException iOException) { handleIOException(iOException); SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException); sQLException.fillInStackTrace(); throw sQLException; }  } synchronized void doRollback() throws SQLException { try { assertLoggedOn("T4CConnection.do_rollback"); this.commoncall.doOROLLBACK(); } catch (IOException iOException) { handleIOException(iOException); SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException); sQLException.fillInStackTrace(); throw sQLException; }  } synchronized void doSetAutoCommit(boolean paramBoolean) throws SQLException { if (this.autoCommitSpecCompliant && paramBoolean && getTransactionState().contains(OracleConnection.TransactionState.TRANSACTION_STARTED)) commit();  this.autocommit = paramBoolean; } public String getExecutingRPCSQL() { return this.executingRPCSQL; }
/*      */   synchronized void open(OracleStatement paramOracleStatement) throws SQLException { assertLoggedOn("T4CConnection.open"); paramOracleStatement.setCursorId(0); }
/*      */   synchronized String doGetDatabaseProductVersion() throws SQLException { assertLoggedOn("T4CConnection.do_getDatabaseProductVersion"); T4C7Oversion t4C7Oversion = new T4C7Oversion(this); try { t4C7Oversion.doOVERSION(); } catch (IOException iOException) { handleIOException(iOException); SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException); sQLException.fillInStackTrace(); throw sQLException; }  String str = null; byte[] arrayOfByte = t4C7Oversion.getVersion(); try { str = new String(arrayOfByte, "UTF8"); } catch (UnsupportedEncodingException unsupportedEncodingException) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), unsupportedEncodingException); sQLException.fillInStackTrace(); throw sQLException; }  return str; }
/*      */   synchronized short doGetVersionNumber() throws SQLException { assertLoggedOn("T4CConnection.do_getVersionNumber"); T4C7Oversion t4C7Oversion = new T4C7Oversion(this); try { t4C7Oversion.doOVERSION(); } catch (IOException iOException) { handleIOException(iOException); SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException); sQLException.fillInStackTrace(); throw sQLException; }  return t4C7Oversion.getVersionNumber(); }
/*      */   OracleStatement RefCursorBytesToStatement(byte[] paramArrayOfbyte, OracleStatement paramOracleStatement) throws SQLException { T4CStatement t4CStatement = new T4CStatement(this, -1, -1); try { int i = this.mare.unmarshalRefCursor(paramArrayOfbyte); t4CStatement.setCursorId(i); t4CStatement.isOpen = true; t4CStatement.sqlObject = paramOracleStatement.sqlObject; t4CStatement.serverCursor = true; paramOracleStatement.addChild(t4CStatement); t4CStatement.prepareForNewResults(true, false, true); } catch (IOException iOException) { handleIOException(iOException); SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException); sQLException.fillInStackTrace(); throw sQLException; }  t4CStatement.needToParse = false; return t4CStatement; }
/*      */   OracleStatement createImplicitResultSetStatement(OracleStatement paramOracleStatement) throws SQLException { T4CStatement t4CStatement = new T4CStatement(this, -1, -1); t4CStatement.sqlObject = paramOracleStatement.sqlObject; t4CStatement.sqlKind = OracleStatement.SqlKind.SELECT; t4CStatement.numberOfDefinePositions = paramOracleStatement.numberOfDefinePositions; t4CStatement.isOpen = paramOracleStatement.isOpen; t4CStatement.prepareForNewResults(true, false, true); paramOracleStatement.addImplicitResultSetStmt(t4CStatement); return t4CStatement; }
/*      */   void cancelOperationOnServer(boolean paramBoolean) throws SQLException { synchronized (this.cancelInProgressLockForThin) { if (!this.cancelInProgressFlag) { try { switch (this.pipeState) { case -1: return;case 1: this.net.sendBreak(); break;case 2: this.net.sendInterrupt(); break; }  this.sentCancel = true; } catch (NetException netException) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), (IOException)netException); sQLException.fillInStackTrace(); throw sQLException; } catch (IOException iOException) { handleIOException(iOException); SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException); sQLException.fillInStackTrace(); throw sQLException; }  this.cancelInProgressFlag = true; this.statementCancel = paramBoolean; }  }  }
/*      */   void connect(String paramString) throws IOException, SQLException { if (paramString == null) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 433); sQLException.fillInStackTrace(); throw sQLException; }  Properties properties = new Properties(); if (this.thinNetProfile != null) properties.setProperty("oracle.net.profile", this.thinNetProfile);  if (this.thinNetAuthenticationServices != null) properties.setProperty("oracle.net.authentication_services", this.thinNetAuthenticationServices);  if (this.thinNetAuthenticationKrb5Mutual != null) properties.setProperty("oracle.net.kerberos5_mutual_authentication", this.thinNetAuthenticationKrb5Mutual);  if (this.thinNetAuthenticationKrb5CcName != null) properties.setProperty("oracle.net.kerberos5_cc_name", this.thinNetAuthenticationKrb5CcName);  if (this.thinNetEncryptionLevel != null) properties.setProperty("oracle.net.encryption_client", this.thinNetEncryptionLevel);  if (this.thinNetEncryptionTypes != null) properties.setProperty("oracle.net.encryption_types_client", this.thinNetEncryptionTypes);  if (this.thinNetChecksumLevel != null) properties.setProperty("oracle.net.crypto_checksum_client", this.thinNetChecksumLevel);  if (this.thinNetChecksumTypes != null) properties.setProperty("oracle.net.crypto_checksum_types_client", this.thinNetChecksumTypes);  if (this.thinNetCryptoSeed != null) properties.setProperty("oracle.net.crypto_seed", this.thinNetCryptoSeed);  if (this.thinTcpNoDelay) properties.setProperty("TCP.NODELAY", "YES");  if (this.thinReadTimeout != null) properties.setProperty("oracle.net.READ_TIMEOUT", this.thinReadTimeout);  if (this.thinNetConnectTimeout != null) properties.setProperty("oracle.net.CONNECT_TIMEOUT", this.thinNetConnectTimeout);  if (this.thinSslServerDnMatch != null) properties.setProperty("oracle.net.ssl_server_dn_match", this.thinSslServerDnMatch);  if (this.walletLocation != null) properties.setProperty("oracle.net.wallet_location", this.walletLocation);  if (this.walletPassword != null) properties.setProperty("oracle.net.wallet_password", this.walletPassword);  if (this.thinSslVersion != null) properties.setProperty("oracle.net.ssl_version", this.thinSslVersion);  if (this.thinSslCipherSuites != null) properties.setProperty("oracle.net.ssl_cipher_suites", this.thinSslCipherSuites);  if (this.thinJavaxNetSslKeystore != null) properties.setProperty("javax.net.ssl.keyStore", this.thinJavaxNetSslKeystore);  if (this.thinJavaxNetSslKeystoretype != null) properties.setProperty("javax.net.ssl.keyStoreType", this.thinJavaxNetSslKeystoretype);  if (this.thinJavaxNetSslKeystorepassword != null) properties.setProperty("javax.net.ssl.keyStorePassword", this.thinJavaxNetSslKeystorepassword);  if (this.thinJavaxNetSslTruststore != null) properties.setProperty("javax.net.ssl.trustStore", this.thinJavaxNetSslTruststore);  if (this.thinJavaxNetSslTruststoretype != null) properties.setProperty("javax.net.ssl.trustStoreType", this.thinJavaxNetSslTruststoretype);  if (this.thinJavaxNetSslTruststorepassword != null) properties.setProperty("javax.net.ssl.trustStorePassword", this.thinJavaxNetSslTruststorepassword);  if (this.thinSslKeymanagerfactoryAlgorithm != null) properties.setProperty("ssl.keyManagerFactory.algorithm", this.thinSslKeymanagerfactoryAlgorithm);  if (this.thinSslTrustmanagerfactoryAlgorithm != null) properties.setProperty("ssl.trustManagerFactory.algorithm", this.thinSslTrustmanagerfactoryAlgorithm);  if (this.thinNetOldsyntax != null) properties.setProperty("oracle.net.oldSyntax", this.thinNetOldsyntax);  if (this.thinNamingContextInitial != null) properties.setProperty("java.naming.factory.initial", this.thinNamingContextInitial);  if (this.thinNamingProviderUrl != null) properties.setProperty("java.naming.provider.url", this.thinNamingProviderUrl);  if (this.thinNamingSecurityAuthentication != null) properties.setProperty("java.naming.security.authentication", this.thinNamingSecurityAuthentication);  if (this.thinNamingSecurityPrincipal != null) properties.setProperty("java.naming.security.principal", this.thinNamingSecurityPrincipal);  if (this.thinNamingSecurityCredentials != null)
/*      */       properties.setProperty("java.naming.security.credentials", this.thinNamingSecurityCredentials);  if (this.thinJndiLdapConnectTimeout != null)
/*      */       properties.setProperty("com.sun.jndi.ldap.connect.timeout", this.thinJndiLdapConnectTimeout);  if (this.thinJndiLdapReadTimeout != null)
/*      */       properties.setProperty("com.sun.jndi.ldap.read.timeout", this.thinJndiLdapReadTimeout);  if (this.thinNetDisableOutOfBandBreak)
/*      */       properties.setProperty("DISABLE_OOB", "" + this.thinNetDisableOutOfBandBreak);  properties.setProperty("USE_ZERO_COPY_IO", "" + this.thinNetUseZeroCopyIO); properties.setProperty("FORCE_DNS_LOAD_BALANCING", "" + this.thinForceDnsLoadBalancing); properties.setProperty("oracle.jdbc.v$session.osuser", this.thinVsessionOsuser); properties.setProperty("oracle.jdbc.v$session.program", this.thinVsessionProgram); properties.setProperty("T4CConnection.hashCode", Integer.toHexString(hashCode()).toUpperCase()); properties.setProperty("oracle.net.keepAlive", Boolean.toString(this.keepAlive)); properties.setProperty("oracle.jdbc.useNio", Boolean.toString(this.javaNetNio)); if (this.targetInstanceName != null)
/*      */       properties.setProperty("oracle.jdbc.targetInstanceName", this.targetInstanceName);  if (this.javaNetNio) { this.net = (Communication)new NSProtocolNIO(this.nsDirectBuffer); } else { this.net = (Communication)new NSProtocolStream(); }  this.net.connect(paramString, properties); if (this.javaNetNio) { this.mare = new T4CMAREngineNIO(this.net); } else { this.mare = new T4CMAREngineStream(this.net); }  this.oer = new T4CTTIoer(this); this.mare.setConnectionDuringExceptionHandling(this); this.pro = new T4C8TTIpro(this); this.pro.marshal(); this.serverCompileTimeCapabilities = this.pro.receive(); this.serverRuntimeCapabilities = this.pro.getServerRuntimeCapabilities(); short s1 = this.pro.getOracleVersion(); short s2 = this.pro.getCharacterSet(); short s3 = DBConversion.findDriverCharSet(s2, s1); this.conversion = new DBConversion(s2, s3, this.pro.getncharCHARSET(), this.isStrictAsciiConversion); this.mare.types.setServerConversion(!(s3 == s2)); if (DBConversion.isCharSetMultibyte(s3)) { if (DBConversion.isCharSetMultibyte(this.pro.getCharacterSet())) { this.mare.types.setFlags((byte)1); } else { this.mare.types.setFlags((byte)2); }  } else { this.mare.types.setFlags(this.pro.getFlags()); }  this.mare.conv = this.conversion; if (this.serverCompileTimeCapabilities.length > 37 && bit(this.serverCompileTimeCapabilities[37], 32))
/*      */       this.mare.setUseCLRBigChunks(true);  T4C8TTIdty t4C8TTIdty = new T4C8TTIdty(this, this.serverCompileTimeCapabilities, this.serverRuntimeCapabilities, (this.logonCap != null && this.logonCap.trim().equals("o3")), this.thinNetUseZeroCopyIO); t4C8TTIdty.doRPC(); this.negotiatedTTCversion = this.serverCompileTimeCapabilities[7]; if (t4C8TTIdty.jdbcThinCompileTimeCapabilities[7] < this.serverCompileTimeCapabilities[7])
/*      */       this.negotiatedTTCversion = t4C8TTIdty.jdbcThinCompileTimeCapabilities[7];  if (this.serverRuntimeCapabilities != null && this.serverRuntimeCapabilities.length > 6 && (this.serverRuntimeCapabilities[6] & T4C8TTIdty.KPCCAP_RTB_TTC_ZCPY) != 0 && this.thinNetUseZeroCopyIO && (this.net.getSessionAttributes().getNegotiatedOptions() & 0x40) != 0 && getDataIntegrityAlgorithmName().equals("") && getEncryptionAlgorithmName().equals("")) { this.useZeroCopyIO = true; } else { this.useZeroCopyIO = false; }  if (this.serverCompileTimeCapabilities.length > 23 && bit(this.serverCompileTimeCapabilities[23], 64) && bit(t4C8TTIdty.jdbcThinCompileTimeCapabilities[23], 64)) { this.useLobPrefetch = true; } else { this.useLobPrefetch = false; }  if (this.serverRuntimeCapabilities != null && this.serverRuntimeCapabilities.length > T4C8TTIdty.KPCCAP_RTB_TTC && bit(this.serverRuntimeCapabilities[T4C8TTIdty.KPCCAP_RTB_TTC], T4C8TTIdty.KPCCAP_RTB_TTC_32K)) { this.maxNonStreamBindByteSize = 32767; this.varTypeMaxLenCompat = 2; } else { this.maxNonStreamBindByteSize = 4000; this.varTypeMaxLenCompat = 1; }  }
/*  385 */   boolean isZeroCopyIOEnabled() { return this.useZeroCopyIO; } T4CConnection(String paramString, Properties paramProperties, OracleDriverExtension paramOracleDriverExtension) throws SQLException { super(paramString, paramProperties, paramOracleDriverExtension);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 3215 */     this.checksumEngine = new CRC32();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 3232 */     this.tempLobRefCount = new Hashtable<>(); } final T4CTTIoer getT4CTTIoer() { return this.oer; } final byte getTTCVersion() { return this.negotiatedTTCversion; } void doStartup(int paramInt) throws SQLException { try { byte b = 0; if (paramInt == OracleConnection.DatabaseStartupMode.FORCE.getMode()) { b = 16; } else if (paramInt == OracleConnection.DatabaseStartupMode.RESTRICT.getMode()) { b = 1; }  this.spfp.doOSPFPPUT(); this.sto.doOV6STRT(b); } catch (IOException iOException) { handleIOException(iOException); SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException); sQLException.fillInStackTrace(); throw sQLException; }  } void doShutdown(int paramInt) throws SQLException { try { char c = '\004'; if (paramInt == OracleConnection.DatabaseShutdownMode.TRANSACTIONAL.getMode()) { c = ''; } else if (paramInt == OracleConnection.DatabaseShutdownMode.TRANSACTIONAL_LOCAL.getMode()) { c = 'Ā'; } else if (paramInt == OracleConnection.DatabaseShutdownMode.IMMEDIATE.getMode()) { c = '\002'; } else if (paramInt == OracleConnection.DatabaseShutdownMode.FINAL.getMode()) { c = '\b'; } else if (paramInt == OracleConnection.DatabaseShutdownMode.ABORT.getMode()) { c = '@'; }  this.sto.doOV6STOP(c); } catch (IOException iOException) { handleIOException(iOException); SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException); sQLException.fillInStackTrace(); throw sQLException; }  } void checkEndReplayCallback() throws SQLException { if (this.endReplayCallback != null && this.oappcontreplayContextsArr == null) { OracleConnection.EndReplayCallback endReplayCallback = this.endReplayCallback; this.endReplayCallback = null; T4C8Oall t4C8Oall1 = new T4C8Oall(this); T4C8Oall t4C8Oall2 = this.all8; this.all8 = t4C8Oall1; try { endReplayCallback.executeCallback(); } finally { this.all8 = t4C8Oall2; }  }  } void sendPiggyBackedMessages() throws SQLException, IOException { checkEndReplayCallback(); if (this.queryToCloseOffset > 0) { this.close8.doOCANA(this.queryToClose, this.queryToCloseOffset); this.queryToCloseOffset = 0; }  if (this.cursorToCloseOffset > 0) { this.close8.doOCCA(this.cursorToClose, this.cursorToCloseOffset); this.cursorToCloseOffset = 0; }  if (this.endToEndAnyChanged && getTTCVersion() >= 3) { this.oscid.doOSCID(this.endToEndHasChanged, this.endToEndValues, this.endToEndECIDSequenceNumber); for (byte b = 0; b < 5; b++) { if (this.endToEndHasChanged[b]) this.endToEndHasChanged[b] = false;  }  }  this.endToEndAnyChanged = false; if (!this.namespaces.isEmpty()) { if (getTTCVersion() >= 4) { Object[] arrayOfObject = this.namespaces.values().toArray(); for (byte b = 0; b < arrayOfObject.length; b++) this.okeyval.doOKEYVAL((Namespace)arrayOfObject[b]);  }  this.namespaces.clear(); }  if (this.lusOffset2 > 0) { for (byte b = 0; b < this.lusOffset2; b++) this.oxsspo.doOXSSPO(this.lusFunctionId2[b], this.lusSessionId2[b], this.lusInKeyVal2[b], this.lusInFlags2[b]);  this.lusOffset2 = 0; }  assert !this.replayModes.contains(ReplayMode.RUNTIME_REPLAY_ENABLED) || !this.replayModes.contains(ReplayMode.REPLAYING) : "RUNTIME_REPLAY_ENABLED and REPLAYING modes cannot bet set at the same time"; if (this.replayModes.contains(ReplayMode.NONREQUEST)) { if (this.replayModes.contains(ReplayMode.RUNTIME_REPLAY_ENABLED)) { if (this.ossestateOperations == -1L) this.ossestateOperations = 0L;  this.ossestateOperations |= OracleConnection.ReplayOperation.KPDSS_SESSSTATE_NONREQUEST_CALL.getCode() | OracleConnection.ReplayOperation.KPDSS_SESSSTATE_APPCONT_ENABLED.getCode(); } else if (this.replayModes.contains(ReplayMode.REPLAYING)) { this.ossestateOperations = OracleConnection.ReplayOperation.KPDSS_SESSSTATE_NONREQUEST_CALL.getCode(); }  if (this.replayModes.contains(ReplayMode.RUNTIME_OR_REPLAYING_STATIC)) this.ossestateOperations |= OracleConnection.ReplayOperation.KPDSS_SESSSTATE_STATIC.getCode();  }  if (this.ossestateOperations >= 0L) this.osesstate.doOSESSSTATE(this.ossestateOperations);  this.ossestateOperations = -1L; if (!this.replayModes.contains(ReplayMode.NONREQUEST) && this.oappcontreplayContextsArr != null) { while (this.oappcontreplayOffset < this.oappcontreplayContextsArr.length - 1 && this.oappcontreplayContextsArr[this.oappcontreplayOffset] == null) this.oappcontreplayOffset++;  if (this.oappcontreplayContextsArr[this.oappcontreplayOffset] != null && this.oappcontreplayContextsArr[this.oappcontreplayOffset].getContext() != null) this.oappcontreplay.doOAPPCONTREPLAY(this.oappcontreplayContextsArr[this.oappcontreplayOffset]);  if (this.oappcontreplayOffset == this.oappcontreplayContextsArr.length - 1) { this.oappcontreplayContextsArr = null; } else { this.oappcontreplayOffset++; }  }  } synchronized void closeCursor(int paramInt) throws SQLException { if (this.cursorToCloseOffset == this.cursorToClose.length) { int[] arrayOfInt = new int[this.cursorToClose.length * 2]; System.arraycopy(this.cursorToClose, 0, arrayOfInt, 0, this.cursorToClose.length); this.cursorToClose = arrayOfInt; }  this.cursorToClose[this.cursorToCloseOffset++] = paramInt; } void doProxySession(int paramInt, Properties paramProperties) throws SQLException { try { this.auth.doOAUTH(paramInt, paramProperties, this.sessionId, this.serialNumber); int i = getSessionId(); int j = getSerialNumber(); this.oses.doO80SES(i, j, 1); this.savedUser = this.userName; if (paramInt == 1) { this.userName = paramProperties.getProperty("PROXY_USER_NAME"); } else { this.userName = null; }  this.isProxy = true; } catch (IOException iOException) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException); sQLException.fillInStackTrace(); throw sQLException; }  } void closeProxySession() throws SQLException { try { this.commoncall.doOLOGOFF(); this.oses.doO80SES(this.sessionId, this.serialNumber, 1); this.userName = this.savedUser; } catch (IOException iOException) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException); sQLException.fillInStackTrace(); throw sQLException; }  } void updateSessionProperties(KeywordValue[] paramArrayOfKeywordValue) throws SQLException { for (byte b = 0; b < paramArrayOfKeywordValue.length; b++) { int i = paramArrayOfKeywordValue[b].getKeyword(); byte[] arrayOfByte = paramArrayOfKeywordValue[b].getBinaryValue(); if (i < T4C8Oall.NLS_KEYS.length) { String str = T4C8Oall.NLS_KEYS[i]; if (str != null) if (arrayOfByte != null) { this.sessionProperties.setProperty(str, this.mare.conv.CharBytesToString(arrayOfByte, arrayOfByte.length)); } else if (paramArrayOfKeywordValue[b].getTextValue() != null) { this.sessionProperties.setProperty(str, paramArrayOfKeywordValue[b].getTextValue().trim()); }   } else if (i == 163) { if (arrayOfByte != null) { int j = arrayOfByte[4]; int k = arrayOfByte[5]; if ((arrayOfByte[4] & 0xFF) > 120) { int m = (arrayOfByte[4] & 0xFF) - 181; int n = (arrayOfByte[5] & 0xFF) - 60; } else { j = (arrayOfByte[4] & 0xFF) - 60; k = (arrayOfByte[5] & 0xFF) - 60; }  String str = ((j > 0) ? "+" : "") + j + ((k <= 9) ? ":0" : ":") + k; this.sessionProperties.setProperty("SESSION_TIME_ZONE", str); }  } else if (i != 165) { if (i != 166) if (i != 167) if (i == 168) { String str = paramArrayOfKeywordValue[b].getTextValue(); if (str != null) this.currentSchema = str.trim();  } else if (i != 169) { if (i != 170) if (i != 171) if (i != 175) if (i != 176) if (i == 177) { this.isPDBChanged = true; long l = 0L; for (byte b1 = 3; b1 >= 0; b1--) l |= (arrayOfByte[3 - b1] & 0xFFL) << 8 * b1;  this.sessionProperties.setProperty("AUTH_DB_ID", String.valueOf(l)); onPDBChange(); } else if (i != 178) { if (i == 179 && paramArrayOfKeywordValue[b].getTextValue() != null) { this.dbName = paramArrayOfKeywordValue[b].getTextValue(); this.sessionProperties.setProperty("AUTH_DBNAME", this.dbName); }  }      }    }  }  } void onPDBChange() throws SQLException { super.onPDBChange(); this.databaseUniqueIdentifier = this.sessionProperties.getProperty("AUTH_DB_ID"); } public void setPDBChangeEventListener(PDBChangeEventListener paramPDBChangeEventListener, Executor paramExecutor) throws SQLException { if (this.lifecycle != 1) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 8); sQLException.fillInStackTrace(); throw sQLException; }  NTFEventListener nTFEventListener = new NTFEventListener(paramPDBChangeEventListener); nTFEventListener.setExecutor(paramExecutor); if (this.pdbChangeListener == null) { this.pdbChangeListener = nTFEventListener; } else { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 248); sQLException.fillInStackTrace(); throw sQLException; }  } public void setPDBChangeEventListener(PDBChangeEventListener paramPDBChangeEventListener) throws SQLException { setPDBChangeEventListener(paramPDBChangeEventListener, (Executor)null); }
/*      */   void notify(final NTFPDBChangeEvent event) { if (this.pdbChangeListener != null) { Executor executor = this.pdbChangeListener.getExecutor(); if (executor != null) { final PDBChangeEventListener l = this.pdbChangeListener.getPDBChangeEventListener(); executor.execute(new Runnable() { public void run() { l.pdbChanged(event); } }
/*      */           ); } else { this.pdbChangeListener.getPDBChangeEventListener().pdbChanged(event); }  }  }
/*      */   public String getCurrentSchema() throws SQLException { if (this.lifecycle != 1) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 8); sQLException.fillInStackTrace(); throw sQLException; }  if (this.currentSchema == null || getVersionNumber() < 11100) this.currentSchema = super.getCurrentSchema();  return this.currentSchema; }
/*      */   public Properties getServerSessionInfo() throws SQLException { if (getVersionNumber() >= 10000 && getVersionNumber() < 10200) queryFCFProperties(this.sessionProperties);  return this.sessionProperties; }
/* 3237 */   private final synchronized Long getLocatorHash(byte[] paramArrayOfbyte) { this.checksumEngine.reset();
/*      */     
/* 3239 */     this.checksumEngine.update(paramArrayOfbyte, 10, 10);
/* 3240 */     long l = this.checksumEngine.getValue();
/* 3241 */     return Long.valueOf(l); } public String getSessionTimeZoneOffset() throws SQLException { String str = getServerSessionInfo().getProperty("SESSION_TIME_ZONE"); if (str == null) { str = super.getSessionTimeZoneOffset(); } else { str = tzToOffset(str); }  return str; } int getSessionId() { int i = -1; String str = this.sessionProperties.getProperty("AUTH_SESSION_ID"); try { i = Integer.parseInt(str); } catch (NumberFormatException numberFormatException) {} return i; } int getSerialNumber() { int i = -1; String str = this.sessionProperties.getProperty("AUTH_SERIAL_NUM"); try { i = Integer.parseInt(str); } catch (NumberFormatException numberFormatException) {} return i; } public byte getInstanceProperty(OracleConnection.InstanceProperty paramInstanceProperty) throws SQLException { byte b = 0; if (paramInstanceProperty == OracleConnection.InstanceProperty.ASM_VOLUME_SUPPORTED) { if (this.serverRuntimeCapabilities == null || this.serverRuntimeCapabilities.length < 6) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 256); sQLException.fillInStackTrace(); throw sQLException; }  b = this.serverRuntimeCapabilities[5]; } else if (paramInstanceProperty == OracleConnection.InstanceProperty.INSTANCE_TYPE) { if (this.serverRuntimeCapabilities == null || this.serverRuntimeCapabilities.length < 4) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 256); sQLException.fillInStackTrace(); throw sQLException; }  b = this.serverRuntimeCapabilities[3]; }  return b; } public synchronized BlobDBAccess createBlobDBAccess() throws SQLException { return this; } public synchronized ClobDBAccess createClobDBAccess() throws SQLException { return this; } public synchronized BfileDBAccess createBfileDBAccess() throws SQLException { return this; } public synchronized long length(BFILE paramBFILE) throws SQLException { assertLoggedOn("length"); assertNotNull(paramBFILE.shareBytes(), "length"); needLine(); long l = 0L; try { l = this.bfileMsg.getLength(paramBFILE.shareBytes()); } catch (IOException iOException) { handleIOException(iOException); SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException); sQLException.fillInStackTrace(); throw sQLException; }  return l; } public synchronized long position(BFILE paramBFILE, byte[] paramArrayOfbyte, long paramLong) throws SQLException { assertNotNull(paramBFILE.shareBytes(), "position"); if (paramLong < 1L) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68, "position()"); sQLException.fillInStackTrace(); throw sQLException; }  long l = LobPlsqlUtil.hasPattern(paramBFILE, paramArrayOfbyte, paramLong); l = (l == 0L) ? -1L : l; return l; } public long position(BFILE paramBFILE1, BFILE paramBFILE2, long paramLong) throws SQLException { assertNotNull(paramBFILE1.shareBytes(), "position"); if (paramLong < 1L) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68, "position()"); sQLException.fillInStackTrace(); throw sQLException; }  long l = LobPlsqlUtil.isSubLob(paramBFILE1, paramBFILE2, paramLong); l = (l == 0L) ? -1L : l; return l; } public synchronized int getBytes(BFILE paramBFILE, long paramLong, int paramInt, byte[] paramArrayOfbyte) throws SQLException { assertLoggedOn("getBytes"); assertNotNull(paramBFILE.shareBytes(), "getBytes"); if (paramLong < 1L) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68, "getBytes()"); sQLException.fillInStackTrace(); throw sQLException; }  if (paramInt <= 0 || paramArrayOfbyte == null) return 0;  if (this.pipeState != -1) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 453, "getBytes()"); sQLException.fillInStackTrace(); throw sQLException; }  needLine(); long l = 0L; if (paramInt != 0) try { l = this.bfileMsg.read(paramBFILE.shareBytes(), paramLong, paramInt, paramArrayOfbyte, 0); } catch (IOException iOException) { handleIOException(iOException); SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException); sQLException.fillInStackTrace(); throw sQLException; }   return (int)l; } public String getName(BFILE paramBFILE) throws SQLException { assertLoggedOn("getName"); assertNotNull(paramBFILE.shareBytes(), "getName"); return LobPlsqlUtil.fileGetName(paramBFILE); } public String getDirAlias(BFILE paramBFILE) throws SQLException { assertLoggedOn("getDirAlias"); assertNotNull(paramBFILE.shareBytes(), "getDirAlias"); return LobPlsqlUtil.fileGetDirAlias(paramBFILE); } public synchronized void openFile(BFILE paramBFILE) throws SQLException { assertLoggedOn("openFile"); assertNotNull(paramBFILE.shareBytes(), "openFile"); needLine(); try { this.bfileMsg.open(paramBFILE.shareBytes(), 11); } catch (IOException iOException) { handleIOException(iOException); SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException); sQLException.fillInStackTrace(); throw sQLException; }  } public synchronized boolean isFileOpen(BFILE paramBFILE) throws SQLException { assertLoggedOn("openFile"); assertNotNull(paramBFILE.shareBytes(), "openFile"); needLine(); boolean bool = false; try { bool = this.bfileMsg.isOpen(paramBFILE.shareBytes()); } catch (IOException iOException) { handleIOException(iOException); SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException); sQLException.fillInStackTrace(); throw sQLException; }  return bool; } public synchronized boolean fileExists(BFILE paramBFILE) throws SQLException { assertLoggedOn("fileExists"); assertNotNull(paramBFILE.shareBytes(), "fileExists"); needLine(); boolean bool = false; try { bool = this.bfileMsg.doesExist(paramBFILE.shareBytes()); } catch (IOException iOException) { handleIOException(iOException); SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException); sQLException.fillInStackTrace(); throw sQLException; }  return bool; } public synchronized void closeFile(BFILE paramBFILE) throws SQLException { assertLoggedOn("closeFile"); assertNotNull(paramBFILE.shareBytes(), "closeFile"); needLine(); try { this.bfileMsg.close(paramBFILE.shareBytes()); } catch (IOException iOException) { handleIOException(iOException); SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException); sQLException.fillInStackTrace(); throw sQLException; }  } public synchronized void open(BFILE paramBFILE, int paramInt) throws SQLException { assertLoggedOn("open"); assertNotNull(paramBFILE.shareBytes(), "open"); needLine(); try { this.bfileMsg.open(paramBFILE.shareBytes(), paramInt); } catch (IOException iOException) { handleIOException(iOException); SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException); sQLException.fillInStackTrace(); throw sQLException; }  } public synchronized void close(BFILE paramBFILE) throws SQLException { assertLoggedOn("close"); assertNotNull(paramBFILE.shareBytes(), "close"); needLine(); try { this.bfileMsg.close(paramBFILE.shareBytes()); } catch (IOException iOException) { handleIOException(iOException); SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException); sQLException.fillInStackTrace(); throw sQLException; }  } public synchronized boolean isOpen(BFILE paramBFILE) throws SQLException { assertLoggedOn("isOpen"); assertNotNull(paramBFILE.shareBytes(), "isOpen"); needLine(); boolean bool = false; try { bool = this.bfileMsg.isOpen(paramBFILE.shareBytes()); } catch (IOException iOException) { handleIOException(iOException); SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException); sQLException.fillInStackTrace(); throw sQLException; }  return bool; } public InputStream newInputStream(BFILE paramBFILE, int paramInt, long paramLong) throws SQLException { return newInputStream((OracleBfile)paramBFILE, paramInt, paramLong); } public InputStream newInputStream(OracleBfile paramOracleBfile, int paramInt, long paramLong) throws SQLException { if (paramLong == 0L) return new OracleBlobInputStream(paramOracleBfile, paramInt);  return new OracleBlobInputStream(paramOracleBfile, paramInt, paramLong); } public InputStream newConversionInputStream(BFILE paramBFILE, int paramInt) throws SQLException { return newConversionInputStream((OracleBfile)paramBFILE, paramInt); }
/*      */   public InputStream newConversionInputStream(OracleBfile paramOracleBfile, int paramInt) throws SQLException { assertNotNull(paramOracleBfile.shareBytes(), "newConversionInputStream"); return new OracleConversionInputStream(this.conversion, paramOracleBfile.getBinaryStream(), paramInt); }
/*      */   public Reader newConversionReader(BFILE paramBFILE, int paramInt) throws SQLException { return newConversionReader((OracleBfile)paramBFILE, paramInt); }
/*      */   public Reader newConversionReader(OracleBfile paramOracleBfile, int paramInt) throws SQLException { assertNotNull(paramOracleBfile.shareBytes(), "newConversionReader"); return new OracleConversionReader(this.conversion, paramOracleBfile.getBinaryStream(), paramInt); }
/*      */   public synchronized long length(BLOB paramBLOB) throws SQLException { assertLoggedOn("length"); assertNotNull(paramBLOB.shareBytes(), "length"); needLine(); long l = 0L; try { l = this.blobMsg.getLength(paramBLOB.shareBytes()); } catch (IOException iOException) { handleIOException(iOException); SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException); sQLException.fillInStackTrace(); throw sQLException; }  return l; }
/*      */   public long position(BLOB paramBLOB, byte[] paramArrayOfbyte, long paramLong) throws SQLException { assertLoggedOn("position"); assertNotNull(paramBLOB.shareBytes(), "position"); if (paramLong < 1L) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68, "position()"); sQLException.fillInStackTrace(); throw sQLException; }  long l = LobPlsqlUtil.hasPattern(paramBLOB, paramArrayOfbyte, paramLong); l = (l == 0L) ? -1L : l; return l; }
/*      */   public long position(BLOB paramBLOB1, BLOB paramBLOB2, long paramLong) throws SQLException { assertLoggedOn("position"); assertNotNull(paramBLOB1.shareBytes(), "position"); assertNotNull(paramBLOB2.shareBytes(), "position"); if (paramLong < 1L) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68, "position()"); sQLException.fillInStackTrace(); throw sQLException; }  long l = LobPlsqlUtil.isSubLob(paramBLOB1, paramBLOB2, paramLong); l = (l == 0L) ? -1L : l; return l; }
/*      */   public synchronized int getBytes(BLOB paramBLOB, long paramLong, int paramInt, byte[] paramArrayOfbyte) throws SQLException { assertLoggedOn("getBytes"); assertNotNull(paramBLOB.shareBytes(), "getBytes"); if (paramLong < 1L) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68, "getBytes()"); sQLException.fillInStackTrace(); throw sQLException; }  if (this.pipeState != -1) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 453, "getBytes()"); sQLException.fillInStackTrace(); throw sQLException; }  if (paramInt <= 0 || paramArrayOfbyte == null) return 0;  long l1 = 0L; long l2 = -1L; if (paramBLOB.isActivePrefetch()) { byte[] arrayOfByte = paramBLOB.getPrefetchedData(); int i = paramBLOB.getPrefetchedDataSize(); l2 = paramBLOB.length(); int j = 0; if (arrayOfByte != null) j = Math.min(i, arrayOfByte.length);  if (j > 0 && paramLong <= j) { int k = Math.min(j - (int)paramLong + 1, paramInt); System.arraycopy(arrayOfByte, (int)paramLong - 1, paramArrayOfbyte, 0, k); l1 += k; }  }  if (l1 < paramInt && (l2 == -1L || paramLong - 1L + l1 < l2)) { needLine(); try { l1 += this.blobMsg.read(paramBLOB.shareBytes(), paramLong + l1, paramInt - l1, paramArrayOfbyte, (int)l1); } catch (IOException iOException) { handleIOException(iOException); SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException); sQLException.fillInStackTrace(); throw sQLException; }  }  return (int)l1; }
/*      */   public synchronized int putBytes(BLOB paramBLOB, long paramLong, byte[] paramArrayOfbyte, int paramInt1, int paramInt2) throws SQLException { assertLoggedOn("putBytes"); assertNotNull(paramBLOB.shareBytes(), "putBytes"); if (paramLong < 1L) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68, "putBytes()"); sQLException.fillInStackTrace(); throw sQLException; }  if (paramArrayOfbyte == null || paramInt2 <= 0) return 0;  needLine(); long l = 0L; if (paramInt2 != 0) try { paramBLOB.setActivePrefetch(false); paramBLOB.clearCachedData(); l = this.blobMsg.write(paramBLOB.shareBytes(), paramLong, paramArrayOfbyte, paramInt1, paramInt2); } catch (IOException iOException) { handleIOException(iOException); SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException); sQLException.fillInStackTrace(); throw sQLException; }   return (int)l; }
/*      */   public synchronized int getChunkSize(BLOB paramBLOB) throws SQLException { assertLoggedOn("getChunkSize"); assertNotNull(paramBLOB.shareBytes(), "getChunkSize"); needLine(); long l = 0L; try { l = this.blobMsg.getChunkSize(paramBLOB.shareBytes()); } catch (IOException iOException) { handleIOException(iOException); SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException); sQLException.fillInStackTrace(); throw sQLException; }  return (int)l; }
/*      */   public synchronized void trim(BLOB paramBLOB, long paramLong) throws SQLException { assertLoggedOn("trim"); assertNotNull(paramBLOB.shareBytes(), "trim"); if (paramLong < 0L) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68, "trim()"); sQLException.fillInStackTrace(); throw sQLException; }  needLine(); try { paramBLOB.setActivePrefetch(false); paramBLOB.clearCachedData(); this.blobMsg.trim(paramBLOB.shareBytes(), paramLong); } catch (IOException iOException) { handleIOException(iOException); SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException); sQLException.fillInStackTrace(); throw sQLException; }  }
/*      */   public synchronized BLOB createTemporaryBlob(Connection paramConnection, boolean paramBoolean, int paramInt) throws SQLException { assertLoggedOn("createTemporaryBlob"); needLine(); BLOB bLOB = null; try { bLOB = (BLOB)this.blobMsg.createTemporaryLob((Connection)this, paramBoolean, paramInt); } catch (IOException iOException) { handleIOException(iOException); SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException); sQLException.fillInStackTrace(); throw sQLException; }  return bLOB; }
/* 3253 */   public final synchronized int decrementTempLobReferenceCount(byte[] paramArrayOfbyte) { int i = 0;
/* 3254 */     if (this.enableTempLobRefCnt && paramArrayOfbyte != null && paramArrayOfbyte.length == 40 && ((paramArrayOfbyte[7] & 0x1) > 0 || (paramArrayOfbyte[4] & 0x40) > 0)) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 3260 */       Long long_ = getLocatorHash(paramArrayOfbyte);
/* 3261 */       Integer integer = this.tempLobRefCount.get(long_);
/* 3262 */       if (integer != null) {
/*      */         
/* 3264 */         i = integer.intValue() - 1;
/* 3265 */         if (i == 0) {
/* 3266 */           this.tempLobRefCount.remove(long_);
/*      */         } else {
/* 3268 */           this.tempLobRefCount.put(long_, Integer.valueOf(i));
/*      */         } 
/*      */       } 
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 3279 */     return i; }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final synchronized void incrementTempLobReferenceCount(byte[] paramArrayOfbyte) {
/* 3285 */     if (this.enableTempLobRefCnt && paramArrayOfbyte != null && paramArrayOfbyte.length == 40 && ((paramArrayOfbyte[7] & 0x1) > 0 || (paramArrayOfbyte[4] & 0x40) > 0)) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 3291 */       Long long_ = getLocatorHash(paramArrayOfbyte);
/* 3292 */       Integer integer = this.tempLobRefCount.get(long_);
/*      */       
/* 3294 */       if (integer != null) {
/*      */         
/* 3296 */         int i = integer.intValue();
/*      */         
/* 3298 */         this.tempLobRefCount.put(long_, Integer.valueOf(i + 1));
/*      */       
/*      */       }
/*      */       else {
/*      */         
/* 3303 */         this.tempLobRefCount.put(long_, Integer.valueOf(1));
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void freeTemporary(BLOB paramBLOB, boolean paramBoolean) throws SQLException {
/* 3320 */     assertLoggedOn("freeTemporary");
/* 3321 */     assertNotNull(paramBLOB.shareBytes(), "freeTemporary");
/*      */     
/* 3323 */     needLine();
/*      */ 
/*      */     
/*      */     try {
/* 3327 */       this.blobMsg.freeTemporaryLob(paramBLOB.shareBytes());
/*      */     }
/* 3329 */     catch (IOException iOException) {
/*      */ 
/*      */       
/* 3332 */       handleIOException(iOException);
/*      */       
/* 3334 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException);
/* 3335 */       sQLException.fillInStackTrace();
/* 3336 */       throw sQLException;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isTemporary(BLOB paramBLOB) throws SQLException {
/* 3355 */     assertNotNull(paramBLOB.shareBytes(), "isTemporary");
/*      */ 
/*      */ 
/*      */     
/* 3359 */     boolean bool = false;
/* 3360 */     byte[] arrayOfByte = paramBLOB.shareBytes();
/*      */     
/* 3362 */     if ((arrayOfByte[7] & 0x1) > 0 || (arrayOfByte[4] & 0x40) > 0) {
/* 3363 */       bool = true;
/*      */     }
/* 3365 */     return bool;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void open(BLOB paramBLOB, int paramInt) throws SQLException {
/* 3378 */     assertLoggedOn("open");
/* 3379 */     assertNotNull(paramBLOB.shareBytes(), "open");
/*      */     
/* 3381 */     needLine();
/*      */ 
/*      */     
/*      */     try {
/* 3385 */       this.blobMsg.open(paramBLOB.shareBytes(), paramInt);
/*      */     }
/* 3387 */     catch (IOException iOException) {
/*      */ 
/*      */       
/* 3390 */       handleIOException(iOException);
/*      */       
/* 3392 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException);
/* 3393 */       sQLException.fillInStackTrace();
/* 3394 */       throw sQLException;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void close(BLOB paramBLOB) throws SQLException {
/* 3409 */     assertLoggedOn("close");
/* 3410 */     assertNotNull(paramBLOB.shareBytes(), "close");
/*      */     
/* 3412 */     needLine();
/*      */ 
/*      */     
/*      */     try {
/* 3416 */       this.blobMsg.close(paramBLOB.shareBytes());
/*      */     }
/* 3418 */     catch (IOException iOException) {
/*      */ 
/*      */       
/* 3421 */       handleIOException(iOException);
/*      */       
/* 3423 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException);
/* 3424 */       sQLException.fillInStackTrace();
/* 3425 */       throw sQLException;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized boolean isOpen(BLOB paramBLOB) throws SQLException {
/* 3441 */     assertLoggedOn("isOpen");
/* 3442 */     assertNotNull(paramBLOB.shareBytes(), "isOpen");
/*      */     
/* 3444 */     needLine();
/*      */     
/* 3446 */     boolean bool = false;
/*      */ 
/*      */     
/*      */     try {
/* 3450 */       bool = this.blobMsg.isOpen(paramBLOB.shareBytes());
/*      */     }
/* 3452 */     catch (IOException iOException) {
/*      */ 
/*      */       
/* 3455 */       handleIOException(iOException);
/*      */       
/* 3457 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException);
/* 3458 */       sQLException.fillInStackTrace();
/* 3459 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 3464 */     return bool;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public InputStream newInputStream(BLOB paramBLOB, int paramInt, long paramLong) throws SQLException {
/* 3483 */     return newInputStream((OracleBlob)paramBLOB, paramInt, paramLong);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public InputStream newInputStream(OracleBlob paramOracleBlob, int paramInt, long paramLong) throws SQLException {
/* 3502 */     if (paramLong == 0L)
/*      */     {
/* 3504 */       return new OracleBlobInputStream(paramOracleBlob, paramInt);
/*      */     }
/*      */ 
/*      */     
/* 3508 */     return new OracleBlobInputStream(paramOracleBlob, paramInt, paramLong);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public InputStream newInputStream(BLOB paramBLOB, int paramInt, long paramLong1, long paramLong2) throws SQLException {
/* 3528 */     return newInputStream((OracleBlob)paramBLOB, paramInt, paramLong1, paramLong2);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public InputStream newInputStream(OracleBlob paramOracleBlob, int paramInt, long paramLong1, long paramLong2) throws SQLException {
/* 3547 */     return new OracleBlobInputStream(paramOracleBlob, paramInt, paramLong1, paramLong2);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public OutputStream newOutputStream(BLOB paramBLOB, int paramInt, long paramLong, boolean paramBoolean) throws SQLException {
/* 3566 */     return newOutputStream((OracleBlob)paramBLOB, paramInt, paramLong, paramBoolean);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public OutputStream newOutputStream(OracleBlob paramOracleBlob, int paramInt, long paramLong, boolean paramBoolean) throws SQLException {
/* 3585 */     if (paramLong == 0L) {
/*      */       
/* 3587 */       if (paramBoolean & this.lobStreamPosStandardCompliant) {
/*      */ 
/*      */         
/* 3590 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/* 3591 */         sQLException.fillInStackTrace();
/* 3592 */         throw sQLException;
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/* 3597 */       return new OracleBlobOutputStream(paramOracleBlob, paramInt);
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 3602 */     return new OracleBlobOutputStream(paramOracleBlob, paramInt, paramLong);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public InputStream newConversionInputStream(BLOB paramBLOB, int paramInt) throws SQLException {
/* 3621 */     return newConversionInputStream((OracleBlob)paramBLOB, paramInt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public InputStream newConversionInputStream(OracleBlob paramOracleBlob, int paramInt) throws SQLException {
/* 3639 */     assertNotNull(paramOracleBlob.shareBytes(), "newConversionInputStream");
/*      */     
/* 3641 */     return new OracleConversionInputStream(this.conversion, paramOracleBlob.getBinaryStream(), paramInt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Reader newConversionReader(BLOB paramBLOB, int paramInt) throws SQLException {
/* 3662 */     return newConversionReader((OracleBlob)paramBLOB, paramInt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Reader newConversionReader(OracleBlob paramOracleBlob, int paramInt) throws SQLException {
/* 3680 */     assertNotNull(paramOracleBlob.shareBytes(), "newConversionReader");
/*      */     
/* 3682 */     return new OracleConversionReader(this.conversion, paramOracleBlob.getBinaryStream(), paramInt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized long length(CLOB paramCLOB) throws SQLException {
/* 3710 */     assertLoggedOn("length");
/* 3711 */     assertNotNull(paramCLOB.shareBytes(), "length");
/*      */     
/* 3713 */     needLine();
/*      */     
/* 3715 */     long l = 0L;
/*      */ 
/*      */     
/*      */     try {
/* 3719 */       l = this.clobMsg.getLength(paramCLOB.shareBytes());
/*      */     }
/* 3721 */     catch (IOException iOException) {
/*      */ 
/*      */       
/* 3724 */       handleIOException(iOException);
/*      */       
/* 3726 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException);
/* 3727 */       sQLException.fillInStackTrace();
/* 3728 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 3733 */     return l;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public long position(CLOB paramCLOB, String paramString, long paramLong) throws SQLException {
/* 3750 */     if (paramString == null) {
/*      */       
/* 3752 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68, "position()");
/* 3753 */       sQLException.fillInStackTrace();
/* 3754 */       throw sQLException;
/*      */     } 
/*      */     
/* 3757 */     assertLoggedOn("position");
/* 3758 */     assertNotNull(paramCLOB.shareBytes(), "position");
/*      */ 
/*      */     
/* 3761 */     if (paramLong < 1L) {
/*      */ 
/*      */       
/* 3764 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68, "position()");
/* 3765 */       sQLException.fillInStackTrace();
/* 3766 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 3771 */     char[] arrayOfChar = new char[paramString.length()];
/*      */     
/* 3773 */     paramString.getChars(0, arrayOfChar.length, arrayOfChar, 0);
/*      */     
/* 3775 */     long l = LobPlsqlUtil.hasPattern(paramCLOB, arrayOfChar, paramLong);
/*      */     
/* 3777 */     l = (l == 0L) ? -1L : l;
/*      */     
/* 3779 */     return l;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public long position(CLOB paramCLOB1, CLOB paramCLOB2, long paramLong) throws SQLException {
/* 3795 */     if (paramCLOB2 == null) {
/*      */       
/* 3797 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68, "position()");
/* 3798 */       sQLException.fillInStackTrace();
/* 3799 */       throw sQLException;
/*      */     } 
/*      */     
/* 3802 */     assertLoggedOn("position");
/* 3803 */     assertNotNull(paramCLOB1.shareBytes(), "position");
/* 3804 */     assertNotNull(paramCLOB2.shareBytes(), "position");
/*      */     
/* 3806 */     if (paramLong < 1L) {
/*      */ 
/*      */       
/* 3809 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68, "position()");
/* 3810 */       sQLException.fillInStackTrace();
/* 3811 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/* 3815 */     long l = LobPlsqlUtil.isSubLob(paramCLOB1, paramCLOB2, paramLong);
/*      */     
/* 3817 */     l = (l == 0L) ? -1L : l;
/*      */     
/* 3819 */     return l;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized int getChars(CLOB paramCLOB, long paramLong, int paramInt, char[] paramArrayOfchar) throws SQLException {
/* 3836 */     assertLoggedOn("getChars");
/* 3837 */     assertNotNull(paramCLOB.shareBytes(), "getChars");
/*      */     
/* 3839 */     if (paramLong < 1L) {
/*      */ 
/*      */       
/* 3842 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68, "getChars()");
/* 3843 */       sQLException.fillInStackTrace();
/* 3844 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 3850 */     if (this.pipeState != -1) {
/*      */ 
/*      */       
/* 3853 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 453, "getChars()");
/* 3854 */       sQLException.fillInStackTrace();
/* 3855 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 3860 */     if (paramInt <= 0 || paramArrayOfchar == null) {
/* 3861 */       return 0;
/*      */     }
/*      */     
/* 3864 */     long l1 = 0L;
/*      */ 
/*      */     
/* 3867 */     long l2 = -1L;
/*      */ 
/*      */     
/* 3870 */     if (paramCLOB.isActivePrefetch()) {
/*      */       
/* 3872 */       l2 = paramCLOB.length();
/* 3873 */       char[] arrayOfChar = paramCLOB.getPrefetchedData();
/* 3874 */       int i = paramCLOB.getPrefetchedDataSize();
/*      */       
/* 3876 */       int j = 0;
/* 3877 */       if (arrayOfChar != null) {
/* 3878 */         j = Math.min(i, arrayOfChar.length);
/*      */       }
/* 3880 */       if (j > 0 && paramLong <= j) {
/*      */ 
/*      */ 
/*      */         
/* 3884 */         int k = Math.min(j - (int)paramLong + 1, paramInt);
/*      */ 
/*      */ 
/*      */         
/* 3888 */         System.arraycopy(arrayOfChar, (int)paramLong - 1, paramArrayOfchar, 0, k);
/* 3889 */         l1 += k;
/*      */       } 
/*      */     } 
/*      */     
/* 3893 */     if (l1 < paramInt && (l2 == -1L || paramLong - 1L + l1 < l2)) {
/*      */ 
/*      */       
/* 3896 */       needLine();
/*      */       
/*      */       try {
/* 3899 */         boolean bool = paramCLOB.isNCLOB();
/*      */         
/* 3901 */         l1 += this.clobMsg.read(paramCLOB.shareBytes(), paramLong + l1, paramInt - l1, bool, paramArrayOfchar, (int)l1);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       }
/* 3908 */       catch (IOException iOException) {
/*      */ 
/*      */         
/* 3911 */         handleIOException(iOException);
/*      */         
/* 3913 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException);
/* 3914 */         sQLException.fillInStackTrace();
/* 3915 */         throw sQLException;
/*      */       } 
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 3922 */     return (int)l1;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized int putChars(CLOB paramCLOB, long paramLong, char[] paramArrayOfchar, int paramInt1, int paramInt2) throws SQLException {
/* 3942 */     assertLoggedOn("putChars");
/* 3943 */     assertNotNull(paramCLOB.shareBytes(), "putChars");
/*      */     
/* 3945 */     if (paramLong < 1L) {
/*      */ 
/*      */       
/* 3948 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68, "putChars()");
/* 3949 */       sQLException.fillInStackTrace();
/* 3950 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/* 3954 */     if (paramArrayOfchar == null || paramInt2 <= 0) {
/* 3955 */       return 0;
/*      */     }
/* 3957 */     needLine();
/*      */     
/* 3959 */     long l = 0L;
/*      */     
/* 3961 */     if (paramInt2 != 0) {
/*      */       
/*      */       try {
/*      */         
/* 3965 */         boolean bool = paramCLOB.isNCLOB();
/*      */         
/* 3967 */         paramCLOB.setActivePrefetch(false);
/* 3968 */         paramCLOB.clearCachedData();
/* 3969 */         l = this.clobMsg.write(paramCLOB.shareBytes(), paramLong, bool, paramArrayOfchar, paramInt1, paramInt2);
/*      */       
/*      */       }
/* 3972 */       catch (IOException iOException) {
/*      */ 
/*      */         
/* 3975 */         handleIOException(iOException);
/*      */         
/* 3977 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException);
/* 3978 */         sQLException.fillInStackTrace();
/* 3979 */         throw sQLException;
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */     
/* 3985 */     return (int)l;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized int getChunkSize(CLOB paramCLOB) throws SQLException {
/* 3997 */     assertLoggedOn("getChunkSize");
/* 3998 */     assertNotNull(paramCLOB.shareBytes(), "getChunkSize");
/*      */     
/* 4000 */     needLine();
/*      */     
/* 4002 */     long l = 0L;
/*      */ 
/*      */     
/*      */     try {
/* 4006 */       l = this.clobMsg.getChunkSize(paramCLOB.shareBytes());
/*      */     }
/* 4008 */     catch (IOException iOException) {
/*      */ 
/*      */       
/* 4011 */       handleIOException(iOException);
/*      */       
/* 4013 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException);
/* 4014 */       sQLException.fillInStackTrace();
/* 4015 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 4020 */     return (int)l;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void trim(CLOB paramCLOB, long paramLong) throws SQLException {
/* 4034 */     assertLoggedOn("trim");
/* 4035 */     assertNotNull(paramCLOB.shareBytes(), "trim");
/*      */ 
/*      */     
/* 4038 */     if (paramLong < 0L) {
/*      */ 
/*      */       
/* 4041 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68, "trim()");
/* 4042 */       sQLException.fillInStackTrace();
/* 4043 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 4048 */     needLine();
/*      */ 
/*      */ 
/*      */     
/*      */     try {
/* 4053 */       paramCLOB.setActivePrefetch(false);
/* 4054 */       paramCLOB.clearCachedData();
/* 4055 */       this.clobMsg.trim(paramCLOB.shareBytes(), paramLong);
/*      */     }
/* 4057 */     catch (IOException iOException) {
/*      */ 
/*      */       
/* 4060 */       handleIOException(iOException);
/*      */       
/* 4062 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException);
/* 4063 */       sQLException.fillInStackTrace();
/* 4064 */       throw sQLException;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized CLOB createTemporaryClob(Connection paramConnection, boolean paramBoolean, int paramInt, short paramShort) throws SQLException {
/* 4087 */     assertLoggedOn("createTemporaryClob");
/*      */ 
/*      */     
/* 4090 */     if (paramShort != 2 && paramShort != 1) {
/*      */ 
/*      */ 
/*      */       
/* 4094 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 184);
/* 4095 */       sQLException.fillInStackTrace();
/* 4096 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/* 4100 */     needLine();
/*      */     
/* 4102 */     CLOB cLOB = null;
/*      */ 
/*      */     
/*      */     try {
/* 4106 */       cLOB = (CLOB)this.clobMsg.createTemporaryLob((Connection)this, paramBoolean, paramInt, paramShort);
/*      */     
/*      */     }
/* 4109 */     catch (IOException iOException) {
/*      */ 
/*      */       
/* 4112 */       handleIOException(iOException);
/*      */       
/* 4114 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException);
/* 4115 */       sQLException.fillInStackTrace();
/* 4116 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 4121 */     return cLOB;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void freeTemporary(CLOB paramCLOB, boolean paramBoolean) throws SQLException {
/* 4136 */     assertLoggedOn("freeTemporary");
/* 4137 */     assertNotNull(paramCLOB.shareBytes(), "freeTemporary");
/*      */     
/* 4139 */     needLine();
/*      */ 
/*      */     
/*      */     try {
/* 4143 */       this.clobMsg.freeTemporaryLob(paramCLOB.shareBytes());
/*      */     }
/* 4145 */     catch (IOException iOException) {
/*      */ 
/*      */       
/* 4148 */       handleIOException(iOException);
/*      */       
/* 4150 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException);
/* 4151 */       sQLException.fillInStackTrace();
/* 4152 */       throw sQLException;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isTemporary(CLOB paramCLOB) throws SQLException {
/* 4173 */     boolean bool = false;
/* 4174 */     byte[] arrayOfByte = paramCLOB.shareBytes();
/*      */     
/* 4176 */     if ((arrayOfByte[7] & 0x1) > 0 || (arrayOfByte[4] & 0x40) > 0) {
/* 4177 */       bool = true;
/*      */     }
/* 4179 */     return bool;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void open(CLOB paramCLOB, int paramInt) throws SQLException {
/* 4192 */     assertLoggedOn("open");
/* 4193 */     assertNotNull(paramCLOB.shareBytes(), "open");
/*      */     
/* 4195 */     needLine();
/*      */ 
/*      */     
/*      */     try {
/* 4199 */       this.clobMsg.open(paramCLOB.shareBytes(), paramInt);
/*      */     }
/* 4201 */     catch (IOException iOException) {
/*      */ 
/*      */       
/* 4204 */       handleIOException(iOException);
/*      */       
/* 4206 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException);
/* 4207 */       sQLException.fillInStackTrace();
/* 4208 */       throw sQLException;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void close(CLOB paramCLOB) throws SQLException {
/* 4223 */     assertLoggedOn("close");
/* 4224 */     assertNotNull(paramCLOB.shareBytes(), "close");
/*      */     
/* 4226 */     needLine();
/*      */ 
/*      */     
/*      */     try {
/* 4230 */       this.clobMsg.close(paramCLOB.shareBytes());
/*      */     }
/* 4232 */     catch (IOException iOException) {
/*      */ 
/*      */       
/* 4235 */       handleIOException(iOException);
/*      */       
/* 4237 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException);
/* 4238 */       sQLException.fillInStackTrace();
/* 4239 */       throw sQLException;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized boolean isOpen(CLOB paramCLOB) throws SQLException {
/* 4255 */     assertLoggedOn("isOpen");
/* 4256 */     assertNotNull(paramCLOB.shareBytes(), "isOpen");
/*      */     
/* 4258 */     boolean bool = false;
/*      */     
/* 4260 */     needLine();
/*      */ 
/*      */     
/*      */     try {
/* 4264 */       bool = this.clobMsg.isOpen(paramCLOB.shareBytes());
/*      */     }
/* 4266 */     catch (IOException iOException) {
/*      */ 
/*      */       
/* 4269 */       handleIOException(iOException);
/*      */       
/* 4271 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException);
/* 4272 */       sQLException.fillInStackTrace();
/* 4273 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 4278 */     return bool;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public InputStream newInputStream(CLOB paramCLOB, int paramInt, long paramLong) throws SQLException {
/* 4297 */     return newInputStream((OracleClob)paramCLOB, paramInt, paramLong);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public InputStream newInputStream(OracleClob paramOracleClob, int paramInt, long paramLong) throws SQLException {
/* 4316 */     if (paramLong == 0L)
/*      */     {
/* 4318 */       return new OracleClobInputStream(paramOracleClob, paramInt);
/*      */     }
/*      */ 
/*      */     
/* 4322 */     return new OracleClobInputStream(paramOracleClob, paramInt, paramLong);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public OutputStream newOutputStream(CLOB paramCLOB, int paramInt, long paramLong, boolean paramBoolean) throws SQLException {
/* 4343 */     return newOutputStream((OracleClob)paramCLOB, paramInt, paramLong, paramBoolean);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public OutputStream newOutputStream(OracleClob paramOracleClob, int paramInt, long paramLong, boolean paramBoolean) throws SQLException {
/* 4363 */     if (paramLong == 0L) {
/*      */       
/* 4365 */       if (paramBoolean & this.lobStreamPosStandardCompliant) {
/*      */ 
/*      */         
/* 4368 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/* 4369 */         sQLException.fillInStackTrace();
/* 4370 */         throw sQLException;
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/* 4375 */       return new OracleClobOutputStream(paramOracleClob, paramInt);
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 4380 */     return new OracleClobOutputStream(paramOracleClob, paramInt, paramLong);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Reader newReader(CLOB paramCLOB, int paramInt, long paramLong) throws SQLException {
/* 4400 */     return newReader((OracleClob)paramCLOB, paramInt, paramLong);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Reader newReader(OracleClob paramOracleClob, int paramInt, long paramLong) throws SQLException {
/* 4419 */     if (paramLong == 0L)
/*      */     {
/* 4421 */       return new OracleClobReader(paramOracleClob, paramInt);
/*      */     }
/*      */ 
/*      */     
/* 4425 */     return new OracleClobReader(paramOracleClob, paramInt, paramLong);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Reader newReader(CLOB paramCLOB, int paramInt, long paramLong1, long paramLong2) throws SQLException {
/* 4446 */     return newReader((OracleClob)paramCLOB, paramInt, paramLong1, paramLong2);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Reader newReader(OracleClob paramOracleClob, int paramInt, long paramLong1, long paramLong2) throws SQLException {
/* 4466 */     return new OracleClobReader(paramOracleClob, paramInt, paramLong1, paramLong2);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Writer newWriter(CLOB paramCLOB, int paramInt, long paramLong, boolean paramBoolean) throws SQLException {
/* 4485 */     return newWriter((OracleClob)paramCLOB, paramInt, paramLong, paramBoolean);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Writer newWriter(OracleClob paramOracleClob, int paramInt, long paramLong, boolean paramBoolean) throws SQLException {
/* 4504 */     if (paramLong == 0L) {
/*      */       
/* 4506 */       if (paramBoolean & this.lobStreamPosStandardCompliant) {
/*      */ 
/*      */         
/* 4509 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/* 4510 */         sQLException.fillInStackTrace();
/* 4511 */         throw sQLException;
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/* 4516 */       return new OracleClobWriter(paramOracleClob, paramInt);
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 4521 */     return new OracleClobWriter(paramOracleClob, paramInt, paramLong);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void assertLoggedOn(String paramString) throws SQLException {
/* 4547 */     if (!this.isLoggedOn) {
/*      */ 
/*      */       
/* 4550 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 430);
/* 4551 */       sQLException.fillInStackTrace();
/* 4552 */       throw sQLException;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   boolean isLoggedOn() {
/* 4566 */     return this.isLoggedOn;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void assertNotNull(byte[] paramArrayOfbyte, String paramString) throws NullPointerException {
/* 4582 */     if (paramArrayOfbyte == null)
/*      */     {
/* 4584 */       throw new NullPointerException("bytes are null");
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void internalClose() throws SQLException {
/* 4593 */     super.internalClose();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 4601 */     if (this.all8 != null) {
/* 4602 */       this.all8.definesAccessors = null;
/*      */     }
/*      */     
/* 4605 */     this.isLoggedOn = false;
/*      */     
/*      */     try {
/* 4608 */       if (this.net != null) {
/* 4609 */         this.net.disconnect();
/*      */       }
/* 4611 */     } catch (Exception exception) {}
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void doAbort() throws SQLException {
/*      */     try {
/* 4623 */       this.net.abort();
/*      */     }
/* 4625 */     catch (NetException netException) {
/*      */ 
/*      */ 
/*      */       
/* 4629 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), (IOException)netException);
/* 4630 */       sQLException.fillInStackTrace();
/* 4631 */       throw sQLException;
/*      */ 
/*      */     
/*      */     }
/* 4635 */     catch (IOException iOException) {
/*      */ 
/*      */       
/* 4638 */       handleIOException(iOException);
/*      */       
/* 4640 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException);
/* 4641 */       sQLException.fillInStackTrace();
/* 4642 */       throw sQLException;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void doDescribeTable(AutoKeyInfo paramAutoKeyInfo) throws SQLException {
/* 4653 */     T4CStatement t4CStatement = new T4CStatement(this, -1, -1);
/* 4654 */     t4CStatement.open();
/*      */     
/* 4656 */     String str1 = paramAutoKeyInfo.getTableName();
/* 4657 */     String str2 = "SELECT * FROM " + str1;
/*      */     
/* 4659 */     t4CStatement.sqlObject.initialize(str2);
/*      */     
/* 4661 */     Accessor[] arrayOfAccessor = null;
/*      */ 
/*      */     
/*      */     try {
/* 4665 */       this.describe.doODNY(t4CStatement, 0, arrayOfAccessor, t4CStatement.sqlObject.getSqlBytes(false, false));
/* 4666 */       arrayOfAccessor = this.describe.getAccessors();
/*      */     }
/* 4668 */     catch (IOException iOException) {
/*      */       
/* 4670 */       handleIOException(iOException);
/*      */       
/* 4672 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException);
/* 4673 */       sQLException.fillInStackTrace();
/* 4674 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/* 4678 */     int i = this.describe.numuds;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 4689 */     paramAutoKeyInfo.allocateSpaceForDescribedData(i);
/*      */     
/* 4691 */     for (byte b = 0; b < i; b++) {
/*      */       
/* 4693 */       Accessor accessor = arrayOfAccessor[b];
/* 4694 */       String str3 = accessor.columnName;
/* 4695 */       int j = accessor.describeType;
/* 4696 */       int k = accessor.describeMaxLength;
/* 4697 */       boolean bool = accessor.nullable;
/* 4698 */       short s = accessor.formOfUse;
/* 4699 */       int m = accessor.precision;
/* 4700 */       int n = accessor.scale;
/* 4701 */       String str4 = accessor.describeTypeName;
/*      */       
/* 4703 */       paramAutoKeyInfo.fillDescribedData(b, str3, j, k, bool, s, m, n, str4);
/*      */     } 
/*      */ 
/*      */     
/* 4707 */     t4CStatement.close();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void doSetApplicationContext(String paramString1, String paramString2, String paramString3) throws SQLException {
/* 4718 */     Namespace namespace = (Namespace)this.namespaces.get(paramString1);
/* 4719 */     if (namespace == null) {
/*      */       
/* 4721 */       namespace = new Namespace(paramString1);
/* 4722 */       this.namespaces.put(paramString1, namespace);
/*      */     } 
/* 4724 */     namespace.setAttribute(paramString2, paramString3);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void doClearAllApplicationContext(String paramString) throws SQLException {
/* 4733 */     Namespace namespace = new Namespace(paramString);
/* 4734 */     namespace.clear();
/* 4735 */     this.namespaces.put(paramString, namespace);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void getPropertyForPooledConnection(OraclePooledConnection paramOraclePooledConnection) throws SQLException {
/* 4743 */     getPropertyForPooledConnection(paramOraclePooledConnection, this.password);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final void getPasswordInternal(T4CXAResource paramT4CXAResource) throws SQLException {
/* 4751 */     paramT4CXAResource.setPasswordInternal(this.password);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   synchronized void doEnqueue(String paramString, AQEnqueueOptions paramAQEnqueueOptions, AQMessagePropertiesI paramAQMessagePropertiesI, byte[] paramArrayOfbyte1, byte[] paramArrayOfbyte2, byte[][] paramArrayOfbyte, boolean paramBoolean) throws SQLException {
/*      */     try {
/* 4769 */       needLine();
/* 4770 */       this.aqe.doOAQEQ(paramString, paramAQEnqueueOptions, paramAQMessagePropertiesI, paramArrayOfbyte2, paramArrayOfbyte1, paramBoolean);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 4777 */       if (paramAQEnqueueOptions.getRetrieveMessageId()) {
/* 4778 */         paramArrayOfbyte[0] = this.aqe.getMessageId();
/*      */       }
/* 4780 */     } catch (IOException iOException) {
/*      */       
/* 4782 */       handleIOException(iOException);
/*      */       
/* 4784 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException);
/* 4785 */       sQLException.fillInStackTrace();
/* 4786 */       throw sQLException;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   synchronized boolean doDequeue(String paramString, AQDequeueOptions paramAQDequeueOptions, AQMessagePropertiesI paramAQMessagePropertiesI, byte[] paramArrayOfbyte, byte[][] paramArrayOfbyte1, byte[][] paramArrayOfbyte2, boolean paramBoolean) throws SQLException {
/* 4803 */     boolean bool = false;
/*      */     
/*      */     try {
/* 4806 */       needLine();
/* 4807 */       this.aqdq.doOAQDQ(paramString, paramAQDequeueOptions, paramArrayOfbyte, paramBoolean, paramAQMessagePropertiesI);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 4813 */       paramArrayOfbyte1[0] = this.aqdq.getPayload();
/* 4814 */       paramArrayOfbyte2[0] = this.aqdq.getDequeuedMessageId();
/* 4815 */       bool = this.aqdq.hasAMessageBeenDequeued();
/*      */     }
/* 4817 */     catch (IOException iOException) {
/*      */       
/* 4819 */       handleIOException(iOException);
/*      */       
/* 4821 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException);
/* 4822 */       sQLException.fillInStackTrace();
/* 4823 */       throw sQLException;
/*      */     } 
/*      */     
/* 4826 */     return bool;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   synchronized void doJMSEnqueue(String paramString, JMSEnqueueOptions paramJMSEnqueueOptions, AQMessagePropertiesI paramAQMessagePropertiesI, JMSMessageProperties paramJMSMessageProperties, byte[] paramArrayOfbyte1, byte[] paramArrayOfbyte2, byte[][] paramArrayOfbyte) throws SQLException {
/*      */     try {
/* 4842 */       needLine();
/* 4843 */       this.oaqenq.doJMSEnq(paramString, paramJMSEnqueueOptions, paramAQMessagePropertiesI, paramJMSMessageProperties, paramArrayOfbyte1, paramArrayOfbyte2);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 4851 */       if (paramJMSEnqueueOptions.isRetrieveMessageId()) {
/* 4852 */         paramArrayOfbyte[0] = this.oaqenq.getMsgId();
/*      */       }
/* 4854 */     } catch (IOException iOException) {
/*      */       
/* 4856 */       handleIOException(iOException);
/*      */       
/* 4858 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException);
/* 4859 */       sQLException.fillInStackTrace();
/* 4860 */       throw sQLException;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   synchronized boolean doJmsDequeue(String paramString, JMSDequeueOptions paramJMSDequeueOptions, AQMessagePropertiesI paramAQMessagePropertiesI, JMSMessagePropertiesI paramJMSMessagePropertiesI, byte[] paramArrayOfbyte, byte[][] paramArrayOfbyte1, byte[][] paramArrayOfbyte2) throws SQLException {
/* 4875 */     boolean bool = false;
/*      */     
/*      */     try {
/* 4878 */       needLine();
/* 4879 */       this.oaqdeq.doJMSDeq(paramString, paramJMSDequeueOptions, paramArrayOfbyte, paramAQMessagePropertiesI, paramJMSMessagePropertiesI);
/* 4880 */       paramArrayOfbyte1[0] = this.oaqdeq.getPayload();
/* 4881 */       paramArrayOfbyte2[0] = this.oaqdeq.getDequeuedMessageId();
/* 4882 */       bool = this.oaqdeq.isHasAMessageBeenDequeued();
/*      */     }
/* 4884 */     catch (IOException iOException) {
/*      */       
/* 4886 */       handleIOException(iOException);
/* 4887 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException);
/* 4888 */       sQLException.fillInStackTrace();
/* 4889 */       throw sQLException;
/*      */     } 
/* 4891 */     return bool;
/*      */   }
/*      */ 
/*      */   
/*      */   synchronized int doPingDatabase() throws SQLException {
/* 4896 */     if (this.versionNumber >= 10102) {
/*      */ 
/*      */       
/*      */       try {
/* 4900 */         needLine();
/* 4901 */         this.oping.doOPING();
/*      */       }
/* 4903 */       catch (IOException iOException) {
/*      */         
/* 4905 */         return -1;
/*      */       }
/* 4907 */       catch (SQLException sQLException) {
/*      */         
/* 4909 */         return -1;
/*      */       } 
/* 4911 */       return 0;
/*      */     } 
/*      */ 
/*      */     
/* 4915 */     return super.doPingDatabase();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   synchronized Map<String, JMSNotificationRegistration> doRegisterJMSNotification(String[] paramArrayOfString, Map<String, Properties> paramMap) throws SQLException {
/* 4936 */     assert this.databaseUniqueIdentifier != null : "databaseUniqueIdentifier is null";
/* 4937 */     String str = null;
/* 4938 */     int i = paramArrayOfString.length;
/* 4939 */     int[] arrayOfInt1 = new int[i];
/* 4940 */     int[] arrayOfInt2 = new int[i];
/* 4941 */     int[] arrayOfInt3 = new int[i];
/* 4942 */     int[] arrayOfInt4 = new int[i];
/* 4943 */     int[] arrayOfInt5 = new int[i];
/*      */     
/* 4945 */     byte[][] arrayOfByte = new byte[i][];
/* 4946 */     NTFJMSPerDatabaseManager nTFJMSPerDatabaseManager = PhysicalConnection.ntfManager.getJMSPerDatabaseManager(this.databaseUniqueIdentifier);
/*      */     
/* 4948 */     HashMap<Object, Object> hashMap = new HashMap<>();
/*      */ 
/*      */     
/* 4951 */     for (byte b = 0; b < i; b++) {
/* 4952 */       arrayOfInt2[b] = 1;
/* 4953 */       arrayOfInt3[b] = 0;
/* 4954 */       arrayOfInt1[b] = PhysicalConnection.ntfManager.getNextJdbcRegId();
/* 4955 */       arrayOfByte[b] = new byte[4];
/* 4956 */       arrayOfByte[b][0] = (byte)((arrayOfInt1[b] & 0xFF000000) >> 24);
/* 4957 */       arrayOfByte[b][1] = (byte)((arrayOfInt1[b] & 0xFF0000) >> 16);
/* 4958 */       arrayOfByte[b][2] = (byte)((arrayOfInt1[b] & 0xFF00) >> 8);
/* 4959 */       arrayOfByte[b][3] = (byte)(arrayOfInt1[b] & 0xFF);
/* 4960 */       Properties properties = paramMap.get(paramArrayOfString[b]);
/* 4961 */       if (properties != null) {
/* 4962 */         if (properties.getProperty("NTF_QOS_RELIABLE", "false").equalsIgnoreCase("true")) {
/* 4963 */           arrayOfInt4[b] = arrayOfInt4[b] | 0x1;
/*      */         }
/* 4965 */         if (properties.getProperty("NTF_QOS_PURGE_ON_NTFN", "false").equalsIgnoreCase("true")) {
/* 4966 */           arrayOfInt4[b] = arrayOfInt4[b] | 0x10;
/*      */         }
/* 4968 */         if (properties.getProperty("NTF_AQ_PAYLOAD", "false").equalsIgnoreCase("true")) {
/* 4969 */           arrayOfInt4[b] = arrayOfInt4[b] | 0x2;
/*      */         }
/* 4971 */         if (properties.getProperty("NTF_ASYNC_DEQ", "false").equalsIgnoreCase("true")) {
/* 4972 */           arrayOfInt4[b] = arrayOfInt4[b] | 0x200;
/*      */         }
/* 4974 */         if (properties.getProperty("NTF_QOS_SECURE", "false").equalsIgnoreCase("true")) {
/* 4975 */           arrayOfInt4[b] = arrayOfInt4[b] | 0x8;
/*      */         }
/* 4977 */         if (properties.getProperty("NTF_QOS_TX_ACK", "false").equalsIgnoreCase("true")) {
/* 4978 */           arrayOfInt4[b] = arrayOfInt4[b] | 0x800;
/*      */         }
/* 4980 */         if (properties.getProperty("NTF_QOS_AUTO_ACK", "false").equalsIgnoreCase("true")) {
/* 4981 */           arrayOfInt4[b] = arrayOfInt4[b] | 0x400;
/*      */         }
/* 4983 */         arrayOfInt5[b] = readNTFtimeout(properties);
/*      */       } 
/*      */     } 
/* 4986 */     synchronized (nTFJMSPerDatabaseManager) {
/* 4987 */       if (nTFJMSPerDatabaseManager.isInitialized) {
/* 4988 */         str = nTFJMSPerDatabaseManager.getJMSClientId();
/*      */       }
/*      */       try {
/* 4991 */         this.okpn.doOKPN(1, 4, this.userName, str, i, arrayOfInt2, paramArrayOfString, arrayOfByte, arrayOfInt3, arrayOfInt4, arrayOfInt5, null, null, null, null, null, null, null, null, null);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       }
/* 5012 */       catch (IOException iOException) {
/* 5013 */         handleIOException(iOException);
/*      */         
/* 5015 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException);
/* 5016 */         sQLException.fillInStackTrace();
/* 5017 */         throw sQLException;
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 5023 */       if (!nTFJMSPerDatabaseManager.isInitialized) {
/*      */ 
/*      */         
/* 5026 */         str = this.okpn.getJMSClientId();
/* 5027 */         if (str == null) {
/*      */           
/* 5029 */           SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 287, "clientID returned by server is null");
/* 5030 */           sQLException.fillInStackTrace();
/* 5031 */           throw sQLException;
/*      */         } 
/*      */         
/* 5034 */         String[] arrayOfString = this.okpn.getDatabaseInstances();
/* 5035 */         if (arrayOfString == null || arrayOfString.length == 0) {
/* 5036 */           arrayOfString = new String[1];
/* 5037 */           arrayOfString[0] = this.instanceName;
/*      */         } 
/* 5039 */         ArrayList<String> arrayList = this.okpn.getListenerAddresses();
/* 5040 */         if (arrayList == null) {
/*      */           
/* 5042 */           SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 287, "listenerAddress returned by server is null");
/* 5043 */           sQLException.fillInStackTrace();
/* 5044 */           throw sQLException;
/*      */         } 
/*      */         
/* 5047 */         nTFJMSPerDatabaseManager.init(str, arrayOfString, arrayList);
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 5053 */       String str1 = (this.net.getSessionAttributes().getcOption()).service_name;
/*      */       
/* 5055 */       if (str1 == null) {
/*      */         
/* 5057 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 287, "No service name found,please use a service name format URL to create a connection");
/* 5058 */         sQLException.fillInStackTrace();
/* 5059 */         throw sQLException;
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 5068 */       nTFJMSPerDatabaseManager.startJMSListenerConnection(str1, this.userName, this.password);
/*      */ 
/*      */ 
/*      */       
/* 5072 */       long[] arrayOfLong = this.okpn.getRegistrationIdArray();
/*      */       
/* 5074 */       assert arrayOfLong.length == arrayOfInt1.length : "jmsRegIdArr.length = " + arrayOfLong.length + ", jdbcRegIdArr.length = " + arrayOfInt1.length;
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 5079 */       for (byte b1 = 0; b1 < i; b1++) {
/* 5080 */         Properties properties = paramMap.get(paramArrayOfString[b1]);
/* 5081 */         if (properties == null) {
/* 5082 */           properties = new Properties();
/*      */         }
/*      */         
/* 5085 */         NTFJMSRegistration nTFJMSRegistration = new NTFJMSRegistration(arrayOfInt1[b1], true, this.instanceName, this.userName, properties, paramArrayOfString[b1], this.versionNumber, str);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 5096 */         nTFJMSRegistration.setJMSRegistrationId(arrayOfLong[b1]);
/*      */         
/* 5098 */         nTFJMSRegistration.setQOSFlag(arrayOfInt4[b1]);
/* 5099 */         hashMap.put(paramArrayOfString[b1], nTFJMSRegistration);
/*      */         
/* 5101 */         PhysicalConnection.ntfManager.addRegistration(nTFJMSRegistration);
/*      */ 
/*      */         
/* 5104 */         nTFJMSPerDatabaseManager.mapJMSRegIdToJDBCRegId(Long.valueOf(arrayOfLong[b1]), arrayOfInt1[b1]);
/*      */         
/* 5106 */         nTFJMSPerDatabaseManager.incrementNumberOfRegistrations();
/*      */       } 
/* 5108 */       return (Map)hashMap;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   synchronized void doUnregisterJMSNotification(NTFJMSRegistration paramNTFJMSRegistration) throws SQLException {
/* 5120 */     assert this.databaseUniqueIdentifier != null : "databaseUniqueIdentifier is null";
/*      */     
/* 5122 */     PhysicalConnection.ntfManager.removeRegistration(paramNTFJMSRegistration);
/* 5123 */     PhysicalConnection.ntfManager.freeJdbcRegId(paramNTFJMSRegistration.getJdbcRegId());
/* 5124 */     Long long_ = Long.valueOf(paramNTFJMSRegistration.getJMSRegistrationId());
/* 5125 */     paramNTFJMSRegistration.setState(NotificationRegistration.RegistrationState.CLOSED);
/*      */     
/* 5127 */     NTFJMSPerDatabaseManager nTFJMSPerDatabaseManager = PhysicalConnection.ntfManager.getJMSPerDatabaseManager(this.databaseUniqueIdentifier);
/*      */     
/* 5129 */     assert nTFJMSPerDatabaseManager != null : "jmsPerDatabaseManager is null";
/* 5130 */     assert nTFJMSPerDatabaseManager.isInitialized : "jmsPerDatabaseManager is not initialized";
/* 5131 */     nTFJMSPerDatabaseManager.decrementNumberOfRegistrations();
/*      */ 
/*      */     
/* 5134 */     nTFJMSPerDatabaseManager.closeJMSListenerConnection();
/* 5135 */     nTFJMSPerDatabaseManager.removeRegistrationId(long_);
/* 5136 */     String str = nTFJMSPerDatabaseManager.getJMSClientId();
/*      */     
/* 5138 */     int[] arrayOfInt1 = { 1 };
/* 5139 */     String[] arrayOfString = new String[1];
/* 5140 */     arrayOfString[0] = paramNTFJMSRegistration.getQueueName();
/* 5141 */     int[] arrayOfInt2 = { 0 };
/* 5142 */     int i = paramNTFJMSRegistration.getQOSFlag();
/* 5143 */     int[] arrayOfInt3 = { i };
/* 5144 */     int[] arrayOfInt4 = { 0 };
/* 5145 */     long[] arrayOfLong = { long_.longValue() };
/*      */     try {
/* 5147 */       this.okpn.doOKPN(2, 4, this.userName, str, 1, arrayOfInt1, arrayOfString, (byte[][])null, arrayOfInt2, arrayOfInt3, arrayOfInt4, null, null, null, null, null, null, null, null, arrayOfLong);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     }
/* 5168 */     catch (IOException iOException) {
/* 5169 */       handleIOException(iOException);
/*      */       
/* 5171 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException);
/* 5172 */       sQLException.fillInStackTrace();
/* 5173 */       throw sQLException;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void doAckJMSNtfn(NTFJMSRegistration paramNTFJMSRegistration, byte[] paramArrayOfbyte, short paramShort) throws SQLException {
/*      */     try {
/* 5185 */       assert this.databaseUniqueIdentifier != null : "databaseUniqueIdentifier is null";
/* 5186 */       NTFJMSPerDatabaseManager nTFJMSPerDatabaseManager = PhysicalConnection.ntfManager.getJMSPerDatabaseManager(this.databaseUniqueIdentifier);
/*      */       
/* 5188 */       assert nTFJMSPerDatabaseManager != null : "jmsPerDatabaseManager is null";
/* 5189 */       String str = nTFJMSPerDatabaseManager.getJMSClientId();
/* 5190 */       this.kpdnrdeq.doOAQEMNDEQ(str, paramShort, paramArrayOfbyte, paramNTFJMSRegistration.getJMSRegistrationId(), paramNTFJMSRegistration.getQueueName());
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     }
/* 5196 */     catch (IOException iOException) {
/* 5197 */       handleIOException(iOException);
/*      */       
/* 5199 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException);
/* 5200 */       sQLException.fillInStackTrace();
/* 5201 */       throw sQLException;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   synchronized NTFAQRegistration[] doRegisterAQNotification(String[] paramArrayOfString, String paramString, int paramInt, Properties[] paramArrayOfProperties) throws SQLException {
/* 5216 */     int i = paramArrayOfString.length;
/* 5217 */     int[] arrayOfInt1 = new int[i];
/* 5218 */     byte[][] arrayOfByte = new byte[i][];
/* 5219 */     int[] arrayOfInt2 = new int[i];
/* 5220 */     int[] arrayOfInt3 = new int[i];
/* 5221 */     int[] arrayOfInt4 = new int[i];
/* 5222 */     int[] arrayOfInt5 = new int[i];
/* 5223 */     int[] arrayOfInt6 = new int[i];
/* 5224 */     int[] arrayOfInt7 = new int[i];
/* 5225 */     long[] arrayOfLong = new long[i];
/* 5226 */     byte[] arrayOfByte1 = new byte[i];
/* 5227 */     int[] arrayOfInt8 = new int[i];
/* 5228 */     byte[] arrayOfByte2 = new byte[i];
/* 5229 */     TIMESTAMPTZ[] arrayOfTIMESTAMPTZ = new TIMESTAMPTZ[i];
/* 5230 */     int[] arrayOfInt9 = new int[i];
/*      */     
/* 5232 */     boolean bool = false;
/* 5233 */     if (paramInt == 0) {
/*      */ 
/*      */       
/* 5236 */       bool = true;
/* 5237 */       paramInt = 47632;
/*      */     } 
/*      */     
/* 5240 */     for (byte b1 = 0; b1 < i; b1++) {
/*      */       
/* 5242 */       arrayOfInt1[b1] = PhysicalConnection.ntfManager.getNextJdbcRegId();
/* 5243 */       arrayOfByte[b1] = new byte[4];
/* 5244 */       arrayOfByte[b1][0] = (byte)((arrayOfInt1[b1] & 0xFF000000) >> 24);
/* 5245 */       arrayOfByte[b1][1] = (byte)((arrayOfInt1[b1] & 0xFF0000) >> 16);
/* 5246 */       arrayOfByte[b1][2] = (byte)((arrayOfInt1[b1] & 0xFF00) >> 8);
/* 5247 */       arrayOfByte[b1][3] = (byte)(arrayOfInt1[b1] & 0xFF);
/* 5248 */       arrayOfInt2[b1] = 1;
/* 5249 */       arrayOfInt3[b1] = 23;
/*      */ 
/*      */       
/* 5252 */       if (paramArrayOfProperties.length > b1 && paramArrayOfProperties[b1] != null) {
/*      */         
/* 5254 */         if (paramArrayOfProperties[b1].getProperty("NTF_QOS_RELIABLE", "false").compareToIgnoreCase("true") == 0)
/*      */         {
/* 5256 */           arrayOfInt4[b1] = arrayOfInt4[b1] | 0x1; } 
/* 5257 */         if (paramArrayOfProperties[b1].getProperty("NTF_QOS_PURGE_ON_NTFN", "false").compareToIgnoreCase("true") == 0)
/*      */         {
/* 5259 */           arrayOfInt4[b1] = arrayOfInt4[b1] | 0x10; } 
/* 5260 */         if (paramArrayOfProperties[b1].getProperty("NTF_AQ_PAYLOAD", "false").compareToIgnoreCase("true") == 0)
/*      */         {
/* 5262 */           arrayOfInt4[b1] = arrayOfInt4[b1] | 0x2; } 
/* 5263 */         arrayOfInt5[b1] = readNTFtimeout(paramArrayOfProperties[b1]);
/*      */       } 
/*      */     } 
/*      */     
/* 5267 */     setNtfGroupingOptions(arrayOfByte1, arrayOfInt8, arrayOfByte2, arrayOfTIMESTAMPTZ, arrayOfInt9, paramArrayOfProperties);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 5274 */     int[] arrayOfInt10 = new int[1];
/* 5275 */     arrayOfInt10[0] = paramInt;
/*      */ 
/*      */ 
/*      */     
/* 5279 */     boolean bool1 = PhysicalConnection.ntfManager.listenOnPortT4C(arrayOfInt10, bool);
/* 5280 */     paramInt = arrayOfInt10[0];
/*      */     
/* 5282 */     String str = "(ADDRESS=(PROTOCOL=tcp)(HOST=" + paramString + ")(PORT=" + paramInt + "))?PR=0";
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     try {
/*      */       try {
/* 5289 */         boolean bool2 = bool1 ? true : false;
/* 5290 */         this.okpn.doOKPN(1, bool2, this.userName, str, i, arrayOfInt2, paramArrayOfString, arrayOfByte, arrayOfInt3, arrayOfInt4, arrayOfInt5, arrayOfInt6, arrayOfInt7, arrayOfLong, arrayOfByte1, arrayOfInt8, arrayOfByte2, arrayOfTIMESTAMPTZ, arrayOfInt9, arrayOfLong);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       }
/* 5313 */       catch (IOException iOException) {
/*      */         
/* 5315 */         handleIOException(iOException);
/*      */         
/* 5317 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException);
/* 5318 */         sQLException.fillInStackTrace();
/* 5319 */         throw sQLException;
/*      */       }
/*      */     
/*      */     }
/* 5323 */     catch (SQLException sQLException) {
/*      */       
/* 5325 */       if (bool1) {
/* 5326 */         PhysicalConnection.ntfManager.cleanListenersT4C(paramInt);
/*      */       }
/* 5328 */       throw sQLException;
/*      */     } 
/* 5330 */     NTFAQRegistration[] arrayOfNTFAQRegistration = new NTFAQRegistration[i];
/*      */     byte b2;
/* 5332 */     for (b2 = 0; b2 < i; b2++) {
/* 5333 */       arrayOfNTFAQRegistration[b2] = new NTFAQRegistration(arrayOfInt1[b2], true, this.instanceName, this.userName, paramString, paramInt, paramArrayOfProperties[b2], paramArrayOfString[b2], this.versionNumber);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 5343 */     for (b2 = 0; b2 < arrayOfNTFAQRegistration.length; b2++)
/* 5344 */       PhysicalConnection.ntfManager.addRegistration(arrayOfNTFAQRegistration[b2]); 
/* 5345 */     return arrayOfNTFAQRegistration;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void setNtfGroupingOptions(byte[] paramArrayOfbyte1, int[] paramArrayOfint1, byte[] paramArrayOfbyte2, TIMESTAMPTZ[] paramArrayOfTIMESTAMPTZ, int[] paramArrayOfint2, Properties[] paramArrayOfProperties) throws SQLException {
/* 5364 */     for (byte b = 0; b < paramArrayOfProperties.length; b++) {
/*      */       
/* 5366 */       String str1 = paramArrayOfProperties[b].getProperty("NTF_GROUPING_CLASS", "NTF_GROUPING_CLASS_NONE");
/* 5367 */       String str2 = paramArrayOfProperties[b].getProperty("NTF_GROUPING_VALUE");
/* 5368 */       String str3 = paramArrayOfProperties[b].getProperty("NTF_GROUPING_TYPE");
/* 5369 */       TIMESTAMPTZ tIMESTAMPTZ = null;
/* 5370 */       if (paramArrayOfProperties[b].get("NTF_GROUPING_START_TIME") != null)
/* 5371 */         tIMESTAMPTZ = (TIMESTAMPTZ)paramArrayOfProperties[b].get("NTF_GROUPING_START_TIME"); 
/* 5372 */       String str4 = paramArrayOfProperties[b].getProperty("NTF_GROUPING_REPEAT_TIME", "NTF_GROUPING_REPEAT_FOREVER");
/*      */ 
/*      */       
/* 5375 */       if (str1.compareTo("NTF_GROUPING_CLASS_TIME") != 0 && str1.compareTo("NTF_GROUPING_CLASS_NONE") != 0) {
/*      */ 
/*      */ 
/*      */         
/* 5379 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/* 5380 */         sQLException.fillInStackTrace();
/* 5381 */         throw sQLException;
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/* 5386 */       if (str1.compareTo("NTF_GROUPING_CLASS_NONE") != 0 && getTTCVersion() < 5) {
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 5391 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 23);
/* 5392 */         sQLException.fillInStackTrace();
/* 5393 */         throw sQLException;
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 5399 */       if (str1.compareTo("NTF_GROUPING_CLASS_TIME") == 0) {
/*      */         
/* 5401 */         paramArrayOfbyte1[b] = 1;
/*      */         
/* 5403 */         paramArrayOfint1[b] = 600;
/* 5404 */         if (str2 != null) {
/* 5405 */           paramArrayOfint1[b] = Integer.parseInt(str2);
/*      */         }
/* 5407 */         paramArrayOfbyte2[b] = 1;
/* 5408 */         if (str3 != null)
/*      */         {
/* 5410 */           if (str3.compareTo("NTF_GROUPING_TYPE_SUMMARY") == 0) {
/* 5411 */             paramArrayOfbyte2[b] = 1;
/* 5412 */           } else if (str3.compareTo("NTF_GROUPING_TYPE_LAST") == 0) {
/* 5413 */             paramArrayOfbyte2[b] = 2;
/*      */           
/*      */           }
/*      */           else {
/*      */ 
/*      */             
/* 5419 */             SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/* 5420 */             sQLException.fillInStackTrace();
/* 5421 */             throw sQLException;
/*      */           } 
/*      */         }
/*      */ 
/*      */         
/* 5426 */         paramArrayOfTIMESTAMPTZ[b] = tIMESTAMPTZ;
/* 5427 */         if (str4.compareTo("NTF_GROUPING_REPEAT_FOREVER") == 0) {
/* 5428 */           paramArrayOfint2[b] = 0;
/*      */         } else {
/* 5430 */           paramArrayOfint2[b] = Integer.parseInt(str4);
/*      */         } 
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   synchronized void doUnregisterAQNotification(NTFAQRegistration paramNTFAQRegistration) throws SQLException {
/* 5442 */     String str1 = paramNTFAQRegistration.getClientHost();
/* 5443 */     int i = paramNTFAQRegistration.getClientTCPPort();
/* 5444 */     if (str1 == null) {
/*      */       return;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 5455 */     PhysicalConnection.ntfManager.removeRegistration(paramNTFAQRegistration);
/* 5456 */     PhysicalConnection.ntfManager.freeJdbcRegId(paramNTFAQRegistration.getJdbcRegId());
/* 5457 */     PhysicalConnection.ntfManager.cleanListenersT4C(paramNTFAQRegistration.getClientTCPPort());
/* 5458 */     paramNTFAQRegistration.setState(NotificationRegistration.RegistrationState.CLOSED);
/*      */     
/* 5460 */     String str2 = "(ADDRESS=(PROTOCOL=tcp)(HOST=" + str1 + ")(PORT=" + i + "))?PR=0";
/*      */ 
/*      */     
/* 5463 */     int[] arrayOfInt1 = { 1 };
/* 5464 */     String[] arrayOfString = new String[1];
/* 5465 */     arrayOfString[0] = paramNTFAQRegistration.getQueueName();
/* 5466 */     int[] arrayOfInt2 = { 0 };
/* 5467 */     int[] arrayOfInt3 = { 0 };
/* 5468 */     int[] arrayOfInt4 = { 0 };
/* 5469 */     int[] arrayOfInt5 = { 0 };
/* 5470 */     int[] arrayOfInt6 = { 0 };
/* 5471 */     long[] arrayOfLong = { 0L };
/* 5472 */     byte[] arrayOfByte1 = { 0 };
/* 5473 */     int[] arrayOfInt7 = { 0 };
/* 5474 */     byte[] arrayOfByte2 = { 0 };
/* 5475 */     TIMESTAMPTZ[] arrayOfTIMESTAMPTZ = { null };
/* 5476 */     int[] arrayOfInt8 = { 0 };
/* 5477 */     byte[][] arrayOfByte = new byte[1][];
/* 5478 */     int j = paramNTFAQRegistration.getJdbcRegId();
/* 5479 */     arrayOfByte[0] = new byte[4];
/* 5480 */     arrayOfByte[0][0] = (byte)((j & 0xFF000000) >> 24);
/* 5481 */     arrayOfByte[0][1] = (byte)((j & 0xFF0000) >> 16);
/* 5482 */     arrayOfByte[0][2] = (byte)((j & 0xFF00) >> 8);
/* 5483 */     arrayOfByte[0][3] = (byte)(j & 0xFF);
/*      */     
/*      */     try {
/* 5486 */       this.okpn.doOKPN(2, 0, this.userName, str2, 1, arrayOfInt1, arrayOfString, arrayOfByte, arrayOfInt2, arrayOfInt3, arrayOfInt4, arrayOfInt5, arrayOfInt6, arrayOfLong, arrayOfByte1, arrayOfInt7, arrayOfByte2, arrayOfTIMESTAMPTZ, arrayOfInt8, arrayOfLong);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     }
/* 5509 */     catch (IOException iOException) {
/*      */       
/* 5511 */       handleIOException(iOException);
/*      */       
/* 5513 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException);
/* 5514 */       sQLException.fillInStackTrace();
/* 5515 */       throw sQLException;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   synchronized NTFDCNRegistration doRegisterDatabaseChangeNotification(String paramString, int paramInt1, Properties paramProperties, int paramInt2, int paramInt3) throws SQLException {
/* 5531 */     int i = 0;
/* 5532 */     int j = 0;
/* 5533 */     boolean bool1 = false;
/* 5534 */     boolean bool2 = false;
/* 5535 */     boolean bool3 = false;
/* 5536 */     Object object = null;
/* 5537 */     boolean bool4 = false;
/* 5538 */     boolean bool5 = false;
/* 5539 */     if (paramInt1 == 0) {
/*      */ 
/*      */       
/* 5542 */       bool5 = true;
/* 5543 */       paramInt1 = 47632;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 5548 */     if (paramProperties.getProperty("NTF_QOS_RELIABLE", "false").compareToIgnoreCase("true") == 0)
/*      */     {
/* 5550 */       j |= 0x1; } 
/* 5551 */     if (paramProperties.getProperty("NTF_QOS_PURGE_ON_NTFN", "false").compareToIgnoreCase("true") == 0)
/*      */     {
/* 5553 */       j |= 0x10;
/*      */     }
/*      */ 
/*      */     
/* 5557 */     if (paramProperties.getProperty("DCN_NOTIFY_ROWIDS", "false").compareToIgnoreCase("true") == 0)
/*      */     {
/* 5559 */       i |= 0x10;
/*      */     }
/*      */     
/* 5562 */     if (paramProperties.getProperty("DCN_QUERY_CHANGE_NOTIFICATION", "false").compareToIgnoreCase("true") == 0)
/*      */     {
/* 5564 */       i |= 0x20;
/*      */     }
/*      */     
/* 5567 */     if (paramProperties.getProperty("DCN_BEST_EFFORT", "false").compareToIgnoreCase("true") == 0)
/*      */     {
/* 5569 */       i |= 0x40;
/*      */     }
/* 5571 */     boolean bool6 = false;
/* 5572 */     boolean bool7 = false;
/* 5573 */     boolean bool8 = false;
/* 5574 */     if (paramProperties.getProperty("DCN_IGNORE_INSERTOP", "false").compareToIgnoreCase("true") == 0)
/*      */     {
/* 5576 */       bool6 = true; } 
/* 5577 */     if (paramProperties.getProperty("DCN_IGNORE_UPDATEOP", "false").compareToIgnoreCase("true") == 0)
/*      */     {
/* 5579 */       bool7 = true; } 
/* 5580 */     if (paramProperties.getProperty("DCN_IGNORE_DELETEOP", "false").compareToIgnoreCase("true") == 0)
/*      */     {
/* 5582 */       bool8 = true;
/*      */     }
/* 5584 */     if (bool6 || bool7 || bool8) {
/*      */       
/* 5586 */       i |= 0xF;
/*      */ 
/*      */ 
/*      */       
/* 5590 */       if (bool6)
/* 5591 */         i -= 2; 
/* 5592 */       if (bool7)
/* 5593 */         i -= 4; 
/* 5594 */       if (bool8) {
/* 5595 */         i -= 8;
/*      */       }
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 5601 */     byte[] arrayOfByte1 = new byte[1];
/* 5602 */     int[] arrayOfInt1 = new int[1];
/* 5603 */     byte[] arrayOfByte2 = new byte[1];
/* 5604 */     TIMESTAMPTZ[] arrayOfTIMESTAMPTZ = new TIMESTAMPTZ[1];
/* 5605 */     int[] arrayOfInt2 = new int[1];
/* 5606 */     Properties[] arrayOfProperties = { paramProperties };
/* 5607 */     setNtfGroupingOptions(arrayOfByte1, arrayOfInt1, arrayOfByte2, arrayOfTIMESTAMPTZ, arrayOfInt2, arrayOfProperties);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 5623 */     int[] arrayOfInt3 = new int[1];
/* 5624 */     arrayOfInt3[0] = paramInt1;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 5629 */     boolean bool = PhysicalConnection.ntfManager.listenOnPortT4C(arrayOfInt3, bool5);
/* 5630 */     paramInt1 = arrayOfInt3[0];
/*      */     
/* 5632 */     String str = "(ADDRESS=(PROTOCOL=tcp)(HOST=" + paramString + ")(PORT=" + paramInt1 + "))?PR=0";
/*      */ 
/*      */ 
/*      */     
/* 5636 */     int[] arrayOfInt4 = { 2 };
/* 5637 */     String[] arrayOfString = new String[1];
/* 5638 */     int[] arrayOfInt5 = { 23 };
/*      */ 
/*      */     
/* 5641 */     int[] arrayOfInt6 = { j };
/* 5642 */     int[] arrayOfInt7 = { paramInt2 };
/* 5643 */     int[] arrayOfInt8 = { i };
/* 5644 */     int[] arrayOfInt9 = { paramInt3 };
/* 5645 */     long[] arrayOfLong = { 0L };
/* 5646 */     int k = PhysicalConnection.ntfManager.getNextJdbcRegId();
/* 5647 */     byte[][] arrayOfByte = new byte[1][];
/* 5648 */     arrayOfByte[0] = new byte[4];
/* 5649 */     arrayOfByte[0][0] = (byte)((k & 0xFF000000) >> 24);
/* 5650 */     arrayOfByte[0][1] = (byte)((k & 0xFF0000) >> 16);
/* 5651 */     arrayOfByte[0][2] = (byte)((k & 0xFF00) >> 8);
/* 5652 */     arrayOfByte[0][3] = (byte)(k & 0xFF);
/* 5653 */     long l = 0L;
/*      */ 
/*      */     
/*      */     try {
/*      */       try {
/* 5658 */         boolean bool9 = bool ? true : false;
/* 5659 */         this.okpn.doOKPN(1, bool9, this.userName, str, 1, arrayOfInt4, arrayOfString, arrayOfByte, arrayOfInt5, arrayOfInt6, arrayOfInt7, arrayOfInt8, arrayOfInt9, arrayOfLong, arrayOfByte1, arrayOfInt1, arrayOfByte2, arrayOfTIMESTAMPTZ, arrayOfInt2, arrayOfLong);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 5681 */         l = this.okpn.getRegistrationId();
/*      */       }
/* 5683 */       catch (IOException iOException) {
/*      */         
/* 5685 */         handleIOException(iOException);
/*      */         
/* 5687 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException);
/* 5688 */         sQLException.fillInStackTrace();
/* 5689 */         throw sQLException;
/*      */       }
/*      */     
/*      */     }
/* 5693 */     catch (SQLException sQLException) {
/*      */       
/* 5695 */       if (bool) {
/* 5696 */         PhysicalConnection.ntfManager.cleanListenersT4C(paramInt1);
/*      */       }
/* 5698 */       throw sQLException;
/*      */     } 
/* 5700 */     return new NTFDCNRegistration(k, true, this.dbName, l, this.userName, paramString, paramInt1, paramProperties, this.versionNumber);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   synchronized void doUnregisterDatabaseChangeNotification(long paramLong, String paramString) throws SQLException {
/* 5724 */     int[] arrayOfInt1 = { 2 };
/* 5725 */     String[] arrayOfString = new String[1];
/* 5726 */     int[] arrayOfInt2 = { 0 };
/* 5727 */     int[] arrayOfInt3 = { 0 };
/* 5728 */     int[] arrayOfInt4 = { 0 };
/* 5729 */     int[] arrayOfInt5 = { 0 };
/* 5730 */     int[] arrayOfInt6 = { 0 };
/* 5731 */     byte[] arrayOfByte1 = { 0 };
/* 5732 */     int[] arrayOfInt7 = { 0 };
/* 5733 */     byte[] arrayOfByte2 = { 0 };
/* 5734 */     TIMESTAMPTZ[] arrayOfTIMESTAMPTZ = { null };
/* 5735 */     int[] arrayOfInt8 = { 0 };
/* 5736 */     long[] arrayOfLong = { paramLong };
/* 5737 */     byte[][] arrayOfByte = new byte[1][];
/*      */     
/*      */     try {
/* 5740 */       this.okpn.doOKPN(2, 0, null, paramString, 1, arrayOfInt1, arrayOfString, arrayOfByte, arrayOfInt2, arrayOfInt3, arrayOfInt4, arrayOfInt5, arrayOfInt6, arrayOfLong, arrayOfByte1, arrayOfInt7, arrayOfByte2, arrayOfTIMESTAMPTZ, arrayOfInt8, arrayOfLong);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     }
/* 5763 */     catch (IOException iOException) {
/*      */       
/* 5765 */       handleIOException(iOException);
/*      */       
/* 5767 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException);
/* 5768 */       sQLException.fillInStackTrace();
/* 5769 */       throw sQLException;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   synchronized void doUnregisterDatabaseChangeNotification(NTFDCNRegistration paramNTFDCNRegistration) throws SQLException {
/* 5782 */     PhysicalConnection.ntfManager.removeRegistration(paramNTFDCNRegistration);
/* 5783 */     PhysicalConnection.ntfManager.freeJdbcRegId(paramNTFDCNRegistration.getJdbcRegId());
/* 5784 */     PhysicalConnection.ntfManager.cleanListenersT4C(paramNTFDCNRegistration.getClientTCPPort());
/* 5785 */     paramNTFDCNRegistration.setState(NotificationRegistration.RegistrationState.CLOSED);
/*      */     
/* 5787 */     doUnregisterDatabaseChangeNotification(paramNTFDCNRegistration.getRegId(), "(ADDRESS=(PROTOCOL=tcp)(HOST=" + paramNTFDCNRegistration.getClientHost() + ")(PORT=" + paramNTFDCNRegistration.getClientTCPPort() + "))?PR=0");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getDataIntegrityAlgorithmName() throws SQLException {
/* 5797 */     return this.net.getDataIntegrityName();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getEncryptionAlgorithmName() throws SQLException {
/* 5804 */     return this.net.getEncryptionName();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getAuthenticationAdaptorName() throws SQLException {
/* 5811 */     return this.net.getAuthenticationAdaptorName();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void validateConnectionProperties() throws SQLException {
/* 5826 */     super.validateConnectionProperties();
/*      */     
/* 5828 */     String str = ".*[\\00\\(\\)].*";
/* 5829 */     if (this.thinVsessionOsuser != null && (this.thinVsessionOsuser.matches(str) || this.thinVsessionOsuser.length() > 30)) {
/*      */ 
/*      */ 
/*      */       
/* 5833 */       SQLException sQLException = DatabaseError.createSqlException((OracleConnection)null, 190, "Property is 'v$session.osuser' and value is '" + this.thinVsessionOsuser + "'");
/* 5834 */       sQLException.fillInStackTrace();
/* 5835 */       throw sQLException;
/*      */     } 
/*      */     
/* 5838 */     if (this.thinVsessionTerminal != null && (this.thinVsessionTerminal.matches(str) || this.thinVsessionTerminal.length() > 30)) {
/*      */ 
/*      */ 
/*      */       
/* 5842 */       SQLException sQLException = DatabaseError.createSqlException((OracleConnection)null, 190, "Property is 'v$session.terminal' and value is '" + this.thinVsessionTerminal + "'");
/* 5843 */       sQLException.fillInStackTrace();
/* 5844 */       throw sQLException;
/*      */     } 
/*      */     
/* 5847 */     if (this.thinVsessionMachine != null && (this.thinVsessionMachine.matches(str) || this.thinVsessionMachine.length() > 64)) {
/*      */ 
/*      */ 
/*      */       
/* 5851 */       SQLException sQLException = DatabaseError.createSqlException((OracleConnection)null, 190, "Property is 'v$session.machine' and value is '" + this.thinVsessionMachine + "'");
/* 5852 */       sQLException.fillInStackTrace();
/* 5853 */       throw sQLException;
/*      */     } 
/*      */     
/* 5856 */     if (this.thinVsessionProgram != null && (this.thinVsessionProgram.matches(str) || this.thinVsessionProgram.length() > 48)) {
/*      */ 
/*      */ 
/*      */       
/* 5860 */       SQLException sQLException = DatabaseError.createSqlException((OracleConnection)null, 190, "Property is 'v$session.program' and value is '" + this.thinVsessionProgram + "'");
/* 5861 */       sQLException.fillInStackTrace();
/* 5862 */       throw sQLException;
/*      */     } 
/*      */     
/* 5865 */     if (this.thinVsessionProcess != null && (this.thinVsessionProcess.matches(str) || this.thinVsessionProcess.length() > 24)) {
/*      */ 
/*      */ 
/*      */       
/* 5869 */       SQLException sQLException = DatabaseError.createSqlException((OracleConnection)null, 190, "Property is 'v$session.process' and value is '" + this.thinVsessionProcess + "'");
/* 5870 */       sQLException.fillInStackTrace();
/* 5871 */       throw sQLException;
/*      */     } 
/*      */     
/* 5874 */     if (this.thinVsessionIname != null && this.thinVsessionIname.matches(str)) {
/*      */       
/* 5876 */       SQLException sQLException = DatabaseError.createSqlException((OracleConnection)null, 190, "Property is 'v$session.iname' and value is '" + this.thinVsessionIname + "'");
/* 5877 */       sQLException.fillInStackTrace();
/* 5878 */       throw sQLException;
/*      */     } 
/*      */     
/* 5881 */     if (this.thinVsessionEname != null && this.thinVsessionEname.matches(str)) {
/*      */       
/* 5883 */       SQLException sQLException = DatabaseError.createSqlException((OracleConnection)null, 190, "Property is 'v$session.ename' and value is '" + this.thinVsessionEname + "'");
/* 5884 */       sQLException.fillInStackTrace();
/* 5885 */       throw sQLException;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized byte[] createLightweightSession(String paramString, KeywordValueLong[] paramArrayOfKeywordValueLong, int paramInt, KeywordValueLong[][] paramArrayOfKeywordValueLong1, int[] paramArrayOfint) throws SQLException {
/* 5899 */     if (paramArrayOfKeywordValueLong1.length != 1 || paramArrayOfint.length != 1) {
/*      */       
/* 5901 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/* 5902 */       sQLException.fillInStackTrace();
/* 5903 */       throw sQLException;
/*      */     } 
/*      */     
/* 5906 */     byte[] arrayOfByte = null;
/*      */     
/*      */     try {
/* 5909 */       this.oxsscs.doOXSSCS(paramString, paramArrayOfKeywordValueLong, paramInt);
/* 5910 */       arrayOfByte = this.oxsscs.getSessionId();
/* 5911 */       paramArrayOfKeywordValueLong1[0] = this.oxsscs.getOutKV();
/* 5912 */       paramArrayOfint[0] = this.oxsscs.getOutFlags();
/*      */     }
/* 5914 */     catch (IOException iOException) {
/*      */       
/* 5916 */       handleIOException(iOException);
/*      */       
/* 5918 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException);
/* 5919 */       sQLException.fillInStackTrace();
/* 5920 */       throw sQLException;
/*      */     } 
/*      */     
/* 5923 */     return arrayOfByte;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private synchronized void doXSNamespaceOp(OracleConnection.XSOperationCode paramXSOperationCode, byte[] paramArrayOfbyte, XSNamespace[] paramArrayOfXSNamespace, XSNamespace[][] paramArrayOfXSNamespace1, XSSecureId paramXSSecureId, boolean paramBoolean) throws SQLException {
/* 5941 */     XSNamespace[] arrayOfXSNamespace = null;
/*      */     try {
/* 5943 */       this.xsnsop2.doOXSNS(paramXSOperationCode, paramArrayOfbyte, paramArrayOfXSNamespace, paramXSSecureId, paramBoolean);
/* 5944 */       if (paramBoolean)
/* 5945 */         arrayOfXSNamespace = this.xsnsop2.getNamespaces(); 
/* 5946 */     } catch (IOException iOException) {
/* 5947 */       handleIOException(iOException);
/*      */       
/* 5949 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException);
/* 5950 */       sQLException.fillInStackTrace();
/* 5951 */       throw sQLException;
/*      */     } 
/*      */     
/* 5954 */     if (paramArrayOfXSNamespace1 != null && paramArrayOfXSNamespace1.length > 0) {
/* 5955 */       paramArrayOfXSNamespace1[0] = arrayOfXSNamespace;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void doXSSessionDetachOp(int paramInt, byte[] paramArrayOfbyte, XSSecureId paramXSSecureId, boolean paramBoolean) throws SQLException {
/*      */     try {
/* 5968 */       this.oxsdet.doOXSDET(paramInt, paramArrayOfbyte, paramXSSecureId, paramBoolean);
/*      */     }
/* 5970 */     catch (IOException iOException) {
/* 5971 */       handleIOException(iOException);
/*      */       
/* 5973 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException);
/* 5974 */       sQLException.fillInStackTrace();
/* 5975 */       throw sQLException;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void doXSNamespaceOp(OracleConnection.XSOperationCode paramXSOperationCode, byte[] paramArrayOfbyte, XSNamespace[] paramArrayOfXSNamespace, XSNamespace[][] paramArrayOfXSNamespace1, XSSecureId paramXSSecureId) throws SQLException {
/* 5992 */     doXSNamespaceOp(paramXSOperationCode, paramArrayOfbyte, paramArrayOfXSNamespace, paramArrayOfXSNamespace1, paramXSSecureId, true);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void doXSNamespaceOp(OracleConnection.XSOperationCode paramXSOperationCode, byte[] paramArrayOfbyte, XSNamespace[] paramArrayOfXSNamespace, XSSecureId paramXSSecureId) throws SQLException {
/* 6005 */     doXSNamespaceOp(paramXSOperationCode, paramArrayOfbyte, paramArrayOfXSNamespace, (XSNamespace[][])null, paramXSSecureId, false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public byte[] doXSSessionCreateOp(OracleConnection.XSSessionOperationCode paramXSSessionOperationCode, XSSecureId paramXSSecureId, byte[] paramArrayOfbyte, XSPrincipal paramXSPrincipal, String paramString, XSNamespace[] paramArrayOfXSNamespace, OracleConnection.XSSessionModeFlag paramXSSessionModeFlag, XSKeyval paramXSKeyval) throws SQLException {
/* 6020 */     byte[] arrayOfByte = null;
/*      */     
/*      */     try {
/* 6023 */       this.oxscre.doOXSCRE(paramXSSessionOperationCode, paramXSSecureId, paramArrayOfbyte, paramXSPrincipal, paramString, paramArrayOfXSNamespace, paramXSSessionModeFlag, paramXSKeyval);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 6032 */       arrayOfByte = this.oxscre.getSessionId();
/* 6033 */     } catch (IOException iOException) {
/* 6034 */       handleIOException(iOException);
/*      */       
/* 6036 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException);
/* 6037 */       sQLException.fillInStackTrace();
/* 6038 */       throw sQLException;
/*      */     } 
/*      */     
/* 6041 */     return arrayOfByte;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void doXSSessionDestroyOp(byte[] paramArrayOfbyte1, XSSecureId paramXSSecureId, byte[] paramArrayOfbyte2) throws SQLException {
/*      */     try {
/* 6053 */       this.oxsdes.doOXSDES(paramArrayOfbyte1, paramXSSecureId, paramArrayOfbyte2);
/*      */ 
/*      */     
/*      */     }
/* 6057 */     catch (IOException iOException) {
/* 6058 */       handleIOException(iOException);
/*      */       
/* 6060 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException);
/* 6061 */       sQLException.fillInStackTrace();
/* 6062 */       throw sQLException;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void doXSSessionAttachOp(int paramInt1, byte[] paramArrayOfbyte1, XSSecureId paramXSSecureId, byte[] paramArrayOfbyte2, XSPrincipal paramXSPrincipal, String[] paramArrayOfString1, String[] paramArrayOfString2, String[] paramArrayOfString3, XSNamespace[] paramArrayOfXSNamespace1, XSNamespace[] paramArrayOfXSNamespace2, XSNamespace[] paramArrayOfXSNamespace3, TIMESTAMPTZ paramTIMESTAMPTZ1, TIMESTAMPTZ paramTIMESTAMPTZ2, int paramInt2, long paramLong, XSKeyval paramXSKeyval, int[] paramArrayOfint) throws SQLException {
/*      */     try {
/* 6096 */       this.oxsatt.doOXSATT(paramInt1, paramArrayOfbyte1, paramXSSecureId, paramArrayOfbyte2, paramXSPrincipal, paramArrayOfString1, paramArrayOfString2, paramArrayOfString3, paramArrayOfXSNamespace1, paramArrayOfXSNamespace2, paramArrayOfXSNamespace3, paramTIMESTAMPTZ1, paramTIMESTAMPTZ2, paramInt2, paramLong, paramXSKeyval, paramArrayOfint);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     }
/* 6114 */     catch (IOException iOException) {
/* 6115 */       handleIOException(iOException);
/*      */       
/* 6117 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException);
/* 6118 */       sQLException.fillInStackTrace();
/* 6119 */       throw sQLException;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void doXSSessionChangeOp(OracleConnection.XSSessionSetOperationCode paramXSSessionSetOperationCode, byte[] paramArrayOfbyte, XSSecureId paramXSSecureId, XSSessionParameters paramXSSessionParameters) throws SQLException {
/*      */     try {
/* 6135 */       this.oxsset.doOXSSET(paramXSSessionSetOperationCode, paramArrayOfbyte, paramXSSecureId, (XSSessionParametersI)paramXSSessionParameters);
/*      */ 
/*      */ 
/*      */     
/*      */     }
/* 6140 */     catch (IOException iOException) {
/* 6141 */       handleIOException(iOException);
/*      */       
/* 6143 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException);
/* 6144 */       sQLException.fillInStackTrace();
/* 6145 */       throw sQLException;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void addLogicalTransactionIdEventListener(LogicalTransactionIdEventListener paramLogicalTransactionIdEventListener, Executor paramExecutor) throws SQLException {
/* 6163 */     if (this.lifecycle != 1) {
/*      */       
/* 6165 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 8);
/* 6166 */       sQLException.fillInStackTrace();
/* 6167 */       throw sQLException;
/*      */     } 
/*      */     
/* 6170 */     NTFEventListener nTFEventListener = new NTFEventListener(paramLogicalTransactionIdEventListener);
/* 6171 */     nTFEventListener.setExecutor(paramExecutor);
/* 6172 */     synchronized (this.ltxidListeners) {
/*      */       
/* 6174 */       int i = this.ltxidListeners.length;
/* 6175 */       for (byte b = 0; b < i; b++) {
/* 6176 */         if (this.ltxidListeners[b].getLogicalTransactionIdEventListener() == paramLogicalTransactionIdEventListener) {
/*      */ 
/*      */ 
/*      */           
/* 6180 */           SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 248);
/* 6181 */           sQLException.fillInStackTrace();
/* 6182 */           throw sQLException;
/*      */         } 
/*      */       } 
/*      */       
/* 6186 */       NTFEventListener[] arrayOfNTFEventListener = new NTFEventListener[i + 1];
/* 6187 */       System.arraycopy(this.ltxidListeners, 0, arrayOfNTFEventListener, 0, i);
/*      */       
/* 6189 */       arrayOfNTFEventListener[i] = nTFEventListener;
/*      */       
/* 6191 */       this.ltxidListeners = arrayOfNTFEventListener;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void addLogicalTransactionIdEventListener(LogicalTransactionIdEventListener paramLogicalTransactionIdEventListener) throws SQLException {
/* 6206 */     addLogicalTransactionIdEventListener(paramLogicalTransactionIdEventListener, (Executor)null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void removeLogicalTransactionIdEventListener(LogicalTransactionIdEventListener paramLogicalTransactionIdEventListener) throws SQLException {
/* 6219 */     synchronized (this.ltxidListeners) {
/*      */ 
/*      */       
/* 6222 */       byte b1 = 0;
/* 6223 */       int i = this.ltxidListeners.length;
/*      */       
/* 6225 */       for (b1 = 0; b1 < i && 
/* 6226 */         this.ltxidListeners[b1].getLogicalTransactionIdEventListener() != paramLogicalTransactionIdEventListener; b1++);
/*      */       
/* 6228 */       if (b1 == i) {
/*      */ 
/*      */ 
/*      */         
/* 6232 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 249);
/* 6233 */         sQLException.fillInStackTrace();
/* 6234 */         throw sQLException;
/*      */       } 
/*      */ 
/*      */       
/* 6238 */       NTFEventListener[] arrayOfNTFEventListener = new NTFEventListener[i - 1];
/* 6239 */       byte b2 = 0;
/* 6240 */       for (b1 = 0; b1 < i; b1++) {
/* 6241 */         if (this.ltxidListeners[b1].getLogicalTransactionIdEventListener() != paramLogicalTransactionIdEventListener) {
/* 6242 */           arrayOfNTFEventListener[b2++] = this.ltxidListeners[b1];
/*      */         }
/*      */       } 
/* 6245 */       this.ltxidListeners = arrayOfNTFEventListener;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public LogicalTransactionId getLogicalTransactionId() throws SQLException {
/* 6257 */     return this.thinACCurrentLTXID;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   boolean notify(final NTFLTXIDEvent event) {
/* 6264 */     boolean bool = false;
/* 6265 */     if (this.ltxidListeners != null) {
/*      */       
/* 6267 */       NTFEventListener[] arrayOfNTFEventListener = this.ltxidListeners;
/*      */ 
/*      */ 
/*      */       
/* 6271 */       int i = arrayOfNTFEventListener.length;
/* 6272 */       if (i > 0)
/* 6273 */         bool = true; 
/* 6274 */       for (byte b = 0; b < i; b++) {
/*      */         
/* 6276 */         Executor executor = arrayOfNTFEventListener[b].getExecutor();
/* 6277 */         if (executor != null) {
/*      */           
/* 6279 */           final LogicalTransactionIdEventListener l = arrayOfNTFEventListener[b].getLogicalTransactionIdEventListener();
/*      */           
/* 6281 */           executor.execute(new Runnable() {
/*      */                 public void run() {
/* 6283 */                   l.onLogicalTransactionIdEvent(event);
/*      */                 }
/*      */               });
/*      */         }
/*      */         else {
/*      */           
/* 6289 */           arrayOfNTFEventListener[b].getLogicalTransactionIdEventListener().onLogicalTransactionIdEvent(event);
/*      */         } 
/*      */       } 
/*      */     } 
/*      */     
/* 6294 */     return bool;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void addXSEventListener(XSEventListener paramXSEventListener, Executor paramExecutor) throws SQLException {
/* 6310 */     if (this.lifecycle != 1) {
/*      */       
/* 6312 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 8);
/* 6313 */       sQLException.fillInStackTrace();
/* 6314 */       throw sQLException;
/*      */     } 
/*      */     
/* 6317 */     NTFEventListener nTFEventListener = new NTFEventListener(paramXSEventListener);
/* 6318 */     nTFEventListener.setExecutor(paramExecutor);
/* 6319 */     synchronized (this.xsListeners) {
/*      */       
/* 6321 */       int i = this.xsListeners.length;
/* 6322 */       for (byte b = 0; b < i; b++) {
/* 6323 */         if (this.xsListeners[b].getXSEventListener() == paramXSEventListener) {
/*      */ 
/*      */ 
/*      */           
/* 6327 */           SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 248);
/* 6328 */           sQLException.fillInStackTrace();
/* 6329 */           throw sQLException;
/*      */         } 
/*      */       } 
/*      */       
/* 6333 */       NTFEventListener[] arrayOfNTFEventListener = new NTFEventListener[i + 1];
/* 6334 */       System.arraycopy(this.xsListeners, 0, arrayOfNTFEventListener, 0, i);
/*      */       
/* 6336 */       arrayOfNTFEventListener[i] = nTFEventListener;
/*      */       
/* 6338 */       this.xsListeners = arrayOfNTFEventListener;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void addXSEventListener(XSEventListener paramXSEventListener) throws SQLException {
/* 6353 */     addXSEventListener(paramXSEventListener, (Executor)null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void removeXSEventListener(XSEventListener paramXSEventListener) throws SQLException {
/* 6366 */     synchronized (this.xsListeners) {
/*      */ 
/*      */       
/* 6369 */       byte b1 = 0;
/* 6370 */       int i = this.xsListeners.length;
/*      */       
/* 6372 */       for (b1 = 0; b1 < i && 
/* 6373 */         this.xsListeners[b1].getXSEventListener() != paramXSEventListener; b1++);
/*      */       
/* 6375 */       if (b1 == i) {
/*      */ 
/*      */ 
/*      */         
/* 6379 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 249);
/* 6380 */         sQLException.fillInStackTrace();
/* 6381 */         throw sQLException;
/*      */       } 
/*      */ 
/*      */       
/* 6385 */       NTFEventListener[] arrayOfNTFEventListener = new NTFEventListener[i - 1];
/* 6386 */       byte b2 = 0;
/* 6387 */       for (b1 = 0; b1 < i; b1++) {
/* 6388 */         if (this.xsListeners[b1].getXSEventListener() != paramXSEventListener) {
/* 6389 */           arrayOfNTFEventListener[b2++] = this.xsListeners[b1];
/*      */         }
/*      */       } 
/* 6392 */       this.xsListeners = arrayOfNTFEventListener;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void removeAllXSEventListener() throws SQLException {
/* 6405 */     synchronized (this.xsListeners) {
/*      */       
/* 6407 */       NTFEventListener[] arrayOfNTFEventListener = new NTFEventListener[0];
/*      */       
/* 6409 */       this.xsListeners = arrayOfNTFEventListener;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void notify(final NTFXSEvent event) {
/* 6421 */     NTFEventListener[] arrayOfNTFEventListener = this.xsListeners;
/*      */ 
/*      */ 
/*      */     
/* 6425 */     int i = arrayOfNTFEventListener.length;
/* 6426 */     for (byte b = 0; b < i; b++) {
/*      */       
/* 6428 */       Executor executor = arrayOfNTFEventListener[b].getExecutor();
/* 6429 */       if (executor != null) {
/*      */         
/* 6431 */         final XSEventListener l = arrayOfNTFEventListener[b].getXSEventListener();
/*      */         
/* 6433 */         executor.execute(new Runnable() {
/*      */               public void run() {
/* 6435 */                 l.onXSEvent(event);
/*      */               }
/*      */             });
/*      */       }
/*      */       else {
/*      */         
/* 6441 */         arrayOfNTFEventListener[b].getXSEventListener().onXSEvent(event);
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final boolean hasServerCompileTimeCapability(int paramInt1, int paramInt2) {
/* 6464 */     boolean bool = false;
/* 6465 */     if (this.serverCompileTimeCapabilities != null && this.serverCompileTimeCapabilities.length > paramInt1 && (this.serverCompileTimeCapabilities[paramInt1] & paramInt2) != 0)
/*      */     {
/*      */ 
/*      */ 
/*      */       
/* 6470 */       bool = true;
/*      */     }
/* 6472 */     return bool;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   long doGetCurrentSCN() throws SQLException {
/* 6480 */     return this.outScn;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   EnumSet<OracleConnection.TransactionState> doGetTransactionState() throws SQLException {
/* 6487 */     EnumSet<OracleConnection.TransactionState> enumSet = EnumSet.noneOf(OracleConnection.TransactionState.class);
/* 6488 */     if ((this.eocs & 0x1) != 0)
/*      */     {
/* 6490 */       enumSet.add(OracleConnection.TransactionState.TRANSACTION_READONLY);
/*      */     }
/* 6492 */     if ((this.eocs & 0x2) != 0)
/*      */     {
/* 6494 */       enumSet.add(OracleConnection.TransactionState.TRANSACTION_STARTED);
/*      */     }
/* 6496 */     if ((this.eocs & 0x4) != 0)
/*      */     {
/* 6498 */       enumSet.add(OracleConnection.TransactionState.TRANSACTION_ENDED);
/*      */     }
/* 6500 */     if ((this.eocs & 0x400) != 0)
/*      */     {
/* 6502 */       enumSet.add(OracleConnection.TransactionState.TRANSACTION_INTENTION);
/*      */     }
/* 6504 */     return enumSet;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isConnectionSocketKeepAlive() throws SocketException {
/* 6511 */     return this.net.isConnectionSocketKeepAlive();
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public int getEOC() throws SQLException {
/* 6517 */     return this.eocs;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void setReplayOperations(EnumSet<OracleConnection.ReplayOperation> paramEnumSet) throws SQLException {
/* 6523 */     if (this.ossestateOperations == OracleConnection.ReplayOperation.KPDSS_SESSSTATE_REQUEST_END.getCode() && paramEnumSet.size() == 0) {
/*      */       return;
/*      */     }
/*      */ 
/*      */ 
/*      */     
/* 6529 */     this.ossestateOperations = 0L;
/*      */     
/* 6531 */     Iterator<OracleConnection.ReplayOperation> iterator = paramEnumSet.iterator();
/* 6532 */     while (iterator.hasNext()) {
/* 6533 */       this.ossestateOperations |= ((OracleConnection.ReplayOperation)iterator.next()).getCode();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 6539 */     if ((this.ossestateOperations & OracleConnection.ReplayOperation.KPDSS_SESSSTATE_APPCONT_ENABLED.getCode()) != 0L) {
/* 6540 */       this.replayModes.add(ReplayMode.RUNTIME_REPLAY_ENABLED);
/*      */     } else {
/* 6542 */       this.replayModes.remove(ReplayMode.RUNTIME_REPLAY_ENABLED);
/*      */     } 
/* 6544 */     if ((this.ossestateOperations & OracleConnection.ReplayOperation.KPDSS_SESSSTATE_STATIC.getCode()) != 0L) {
/* 6545 */       this.replayModes.add(ReplayMode.RUNTIME_OR_REPLAYING_STATIC);
/*      */     } else {
/* 6547 */       this.replayModes.remove(ReplayMode.RUNTIME_OR_REPLAYING_STATIC);
/*      */     } 
/*      */   }
/*      */   
/*      */   public synchronized void setReplayingMode(boolean paramBoolean) throws SQLException {
/* 6552 */     if (paramBoolean) {
/*      */       
/* 6554 */       this.replayModes.remove(ReplayMode.RUNTIME_REPLAY_ENABLED);
/* 6555 */       this.replayModes.add(ReplayMode.REPLAYING);
/*      */     } else {
/*      */       
/* 6558 */       this.replayModes.remove(ReplayMode.REPLAYING);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void beginNonRequestCalls() throws SQLException {
/* 6567 */     this.replayModes.add(ReplayMode.NONREQUEST);
/*      */   }
/*      */   
/*      */   public synchronized void endNonRequestCalls() throws SQLException {
/* 6571 */     this.replayModes.remove(ReplayMode.NONREQUEST);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void setReplayContext(ReplayContext[] paramArrayOfReplayContext) throws SQLException {
/* 6578 */     if (paramArrayOfReplayContext != null) {
/*      */       
/* 6580 */       this.oappcontreplayContextsArr = paramArrayOfReplayContext;
/* 6581 */       this.oappcontreplayOffset = 0;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized ReplayContext[] getReplayContext() throws SQLException {
/* 6593 */     if (this.thinACReplayContextReceivedCurrent == 0) {
/* 6594 */       return null;
/*      */     }
/*      */ 
/*      */     
/* 6598 */     ReplayContext[] arrayOfReplayContext = new ReplayContext[this.thinACReplayContextReceivedCurrent];
/* 6599 */     System.arraycopy(this.thinACReplayContextReceived, 0, arrayOfReplayContext, 0, this.thinACReplayContextReceivedCurrent);
/*      */ 
/*      */     
/* 6602 */     this.thinACReplayContextReceivedCurrent = 0;
/* 6603 */     return arrayOfReplayContext;
/*      */   }
/*      */ 
/*      */   
/*      */   public ReplayContext getLastReplayContext() throws SQLException {
/* 6608 */     return this.thinACLastReplayContextReceived;
/*      */   }
/*      */   
/*      */   public void registerEndReplayCallback(OracleConnection.EndReplayCallback paramEndReplayCallback) throws SQLException {
/* 6612 */     this.endReplayCallback = paramEndReplayCallback;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public byte[] getDerivedKeyInternal(byte[] paramArrayOfbyte, int paramInt) throws NoSuchAlgorithmException, InvalidKeySpecException, SQLException {
/* 6622 */     return this.auth.getDerivedKeyJdbc(paramArrayOfbyte, paramInt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void releaseConnectionToPool() throws SQLException {
/*      */     
/* 6630 */     try { if (this.drcpState != PhysicalConnection.DrcpState.STATEFUL)
/*      */         return; 
/* 6632 */       this.drcpState = PhysicalConnection.DrcpState.STATELESS;
/* 6633 */       if (this.currentlyInTransaction) {
/*      */         
/* 6635 */         this.osessrls.setTTCCode((byte)3);
/* 6636 */         this.osessrls.doRPC();
/*      */       }
/*      */       else {
/*      */         
/* 6640 */         this.osessrls.setTTCCode((byte)26);
/* 6641 */         this.osessrls.doOneWayRPC();
/*      */       }  }
/* 6643 */     catch (IOException iOException) { handleIOException(iOException); }
/* 6644 */     catch (SQLException sQLException)
/* 6645 */     { if (this.currentlyInTransaction)
/*      */       {
/* 6647 */         throw sQLException;
/*      */       } }
/*      */   
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   boolean reusePooledConnection() throws SQLException {
/* 6660 */     if (this.drcpState != PhysicalConnection.DrcpState.STATEFUL) {
/* 6661 */       this.drcpState = PhysicalConnection.DrcpState.STATEFUL;
/*      */ 
/*      */       
/* 6664 */       try { if (this.drcpTagName != null) {
/*      */           
/* 6666 */           this.osessget.doRPC();
/* 6667 */           resetAfterReusePooledConnection();
/*      */         }  }
/* 6669 */       catch (IOException iOException) { handleIOException(iOException); }
/*      */     
/*      */     } 
/* 6672 */     return !bit(this.ocsessret.sessretflags, 1L);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean needToPurgeStatementCache() throws SQLException {
/* 6692 */     if (this.lifecycle != 1) {
/*      */       
/* 6694 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 8);
/* 6695 */       sQLException.fillInStackTrace();
/* 6696 */       throw sQLException;
/*      */     } 
/*      */     
/* 6699 */     if (!this.drcpEnabled) return false; 
/* 6700 */     return (bit(this.ocsessret.sessretflags, 4L) || bit(this.ocsessret.sessretflags, 8L));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getNetworkTimeout() throws SQLException {
/*      */     try {
/* 6724 */       return this.net.getSocketReadTimeout();
/*      */     }
/* 6726 */     catch (NetException netException) {
/*      */       
/* 6728 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), (IOException)netException);
/* 6729 */       sQLException.fillInStackTrace();
/* 6730 */       throw sQLException;
/*      */     
/*      */     }
/* 6733 */     catch (IOException iOException) {
/*      */       
/* 6735 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException);
/* 6736 */       sQLException.fillInStackTrace();
/* 6737 */       throw sQLException;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void doSetNetworkTimeout(int paramInt) throws SQLException {
/*      */     try {
/* 6752 */       this.net.setSocketReadTimeout(paramInt);
/*      */     }
/* 6754 */     catch (NetException netException) {
/*      */       
/* 6756 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), (IOException)netException);
/* 6757 */       sQLException.fillInStackTrace();
/* 6758 */       throw sQLException;
/*      */     
/*      */     }
/* 6761 */     catch (IOException iOException) {
/*      */       
/* 6763 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException);
/* 6764 */       sQLException.fillInStackTrace();
/* 6765 */       throw sQLException;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static final String dumpObject(Object paramObject, String paramString) {
/* 6778 */     return dumpObject(paramObject, paramString, new StringBuilder());
/*      */   }
/*      */ 
/*      */   
/*      */   static final String dumpObject(Object paramObject, String paramString, StringBuilder paramStringBuilder) {
/* 6783 */     Class<?> clazz = paramObject.getClass();
/* 6784 */     Field[] arrayOfField = clazz.getDeclaredFields();
/*      */     
/* 6786 */     paramStringBuilder.append(paramString + clazz.getName() + " { \n");
/* 6787 */     for (Field field : arrayOfField) {
/*      */       
/* 6789 */       if ((field.getModifiers() & 0x8) == 0) {
/*      */ 
/*      */ 
/*      */         
/* 6793 */         field.setAccessible(true);
/*      */         
/*      */         try {
/* 6796 */           paramStringBuilder.append(paramString + "  " + field.getName() + " = ");
/*      */           
/* 6798 */           Object object = field.get(paramObject);
/* 6799 */           if (object == null) {
/* 6800 */             paramStringBuilder.append("null");
/*      */           }
/*      */           else {
/*      */             
/* 6804 */             paramStringBuilder.append(object);
/*      */           } 
/* 6806 */           paramStringBuilder.append("\n");
/* 6807 */         } catch (IllegalAccessException illegalAccessException) {}
/*      */       } 
/* 6809 */     }  paramStringBuilder.append(paramString + "}\n");
/*      */     
/* 6811 */     return paramStringBuilder.toString();
/*      */   }
/*      */ 
/*      */   
/*      */   byte getNextSeqNumber() {
/* 6816 */     if (this.currentTTCSeqNumber == Byte.MAX_VALUE) {
/*      */       
/* 6818 */       this.currentTTCSeqNumber = 1;
/* 6819 */       return this.currentTTCSeqNumber;
/*      */     } 
/*      */     
/* 6822 */     return this.currentTTCSeqNumber = (byte)(this.currentTTCSeqNumber + 1);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public int getNegotiatedSDU() throws SQLException {
/*      */     try {
/* 6829 */       return this.net.getNegotiatedSDU();
/*      */     }
/* 6831 */     catch (NetException netException) {
/*      */       
/* 6833 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), (IOException)netException);
/* 6834 */       sQLException.fillInStackTrace();
/* 6835 */       throw sQLException;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 6842 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*      */   public static final String BUILD_DATE = "Thu_Apr_04_15:09:24_PDT_2013";
/*      */   public static final boolean TRACE = false;
/*      */ }


/* Location:              C:\Users\olatu\OneDrive\Documents\Calypso\syncbase\sync_base.jar!\BOOT-INF\classes\ojdbc.jar!\oracle\jdbc\driver\T4CConnection.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */