/*     */ package oracle.jdbc.driver;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.sql.SQLException;
/*     */ import oracle.jdbc.internal.KeywordValueLong;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class T4CTTIoxsspo
/*     */   extends T4CTTIfun
/*     */ {
/*     */   private int functionId;
/*     */   private byte[] sessionId;
/*     */   private KeywordValueLong[] inKV;
/*     */   private int inFlags;
/*     */   
/*     */   T4CTTIoxsspo(T4CConnection paramT4CConnection) {
/*  60 */     super(paramT4CConnection, (byte)17);
/*     */     
/*  62 */     setFunCode((short)157);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void doOXSSPO(int paramInt1, byte[] paramArrayOfbyte, KeywordValueLong[] paramArrayOfKeywordValueLong, int paramInt2) throws IOException, SQLException {
/*  78 */     this.functionId = paramInt1;
/*  79 */     this.sessionId = paramArrayOfbyte;
/*  80 */     this.inKV = paramArrayOfKeywordValueLong;
/*  81 */     this.inFlags = paramInt2;
/*  82 */     if (this.inKV != null)
/*  83 */       for (byte b = 0; b < this.inKV.length; b++)
/*  84 */         ((KeywordValueLongI)this.inKV[b]).doCharConversion(this.meg.conv);  
/*  85 */     doPigRPC();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void marshal() throws IOException {
/*  92 */     this.meg.marshalUB4(this.functionId);
/*  93 */     boolean bool1 = false;
/*  94 */     if (this.sessionId != null && this.sessionId.length > 0) {
/*     */       
/*  96 */       bool1 = true;
/*  97 */       this.meg.marshalPTR();
/*  98 */       this.meg.marshalUB4(this.sessionId.length);
/*     */     }
/*     */     else {
/*     */       
/* 102 */       this.meg.marshalNULLPTR();
/* 103 */       this.meg.marshalUB4(0L);
/*     */     } 
/*     */     
/* 106 */     boolean bool2 = false;
/* 107 */     if (this.inKV != null && this.inKV.length > 0) {
/*     */       
/* 109 */       bool2 = true;
/* 110 */       this.meg.marshalPTR();
/* 111 */       this.meg.marshalUB4(this.inKV.length);
/*     */     }
/*     */     else {
/*     */       
/* 115 */       this.meg.marshalNULLPTR();
/* 116 */       this.meg.marshalUB4(0L);
/*     */     } 
/* 118 */     this.meg.marshalUB4(this.inFlags);
/*     */ 
/*     */     
/* 121 */     if (bool1)
/* 122 */       this.meg.marshalB1Array(this.sessionId); 
/* 123 */     if (bool2) {
/* 124 */       for (byte b = 0; b < this.inKV.length; b++) {
/* 125 */         ((KeywordValueLongI)this.inKV[b]).marshal(this.meg);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/* 130 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*     */   public static final String BUILD_DATE = "Thu_Apr_04_15:09:24_PDT_2013";
/*     */   public static final boolean TRACE = false;
/*     */ }


/* Location:              C:\Users\olatu\OneDrive\Documents\Calypso\syncbase\sync_base.jar!\BOOT-INF\classes\ojdbc.jar!\oracle\jdbc\driver\T4CTTIoxsspo.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */