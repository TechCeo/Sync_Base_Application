/*    */ package oracle.jdbc.driver;
/*    */ 
/*    */ import oracle.jdbc.dcn.RowChangeDescription;
/*    */ import oracle.sql.ROWID;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class NTFDCNRowChanges
/*    */   implements RowChangeDescription
/*    */ {
/*    */   RowChangeDescription.RowOperation opcode;
/*    */   int rowidLength;
/*    */   byte[] rowid;
/*    */   ROWID rowidObj;
/*    */   
/*    */   NTFDCNRowChanges(RowChangeDescription.RowOperation paramRowOperation, int paramInt, byte[] paramArrayOfbyte) {
/* 37 */     this.opcode = paramRowOperation;
/* 38 */     this.rowidLength = paramInt;
/* 39 */     this.rowid = paramArrayOfbyte;
/* 40 */     this.rowidObj = null;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public ROWID getRowid() {
/* 52 */     if (this.rowidObj == null)
/* 53 */       this.rowidObj = new ROWID(this.rowid); 
/* 54 */     return this.rowidObj;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public RowChangeDescription.RowOperation getRowOperation() {
/* 60 */     return this.opcode;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String toString() {
/* 72 */     StringBuffer stringBuffer = new StringBuffer();
/* 73 */     stringBuffer.append("      ROW:  operation=" + getRowOperation() + ", ROWID=" + new String(this.rowid) + "\n");
/* 74 */     return stringBuffer.toString();
/*    */   }
/*    */ 
/*    */   
/* 78 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*    */   public static final String BUILD_DATE = "Thu_Apr_04_15:09:24_PDT_2013";
/*    */   public static final boolean TRACE = false;
/*    */ }


/* Location:              C:\Users\olatu\OneDrive\Documents\Calypso\syncbase\sync_base.jar!\BOOT-INF\classes\ojdbc.jar!\oracle\jdbc\driver\NTFDCNRowChanges.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */