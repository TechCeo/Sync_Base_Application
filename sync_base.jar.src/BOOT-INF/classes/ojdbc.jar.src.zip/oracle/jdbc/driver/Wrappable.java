package oracle.jdbc.driver;

interface Wrappable<T> {
  void setWrapper(T paramT);
}


/* Location:              C:\Users\olatu\OneDrive\Documents\Calypso\syncbase\sync_base.jar!\BOOT-INF\classes\ojdbc.jar!\oracle\jdbc\driver\Wrappable.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */