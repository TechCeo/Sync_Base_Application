/*      */ package oracle.jdbc.driver;
/*      */ 
/*      */ import java.io.IOException;
/*      */ import java.math.BigDecimal;
/*      */ import java.sql.Connection;
/*      */ import java.sql.Date;
/*      */ import java.sql.SQLException;
/*      */ import java.sql.Time;
/*      */ import java.sql.Timestamp;
/*      */ import java.text.DateFormatSymbols;
/*      */ import java.util.Calendar;
/*      */ import java.util.GregorianCalendar;
/*      */ import oracle.jdbc.OracleResultSetMetaData;
/*      */ import oracle.jdbc.internal.OracleConnection;
/*      */ import oracle.sql.DATE;
/*      */ import oracle.sql.Datum;
/*      */ import oracle.sql.NUMBER;
/*      */ import oracle.sql.RAW;
/*      */ import oracle.sql.TIMESTAMP;
/*      */ import oracle.sql.TIMESTAMPLTZ;
/*      */ import oracle.sql.TIMESTAMPTZ;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ class T4CVarcharAccessor
/*      */   extends VarcharAccessor
/*      */   implements T4CAccessor
/*      */ {
/*      */   T4CMAREngine mare;
/*      */   static final int MAX_CALL_LENGTH_PRE102 = 4001;
/*      */   static final int MIN_SQL_LENGTH = 32;
/*      */   boolean underlyingLong = false;
/*      */   private T4CMarshaller marshaller;
/*      */   static final int NONE = -1;
/*      */   static final int DAY = 1;
/*      */   static final int MM_MONTH = 2;
/*      */   static final int FULL_MONTH = 3;
/*      */   static final int MON_MONTH = 4;
/*      */   static final int YY_YEAR = 5;
/*      */   static final int RR_YEAR = 6;
/*      */   static final int HH_HOUR = 7;
/*      */   static final int HH24_HOUR = 8;
/*      */   static final int MINUTE = 9;
/*      */   static final int SECOND = 10;
/*      */   static final int NSECOND = 11;
/*      */   static final int AM = 12;
/*      */   static final int TZR = 13;
/*      */   static final int TZH = 14;
/*      */   static final int TZM = 15;
/*      */   
/*      */   T4CVarcharAccessor(OracleStatement paramOracleStatement, int paramInt1, short paramShort, int paramInt2, boolean paramBoolean, T4CMAREngine paramT4CMAREngine) throws SQLException {
/*   64 */     super(paramOracleStatement, paramInt1, paramShort, paramInt2, paramBoolean);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  708 */     this.marshaller = null; this.mare = paramT4CMAREngine; calculateSizeTmpByteArray(); } public T4CMAREngine getMAREngine() { return this.mare; } public void unmarshalColumnMetadata() throws SQLException, IOException { if (this.statement.statementType != 2 && !this.statement.sqlKind.isPlsqlOrCall() && this.securityAttribute == OracleResultSetMetaData.SecurityAttribute.ENABLED) setRowMetadata(this.lastRowProcessed, (byte)this.mare.unmarshalUB1());  } public void processIndicator(int paramInt) throws IOException, SQLException { if ((this.internalType == 1 && this.describeType == 112) || (this.internalType == 23 && this.describeType == 113)) { this.mare.unmarshalUB2(); this.mare.unmarshalUB2(); } else if (this.statement.connection.versionNumber < 9200) { this.mare.unmarshalSB2(); if (!this.statement.sqlKind.isPlsqlOrCall()) this.mare.unmarshalSB2();  } else if (this.statement.sqlKind.isPlsqlOrCall() || this.isDMLReturnedParam) { this.mare.processIndicator((paramInt <= 0), paramInt); }  } int getPreviousRowProcessed() { if (this.previousRowProcessed == -1) this.previousRowProcessed = this.statement.rowPrefetchInLastFetch - 1;  return this.previousRowProcessed; } void copyRow() throws SQLException, IOException { if (this.isNullByDescribe) { setNull(this.lastRowProcessed, true); } else if (this.lastRowProcessed == 0) { if (this.previousRowProcessed == -1) this.previousRowProcessed = this.statement.rowPrefetchInLastFetch - 1;  long l = getOffset(this.previousRowProcessed); setNull(this.lastRowProcessed, isNull(this.previousRowProcessed)); this.rowMetadata[this.lastRowProcessed] = this.rowMetadata[this.previousRowProcessed]; if (!isNull(this.previousRowProcessed)) { setOffset(this.lastRowProcessed); ((DynamicByteArray)this.rowData).copyLeft(l, getLength(this.previousRowProcessed)); setLength(this.lastRowProcessed, getLength(this.previousRowProcessed)); }  } else { setNull(this.lastRowProcessed, isNull(this.previousRowProcessed)); this.rowMetadata[this.lastRowProcessed] = this.rowMetadata[this.previousRowProcessed]; setOffset(this.lastRowProcessed, getOffset(this.previousRowProcessed)); setLength(this.lastRowProcessed, getLength(this.previousRowProcessed)); }  this.previousRowProcessed = this.lastRowProcessed; this.lastRowProcessed++; } boolean unmarshalOneRow() throws SQLException, IOException { return getMarshaller().unmarshalOneRow(this); } T4CVarcharAccessor(OracleStatement paramOracleStatement, int paramInt1, boolean paramBoolean, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, short paramShort, int paramInt7, int paramInt8, int paramInt9, T4CMAREngine paramT4CMAREngine) throws SQLException { super(paramOracleStatement, paramInt1, paramBoolean, paramInt2, paramInt3, paramInt4, paramInt5, paramInt6, paramShort); this.marshaller = null; this.mare = paramT4CMAREngine; this.definedColumnType = paramInt8; this.definedColumnSize = paramInt9; calculateSizeTmpByteArray(); this.oacmxl = paramInt7; if (this.oacmxl == -1) { this.underlyingLong = true; this.oacmxl = 4000; }  }
/*      */   int readStreamFromWire(byte[] paramArrayOfbyte, int paramInt1, int paramInt2, int[] paramArrayOfint, boolean[] paramArrayOfboolean1, boolean[] paramArrayOfboolean2, T4CMAREngine paramT4CMAREngine, T4CTTIoer paramT4CTTIoer) throws SQLException, IOException { return getMarshaller().readStreamFromWire(paramArrayOfbyte, paramInt1, paramInt2, paramArrayOfint, paramArrayOfboolean1, paramArrayOfboolean2, paramT4CMAREngine, paramT4CTTIoer); }
/*  710 */   NUMBER getNUMBER(int paramInt) throws SQLException { NUMBER nUMBER = null; if (this.definedColumnType == 0) { nUMBER = super.getNUMBER(paramInt); } else { String str = getString(paramInt); if (str != null) return StringToNUMBER(str.trim());  }  return nUMBER; } DATE getDATE(int paramInt) throws SQLException { DATE dATE = null; if (this.definedColumnType == 0) { dATE = super.getDATE(paramInt); } else { Date date = getDate(paramInt); if (date != null) dATE = new DATE(date);  }  return dATE; } TIMESTAMP getTIMESTAMP(int paramInt) throws SQLException { TIMESTAMP tIMESTAMP = null; if (this.definedColumnType == 0) { tIMESTAMP = super.getTIMESTAMP(paramInt); } else { String str = getString(paramInt); if (str != null) { int[] arrayOfInt = new int[1]; Calendar calendar = DATEStringToCalendar(str, (String)this.statement.connection.sessionProperties.get("AUTH_NLS_LXCSTMPFM"), arrayOfInt); Timestamp timestamp = new Timestamp(calendar.getTimeInMillis()); timestamp.setNanos(arrayOfInt[0]); tIMESTAMP = new TIMESTAMP(timestamp); }  }  return tIMESTAMP; } TIMESTAMPTZ getTIMESTAMPTZ(int paramInt) throws SQLException { TIMESTAMPTZ tIMESTAMPTZ = null; if (this.definedColumnType == 0) { tIMESTAMPTZ = super.getTIMESTAMPTZ(paramInt); } else { String str = getString(paramInt); if (str != null) { int[] arrayOfInt = new int[1]; Calendar calendar = DATEStringToCalendar(str, (String)this.statement.connection.sessionProperties.get("AUTH_NLS_LXCSTZNFM"), arrayOfInt); Timestamp timestamp = new Timestamp(calendar.getTimeInMillis()); timestamp.setNanos(arrayOfInt[0]); tIMESTAMPTZ = new TIMESTAMPTZ((Connection)this.statement.connection, timestamp, calendar); }  }  return tIMESTAMPTZ; } private final T4CMarshaller getMarshaller() { if (this.marshaller == null) {
/*  711 */       this.marshaller = (this.describeType == 8) ? T4CMarshaller.LONG : T4CMarshaller.VARCHAR;
/*      */     }
/*      */ 
/*      */     
/*  715 */     return this.marshaller; } TIMESTAMPLTZ getTIMESTAMPLTZ(int paramInt) throws SQLException { TIMESTAMPLTZ tIMESTAMPLTZ = null; if (this.definedColumnType == 0) { tIMESTAMPLTZ = super.getTIMESTAMPLTZ(paramInt); } else { String str = getString(paramInt); if (str != null) { int[] arrayOfInt = new int[1]; Calendar calendar = DATEStringToCalendar(str, (String)this.statement.connection.sessionProperties.get("AUTH_NLS_LXCSTZNFM"), arrayOfInt); Timestamp timestamp = new Timestamp(calendar.getTimeInMillis()); timestamp.setNanos(arrayOfInt[0]); tIMESTAMPLTZ = new TIMESTAMPLTZ((Connection)this.statement.connection, timestamp, calendar); }  }  return tIMESTAMPLTZ; }
/*      */   RAW getRAW(int paramInt) throws SQLException { RAW rAW = null; if (this.definedColumnType == 0) { rAW = super.getRAW(paramInt); } else if (!this.rowNull[paramInt]) { if (this.definedColumnType == -2 || this.definedColumnType == -3 || this.definedColumnType == -4) { rAW = new RAW(getBytesFromHexChars(paramInt)); } else { rAW = new RAW(getBytes(paramInt)); }  }  return rAW; }
/*      */   Datum getOracleObject(int paramInt) throws SQLException { if (this.definedColumnType == 0) return super.getOracleObject(paramInt);  Datum datum = null; if (this.rowNull == null) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21); sQLException.fillInStackTrace(); throw sQLException; }  if (!this.rowNull[paramInt]) { switch (this.definedColumnType) { case -16: case -15: case -9: case -1: case 1: case 12: return super.getOracleObject(paramInt);case -7: case -6: case -5: case 2: case 3: case 4: case 5: case 6: case 7: case 8: case 16: return (Datum)getNUMBER(paramInt);case 91: return (Datum)getDATE(paramInt);case 92: return (Datum)getDATE(paramInt);case 93: return (Datum)getTIMESTAMP(paramInt);case -101: return (Datum)getTIMESTAMPTZ(paramInt);case -102: return (Datum)getTIMESTAMPLTZ(paramInt);case -4: case -3: case -2: return (Datum)getRAW(paramInt);case -8: return (Datum)getROWID(paramInt); }  SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4); sQLException.fillInStackTrace(); throw sQLException; }  return datum; }
/*      */   byte getByte(int paramInt) throws SQLException { byte b = 0; if (this.definedColumnType == 0) { b = super.getByte(paramInt); } else { NUMBER nUMBER = getNUMBER(paramInt); if (nUMBER != null) b = nUMBER.byteValue();  }  return b; }
/*      */   int getInt(int paramInt) throws SQLException { int i = 0; if (this.definedColumnType == 0) { i = super.getInt(paramInt); } else { NUMBER nUMBER = getNUMBER(paramInt); if (nUMBER != null) i = nUMBER.intValue();  }  return i; }
/*      */   short getShort(int paramInt) throws SQLException { short s = 0; if (this.definedColumnType == 0) { s = super.getShort(paramInt); } else { NUMBER nUMBER = getNUMBER(paramInt); if (nUMBER != null) s = nUMBER.shortValue();  }  return s; }
/*  721 */   Object getObject(int paramInt) throws SQLException { if (this.definedColumnType == 0) return super.getObject(paramInt); 
/*  722 */     if (isUnexpected()) {
/*  723 */       SQLException sQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
/*  724 */       sQLException1.fillInStackTrace();
/*  725 */       throw sQLException1;
/*      */     } 
/*  727 */     if (isNull(paramInt)) return null;
/*      */     
/*  729 */     switch (this.definedColumnType) {
/*      */       
/*      */       case -16:
/*      */       case -15:
/*      */       case -9:
/*      */       case -1:
/*      */       case 1:
/*      */       case 12:
/*  737 */         return getString(paramInt);
/*      */       
/*      */       case 2:
/*      */       case 3:
/*  741 */         return getBigDecimal(paramInt);
/*      */       
/*      */       case 4:
/*  744 */         return Integer.valueOf(getInt(paramInt));
/*      */       
/*      */       case -6:
/*  747 */         return Byte.valueOf(getByte(paramInt));
/*      */       
/*      */       case 5:
/*  750 */         return Short.valueOf(getShort(paramInt));
/*      */ 
/*      */       
/*      */       case -7:
/*      */       case 16:
/*  755 */         return Boolean.valueOf(getBoolean(paramInt));
/*      */       
/*      */       case -5:
/*  758 */         return Long.valueOf(getLong(paramInt));
/*      */       
/*      */       case 7:
/*  761 */         return Float.valueOf(getFloat(paramInt));
/*      */       
/*      */       case 6:
/*      */       case 8:
/*  765 */         return Double.valueOf(getDouble(paramInt));
/*      */       
/*      */       case 91:
/*  768 */         return getDate(paramInt);
/*      */       
/*      */       case 92:
/*  771 */         return getTime(paramInt);
/*      */       
/*      */       case 93:
/*  774 */         return getTimestamp(paramInt);
/*      */       
/*      */       case -101:
/*  777 */         return getTIMESTAMPTZ(paramInt);
/*      */       
/*      */       case -102:
/*  780 */         return getTIMESTAMPLTZ(paramInt);
/*      */       
/*      */       case -4:
/*      */       case -3:
/*      */       case -2:
/*  785 */         return getBytesFromHexChars(paramInt);
/*      */       
/*      */       case -8:
/*  788 */         return getROWID(paramInt);
/*      */     } 
/*      */ 
/*      */     
/*  792 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4);
/*  793 */     sQLException.fillInStackTrace();
/*  794 */     throw sQLException; } long getLong(int paramInt) throws SQLException { long l = 0L; if (this.definedColumnType == 0) { l = super.getLong(paramInt); } else { NUMBER nUMBER = getNUMBER(paramInt); if (nUMBER != null)
/*      */         l = nUMBER.longValue();  }  return l; }
/*      */   float getFloat(int paramInt) throws SQLException { float f = 0.0F; if (this.definedColumnType == 0) { f = super.getFloat(paramInt); } else { NUMBER nUMBER = getNUMBER(paramInt); if (nUMBER != null)
/*      */         f = nUMBER.floatValue();  }  return f; }
/*      */   double getDouble(int paramInt) throws SQLException { double d = 0.0D; if (this.definedColumnType == 0) { d = super.getDouble(paramInt); } else { NUMBER nUMBER = getNUMBER(paramInt); if (nUMBER != null)
/*      */         d = nUMBER.doubleValue();  }  return d; }
/*      */   Date getDate(int paramInt) throws SQLException { Date date = null; if (this.definedColumnType == 0) { date = super.getDate(paramInt); } else { String str = getString(paramInt); if (str != null) { int[] arrayOfInt = new int[1]; try { date = new Date(DATEStringToCalendar(str, (String)this.statement.connection.sessionProperties.get("AUTH_NLS_LXCDATEFM"), arrayOfInt).getTimeInMillis()); } catch (NumberFormatException numberFormatException) { SQLException sQLException = DatabaseError.createSqlException((OracleConnection)null, 132, (Object)null, numberFormatException); sQLException.fillInStackTrace(); throw sQLException; }  }  }  return date; }
/*      */   Timestamp getTimestamp(int paramInt) throws SQLException { Timestamp timestamp = null; if (this.definedColumnType == 0) { timestamp = super.getTimestamp(paramInt); } else { String str = getString(paramInt); if (str != null) { int[] arrayOfInt = new int[1]; try { Calendar calendar = DATEStringToCalendar(str, (String)this.statement.connection.sessionProperties.get("AUTH_NLS_LXCSTMPFM"), arrayOfInt); timestamp = new Timestamp(calendar.getTimeInMillis()); timestamp.setNanos(arrayOfInt[0]); } catch (NumberFormatException numberFormatException) { SQLException sQLException = DatabaseError.createSqlException((OracleConnection)null, 132, (Object)null, numberFormatException); sQLException.fillInStackTrace(); throw sQLException; }  }  }  return timestamp; }
/*      */   Time getTime(int paramInt) throws SQLException { Time time = null; if (this.definedColumnType == 0) { time = super.getTime(paramInt); }
/*      */     else { String str = getString(paramInt); if (str != null) { int[] arrayOfInt = new int[1]; try { Calendar calendar = DATEStringToCalendar(str, (String)this.statement.connection.sessionProperties.get("AUTH_NLS_LXCSTZNFM"), arrayOfInt); time = new Time(calendar.getTimeInMillis()); }
/*      */         catch (NumberFormatException numberFormatException) { SQLException sQLException = DatabaseError.createSqlException((OracleConnection)null, 132, (Object)null, numberFormatException); sQLException.fillInStackTrace(); throw sQLException; }
/*      */          }
/*      */        }
/*      */      return time; }
/*  808 */   static final NUMBER StringToNUMBER(String paramString) throws SQLException { try { return new NUMBER(new BigDecimal(paramString)); }
/*      */     
/*  810 */     catch (NumberFormatException numberFormatException)
/*      */     
/*      */     { 
/*      */       
/*  814 */       SQLException sQLException = DatabaseError.createSqlException((OracleConnection)null, 132, (Object)null, numberFormatException);
/*  815 */       sQLException.fillInStackTrace();
/*  816 */       throw sQLException; }
/*      */      }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static final Calendar DATEStringToCalendar(String paramString1, String paramString2, int[] paramArrayOfint) throws SQLException {
/*  847 */     char[] arrayOfChar = (paramString2 + " ").toCharArray();
/*  848 */     paramString1 = paramString1 + " ";
/*      */ 
/*      */     
/*  851 */     int i = Math.min(paramString1.length(), arrayOfChar.length);
/*      */     
/*  853 */     byte b1 = -1;
/*  854 */     byte b2 = -1;
/*      */     
/*  856 */     byte b3 = 0;
/*  857 */     byte b4 = 0;
/*      */     
/*  859 */     int j = 0;
/*  860 */     int k = 0;
/*      */     
/*  862 */     int m = 0;
/*  863 */     int n = 0;
/*  864 */     int i1 = 0;
/*      */     
/*  866 */     int i2 = 0;
/*  867 */     int i3 = 0;
/*  868 */     int i4 = 0;
/*  869 */     int i5 = 0;
/*      */     
/*  871 */     String str1 = null;
/*  872 */     String str2 = null;
/*      */     
/*  874 */     boolean bool = false;
/*      */ 
/*      */     
/*  877 */     String[] arrayOfString1 = null;
/*  878 */     String[] arrayOfString2 = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  896 */     for (byte b5 = 0; b5 < i; b5++) {
/*      */       
/*  898 */       switch (arrayOfChar[b5]) {
/*      */         
/*      */         case 'R':
/*      */         case 'r':
/*  902 */           if (b1 != 6) {
/*      */             
/*  904 */             b1 = 6;
/*  905 */             b3 = b5;
/*      */           } 
/*      */           break;
/*      */         
/*      */         case 'Y':
/*      */         case 'y':
/*  911 */           if (b1 != 5) {
/*      */             
/*  913 */             b1 = 5;
/*  914 */             b3 = b5;
/*      */           } 
/*      */           break;
/*      */         
/*      */         case 'D':
/*      */         case 'd':
/*  920 */           if (b1 != 1) {
/*      */             
/*  922 */             b1 = 1;
/*  923 */             b3 = b5;
/*      */           } 
/*      */           break;
/*      */         
/*      */         case 'M':
/*      */         case 'm':
/*  929 */           if (b1 != 2 || b1 != 4 || b1 != 3 || b1 != 9) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*  935 */             b3 = b5;
/*      */             
/*  937 */             if (b5 + 4 < i && (arrayOfChar[b5 + 1] == 'O' || arrayOfChar[b5 + 1] == 'o') && (arrayOfChar[b5 + 2] == 'N' || arrayOfChar[b5 + 2] == 'n') && (arrayOfChar[b5 + 3] == 'T' || arrayOfChar[b5 + 3] == 't') && (arrayOfChar[b5 + 4] == 'H' || arrayOfChar[b5 + 4] == 'h')) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */               
/*  943 */               b1 = 3;
/*  944 */               b5 += 4; break;
/*  945 */             }  if (b5 + 2 < i && (arrayOfChar[b5 + 1] == 'O' || arrayOfChar[b5 + 1] == 'o') && (arrayOfChar[b5 + 2] == 'N' || arrayOfChar[b5 + 2] == 'n')) {
/*      */ 
/*      */ 
/*      */               
/*  949 */               b1 = 4;
/*  950 */               b5 += 2; break;
/*  951 */             }  if (b5 + 1 < i && (arrayOfChar[b5 + 1] == 'M' || arrayOfChar[b5 + 1] == 'm')) {
/*      */ 
/*      */               
/*  954 */               b1 = 2;
/*  955 */               b5++; break;
/*  956 */             }  if (b5 + 1 < i && (arrayOfChar[b5 + 1] == 'I' || arrayOfChar[b5 + 1] == 'i')) {
/*      */ 
/*      */               
/*  959 */               b1 = 9;
/*  960 */               b5++;
/*      */             } 
/*      */           } 
/*      */           break;
/*      */ 
/*      */ 
/*      */         
/*      */         case 'H':
/*      */         case 'h':
/*  969 */           if (b1 != 7) {
/*      */             
/*  971 */             b1 = 7;
/*  972 */             b3 = b5; break;
/*  973 */           }  if (b5 + 2 < i && (arrayOfChar[b5 + 1] == '2' || arrayOfChar[b5 + 4] == '4')) {
/*      */ 
/*      */             
/*  976 */             b1 = 8;
/*  977 */             b5 += 2;
/*      */           } 
/*      */           break;
/*      */         
/*      */         case 'S':
/*      */         case 's':
/*  983 */           if (b5 + 1 < i && (arrayOfChar[b5 + 1] == 'S' || arrayOfChar[b5 + 1] == 's')) {
/*      */ 
/*      */             
/*  986 */             b1 = 10;
/*  987 */             b3 = b5;
/*  988 */             b5++;
/*      */           } 
/*      */           break;
/*      */ 
/*      */         
/*      */         case 'F':
/*      */         case 'f':
/*  995 */           if (b1 != 11) {
/*      */             
/*  997 */             b1 = 11;
/*  998 */             b3 = b5;
/*      */           } 
/*      */           break;
/*      */         
/*      */         case 'A':
/*      */         case 'a':
/* 1004 */           if (b5 + 1 < i && (arrayOfChar[b5 + 1] == 'M' || arrayOfChar[b5 + 1] == 'm')) {
/*      */ 
/*      */             
/* 1007 */             b1 = 12;
/* 1008 */             b3 = b5;
/* 1009 */             b5++;
/*      */           } 
/*      */           break;
/*      */         
/*      */         case 'T':
/*      */         case 't':
/* 1015 */           if (b5 + 2 < i && (arrayOfChar[b5 + 1] == 'Z' || arrayOfChar[b5 + 1] == 'z') && (arrayOfChar[b5 + 2] == 'R' || arrayOfChar[b5 + 2] == 'r')) {
/*      */ 
/*      */ 
/*      */             
/* 1019 */             b1 = 13;
/* 1020 */             b3 = b5;
/* 1021 */             b5 += 2;
/*      */           } 
/*      */           break;
/*      */ 
/*      */ 
/*      */         
/*      */         default:
/* 1028 */           bool = true;
/*      */           break;
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1039 */       if (bool && b1 != -1) {
/*      */         int i8, i10; String str3; int i9; String str4;
/* 1041 */         int i6 = b5 - b3;
/* 1042 */         int i7 = b3 - b4;
/* 1043 */         j = k + i7;
/*      */         
/* 1045 */         k = j + i6;
/* 1046 */         switch (b1) {
/*      */           
/*      */           case 1:
/* 1049 */             m = Integer.parseInt(paramString1.substring(j, k));
/*      */             break;
/*      */           
/*      */           case 2:
/* 1053 */             n = Integer.parseInt(paramString1.substring(j, k));
/*      */             break;
/*      */ 
/*      */ 
/*      */           
/*      */           case 3:
/* 1059 */             i10 = j;
/* 1060 */             k = j;
/* 1061 */             for (i10 = j; i10 < paramString1.length() && 
/* 1062 */               paramString1.charAt(i10) != arrayOfChar[b5]; i10++);
/*      */             
/* 1064 */             k = i10;
/*      */             
/* 1066 */             str4 = null;
/* 1067 */             if (k != j) {
/* 1068 */               str4 = paramString1.substring(j, k);
/*      */ 
/*      */ 
/*      */               
/* 1072 */               str4 = str4.trim();
/*      */               
/* 1074 */               if (arrayOfString2 == null)
/* 1075 */                 arrayOfString2 = (new DateFormatSymbols()).getMonths(); 
/* 1076 */               for (n = 0; n < arrayOfString2.length && 
/* 1077 */                 !str4.equalsIgnoreCase(arrayOfString2[n]); n++);
/*      */ 
/*      */               
/* 1080 */               if (n >= 12) {
/*      */                 
/* 1082 */                 SQLException sQLException = DatabaseError.createSqlException((OracleConnection)null, 59);
/* 1083 */                 sQLException.fillInStackTrace();
/* 1084 */                 throw sQLException;
/*      */               } 
/*      */             } 
/*      */             break;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           case 4:
/* 1096 */             i8 = j;
/* 1097 */             k = j;
/* 1098 */             for (i8 = j; i8 < paramString1.length() && 
/* 1099 */               paramString1.charAt(i8) != arrayOfChar[b5]; i8++);
/*      */             
/* 1101 */             k = i8;
/*      */             
/* 1103 */             str3 = null;
/* 1104 */             if (k != j) {
/* 1105 */               str3 = paramString1.substring(j, k);
/*      */ 
/*      */ 
/*      */               
/* 1109 */               str3 = str3.trim();
/*      */               
/* 1111 */               if (arrayOfString1 == null)
/* 1112 */                 arrayOfString1 = (new DateFormatSymbols()).getShortMonths(); 
/* 1113 */               for (n = 0; n < arrayOfString1.length && 
/* 1114 */                 !str3.equalsIgnoreCase(arrayOfString1[n]); n++);
/*      */ 
/*      */               
/* 1117 */               if (n >= 12) {
/*      */                 
/* 1119 */                 SQLException sQLException = DatabaseError.createSqlException((OracleConnection)null, 59);
/* 1120 */                 sQLException.fillInStackTrace();
/* 1121 */                 throw sQLException;
/*      */               } 
/*      */             } 
/*      */             break;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           case 5:
/* 1133 */             i1 = Integer.parseInt(paramString1.substring(j, k));
/*      */ 
/*      */ 
/*      */             
/* 1137 */             if (i6 == 2) {
/* 1138 */               i1 += 2000;
/*      */             }
/*      */             break;
/*      */           case 6:
/* 1142 */             i1 = Integer.parseInt(paramString1.substring(j, k));
/*      */ 
/*      */ 
/*      */             
/* 1146 */             if (i6 == 2 && i1 < 50) {
/* 1147 */               i1 += 2000; break;
/*      */             } 
/* 1149 */             i1 += 1900;
/*      */             break;
/*      */ 
/*      */ 
/*      */           
/*      */           case 7:
/*      */           case 8:
/* 1156 */             k = j + 2;
/* 1157 */             i2 = Integer.parseInt(paramString1.substring(j, k));
/*      */             break;
/*      */           
/*      */           case 9:
/* 1161 */             i3 = Integer.parseInt(paramString1.substring(j, k));
/*      */             break;
/*      */           
/*      */           case 10:
/* 1165 */             i4 = Integer.parseInt(paramString1.substring(j, k));
/*      */             break;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           case 11:
/* 1175 */             i9 = j;
/* 1176 */             k = j;
/* 1177 */             for (i9 = j; i9 < paramString1.length() && (
/* 1178 */               i8 = paramString1.charAt(i9)) >= 48 && i8 <= 57; i9++);
/*      */             
/* 1180 */             k += i9 - j;
/*      */             
/* 1182 */             if (k != j) {
/* 1183 */               i5 = Integer.parseInt(paramString1.substring(j, k));
/*      */             }
/*      */             break;
/*      */           case 12:
/* 1187 */             if (k > 0) {
/* 1188 */               str1 = paramString1.substring(j, k);
/*      */             }
/*      */             break;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           case 13:
/* 1198 */             i9 = j;
/* 1199 */             k = j;
/* 1200 */             for (i9 = j; i9 < paramString1.length() && (((
/* 1201 */               i8 = paramString1.charAt(i9)) >= 48 && i8 <= 57) || (i8 >= 97 && i8 <= 122) || (i8 >= 65 && i8 <= 90)); i9++)
/*      */             {
/*      */ 
/*      */ 
/*      */               
/* 1206 */               k = i9;
/*      */             }
/* 1208 */             if (k != j) {
/* 1209 */               str2 = paramString1.substring(j, k);
/*      */             }
/*      */             break;
/*      */           
/*      */           default:
/* 1214 */             System.out.println("\n\n\n             ***** ERROR(1) ****\n");
/*      */             break;
/*      */         } 
/*      */         
/* 1218 */         b4 = b5;
/* 1219 */         b1 = -1;
/* 1220 */         bool = false;
/*      */       } 
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1227 */     GregorianCalendar gregorianCalendar = new GregorianCalendar(i1, n, m, i2, i3, i4);
/* 1228 */     if (str1 != null) {
/* 1229 */       gregorianCalendar.set(9, str1.equalsIgnoreCase("AM") ? 0 : 1);
/*      */     }
/*      */ 
/*      */ 
/*      */     
/* 1234 */     if (str2 != null);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1240 */     if (i5 != 0) {
/* 1241 */       paramArrayOfint[0] = i5;
/*      */     }
/* 1243 */     return gregorianCalendar;
/*      */   }
/*      */ 
/*      */   
/* 1247 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*      */   public static final String BUILD_DATE = "Thu_Apr_04_15:09:24_PDT_2013";
/*      */   public static final boolean TRACE = false;
/*      */ }


/* Location:              C:\Users\olatu\OneDrive\Documents\Calypso\syncbase\sync_base.jar!\BOOT-INF\classes\ojdbc.jar!\oracle\jdbc\driver\T4CVarcharAccessor.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */