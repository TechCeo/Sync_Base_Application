/*     */ package oracle.jdbc.driver;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.sql.SQLException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class T4C8TTIrxh
/*     */   extends T4CTTIMsg
/*     */ {
/*     */   short rxhflg;
/*     */   int numRqsts;
/*     */   int iterNum;
/*     */   int numItersThisTime;
/*     */   int uacBufLength;
/*     */   static final byte RXHFU2O = 1;
/*     */   static final byte RXHFEOR = 2;
/*     */   static final byte RXHPLSV = 4;
/*     */   static final byte RXHFRXR = 8;
/*     */   static final byte RXHFKCO = 16;
/*     */   static final byte RXHFDCF = 32;
/*     */   
/*     */   T4C8TTIrxh(T4CConnection paramT4CConnection) {
/*  97 */     super(paramT4CConnection, (byte)0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void unmarshalV10(T4CTTIrxd paramT4CTTIrxd) throws SQLException, IOException {
/* 109 */     this.rxhflg = this.meg.unmarshalUB1();
/* 110 */     this.numRqsts = this.meg.unmarshalUB2();
/* 111 */     this.iterNum = this.meg.unmarshalUB2();
/*     */ 
/*     */ 
/*     */     
/* 115 */     this.numRqsts += this.iterNum * 256;
/*     */     
/* 117 */     this.numItersThisTime = this.meg.unmarshalUB2();
/* 118 */     this.uacBufLength = this.meg.unmarshalUB2();
/*     */ 
/*     */     
/* 121 */     byte[] arrayOfByte1 = this.meg.unmarshalDALC();
/* 122 */     paramT4CTTIrxd.readBitVector(arrayOfByte1);
/*     */ 
/*     */     
/* 125 */     byte[] arrayOfByte2 = this.meg.unmarshalDALC();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void init() {
/* 132 */     this.rxhflg = 0;
/* 133 */     this.numRqsts = 0;
/* 134 */     this.iterNum = 0;
/* 135 */     this.numItersThisTime = 0;
/* 136 */     this.uacBufLength = 0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void print() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 186 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*     */   public static final String BUILD_DATE = "Thu_Apr_04_15:09:24_PDT_2013";
/*     */   public static final boolean TRACE = false;
/*     */ }


/* Location:              C:\Users\olatu\OneDrive\Documents\Calypso\syncbase\sync_base.jar!\BOOT-INF\classes\ojdbc.jar!\oracle\jdbc\driver\T4C8TTIrxh.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */