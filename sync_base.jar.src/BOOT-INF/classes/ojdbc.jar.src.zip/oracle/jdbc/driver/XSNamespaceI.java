/*     */ package oracle.jdbc.driver;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.sql.SQLException;
/*     */ import oracle.jdbc.internal.XSAttribute;
/*     */ import oracle.jdbc.internal.XSNamespace;
/*     */ import oracle.sql.TIMESTAMPTZ;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class XSNamespaceI
/*     */   extends XSNamespace
/*     */ {
/*  81 */   String namespaceName = null;
/*  82 */   byte[] namespaceNameBytes = null;
/*  83 */   String kpxsnshandler = null;
/*  84 */   byte[] kpxsnshandlerBytes = null;
/*  85 */   XSAttributeI[] attributes = null;
/*  86 */   byte[] timestampBytes = null;
/*  87 */   long flag = 0L;
/*  88 */   long[] aclList = null;
/*     */ 
/*     */   
/*     */   public void setNamespaceName(String paramString) throws SQLException {
/*  92 */     this.namespaceName = paramString;
/*     */   }
/*     */   
/*     */   public void setNamespaceHandler(String paramString) throws SQLException {
/*  96 */     this.kpxsnshandler = paramString;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setTimestamp(TIMESTAMPTZ paramTIMESTAMPTZ) throws SQLException {
/* 101 */     this.timestampBytes = paramTIMESTAMPTZ.toBytes();
/*     */   }
/*     */   
/*     */   private void setTimestamp(byte[] paramArrayOfbyte) throws SQLException {
/* 105 */     this.timestampBytes = paramArrayOfbyte;
/*     */   }
/*     */   
/*     */   public void setACLIdList(long[] paramArrayOflong) throws SQLException {
/* 109 */     this.aclList = paramArrayOflong;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setFlag(long paramLong) throws SQLException {
/* 114 */     this.flag = paramLong;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setAttributes(XSAttribute[] paramArrayOfXSAttribute) throws SQLException {
/* 119 */     if (paramArrayOfXSAttribute != null) {
/* 120 */       XSAttributeI[] arrayOfXSAttributeI = new XSAttributeI[paramArrayOfXSAttribute.length];
/* 121 */       for (byte b = 0; b < paramArrayOfXSAttribute.length; b++) {
/* 122 */         arrayOfXSAttributeI[b] = (XSAttributeI)paramArrayOfXSAttribute[b];
/*     */       }
/* 124 */       this.attributes = arrayOfXSAttributeI;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void doCharConversion(DBConversion paramDBConversion) throws SQLException {
/* 132 */     if (this.namespaceName != null) {
/* 133 */       this.namespaceNameBytes = paramDBConversion.StringToCharBytes(this.namespaceName);
/*     */     } else {
/* 135 */       this.namespaceNameBytes = null;
/*     */     } 
/* 137 */     if (this.kpxsnshandler != null) {
/* 138 */       this.kpxsnshandlerBytes = paramDBConversion.StringToCharBytes(this.kpxsnshandler);
/*     */     } else {
/* 140 */       this.kpxsnshandlerBytes = null;
/*     */     } 
/*     */     
/* 143 */     if (this.attributes != null) {
/* 144 */       for (byte b = 0; b < this.attributes.length; b++) {
/* 145 */         this.attributes[b].doCharConversion(paramDBConversion);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public String getNamespaceName() {
/* 152 */     return this.namespaceName;
/*     */   }
/*     */   
/*     */   public String getNamespaceHandler() {
/* 156 */     return this.kpxsnshandler;
/*     */   }
/*     */   
/*     */   public TIMESTAMPTZ getTimestamp() {
/* 160 */     return new TIMESTAMPTZ(this.timestampBytes);
/*     */   }
/*     */ 
/*     */   
/*     */   public long getFlag() {
/* 165 */     return this.flag;
/*     */   }
/*     */ 
/*     */   
/*     */   public XSAttribute[] getAttributes() {
/* 170 */     return (XSAttribute[])this.attributes;
/*     */   }
/*     */   
/*     */   public long[] getACLIdList() {
/* 174 */     return this.aclList;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void marshal(T4CMAREngine paramT4CMAREngine) throws IOException {
/* 184 */     if (this.namespaceNameBytes != null) {
/* 185 */       paramT4CMAREngine.marshalUB4(this.namespaceNameBytes.length);
/* 186 */       paramT4CMAREngine.marshalCLR(this.namespaceNameBytes, this.namespaceNameBytes.length);
/*     */     } else {
/*     */       
/* 189 */       paramT4CMAREngine.marshalUB4(0L);
/*     */     } 
/* 191 */     if (this.kpxsnshandlerBytes != null) {
/* 192 */       paramT4CMAREngine.marshalUB4(this.kpxsnshandlerBytes.length);
/* 193 */       paramT4CMAREngine.marshalCLR(this.kpxsnshandlerBytes, this.kpxsnshandlerBytes.length);
/*     */     } else {
/*     */       
/* 196 */       paramT4CMAREngine.marshalUB4(0L);
/*     */     } 
/* 198 */     if (this.timestampBytes != null) {
/* 199 */       paramT4CMAREngine.marshalUB4(this.timestampBytes.length);
/* 200 */       paramT4CMAREngine.marshalCLR(this.timestampBytes, this.timestampBytes.length);
/*     */     } else {
/*     */       
/* 203 */       paramT4CMAREngine.marshalUB4(0L);
/*     */     } 
/* 205 */     paramT4CMAREngine.marshalUB4(this.flag);
/*     */     
/* 207 */     if (this.attributes != null) {
/* 208 */       paramT4CMAREngine.marshalUB4(this.attributes.length);
/*     */ 
/*     */       
/* 211 */       paramT4CMAREngine.marshalUB1((short)28);
/* 212 */       for (byte b = 0; b < this.attributes.length; b++) {
/* 213 */         this.attributes[b].marshal(paramT4CMAREngine);
/*     */       }
/*     */     } else {
/* 216 */       paramT4CMAREngine.marshalUB4(0L);
/*     */     } 
/* 218 */     if (this.aclList != null) {
/* 219 */       paramT4CMAREngine.marshalUB4(this.aclList.length);
/* 220 */       paramT4CMAREngine.marshalUB1((short)8);
/* 221 */       for (byte b = 0; b < this.aclList.length; b++) {
/* 222 */         paramT4CMAREngine.marshalSB8(this.aclList[b]);
/*     */       }
/*     */     } else {
/* 225 */       paramT4CMAREngine.marshalUB4(0L);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static XSNamespaceI unmarshal(T4CMAREngine paramT4CMAREngine) throws SQLException, IOException {
/* 237 */     int[] arrayOfInt = new int[1];
/* 238 */     String str1 = null;
/*     */ 
/*     */     
/* 241 */     int i = (int)paramT4CMAREngine.unmarshalUB4();
/* 242 */     if (i > 0) {
/* 243 */       byte[] arrayOfByte1 = new byte[i];
/* 244 */       paramT4CMAREngine.unmarshalCLR(arrayOfByte1, 0, arrayOfInt);
/* 245 */       str1 = paramT4CMAREngine.conv.CharBytesToString(arrayOfByte1, arrayOfInt[0]);
/*     */     } 
/*     */     
/* 248 */     int j = (int)paramT4CMAREngine.unmarshalUB4();
/* 249 */     String str2 = null;
/* 250 */     if (j > 0) {
/* 251 */       byte[] arrayOfByte1 = new byte[i];
/* 252 */       paramT4CMAREngine.unmarshalCLR(arrayOfByte1, 0, arrayOfInt);
/* 253 */       str2 = paramT4CMAREngine.conv.CharBytesToString(arrayOfByte1, arrayOfInt[0]);
/*     */     } 
/*     */ 
/*     */     
/* 257 */     byte[] arrayOfByte = null;
/* 258 */     if (paramT4CMAREngine.unmarshalUB1() == 1) {
/* 259 */       int n = (int)paramT4CMAREngine.unmarshalUB4();
/* 260 */       arrayOfByte = paramT4CMAREngine.unmarshalNBytes(n);
/*     */     } 
/*     */     
/* 263 */     long l = paramT4CMAREngine.unmarshalUB4();
/*     */     
/* 265 */     XSAttribute[] arrayOfXSAttribute = null;
/* 266 */     int k = (int)paramT4CMAREngine.unmarshalUB4();
/* 267 */     arrayOfXSAttribute = new XSAttribute[k];
/* 268 */     if (k > 0)
/* 269 */       paramT4CMAREngine.unmarshalUB1();  int m;
/* 270 */     for (m = 0; m < k; m++) {
/* 271 */       arrayOfXSAttribute[m] = XSAttributeI.unmarshal(paramT4CMAREngine);
/*     */     }
/* 273 */     m = (int)paramT4CMAREngine.unmarshalUB4();
/* 274 */     long[] arrayOfLong = null;
/* 275 */     if (m > 0) {
/* 276 */       arrayOfLong = new long[m];
/* 277 */       for (byte b = 0; b < m; b++) {
/* 278 */         arrayOfLong[b] = paramT4CMAREngine.unmarshalSB8();
/*     */       }
/*     */     } 
/* 281 */     XSNamespaceI xSNamespaceI = new XSNamespaceI();
/* 282 */     xSNamespaceI.setNamespaceName(str1);
/* 283 */     xSNamespaceI.setNamespaceHandler(str2);
/* 284 */     xSNamespaceI.setTimestamp(arrayOfByte);
/* 285 */     xSNamespaceI.setFlag(l);
/* 286 */     xSNamespaceI.setAttributes(arrayOfXSAttribute);
/* 287 */     xSNamespaceI.setACLIdList(arrayOfLong);
/* 288 */     return xSNamespaceI;
/*     */   }
/*     */ 
/*     */   
/* 292 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*     */   public static final String BUILD_DATE = "Thu_Apr_04_15:09:24_PDT_2013";
/*     */   public static final boolean TRACE = false;
/*     */ }


/* Location:              C:\Users\olatu\OneDrive\Documents\Calypso\syncbase\sync_base.jar!\BOOT-INF\classes\ojdbc.jar!\oracle\jdbc\driver\XSNamespaceI.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */