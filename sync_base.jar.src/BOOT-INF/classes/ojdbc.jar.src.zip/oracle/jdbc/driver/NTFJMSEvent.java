/*     */ package oracle.jdbc.driver;
/*     */ 
/*     */ import java.sql.SQLException;
/*     */ import oracle.jdbc.aq.AQMessageProperties;
/*     */ import oracle.jdbc.internal.JMSMessageProperties;
/*     */ import oracle.jdbc.internal.JMSNotificationEvent;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class NTFJMSEvent
/*     */   extends JMSNotificationEvent
/*     */ {
/*  33 */   private JMSMessageProperties jmsMessageProperties = null;
/*  34 */   private AQMessageProperties aqMessageProperties = null;
/*  35 */   private String registrationString = null;
/*     */   private byte[] payload;
/*  37 */   private String queueName = null;
/*  38 */   private byte[] messageId = null;
/*  39 */   private String consumerName = null;
/*     */ 
/*     */   
/*     */   NTFJMSEvent(T4CTTIoaqnfy paramT4CTTIoaqnfy) {
/*  43 */     super(paramT4CTTIoaqnfy);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JMSMessageProperties getJMSMessageProperties() throws SQLException {
/*  60 */     return this.jmsMessageProperties;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AQMessageProperties getMessageProperties() throws SQLException {
/*  76 */     return this.aqMessageProperties;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] getPayload() throws SQLException {
/*  96 */     return this.payload;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getQueueName() throws SQLException {
/* 113 */     return this.queueName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] getMessageId() throws SQLException {
/* 130 */     return this.messageId;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getConsumerName() throws SQLException {
/* 150 */     return this.consumerName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getRegistrationName() throws SQLException {
/* 171 */     return this.registrationString;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void setAqMessageProperites(AQMessageProperties paramAQMessageProperties) {
/* 181 */     this.aqMessageProperties = paramAQMessageProperties;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void setConsumerName(String paramString) {
/* 191 */     this.consumerName = paramString;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void setJmsMessageProperties(JMSMessageProperties paramJMSMessageProperties) {
/* 201 */     this.jmsMessageProperties = paramJMSMessageProperties;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void setMessageId(byte[] paramArrayOfbyte) {
/* 211 */     this.messageId = paramArrayOfbyte;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void setPayload(byte[] paramArrayOfbyte) {
/* 221 */     this.payload = paramArrayOfbyte;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void setQueueName(String paramString) {
/* 231 */     this.queueName = paramString;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void setRegistration(String paramString) {
/* 241 */     this.registrationString = paramString;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/* 246 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*     */   public static final String BUILD_DATE = "Thu_Apr_04_15:09:24_PDT_2013";
/*     */   public static final boolean TRACE = false;
/*     */ }


/* Location:              C:\Users\olatu\OneDrive\Documents\Calypso\syncbase\sync_base.jar!\BOOT-INF\classes\ojdbc.jar!\oracle\jdbc\driver\NTFJMSEvent.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */