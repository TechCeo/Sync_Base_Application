/*     */ package oracle.jdbc.driver;
/*     */ 
/*     */ import java.sql.Connection;
/*     */ import java.sql.Date;
/*     */ import java.sql.SQLException;
/*     */ import java.sql.Time;
/*     */ import java.sql.Timestamp;
/*     */ import java.util.Calendar;
/*     */ import java.util.Map;
/*     */ import java.util.TimeZone;
/*     */ import oracle.sql.DATE;
/*     */ import oracle.sql.Datum;
/*     */ import oracle.sql.OffsetDST;
/*     */ import oracle.sql.TIMESTAMP;
/*     */ import oracle.sql.TIMESTAMPLTZ;
/*     */ import oracle.sql.TIMESTAMPTZ;
/*     */ import oracle.sql.TIMEZONETAB;
/*     */ import oracle.sql.ZONEIDMAP;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class TimestampltzAccessor
/*     */   extends DateTimeCommonAccessor
/*     */ {
/*     */   static final int MAXLENGTH = 11;
/*     */   
/*     */   TimestampltzAccessor(OracleStatement paramOracleStatement, int paramInt1, short paramShort, int paramInt2, boolean paramBoolean) throws SQLException {
/*  32 */     super(Representation.TIMESTAMPLTZ, paramOracleStatement, 11, paramBoolean);
/*     */     
/*  34 */     init(paramOracleStatement, 231, 231, paramShort, paramBoolean);
/*  35 */     initForDataAccess(paramInt2, paramInt1, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   TimestampltzAccessor(OracleStatement paramOracleStatement, int paramInt1, boolean paramBoolean, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, short paramShort) throws SQLException {
/*  43 */     super(Representation.TIMESTAMPLTZ, paramOracleStatement, 11, false);
/*     */     
/*  45 */     init(paramOracleStatement, 231, 231, paramShort, false);
/*  46 */     initForDescribe(231, paramInt1, paramBoolean, paramInt2, paramInt3, paramInt4, paramInt5, paramInt6, paramShort, null);
/*     */     
/*  48 */     initForDataAccess(0, paramInt1, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   String getString(int paramInt) throws SQLException {
/*  57 */     if (isNull(paramInt)) {
/*  58 */       return null;
/*     */     }
/*     */ 
/*     */     
/*  62 */     Calendar calendar1 = this.statement.connection.getDbTzCalendar();
/*     */ 
/*     */ 
/*     */     
/*  66 */     String str1 = this.statement.connection.getSessionTimeZone();
/*     */     
/*  68 */     if (str1 == null) {
/*     */       
/*  70 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 198);
/*  71 */       sQLException.fillInStackTrace();
/*  72 */       throw sQLException;
/*     */     } 
/*     */ 
/*     */     
/*  76 */     TimeZone timeZone = TimeZone.getTimeZone(str1);
/*  77 */     Calendar calendar2 = Calendar.getInstance(timeZone);
/*     */     
/*  79 */     getBytesInternal(paramInt, this.tmpBytes);
/*     */     
/*  81 */     int i = oracleYear(this.tmpBytes);
/*     */     
/*  83 */     calendar1.set(1, i);
/*  84 */     calendar1.set(2, oracleMonth(this.tmpBytes));
/*  85 */     calendar1.set(5, oracleDay(this.tmpBytes));
/*  86 */     calendar1.set(11, oracleHour(this.tmpBytes));
/*  87 */     calendar1.set(12, oracleMin(this.tmpBytes));
/*  88 */     calendar1.set(13, oracleSec(this.tmpBytes));
/*  89 */     calendar1.set(14, 0);
/*     */ 
/*     */     
/*  92 */     TimeZoneAdjust(calendar1, calendar2);
/*     */ 
/*     */     
/*  95 */     i = calendar2.get(1);
/*     */     
/*  97 */     int j = calendar2.get(2) + 1;
/*  98 */     int k = calendar2.get(5);
/*  99 */     int m = calendar2.get(11);
/* 100 */     int n = calendar2.get(12);
/* 101 */     int i1 = calendar2.get(13);
/* 102 */     int i2 = 0;
/* 103 */     boolean bool = (m < 12) ? true : false;
/*     */     
/* 105 */     String str2 = calendar2.getTimeZone().getID();
/* 106 */     if (str2.length() > 3 && str2.startsWith("GMT")) {
/* 107 */       str2 = str2.substring(3);
/*     */     }
/*     */     
/* 110 */     if (getLength(paramInt) == 11) {
/* 111 */       i2 = oracleNanos(this.tmpBytes);
/*     */     }
/*     */     
/* 114 */     return toText(i, j, k, m, n, i1, i2, bool, str2);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Date getDate(int paramInt, Calendar paramCalendar) throws SQLException {
/* 125 */     return getDate(paramInt);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Date getDate(int paramInt) throws SQLException {
/* 133 */     if (isNull(paramInt)) {
/* 134 */       return null;
/*     */     }
/*     */ 
/*     */     
/* 138 */     Calendar calendar1 = this.statement.connection.getDbTzCalendar();
/*     */ 
/*     */ 
/*     */     
/* 142 */     String str = this.statement.connection.getSessionTimeZone();
/*     */     
/* 144 */     if (str == null) {
/*     */       
/* 146 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 198);
/* 147 */       sQLException.fillInStackTrace();
/* 148 */       throw sQLException;
/*     */     } 
/*     */ 
/*     */     
/* 152 */     TimeZone timeZone = TimeZone.getTimeZone(str);
/* 153 */     Calendar calendar2 = Calendar.getInstance(timeZone);
/*     */     
/* 155 */     getBytesInternal(paramInt, this.tmpBytes);
/*     */     
/* 157 */     int i = oracleYear(this.tmpBytes);
/*     */     
/* 159 */     calendar1.set(1, i);
/* 160 */     calendar1.set(2, oracleMonth(this.tmpBytes));
/* 161 */     calendar1.set(5, oracleDay(this.tmpBytes));
/* 162 */     calendar1.set(11, oracleHour(this.tmpBytes));
/* 163 */     calendar1.set(12, oracleMin(this.tmpBytes));
/* 164 */     calendar1.set(13, oracleSec(this.tmpBytes));
/* 165 */     calendar1.set(14, 0);
/*     */     
/* 167 */     long l = TimeZoneAdjustUTC(calendar1);
/*     */     
/* 169 */     return new Date(l);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Time getTime(int paramInt, Calendar paramCalendar) throws SQLException {
/* 179 */     return getTime(paramInt);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Time getTime(int paramInt) throws SQLException {
/* 187 */     if (isNull(paramInt)) {
/* 188 */       return null;
/*     */     }
/*     */ 
/*     */     
/* 192 */     Calendar calendar1 = this.statement.connection.getDbTzCalendar();
/*     */ 
/*     */ 
/*     */     
/* 196 */     String str = this.statement.connection.getSessionTimeZone();
/*     */     
/* 198 */     if (str == null) {
/*     */       
/* 200 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 198);
/* 201 */       sQLException.fillInStackTrace();
/* 202 */       throw sQLException;
/*     */     } 
/*     */ 
/*     */     
/* 206 */     TimeZone timeZone = TimeZone.getTimeZone(str);
/*     */     
/* 208 */     Calendar calendar2 = Calendar.getInstance(timeZone);
/*     */     
/* 210 */     getBytesInternal(paramInt, this.tmpBytes);
/*     */     
/* 212 */     int i = oracleYear(this.tmpBytes);
/*     */     
/* 214 */     calendar1.set(1, i);
/* 215 */     calendar1.set(2, oracleMonth(this.tmpBytes));
/* 216 */     calendar1.set(5, oracleDay(this.tmpBytes));
/* 217 */     calendar1.set(11, oracleHour(this.tmpBytes));
/* 218 */     calendar1.set(12, oracleMin(this.tmpBytes));
/* 219 */     calendar1.set(13, oracleSec(this.tmpBytes));
/* 220 */     calendar1.set(14, 0);
/*     */ 
/*     */     
/* 223 */     long l = TimeZoneAdjustUTC(calendar1);
/*     */     
/* 225 */     return new Time(l);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Timestamp getTimestamp(int paramInt, Calendar paramCalendar) throws SQLException {
/* 235 */     return getTimestamp(paramInt);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Timestamp getTimestamp(int paramInt) throws SQLException {
/* 243 */     if (isNull(paramInt)) {
/* 244 */       return null;
/*     */     }
/*     */ 
/*     */     
/* 248 */     Calendar calendar1 = this.statement.connection.getDbTzCalendar();
/*     */ 
/*     */ 
/*     */     
/* 252 */     String str = this.statement.connection.getSessionTimeZone();
/*     */     
/* 254 */     if (str == null) {
/*     */       
/* 256 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 198);
/* 257 */       sQLException.fillInStackTrace();
/* 258 */       throw sQLException;
/*     */     } 
/*     */ 
/*     */     
/* 262 */     TimeZone timeZone = TimeZone.getTimeZone(str);
/* 263 */     Calendar calendar2 = Calendar.getInstance(timeZone);
/*     */     
/* 265 */     getBytesInternal(paramInt, this.tmpBytes);
/*     */     
/* 267 */     int i = oracleYear(this.tmpBytes);
/*     */     
/* 269 */     calendar1.set(1, i);
/* 270 */     calendar1.set(2, oracleMonth(this.tmpBytes));
/* 271 */     calendar1.set(5, oracleDay(this.tmpBytes));
/* 272 */     calendar1.set(11, oracleHour(this.tmpBytes));
/* 273 */     calendar1.set(12, oracleMin(this.tmpBytes));
/* 274 */     calendar1.set(13, oracleSec(this.tmpBytes));
/* 275 */     calendar1.set(14, 0);
/*     */ 
/*     */     
/* 278 */     long l = TimeZoneAdjustUTC(calendar1);
/*     */     
/* 280 */     Timestamp timestamp = new Timestamp(l);
/*     */     
/* 282 */     if (getLength(paramInt) == 11)
/*     */     {
/* 284 */       timestamp.setNanos(oracleNanos(this.tmpBytes));
/*     */     }
/*     */     
/* 287 */     return timestamp;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Object getObject(int paramInt) throws SQLException {
/* 295 */     return getTIMESTAMPLTZ(paramInt);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Datum getOracleObject(int paramInt) throws SQLException {
/* 303 */     return (Datum)getTIMESTAMPLTZ(paramInt);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Object getObject(int paramInt, Map paramMap) throws SQLException {
/* 311 */     return getTIMESTAMPLTZ(paramInt);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   TIMESTAMPLTZ getTIMESTAMPLTZ(int paramInt) throws SQLException {
/* 319 */     if (isNull(paramInt)) {
/* 320 */       return null;
/*     */     }
/*     */     
/* 323 */     return new TIMESTAMPLTZ(getBytesInternal(paramInt));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   TIMESTAMPTZ getTIMESTAMPTZ(int paramInt) throws SQLException {
/* 331 */     if (isNull(paramInt)) {
/* 332 */       return null;
/*     */     }
/*     */     
/* 335 */     return TIMESTAMPLTZ.toTIMESTAMPTZ((Connection)this.statement.connection, getBytesInternal(paramInt));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   TIMESTAMP getTIMESTAMP(int paramInt) throws SQLException {
/* 345 */     if (isNull(paramInt)) {
/* 346 */       return null;
/*     */     }
/* 348 */     TIMESTAMPTZ tIMESTAMPTZ = getTIMESTAMPTZ(paramInt);
/* 349 */     return TIMESTAMPTZ.toTIMESTAMP((Connection)this.statement.connection, tIMESTAMPTZ.getBytes());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   DATE getDATE(int paramInt) throws SQLException {
/* 357 */     if (isNull(paramInt)) {
/* 358 */       return null;
/*     */     }
/* 360 */     TIMESTAMPTZ tIMESTAMPTZ = getTIMESTAMPTZ(paramInt);
/* 361 */     return TIMESTAMPTZ.toDATE((Connection)this.statement.connection, tIMESTAMPTZ.getBytes());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void TimeZoneAdjust(Calendar paramCalendar1, Calendar paramCalendar2) throws SQLException {
/* 374 */     String str1 = paramCalendar1.getTimeZone().getID();
/* 375 */     String str2 = paramCalendar2.getTimeZone().getID();
/*     */ 
/*     */     
/* 378 */     if (!str2.equals(str1)) {
/* 379 */       int i3; OffsetDST offsetDST = new OffsetDST();
/*     */ 
/*     */       
/* 382 */       byte b = getZoneOffset(paramCalendar1, offsetDST);
/*     */       
/* 384 */       int i4 = offsetDST.getOFFSET();
/*     */ 
/*     */       
/* 387 */       paramCalendar1.add(11, -(i4 / 3600000));
/* 388 */       paramCalendar1.add(12, -(i4 % 3600000) / 60000);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 394 */       if (str2.equals("Custom") || (str2.startsWith("GMT") && str2.length() > 3)) {
/*     */ 
/*     */         
/* 397 */         i3 = paramCalendar2.getTimeZone().getRawOffset();
/*     */       }
/*     */       else {
/*     */         
/* 401 */         int i5 = ZONEIDMAP.getID(str2);
/*     */         
/* 403 */         if (!ZONEIDMAP.isValidID(i5)) {
/*     */           
/* 405 */           SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 199);
/* 406 */           sQLException.fillInStackTrace();
/* 407 */           throw sQLException;
/*     */         } 
/*     */ 
/*     */         
/* 411 */         TIMEZONETAB tIMEZONETAB = this.statement.connection.getTIMEZONETAB();
/* 412 */         if (tIMEZONETAB.checkID(i5)) {
/* 413 */           tIMEZONETAB.updateTable((Connection)this.statement.connection, i5);
/*     */         }
/*     */         
/* 416 */         Calendar calendar = (Calendar)this.statement.getGMTCalendar().clone();
/*     */         
/* 418 */         calendar.set(0, paramCalendar1.get(0));
/* 419 */         calendar.set(1, paramCalendar1.get(1));
/* 420 */         calendar.set(2, paramCalendar1.get(2));
/* 421 */         calendar.set(5, paramCalendar1.get(5));
/* 422 */         calendar.set(11, paramCalendar1.get(11));
/* 423 */         calendar.set(12, paramCalendar1.get(12));
/* 424 */         calendar.set(13, paramCalendar1.get(13));
/* 425 */         calendar.set(14, paramCalendar1.get(14));
/*     */ 
/*     */         
/* 428 */         i3 = tIMEZONETAB.getOffset(calendar, i5);
/*     */       } 
/*     */ 
/*     */       
/* 432 */       paramCalendar1.add(11, i3 / 3600000);
/* 433 */       paramCalendar1.add(12, i3 % 3600000 / 60000);
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 440 */     if ((str2.equals("Custom") && str1.equals("Custom")) || (str2.startsWith("GMT") && str2.length() > 3 && str1.startsWith("GMT") && str1.length() > 3)) {
/*     */ 
/*     */ 
/*     */       
/* 444 */       int i3 = paramCalendar1.getTimeZone().getRawOffset();
/* 445 */       int i4 = paramCalendar2.getTimeZone().getRawOffset();
/* 446 */       int i5 = 0;
/*     */ 
/*     */       
/* 449 */       if (i3 != i4) {
/*     */         
/* 451 */         i5 = i3 - i4;
/* 452 */         i5 = (i5 > 0) ? i5 : -i5;
/*     */       } 
/*     */       
/* 455 */       if (i3 > i4) {
/* 456 */         i5 = -i5;
/*     */       }
/*     */       
/* 459 */       paramCalendar1.add(11, i5 / 3600000);
/* 460 */       paramCalendar1.add(12, i5 % 3600000 / 60000);
/*     */     } 
/*     */ 
/*     */     
/* 464 */     int i = paramCalendar1.get(1);
/* 465 */     int j = paramCalendar1.get(2);
/* 466 */     int k = paramCalendar1.get(5);
/* 467 */     int m = paramCalendar1.get(11);
/* 468 */     int n = paramCalendar1.get(12);
/* 469 */     int i1 = paramCalendar1.get(13);
/* 470 */     int i2 = paramCalendar1.get(14);
/*     */ 
/*     */     
/* 473 */     paramCalendar2.set(0, paramCalendar1.get(0));
/* 474 */     paramCalendar2.set(1, i);
/* 475 */     paramCalendar2.set(2, j);
/* 476 */     paramCalendar2.set(5, k);
/* 477 */     paramCalendar2.set(11, m);
/* 478 */     paramCalendar2.set(12, n);
/* 479 */     paramCalendar2.set(13, i1);
/* 480 */     paramCalendar2.set(14, i2);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   long TimeZoneAdjustUTC(Calendar paramCalendar) throws SQLException {
/* 490 */     String str = paramCalendar.getTimeZone().getID();
/*     */     
/* 492 */     if (str.equals("Custom") || (str.startsWith("GMT") && str.length() > 3)) {
/*     */ 
/*     */       
/* 495 */       int i3 = paramCalendar.getTimeZone().getRawOffset();
/* 496 */       paramCalendar.add(11, -(i3 / 3600000));
/* 497 */       paramCalendar.add(12, -(i3 % 3600000) / 60000);
/*     */     }
/* 499 */     else if (!str.equals("GMT") && !str.equals("UTC")) {
/* 500 */       OffsetDST offsetDST = new OffsetDST();
/*     */ 
/*     */       
/* 503 */       byte b = getZoneOffset(paramCalendar, offsetDST);
/*     */       
/* 505 */       int i3 = offsetDST.getOFFSET();
/*     */ 
/*     */ 
/*     */       
/* 509 */       paramCalendar.add(11, -(i3 / 3600000));
/* 510 */       paramCalendar.add(12, -(i3 % 3600000) / 60000);
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 518 */     int i = paramCalendar.get(1);
/* 519 */     int j = paramCalendar.get(2);
/* 520 */     int k = paramCalendar.get(5);
/* 521 */     int m = paramCalendar.get(11);
/* 522 */     int n = paramCalendar.get(12);
/* 523 */     int i1 = paramCalendar.get(13);
/* 524 */     int i2 = paramCalendar.get(14);
/*     */     
/* 526 */     Calendar calendar = (Calendar)this.statement.getGMTCalendar().clone();
/*     */ 
/*     */     
/* 529 */     calendar.set(0, paramCalendar.get(0));
/* 530 */     calendar.set(1, i);
/* 531 */     calendar.set(2, j);
/* 532 */     calendar.set(5, k);
/* 533 */     calendar.set(11, m);
/* 534 */     calendar.set(12, n);
/* 535 */     calendar.set(13, i1);
/* 536 */     calendar.set(14, i2);
/*     */     
/* 538 */     return calendar.getTimeInMillis();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   byte getZoneOffset(Calendar paramCalendar, OffsetDST paramOffsetDST) throws SQLException {
/* 548 */     byte b = 0;
/*     */ 
/*     */     
/* 551 */     String str = paramCalendar.getTimeZone().getID();
/*     */ 
/*     */     
/* 554 */     if (str == "Custom" || (str.startsWith("GMT") && str.length() > 3)) {
/*     */ 
/*     */ 
/*     */       
/* 558 */       paramOffsetDST.setOFFSET(paramCalendar.getTimeZone().getRawOffset());
/*     */     }
/*     */     else {
/*     */       
/* 562 */       int i = ZONEIDMAP.getID(str);
/*     */       
/* 564 */       if (!ZONEIDMAP.isValidID(i)) {
/*     */         
/* 566 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 199);
/* 567 */         sQLException.fillInStackTrace();
/* 568 */         throw sQLException;
/*     */       } 
/*     */ 
/*     */       
/* 572 */       TIMEZONETAB tIMEZONETAB = this.statement.connection.getTIMEZONETAB();
/* 573 */       if (tIMEZONETAB.checkID(i)) {
/* 574 */         tIMEZONETAB.updateTable((Connection)this.statement.connection, i);
/*     */       }
/*     */ 
/*     */       
/* 578 */       b = tIMEZONETAB.getLocalOffset(paramCalendar, i, paramOffsetDST);
/*     */     } 
/*     */     
/* 581 */     return b;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/* 586 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*     */   public static final String BUILD_DATE = "Thu_Apr_04_15:09:24_PDT_2013";
/*     */   public static final boolean TRACE = false;
/*     */ }


/* Location:              C:\Users\olatu\OneDrive\Documents\Calypso\syncbase\sync_base.jar!\BOOT-INF\classes\ojdbc.jar!\oracle\jdbc\driver\TimestampltzAccessor.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */