/*    */ package oracle.jdbc.driver;
/*    */ 
/*    */ import java.sql.Connection;
/*    */ import javax.transaction.xa.XAException;
/*    */ import javax.transaction.xa.XAResource;
/*    */ import oracle.jdbc.proxy._Proxy_;
/*    */ import oracle.jdbc.xa.OracleXAConnection;
/*    */ import oracle.jdbc.xa.OracleXAResource;
/*    */ import oracle.jdbc.xa.client.OracleXAConnection;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class T4CXAConnection
/*    */   extends OracleXAConnection
/*    */ {
/*    */   T4CTTIOtxen otxen;
/*    */   T4CTTIOtxse otxse;
/*    */   T4CConnection physicalConnection;
/*    */   
/*    */   public T4CXAConnection(Connection paramConnection) throws XAException {
/* 32 */     super(paramConnection);
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 40 */     if (paramConnection instanceof oracle.jdbc.babelfish.BabelfishConnection) {
/*    */       
/* 42 */       this.physicalConnection = (T4CConnection)((_Proxy_)paramConnection)._getDelegate_();
/*    */     }
/*    */     else {
/*    */       
/* 46 */       this.physicalConnection = (T4CConnection)paramConnection;
/*    */     } 
/*    */ 
/*    */     
/* 50 */     this.xaResource = null;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public synchronized XAResource getXAResource() {
/*    */     try {
/* 59 */       if (this.xaResource == null)
/*    */       {
/* 61 */         this.xaResource = (XAResource)new T4CXAResource(this.physicalConnection, (OracleXAConnection)this, this.isXAResourceTransLoose);
/*    */ 
/*    */         
/* 64 */         if (this.logicalHandle != null)
/*    */         {
/*    */ 
/*    */           
/* 68 */           ((OracleXAResource)this.xaResource).setLogicalConnection((Connection)this.logicalHandle);
/*    */         }
/*    */       }
/*    */     
/* 72 */     } catch (Exception exception) {
/*    */ 
/*    */       
/* 75 */       this.xaResource = null;
/*    */     } 
/* 77 */     return this.xaResource;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/* 82 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*    */   public static final String BUILD_DATE = "Thu_Apr_04_15:09:24_PDT_2013";
/*    */   public static final boolean TRACE = false;
/*    */ }


/* Location:              C:\Users\olatu\OneDrive\Documents\Calypso\syncbase\sync_base.jar!\BOOT-INF\classes\ojdbc.jar!\oracle\jdbc\driver\T4CXAConnection.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */