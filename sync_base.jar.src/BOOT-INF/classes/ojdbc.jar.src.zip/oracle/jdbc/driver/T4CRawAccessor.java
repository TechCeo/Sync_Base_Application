/*     */ package oracle.jdbc.driver;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.sql.SQLException;
/*     */ import oracle.jdbc.OracleResultSetMetaData;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class T4CRawAccessor
/*     */   extends RawAccessor
/*     */   implements T4CAccessor
/*     */ {
/*     */   T4CMAREngine mare;
/*     */   boolean underlyingLongRaw = false;
/*     */   private T4CMarshaller marshaller;
/*     */   
/*     */   T4CRawAccessor(OracleStatement paramOracleStatement, int paramInt1, short paramShort, int paramInt2, boolean paramBoolean, T4CMAREngine paramT4CMAREngine) throws SQLException {
/*  40 */     super(paramOracleStatement, paramInt1, paramShort, paramInt2, paramBoolean);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 182 */     this.marshaller = null; this.mare = paramT4CMAREngine; } public T4CMAREngine getMAREngine() { return this.mare; } public void unmarshalColumnMetadata() throws SQLException, IOException { if (this.statement.statementType != 2 && !this.statement.sqlKind.isPlsqlOrCall() && this.securityAttribute == OracleResultSetMetaData.SecurityAttribute.ENABLED) setRowMetadata(this.lastRowProcessed, (byte)this.mare.unmarshalUB1());  } T4CRawAccessor(OracleStatement paramOracleStatement, int paramInt1, boolean paramBoolean, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, short paramShort, int paramInt7, int paramInt8, T4CMAREngine paramT4CMAREngine) throws SQLException { super(paramOracleStatement, (paramInt1 == -1) ? paramInt8 : paramInt1, paramBoolean, paramInt2, paramInt3, paramInt4, paramInt5, paramInt6, paramShort); this.marshaller = null; this.mare = paramT4CMAREngine; if (paramOracleStatement != null && paramOracleStatement.implicitDefineForLobPrefetchDone) { this.definedColumnType = 0; this.definedColumnSize = 0; } else { this.definedColumnType = paramInt7; this.definedColumnSize = paramInt8; }  if (paramInt1 == -1) this.underlyingLongRaw = true;  }
/*     */   public void processIndicator(int paramInt) throws IOException, SQLException { if ((this.internalType == 1 && this.describeType == 112) || (this.internalType == 23 && this.describeType == 113)) { this.mare.unmarshalUB2(); this.mare.unmarshalUB2(); } else if (this.statement.connection.versionNumber < 9200) { this.mare.unmarshalSB2(); if (!this.statement.sqlKind.isPlsqlOrCall())
/* 184 */         this.mare.unmarshalSB2();  } else if (this.statement.sqlKind.isPlsqlOrCall() || this.isDMLReturnedParam) { this.mare.processIndicator((paramInt <= 0), paramInt); }  } private final T4CMarshaller getMarshaller() { if (this.marshaller == null) this.marshaller = (this.describeType == 24) ? T4CMarshaller.LONG_RAW : T4CMarshaller.RAW; 
/* 185 */     return this.marshaller; } int getPreviousRowProcessed() { if (this.previousRowProcessed == -1)
/*     */       this.previousRowProcessed = this.statement.rowPrefetchInLastFetch - 1;  return this.previousRowProcessed; }
/*     */   void copyRow() throws SQLException, IOException { if (this.isNullByDescribe) { setNull(this.lastRowProcessed, true); } else if (this.lastRowProcessed == 0) { if (this.previousRowProcessed == -1)
/*     */         this.previousRowProcessed = this.statement.rowPrefetchInLastFetch - 1;  long l = getOffset(this.previousRowProcessed); setNull(this.lastRowProcessed, isNull(this.previousRowProcessed)); this.rowMetadata[this.lastRowProcessed] = this.rowMetadata[this.previousRowProcessed]; if (!isNull(this.previousRowProcessed)) { setOffset(this.lastRowProcessed); ((DynamicByteArray)this.rowData).copyLeft(l, getLength(this.previousRowProcessed)); setLength(this.lastRowProcessed, getLength(this.previousRowProcessed)); }  }
/*     */     else { setNull(this.lastRowProcessed, isNull(this.previousRowProcessed)); this.rowMetadata[this.lastRowProcessed] = this.rowMetadata[this.previousRowProcessed]; setOffset(this.lastRowProcessed, getOffset(this.previousRowProcessed)); setLength(this.lastRowProcessed, getLength(this.previousRowProcessed)); }
/*     */      this.previousRowProcessed = this.lastRowProcessed; this.lastRowProcessed++; }
/* 191 */   String getString(int paramInt) throws SQLException { String str = super.getString(paramInt);
/*     */ 
/*     */ 
/*     */     
/* 195 */     if (str != null && this.definedColumnSize > 0 && str.length() > this.definedColumnSize * 2)
/*     */     {
/* 197 */       str = str.substring(0, this.definedColumnSize * 2);
/*     */     }
/* 199 */     return str; }
/*     */    boolean unmarshalOneRow() throws SQLException, IOException {
/*     */     return getMarshaller().unmarshalOneRow(this);
/*     */   } int readStreamFromWire(byte[] paramArrayOfbyte, int paramInt1, int paramInt2, int[] paramArrayOfint, boolean[] paramArrayOfboolean1, boolean[] paramArrayOfboolean2, T4CMAREngine paramT4CMAREngine, T4CTTIoer paramT4CTTIoer) throws SQLException, IOException {
/*     */     return getMarshaller().readStreamFromWire(paramArrayOfbyte, paramInt1, paramInt2, paramArrayOfint, paramArrayOfboolean1, paramArrayOfboolean2, paramT4CMAREngine, paramT4CTTIoer);
/*     */   } Object getObject(int paramInt) throws SQLException {
/* 205 */     if (this.definedColumnType == 0)
/* 206 */       return super.getObject(paramInt); 
/* 207 */     if (isNull(paramInt)) return null;
/*     */     
/* 209 */     switch (this.definedColumnType) {
/*     */       
/*     */       case -16:
/*     */       case -15:
/*     */       case -9:
/*     */       case -1:
/*     */       case 1:
/*     */       case 12:
/* 217 */         return getString(paramInt);
/*     */       
/*     */       case -4:
/*     */       case -2:
/* 221 */         return getRAW(paramInt);
/*     */     } 
/*     */ 
/*     */     
/* 225 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4);
/* 226 */     sQLException.fillInStackTrace();
/* 227 */     throw sQLException;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 237 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*     */   public static final String BUILD_DATE = "Thu_Apr_04_15:09:24_PDT_2013";
/*     */   public static final boolean TRACE = false;
/*     */ }


/* Location:              C:\Users\olatu\OneDrive\Documents\Calypso\syncbase\sync_base.jar!\BOOT-INF\classes\ojdbc.jar!\oracle\jdbc\driver\T4CRawAccessor.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */