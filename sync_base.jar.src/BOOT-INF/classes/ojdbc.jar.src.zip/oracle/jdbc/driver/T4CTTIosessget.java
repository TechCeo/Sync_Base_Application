/*     */ package oracle.jdbc.driver;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.sql.SQLException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class T4CTTIosessget
/*     */   extends T4CTTIfun
/*     */ {
/*     */   static final int SESSGET_TAG_MISMATCH = 1;
/*     */   static final int SESSGET_PURITY_NEW = 2;
/*     */   static final int SESSGET_SESSION_CHANGED = 4;
/*     */   static final int SESSGET_STMTCACHE_DESTROY = 8;
/*     */   int sessgetokvn;
/*     */   KeywordValueI[] sessgetokv;
/*     */   long sessgetflags;
/*     */   
/*     */   T4CTTIosessget(T4CConnection paramT4CConnection) {
/*  62 */     super(paramT4CConnection, (byte)3);
/*     */     
/*  64 */     setFunCode((short)162);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void marshal() throws IOException {
/*  73 */     this.sessgetflags = 0L;
/*  74 */     this.meg.marshalDALC(T4CMAREngine.NO_BYTES);
/*  75 */     this.meg.marshalPTR();
/*  76 */     this.meg.marshalPTR();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void readRPA() throws IOException, SQLException {
/* 105 */     int i = this.meg.unmarshalUB2();
/* 106 */     short s = this.meg.unmarshalUB1();
/* 107 */     this.meg.unmarshalNBytes(s);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/* 112 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*     */   public static final String BUILD_DATE = "Thu_Apr_04_15:09:24_PDT_2013";
/*     */   public static final boolean TRACE = false;
/*     */ }


/* Location:              C:\Users\olatu\OneDrive\Documents\Calypso\syncbase\sync_base.jar!\BOOT-INF\classes\ojdbc.jar!\oracle\jdbc\driver\T4CTTIosessget.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */