/*     */ package oracle.jdbc.driver;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.Writer;
/*     */ import java.sql.SQLException;
/*     */ import oracle.jdbc.internal.OracleClob;
/*     */ import oracle.jdbc.internal.OracleConnection;
/*     */ import oracle.sql.CLOB;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class OracleClobWriter
/*     */   extends Writer
/*     */ {
/*     */   DBConversion dbConversion;
/*     */   OracleClob clob;
/*     */   long lobOffset;
/*     */   char[] charBuf;
/*     */   byte[] nativeBuf;
/*     */   int pos;
/*     */   int count;
/*     */   int chunkSize;
/*     */   boolean isClosed;
/*     */   
/*     */   public OracleClobWriter(CLOB paramCLOB, int paramInt) throws SQLException {
/*  47 */     this((OracleClob)paramCLOB, paramInt);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public OracleClobWriter(OracleClob paramOracleClob, int paramInt) throws SQLException {
/*  58 */     this(paramOracleClob, paramInt, 1L);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public OracleClobWriter(CLOB paramCLOB, int paramInt, long paramLong) throws SQLException {
/*  73 */     this((OracleClob)paramCLOB, paramInt, paramLong);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public OracleClobWriter(OracleClob paramOracleClob, int paramInt, long paramLong) throws SQLException {
/*  88 */     if (paramOracleClob == null || paramInt <= 0 || paramOracleClob.getJavaSqlConnection() == null || paramLong < 1L)
/*     */     {
/*     */       
/*  91 */       throw new IllegalArgumentException();
/*     */     }
/*     */     
/*  94 */     this.dbConversion = ((PhysicalConnection)paramOracleClob.getInternalConnection()).conversion;
/*     */ 
/*     */     
/*  97 */     this.clob = paramOracleClob;
/*  98 */     this.lobOffset = paramLong;
/*     */     
/* 100 */     this.charBuf = new char[paramInt];
/* 101 */     this.nativeBuf = new byte[paramInt * 3];
/* 102 */     this.pos = this.count = 0;
/* 103 */     this.chunkSize = paramInt;
/*     */     
/* 105 */     this.isClosed = false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void write(char[] paramArrayOfchar, int paramInt1, int paramInt2) throws IOException {
/* 127 */     synchronized (this.lock) {
/*     */       
/* 129 */       ensureOpen();
/*     */       
/* 131 */       int i = paramInt1;
/* 132 */       int j = Math.min(paramInt2, paramArrayOfchar.length - paramInt1);
/*     */       
/* 134 */       if (j >= 2 * this.chunkSize) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 141 */         if (this.count > 0) flushBuffer();
/*     */         
/*     */         try {
/* 144 */           this.lobOffset += this.clob.putChars(this.lobOffset, paramArrayOfchar, paramInt1, j);
/*     */         }
/* 146 */         catch (SQLException sQLException) {
/*     */ 
/*     */           
/* 149 */           IOException iOException = DatabaseError.createIOException(sQLException);
/* 150 */           iOException.fillInStackTrace();
/* 151 */           throw iOException;
/*     */         } 
/*     */         
/*     */         return;
/*     */       } 
/*     */       
/* 157 */       int k = i + j;
/*     */       
/* 159 */       while (i < k) {
/*     */         
/* 161 */         int m = Math.min(this.chunkSize - this.count, k - i);
/*     */         
/* 163 */         System.arraycopy(paramArrayOfchar, i, this.charBuf, this.count, m);
/*     */         
/* 165 */         i += m;
/* 166 */         this.count += m;
/*     */         
/* 168 */         if (this.count >= this.chunkSize) {
/* 169 */           flushBuffer();
/*     */         }
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void flush() throws IOException {
/* 193 */     synchronized (this.lock) {
/*     */       
/* 195 */       ensureOpen();
/* 196 */       flushBuffer();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void close() throws IOException {
/* 217 */     synchronized (this.lock) {
/*     */       
/* 219 */       flushBuffer();
/*     */       
/* 221 */       this.isClosed = true;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void flushBuffer() throws IOException {
/* 233 */     synchronized (this.lock) {
/*     */ 
/*     */       
/*     */       try {
/* 237 */         if (this.count > 0)
/*     */         {
/* 239 */           this.lobOffset += this.clob.putChars(this.lobOffset, this.charBuf, 0, this.count);
/* 240 */           this.count = 0;
/*     */         }
/*     */       
/* 243 */       } catch (SQLException sQLException) {
/*     */ 
/*     */         
/* 246 */         IOException iOException = DatabaseError.createIOException(sQLException);
/* 247 */         iOException.fillInStackTrace();
/* 248 */         throw iOException;
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void ensureOpen() throws IOException {
/*     */     try {
/* 266 */       if (this.isClosed)
/*     */       {
/* 268 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 57, (Object)null);
/* 269 */         sQLException.fillInStackTrace();
/* 270 */         throw sQLException;
/*     */       }
/*     */     
/* 273 */     } catch (SQLException sQLException) {
/*     */ 
/*     */       
/* 276 */       IOException iOException = DatabaseError.createIOException(sQLException);
/* 277 */       iOException.fillInStackTrace();
/* 278 */       throw iOException;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected OracleConnection getConnectionDuringExceptionHandling() {
/*     */     try {
/* 298 */       return this.clob.getInternalConnection();
/*     */     }
/* 300 */     catch (Exception exception) {
/*     */       
/* 302 */       return null;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 309 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*     */   public static final String BUILD_DATE = "Thu_Apr_04_15:09:24_PDT_2013";
/*     */   public static final boolean TRACE = false;
/*     */ }


/* Location:              C:\Users\olatu\OneDrive\Documents\Calypso\syncbase\sync_base.jar!\BOOT-INF\classes\ojdbc.jar!\oracle\jdbc\driver\OracleClobWriter.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */