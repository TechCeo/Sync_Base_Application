/*     */ package oracle.jdbc.driver;
/*     */ 
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.Reader;
/*     */ import java.sql.SQLException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class LongAccessor
/*     */   extends CharCommonAccessor
/*     */ {
/*     */   static final int MAXLENGTH = 2147483647;
/*     */   OracleInputStream stream;
/*  30 */   int columnPosition = 0;
/*     */ 
/*     */ 
/*     */   
/*     */   LongAccessor(OracleStatement paramOracleStatement, int paramInt1, int paramInt2, short paramShort, int paramInt3) throws SQLException {
/*  35 */     super(paramOracleStatement, (paramInt2 > 0 && paramInt2 < Integer.MAX_VALUE) ? paramInt2 : Integer.MAX_VALUE, paramShort, false);
/*     */ 
/*     */ 
/*     */     
/*  39 */     init(paramOracleStatement, 8, 8, paramShort, false);
/*     */     
/*  41 */     this.columnPosition = paramInt1;
/*     */     
/*  43 */     initForDataAccess(paramInt3, paramInt2, (String)null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   LongAccessor(OracleStatement paramOracleStatement, int paramInt1, int paramInt2, boolean paramBoolean, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, short paramShort) throws SQLException {
/*  51 */     super(paramOracleStatement, (paramInt2 > 0 && paramInt2 < Integer.MAX_VALUE) ? paramInt2 : Integer.MAX_VALUE, paramShort, false);
/*     */ 
/*     */ 
/*     */     
/*  55 */     init(paramOracleStatement, 8, 8, paramShort, false);
/*     */     
/*  57 */     this.columnPosition = paramInt1;
/*     */     
/*  59 */     initForDescribe(8, paramInt2, paramBoolean, paramInt3, paramInt4, paramInt5, paramInt6, paramInt7, paramShort, null);
/*     */ 
/*     */     
/*  62 */     int i = paramOracleStatement.maxFieldSize;
/*     */     
/*  64 */     if (i > 0 && (paramInt2 == 0 || i < paramInt2)) {
/*  65 */       paramInt2 = i;
/*     */     }
/*  67 */     initForDataAccess(0, paramInt2, (String)null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void initForDataAccess(int paramInt1, int paramInt2, String paramString) throws SQLException {
/*  75 */     if (paramInt1 != 0) {
/*  76 */       this.externalType = paramInt1;
/*     */     }
/*  78 */     this.isStream = true;
/*  79 */     this.isColumnNumberAware = true;
/*     */ 
/*     */     
/*  82 */     this.charLength = 0;
/*     */ 
/*     */     
/*  85 */     this.stream = this.statement.connection.driverExtension.createInputStream(this.statement, this.columnPosition, this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   OracleInputStream initForNewRow() throws SQLException {
/*  95 */     this.stream = this.statement.connection.driverExtension.createInputStream(this.statement, this.columnPosition, this);
/*     */ 
/*     */     
/*  98 */     return this.stream;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void updateColumnNumber(int paramInt) {
/* 110 */     this.columnPosition = ++paramInt;
/*     */     
/* 112 */     if (this.stream != null) {
/* 113 */       this.stream.columnIndex = paramInt;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   byte[] getBytesInternal(int paramInt) throws SQLException {
/* 125 */     if (this.statement.isFetchStreams) return super.getBytesInternal(paramInt); 
/* 126 */     if (isNull(paramInt)) return null; 
/* 127 */     if (this.stream == null) return null; 
/* 128 */     if (!this.isStream) return super.getBytesInternal(paramInt); 
/* 129 */     if (this.stream.closed) {
/* 130 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 27);
/* 131 */       sQLException.fillInStackTrace();
/* 132 */       throw sQLException;
/*     */     } 
/*     */     
/* 135 */     ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream(1024);
/* 136 */     byte[] arrayOfByte = this.statement.connection.getByteBuffer(32768);
/*     */     try {
/*     */       int i;
/* 139 */       for (; (i = this.stream.read(arrayOfByte, 0, 32768)) != -1; byteArrayOutputStream.write(arrayOfByte, 0, i));
/* 140 */       this.statement.connection.cacheBuffer(arrayOfByte);
/*     */     }
/* 142 */     catch (IOException iOException) {
/*     */       
/* 144 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException);
/* 145 */       sQLException.fillInStackTrace();
/* 146 */       throw sQLException;
/*     */     } 
/*     */     
/* 149 */     return byteArrayOutputStream.toByteArray();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   String getString(int paramInt) throws SQLException {
/* 165 */     String str = null;
/* 166 */     byte[] arrayOfByte = getBytes(paramInt);
/* 167 */     if (arrayOfByte != null) {
/* 168 */       int i = (this.statement.maxFieldSize > 0 && this.statement.maxFieldSize < this.representationMaxLength) ? this.statement.maxFieldSize : this.representationMaxLength;
/*     */       
/* 170 */       int j = Math.min(arrayOfByte.length, i);
/*     */ 
/*     */ 
/*     */       
/* 174 */       assert j > 0 : "len: " + j;
/*     */       
/* 176 */       if (this.formOfUse == 2) {
/* 177 */         str = this.statement.connection.conversion.NCharBytesToString(arrayOfByte, j);
/*     */       } else {
/* 179 */         str = this.statement.connection.conversion.CharBytesToString(arrayOfByte, j);
/*     */       } 
/* 181 */     }  return str;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected InputStream convertBytesToStream(int paramInt1, int paramInt2) throws SQLException {
/* 188 */     ByteArrayInputStream byteArrayInputStream = new ByteArrayInputStream(getBytesInternal(paramInt1));
/*     */     try {
/* 190 */       InputStream inputStream = this.statement.connection.conversion.ConvertStream(byteArrayInputStream, paramInt2);
/* 191 */       return inputStream;
/*     */     } finally {
/*     */       
/*     */       try {
/* 195 */         if (byteArrayInputStream != null) byteArrayInputStream.close();
/*     */       
/* 197 */       } catch (IOException iOException) {}
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   InputStream getAsciiStream(int paramInt) throws SQLException {
/* 213 */     PhysicalConnection physicalConnection = this.statement.connection;
/* 214 */     if (isNull(paramInt)) return null; 
/* 215 */     if (this.statement.isFetchStreams) return convertBytesToStream(paramInt, 0); 
/* 216 */     if (this.stream.closed) {
/* 217 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 27);
/* 218 */       sQLException.fillInStackTrace();
/* 219 */       throw sQLException;
/*     */     } 
/* 221 */     return physicalConnection.conversion.ConvertStream(this.stream, 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   InputStream getUnicodeStream(int paramInt) throws SQLException {
/* 237 */     PhysicalConnection physicalConnection = this.statement.connection;
/* 238 */     if (isNull(paramInt)) return null; 
/* 239 */     if (this.statement.isFetchStreams) return convertBytesToStream(paramInt, 1); 
/* 240 */     if (this.stream.closed) {
/* 241 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 27);
/* 242 */       sQLException.fillInStackTrace();
/* 243 */       throw sQLException;
/*     */     } 
/* 245 */     return physicalConnection.conversion.ConvertStream(this.stream, 1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Reader getCharacterStream(int paramInt) throws SQLException {
/* 261 */     if (isNull(paramInt)) return null; 
/* 262 */     if (this.statement.isFetchStreams) {
/* 263 */       ByteArrayInputStream byteArrayInputStream = new ByteArrayInputStream(getBytesInternal(paramInt));
/*     */       try {
/* 265 */         PhysicalConnection physicalConnection1 = this.statement.connection;
/* 266 */         Reader reader = this.statement.connection.conversion.ConvertCharacterStream(byteArrayInputStream, 9, this.formOfUse);
/* 267 */         return reader;
/*     */       } finally {
/*     */         
/*     */         try {
/* 271 */           if (byteArrayInputStream != null) byteArrayInputStream.close();
/*     */         
/* 273 */         } catch (IOException iOException) {}
/*     */       } 
/*     */     } 
/* 276 */     if (this.stream.closed) {
/* 277 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 27);
/* 278 */       sQLException.fillInStackTrace();
/* 279 */       throw sQLException;
/*     */     } 
/*     */     
/* 282 */     PhysicalConnection physicalConnection = this.statement.connection;
/* 283 */     return physicalConnection.conversion.ConvertCharacterStream(this.stream, 9, this.formOfUse);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   InputStream getBinaryStream(int paramInt) throws SQLException {
/* 302 */     PhysicalConnection physicalConnection = this.statement.connection;
/* 303 */     if (isNull(paramInt)) return null; 
/* 304 */     if (this.statement.isFetchStreams) return convertBytesToStream(paramInt, 6); 
/* 305 */     if (this.stream.closed) {
/* 306 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 27);
/* 307 */       sQLException.fillInStackTrace();
/* 308 */       throw sQLException;
/*     */     } 
/* 310 */     return physicalConnection.conversion.ConvertStream(this.stream, 6);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 319 */     return "LongAccessor@" + Integer.toHexString(hashCode()) + "{columnPosition = " + this.columnPosition + "}";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 327 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*     */   public static final String BUILD_DATE = "Thu_Apr_04_15:09:24_PDT_2013";
/*     */   public static final boolean TRACE = false;
/*     */ }


/* Location:              C:\Users\olatu\OneDrive\Documents\Calypso\syncbase\sync_base.jar!\BOOT-INF\classes\ojdbc.jar!\oracle\jdbc\driver\LongAccessor.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */