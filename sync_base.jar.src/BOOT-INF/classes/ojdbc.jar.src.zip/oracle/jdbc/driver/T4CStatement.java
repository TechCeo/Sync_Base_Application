/*      */ package oracle.jdbc.driver;
/*      */ 
/*      */ import java.io.IOException;
/*      */ import java.sql.SQLException;
/*      */ import oracle.jdbc.OracleConnection;
/*      */ import oracle.jdbc.internal.OracleStatement;
/*      */ import oracle.jdbc.oracore.OracleTypeADT;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ class T4CStatement
/*      */   extends OracleStatement
/*      */ {
/*   22 */   static final byte[][][] parameterDatum = (byte[][][])null;
/*   23 */   static final OracleTypeADT[][] parameterOtype = (OracleTypeADT[][])null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*   33 */   static final byte[] EMPTY_BYTE = new byte[0];
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   T4CConnection t4Connection;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void doOall8(boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3, boolean paramBoolean4, boolean paramBoolean5) throws SQLException, IOException {
/*   45 */     doOall8(paramBoolean1, paramBoolean2, paramBoolean3, paramBoolean4, paramBoolean5, 0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void doOall8(boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3, boolean paramBoolean4, boolean paramBoolean5, int paramInt) throws SQLException, IOException {
/*   59 */     if (paramBoolean1 || paramBoolean4 || !paramBoolean2) {
/*   60 */       this.oacdefSent = null;
/*      */     }
/*   62 */     this.t4Connection.assertLoggedOn("oracle.jdbc.driver.T4CStatement.doOall8");
/*      */     
/*   64 */     if (this.sqlKind == OracleStatement.SqlKind.UNINITIALIZED) {
/*      */ 
/*      */ 
/*      */       
/*   68 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 439, "sqlKind = " + this.sqlKind);
/*   69 */       sQLException.fillInStackTrace();
/*   70 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/*   74 */     int i = this.rowPrefetch;
/*   75 */     if (paramBoolean3) {
/*   76 */       if (this.maxRows > 0 && this.maxRows <= this.indexOfFirstRow + this.storedRowCount + this.rowPrefetch) {
/*      */         
/*   78 */         i = this.maxRows - this.indexOfFirstRow + this.storedRowCount;
/*   79 */         this.isComplete = true;
/*      */       } 
/*   81 */       this.rowPrefetchInLastFetch = i;
/*   82 */       if (i == 0 && this.isComplete)
/*      */         return; 
/*      */     } 
/*   85 */     int j = this.numberOfDefinePositions;
/*      */     
/*   87 */     if (this.sqlKind.isDML()) {
/*   88 */       j = 0;
/*      */     }
/*      */     
/*   91 */     if (this.accessors != null)
/*   92 */       for (byte b = 0; b < this.accessors.length; b++) {
/*   93 */         if (this.accessors[b] != null)
/*   94 */           (this.accessors[b]).lastRowProcessed = paramInt; 
/*   95 */       }   if (this.outBindAccessors != null) {
/*   96 */       for (byte b = 0; b < this.outBindAccessors.length; b++) {
/*   97 */         if (this.outBindAccessors[b] != null) {
/*   98 */           (this.outBindAccessors[b]).lastRowProcessed = 0;
/*      */         }
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*  105 */     if (this.bindIndicators != null) {
/*      */       
/*  107 */       int k = ((this.bindIndicators[this.bindIndicatorSubRange + 3] & 0xFFFF) << 16) + (this.bindIndicators[this.bindIndicatorSubRange + 4] & 0xFFFF);
/*      */ 
/*      */       
/*  110 */       int m = 0;
/*      */       
/*  112 */       if (this.ibtBindChars != null) {
/*  113 */         m = this.ibtBindChars.length * this.connection.conversion.cMaxCharSize;
/*      */       }
/*  115 */       for (byte b = 0; b < this.numberOfBindPositions; b++) {
/*      */         
/*  117 */         int n = this.bindIndicatorSubRange + 5 + 10 * b;
/*      */ 
/*      */ 
/*      */         
/*  121 */         int i1 = this.bindIndicators[n + 2] & 0xFFFF;
/*      */ 
/*      */ 
/*      */         
/*  125 */         if (i1 != 0) {
/*      */ 
/*      */           
/*  128 */           int i2 = this.bindIndicators[n + 9] & 0xFFFF;
/*      */ 
/*      */ 
/*      */           
/*  132 */           if (i2 == 2) {
/*      */             
/*  134 */             m = Math.max(i1 * this.connection.conversion.maxNCharSize, m);
/*      */           
/*      */           }
/*      */           else {
/*      */             
/*  139 */             m = Math.max(i1 * this.connection.conversion.cMaxCharSize, m);
/*      */           } 
/*      */         } 
/*      */       } 
/*      */ 
/*      */       
/*  145 */       if (this.tmpBindsByteArray == null)
/*      */       {
/*  147 */         this.tmpBindsByteArray = new byte[m];
/*      */       }
/*  149 */       else if (this.tmpBindsByteArray.length < m)
/*      */       {
/*  151 */         this.tmpBindsByteArray = null;
/*  152 */         this.tmpBindsByteArray = new byte[m];
/*      */ 
/*      */       
/*      */       }
/*      */ 
/*      */ 
/*      */     
/*      */     }
/*      */     else {
/*      */ 
/*      */ 
/*      */       
/*  164 */       this.tmpBindsByteArray = null;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  169 */     int[] arrayOfInt1 = this.definedColumnType;
/*  170 */     int[] arrayOfInt2 = this.definedColumnSize;
/*  171 */     int[] arrayOfInt3 = this.definedColumnFormOfUse;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  177 */     if (paramBoolean5 && paramBoolean4 && this.isRowidPrepended) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  182 */       arrayOfInt1 = new int[this.definedColumnType.length + 1];
/*  183 */       System.arraycopy(this.definedColumnType, 0, arrayOfInt1, 1, this.definedColumnType.length);
/*  184 */       arrayOfInt1[0] = -8;
/*  185 */       arrayOfInt2 = new int[this.definedColumnSize.length + 1];
/*  186 */       System.arraycopy(this.definedColumnSize, 0, arrayOfInt2, 1, this.definedColumnSize.length);
/*  187 */       arrayOfInt3 = new int[this.definedColumnFormOfUse.length + 1];
/*  188 */       System.arraycopy(this.definedColumnFormOfUse, 0, arrayOfInt3, 1, this.definedColumnFormOfUse.length);
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  194 */     allocateTmpByteArray();
/*      */     
/*  196 */     T4C8Oall t4C8Oall = this.t4Connection.all8;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     try {
/*  202 */       t4C8Oall.doOALL(paramBoolean1, paramBoolean2, paramBoolean3, paramBoolean4, paramBoolean5, this.sqlKind, this.cursorId, this.sqlObject.getSqlBytes(this.processEscapes, this.convertNcharLiterals), i, this.outBindAccessors, this.numberOfBindPositions, this.accessors, j, this.bindBytes, this.bindChars, this.bindIndicators, this.bindIndicatorSubRange, this.connection.conversion, this.tmpBindsByteArray, this.parameterStream, parameterDatum, parameterOtype, this, this.ibtBindBytes, this.ibtBindChars, this.ibtBindIndicators, this.oacdefSent, arrayOfInt1, arrayOfInt2, arrayOfInt3, this.registration);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  214 */       int k = t4C8Oall.getCursorId();
/*  215 */       if (k != 0 && this.implicitResultSetStatements == null) {
/*  216 */         this.cursorId = k;
/*      */       }
/*  218 */       this.oacdefSent = t4C8Oall.oacdefBindsSent;
/*  219 */       if (this.connection.isPDBChanged) {
/*  220 */         NTFPDBChangeEvent nTFPDBChangeEvent = new NTFPDBChangeEvent((OracleConnection)this.connection);
/*      */         
/*  222 */         ((T4CConnection)this.connection).notify(nTFPDBChangeEvent);
/*  223 */         this.connection.isPDBChanged = false;
/*      */       }
/*      */     
/*  226 */     } catch (SQLException sQLException) {
/*      */       
/*  228 */       int k = t4C8Oall.getCursorId();
/*  229 */       if (k != 0) {
/*  230 */         this.cursorId = k;
/*      */       }
/*  232 */       if (sQLException.getErrorCode() == DatabaseError.getVendorCode(110)) {
/*      */ 
/*      */         
/*  235 */         this.sqlWarning = DatabaseError.addSqlWarning(this.sqlWarning, 110);
/*      */       
/*      */       }
/*      */       else {
/*      */         
/*  240 */         throw sQLException;
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void allocateTmpByteArray() {
/*  250 */     if (this.tmpByteArray == null) {
/*      */ 
/*      */       
/*  253 */       this.tmpByteArray = new byte[this.sizeTmpByteArray];
/*      */     }
/*  255 */     else if (this.sizeTmpByteArray > this.tmpByteArray.length) {
/*      */ 
/*      */ 
/*      */       
/*  259 */       this.tmpByteArray = new byte[this.sizeTmpByteArray];
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void releaseBuffers() {
/*  271 */     super.releaseBuffers();
/*  272 */     this.tmpByteArray = null;
/*  273 */     this.tmpBindsByteArray = null;
/*      */     
/*  275 */     if (this.t4Connection != null) {
/*      */       
/*  277 */       this.t4Connection.all8.bindChars = null;
/*  278 */       this.t4Connection.all8.bindBytes = null;
/*  279 */       this.t4Connection.all8.tmpBindsByteArray = null;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void allocateRowidAccessor() throws SQLException {
/*  287 */     this.accessors[0] = new T4CRowidAccessor(this, 128, (short)1, -8, false, this.t4Connection.mare);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void reparseOnRedefineIfNeeded() throws SQLException {
/*  300 */     this.needToParse = true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void defineColumnTypeInternal(int paramInt1, int paramInt2, int paramInt3, short paramShort, boolean paramBoolean, String paramString) throws SQLException {
/*  311 */     if (this.connection.disableDefinecolumntype) {
/*      */       return;
/*      */     }
/*      */ 
/*      */     
/*  316 */     if (paramInt2 == -15 || paramInt2 == -9 || paramInt2 == -16)
/*      */     {
/*  318 */       paramShort = 2;
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*  323 */     if (paramInt1 < 1) {
/*      */       
/*  325 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/*  326 */       sQLException.fillInStackTrace();
/*  327 */       throw sQLException;
/*      */     } 
/*      */     
/*  330 */     if (this.currentResultSet != null && !this.currentResultSet.closed) {
/*      */       
/*  332 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 28);
/*  333 */       sQLException.fillInStackTrace();
/*  334 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  341 */     int i = paramInt1 - 1;
/*      */     
/*  343 */     if (this.definedColumnType == null || this.definedColumnType.length <= i)
/*      */     {
/*  345 */       if (this.definedColumnType == null) {
/*      */         
/*  347 */         this.definedColumnType = new int[(i + 1) * 4];
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       }
/*      */       else {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  359 */         int[] arrayOfInt = new int[(i + 1) * 4];
/*      */         
/*  361 */         System.arraycopy(this.definedColumnType, 0, arrayOfInt, 0, this.definedColumnType.length);
/*      */ 
/*      */         
/*  364 */         this.definedColumnType = arrayOfInt;
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*  370 */     this.definedColumnType[i] = paramInt2;
/*      */     
/*  372 */     if (this.definedColumnSize == null || this.definedColumnSize.length <= i)
/*      */     {
/*  374 */       if (this.definedColumnSize == null) {
/*  375 */         this.definedColumnSize = new int[(i + 1) * 4];
/*      */       }
/*      */       else {
/*      */         
/*  379 */         int[] arrayOfInt = new int[(i + 1) * 4];
/*      */         
/*  381 */         System.arraycopy(this.definedColumnSize, 0, arrayOfInt, 0, this.definedColumnSize.length);
/*      */ 
/*      */         
/*  384 */         this.definedColumnSize = arrayOfInt;
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*  389 */     this.definedColumnSize[i] = (paramInt2 == 2005 || paramInt2 == 2004) ? paramInt3 : -1;
/*      */     
/*  391 */     if (this.definedColumnFormOfUse == null || this.definedColumnFormOfUse.length <= i)
/*      */     {
/*  393 */       if (this.definedColumnFormOfUse == null) {
/*  394 */         this.definedColumnFormOfUse = new int[(i + 1) * 4];
/*      */       }
/*      */       else {
/*      */         
/*  398 */         int[] arrayOfInt = new int[(i + 1) * 4];
/*      */         
/*  400 */         System.arraycopy(this.definedColumnFormOfUse, 0, arrayOfInt, 0, this.definedColumnFormOfUse.length);
/*      */ 
/*      */         
/*  403 */         this.definedColumnFormOfUse = arrayOfInt;
/*      */       } 
/*      */     }
/*      */     
/*  407 */     this.definedColumnFormOfUse[i] = paramShort;
/*      */     
/*  409 */     if (this.accessors != null && i < this.accessors.length && this.accessors[i] != null) {
/*      */       
/*  411 */       (this.accessors[i]).definedColumnSize = paramInt3;
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  416 */       if (((this.accessors[i]).internalType == 96 || (this.accessors[i]).internalType == 1) && (paramInt2 == 1 || paramInt2 == 12))
/*      */       {
/*      */ 
/*      */         
/*  420 */         if (paramInt3 <= (this.accessors[i]).oacmxl) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  426 */           this.needToPrepareDefineBuffer = true;
/*  427 */           this.columnsDefinedByUser = true;
/*      */           
/*  429 */           this.accessors[i].initForDataAccess(paramInt2, paramInt3, null);
/*  430 */           this.accessors[i].calculateSizeTmpByteArray();
/*      */         } 
/*      */       }
/*      */     } 
/*      */     
/*  435 */     this.executeDoneForDefines = false;
/*      */   }
/*      */ 
/*      */   
/*      */   public void clearDefines() throws SQLException {
/*  440 */     synchronized (this.connection) {
/*      */       
/*  442 */       super.clearDefines();
/*  443 */       this.definedColumnType = null;
/*  444 */       this.definedColumnSize = null;
/*  445 */       this.definedColumnFormOfUse = null;
/*  446 */       if (this.t4Connection != null && this.t4Connection.all8 != null) {
/*  447 */         this.t4Connection.all8.definesAccessors = null;
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void doSetSnapshotSCN(long paramLong) throws SQLException {
/*  456 */     this.inScn = paramLong; } Accessor allocateAccessor(int paramInt1, int paramInt2, int paramInt3, int paramInt4, short paramShort, String paramString, boolean paramBoolean) throws SQLException { T4CVarcharAccessor t4CVarcharAccessor;
/*      */     T4CNumberAccessor t4CNumberAccessor;
/*      */     T4CVarnumAccessor t4CVarnumAccessor;
/*      */     T4CRawAccessor t4CRawAccessor;
/*      */     T4CBinaryFloatAccessor t4CBinaryFloatAccessor;
/*      */     T4CBinaryDoubleAccessor t4CBinaryDoubleAccessor;
/*      */     T4CRowidAccessor t4CRowidAccessor;
/*      */     T4CResultSetAccessor t4CResultSetAccessor;
/*      */     T4CDateAccessor t4CDateAccessor;
/*      */     T4CBlobAccessor t4CBlobAccessor;
/*      */     T4CClobAccessor t4CClobAccessor;
/*      */     T4CBfileAccessor t4CBfileAccessor;
/*      */     T4CNamedTypeAccessor t4CNamedTypeAccessor;
/*      */     T4CRefTypeAccessor t4CRefTypeAccessor;
/*      */     T4CTimestampAccessor t4CTimestampAccessor;
/*      */     T4CTimestamptzAccessor t4CTimestamptzAccessor;
/*      */     T4CTimestampltzAccessor t4CTimestampltzAccessor;
/*      */     T4CIntervalymAccessor t4CIntervalymAccessor;
/*      */     T4CIntervaldsAccessor t4CIntervaldsAccessor;
/*      */     SQLException sQLException;
/*  476 */     T4CCharAccessor t4CCharAccessor = null;
/*      */     
/*  478 */     switch (paramInt1) {
/*      */ 
/*      */       
/*      */       case 96:
/*  482 */         t4CCharAccessor = new T4CCharAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 8:
/*  488 */         if (!paramBoolean) {
/*      */           
/*  490 */           T4CLongAccessor t4CLongAccessor = new T4CLongAccessor(this, paramInt3, paramInt4, paramShort, paramInt2, this.t4Connection.mare);
/*      */           break;
/*      */         } 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 1:
/*  498 */         t4CVarcharAccessor = new T4CVarcharAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 2:
/*  504 */         t4CNumberAccessor = new T4CNumberAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 6:
/*  510 */         t4CVarnumAccessor = new T4CVarnumAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 24:
/*  516 */         if (!paramBoolean) {
/*      */           
/*  518 */           T4CLongRawAccessor t4CLongRawAccessor = new T4CLongRawAccessor(this, paramInt3, paramInt4, paramShort, paramInt2, this.t4Connection.mare);
/*      */           break;
/*      */         } 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 23:
/*  526 */         if (paramBoolean && paramString != null) {
/*      */           
/*  528 */           SQLException sQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 12, "sqlType=" + paramInt2);
/*  529 */           sQLException1.fillInStackTrace();
/*  530 */           throw sQLException1;
/*      */         } 
/*      */         
/*  533 */         if (paramBoolean) {
/*  534 */           T4COutRawAccessor t4COutRawAccessor = new T4COutRawAccessor(this, paramInt4, paramShort, paramInt2, this.t4Connection.mare);
/*      */           break;
/*      */         } 
/*  537 */         t4CRawAccessor = new T4CRawAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 100:
/*  543 */         t4CBinaryFloatAccessor = new T4CBinaryFloatAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 101:
/*  549 */         t4CBinaryDoubleAccessor = new T4CBinaryDoubleAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 104:
/*  555 */         if (this.sqlKind == OracleStatement.SqlKind.CALL_BLOCK) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  561 */           T4CVarcharAccessor t4CVarcharAccessor1 = new T4CVarcharAccessor(this, 18, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */ 
/*      */ 
/*      */           
/*  565 */           t4CVarcharAccessor1.definedColumnType = -8;
/*      */           break;
/*      */         } 
/*  568 */         t4CRowidAccessor = new T4CRowidAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */         break;
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 102:
/*  575 */         t4CResultSetAccessor = new T4CResultSetAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 12:
/*  581 */         t4CDateAccessor = new T4CDateAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 113:
/*  587 */         t4CBlobAccessor = new T4CBlobAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 112:
/*  593 */         t4CClobAccessor = new T4CClobAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 114:
/*  599 */         t4CBfileAccessor = new T4CBfileAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 109:
/*  605 */         t4CNamedTypeAccessor = new T4CNamedTypeAccessor(this, paramString, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */ 
/*      */         
/*  608 */         t4CNamedTypeAccessor.initMetadata();
/*      */         break;
/*      */ 
/*      */       
/*      */       case 111:
/*  613 */         t4CRefTypeAccessor = new T4CRefTypeAccessor(this, paramString, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */ 
/*      */         
/*  616 */         t4CRefTypeAccessor.initMetadata();
/*      */         break;
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 180:
/*  623 */         t4CTimestampAccessor = new T4CTimestampAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 181:
/*  629 */         t4CTimestamptzAccessor = new T4CTimestamptzAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 231:
/*  635 */         t4CTimestampltzAccessor = new T4CTimestampltzAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 182:
/*  641 */         t4CIntervalymAccessor = new T4CIntervalymAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 183:
/*  647 */         t4CIntervaldsAccessor = new T4CIntervaldsAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */         break;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 995:
/*  663 */         sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 89);
/*  664 */         sQLException.fillInStackTrace();
/*  665 */         throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/*  669 */     return t4CIntervaldsAccessor; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void doDescribe(boolean paramBoolean) throws SQLException {
/*  695 */     if (!this.isOpen) {
/*      */ 
/*      */ 
/*      */       
/*  699 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 144);
/*  700 */       sQLException.fillInStackTrace();
/*  701 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     try {
/*  708 */       this.t4Connection.needLine();
/*  709 */       this.t4Connection.describe.doODNY(this, 0, this.accessors, this.sqlObject.getSqlBytes(this.processEscapes, this.convertNcharLiterals));
/*  710 */       this.accessors = this.t4Connection.describe.getAccessors();
/*      */       
/*  712 */       this.numberOfDefinePositions = this.t4Connection.describe.numuds;
/*      */       
/*  714 */       for (byte b = 0; b < this.numberOfDefinePositions; b++) {
/*  715 */         this.accessors[b].initMetadata();
/*      */       }
/*  717 */     } catch (IOException iOException) {
/*      */       
/*  719 */       ((T4CConnection)this.connection).handleIOException(iOException);
/*      */ 
/*      */       
/*  722 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException);
/*  723 */       sQLException.fillInStackTrace();
/*  724 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/*  728 */     this.describedWithNames = true;
/*  729 */     this.described = true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void executeForDescribe() throws SQLException {
/*  764 */     this.t4Connection.assertLoggedOn("oracle.jdbc.driver.T4CStatement.execute_for_describe");
/*      */     try {
/*  766 */       doOall8(true, true, (this.definedColumnType != null), true, (this.definedColumnType != null));
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     }
/*  772 */     catch (SQLException sQLException) {
/*      */ 
/*      */       
/*  775 */       throw sQLException;
/*      */     }
/*  777 */     catch (IOException iOException) {
/*      */       
/*  779 */       ((T4CConnection)this.connection).handleIOException(iOException);
/*      */       
/*  781 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException);
/*  782 */       sQLException.fillInStackTrace();
/*  783 */       throw sQLException;
/*      */     
/*      */     }
/*      */     finally {
/*      */       
/*  788 */       this.rowsProcessed = this.t4Connection.all8.rowsProcessed;
/*  789 */       this.validRows = this.t4Connection.all8.getNumRows();
/*  790 */       if (this.connection.checksumMode.needToCalculateFetchChecksum()) {
/*  791 */         if (this.validRows > 0) {
/*  792 */           calculateCheckSum();
/*  793 */         } else if (this.rowsProcessed > 0) {
/*  794 */           long l = CRC64.updateChecksum(this.checkSum, this.rowsProcessed);
/*      */           
/*  796 */           this.checkSum = l;
/*      */         } 
/*      */       }
/*      */     } 
/*      */     
/*  801 */     this.needToParse = false;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  811 */     if (this.definedColumnType == null) {
/*  812 */       this.implicitDefineForLobPrefetchDone = false;
/*      */     }
/*  814 */     this.aFetchWasDoneDuringDescribe = false;
/*  815 */     if (this.t4Connection.all8.aFetchWasDone) {
/*      */       
/*  817 */       this.aFetchWasDoneDuringDescribe = true;
/*  818 */       this.rowPrefetchInLastFetch = this.rowPrefetch;
/*      */     } 
/*      */ 
/*      */     
/*  822 */     for (byte b = 0; b < this.numberOfDefinePositions; b++) {
/*  823 */       this.accessors[b].initMetadata();
/*      */     }
/*  825 */     this.needToPrepareDefineBuffer = false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void executeForRows(boolean paramBoolean) throws SQLException {
/*      */     try {
/*      */       try {
/*  867 */         boolean bool = false;
/*  868 */         if (this.columnsDefinedByUser) {
/*  869 */           this.needToPrepareDefineBuffer = false;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         }
/*  889 */         else if (this.t4Connection.useLobPrefetch && this.accessors != null && this.defaultLobPrefetchSize != -1 && !this.implicitDefineForLobPrefetchDone && !this.aFetchWasDoneDuringDescribe && this.definedColumnType == null) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  897 */           boolean bool1 = false;
/*  898 */           int[] arrayOfInt1 = new int[this.accessors.length];
/*  899 */           int[] arrayOfInt2 = new int[this.accessors.length];
/*  900 */           int[] arrayOfInt3 = new int[this.accessors.length];
/*      */           
/*  902 */           for (byte b = 0; b < this.accessors.length; b++) {
/*  903 */             if (this.accessors[b] != null) {
/*      */ 
/*      */ 
/*      */               
/*  907 */               arrayOfInt1[b] = getJDBCType((this.accessors[b]).internalType);
/*  908 */               arrayOfInt3[b] = (this.accessors[b]).formOfUse;
/*  909 */               if ((this.accessors[b]).internalType == 113 || (this.accessors[b]).internalType == 112 || (this.accessors[b]).internalType == 114) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */                 
/*  915 */                 bool1 = true;
/*      */                 
/*  917 */                 this.accessors[b].setPrefetchLength(this.defaultLobPrefetchSize);
/*  918 */                 arrayOfInt2[b] = this.defaultLobPrefetchSize;
/*      */               } 
/*      */             } 
/*      */           } 
/*  922 */           if (bool1) {
/*      */             
/*  924 */             this.definedColumnType = arrayOfInt1;
/*  925 */             this.definedColumnSize = arrayOfInt2;
/*  926 */             this.definedColumnFormOfUse = arrayOfInt3;
/*  927 */             bool = true;
/*      */           } 
/*      */         } 
/*      */ 
/*      */ 
/*      */         
/*  933 */         doOall8(this.needToParse, !paramBoolean, true, false, bool);
/*      */         
/*  935 */         this.needToParse = false;
/*  936 */         if (bool) {
/*  937 */           this.implicitDefineForLobPrefetchDone = true;
/*      */         }
/*      */       } finally {
/*      */         
/*  941 */         if (this.implicitResultSetStatements == null) {
/*  942 */           this.validRows = this.t4Connection.all8.getNumRows();
/*      */         } else {
/*  944 */           this.validRows = 0;
/*  945 */         }  calculateCheckSum();
/*      */       }
/*      */     
/*  948 */     } catch (SQLException sQLException) {
/*      */       
/*  950 */       throw sQLException;
/*      */     }
/*  952 */     catch (IOException iOException) {
/*      */       
/*  954 */       ((T4CConnection)this.connection).handleIOException(iOException);
/*      */       
/*  956 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException);
/*  957 */       sQLException.fillInStackTrace();
/*  958 */       throw sQLException;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void fetch(int paramInt, boolean paramBoolean) throws SQLException {
/*  984 */     if (this.rowData != null) {
/*  985 */       if (paramBoolean) {
/*      */         
/*  987 */         this.rowData.setPosition(this.rowData.length());
/*      */       } else {
/*  989 */         this.rowData.reset();
/*      */       } 
/*      */     }
/*      */     
/*  993 */     if (this.streamList != null)
/*      */     {
/*  995 */       while (this.nextStream != null) {
/*      */         try {
/*  997 */           this.nextStream.close();
/*      */         }
/*  999 */         catch (IOException iOException) {
/* 1000 */           ((T4CConnection)this.connection).handleIOException(iOException);
/*      */           
/* 1002 */           SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException);
/* 1003 */           sQLException.fillInStackTrace();
/* 1004 */           throw sQLException;
/*      */         } 
/*      */         
/* 1007 */         this.nextStream = this.nextStream.nextStream;
/*      */       } 
/*      */     }
/*      */     
/*      */     try {
/* 1012 */       doOall8(false, false, true, false, false, paramInt);
/* 1013 */       this.validRows = this.t4Connection.all8.getNumRows();
/* 1014 */       if (this.validRows != -2) this.validRows -= paramInt; 
/* 1015 */       calculateCheckSum();
/*      */     }
/* 1017 */     catch (IOException iOException) {
/* 1018 */       ((T4CConnection)this.connection).handleIOException(iOException);
/*      */       
/* 1020 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException);
/* 1021 */       sQLException.fillInStackTrace();
/* 1022 */       throw sQLException;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void continueReadRow(int paramInt) throws SQLException {
/*      */     try {
/* 1041 */       if (!this.isFetchStreams)
/*      */       {
/* 1043 */         T4C8Oall t4C8Oall = this.t4Connection.all8;
/*      */         
/* 1045 */         t4C8Oall.continueReadRow(paramInt, this);
/*      */       }
/*      */     
/* 1048 */     } catch (IOException iOException) {
/*      */       
/* 1050 */       ((T4CConnection)this.connection).handleIOException(iOException);
/*      */       
/* 1052 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException);
/* 1053 */       sQLException.fillInStackTrace();
/* 1054 */       throw sQLException;
/*      */     
/*      */     }
/* 1057 */     catch (SQLException sQLException) {
/*      */       
/* 1059 */       if (sQLException.getErrorCode() == DatabaseError.getVendorCode(110)) {
/*      */ 
/*      */         
/* 1062 */         this.sqlWarning = DatabaseError.addSqlWarning(this.sqlWarning, 110);
/*      */       
/*      */       }
/*      */       else {
/*      */         
/* 1067 */         throw sQLException;
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void doClose() throws SQLException {
/* 1091 */     this.t4Connection.assertLoggedOn("oracle.jdbc.driver.T4CStatement.do_close");
/* 1092 */     if (this.cursorId != 0)
/*      */     {
/* 1094 */       this.t4Connection.closeCursor(this.cursorId);
/*      */     }
/*      */     
/* 1097 */     this.tmpByteArray = null;
/* 1098 */     this.tmpBindsByteArray = null;
/* 1099 */     this.definedColumnType = null;
/* 1100 */     this.definedColumnSize = null;
/* 1101 */     this.definedColumnFormOfUse = null;
/* 1102 */     this.oacdefSent = null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void closeQuery() throws SQLException {
/* 1121 */     this.connection.registerHeartbeat();
/* 1122 */     this.connection.needLine();
/* 1123 */     this.t4Connection.assertLoggedOn("oracle.jdbc.driver.T4CStatement.closeQuery");
/*      */     
/* 1125 */     if (this.streamList != null)
/*      */     {
/* 1127 */       while (this.nextStream != null) {
/*      */         try {
/* 1129 */           this.nextStream.close();
/*      */         }
/* 1131 */         catch (IOException iOException) {
/* 1132 */           ((T4CConnection)this.connection).handleIOException(iOException);
/*      */           
/* 1134 */           SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException);
/* 1135 */           sQLException.fillInStackTrace();
/* 1136 */           throw sQLException;
/*      */         } 
/*      */         
/* 1139 */         this.nextStream = this.nextStream.nextStream;
/*      */       } 
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   T4CStatement(PhysicalConnection paramPhysicalConnection, int paramInt1, int paramInt2) throws SQLException {
/* 1152 */     super(paramPhysicalConnection, 1, paramPhysicalConnection.defaultRowPrefetch, paramInt1, paramInt2);
/*      */     
/* 1154 */     this.nbPostPonedColumns = new int[1];
/* 1155 */     this.nbPostPonedColumns[0] = 0;
/* 1156 */     this.indexOfPostPonedColumn = new int[1][3];
/* 1157 */     this.t4Connection = (T4CConnection)paramPhysicalConnection;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void closeCursorOnPlainStatement() throws SQLException {
/* 1172 */     if (this.cursorId != 0 && this.t4Connection.isLoggedOn()) {
/* 1173 */       this.t4Connection.closeCursor(this.cursorId);
/* 1174 */       setCursorId(0);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/* 1180 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*      */   public static final String BUILD_DATE = "Thu_Apr_04_15:09:24_PDT_2013";
/*      */   public static final boolean TRACE = false;
/*      */ }


/* Location:              C:\Users\olatu\OneDrive\Documents\Calypso\syncbase\sync_base.jar!\BOOT-INF\classes\ojdbc.jar!\oracle\jdbc\driver\T4CStatement.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */