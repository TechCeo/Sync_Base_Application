/*     */ package oracle.jdbc.driver;
/*     */ 
/*     */ import java.sql.SQLException;
/*     */ import oracle.jdbc.internal.OracleConnection;
/*     */ import oracle.sql.CharacterSet;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ abstract class ByteArray
/*     */ {
/*  24 */   protected long position = 0L;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   abstract long length();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   final long getPosition() {
/*  43 */     return this.position;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   final void setPosition(long paramLong) {
/*  53 */     assert paramLong >= 0L : "index: " + paramLong;
/*  54 */     this.position = paramLong;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   final void reset() {
/*  62 */     setPosition(0L);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   final byte get() {
/*  77 */     assert this.position < length() : "position: " + this.position + " length: " + length();
/*  78 */     return get(this.position++);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   final byte[] getBytes(int paramInt) {
/*  92 */     assert paramInt >= 0 && length() >= getPosition() + paramInt : "this.length: " + length() + " position: " + this.position + " length: " + paramInt;
/*  93 */     byte[] arrayOfByte = get(this.position, paramInt);
/*  94 */     this.position += paramInt;
/*     */     
/*  96 */     return arrayOfByte;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   final void getBytes(byte[] paramArrayOfbyte, int paramInt1, int paramInt2) {
/* 112 */     assert paramArrayOfbyte != null : "dest is null";
/*     */     
/* 114 */     assert paramInt1 >= 0 && paramInt2 >= 0 && paramArrayOfbyte.length >= paramInt1 + paramInt2 : "destOffset: " + paramInt1 + " length: " + paramInt2 + " dest.length: " + paramArrayOfbyte.length;
/*     */     
/* 116 */     assert length() >= this.position + paramInt2 : " this.length: " + length() + " this.position: " + this.position + " length: " + paramInt2;
/* 117 */     get(this.position, paramArrayOfbyte, paramInt1, paramInt2);
/* 118 */     this.position += paramInt2;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   final int getShort() {
/* 130 */     assert this.position + 1L < length() : "position: " + this.position + " length: " + length();
/* 131 */     return (get() & 0xFF) << 8 | get() & 0xFF;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   final int getInt() {
/* 142 */     assert this.position + 3L < length() : "position: " + this.position + " length: " + length();
/* 143 */     return (get() & 0xFF) << 24 | (get() & 0xFF) << 16 | (get() & 0xFF) << 8 | get() & 0xFF;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   final String getString(int paramInt, CharacterSet paramCharacterSet) throws SQLException {
/* 159 */     String str = getString(this.position, paramInt, paramCharacterSet);
/* 160 */     this.position += paramInt;
/* 161 */     return str;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   final void put(byte paramByte) {
/* 176 */     put(this.position++, paramByte);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   final void putShort(short paramShort) {
/* 184 */     putShort(this.position, paramShort);
/* 185 */     this.position += 2L;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   final void putInt(int paramInt) {
/* 194 */     putInt(this.position, paramInt);
/* 195 */     this.position += 4L;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   final void put(byte[] paramArrayOfbyte) {
/* 207 */     put(this.position, paramArrayOfbyte);
/* 208 */     this.position += paramArrayOfbyte.length;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   final void put(byte[] paramArrayOfbyte, int paramInt1, int paramInt2) {
/* 225 */     assert paramArrayOfbyte != null : "src is null";
/* 226 */     assert paramInt1 >= 0 && paramInt2 >= 0 : "srcOffset: " + paramInt1 + " length: " + paramInt2;
/*     */     
/* 228 */     assert paramArrayOfbyte.length >= paramInt1 + paramInt2 : "src.length: " + paramArrayOfbyte.length + " srcOffset: " + paramInt1 + " length: " + paramInt2;
/* 229 */     put(this.position, paramArrayOfbyte, paramInt1, paramInt2);
/* 230 */     this.position += paramInt2;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   abstract void put(long paramLong, byte paramByte);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   abstract byte get(long paramLong);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   final void putShort(long paramLong, short paramShort) {
/* 267 */     put(paramLong, (byte)(paramShort >> 8 & 0xFF));
/* 268 */     put(paramLong + 1L, (byte)(paramShort & 0xFF));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   final void putInt(long paramLong, int paramInt) {
/* 284 */     for (byte b = 3; b >= 0; b--) {
/* 285 */       put(paramLong + b, (byte)(paramInt & 0xFF));
/* 286 */       paramInt >>= 8;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   final void put(long paramLong, byte[] paramArrayOfbyte) {
/* 300 */     assert paramLong >= 0L && paramArrayOfbyte != null : "offset: " + paramLong + " src: " + paramArrayOfbyte;
/* 301 */     put(paramLong, paramArrayOfbyte, 0, paramArrayOfbyte.length);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   abstract void put(long paramLong, byte[] paramArrayOfbyte, int paramInt1, int paramInt2);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void put(long paramLong1, ByteArray paramByteArray, long paramLong2, int paramInt) {
/* 334 */     assert paramLong1 >= 0L && paramByteArray != null && paramLong2 >= 0L : "offset: " + paramLong1 + " src: " + paramByteArray + " srcOffset: " + paramLong2;
/* 335 */     byte[] arrayOfByte = paramByteArray.get(paramLong2, paramInt);
/* 336 */     put(paramLong1, arrayOfByte, 0, paramInt);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   final byte[] get(long paramLong, int paramInt) {
/* 351 */     assert paramLong >= 0L && paramInt >= 0 && length() >= paramLong + paramInt : "this.length: " + length() + " offset: " + paramLong + " length: " + paramInt;
/* 352 */     byte[] arrayOfByte = new byte[paramInt];
/* 353 */     get(paramLong, arrayOfByte, 0, paramInt);
/* 354 */     return arrayOfByte;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   abstract void get(long paramLong, byte[] paramArrayOfbyte, int paramInt1, int paramInt2);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   String getString(long paramLong, int paramInt, CharacterSet paramCharacterSet) throws SQLException {
/* 387 */     int[] arrayOfInt = new int[1];
/* 388 */     char[] arrayOfChar = getChars(paramLong, paramInt, paramCharacterSet, arrayOfInt);
/* 389 */     if (arrayOfInt[0] == arrayOfChar.length) {
/* 390 */       return new String(arrayOfChar);
/*     */     }
/* 392 */     return String.valueOf(arrayOfChar, 0, arrayOfInt[0]);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   char[] getChars(long paramLong, int paramInt, CharacterSet paramCharacterSet) throws SQLException {
/* 411 */     int[] arrayOfInt = new int[1];
/* 412 */     char[] arrayOfChar1 = getChars(paramLong, paramInt, paramCharacterSet, arrayOfInt);
/* 413 */     if (arrayOfInt[0] == arrayOfChar1.length) {
/* 414 */       return arrayOfChar1;
/*     */     }
/* 416 */     char[] arrayOfChar2 = new char[arrayOfInt[0]];
/* 417 */     System.arraycopy(arrayOfChar1, 0, arrayOfChar2, 0, arrayOfChar2.length);
/* 418 */     return arrayOfChar2;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   abstract char[] getChars(long paramLong, int paramInt, CharacterSet paramCharacterSet, int[] paramArrayOfint) throws SQLException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean equalBytes(long paramLong1, int paramInt, ByteArray paramByteArray, long paramLong2) throws SQLException {
/* 462 */     if (paramLong1 + paramInt >= length() || paramLong2 + paramInt >= paramByteArray.length())
/* 463 */       return false; 
/* 464 */     for (byte b = 0; b < paramInt; b++) {
/* 465 */       if (get(paramLong1 + b) != paramByteArray.get(paramLong2 + b)) return false; 
/*     */     } 
/* 467 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   abstract long updateChecksum(long paramLong1, int paramInt, CRC64 paramCRC64, long paramLong2);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   byte[] getBytesFromHex(long paramLong, int paramInt, CharacterSet paramCharacterSet) throws SQLException {
/* 496 */     int[] arrayOfInt = new int[1];
/* 497 */     char[] arrayOfChar = getChars(paramLong, paramInt, paramCharacterSet, arrayOfInt);
/* 498 */     int i = arrayOfInt[0];
/* 499 */     byte[] arrayOfByte = new byte[(i + 1) / 2];
/* 500 */     boolean bool = true;
/* 501 */     byte b = 0;
/* 502 */     for (char c : arrayOfChar) {
/* 503 */       if (bool) { arrayOfByte[b] = (byte)(hexDigit2Nibble(c) << 4); }
/* 504 */       else { arrayOfByte[b++] = (byte)(arrayOfByte[b++] + (hexDigit2Nibble(c) & 0xF)); }
/* 505 */        bool = !bool ? true : false;
/*     */     } 
/* 507 */     return arrayOfByte;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   final int hexDigit2Nibble(char paramChar) throws SQLException {
/* 521 */     int i = Character.digit(paramChar, 16);
/* 522 */     if (i == -1) {
/*     */       
/* 524 */       SQLException sQLException = DatabaseError.createSqlException((OracleConnection)null, 59, "Invalid hex digit: " + paramChar);
/* 525 */       sQLException.fillInStackTrace();
/* 526 */       throw sQLException;
/*     */     } 
/* 528 */     return i;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   final void freeSpace(long paramLong, int paramInt) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   byte[] getBlockBasic(long paramLong, int[] paramArrayOfint) {
/* 547 */     throw new Error("not implemented");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 555 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*     */   public static final String BUILD_DATE = "Thu_Apr_04_15:09:24_PDT_2013";
/*     */   public static final boolean TRACE = false;
/*     */   
/*     */   abstract void free();
/*     */ }


/* Location:              C:\Users\olatu\OneDrive\Documents\Calypso\syncbase\sync_base.jar!\BOOT-INF\classes\ojdbc.jar!\oracle\jdbc\driver\ByteArray.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */