/*     */ package oracle.jdbc.driver;
/*     */ 
/*     */ import java.sql.Connection;
/*     */ import java.sql.Date;
/*     */ import java.sql.SQLException;
/*     */ import java.sql.Time;
/*     */ import java.sql.Timestamp;
/*     */ import java.util.Calendar;
/*     */ import java.util.Date;
/*     */ import java.util.Map;
/*     */ import java.util.TimeZone;
/*     */ import oracle.sql.DATE;
/*     */ import oracle.sql.Datum;
/*     */ import oracle.sql.TIMESTAMP;
/*     */ import oracle.sql.TIMESTAMPTZ;
/*     */ import oracle.sql.TIMEZONETAB;
/*     */ import oracle.sql.ZONEIDMAP;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class TimestamptzAccessor
/*     */   extends DateTimeCommonAccessor
/*     */ {
/*     */   static final int MAXLENGTH = 13;
/*  30 */   TimestampTzConverter tstzConverter = null;
/*     */ 
/*     */ 
/*     */   
/*     */   TimestamptzAccessor(OracleStatement paramOracleStatement, int paramInt1, short paramShort, int paramInt2, boolean paramBoolean) throws SQLException {
/*  35 */     super(Representation.TIMESTAMPTZ, paramOracleStatement, 13, paramBoolean);
/*     */     
/*  37 */     init(paramOracleStatement, 181, 181, paramShort, paramBoolean);
/*  38 */     initForDataAccess(paramInt2, paramInt1, null);
/*     */     
/*  40 */     if (this.statement.connection.timestamptzInGmt) {
/*  41 */       this.tstzConverter = new GmtTimestampTzConverter();
/*     */     } else {
/*  43 */       this.tstzConverter = new OldTimestampTzConverter();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   TimestamptzAccessor(OracleStatement paramOracleStatement, int paramInt1, boolean paramBoolean, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, short paramShort) throws SQLException {
/*  51 */     super(Representation.TIMESTAMPTZ, paramOracleStatement, 13, false);
/*     */     
/*  53 */     init(paramOracleStatement, 181, 181, paramShort, false);
/*  54 */     initForDescribe(181, paramInt1, paramBoolean, paramInt2, paramInt3, paramInt4, paramInt5, paramInt6, paramShort, null);
/*     */     
/*  56 */     initForDataAccess(0, paramInt1, null);
/*     */     
/*  58 */     if (this.statement.connection.timestamptzInGmt) {
/*  59 */       this.tstzConverter = new GmtTimestampTzConverter();
/*     */     } else {
/*  61 */       this.tstzConverter = new OldTimestampTzConverter();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   String getString(int paramInt) throws SQLException {
/*     */     String str;
/*  69 */     if (isNull(paramInt)) {
/*  70 */       return null;
/*     */     }
/*     */ 
/*     */     
/*  74 */     int i = 0;
/*  75 */     getBytesInternal(paramInt, this.tmpBytes);
/*     */     
/*  77 */     if ((oracleTZ1(this.tmpBytes) & REGIONIDBIT) != 0) {
/*  78 */       i = getHighOrderbits(oracleTZ1(this.tmpBytes));
/*  79 */       i += getLowOrderbits(oracleTZ2(this.tmpBytes));
/*     */ 
/*     */       
/*  82 */       TIMEZONETAB tIMEZONETAB = this.statement.connection.getTIMEZONETAB();
/*  83 */       if (tIMEZONETAB.checkID(i)) {
/*  84 */         tIMEZONETAB.updateTable((Connection)this.statement.connection, i);
/*     */       }
/*     */       
/*  87 */       str = ZONEIDMAP.getRegion(i);
/*     */     } else {
/*     */       
/*  90 */       int i4 = oracleTZ1(this.tmpBytes) - OFFSET_HOUR;
/*  91 */       int i5 = oracleTZ2(this.tmpBytes) - OFFSET_MINUTE;
/*     */       
/*  93 */       str = "GMT" + ((i4 < 0) ? "-" : "+") + Math.abs(i4) + ":" + ((i5 < 10) ? "0" : "") + i5;
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 101 */     Calendar calendar = (Calendar)this.statement.getGMTCalendar().clone();
/*     */     
/* 103 */     int j = oracleYear(this.tmpBytes);
/*     */     
/* 105 */     calendar.set(1, j);
/* 106 */     calendar.set(2, oracleMonth(this.tmpBytes));
/* 107 */     calendar.set(5, oracleDay(this.tmpBytes));
/* 108 */     calendar.set(11, oracleHour(this.tmpBytes));
/* 109 */     calendar.set(12, oracleMin(this.tmpBytes));
/* 110 */     calendar.set(13, oracleSec(this.tmpBytes));
/* 111 */     calendar.set(14, 0);
/*     */     
/* 113 */     if ((oracleTZ1(this.tmpBytes) & REGIONIDBIT) != 0) {
/* 114 */       TIMEZONETAB tIMEZONETAB = this.statement.connection.getTIMEZONETAB();
/*     */ 
/*     */       
/* 117 */       int i4 = tIMEZONETAB.getOffset(calendar, i);
/*     */ 
/*     */       
/* 120 */       calendar.add(14, i4);
/*     */     } else {
/*     */       
/* 123 */       calendar.add(10, oracleTZ1(this.tmpBytes) - OFFSET_HOUR);
/* 124 */       calendar.add(12, oracleTZ2(this.tmpBytes) - OFFSET_MINUTE);
/*     */     } 
/*     */ 
/*     */     
/* 128 */     j = calendar.get(1);
/*     */     
/* 130 */     int k = calendar.get(2) + 1;
/* 131 */     int m = calendar.get(5);
/* 132 */     int n = calendar.get(11);
/* 133 */     int i1 = calendar.get(12);
/* 134 */     int i2 = calendar.get(13);
/* 135 */     boolean bool = (n < 12) ? true : false;
/* 136 */     if (str.length() > 3 && str.startsWith("GMT")) {
/* 137 */       str = str.substring(3);
/*     */     }
/*     */     
/* 140 */     int i3 = oracleNanos(this.tmpBytes);
/*     */     
/* 142 */     return toText(j, k, m, n, i1, i2, i3, bool, str);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Date getDate(int paramInt) throws SQLException {
/* 149 */     return this.tstzConverter.getDate(paramInt);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Date getDate(int paramInt, Calendar paramCalendar) throws SQLException {
/* 157 */     return getDate(paramInt);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Time getTime(int paramInt) throws SQLException {
/* 164 */     return this.tstzConverter.getTime(paramInt);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Time getTime(int paramInt, Calendar paramCalendar) throws SQLException {
/* 172 */     return getTime(paramInt);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Timestamp getTimestamp(int paramInt) throws SQLException {
/* 179 */     return this.tstzConverter.getTimestamp(paramInt);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Timestamp getTimestamp(int paramInt, Calendar paramCalendar) throws SQLException {
/* 187 */     return getTimestamp(paramInt);
/*     */   }
/*     */ 
/*     */   
/*     */   Object getObject(int paramInt) throws SQLException {
/* 192 */     return this.tstzConverter.getObject(paramInt);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   Datum getOracleObject(int paramInt) throws SQLException {
/* 198 */     return this.tstzConverter.getOracleObject(paramInt);
/*     */   }
/*     */ 
/*     */   
/*     */   DATE getDATE(int paramInt) throws SQLException {
/* 203 */     TIMESTAMPTZ tIMESTAMPTZ = this.tstzConverter.getTIMESTAMPTZ(paramInt);
/* 204 */     if (tIMESTAMPTZ == null) {
/* 205 */       return null;
/*     */     }
/* 207 */     return TIMESTAMPTZ.toDATE((Connection)this.statement.connection, tIMESTAMPTZ.getBytes());
/*     */   }
/*     */ 
/*     */   
/*     */   TIMESTAMP getTIMESTAMP(int paramInt) throws SQLException {
/* 212 */     TIMESTAMPTZ tIMESTAMPTZ = this.tstzConverter.getTIMESTAMPTZ(paramInt);
/* 213 */     if (tIMESTAMPTZ == null) {
/* 214 */       return null;
/*     */     }
/* 216 */     return TIMESTAMPTZ.toTIMESTAMP((Connection)this.statement.connection, tIMESTAMPTZ.getBytes());
/*     */   }
/*     */ 
/*     */   
/*     */   TIMESTAMPTZ getTIMESTAMPTZ(int paramInt) throws SQLException {
/* 221 */     return this.tstzConverter.getTIMESTAMPTZ(paramInt);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 227 */   static int OFFSET_HOUR = 20;
/* 228 */   static int OFFSET_MINUTE = 60;
/*     */ 
/*     */   
/* 231 */   static byte REGIONIDBIT = Byte.MIN_VALUE;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static int setHighOrderbits(int paramInt) {
/* 241 */     return (paramInt & 0x1FC0) >> 6;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static int setLowOrderbits(int paramInt) {
/* 249 */     return (paramInt & 0x3F) << 2;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static int getHighOrderbits(int paramInt) {
/* 257 */     return (paramInt & 0x7F) << 6;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static int getLowOrderbits(int paramInt) {
/* 264 */     return (paramInt & 0xFC) >> 2;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   class OldTimestampTzConverter
/*     */     extends TimestampTzConverter
/*     */   {
/*     */     Date getDate(int param1Int) throws SQLException {
/* 280 */       if (TimestamptzAccessor.this.isNull(param1Int)) return null;
/*     */       
/* 282 */       TimeZone timeZone = TimestamptzAccessor.this.statement.getDefaultTimeZone();
/* 283 */       Calendar calendar = Calendar.getInstance(timeZone);
/*     */       
/* 285 */       TimestamptzAccessor.this.getBytesInternal(param1Int, TimestamptzAccessor.this.tmpBytes);
/*     */       
/* 287 */       int i = TimestamptzAccessor.this.oracleYear(TimestamptzAccessor.this.tmpBytes);
/*     */       
/* 289 */       calendar.set(1, i);
/* 290 */       calendar.set(2, TimestamptzAccessor.this.oracleMonth(TimestamptzAccessor.this.tmpBytes));
/* 291 */       calendar.set(5, TimestamptzAccessor.this.oracleDay(TimestamptzAccessor.this.tmpBytes));
/* 292 */       calendar.set(11, TimestamptzAccessor.this.oracleHour(TimestamptzAccessor.this.tmpBytes));
/* 293 */       calendar.set(12, TimestamptzAccessor.this.oracleMin(TimestamptzAccessor.this.tmpBytes));
/* 294 */       calendar.set(13, TimestamptzAccessor.this.oracleSec(TimestamptzAccessor.this.tmpBytes));
/* 295 */       calendar.set(14, 0);
/*     */       
/* 297 */       if ((TimestamptzAccessor.this.oracleTZ1(TimestamptzAccessor.this.tmpBytes) & TimestamptzAccessor.REGIONIDBIT) != 0) {
/*     */ 
/*     */ 
/*     */         
/* 301 */         int j = TimestamptzAccessor.getHighOrderbits(TimestamptzAccessor.this.oracleTZ1(TimestamptzAccessor.this.tmpBytes));
/* 302 */         j += TimestamptzAccessor.getLowOrderbits(TimestamptzAccessor.this.oracleTZ2(TimestamptzAccessor.this.tmpBytes));
/*     */         
/* 304 */         TIMEZONETAB tIMEZONETAB = TimestamptzAccessor.this.statement.connection.getTIMEZONETAB();
/*     */         
/* 306 */         if (tIMEZONETAB.checkID(j)) {
/* 307 */           tIMEZONETAB.updateTable((Connection)TimestamptzAccessor.this.statement.connection, j);
/*     */         }
/* 309 */         int k = tIMEZONETAB.getOffset(calendar, j);
/*     */         
/* 311 */         boolean bool1 = timeZone.inDaylightTime(calendar.getTime());
/* 312 */         boolean bool2 = timeZone.inDaylightTime(new Date(calendar.getTimeInMillis() + k));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 319 */         if (!bool1 && bool2) {
/*     */           
/* 321 */           calendar.add(14, -1 * timeZone.getDSTSavings());
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         }
/* 329 */         else if (bool1 && !bool2) {
/*     */           
/* 331 */           calendar.add(14, timeZone.getDSTSavings());
/*     */         } 
/*     */ 
/*     */ 
/*     */         
/* 336 */         calendar.add(10, k / 3600000);
/* 337 */         calendar.add(12, k % 3600000 / 60000);
/*     */       }
/*     */       else {
/*     */         
/* 341 */         calendar.add(10, TimestamptzAccessor.this.oracleTZ1(TimestamptzAccessor.this.tmpBytes) - TimestamptzAccessor.OFFSET_HOUR);
/* 342 */         calendar.add(12, TimestamptzAccessor.this.oracleTZ2(TimestamptzAccessor.this.tmpBytes) - TimestamptzAccessor.OFFSET_MINUTE);
/*     */       } 
/*     */ 
/*     */       
/* 346 */       long l = calendar.getTimeInMillis();
/*     */ 
/*     */       
/* 349 */       return new Date(l);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     Time getTime(int param1Int) throws SQLException {
/* 358 */       if (TimestamptzAccessor.this.isNull(param1Int)) return null;
/*     */       
/* 360 */       TimeZone timeZone = TimestamptzAccessor.this.statement.getDefaultTimeZone();
/* 361 */       Calendar calendar = Calendar.getInstance(timeZone);
/*     */       
/* 363 */       TimestamptzAccessor.this.getBytesInternal(param1Int, TimestamptzAccessor.this.tmpBytes);
/*     */       
/* 365 */       int i = TimestamptzAccessor.this.oracleYear(TimestamptzAccessor.this.tmpBytes);
/*     */       
/* 367 */       calendar.set(1, i);
/* 368 */       calendar.set(2, TimestamptzAccessor.this.oracleMonth(TimestamptzAccessor.this.tmpBytes));
/* 369 */       calendar.set(5, TimestamptzAccessor.this.oracleDay(TimestamptzAccessor.this.tmpBytes));
/* 370 */       calendar.set(11, TimestamptzAccessor.this.oracleHour(TimestamptzAccessor.this.tmpBytes));
/* 371 */       calendar.set(12, TimestamptzAccessor.this.oracleMin(TimestamptzAccessor.this.tmpBytes));
/* 372 */       calendar.set(13, TimestamptzAccessor.this.oracleSec(TimestamptzAccessor.this.tmpBytes));
/* 373 */       calendar.set(14, 0);
/*     */       
/* 375 */       if ((TimestamptzAccessor.this.oracleTZ1(TimestamptzAccessor.this.tmpBytes) & TimestamptzAccessor.REGIONIDBIT) != 0) {
/*     */ 
/*     */ 
/*     */         
/* 379 */         int j = TimestamptzAccessor.getHighOrderbits(TimestamptzAccessor.this.oracleTZ1(TimestamptzAccessor.this.tmpBytes));
/* 380 */         j += TimestamptzAccessor.getLowOrderbits(TimestamptzAccessor.this.oracleTZ2(TimestamptzAccessor.this.tmpBytes));
/*     */         
/* 382 */         TIMEZONETAB tIMEZONETAB = TimestamptzAccessor.this.statement.connection.getTIMEZONETAB();
/*     */         
/* 384 */         if (tIMEZONETAB.checkID(j)) {
/* 385 */           tIMEZONETAB.updateTable((Connection)TimestamptzAccessor.this.statement.connection, j);
/*     */         }
/* 387 */         int k = tIMEZONETAB.getOffset(calendar, j);
/*     */         
/* 389 */         boolean bool1 = timeZone.inDaylightTime(calendar.getTime());
/* 390 */         boolean bool2 = timeZone.inDaylightTime(new Date(calendar.getTimeInMillis() + k));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 397 */         if (!bool1 && bool2) {
/*     */           
/* 399 */           calendar.add(14, -1 * timeZone.getDSTSavings());
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         }
/* 407 */         else if (bool1 && !bool2) {
/*     */           
/* 409 */           calendar.add(14, timeZone.getDSTSavings());
/*     */         } 
/*     */ 
/*     */         
/* 413 */         calendar.add(10, k / 3600000);
/* 414 */         calendar.add(12, k % 3600000 / 60000);
/*     */       }
/*     */       else {
/*     */         
/* 418 */         calendar.add(10, TimestamptzAccessor.this.oracleTZ1(TimestamptzAccessor.this.tmpBytes) - TimestamptzAccessor.OFFSET_HOUR);
/* 419 */         calendar.add(12, TimestamptzAccessor.this.oracleTZ2(TimestamptzAccessor.this.tmpBytes) - TimestamptzAccessor.OFFSET_MINUTE);
/*     */       } 
/*     */ 
/*     */       
/* 423 */       long l = calendar.getTimeInMillis();
/*     */ 
/*     */       
/* 426 */       return new Time(l);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     Timestamp getTimestamp(int param1Int) throws SQLException {
/* 436 */       if (TimestamptzAccessor.this.isNull(param1Int)) return null;
/*     */       
/* 438 */       TimeZone timeZone = TimestamptzAccessor.this.statement.getDefaultTimeZone();
/* 439 */       Calendar calendar1 = Calendar.getInstance(timeZone);
/* 440 */       Calendar calendar2 = (Calendar)TimestamptzAccessor.this.statement.getGMTCalendar().clone();
/*     */       
/* 442 */       TimestamptzAccessor.this.getBytesInternal(param1Int, TimestamptzAccessor.this.tmpBytes);
/*     */       
/* 444 */       int i = TimestamptzAccessor.this.oracleYear(TimestamptzAccessor.this.tmpBytes);
/*     */       
/* 446 */       calendar1.set(1, i);
/* 447 */       calendar1.set(2, TimestamptzAccessor.this.oracleMonth(TimestamptzAccessor.this.tmpBytes));
/* 448 */       calendar1.set(5, TimestamptzAccessor.this.oracleDay(TimestamptzAccessor.this.tmpBytes));
/* 449 */       calendar1.set(11, TimestamptzAccessor.this.oracleHour(TimestamptzAccessor.this.tmpBytes));
/* 450 */       calendar1.set(12, TimestamptzAccessor.this.oracleMin(TimestamptzAccessor.this.tmpBytes));
/* 451 */       calendar1.set(13, TimestamptzAccessor.this.oracleSec(TimestamptzAccessor.this.tmpBytes));
/* 452 */       calendar1.set(14, 0);
/*     */       
/* 454 */       calendar2.set(1, i);
/* 455 */       calendar2.set(2, TimestamptzAccessor.this.oracleMonth(TimestamptzAccessor.this.tmpBytes));
/* 456 */       calendar2.set(5, TimestamptzAccessor.this.oracleDay(TimestamptzAccessor.this.tmpBytes));
/* 457 */       calendar2.set(11, TimestamptzAccessor.this.oracleHour(TimestamptzAccessor.this.tmpBytes));
/* 458 */       calendar2.set(12, TimestamptzAccessor.this.oracleMin(TimestamptzAccessor.this.tmpBytes));
/* 459 */       calendar2.set(13, TimestamptzAccessor.this.oracleSec(TimestamptzAccessor.this.tmpBytes));
/* 460 */       calendar2.set(14, 0);
/*     */       
/* 462 */       if ((TimestamptzAccessor.this.oracleTZ1(TimestamptzAccessor.this.tmpBytes) & TimestamptzAccessor.REGIONIDBIT) != 0) {
/*     */ 
/*     */         
/* 465 */         int k = TimestamptzAccessor.getHighOrderbits(TimestamptzAccessor.this.oracleTZ1(TimestamptzAccessor.this.tmpBytes));
/* 466 */         k += TimestamptzAccessor.getLowOrderbits(TimestamptzAccessor.this.oracleTZ2(TimestamptzAccessor.this.tmpBytes));
/*     */ 
/*     */         
/* 469 */         TIMEZONETAB tIMEZONETAB = TimestamptzAccessor.this.statement.connection.getTIMEZONETAB();
/* 470 */         if (tIMEZONETAB.checkID(k)) {
/* 471 */           tIMEZONETAB.updateTable((Connection)TimestamptzAccessor.this.statement.connection, k);
/*     */         }
/*     */         
/* 474 */         int m = tIMEZONETAB.getOffset(calendar2, k);
/*     */         
/* 476 */         boolean bool1 = timeZone.inDaylightTime(calendar1.getTime());
/* 477 */         boolean bool2 = timeZone.inDaylightTime(new Date(calendar1.getTimeInMillis() + m));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 485 */         if (!bool1 && bool2) {
/*     */           
/* 487 */           calendar1.add(14, -1 * timeZone.getDSTSavings());
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         }
/* 496 */         else if (bool1 && !bool2) {
/* 497 */           calendar1.add(14, timeZone.getDSTSavings());
/*     */         } 
/*     */ 
/*     */         
/* 501 */         calendar1.add(10, m / 3600000);
/* 502 */         calendar1.add(12, m % 3600000 / 60000);
/*     */       } else {
/*     */         
/* 505 */         calendar1.add(10, TimestamptzAccessor.this.oracleTZ1(TimestamptzAccessor.this.tmpBytes) - TimestamptzAccessor.OFFSET_HOUR);
/* 506 */         calendar1.add(12, TimestamptzAccessor.this.oracleTZ2(TimestamptzAccessor.this.tmpBytes) - TimestamptzAccessor.OFFSET_MINUTE);
/*     */       } 
/*     */ 
/*     */       
/* 510 */       long l = calendar1.getTimeInMillis();
/*     */ 
/*     */       
/* 513 */       Timestamp timestamp = new Timestamp(l);
/*     */ 
/*     */       
/* 516 */       int j = TimestamptzAccessor.this.oracleNanos(TimestamptzAccessor.this.tmpBytes);
/*     */ 
/*     */       
/* 519 */       timestamp.setNanos(j);
/*     */       
/* 521 */       return timestamp;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     TIMESTAMPTZ getTIMESTAMPTZ(int param1Int) throws SQLException {
/* 531 */       if (TimestamptzAccessor.this.isNull(param1Int)) return null; 
/* 532 */       return new TIMESTAMPTZ(TimestamptzAccessor.this.getBytesInternal(param1Int));
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   class GmtTimestampTzConverter
/*     */     extends TimestampTzConverter
/*     */   {
/*     */     Date getDate(int param1Int) throws SQLException {
/* 552 */       if (TimestamptzAccessor.this.isNull(param1Int)) {
/* 553 */         return null;
/*     */       }
/*     */       
/* 556 */       Calendar calendar = (Calendar)TimestamptzAccessor.this.statement.getGMTCalendar().clone();
/* 557 */       TimestamptzAccessor.this.getBytesInternal(param1Int, TimestamptzAccessor.this.tmpBytes);
/*     */       
/* 559 */       int i = TimestamptzAccessor.this.oracleYear(TimestamptzAccessor.this.tmpBytes);
/*     */       
/* 561 */       calendar.set(1, i);
/* 562 */       calendar.set(2, TimestamptzAccessor.this.oracleMonth(TimestamptzAccessor.this.tmpBytes));
/* 563 */       calendar.set(5, TimestamptzAccessor.this.oracleDay(TimestamptzAccessor.this.tmpBytes));
/* 564 */       calendar.set(11, TimestamptzAccessor.this.oracleHour(TimestamptzAccessor.this.tmpBytes));
/* 565 */       calendar.set(12, TimestamptzAccessor.this.oracleMin(TimestamptzAccessor.this.tmpBytes));
/* 566 */       calendar.set(13, TimestamptzAccessor.this.oracleSec(TimestamptzAccessor.this.tmpBytes));
/* 567 */       calendar.set(14, 0);
/*     */ 
/*     */       
/* 570 */       long l = calendar.getTimeInMillis();
/*     */ 
/*     */       
/* 573 */       return new Date(l);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     Time getTime(int param1Int) throws SQLException {
/* 583 */       if (TimestamptzAccessor.this.isNull(param1Int)) {
/* 584 */         return null;
/*     */       }
/*     */       
/* 587 */       Calendar calendar = (Calendar)TimestamptzAccessor.this.statement.getGMTCalendar().clone();
/* 588 */       TimestamptzAccessor.this.getBytesInternal(param1Int, TimestamptzAccessor.this.tmpBytes);
/*     */       
/* 590 */       int i = TimestamptzAccessor.this.oracleYear(TimestamptzAccessor.this.tmpBytes);
/*     */       
/* 592 */       calendar.set(1, i);
/* 593 */       calendar.set(2, TimestamptzAccessor.this.oracleMonth(TimestamptzAccessor.this.tmpBytes));
/* 594 */       calendar.set(5, TimestamptzAccessor.this.oracleDay(TimestamptzAccessor.this.tmpBytes));
/* 595 */       calendar.set(11, TimestamptzAccessor.this.oracleHour(TimestamptzAccessor.this.tmpBytes));
/* 596 */       calendar.set(12, TimestamptzAccessor.this.oracleMin(TimestamptzAccessor.this.tmpBytes));
/* 597 */       calendar.set(13, TimestamptzAccessor.this.oracleSec(TimestamptzAccessor.this.tmpBytes));
/* 598 */       calendar.set(14, 0);
/*     */       
/* 600 */       return new Time(calendar.getTimeInMillis());
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     Timestamp getTimestamp(int param1Int) throws SQLException {
/* 610 */       if (TimestamptzAccessor.this.isNull(param1Int)) {
/* 611 */         return null;
/*     */       }
/*     */       
/* 614 */       Calendar calendar = (Calendar)TimestamptzAccessor.this.statement.getGMTCalendar().clone();
/* 615 */       TimestamptzAccessor.this.getBytesInternal(param1Int, TimestamptzAccessor.this.tmpBytes);
/*     */       
/* 617 */       int i = TimestamptzAccessor.this.oracleYear(TimestamptzAccessor.this.tmpBytes);
/*     */       
/* 619 */       calendar.set(1, i);
/* 620 */       calendar.set(2, TimestamptzAccessor.this.oracleMonth(TimestamptzAccessor.this.tmpBytes));
/* 621 */       calendar.set(5, TimestamptzAccessor.this.oracleDay(TimestamptzAccessor.this.tmpBytes));
/* 622 */       calendar.set(11, TimestamptzAccessor.this.oracleHour(TimestamptzAccessor.this.tmpBytes));
/* 623 */       calendar.set(12, TimestamptzAccessor.this.oracleMin(TimestamptzAccessor.this.tmpBytes));
/* 624 */       calendar.set(13, TimestamptzAccessor.this.oracleSec(TimestamptzAccessor.this.tmpBytes));
/* 625 */       calendar.set(14, 0);
/*     */ 
/*     */       
/* 628 */       long l = calendar.getTimeInMillis();
/*     */ 
/*     */       
/* 631 */       Timestamp timestamp = new Timestamp(l);
/*     */ 
/*     */       
/* 634 */       int j = TimestamptzAccessor.this.oracleNanos(TimestamptzAccessor.this.tmpBytes);
/*     */ 
/*     */       
/* 637 */       timestamp.setNanos(j);
/*     */       
/* 639 */       return timestamp;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     TIMESTAMPTZ getTIMESTAMPTZ(int param1Int) throws SQLException {
/* 648 */       if (TimestamptzAccessor.this.isNull(param1Int)) return null; 
/* 649 */       return new TIMESTAMPTZ(TimestamptzAccessor.this.getBytesInternal(param1Int));
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   abstract class TimestampTzConverter
/*     */   {
/*     */     abstract Date getDate(int param1Int) throws SQLException;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     abstract Time getTime(int param1Int) throws SQLException;
/*     */ 
/*     */ 
/*     */     
/*     */     abstract Timestamp getTimestamp(int param1Int) throws SQLException;
/*     */ 
/*     */ 
/*     */     
/*     */     Object getObject(int param1Int) throws SQLException {
/* 672 */       return getTIMESTAMPTZ(param1Int);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     Datum getOracleObject(int param1Int) throws SQLException {
/* 680 */       return (Datum)getTIMESTAMPTZ(param1Int);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     Object getObject(int param1Int, Map param1Map) throws SQLException {
/* 688 */       return getTIMESTAMPTZ(param1Int);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     abstract TIMESTAMPTZ getTIMESTAMPTZ(int param1Int) throws SQLException;
/*     */   }
/*     */ 
/*     */   
/* 697 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*     */   public static final String BUILD_DATE = "Thu_Apr_04_15:09:24_PDT_2013";
/*     */   public static final boolean TRACE = false;
/*     */ }


/* Location:              C:\Users\olatu\OneDrive\Documents\Calypso\syncbase\sync_base.jar!\BOOT-INF\classes\ojdbc.jar!\oracle\jdbc\driver\TimestamptzAccessor.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */