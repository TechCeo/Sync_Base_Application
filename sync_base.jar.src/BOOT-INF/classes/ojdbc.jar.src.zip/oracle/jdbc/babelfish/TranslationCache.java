/*     */ package oracle.jdbc.babelfish;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.sql.SQLException;
/*     */ import java.util.Map;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import javax.xml.parsers.DocumentBuilder;
/*     */ import javax.xml.parsers.DocumentBuilderFactory;
/*     */ import javax.xml.parsers.ParserConfigurationException;
/*     */ import oracle.jdbc.driver.DatabaseError;
/*     */ import oracle.jdbc.internal.OracleConnection;
/*     */ import org.w3c.dom.Document;
/*     */ import org.w3c.dom.Element;
/*     */ import org.w3c.dom.Node;
/*     */ import org.w3c.dom.NodeList;
/*     */ import org.xml.sax.SAXException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class TranslationCache
/*     */ {
/*  83 */   private Map<String, String> queryCache = new ConcurrentHashMap<>();
/*  84 */   private Map<Integer, TranslatedErrorInfo> errorCache = new ConcurrentHashMap<>();
/*     */   TranslationCache(File paramFile) throws SQLException {
/*  86 */     if (paramFile != null) {
/*     */       
/*  88 */       this.localErrorCache = new ConcurrentHashMap<>();
/*  89 */       readLocalErrorFile(paramFile);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Map<Integer, TranslatedErrorInfo> localErrorCache;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void readLocalErrorFile(File paramFile) throws SQLException {
/*     */     try {
/* 114 */       DocumentBuilderFactory documentBuilderFactory = DocumentBuilderFactory.newInstance();
/* 115 */       documentBuilderFactory.setValidating(true);
/* 116 */       DocumentBuilder documentBuilder = documentBuilderFactory.newDocumentBuilder();
/* 117 */       Document document = documentBuilder.parse(paramFile);
/*     */       
/* 119 */       int i = 0;
/* 120 */       TranslatedErrorInfo translatedErrorInfo = null;
/* 121 */       NodeList nodeList = document.getElementsByTagName("Exception");
/*     */       
/* 123 */       for (byte b = 0; b < nodeList.getLength(); b++) {
/*     */         
/* 125 */         translatedErrorInfo = new TranslatedErrorInfo();
/* 126 */         Node node = nodeList.item(b);
/* 127 */         NodeList nodeList1 = node.getChildNodes();
/*     */         
/* 129 */         for (byte b1 = 0; b1 < nodeList1.getLength(); b1++) {
/*     */           
/* 131 */           if (nodeList1.item(b1).getNodeType() == 1) {
/*     */ 
/*     */ 
/*     */             
/* 135 */             Element element = (Element)nodeList1.item(b1);
/*     */             
/* 137 */             if (element.getTagName().equals("ORAError")) {
/*     */               
/* 139 */               i = Integer.parseInt(element.getFirstChild().getNodeValue());
/*     */             }
/* 141 */             else if (element.getTagName().equals("ErrorCode")) {
/*     */               
/* 143 */               translatedErrorInfo.setErrorCode(Integer.parseInt(element.getFirstChild().getNodeValue()));
/*     */             }
/* 145 */             else if (element.getTagName().equals("SQLState")) {
/*     */               
/* 147 */               translatedErrorInfo.setSqlState(element.getFirstChild().getNodeValue());
/*     */             } 
/*     */           } 
/*     */         } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 156 */         this.localErrorCache.put(Integer.valueOf(i), translatedErrorInfo);
/* 157 */         i = 0;
/*     */       } 
/* 159 */     } catch (IOException iOException) {
/*     */ 
/*     */       
/* 162 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 277);
/* 163 */       sQLException.fillInStackTrace();
/* 164 */       throw sQLException;
/*     */     }
/* 166 */     catch (SAXException sAXException) {
/*     */ 
/*     */       
/* 169 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 278);
/* 170 */       sQLException.fillInStackTrace();
/* 171 */       throw sQLException;
/*     */     
/*     */     }
/* 174 */     catch (ParserConfigurationException parserConfigurationException) {
/*     */ 
/*     */       
/* 177 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 278);
/* 178 */       sQLException.fillInStackTrace();
/* 179 */       throw sQLException;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Map<String, String> getQueryCache() {
/* 191 */     return this.queryCache;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Map<Integer, TranslatedErrorInfo> getErrorCache() {
/* 201 */     return this.errorCache;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Map<Integer, TranslatedErrorInfo> getLocalErrorCache() {
/* 211 */     return this.localErrorCache;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected OracleConnection getConnectionDuringExceptionHandling() {
/* 227 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/* 232 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*     */   public static final String BUILD_DATE = "Thu_Apr_04_15:09:24_PDT_2013";
/*     */   public static final boolean TRACE = false;
/*     */ }


/* Location:              C:\Users\olatu\OneDrive\Documents\Calypso\syncbase\sync_base.jar!\BOOT-INF\classes\ojdbc.jar!\oracle\jdbc\babelfish\TranslationCache.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */