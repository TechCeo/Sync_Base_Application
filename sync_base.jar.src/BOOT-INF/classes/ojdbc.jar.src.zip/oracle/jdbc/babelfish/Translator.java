/*     */ package oracle.jdbc.babelfish;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.sql.CallableStatement;
/*     */ import java.sql.Connection;
/*     */ import java.sql.SQLException;
/*     */ import java.util.Map;
/*     */ import oracle.jdbc.driver.DatabaseError;
/*     */ import oracle.jdbc.internal.OracleConnection;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Translator
/*     */ {
/*     */   private final File localErrorTranslationFile;
/*     */   private final String translationProfile;
/*     */   private Connection conn;
/*     */   private CallableStatement queryTranslationStatement;
/*     */   private CallableStatement errorTranslationStatement;
/*     */   private final Map<String, String> queryCache;
/*     */   private final Map<Integer, TranslatedErrorInfo> errorCache;
/*     */   private final Map<Integer, TranslatedErrorInfo> localErrorCache;
/*     */   
/*     */   Translator(String paramString, File paramFile, TranslationCache paramTranslationCache) throws SQLException {
/*  85 */     this.translationProfile = paramString;
/*  86 */     this.localErrorTranslationFile = paramFile;
/*     */     
/*  88 */     this.queryCache = paramTranslationCache.getQueryCache();
/*  89 */     this.errorCache = paramTranslationCache.getErrorCache();
/*  90 */     this.localErrorCache = paramTranslationCache.getLocalErrorCache();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SQLException translateError(SQLException paramSQLException) throws SQLException {
/* 106 */     if (this.conn == null)
/*     */     {
/* 108 */       return translateErrorLocal(paramSQLException);
/*     */     }
/*     */ 
/*     */     
/* 112 */     TranslatedErrorInfo translatedErrorInfo = this.errorCache.get(Integer.valueOf(paramSQLException.getErrorCode()));
/*     */     
/* 114 */     if (translatedErrorInfo != null) {
/*     */       
/* 116 */       SQLException sQLException1 = new SQLException("[Translated Error Codes] " + paramSQLException.getMessage(), translatedErrorInfo.getSqlState(), translatedErrorInfo.getErrorCode(), paramSQLException);
/* 117 */       sQLException1.setStackTrace(paramSQLException.getStackTrace());
/* 118 */       return sQLException1;
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/* 124 */       this.errorTranslationStatement.clearParameters();
/* 125 */       this.errorTranslationStatement.setInt(1, paramSQLException.getErrorCode());
/* 126 */       this.errorTranslationStatement.registerOutParameter(2, 4);
/* 127 */       this.errorTranslationStatement.registerOutParameter(3, 12);
/* 128 */       this.errorTranslationStatement.execute();
/*     */       
/* 130 */       int i = this.errorTranslationStatement.getInt(2);
/* 131 */       if (this.errorTranslationStatement.wasNull())
/*     */       {
/* 133 */         i = paramSQLException.getErrorCode();
/*     */       }
/*     */       
/* 136 */       String str = this.errorTranslationStatement.getString(3);
/* 137 */       if (str == null)
/*     */       {
/* 139 */         str = paramSQLException.getSQLState();
/*     */       }
/* 141 */       translatedErrorInfo = new TranslatedErrorInfo(i, str);
/*     */     }
/* 143 */     catch (SQLException sQLException1) {
/*     */ 
/*     */       
/* 146 */       SQLException sQLException2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 280, null, sQLException1);
/* 147 */       sQLException2.fillInStackTrace();
/* 148 */       throw sQLException2;
/*     */     } 
/*     */     
/* 151 */     this.errorCache.put(Integer.valueOf(paramSQLException.getErrorCode()), translatedErrorInfo);
/*     */     
/* 153 */     SQLException sQLException = new SQLException("[Translated Error Codes] " + paramSQLException.getMessage(), translatedErrorInfo.getSqlState(), translatedErrorInfo.getErrorCode(), paramSQLException);
/*     */     
/* 155 */     sQLException.setStackTrace(paramSQLException.getStackTrace());
/* 156 */     return sQLException;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   SQLException translateErrorLocal(SQLException paramSQLException) throws SQLException {
/* 172 */     if (this.localErrorCache == null)
/*     */     {
/*     */       
/* 175 */       return paramSQLException;
/*     */     }
/*     */ 
/*     */     
/* 179 */     TranslatedErrorInfo translatedErrorInfo = this.localErrorCache.get(Integer.valueOf(paramSQLException.getErrorCode()));
/* 180 */     if (translatedErrorInfo != null) {
/*     */       
/* 182 */       String str = "[Translated Error Codes] " + paramSQLException.getMessage();
/*     */       
/* 184 */       SQLException sQLException1 = new SQLException(str, translatedErrorInfo.getSqlState(), translatedErrorInfo.getErrorCode(), paramSQLException);
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 189 */       sQLException1.setStackTrace(paramSQLException.getStackTrace());
/* 190 */       return sQLException1;
/*     */     } 
/*     */ 
/*     */     
/* 194 */     SQLException sQLException = new SQLException("[Error Translation Not Available] " + paramSQLException.getMessage(), paramSQLException.getSQLState(), paramSQLException.getErrorCode(), paramSQLException);
/*     */ 
/*     */ 
/*     */     
/* 198 */     sQLException.setStackTrace(paramSQLException.getStackTrace());
/* 199 */     return sQLException;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   String translateQuery(String paramString) throws SQLException {
/* 215 */     if (this.conn != null) {
/*     */       
/* 217 */       String str1 = this.queryCache.get(paramString);
/* 218 */       if (str1 != null)
/*     */       {
/* 220 */         return str1;
/*     */       }
/*     */ 
/*     */       
/* 224 */       String str2 = convertParameterMarkersToOracleStyle(paramString);
/*     */       
/*     */       try {
/* 227 */         this.queryTranslationStatement.clearParameters();
/* 228 */         this.queryTranslationStatement.setString(1, str2);
/* 229 */         this.queryTranslationStatement.registerOutParameter(2, 12);
/*     */         
/* 231 */         this.queryTranslationStatement.execute();
/* 232 */         str1 = this.queryTranslationStatement.getString(2);
/*     */       
/*     */       }
/* 235 */       catch (SQLException sQLException1) {
/*     */ 
/*     */         
/* 238 */         SQLException sQLException2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 280, null, sQLException1);
/* 239 */         sQLException2.fillInStackTrace();
/* 240 */         throw sQLException2;
/*     */       } 
/*     */ 
/*     */       
/* 244 */       if (str1 == null)
/*     */       {
/* 246 */         str1 = str2;
/*     */       }
/* 248 */       this.queryCache.put(paramString, str1);
/* 249 */       return str1;
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 255 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 279);
/* 256 */     sQLException.fillInStackTrace();
/* 257 */     throw sQLException;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void activateServerTranslation(Connection paramConnection) throws SQLException {
/* 279 */     CallableStatement callableStatement = paramConnection.prepareCall("begin execute immediate 'alter session set sql_translation_profile = ' || dbms_assert.qualified_sql_name(?); end;");
/* 280 */     callableStatement.setString(1, this.translationProfile);
/* 281 */     callableStatement.execute();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 288 */     this.queryTranslationStatement = paramConnection.prepareCall("begin dbms_sql_translator.translate_sql(?, ? ); end;");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 296 */     this.errorTranslationStatement = paramConnection.prepareCall("begin dbms_sql_translator.translate_error(?, ?, ? ); end;");
/*     */     
/* 298 */     this.conn = paramConnection;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void deactivateServerTranslation() throws SQLException {
/* 305 */     this.queryTranslationStatement.close();
/* 306 */     this.errorTranslationStatement.close();
/* 307 */     this.conn = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   String convertParameterMarkersToOracleStyle(String paramString) {
/* 327 */     StringBuilder stringBuilder = new StringBuilder();
/*     */     
/* 329 */     boolean bool = false;
/* 330 */     byte b1 = 1;
/* 331 */     for (byte b2 = 0; b2 < paramString.length(); b2++) {
/*     */       
/* 333 */       char c = paramString.charAt(b2);
/* 334 */       switch (c) {
/*     */ 
/*     */         
/*     */         case '\\':
/* 338 */           stringBuilder.append(c);
/* 339 */           if (b2 < paramString.length() - 1)
/*     */           {
/* 341 */             stringBuilder.append(paramString.charAt(++b2));
/*     */           }
/*     */           break;
/*     */         
/*     */         case '?':
/* 346 */           if (!bool)
/*     */           {
/* 348 */             stringBuilder.append(" :").append(BabelfishPreparedStatement.NAMED_PARAMETER_PREFIX).append(b1++).append(" ");
/*     */           }
/*     */           break;
/*     */         
/*     */         case '\'':
/* 353 */           bool = bool ? false : true;
/*     */         default:
/* 355 */           stringBuilder.append(c); break;
/*     */       } 
/*     */     } 
/* 358 */     return stringBuilder.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected OracleConnection getConnectionDuringExceptionHandling() {
/* 374 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/* 379 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*     */   public static final String BUILD_DATE = "Thu_Apr_04_15:09:24_PDT_2013";
/*     */   public static final boolean TRACE = false;
/*     */ }


/* Location:              C:\Users\olatu\OneDrive\Documents\Calypso\syncbase\sync_base.jar!\BOOT-INF\classes\ojdbc.jar!\oracle\jdbc\babelfish\Translator.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */