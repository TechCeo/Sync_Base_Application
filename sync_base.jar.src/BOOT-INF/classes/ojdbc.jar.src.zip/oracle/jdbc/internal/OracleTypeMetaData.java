package oracle.jdbc.internal;

import oracle.jdbc.OracleTypeMetaData;

public interface OracleTypeMetaData extends OracleTypeMetaData, ACProxyable {
  public static interface Struct extends OracleTypeMetaData, OracleTypeMetaData.Struct {}
  
  public static interface Opaque extends OracleTypeMetaData, OracleTypeMetaData.Opaque {}
  
  public static interface Array extends OracleTypeMetaData, OracleTypeMetaData.Array {}
}


/* Location:              C:\Users\olatu\OneDrive\Documents\Calypso\syncbase\sync_base.jar!\BOOT-INF\classes\ojdbc.jar!\oracle\jdbc\internal\OracleTypeMetaData.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */