/*    */ package oracle.jdbc.internal;
/*    */ 
/*    */ import java.sql.SQLException;
/*    */ import oracle.jdbc.driver.InternalFactory;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class JMSFactory
/*    */ {
/*    */   public static JMSMessage createJMSMessage(JMSMessageProperties paramJMSMessageProperties) throws SQLException {
/* 40 */     return (JMSMessage)InternalFactory.createJMSMessage(paramJMSMessageProperties);
/*    */   }
/*    */   
/*    */   public static JMSMessageProperties createJMSMessageProperties() throws SQLException {
/* 44 */     return (JMSMessageProperties)InternalFactory.createJMSMessageProperties();
/*    */   }
/*    */ }


/* Location:              C:\Users\olatu\OneDrive\Documents\Calypso\syncbase\sync_base.jar!\BOOT-INF\classes\ojdbc.jar!\oracle\jdbc\internal\JMSFactory.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */