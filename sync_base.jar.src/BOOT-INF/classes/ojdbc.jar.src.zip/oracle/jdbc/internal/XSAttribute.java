/*    */ package oracle.jdbc.internal;
/*    */ 
/*    */ import java.sql.SQLException;
/*    */ import oracle.jdbc.driver.InternalFactory;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class XSAttribute
/*    */ {
/*    */   public static final XSAttribute constructXSAttribute() throws SQLException {
/* 44 */     return (XSAttribute)InternalFactory.createXSAttribute();
/*    */   }
/*    */   
/*    */   public abstract void setAttributeName(String paramString) throws SQLException;
/*    */   
/*    */   public abstract void setAttributeValue(String paramString) throws SQLException;
/*    */   
/*    */   public abstract void setAttributeDefaultValue(String paramString) throws SQLException;
/*    */   
/*    */   public abstract void setFlag(long paramLong) throws SQLException;
/*    */   
/*    */   public abstract String getAttributeName();
/*    */   
/*    */   public abstract String getAttributeValue();
/*    */   
/*    */   public abstract String getAttributeDefaultValue();
/*    */   
/*    */   public abstract long getFlag();
/*    */ }


/* Location:              C:\Users\olatu\OneDrive\Documents\Calypso\syncbase\sync_base.jar!\BOOT-INF\classes\ojdbc.jar!\oracle\jdbc\internal\XSAttribute.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */