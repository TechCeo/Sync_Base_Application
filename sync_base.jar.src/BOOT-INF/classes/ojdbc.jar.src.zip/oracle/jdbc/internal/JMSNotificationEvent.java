/*    */ package oracle.jdbc.internal;
/*    */ 
/*    */ import java.sql.SQLException;
/*    */ import java.util.EventObject;
/*    */ import oracle.jdbc.aq.AQMessageProperties;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class JMSNotificationEvent
/*    */   extends EventObject
/*    */ {
/*    */   protected JMSNotificationEvent(Object paramObject) {
/* 35 */     super(paramObject);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 87 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*    */   public static final String BUILD_DATE = "Thu_Apr_04_15:09:24_PDT_2013";
/*    */   public static final boolean TRACE = false;
/*    */   
/*    */   public abstract JMSMessageProperties getJMSMessageProperties() throws SQLException;
/*    */   
/*    */   public abstract AQMessageProperties getMessageProperties() throws SQLException;
/*    */   
/*    */   public abstract String getRegistrationName() throws SQLException;
/*    */   
/*    */   public abstract byte[] getPayload() throws SQLException;
/*    */   
/*    */   public abstract String getQueueName() throws SQLException;
/*    */   
/*    */   public abstract byte[] getMessageId() throws SQLException;
/*    */   
/*    */   public abstract String getConsumerName() throws SQLException;
/*    */ }


/* Location:              C:\Users\olatu\OneDrive\Documents\Calypso\syncbase\sync_base.jar!\BOOT-INF\classes\ojdbc.jar!\oracle\jdbc\internal\JMSNotificationEvent.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */