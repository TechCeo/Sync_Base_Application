/*    */ package oracle.jdbc.internal;
/*    */ 
/*    */ import java.sql.SQLException;
/*    */ import oracle.jdbc.driver.InternalFactory;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class KeywordValue
/*    */ {
/*    */   public abstract int getKeyword() throws SQLException;
/*    */   
/*    */   public abstract byte[] getBinaryValue() throws SQLException;
/*    */   
/*    */   public abstract String getTextValue() throws SQLException;
/*    */   
/*    */   public static final KeywordValue constructKeywordValue(int paramInt, String paramString) throws SQLException {
/* 50 */     return (KeywordValue)InternalFactory.createKeywordValue(paramInt, paramString, null);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static final KeywordValue constructKeywordValue(int paramInt, byte[] paramArrayOfbyte) throws SQLException {
/* 62 */     return (KeywordValue)InternalFactory.createKeywordValue(paramInt, null, paramArrayOfbyte);
/*    */   }
/*    */ }


/* Location:              C:\Users\olatu\OneDrive\Documents\Calypso\syncbase\sync_base.jar!\BOOT-INF\classes\ojdbc.jar!\oracle\jdbc\internal\KeywordValue.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */