/*    */ package oracle.jdbc.internal;
/*    */ 
/*    */ import java.sql.SQLException;
/*    */ import oracle.jdbc.driver.InternalFactory;
/*    */ import oracle.sql.TIMESTAMPTZ;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class XSSessionNamespace
/*    */ {
/*    */   public static final XSSessionNamespace constructXSSessionNamespace() throws SQLException {
/* 39 */     return (XSSessionNamespace)InternalFactory.createXSSessionNamespace();
/*    */   }
/*    */   
/*    */   public abstract XSPrincipal getPrincipal();
/*    */   
/*    */   public abstract String getTenant();
/*    */   
/*    */   public abstract byte[] getSessionId();
/*    */   
/*    */   public abstract byte[] getCookie();
/*    */   
/*    */   public abstract long getProxyId();
/*    */   
/*    */   public abstract long getACLId();
/*    */   
/*    */   public abstract long getCreatedBy();
/*    */   
/*    */   public abstract long getUpdatedBy();
/*    */   
/*    */   public abstract TIMESTAMPTZ getCreateTimestamp();
/*    */   
/*    */   public abstract TIMESTAMPTZ getAccessTimestamp();
/*    */   
/*    */   public abstract TIMESTAMPTZ getAuthTimestamp();
/*    */   
/*    */   public abstract int getTimeout();
/*    */ }


/* Location:              C:\Users\olatu\OneDrive\Documents\Calypso\syncbase\sync_base.jar!\BOOT-INF\classes\ojdbc.jar!\oracle\jdbc\internal\XSSessionNamespace.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */