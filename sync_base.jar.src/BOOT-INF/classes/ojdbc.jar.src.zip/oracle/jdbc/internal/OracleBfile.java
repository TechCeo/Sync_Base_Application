package oracle.jdbc.internal;

import java.io.InputStream;
import java.io.Reader;
import java.sql.Connection;
import java.sql.SQLException;
import oracle.jdbc.OracleBfile;
import oracle.sql.BFILE;
import oracle.sql.BfileDBAccess;

public interface OracleBfile extends OracleDatumWithConnection, OracleBfile, ACProxyable {
  long position(BFILE paramBFILE, long paramLong) throws SQLException;
  
  byte[] getLocator();
  
  void setLocator(byte[] paramArrayOfbyte);
  
  Object toJdbc() throws SQLException;
  
  boolean isConvertibleTo(Class paramClass);
  
  Reader characterStreamValue() throws SQLException;
  
  InputStream asciiStreamValue() throws SQLException;
  
  InputStream binaryStreamValue() throws SQLException;
  
  Object makeJdbcArray(int paramInt);
  
  BfileDBAccess getDBAccess() throws SQLException;
  
  void setLength(long paramLong);
  
  Connection getJavaSqlConnection() throws SQLException;
}


/* Location:              C:\Users\olatu\OneDrive\Documents\Calypso\syncbase\sync_base.jar!\BOOT-INF\classes\ojdbc.jar!\oracle\jdbc\internal\OracleBfile.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */