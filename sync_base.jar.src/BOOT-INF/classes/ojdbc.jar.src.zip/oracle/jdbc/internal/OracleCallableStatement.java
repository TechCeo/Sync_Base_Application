package oracle.jdbc.internal;

import java.io.InputStream;
import java.io.Reader;
import java.math.BigDecimal;
import java.sql.SQLException;
import oracle.jdbc.OracleCallableStatement;

public interface OracleCallableStatement extends OracleCallableStatement, OraclePreparedStatement, ACProxyable {
  byte[] privateGetBytes(int paramInt) throws SQLException;
  
  BigDecimal getBigDecimal(String paramString, int paramInt) throws SQLException;
  
  InputStream getAsciiStream(String paramString) throws SQLException;
  
  Reader getCharacterStream(String paramString) throws SQLException;
}


/* Location:              C:\Users\olatu\OneDrive\Documents\Calypso\syncbase\sync_base.jar!\BOOT-INF\classes\ojdbc.jar!\oracle\jdbc\internal\OracleCallableStatement.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */