/*    */ package oracle.jdbc.internal;
/*    */ 
/*    */ import java.util.EventObject;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class XSEvent
/*    */   extends EventObject
/*    */ {
/*    */   protected XSEvent(Object paramObject) {
/* 37 */     super(paramObject);
/*    */   }
/*    */   
/*    */   public abstract XSNamespace[] getNamespaces();
/*    */   
/*    */   public abstract XSNamespace[] getInvalidNamespaces();
/*    */   
/*    */   public abstract XSPrincipal[] getSessionRoles();
/*    */   
/*    */   public abstract XSSessionNamespace[] getSessionNamespaces();
/*    */   
/*    */   public abstract int getRoleVersion();
/*    */   
/*    */   public abstract long getSessionFlags();
/*    */   
/*    */   public abstract long getCacheFlags();
/*    */   
/*    */   public abstract XSKeyval getKeyval();
/*    */ }


/* Location:              C:\Users\olatu\OneDrive\Documents\Calypso\syncbase\sync_base.jar!\BOOT-INF\classes\ojdbc.jar!\oracle\jdbc\internal\XSEvent.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */