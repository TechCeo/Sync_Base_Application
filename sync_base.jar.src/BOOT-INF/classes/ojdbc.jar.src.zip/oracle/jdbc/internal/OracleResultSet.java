package oracle.jdbc.internal;

import java.sql.SQLException;
import oracle.jdbc.OracleResultSet;

public interface OracleResultSet extends OracleResultSet, ACProxyable {
  void closeStatementOnClose() throws SQLException;
}


/* Location:              C:\Users\olatu\OneDrive\Documents\Calypso\syncbase\sync_base.jar!\BOOT-INF\classes\ojdbc.jar!\oracle\jdbc\internal\OracleResultSet.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */