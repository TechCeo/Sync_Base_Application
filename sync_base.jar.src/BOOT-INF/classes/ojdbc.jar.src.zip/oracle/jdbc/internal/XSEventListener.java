package oracle.jdbc.internal;

import java.util.EventListener;

public interface XSEventListener extends EventListener {
  void onXSEvent(XSEvent paramXSEvent);
}


/* Location:              C:\Users\olatu\OneDrive\Documents\Calypso\syncbase\sync_base.jar!\BOOT-INF\classes\ojdbc.jar!\oracle\jdbc\internal\XSEventListener.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */