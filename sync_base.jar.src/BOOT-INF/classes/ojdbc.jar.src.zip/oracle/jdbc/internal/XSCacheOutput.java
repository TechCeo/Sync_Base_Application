package oracle.jdbc.internal;

public interface XSCacheOutput {}


/* Location:              C:\Users\olatu\OneDrive\Documents\Calypso\syncbase\sync_base.jar!\BOOT-INF\classes\ojdbc.jar!\oracle\jdbc\internal\XSCacheOutput.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */