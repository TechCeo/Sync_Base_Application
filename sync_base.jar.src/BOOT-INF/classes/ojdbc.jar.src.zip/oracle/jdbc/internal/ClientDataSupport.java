package oracle.jdbc.internal;

public interface ClientDataSupport {
  Object getClientData(Object paramObject);
  
  Object setClientData(Object paramObject1, Object paramObject2);
  
  Object removeClientData(Object paramObject);
}


/* Location:              C:\Users\olatu\OneDrive\Documents\Calypso\syncbase\sync_base.jar!\BOOT-INF\classes\ojdbc.jar!\oracle\jdbc\internal\ClientDataSupport.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */