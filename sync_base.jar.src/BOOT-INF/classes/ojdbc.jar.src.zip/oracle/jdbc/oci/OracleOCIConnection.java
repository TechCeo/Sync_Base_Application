/*    */ package oracle.jdbc.oci;
/*    */ 
/*    */ import java.sql.SQLException;
/*    */ import java.util.Properties;
/*    */ import oracle.jdbc.driver.OracleOCIConnection;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class OracleOCIConnection
/*    */   extends OracleOCIConnection
/*    */ {
/*    */   public OracleOCIConnection(String paramString, Properties paramProperties, Object paramObject) throws SQLException {
/* 33 */     super(paramString, paramProperties, paramObject);
/*    */   }
/*    */ }


/* Location:              C:\Users\olatu\OneDrive\Documents\Calypso\syncbase\sync_base.jar!\BOOT-INF\classes\ojdbc.jar!\oracle\jdbc\oci\OracleOCIConnection.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */