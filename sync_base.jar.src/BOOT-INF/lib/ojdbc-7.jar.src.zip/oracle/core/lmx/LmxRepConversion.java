/*     */ package oracle.core.lmx;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LmxRepConversion
/*     */ {
/*     */   public static void printInHex(byte paramByte) {
/*  26 */     System.out.print((char)nibbleToHex((byte)((paramByte & 0xF0) >> 4)));
/*  27 */     System.out.print((char)nibbleToHex((byte)(paramByte & 0xF)));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static byte nibbleToHex(byte paramByte) {
/*  41 */     paramByte = (byte)(paramByte & 0xF);
/*  42 */     return (byte)((paramByte < 10) ? (paramByte + 48) : (paramByte - 10 + 65));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static byte asciiHexToNibble(byte paramByte) {
/*     */     byte b;
/*  62 */     if (paramByte >= 97 && paramByte <= 102) {
/*  63 */       b = (byte)(paramByte - 97 + 10);
/*     */     }
/*  65 */     else if (paramByte >= 65 && paramByte <= 70) {
/*  66 */       b = (byte)(paramByte - 65 + 10);
/*     */     }
/*  68 */     else if (paramByte >= 48 && paramByte <= 57) {
/*  69 */       b = (byte)(paramByte - 48);
/*     */     } else {
/*     */       
/*  72 */       b = paramByte;
/*     */     } 
/*  74 */     return b;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void bArray2nibbles(byte[] paramArrayOfbyte1, byte[] paramArrayOfbyte2) {
/*  86 */     for (byte b = 0; b < paramArrayOfbyte1.length; b++) {
/*     */       
/*  88 */       paramArrayOfbyte2[b * 2] = nibbleToHex((byte)((paramArrayOfbyte1[b] & 0xF0) >> 4));
/*  89 */       paramArrayOfbyte2[b * 2 + 1] = nibbleToHex((byte)(paramArrayOfbyte1[b] & 0xF));
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String bArray2String(byte[] paramArrayOfbyte) {
/* 102 */     StringBuffer stringBuffer = new StringBuffer(paramArrayOfbyte.length * 2);
/* 103 */     for (byte b = 0; b < paramArrayOfbyte.length; b++) {
/*     */       
/* 105 */       stringBuffer.append((char)nibbleToHex((byte)((paramArrayOfbyte[b] & 0xF0) >> 4)));
/* 106 */       stringBuffer.append((char)nibbleToHex((byte)(paramArrayOfbyte[b] & 0xF)));
/*     */     } 
/* 108 */     return stringBuffer.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static byte[] nibbles2bArray(byte[] paramArrayOfbyte) {
/* 122 */     byte[] arrayOfByte = new byte[paramArrayOfbyte.length / 2];
/*     */ 
/*     */     
/* 125 */     for (byte b = 0; b < arrayOfByte.length; b++) {
/*     */       
/* 127 */       arrayOfByte[b] = (byte)(asciiHexToNibble(paramArrayOfbyte[b * 2]) << 4);
/* 128 */       arrayOfByte[b] = (byte)(arrayOfByte[b] | asciiHexToNibble(paramArrayOfbyte[b * 2 + 1]));
/*     */     } 
/* 130 */     return arrayOfByte;
/*     */   }
/*     */ 
/*     */   
/*     */   public static void printInHex(long paramLong) {
/* 135 */     byte[] arrayOfByte = toHex(paramLong);
/* 136 */     System.out.print(new String(arrayOfByte, 0));
/*     */   }
/*     */ 
/*     */   
/*     */   public static void printInHex(int paramInt) {
/* 141 */     byte[] arrayOfByte = toHex(paramInt);
/* 142 */     System.out.print(new String(arrayOfByte, 0));
/*     */   }
/*     */ 
/*     */   
/*     */   public static void printInHex(short paramShort) {
/* 147 */     byte[] arrayOfByte = toHex(paramShort);
/* 148 */     System.out.print(new String(arrayOfByte, 0));
/*     */   }
/*     */ 
/*     */   
/*     */   public static byte[] toHex(long paramLong) {
/* 153 */     byte b = 16;
/* 154 */     byte[] arrayOfByte = new byte[b];
/*     */     
/* 156 */     for (int i = b - 1; i >= 0; i--) {
/*     */       
/* 158 */       arrayOfByte[i] = nibbleToHex((byte)(int)(paramLong & 0xFL));
/* 159 */       paramLong >>= 4L;
/*     */     } 
/* 161 */     return arrayOfByte;
/*     */   }
/*     */ 
/*     */   
/*     */   public static byte[] toHex(int paramInt) {
/* 166 */     byte b = 8;
/* 167 */     byte[] arrayOfByte = new byte[b];
/*     */     
/* 169 */     for (int i = b - 1; i >= 0; i--) {
/*     */       
/* 171 */       arrayOfByte[i] = nibbleToHex((byte)(paramInt & 0xF));
/* 172 */       paramInt >>= 4;
/*     */     } 
/* 174 */     return arrayOfByte;
/*     */   }
/*     */ 
/*     */   
/*     */   public static byte[] toHex(short paramShort) {
/* 179 */     byte b = 4;
/* 180 */     byte[] arrayOfByte = new byte[b];
/*     */     
/* 182 */     for (int i = b - 1; i >= 0; i--) {
/*     */       
/* 184 */       arrayOfByte[i] = nibbleToHex((byte)(paramShort & 0xF));
/* 185 */       paramShort = (short)(paramShort >> 4);
/*     */     } 
/* 187 */     return arrayOfByte;
/*     */   }
/*     */ }


/* Location:              C:\Users\olatu\OneDrive\Documents\Calypso\syncbase\sync_base.jar!\BOOT-INF\lib\ojdbc-7.jar!\oracle\core\lmx\LmxRepConversion.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */