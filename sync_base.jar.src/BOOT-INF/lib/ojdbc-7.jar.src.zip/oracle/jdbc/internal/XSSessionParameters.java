/*    */ package oracle.jdbc.internal;
/*    */ 
/*    */ import java.sql.SQLException;
/*    */ import oracle.jdbc.driver.InternalFactory;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class XSSessionParameters
/*    */ {
/*    */   public static XSSessionParameters constructXSSessionParameters() throws SQLException {
/* 53 */     return (XSSessionParameters)InternalFactory.createXSSessionParameters();
/*    */   }
/*    */   
/*    */   public abstract void setBinary(byte[] paramArrayOfbyte) throws SQLException;
/*    */   
/*    */   public abstract void setInt(int paramInt) throws SQLException;
/*    */   
/*    */   public abstract void setText(String[] paramArrayOfString) throws SQLException;
/*    */ }


/* Location:              C:\Users\olatu\OneDrive\Documents\Calypso\syncbase\sync_base.jar!\BOOT-INF\lib\ojdbc-7.jar!\oracle\jdbc\internal\XSSessionParameters.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */