/*    */ package oracle.jdbc.internal;
/*    */ 
/*    */ import java.sql.SQLException;
/*    */ import oracle.jdbc.driver.InternalFactory;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class XSKeyval
/*    */ {
/*    */   public static final XSKeyval constructXSKeyval() throws SQLException {
/* 15 */     return (XSKeyval)InternalFactory.createXSKeyval();
/*    */   }
/*    */   
/*    */   public abstract void setKeyval(KeywordValueLong[] paramArrayOfKeywordValueLong) throws SQLException;
/*    */   
/*    */   public abstract void setFlag(long paramLong) throws SQLException;
/*    */   
/*    */   public abstract KeywordValueLong[] getKeyval();
/*    */   
/*    */   public abstract long getFlag();
/*    */ }


/* Location:              C:\Users\olatu\OneDrive\Documents\Calypso\syncbase\sync_base.jar!\BOOT-INF\lib\ojdbc-7.jar!\oracle\jdbc\internal\XSKeyval.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */