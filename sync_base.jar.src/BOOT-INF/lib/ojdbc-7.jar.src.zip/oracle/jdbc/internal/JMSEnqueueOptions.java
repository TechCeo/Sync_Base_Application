/*     */ package oracle.jdbc.internal;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JMSEnqueueOptions
/*     */ {
/*     */   private VisibilityOption attrVisibility;
/*     */   private DeliveryMode attrDeliveryMode;
/*     */   private boolean retrieveMessageId;
/*     */   
/*     */   public enum VisibilityOption
/*     */   {
/*  43 */     ON_COMMIT(2),
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  49 */     IMMEDIATE(1);
/*     */     
/*     */     private final int mode;
/*     */     
/*     */     VisibilityOption(int param1Int1) {
/*  54 */       this.mode = param1Int1;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final int getCode() {
/*  62 */       return this.mode;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public enum DeliveryMode
/*     */   {
/*  70 */     PERSISTENT(0),
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  76 */     BUFFERED(4),
/*     */     
/*  78 */     PERSISTENTORBUFFERED(8);
/*     */     private final int mode;
/*     */     
/*     */     DeliveryMode(int param1Int1) {
/*  82 */       this.mode = param1Int1;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final int getCode() {
/*  89 */       return this.mode;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JMSEnqueueOptions() {
/* 108 */     this.attrVisibility = VisibilityOption.IMMEDIATE;
/* 109 */     this.attrDeliveryMode = DeliveryMode.PERSISTENT;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 114 */     this.retrieveMessageId = false;
/*     */   }
/*     */ 
/*     */   
/*     */   public DeliveryMode getDeliveryMode() {
/* 119 */     return this.attrDeliveryMode;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setDeliveryMode(DeliveryMode paramDeliveryMode) {
/* 124 */     this.attrDeliveryMode = paramDeliveryMode;
/*     */   }
/*     */ 
/*     */   
/*     */   public VisibilityOption getVisibility() {
/* 129 */     return this.attrVisibility;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setVisibility(VisibilityOption paramVisibilityOption) {
/* 134 */     this.attrVisibility = paramVisibilityOption;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isRetrieveMessageId() {
/* 139 */     return this.retrieveMessageId;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setRetrieveMessageId(boolean paramBoolean) {
/* 144 */     this.retrieveMessageId = paramBoolean;
/*     */   }
/*     */ }


/* Location:              C:\Users\olatu\OneDrive\Documents\Calypso\syncbase\sync_base.jar!\BOOT-INF\lib\ojdbc-7.jar!\oracle\jdbc\internal\JMSEnqueueOptions.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */