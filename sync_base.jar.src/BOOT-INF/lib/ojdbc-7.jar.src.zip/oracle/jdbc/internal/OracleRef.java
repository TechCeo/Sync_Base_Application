package oracle.jdbc.internal;

import java.sql.SQLException;
import java.util.Map;
import oracle.jdbc.OracleRef;
import oracle.sql.STRUCT;
import oracle.sql.StructDescriptor;

public interface OracleRef extends OracleDatumWithConnection, OracleRef, ACProxyable {
  Object getValue(Map paramMap) throws SQLException;
  
  Object getValue() throws SQLException;
  
  STRUCT getSTRUCT() throws SQLException;
  
  void setValue(Object paramObject) throws SQLException;
  
  StructDescriptor getDescriptor() throws SQLException;
  
  String getSQLTypeName() throws SQLException;
  
  Object toJdbc() throws SQLException;
  
  boolean isConvertibleTo(Class paramClass);
  
  Object makeJdbcArray(int paramInt);
  
  Object clone() throws CloneNotSupportedException;
  
  boolean equals(Object paramObject);
  
  int hashCode();
}


/* Location:              C:\Users\olatu\OneDrive\Documents\Calypso\syncbase\sync_base.jar!\BOOT-INF\lib\ojdbc-7.jar!\oracle\jdbc\internal\OracleRef.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */