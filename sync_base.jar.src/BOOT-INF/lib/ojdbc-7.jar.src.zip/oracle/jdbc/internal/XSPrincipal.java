/*    */ package oracle.jdbc.internal;
/*    */ 
/*    */ import java.sql.SQLException;
/*    */ import oracle.jdbc.driver.InternalFactory;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class XSPrincipal
/*    */ {
/*    */   public enum Flag
/*    */   {
/* 13 */     KPXS_PRIN_EXT(1L),
/* 14 */     KPXS_PRIN_USEDBID(2L);
/*    */     
/*    */     private final long mode;
/*    */     
/*    */     Flag(long param1Long) {
/* 19 */       this.mode = param1Long;
/*    */     }
/*    */ 
/*    */ 
/*    */ 
/*    */     
/*    */     public final long getMode() {
/* 26 */       return this.mode;
/*    */     }
/*    */   }
/*    */ 
/*    */   
/*    */   public static final XSPrincipal constructXSPrincipal() throws SQLException {
/* 32 */     return (XSPrincipal)InternalFactory.createXSPrincipal();
/*    */   }
/*    */   
/*    */   public abstract void setDatabaseId(long paramLong) throws SQLException;
/*    */   
/*    */   public abstract void setName(String paramString) throws SQLException;
/*    */   
/*    */   public abstract void setUUID(byte[] paramArrayOfbyte) throws SQLException;
/*    */   
/*    */   public abstract void setFlag(Flag paramFlag) throws SQLException;
/*    */   
/*    */   public abstract long getDatabaseId();
/*    */   
/*    */   public abstract String getName();
/*    */   
/*    */   public abstract byte[] getUUID();
/*    */   
/*    */   public abstract Flag getFlag();
/*    */ }


/* Location:              C:\Users\olatu\OneDrive\Documents\Calypso\syncbase\sync_base.jar!\BOOT-INF\lib\ojdbc-7.jar!\oracle\jdbc\internal\XSPrincipal.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */