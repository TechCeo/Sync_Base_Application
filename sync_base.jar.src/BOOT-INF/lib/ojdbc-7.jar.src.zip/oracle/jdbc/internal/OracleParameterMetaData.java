package oracle.jdbc.internal;

import oracle.jdbc.OracleParameterMetaData;

public interface OracleParameterMetaData extends OracleParameterMetaData, ACProxyable {}


/* Location:              C:\Users\olatu\OneDrive\Documents\Calypso\syncbase\sync_base.jar!\BOOT-INF\lib\ojdbc-7.jar!\oracle\jdbc\internal\OracleParameterMetaData.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */