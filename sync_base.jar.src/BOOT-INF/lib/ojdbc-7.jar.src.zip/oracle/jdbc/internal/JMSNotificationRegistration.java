/*    */ package oracle.jdbc.internal;
/*    */ 
/*    */ import java.sql.SQLException;
/*    */ import java.util.concurrent.Executor;
/*    */ import oracle.jdbc.NotificationRegistration;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public interface JMSNotificationRegistration
/*    */   extends NotificationRegistration
/*    */ {
/*    */   void addListener(JMSNotificationListener paramJMSNotificationListener) throws SQLException;
/*    */   
/*    */   void addListener(JMSNotificationListener paramJMSNotificationListener, Executor paramExecutor) throws SQLException;
/*    */   
/*    */   void removeListener(JMSNotificationListener paramJMSNotificationListener) throws SQLException;
/*    */   
/*    */   String getQueueName();
/*    */   
/*    */   public enum Directive
/*    */   {
/* 60 */     COMMIT((short)1),
/*    */ 
/*    */     
/* 63 */     ROLLBACK((short)2);
/*    */     
/*    */     Directive(short param1Short) {
/* 66 */       this.mode = param1Short;
/*    */     }
/*    */     private final short mode;
/*    */     public final short getCode() {
/* 70 */       return this.mode;
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\olatu\OneDrive\Documents\Calypso\syncbase\sync_base.jar!\BOOT-INF\lib\ojdbc-7.jar!\oracle\jdbc\internal\JMSNotificationRegistration.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */