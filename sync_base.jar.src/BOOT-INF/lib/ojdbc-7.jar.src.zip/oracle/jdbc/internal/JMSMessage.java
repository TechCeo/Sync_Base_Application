package oracle.jdbc.internal;

import oracle.jdbc.aq.AQMessageProperties;

public interface JMSMessage {
  byte[] getMessageId();
  
  void setMessageId(byte[] paramArrayOfbyte);
  
  byte[] getPayload();
  
  void setPayload(byte[] paramArrayOfbyte);
  
  void setJMSMessageProperties(JMSMessageProperties paramJMSMessageProperties);
  
  JMSMessageProperties getJMSMessageProperties();
  
  AQMessageProperties getAQMessageProperties();
  
  void setAQMessageProperties(AQMessageProperties paramAQMessageProperties);
  
  byte[] getToid();
}


/* Location:              C:\Users\olatu\OneDrive\Documents\Calypso\syncbase\sync_base.jar!\BOOT-INF\lib\ojdbc-7.jar!\oracle\jdbc\internal\JMSMessage.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */