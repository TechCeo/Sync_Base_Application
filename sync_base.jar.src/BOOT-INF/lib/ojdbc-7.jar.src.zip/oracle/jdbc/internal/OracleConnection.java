/*      */ package oracle.jdbc.internal;
/*      */ import java.sql.ResultSet;
/*      */ import java.sql.SQLException;
/*      */ import java.util.EnumSet;
/*      */ import java.util.Map;
/*      */ import java.util.Properties;
/*      */ import java.util.concurrent.Executor;
/*      */ import oracle.jdbc.aq.AQMessageProperties;
/*      */ import oracle.jdbc.pool.OraclePooledConnection;
/*      */ import oracle.sql.BLOB;
/*      */ import oracle.sql.CLOB;
/*      */ import oracle.sql.Datum;
/*      */ import oracle.sql.TIMESTAMPTZ;
/*      */ 
/*      */ public interface OracleConnection extends OracleConnection, ACProxyable {
/*      */   public static final String CONNECTION_PROPERTY_LOGON_CAP = "oracle.jdbc.thinLogonCapability";
/*      */   public static final String CONNECTION_PROPERTY_LOGON_CAP_DEFAULT = "o5";
/*      */   public static final byte CONNECTION_PROPERTY_LOGON_CAP_ACCESSMODE = 3;
/*      */   public static final String CONNECTION_PROPERTY_OCI_DEFAULT_DEFINES = "oracle.jdbc.useOCIDefaultDefines";
/*      */   public static final String CONNECTION_PROPERTY_OCI_DEFAULT_DEFINES_DEFAULT = "false";
/*      */   public static final byte CONNECTION_PROPERTY_OCI_DEFAULT_DEFINES_ACCESSMODE = 3;
/*      */   public static final String CONNECTION_PROPERTY_JMSNOTIFICATION = "oracle.jdbc.jmsNotification";
/*      */   public static final String CONNECTION_PROPERTY_JMSNOTIFICATION_DEFAULT = "false";
/*      */   public static final byte CONNECTION_PROPERTY_JMSNOTIFICATION_ACCESSMODE = 3;
/*      */   public static final String CONNECTION_PROPERTY_NLS_LANG_BACKDOOR = "oracle.jdbc.ociNlsLangBackwardCompatible";
/*      */   public static final String CONNECTION_PROPERTY_NLS_LANG_BACKDOOR_DEFAULT = "false";
/*      */   public static final byte CONNECTION_PROPERTY_NLS_LANG_BACKDOOR_ACCESSMODE = 3;
/*      */   public static final String CONNECTION_PROPERTY_SPAWN_NEW_THREAD_TO_CANCEL = "oracle.jdbc.spawnNewThreadToCancel";
/*      */   public static final String CONNECTION_PROPERTY_SPAWN_NEW_THREAD_TO_CANCEL_DEFAULT = "false";
/*      */   public static final byte CONNECTION_PROPERTY_SPAWN_NEW_THREAD_TO_CANCEL_ACCESSMODE = 3;
/*      */   public static final String CONNECTION_PROPERTY_OVERRIDE_ENABLE_READ_DATA_IN_LOCATOR = "oracle.jdbc.overrideEnableReadDataInLocator";
/*      */   public static final String CONNECTION_PROPERTY_OVERRIDE_ENABLE_READ_DATA_IN_LOCATOR_DEFAULT = "false";
/*      */   public static final byte CONNECTION_PROPERTY_OVERRIDE_ENABLE_READ_DATA_IN_LOCATOR_ACCESSMODE = 3;
/*      */   public static final String CONNECTION_PROPERTY_PERMIT_TIMESTAMP_DATE_MISMATCH = "oracle.jdbc.internal.permitBindDateDefineTimestampMismatch";
/*      */   public static final String CONNECTION_PROPERTY_PERMIT_TIMESTAMP_DATE_MISMATCH_DEFAULT = "false";
/*      */   public static final byte CONNECTION_PROPERTY_PERMIT_TIMESTAMP_DATE_MISMATCH_ACCESSMODE = 3;
/*      */   public static final String CONNECTION_PROPERTY_IGNORE_REPLAY_CTX_FROM_AUTH = "oracle.jdbc.ignoreReplayContextFromAuthentication";
/*      */   public static final String CONNECTION_PROPERTY_IGNORE_REPLAY_CTX_FROM_AUTH_DEFAULT = "false";
/*      */   public static final byte CONNECTION_PROPERTY_IGNORE_REPLAY_CTX_FROM_AUTH_ACCESSMODE = 1;
/*      */   public static final String CONNECTION_PROPERTY_DEFAULT_USE_JAVANETNIO = "oracle.jdbc.javaNetNio";
/*      */   public static final String CONNECTION_PROPERTY_DEFAULT_USE_JAVANETNIO_DEFAULT = "false";
/*      */   public static final byte CONNECTION_PROPERTY_DEFAULT_USE_JAVANETNIO_ACCESSMODE = 3;
/*      */   public static final String CONNECTION_PROPERTY_NS_DIRECT_BUFFER = "oracle.jdbc.nsDirectBuffer";
/*      */   public static final String CONNECTION_PROPERTY_NS_DIRECT_BUFFER_DEFAULT = "false";
/*      */   public static final byte CONNECTION_PROPERTY_NS_DIRECT_BUFFER_ACCESSMODE = 3;
/*      */   public static final String CONNECTION_PROPERTY_PLSQL_VARCHAR_PARAMETER_4K_ONLY = "oracle.jdbc.plsqlVarcharParameter4KOnly";
/*      */   public static final String CONNECTION_PROPERTY_PLSQL_VARCHAR_PARAMETER_4K_ONLY_DEFAULT = "false";
/*      */   public static final byte CONNECTION_PROPERTY_PLSQL_VARCHAR_PARAMETER_4K_ONLY_ACCESSMODE = 3;
/*      */   public static final String CONNECTION_PROPERTY_INSTANCE_NAME = "oracle.jdbc.targetInstanceName";
/*      */   public static final byte CONNECTION_PROPERTY_INSTANCE_NAME_ACCESSMODE = 3;
/*      */   public static final String CONNECTION_PROPERTY_ENABLE_OCI_FAST_APPLICATION_NOTIFICATION = "oracle.jdbc.enableOCIFastApplicationNotification";
/*      */   public static final String CONNECTION_PROPERTY_ENABLE_OCI_FAST_APPLICATION_NOTIFICATION_DEFAULT = "false";
/*      */   public static final byte CONNECTION_PROPERTY_ENABLE_OCI_FAST_APPLICATION_NOTIFICATION_ACCESSMODE = 3;
/*      */   public static final int CHAR_TO_ASCII = 0;
/*      */   public static final int CHAR_TO_UNICODE = 1;
/*      */   public static final int RAW_TO_ASCII = 2;
/*      */   public static final int RAW_TO_UNICODE = 3;
/*      */   public static final int UNICODE_TO_CHAR = 4;
/*      */   public static final int ASCII_TO_CHAR = 5;
/*      */   public static final int NONE = 6;
/*      */   public static final int JAVACHAR_TO_CHAR = 7;
/*      */   public static final int RAW_TO_JAVACHAR = 8;
/*      */   public static final int CHAR_TO_JAVACHAR = 9;
/*      */   public static final int GLOBAL_TXN = 1;
/*      */   public static final int NO_GLOBAL_TXN = 0;
/*      */   public static final int VARTYPE_MAXLEN_COMPAT_STANDARD = 1;
/*      */   public static final int VARTYPE_MAXLEN_COMPAT_EXTENDED = 2;
/*      */   public static final int VARTYPE_MAXLEN_STANDARD_METADATA = 4000;
/*      */   public static final int VARTYPE_MAXLEN_STANDARD_BIND = 32766;
/*      */   public static final int VARTYPE_MAXLEN_STANDARD_BIND_OUT = 32767;
/*      */   public static final int VARTYPE_MAXLEN_STANDARD_BIND_PLSQL_BUG3936526 = 32512;
/*      */   public static final int NVARTYPE_MAXLEN_STANDARD_METADATA = 4000;
/*      */   public static final int NVARTYPE_MAXLEN_STANDARD_BIND = 32766;
/*      */   public static final int RAWTYPE_MAXLEN_STANDARD_METADATA = 2000;
/*      */   public static final int RAWTYPE_MAXLEN_STANDARD_BIND_SQL = 4000;
/*      */   public static final int RAWTYPE_MAXLEN_STANDARD_BIND_PLSQL = 32766;
/*      */   public static final int VARTYPE_MAXLEN_EXTENDED_METADATA = 32767;
/*      */   public static final int VARTYPE_MAXLEN_EXTENDED_BIND = 32766;
/*      */   public static final int VARTYPE_MAXLEN_EXTENDED_BIND_OUT = 32767;
/*      */   public static final int VARTYPE_MAXLEN_STANDARD = 4000;
/*      */   public static final int RAWTYPE_MAXLEN_STANDARD = 2000;
/*      */   public static final int NVARTYPE_MAXLEN_STANDARD = 4000;
/*      */   public static final int VARTYPE_MAXLEN_EXTENDED = 32767;
/*      */   public static final int RAWTYPE_MAXLEN_EXTENDED = 32767;
/*      */   public static final int NVARTYPE_MAXLEN_EXTENDED = 32766;
/*      */   
/*      */   int getVarTypeMaxLenCompat() throws SQLException;
/*      */   
/*      */   short getStructAttrNCsId() throws SQLException;
/*      */   
/*      */   Map getTypeMap() throws SQLException;
/*      */   
/*      */   Properties getDBAccessProperties() throws SQLException;
/*      */   
/*      */   Properties getOCIHandles() throws SQLException;
/*      */   
/*      */   String getDatabaseProductVersion() throws SQLException;
/*      */   
/*      */   String getURL() throws SQLException;
/*      */   
/*      */   short getVersionNumber() throws SQLException;
/*      */   
/*      */   Map getJavaObjectTypeMap();
/*      */   
/*      */   void setJavaObjectTypeMap(Map paramMap);
/*      */   
/*      */   byte getInstanceProperty(InstanceProperty paramInstanceProperty) throws SQLException;
/*      */   
/*      */   BfileDBAccess createBfileDBAccess() throws SQLException;
/*      */   
/*      */   BlobDBAccess createBlobDBAccess() throws SQLException;
/*      */   
/*      */   ClobDBAccess createClobDBAccess() throws SQLException;
/*      */   
/*      */   void setDefaultFixedString(boolean paramBoolean);
/*      */   
/*      */   boolean getDefaultFixedString();
/*      */   
/*      */   OracleConnection getWrapper();
/*      */   
/*      */   Class classForNameAndSchema(String paramString1, String paramString2) throws ClassNotFoundException;
/*      */   
/*      */   void setFDO(byte[] paramArrayOfbyte) throws SQLException;
/*      */   
/*      */   byte[] getFDO(boolean paramBoolean) throws SQLException;
/*      */   
/*      */   boolean getBigEndian() throws SQLException;
/*      */   
/*      */   Object getDescriptor(byte[] paramArrayOfbyte);
/*      */   
/*      */   void putDescriptor(byte[] paramArrayOfbyte, Object paramObject) throws SQLException;
/*      */   
/*      */   OracleConnection getPhysicalConnection();
/*      */   
/*      */   void removeDescriptor(String paramString);
/*      */   
/*      */   void removeAllDescriptor();
/*      */   
/*      */   int numberOfDescriptorCacheEntries();
/*      */   
/*      */   Enumeration descriptorCacheKeys();
/*      */   
/*      */   long getTdoCState(String paramString1, String paramString2) throws SQLException;
/*      */   
/*      */   long getTdoCState(String paramString) throws SQLException;
/*      */   
/*      */   BufferCacheStatistics getByteBufferCacheStatistics();
/*      */   
/*      */   BufferCacheStatistics getCharBufferCacheStatistics();
/*      */   
/*      */   Datum toDatum(CustomDatum paramCustomDatum) throws SQLException;
/*      */   
/*      */   short getDbCsId() throws SQLException;
/*      */   
/*      */   short getJdbcCsId() throws SQLException;
/*      */   
/*      */   short getNCharSet();
/*      */   
/*      */   ResultSet newArrayDataResultSet(Datum[] paramArrayOfDatum, long paramLong, int paramInt, Map paramMap) throws SQLException;
/*      */   
/*      */   ResultSet newArrayDataResultSet(ARRAY paramARRAY, long paramLong, int paramInt, Map paramMap) throws SQLException;
/*      */   
/*      */   ResultSet newArrayLocatorResultSet(ArrayDescriptor paramArrayDescriptor, byte[] paramArrayOfbyte, long paramLong, int paramInt, Map paramMap) throws SQLException;
/*      */   
/*      */   ResultSetMetaData newStructMetaData(StructDescriptor paramStructDescriptor) throws SQLException;
/*      */   
/*      */   void getForm(OracleTypeADT paramOracleTypeADT, OracleTypeCLOB paramOracleTypeCLOB, int paramInt) throws SQLException;
/*      */   
/*      */   int CHARBytesToJavaChars(byte[] paramArrayOfbyte, int paramInt, char[] paramArrayOfchar) throws SQLException;
/*      */   
/*      */   int NCHARBytesToJavaChars(byte[] paramArrayOfbyte, int paramInt, char[] paramArrayOfchar) throws SQLException;
/*      */   
/*      */   boolean IsNCharFixedWith();
/*      */   
/*      */   short getDriverCharSet();
/*      */   
/*      */   int getC2SNlsRatio();
/*      */   
/*      */   int getMaxCharSize() throws SQLException;
/*      */   
/*      */   int getMaxCharbyteSize();
/*      */   
/*      */   int getMaxNCharbyteSize();
/*      */   
/*      */   boolean isCharSetMultibyte(short paramShort);
/*      */   
/*      */   int javaCharsToCHARBytes(char[] paramArrayOfchar, int paramInt, byte[] paramArrayOfbyte) throws SQLException;
/*      */   
/*      */   int javaCharsToNCHARBytes(char[] paramArrayOfchar, int paramInt, byte[] paramArrayOfbyte) throws SQLException;
/*      */   
/*      */   void setStartTime(long paramLong) throws SQLException;
/*      */   
/*      */   long getStartTime() throws SQLException;
/*      */   
/*      */   boolean isStatementCacheInitialized();
/*      */   
/*      */   void getPropertyForPooledConnection(OraclePooledConnection paramOraclePooledConnection) throws SQLException;
/*      */   
/*      */   void setTypeMap(Map paramMap) throws SQLException;
/*      */   
/*      */   String getProtocolType();
/*      */   
/*      */   Connection getLogicalConnection(OraclePooledConnection paramOraclePooledConnection, boolean paramBoolean) throws SQLException;
/*      */   
/*      */   void setTxnMode(int paramInt);
/*      */   
/*      */   int getTxnMode();
/*      */   
/*      */   int getHeapAllocSize() throws SQLException;
/*      */   
/*      */   int getOCIEnvHeapAllocSize() throws SQLException;
/*      */   
/*      */   void setAbandonedTimeoutEnabled(boolean paramBoolean) throws SQLException;
/*      */   
/*      */   int getHeartbeatNoChangeCount() throws SQLException;
/*      */   
/*      */   void closeInternal(boolean paramBoolean) throws SQLException;
/*      */   
/*      */   void cleanupAndClose(boolean paramBoolean) throws SQLException;
/*      */   
/*      */   OracleConnectionCacheCallback getConnectionCacheCallbackObj() throws SQLException;
/*      */   
/*      */   Object getConnectionCacheCallbackPrivObj() throws SQLException;
/*      */   
/*      */   int getConnectionCacheCallbackFlag() throws SQLException;
/*      */   
/*      */   Properties getServerSessionInfo() throws SQLException;
/*      */   
/*      */   CLOB createClob(byte[] paramArrayOfbyte) throws SQLException;
/*      */   
/*      */   CLOB createClobWithUnpickledBytes(byte[] paramArrayOfbyte) throws SQLException;
/*      */   
/*      */   CLOB createClob(byte[] paramArrayOfbyte, short paramShort) throws SQLException;
/*      */   
/*      */   BLOB createBlob(byte[] paramArrayOfbyte) throws SQLException;
/*      */   
/*      */   BLOB createBlobWithUnpickledBytes(byte[] paramArrayOfbyte) throws SQLException;
/*      */   
/*      */   BFILE createBfile(byte[] paramArrayOfbyte) throws SQLException;
/*      */   
/*      */   boolean isDescriptorSharable(OracleConnection paramOracleConnection) throws SQLException;
/*      */   
/*      */   OracleStatement refCursorCursorToStatement(int paramInt) throws SQLException;
/*      */   
/*      */   XAResource getXAResource() throws SQLException;
/*      */   
/*      */   boolean isV8Compatible() throws SQLException;
/*      */   
/*      */   boolean getMapDateToTimestamp();
/*      */   
/*      */   byte[] createLightweightSession(String paramString, KeywordValueLong[] paramArrayOfKeywordValueLong, int paramInt, KeywordValueLong[][] paramArrayOfKeywordValueLong1, int[] paramArrayOfint) throws SQLException;
/*      */   
/*      */   void executeLightweightSessionPiggyback(int paramInt1, byte[] paramArrayOfbyte, KeywordValueLong[] paramArrayOfKeywordValueLong, int paramInt2) throws SQLException;
/*      */   
/*      */   void doXSNamespaceOp(XSOperationCode paramXSOperationCode, byte[] paramArrayOfbyte, XSNamespace[] paramArrayOfXSNamespace, XSNamespace[][] paramArrayOfXSNamespace1, XSSecureId paramXSSecureId) throws SQLException;
/*      */   
/*      */   void doXSNamespaceOp(XSOperationCode paramXSOperationCode, byte[] paramArrayOfbyte, XSNamespace[] paramArrayOfXSNamespace, XSSecureId paramXSSecureId) throws SQLException;
/*      */   
/*      */   byte[] doXSSessionCreateOp(XSSessionOperationCode paramXSSessionOperationCode, XSSecureId paramXSSecureId, byte[] paramArrayOfbyte, XSPrincipal paramXSPrincipal, String paramString, XSNamespace[] paramArrayOfXSNamespace, XSSessionModeFlag paramXSSessionModeFlag, XSKeyval paramXSKeyval) throws SQLException;
/*      */   
/*      */   void doXSSessionDestroyOp(byte[] paramArrayOfbyte1, XSSecureId paramXSSecureId, byte[] paramArrayOfbyte2) throws SQLException;
/*      */   
/*      */   void doXSSessionAttachOp(int paramInt1, byte[] paramArrayOfbyte1, XSSecureId paramXSSecureId, byte[] paramArrayOfbyte2, XSPrincipal paramXSPrincipal, String[] paramArrayOfString1, String[] paramArrayOfString2, String[] paramArrayOfString3, XSNamespace[] paramArrayOfXSNamespace1, XSNamespace[] paramArrayOfXSNamespace2, XSNamespace[] paramArrayOfXSNamespace3, TIMESTAMPTZ paramTIMESTAMPTZ1, TIMESTAMPTZ paramTIMESTAMPTZ2, int paramInt2, long paramLong, XSKeyval paramXSKeyval, int[] paramArrayOfint) throws SQLException;
/*      */   
/*  265 */   public static final String CONNECTION_PROPERTY_INSTANCE_NAME_DEFAULT = null;
/*      */ 
/*      */ 
/*      */   
/*      */   void doXSSessionDetachOp(int paramInt, byte[] paramArrayOfbyte, XSSecureId paramXSSecureId, boolean paramBoolean) throws SQLException;
/*      */ 
/*      */ 
/*      */   
/*      */   void doXSSessionChangeOp(XSSessionSetOperationCode paramXSSessionSetOperationCode, byte[] paramArrayOfbyte, XSSecureId paramXSSecureId, XSSessionParameters paramXSSessionParameters) throws SQLException;
/*      */ 
/*      */ 
/*      */   
/*      */   String getDefaultSchemaNameForNamedTypes() throws SQLException;
/*      */ 
/*      */ 
/*      */   
/*      */   void setUsable(boolean paramBoolean);
/*      */ 
/*      */ 
/*      */   
/*      */   Class getClassForType(String paramString, Map<String, Class> paramMap);
/*      */ 
/*      */ 
/*      */   
/*      */   void addXSEventListener(XSEventListener paramXSEventListener) throws SQLException;
/*      */ 
/*      */ 
/*      */   
/*      */   void addXSEventListener(XSEventListener paramXSEventListener, Executor paramExecutor) throws SQLException;
/*      */ 
/*      */ 
/*      */   
/*      */   void removeXSEventListener(XSEventListener paramXSEventListener) throws SQLException;
/*      */ 
/*      */ 
/*      */   
/*      */   int getTimezoneVersionNumber() throws SQLException;
/*      */ 
/*      */ 
/*      */   
/*      */   void removeAllXSEventListener() throws SQLException;
/*      */ 
/*      */ 
/*      */   
/*      */   TIMEZONETAB getTIMEZONETAB() throws SQLException;
/*      */ 
/*      */ 
/*      */   
/*      */   String getDatabaseTimeZone() throws SQLException;
/*      */ 
/*      */ 
/*      */   
/*      */   boolean getTimestamptzInGmt();
/*      */ 
/*      */ 
/*      */   
/*      */   boolean getUse1900AsYearForTime();
/*      */ 
/*      */ 
/*      */   
/*      */   boolean isDataInLocatorEnabled() throws SQLException;
/*      */ 
/*      */ 
/*      */   
/*      */   boolean isLobStreamPosStandardCompliant() throws SQLException;
/*      */ 
/*      */ 
/*      */   
/*      */   long getCurrentSCN() throws SQLException;
/*      */ 
/*      */ 
/*      */   
/*      */   EnumSet<TransactionState> getTransactionState() throws SQLException;
/*      */ 
/*      */ 
/*      */   
/*      */   boolean isConnectionSocketKeepAlive() throws SocketException, SQLException;
/*      */ 
/*      */ 
/*      */   
/*      */   void setReplayOperations(EnumSet<ReplayOperation> paramEnumSet) throws SQLException;
/*      */ 
/*      */ 
/*      */   
/*      */   void setReplayingMode(boolean paramBoolean) throws SQLException;
/*      */ 
/*      */ 
/*      */   
/*      */   void beginNonRequestCalls() throws SQLException;
/*      */ 
/*      */ 
/*      */   
/*      */   void endNonRequestCalls() throws SQLException;
/*      */ 
/*      */ 
/*      */   
/*      */   void setReplayContext(ReplayContext[] paramArrayOfReplayContext) throws SQLException;
/*      */ 
/*      */ 
/*      */   
/*      */   ReplayContext[] getReplayContext() throws SQLException;
/*      */ 
/*      */ 
/*      */   
/*      */   ReplayContext getLastReplayContext() throws SQLException;
/*      */ 
/*      */ 
/*      */   
/*      */   void registerEndReplayCallback(EndReplayCallback paramEndReplayCallback) throws SQLException;
/*      */ 
/*      */ 
/*      */   
/*      */   int getEOC() throws SQLException;
/*      */ 
/*      */ 
/*      */   
/*      */   byte[] getDerivedKeyInternal(byte[] paramArrayOfbyte, int paramInt) throws NoSuchAlgorithmException, InvalidKeySpecException, SQLException;
/*      */ 
/*      */ 
/*      */   
/*      */   short getExecutingRPCFunctionCode();
/*      */ 
/*      */ 
/*      */   
/*      */   String getExecutingRPCSQL();
/*      */ 
/*      */ 
/*      */   
/*      */   void jmsEnqueue(String paramString, JMSEnqueueOptions paramJMSEnqueueOptions, JMSMessage paramJMSMessage, AQMessageProperties paramAQMessageProperties) throws SQLException;
/*      */ 
/*      */ 
/*      */   
/*      */   JMSMessage jmsDequeue(String paramString, JMSDequeueOptions paramJMSDequeueOptions) throws SQLException;
/*      */ 
/*      */ 
/*      */   
/*      */   JMSMessage jmsDequeue(String paramString1, JMSDequeueOptions paramJMSDequeueOptions, String paramString2) throws SQLException;
/*      */ 
/*      */ 
/*      */   
/*      */   Map<String, JMSNotificationRegistration> registerJMSNotification(String[] paramArrayOfString, Map<String, Properties> paramMap) throws SQLException;
/*      */ 
/*      */ 
/*      */   
/*      */   void unregisterJMSNotification(JMSNotificationRegistration paramJMSNotificationRegistration) throws SQLException;
/*      */ 
/*      */ 
/*      */   
/*      */   void ackJMSNotification(JMSNotificationRegistration paramJMSNotificationRegistration, byte[] paramArrayOfbyte, JMSNotificationRegistration.Directive paramDirective) throws SQLException;
/*      */ 
/*      */   
/*      */   int getNegotiatedSDU() throws SQLException;
/*      */ 
/*      */   
/*      */   void setPDBChangeEventListener(PDBChangeEventListener paramPDBChangeEventListener) throws SQLException;
/*      */ 
/*      */   
/*      */   void setPDBChangeEventListener(PDBChangeEventListener paramPDBChangeEventListener, Executor paramExecutor) throws SQLException;
/*      */ 
/*      */   
/*      */   void setChecksumMode(ChecksumMode paramChecksumMode) throws SQLException;
/*      */ 
/*      */   
/*      */   public enum InstanceProperty
/*      */   {
/*  430 */     ASM_VOLUME_SUPPORTED,
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  443 */     INSTANCE_TYPE;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public enum TransactionState
/*      */   {
/*  454 */     TRANSACTION_STARTED,
/*      */ 
/*      */ 
/*      */     
/*  458 */     TRANSACTION_ENDED,
/*      */ 
/*      */ 
/*      */     
/*  462 */     TRANSACTION_READONLY,
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  467 */     TRANSACTION_INTENTION;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public enum XSOperationCode
/*      */   {
/*  886 */     NAMESPACE_CREATE(1),
/*  887 */     NAMESPACE_DELETE(2),
/*  888 */     ATTRIBUTE_CREATE(3),
/*  889 */     ATTRIBUTE_SET(4),
/*  890 */     ATTRIBUTE_DELETE(5),
/*  891 */     ATTRIBUTE_RESET(6),
/*  892 */     NAMESPACE_GET(7),
/*  893 */     ATTRIBUTE_GET(8);
/*      */     private final int code;
/*      */     
/*      */     XSOperationCode(int param1Int1) {
/*  897 */       this.code = param1Int1;
/*      */     }
/*      */ 
/*      */     
/*      */     public final int getCode() {
/*  902 */       return this.code;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public enum XSSessionOperationCode
/*      */   {
/*  964 */     SESSION_CREATE(1);
/*      */     private final int code;
/*      */     
/*      */     XSSessionOperationCode(int param1Int1) {
/*  968 */       this.code = param1Int1;
/*      */     }
/*      */ 
/*      */     
/*      */     public final int getCode() {
/*  973 */       return this.code;
/*      */     }
/*      */   }
/*      */   
/*      */   public enum XSSessionModeFlag {
/*  978 */     SECURE(0),
/*  979 */     TRUSTED(1);
/*      */     private final int code;
/*      */     
/*      */     XSSessionModeFlag(int param1Int1) {
/*  983 */       this.code = param1Int1;
/*      */     }
/*      */ 
/*      */     
/*      */     public final int getCode() {
/*  988 */       return this.code;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public enum XSSessionSetOperationCode
/*      */   {
/* 1084 */     SESSION_SET_COOKIE(1),
/* 1085 */     SESSION_SET_TIMEOUT(2),
/* 1086 */     SESSION_REAUTH(3),
/* 1087 */     SESSION_ENABLE_ROLE(4),
/* 1088 */     SESSION_DISABLE_ROLE(5);
/*      */     private final int code;
/*      */     
/*      */     XSSessionSetOperationCode(int param1Int1) {
/* 1092 */       this.code = param1Int1;
/*      */     }
/*      */ 
/*      */     
/*      */     public final int getCode() {
/* 1097 */       return this.code;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static interface BufferCacheStatistics
/*      */   {
/*      */     int getId();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     int[] getBufferSizes();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     int getCacheHits(int param1Int);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     int getCacheMisses(int param1Int);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     int getBuffersCached(int param1Int);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     int getBucketsFull(int param1Int);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     int getReferencesCleared(int param1Int);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     int getTooBigToCache();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public enum ReplayOperation
/*      */   {
/* 1350 */     KPDSS_SESSSTATE_APPCONT_ENABLED(1L),
/* 1351 */     KPDSS_SESSSTATE_STATIC(2L),
/* 1352 */     KPDSS_SESSSTATE_REQUEST_BEGIN(4L),
/* 1353 */     KPDSS_SESSSTATE_REQUEST_END(8L),
/* 1354 */     KPDSS_SESSSTATE_NONREQUEST_CALL(16L);
/*      */     private final long code;
/*      */     
/*      */     ReplayOperation(long param1Long) {
/* 1358 */       this.code = param1Long;
/*      */     }
/*      */ 
/*      */     
/*      */     public final long getCode() {
/* 1363 */       return this.code;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static interface EndReplayCallback
/*      */   {
/*      */     void executeCallback() throws SQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public enum ChecksumMode
/*      */   {
/* 1631 */     NO_CHECKSUM(false, false),
/* 1632 */     CALCULATE_CHECKSUM_FETCH(true, false),
/* 1633 */     CALCULATE_CHECKSUM_BINDS(false, true),
/* 1634 */     CALCULATE_CHECKSUM_ALL(true, true);
/*      */     private boolean fetchChecksum;
/*      */     private boolean bindChecksum;
/*      */     
/*      */     ChecksumMode(boolean param1Boolean1, boolean param1Boolean2) {
/* 1639 */       this.fetchChecksum = param1Boolean1;
/* 1640 */       this.bindChecksum = param1Boolean2;
/*      */     }
/*      */     
/* 1643 */     public boolean needToCalculateFetchChecksum() { return this.fetchChecksum; } public boolean needToCalculateBindChecksum() {
/* 1644 */       return this.bindChecksum;
/*      */     }
/*      */   }
/*      */ }


/* Location:              C:\Users\olatu\OneDrive\Documents\Calypso\syncbase\sync_base.jar!\BOOT-INF\lib\ojdbc-7.jar!\oracle\jdbc\internal\OracleConnection.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */