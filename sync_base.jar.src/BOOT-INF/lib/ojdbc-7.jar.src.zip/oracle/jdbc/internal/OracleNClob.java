package oracle.jdbc.internal;

import oracle.jdbc.OracleNClob;

public interface OracleNClob extends OracleDatumWithConnection, OracleNClob, OracleClob, ACProxyable {}


/* Location:              C:\Users\olatu\OneDrive\Documents\Calypso\syncbase\sync_base.jar!\BOOT-INF\lib\ojdbc-7.jar!\oracle\jdbc\internal\OracleNClob.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */