package oracle.jdbc.internal;

import java.io.Reader;
import java.sql.SQLException;
import oracle.jdbc.OraclePreparedStatement;

public interface OraclePreparedStatement extends OraclePreparedStatement, OracleStatement, ACProxyable {
  void setCheckBindTypes(boolean paramBoolean);
  
  void setInternalBytes(int paramInt1, byte[] paramArrayOfbyte, int paramInt2) throws SQLException;
  
  void enterImplicitCache() throws SQLException;
  
  void enterExplicitCache() throws SQLException;
  
  void exitImplicitCacheToActive() throws SQLException;
  
  void exitExplicitCacheToActive() throws SQLException;
  
  void exitImplicitCacheToClose() throws SQLException;
  
  void exitExplicitCacheToClose() throws SQLException;
  
  void setCharacterStreamAtName(String paramString, Reader paramReader, int paramInt) throws SQLException;
  
  String getOriginalSql() throws SQLException;
}


/* Location:              C:\Users\olatu\OneDrive\Documents\Calypso\syncbase\sync_base.jar!\BOOT-INF\lib\ojdbc-7.jar!\oracle\jdbc\internal\OraclePreparedStatement.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */