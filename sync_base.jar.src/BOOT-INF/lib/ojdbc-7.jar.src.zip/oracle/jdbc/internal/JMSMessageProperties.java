/*    */ package oracle.jdbc.internal;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public interface JMSMessageProperties
/*    */ {
/*    */   String getHeaderProperties();
/*    */   
/*    */   void setHeaderProperties(String paramString);
/*    */   
/*    */   JMSMessageType getJMSMessageType();
/*    */   
/*    */   void setJMSMessageType(JMSMessageType paramJMSMessageType);
/*    */   
/*    */   String getUserProperties();
/*    */   
/*    */   void setUserProperties(String paramString);
/*    */   
/*    */   public enum JMSMessageType
/*    */   {
/* 40 */     TEXT_MESSAGE(0),
/* 41 */     BYTES_MESSAGE(1),
/* 42 */     STREAM_MESSAGE(2),
/* 43 */     MAP_MESSAGE(3),
/* 44 */     OBJECT_MESSAGE(4),
/* 45 */     MESSAGE(100);
/*    */     
/*    */     private final int code;
/*    */     
/*    */     JMSMessageType(int param1Int1) {
/* 50 */       this.code = param1Int1;
/*    */     }
/*    */ 
/*    */     
/*    */     public final int getCode() {
/* 55 */       return this.code;
/*    */     }
/*    */ 
/*    */     
/*    */     public static final JMSMessageType getJMSMessageType(int param1Int) {
/* 60 */       if (param1Int == TEXT_MESSAGE.getCode())
/* 61 */         return TEXT_MESSAGE; 
/* 62 */       if (param1Int == BYTES_MESSAGE.getCode())
/* 63 */         return BYTES_MESSAGE; 
/* 64 */       if (param1Int == STREAM_MESSAGE.getCode())
/* 65 */         return STREAM_MESSAGE; 
/* 66 */       if (param1Int == MAP_MESSAGE.getCode())
/* 67 */         return MAP_MESSAGE; 
/* 68 */       if (param1Int == OBJECT_MESSAGE.getCode()) {
/* 69 */         return OBJECT_MESSAGE;
/*    */       }
/* 71 */       return MESSAGE;
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\olatu\OneDrive\Documents\Calypso\syncbase\sync_base.jar!\BOOT-INF\lib\ojdbc-7.jar!\oracle\jdbc\internal\JMSMessageProperties.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */