/*     */ package oracle.jdbc.internal;
/*     */ 
/*     */ import java.sql.SQLException;
/*     */ import java.util.EventListener;
/*     */ import oracle.jdbc.OracleStatement;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public interface OracleStatement
/*     */   extends OracleStatement, ACProxyable
/*     */ {
/*     */   public static final int DEFAULT_RSET_TYPE = 1;
/*     */   public static final int CLOSED = 0;
/*     */   public static final int ACTIVE = 1;
/*     */   public static final int CACHED = 2;
/*     */   public static final int NON_CACHED = 3;
/*     */   public static final byte IS_UNINITIALIZED = 0;
/*     */   public static final byte IS_SELECT = 1;
/*     */   public static final byte IS_DELETE = 2;
/*     */   public static final byte IS_INSERT = 4;
/*     */   public static final byte IS_MERGE = 8;
/*     */   public static final byte IS_UPDATE = 16;
/*     */   public static final byte IS_PLSQL_BLOCK = 32;
/*     */   public static final byte IS_CALL_BLOCK = 64;
/*     */   public static final byte IS_OTHER = -128;
/*     */   public static final byte IS_DML = 30;
/*     */   public static final byte IS_PLSQL = 96;
/*     */   
/*     */   void setFixedString(boolean paramBoolean);
/*     */   
/*     */   boolean getFixedString();
/*     */   
/*     */   int sendBatch() throws SQLException;
/*     */   
/*     */   boolean getserverCursor();
/*     */   
/*     */   int getcacheState();
/*     */   
/*     */   int getstatementType();
/*     */   
/*     */   SqlKind getSqlKind() throws SQLException;
/*     */   
/*     */   long getChecksum() throws SQLException;
/*     */   
/*     */   void registerBindChecksumListener(BindChecksumListener paramBindChecksumListener) throws SQLException;
/*     */   
/*     */   void setSnapshotSCN(long paramLong) throws SQLException;
/*     */   
/*     */   public static interface BindChecksumListener
/*     */     extends EventListener
/*     */   {
/*     */     boolean shouldContinue(long param1Long);
/*     */   }
/*     */   
/*     */   public enum SqlKind
/*     */   {
/* 150 */     SELECT(false, false, true, false, (byte)1),
/* 151 */     DELETE(false, true, false, false, (byte)2),
/* 152 */     INSERT(false, true, false, false, (byte)4),
/* 153 */     MERGE(false, true, false, false, (byte)8),
/* 154 */     UPDATE(false, true, false, false, (byte)16),
/* 155 */     PLSQL_BLOCK(true, false, false, false, (byte)32),
/* 156 */     CALL_BLOCK(true, false, false, false, (byte)64),
/* 157 */     SELECT_FOR_UPDATE(false, false, true, false, (byte)1),
/* 158 */     ALTER_SESSION(false, false, false, true, -128),
/* 159 */     OTHER(false, false, false, true, -128),
/* 160 */     UNINITIALIZED(false, false, false, false, (byte)0);
/*     */     
/*     */     private final boolean dml;
/*     */     
/*     */     private final boolean plsqlOrCall;
/*     */     
/*     */     private final boolean select;
/*     */     
/*     */     private final boolean other;
/*     */     
/*     */     private final byte kind;
/*     */     
/*     */     SqlKind(boolean param1Boolean1, boolean param1Boolean2, boolean param1Boolean3, boolean param1Boolean4, byte param1Byte) {
/* 173 */       this.dml = param1Boolean2;
/* 174 */       this.plsqlOrCall = param1Boolean1;
/* 175 */       this.select = param1Boolean3;
/* 176 */       this.other = param1Boolean4;
/* 177 */       this.kind = param1Byte;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean isPlsqlOrCall() {
/* 203 */       return this.plsqlOrCall;
/* 204 */     } public boolean isDML() { return this.dml; }
/* 205 */     public boolean isSELECT() { return this.select; }
/* 206 */     public boolean isOTHER() { return this.other; } public byte getKind() {
/* 207 */       return this.kind;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\olatu\OneDrive\Documents\Calypso\syncbase\sync_base.jar!\BOOT-INF\lib\ojdbc-7.jar!\oracle\jdbc\internal\OracleStatement.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */