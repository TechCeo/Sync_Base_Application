/*    */ package oracle.jdbc.internal;
/*    */ 
/*    */ import java.sql.SQLException;
/*    */ import oracle.jdbc.driver.InternalFactory;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class XSSecureId
/*    */ {
/*    */   public static final XSSecureId constructXSecureId() throws SQLException {
/* 13 */     return (XSSecureId)InternalFactory.createXSecureId();
/*    */   }
/*    */   
/*    */   public abstract void setMac(byte[] paramArrayOfbyte) throws SQLException;
/*    */   
/*    */   public abstract void setMidtierId(byte[] paramArrayOfbyte) throws SQLException;
/*    */   
/*    */   public abstract void setNonce(long paramLong) throws SQLException;
/*    */   
/*    */   public abstract byte[] getMac();
/*    */   
/*    */   public abstract byte[] getMidtierId();
/*    */   
/*    */   public abstract long getNonce();
/*    */ }


/* Location:              C:\Users\olatu\OneDrive\Documents\Calypso\syncbase\sync_base.jar!\BOOT-INF\lib\ojdbc-7.jar!\oracle\jdbc\internal\XSSecureId.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */