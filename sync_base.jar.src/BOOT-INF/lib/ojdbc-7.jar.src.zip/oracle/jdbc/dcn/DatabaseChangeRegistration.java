package oracle.jdbc.dcn;

import java.sql.SQLException;
import java.util.concurrent.Executor;
import oracle.jdbc.NotificationRegistration;

public interface DatabaseChangeRegistration extends NotificationRegistration {
  int getRegistrationId();
  
  long getRegId();
  
  String[] getTables();
  
  void addListener(DatabaseChangeListener paramDatabaseChangeListener) throws SQLException;
  
  void addListener(DatabaseChangeListener paramDatabaseChangeListener, Executor paramExecutor) throws SQLException;
  
  void removeListener(DatabaseChangeListener paramDatabaseChangeListener) throws SQLException;
}


/* Location:              C:\Users\olatu\OneDrive\Documents\Calypso\syncbase\sync_base.jar!\BOOT-INF\lib\ojdbc-7.jar!\oracle\jdbc\dcn\DatabaseChangeRegistration.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */