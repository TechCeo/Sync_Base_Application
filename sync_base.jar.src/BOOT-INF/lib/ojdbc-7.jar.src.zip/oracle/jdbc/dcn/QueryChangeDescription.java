/*    */ package oracle.jdbc.dcn;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public interface QueryChangeDescription
/*    */ {
/*    */   long getQueryId();
/*    */   
/*    */   QueryChangeEventType getQueryChangeEventType();
/*    */   
/*    */   TableChangeDescription[] getTableChangeDescription();
/*    */   
/*    */   public enum QueryChangeEventType
/*    */   {
/* 54 */     DEREG(DatabaseChangeEvent.EventType.DEREG.getCode()),
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 59 */     QUERYCHANGE(DatabaseChangeEvent.EventType.QUERYCHANGE.getCode());
/*    */     private final int code;
/*    */     
/*    */     QueryChangeEventType(int param1Int1) {
/* 63 */       this.code = param1Int1;
/*    */     }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */     
/*    */     public final int getCode() {
/* 71 */       return this.code;
/*    */     }
/*    */ 
/*    */ 
/*    */ 
/*    */     
/*    */     public static final QueryChangeEventType getQueryChangeEventType(int param1Int) {
/* 78 */       if (param1Int == DEREG.getCode()) {
/* 79 */         return DEREG;
/*    */       }
/* 81 */       return QUERYCHANGE;
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\olatu\OneDrive\Documents\Calypso\syncbase\sync_base.jar!\BOOT-INF\lib\ojdbc-7.jar!\oracle\jdbc\dcn\QueryChangeDescription.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */