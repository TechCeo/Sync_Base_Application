/*     */ package oracle.jdbc.babelfish;
/*     */ 
/*     */ import java.lang.reflect.Method;
/*     */ import java.sql.CallableStatement;
/*     */ import java.sql.SQLException;
/*     */ import oracle.jdbc.OracleCallableStatement;
/*     */ import oracle.jdbc.proxy.annotation.GetCreator;
/*     */ import oracle.jdbc.proxy.annotation.GetDelegate;
/*     */ import oracle.jdbc.proxy.annotation.OnError;
/*     */ import oracle.jdbc.proxy.annotation.Post;
/*     */ import oracle.jdbc.proxy.annotation.ProxyFor;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @ProxyFor({OracleCallableStatement.class, CallableStatement.class})
/*     */ public abstract class BabelfishCallableStatement
/*     */   extends BabelfishPreparedStatement
/*     */ {
/*     */   @GetCreator
/*     */   protected abstract Object getCreator();
/*     */   
/*     */   @GetDelegate
/*     */   protected abstract Object getDelegate();
/*     */   
/*     */   @OnError(SQLException.class)
/*     */   protected Object translateError(Method paramMethod, SQLException paramSQLException) throws SQLException {
/*  79 */     throw this.translator.translateError(paramSQLException);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Post
/*     */   protected Object post_Methods(Method paramMethod, Object paramObject) {
/*  92 */     if (paramObject instanceof BabelfishGenericProxy)
/*     */     {
/*  94 */       ((BabelfishGenericProxy)paramObject).setTranslator(this.translator);
/*     */     }
/*  96 */     return paramObject;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void registerOutParameter(int paramInt1, int paramInt2) throws SQLException {
/* 111 */     ((OracleCallableStatement)getDelegate()).registerOutParameterAtName(NAMED_PARAMETER_PREFIX + paramInt1, paramInt2);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void registerOutParameter(int paramInt1, int paramInt2, int paramInt3) throws SQLException {
/* 128 */     ((OracleCallableStatement)getDelegate()).registerOutParameterAtName(NAMED_PARAMETER_PREFIX + paramInt1, paramInt2, paramInt3);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void registerOutParameter(int paramInt1, int paramInt2, String paramString) throws SQLException {
/* 146 */     ((OracleCallableStatement)getDelegate()).registerOutParameterAtName(NAMED_PARAMETER_PREFIX + paramInt1, paramInt2, paramString);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 226 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*     */   public static final String BUILD_DATE = "Thu_Apr_04_15:09:24_PDT_2013";
/*     */   public static final boolean TRACE = false;
/*     */ }


/* Location:              C:\Users\olatu\OneDrive\Documents\Calypso\syncbase\sync_base.jar!\BOOT-INF\lib\ojdbc-7.jar!\oracle\jdbc\babelfish\BabelfishCallableStatement.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */