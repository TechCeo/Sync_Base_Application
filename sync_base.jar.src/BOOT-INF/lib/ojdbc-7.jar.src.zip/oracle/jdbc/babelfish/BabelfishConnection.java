/*     */ package oracle.jdbc.babelfish;
/*     */ 
/*     */ import java.lang.reflect.Method;
/*     */ import java.sql.CallableStatement;
/*     */ import java.sql.Connection;
/*     */ import java.sql.PreparedStatement;
/*     */ import java.sql.SQLException;
/*     */ import java.sql.Statement;
/*     */ import java.util.EnumMap;
/*     */ import java.util.Map;
/*     */ import oracle.jdbc.OracleConnection;
/*     */ import oracle.jdbc.OracleTranslatingConnection;
/*     */ import oracle.jdbc.internal.OracleConnection;
/*     */ import oracle.jdbc.proxy.annotation.GetCreator;
/*     */ import oracle.jdbc.proxy.annotation.GetDelegate;
/*     */ import oracle.jdbc.proxy.annotation.OnError;
/*     */ import oracle.jdbc.proxy.annotation.Post;
/*     */ import oracle.jdbc.proxy.annotation.ProxyFor;
/*     */ import oracle.jdbc.proxy.annotation.ProxyLocale;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @ProxyFor({Connection.class, OracleConnection.class, OracleConnection.class})
/*     */ @ProxyLocale
/*     */ public abstract class BabelfishConnection
/*     */   extends BabelfishGenericProxy
/*     */   implements OracleTranslatingConnection
/*     */ {
/*     */   @GetCreator
/*     */   protected abstract Object getCreator();
/*     */   
/*     */   @GetDelegate
/*     */   protected abstract Object getDelegate();
/*     */   
/*     */   @OnError(SQLException.class)
/*     */   protected Object translateError(Method paramMethod, SQLException paramSQLException) throws SQLException {
/*  93 */     throw this.translator.translateError(paramSQLException);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Post
/*     */   protected Object post_Methods(Method paramMethod, Object paramObject) {
/* 106 */     if (paramObject instanceof BabelfishGenericProxy)
/*     */     {
/* 108 */       ((BabelfishGenericProxy)paramObject).setTranslator(this.translator);
/*     */     }
/* 110 */     return paramObject;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PreparedStatement prepareStatement(String paramString) throws SQLException {
/* 124 */     String str = this.translator.translateQuery(paramString);
/* 125 */     return ((Connection)getDelegate()).prepareStatement(str);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PreparedStatement prepareStatement(String paramString, int paramInt) throws SQLException {
/* 139 */     String str = this.translator.translateQuery(paramString);
/* 140 */     return ((Connection)getDelegate()).prepareStatement(str, paramInt);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PreparedStatement prepareStatement(String paramString, int[] paramArrayOfint) throws SQLException {
/* 154 */     String str = this.translator.translateQuery(paramString);
/* 155 */     return ((Connection)getDelegate()).prepareStatement(str, paramArrayOfint);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PreparedStatement prepareStatement(String paramString, String[] paramArrayOfString) throws SQLException {
/* 169 */     String str = this.translator.translateQuery(paramString);
/* 170 */     return ((Connection)getDelegate()).prepareStatement(str, paramArrayOfString);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PreparedStatement prepareStatement(String paramString, int paramInt1, int paramInt2) throws SQLException {
/* 184 */     String str = this.translator.translateQuery(paramString);
/* 185 */     return ((Connection)getDelegate()).prepareStatement(str, paramInt1, paramInt2);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PreparedStatement prepareStatement(String paramString, int paramInt1, int paramInt2, int paramInt3) throws SQLException {
/* 199 */     String str = this.translator.translateQuery(paramString);
/* 200 */     return ((Connection)getDelegate()).prepareStatement(str, paramInt1, paramInt2, paramInt3);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CallableStatement prepareCall(String paramString) throws SQLException {
/* 214 */     String str = this.translator.translateQuery(paramString);
/* 215 */     return ((Connection)getDelegate()).prepareCall(str);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CallableStatement prepareCall(String paramString, int paramInt1, int paramInt2) throws SQLException {
/* 229 */     String str = this.translator.translateQuery(paramString);
/* 230 */     return ((Connection)getDelegate()).prepareCall(str, paramInt1, paramInt2);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CallableStatement prepareCall(String paramString, int paramInt1, int paramInt2, int paramInt3) throws SQLException {
/* 244 */     String str = this.translator.translateQuery(paramString);
/* 245 */     return ((Connection)getDelegate()).prepareCall(str, paramInt1, paramInt2, paramInt3);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String nativeSQL(String paramString) throws SQLException {
/* 265 */     String str = this.translator.translateQuery(paramString);
/* 266 */     return ((Connection)getDelegate()).nativeSQL(str);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void close() throws SQLException {
/* 289 */     this.translator.deactivateServerTranslation();
/* 290 */     ((Connection)getDelegate()).close();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract Statement createStatement() throws SQLException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Statement createStatement(boolean paramBoolean) throws SQLException {
/*     */     Statement statement;
/* 319 */     if (!paramBoolean) {
/*     */       
/* 321 */       statement = ((Connection)getDelegate()).createStatement();
/*     */     }
/*     */     else {
/*     */       
/* 325 */       statement = createStatement();
/*     */     } 
/* 327 */     return statement;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract Statement createStatement(int paramInt1, int paramInt2) throws SQLException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Statement createStatement(int paramInt1, int paramInt2, boolean paramBoolean) throws SQLException {
/*     */     Statement statement;
/* 353 */     if (!paramBoolean) {
/*     */       
/* 355 */       statement = ((Connection)getDelegate()).createStatement(paramInt1, paramInt2);
/*     */     }
/*     */     else {
/*     */       
/* 359 */       statement = createStatement(paramInt1, paramInt2);
/*     */     } 
/* 361 */     return statement;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract Statement createStatement(int paramInt1, int paramInt2, int paramInt3) throws SQLException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Statement createStatement(int paramInt1, int paramInt2, int paramInt3, boolean paramBoolean) throws SQLException {
/*     */     Statement statement;
/* 387 */     if (!paramBoolean) {
/*     */       
/* 389 */       statement = ((Connection)getDelegate()).createStatement(paramInt1, paramInt2, paramInt3);
/*     */     }
/*     */     else {
/*     */       
/* 393 */       statement = createStatement(paramInt1, paramInt2, paramInt3);
/*     */     } 
/* 395 */     return statement;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PreparedStatement prepareStatement(String paramString, boolean paramBoolean) throws SQLException {
/*     */     PreparedStatement preparedStatement;
/* 414 */     if (!paramBoolean) {
/*     */       
/* 416 */       preparedStatement = ((Connection)getDelegate()).prepareStatement(paramString);
/*     */     }
/*     */     else {
/*     */       
/* 420 */       preparedStatement = prepareStatement(paramString);
/*     */     } 
/* 422 */     return preparedStatement;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PreparedStatement prepareStatement(String paramString, int paramInt, boolean paramBoolean) throws SQLException {
/*     */     PreparedStatement preparedStatement;
/* 440 */     if (!paramBoolean) {
/*     */       
/* 442 */       preparedStatement = ((Connection)getDelegate()).prepareStatement(paramString, paramInt);
/*     */     }
/*     */     else {
/*     */       
/* 446 */       preparedStatement = prepareStatement(paramString, paramInt);
/*     */     } 
/* 448 */     return preparedStatement;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PreparedStatement prepareStatement(String paramString, int[] paramArrayOfint, boolean paramBoolean) throws SQLException {
/*     */     PreparedStatement preparedStatement;
/* 467 */     if (!paramBoolean) {
/*     */       
/* 469 */       preparedStatement = ((Connection)getDelegate()).prepareStatement(paramString, paramArrayOfint);
/*     */     }
/*     */     else {
/*     */       
/* 473 */       preparedStatement = prepareStatement(paramString, paramArrayOfint);
/*     */     } 
/* 475 */     return preparedStatement;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PreparedStatement prepareStatement(String paramString, String[] paramArrayOfString, boolean paramBoolean) throws SQLException {
/*     */     PreparedStatement preparedStatement;
/* 494 */     if (!paramBoolean) {
/*     */       
/* 496 */       preparedStatement = ((Connection)getDelegate()).prepareStatement(paramString, paramArrayOfString);
/*     */     }
/*     */     else {
/*     */       
/* 500 */       preparedStatement = prepareStatement(paramString, paramArrayOfString);
/*     */     } 
/* 502 */     return preparedStatement;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PreparedStatement prepareStatement(String paramString, int paramInt1, int paramInt2, boolean paramBoolean) throws SQLException {
/*     */     PreparedStatement preparedStatement;
/* 521 */     if (!paramBoolean) {
/*     */       
/* 523 */       preparedStatement = ((Connection)getDelegate()).prepareStatement(paramString, paramInt1, paramInt2);
/*     */     }
/*     */     else {
/*     */       
/* 527 */       preparedStatement = prepareStatement(paramString, paramInt1, paramInt2);
/*     */     } 
/* 529 */     return preparedStatement;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PreparedStatement prepareStatement(String paramString, int paramInt1, int paramInt2, int paramInt3, boolean paramBoolean) throws SQLException {
/*     */     PreparedStatement preparedStatement;
/* 548 */     if (!paramBoolean) {
/*     */       
/* 550 */       preparedStatement = ((Connection)getDelegate()).prepareStatement(paramString, paramInt1, paramInt2, paramInt3);
/*     */     }
/*     */     else {
/*     */       
/* 554 */       preparedStatement = prepareStatement(paramString, paramInt1, paramInt2, paramInt3);
/*     */     } 
/* 556 */     return preparedStatement;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CallableStatement prepareCall(String paramString, boolean paramBoolean) throws SQLException {
/*     */     CallableStatement callableStatement;
/* 574 */     if (!paramBoolean) {
/*     */       
/* 576 */       callableStatement = ((Connection)getDelegate()).prepareCall(paramString);
/*     */     }
/*     */     else {
/*     */       
/* 580 */       callableStatement = prepareCall(paramString);
/*     */     } 
/* 582 */     return callableStatement;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CallableStatement prepareCall(String paramString, int paramInt1, int paramInt2, boolean paramBoolean) throws SQLException {
/*     */     CallableStatement callableStatement;
/* 600 */     if (!paramBoolean) {
/*     */       
/* 602 */       callableStatement = ((Connection)getDelegate()).prepareCall(paramString, paramInt1, paramInt2);
/*     */     }
/*     */     else {
/*     */       
/* 606 */       callableStatement = prepareCall(paramString, paramInt1, paramInt2);
/*     */     } 
/* 608 */     return callableStatement;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CallableStatement prepareCall(String paramString, int paramInt1, int paramInt2, int paramInt3, boolean paramBoolean) throws SQLException {
/*     */     CallableStatement callableStatement;
/* 626 */     if (!paramBoolean) {
/*     */       
/* 628 */       callableStatement = ((Connection)getDelegate()).prepareCall(paramString, paramInt1, paramInt2, paramInt3);
/*     */     }
/*     */     else {
/*     */       
/* 632 */       callableStatement = prepareCall(paramString, paramInt1, paramInt2, paramInt3);
/*     */     } 
/* 634 */     return callableStatement;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<OracleTranslatingConnection.SqlTranslationVersion, String> getSqlTranslationVersions(String paramString, boolean paramBoolean) throws SQLException {
/* 777 */     EnumMap<OracleTranslatingConnection.SqlTranslationVersion, Object> enumMap = new EnumMap<>(OracleTranslatingConnection.SqlTranslationVersion.class);
/* 778 */     enumMap.put(OracleTranslatingConnection.SqlTranslationVersion.ORIGINAL_SQL, paramString);
/*     */     
/* 780 */     String str = this.translator.convertParameterMarkersToOracleStyle(paramString);
/* 781 */     enumMap.put(OracleTranslatingConnection.SqlTranslationVersion.JDBC_MARKER_CONVERTED, str);
/*     */ 
/*     */     
/*     */     try {
/* 785 */       str = this.translator.translateQuery(paramString);
/* 786 */       enumMap.put(OracleTranslatingConnection.SqlTranslationVersion.TRANSLATED, str);
/*     */     }
/* 788 */     catch (SQLException sQLException) {
/*     */       
/* 790 */       if (paramBoolean) {
/*     */         
/* 792 */         enumMap.put(OracleTranslatingConnection.SqlTranslationVersion.TRANSLATED, null);
/*     */       }
/*     */       else {
/*     */         
/* 796 */         throw sQLException;
/*     */       } 
/*     */     } 
/*     */     
/* 800 */     return (Map)enumMap;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 806 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*     */   public static final String BUILD_DATE = "Thu_Apr_04_15:09:24_PDT_2013";
/*     */   public static final boolean TRACE = false;
/*     */ }


/* Location:              C:\Users\olatu\OneDrive\Documents\Calypso\syncbase\sync_base.jar!\BOOT-INF\lib\ojdbc-7.jar!\oracle\jdbc\babelfish\BabelfishConnection.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */