/*     */ package oracle.jdbc.babelfish;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.sql.SQLException;
/*     */ import java.util.Map;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import oracle.jdbc.driver.DatabaseError;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TranslationManager
/*     */ {
/*  49 */   private static final ConcurrentHashMap<String, TranslationCache> translationCacheRegistry = new ConcurrentHashMap<>();
/*  50 */   private static Map<String, String> defaultErrorFile = new ConcurrentHashMap<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final String SEPARATOR = "\000";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Translator getTranslator(String paramString1, String paramString2, String paramString3, String paramString4) throws SQLException {
/*  74 */     if (paramString4 == null)
/*     */     {
/*  76 */       if (defaultErrorFile.containsKey(paramString3))
/*     */       {
/*  78 */         paramString4 = defaultErrorFile.get(paramString3);
/*     */       }
/*     */     }
/*     */     
/*  82 */     File file = null;
/*     */     
/*  84 */     if (paramString4 != null) {
/*     */       
/*  86 */       file = new File(paramString4);
/*  87 */       if (!file.exists()) {
/*     */ 
/*     */         
/*  90 */         SQLException sQLException = DatabaseError.createSqlException(null, 277);
/*  91 */         sQLException.fillInStackTrace();
/*  92 */         throw sQLException;
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/*  97 */     assert !".*\000.*".matches(paramString1) && !".*\000.*".matches(paramString2) && !".*\000.*".matches(paramString3);
/*  98 */     String str = paramString1 + "\000" + paramString2 + "\000" + paramString3;
/*  99 */     TranslationCache translationCache = translationCacheRegistry.get(str);
/*     */     
/* 101 */     if (translationCache == null) {
/*     */       
/* 103 */       translationCache = new TranslationCache(file);
/* 104 */       translationCacheRegistry.putIfAbsent(str, translationCache);
/*     */     } 
/*     */     
/* 107 */     return new Translator(paramString3, file, translationCache);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 113 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*     */   public static final String BUILD_DATE = "Thu_Apr_04_15:09:24_PDT_2013";
/*     */   public static final boolean TRACE = false;
/*     */ }


/* Location:              C:\Users\olatu\OneDrive\Documents\Calypso\syncbase\sync_base.jar!\BOOT-INF\lib\ojdbc-7.jar!\oracle\jdbc\babelfish\TranslationManager.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */