/*    */ package oracle.jdbc.driver;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.sql.SQLException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class T4CTTIimplres
/*    */   extends T4CTTIMsg
/*    */ {
/*    */   OracleStatement statement;
/*    */   
/*    */   T4CTTIimplres(T4CConnection paramT4CConnection) {
/* 43 */     super(paramT4CConnection, (byte)27);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   void init(OracleStatement paramOracleStatement) {
/* 52 */     this.statement = paramOracleStatement;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   void readImplicitResultSet() throws IOException, SQLException {
/* 59 */     OracleStatement oracleStatement1 = this.statement;
/*    */     
/* 61 */     OracleStatement oracleStatement2 = this.connection.createImplicitResultSetStatement(oracleStatement1);
/*    */ 
/*    */ 
/*    */     
/* 65 */     T4CTTIdcb t4CTTIdcb = new T4CTTIdcb((T4CConnection)oracleStatement2.connection);
/* 66 */     t4CTTIdcb.init(oracleStatement2, 0);
/* 67 */     oracleStatement2.accessors = t4CTTIdcb.receive(oracleStatement2.accessors);
/* 68 */     oracleStatement2.numberOfDefinePositions = t4CTTIdcb.numuds;
/*    */ 
/*    */     
/* 71 */     oracleStatement2.needToSendOalToFetch = true;
/* 72 */     int i = (int)this.meg.unmarshalUB4();
/* 73 */     oracleStatement2.setCursorId(i);
/* 74 */     this.statement = oracleStatement1;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/* 79 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*    */   public static final String BUILD_DATE = "Thu_Apr_04_15:09:24_PDT_2013";
/*    */   public static final boolean TRACE = false;
/*    */ }


/* Location:              C:\Users\olatu\OneDrive\Documents\Calypso\syncbase\sync_base.jar!\BOOT-INF\lib\ojdbc-7.jar!\oracle\jdbc\driver\T4CTTIimplres.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */