/*     */ package oracle.jdbc.driver;
/*     */ 
/*     */ import oracle.jdbc.aq.AQMessageProperties;
/*     */ import oracle.jdbc.internal.JMSMessage;
/*     */ import oracle.jdbc.internal.JMSMessageProperties;
/*     */ import oracle.sql.TypeDescriptor;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class JMSMessageI
/*     */   implements JMSMessage
/*     */ {
/*     */   private byte[] payload;
/*  40 */   private byte[] messageId = null;
/*  41 */   private JMSMessageProperties jmsMessageProperties = null;
/*  42 */   private AQMessageProperties aqMessageProperties = null;
/*  43 */   private byte[] toid = TypeDescriptor.RAWTOID;
/*     */   
/*     */   private String typeName;
/*     */   
/*     */   JMSMessageI(JMSMessageProperties paramJMSMessageProperties) {
/*  48 */     this.jmsMessageProperties = paramJMSMessageProperties;
/*     */   }
/*     */ 
/*     */   
/*     */   public byte[] getMessageId() {
/*  53 */     return this.messageId;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setMessageId(byte[] paramArrayOfbyte) {
/*  58 */     this.messageId = paramArrayOfbyte;
/*     */   }
/*     */ 
/*     */   
/*     */   public byte[] getPayload() {
/*  63 */     return this.payload;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setPayload(byte[] paramArrayOfbyte) {
/*  68 */     this.payload = paramArrayOfbyte;
/*     */   }
/*     */ 
/*     */   
/*     */   public JMSMessageProperties getJMSMessageProperties() {
/*  73 */     return this.jmsMessageProperties;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setJMSMessageProperties(JMSMessageProperties paramJMSMessageProperties) {
/*  78 */     this.jmsMessageProperties = paramJMSMessageProperties;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setTypeName(String paramString) {
/*  84 */     this.typeName = paramString;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getTypeName() {
/*  89 */     return this.typeName;
/*     */   }
/*     */ 
/*     */   
/*     */   public byte[] getToid() {
/*  94 */     return this.toid;
/*     */   }
/*     */ 
/*     */   
/*     */   public AQMessageProperties getAQMessageProperties() {
/*  99 */     return this.aqMessageProperties;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setAQMessageProperties(AQMessageProperties paramAQMessageProperties) {
/* 104 */     this.aqMessageProperties = paramAQMessageProperties;
/*     */   }
/*     */ }


/* Location:              C:\Users\olatu\OneDrive\Documents\Calypso\syncbase\sync_base.jar!\BOOT-INF\lib\ojdbc-7.jar!\oracle\jdbc\driver\JMSMessageI.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */