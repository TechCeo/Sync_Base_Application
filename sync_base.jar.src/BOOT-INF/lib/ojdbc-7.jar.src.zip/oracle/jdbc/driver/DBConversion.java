/*      */ package oracle.jdbc.driver;
/*      */ 
/*      */ import java.io.InputStream;
/*      */ import java.io.Reader;
/*      */ import java.sql.SQLException;
/*      */ import oracle.jdbc.internal.OracleConnection;
/*      */ import oracle.jdbc.util.RepConversion;
/*      */ import oracle.sql.CharacterSet;
/*      */ import oracle.sql.converter.CharacterSetMetaData;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class DBConversion
/*      */ {
/*      */   public static final boolean DO_CONVERSION_WITH_REPLACEMENT = true;
/*      */   public static final short ORACLE8_PROD_VERSION = 8030;
/*      */   protected short serverNCharSetId;
/*      */   protected short serverCharSetId;
/*      */   protected short clientCharSetId;
/*      */   protected CharacterSet serverCharSet;
/*      */   protected CharacterSet serverNCharSet;
/*      */   protected CharacterSet clientCharSet;
/*      */   protected CharacterSet asciiCharSet;
/*      */   protected boolean isServerCharSetFixedWidth;
/*      */   protected boolean isServerNCharSetFixedWidth;
/*      */   protected int c2sNlsRatio;
/*      */   protected int s2cNlsRatio;
/*      */   protected int sMaxCharSize;
/*      */   protected int cMaxCharSize;
/*      */   protected int maxNCharSize;
/*      */   protected boolean isServerCSMultiByte;
/*      */   private boolean isStrictASCIIConversion;
/*      */   public static final short DBCS_CHARSET = -1;
/*      */   public static final short UCS2_CHARSET = -5;
/*      */   public static final short ASCII_CHARSET = 1;
/*      */   public static final short ISO_LATIN_1_CHARSET = 31;
/*      */   public static final short AL24UTFFSS_CHARSET = 870;
/*      */   public static final short UTF8_CHARSET = 871;
/*      */   public static final short AL32UTF8_CHARSET = 873;
/*      */   public static final short AL16UTF16_CHARSET = 2000;
/*      */   
/*      */   public DBConversion(short paramShort1, short paramShort2, short paramShort3, boolean paramBoolean) throws SQLException {
/*  115 */     this.isStrictASCIIConversion = paramBoolean;
/*  116 */     if (paramShort2 != -1)
/*      */     {
/*  118 */       init(paramShort1, paramShort2, paramShort3);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public DBConversion(short paramShort1, short paramShort2, short paramShort3) throws SQLException {
/*  127 */     this(paramShort1, paramShort2, paramShort3, false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void init(short paramShort1, short paramShort2, short paramShort3) throws SQLException {
/*  138 */     switch (paramShort2) {
/*      */       case -5:
/*      */       case 1:
/*      */       case 2:
/*      */       case 31:
/*      */       case 178:
/*      */       case 870:
/*      */       case 871:
/*      */       case 873:
/*      */         break;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       default:
/*  160 */         unexpectedCharset(paramShort2);
/*      */         break;
/*      */     } 
/*      */ 
/*      */     
/*  165 */     this.serverCharSetId = paramShort1;
/*  166 */     this.clientCharSetId = paramShort2;
/*  167 */     this.serverCharSet = CharacterSet.make(this.serverCharSetId);
/*      */     
/*  169 */     this.serverNCharSetId = paramShort3;
/*  170 */     this.serverNCharSet = CharacterSet.make(this.serverNCharSetId);
/*      */     
/*  172 */     this.clientCharSet = CharacterSet.make(this.clientCharSetId);
/*      */     
/*  174 */     this.c2sNlsRatio = CharacterSetMetaData.getRatio(paramShort1, paramShort2);
/*  175 */     this.s2cNlsRatio = CharacterSetMetaData.getRatio(paramShort2, paramShort1);
/*  176 */     this.sMaxCharSize = CharacterSetMetaData.getRatio(paramShort1, 1);
/*  177 */     this.cMaxCharSize = CharacterSetMetaData.getRatio(paramShort2, 1);
/*  178 */     this.maxNCharSize = CharacterSetMetaData.getRatio(paramShort3, 1);
/*      */     
/*  180 */     findFixedWidthInfo();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void findFixedWidthInfo() throws SQLException {
/*  191 */     this.isServerCharSetFixedWidth = CharacterSetMetaData.isFixedWidth(this.serverCharSetId);
/*  192 */     this.isServerNCharSetFixedWidth = CharacterSetMetaData.isFixedWidth(this.serverNCharSetId);
/*  193 */     this.isServerCSMultiByte = (this.sMaxCharSize > 1);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public short getServerCharSetId() {
/*  205 */     return this.serverCharSetId;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public short getNCharSetId() {
/*  217 */     return this.serverNCharSetId;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean IsNCharFixedWith() {
/*  226 */     return (this.serverNCharSetId == 2000);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public short getClientCharSet() {
/*  241 */     if (this.clientCharSetId == -1) {
/*  242 */       return this.serverCharSetId;
/*      */     }
/*  244 */     return this.clientCharSetId;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public CharacterSet getDbCharSetObj() {
/*  258 */     return this.serverCharSet;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public CharacterSet getDriverCharSetObj() {
/*  273 */     return this.clientCharSet;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public CharacterSet getDriverNCharSetObj() {
/*  281 */     return this.serverNCharSet;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   CharacterSet getCharacterSet(short paramShort) {
/*  292 */     if (paramShort == 2) {
/*  293 */       return getDriverNCharSetObj();
/*      */     }
/*  295 */     return getDriverCharSetObj();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final short findDriverCharSet(short paramShort1, short paramShort2) {
/*  358 */     short s = 0;
/*      */     
/*  360 */     switch (paramShort1)
/*      */     
/*      */     { 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 1:
/*      */       case 2:
/*      */       case 31:
/*      */       case 178:
/*      */       case 873:
/*  374 */         s = paramShort1;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  385 */         return s; }  s = (paramShort2 >= 8030) ? 871 : 870; return s;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final byte[] stringToDriverCharBytes(String paramString, short paramShort) throws SQLException {
/*  420 */     if (paramString == null)
/*      */     {
/*  422 */       return null;
/*      */     }
/*      */     
/*  425 */     byte[] arrayOfByte = null;
/*      */     
/*  427 */     switch (paramShort)
/*      */     
/*      */     { 
/*      */       
/*      */       case -5:
/*      */       case 2000:
/*  433 */         arrayOfByte = CharacterSet.stringToAL16UTF16Bytes(paramString);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  471 */         return arrayOfByte;case 1: case 2: arrayOfByte = CharacterSet.stringToASCII(paramString); return arrayOfByte;case 870: case 871: arrayOfByte = CharacterSet.stringToUTF(paramString); return arrayOfByte;case 873: arrayOfByte = CharacterSet.stringToAL32UTF8(paramString); return arrayOfByte; }  unexpectedCharset(paramShort); return arrayOfByte;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public byte[] StringToCharBytes(String paramString) throws SQLException {
/*  493 */     if (paramString.length() == 0) {
/*  494 */       return null;
/*      */     }
/*  496 */     switch (this.clientCharSetId) {
/*      */ 
/*      */       
/*      */       case -1:
/*  500 */         return this.serverCharSet.convertWithReplacement(paramString);
/*      */       
/*      */       case 2:
/*      */       case 31:
/*      */       case 178:
/*  505 */         return this.clientCharSet.convertWithReplacement(paramString);
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  513 */     return stringToDriverCharBytes(paramString, this.clientCharSetId);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String CharBytesToString(byte[] paramArrayOfbyte, int paramInt) throws SQLException {
/*  563 */     return CharBytesToString(paramArrayOfbyte, paramInt, true);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String CharBytesToString(byte[] paramArrayOfbyte, int paramInt, boolean paramBoolean) throws SQLException {
/*  572 */     String str = null;
/*  573 */     if (paramArrayOfbyte.length == 0) {
/*  574 */       return str;
/*      */     }
/*  576 */     switch (this.clientCharSetId)
/*      */     
/*      */     { 
/*      */       case -5:
/*  580 */         str = CharacterSet.AL16UTF16BytesToString(paramArrayOfbyte, paramInt);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  631 */         return str;case 1: str = new String(paramArrayOfbyte, 0, 0, paramInt); return str;case 2: case 31: case 178: if (paramBoolean) { str = this.clientCharSet.toStringWithReplacement(paramArrayOfbyte, 0, paramInt); } else { str = this.clientCharSet.toString(paramArrayOfbyte, 0, paramInt); }  return str;case 870: case 871: str = CharacterSet.UTFToString(paramArrayOfbyte, 0, paramInt, paramBoolean); return str;case 873: str = CharacterSet.AL32UTF8ToString(paramArrayOfbyte, 0, paramInt, paramBoolean); return str;case -1: str = this.serverCharSet.toStringWithReplacement(paramArrayOfbyte, 0, paramInt); return str; }  unexpectedCharset(this.clientCharSetId); return str;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String NCharBytesToString(byte[] paramArrayOfbyte, int paramInt) throws SQLException {
/*  639 */     String str = null;
/*      */     
/*  641 */     if (this.clientCharSetId == -1)
/*      */     
/*      */     { 
/*      */       
/*  645 */       str = this.serverNCharSet.toStringWithReplacement(paramArrayOfbyte, 0, paramInt); }
/*      */     
/*      */     else
/*      */     
/*  649 */     { switch (this.serverNCharSetId)
/*      */       
/*      */       { 
/*      */         
/*      */         case -5:
/*      */         case 2000:
/*  655 */           str = CharacterSet.AL16UTF16BytesToString(paramArrayOfbyte, paramInt);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  703 */           return str;case 1: case 2: str = new String(paramArrayOfbyte, 0, 0, paramInt); return str;case 31: case 178: str = this.serverNCharSet.toStringWithReplacement(paramArrayOfbyte, 0, paramInt); return str;case 870: case 871: str = CharacterSet.UTFToString(paramArrayOfbyte, 0, paramInt); return str;case 873: str = CharacterSet.AL32UTF8ToString(paramArrayOfbyte, 0, paramInt); return str;case -1: str = this.serverCharSet.toStringWithReplacement(paramArrayOfbyte, 0, paramInt); return str; }  unexpectedCharset(this.clientCharSetId); }  return str;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int javaCharsToCHARBytes(char[] paramArrayOfchar, int paramInt, byte[] paramArrayOfbyte) throws SQLException {
/*  730 */     return javaCharsToCHARBytes(paramArrayOfchar, paramInt, paramArrayOfbyte, this.clientCharSetId);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int javaCharsToCHARBytes(char[] paramArrayOfchar, int paramInt1, byte[] paramArrayOfbyte, int paramInt2, int paramInt3) throws SQLException {
/*  740 */     return javaCharsToCHARBytes(paramArrayOfchar, paramInt1, paramArrayOfbyte, paramInt2, this.clientCharSetId, paramInt3);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int javaCharsToNCHARBytes(char[] paramArrayOfchar, int paramInt, byte[] paramArrayOfbyte) throws SQLException {
/*  750 */     return javaCharsToCHARBytes(paramArrayOfchar, paramInt, paramArrayOfbyte, this.serverNCharSetId);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int javaCharsToNCHARBytes(char[] paramArrayOfchar, int paramInt1, byte[] paramArrayOfbyte, int paramInt2, int paramInt3) throws SQLException {
/*  760 */     return javaCharsToCHARBytes(paramArrayOfchar, paramInt1, paramArrayOfbyte, paramInt2, this.serverNCharSetId, paramInt3);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected int javaCharsToCHARBytes(char[] paramArrayOfchar, int paramInt, byte[] paramArrayOfbyte, short paramShort) throws SQLException {
/*  770 */     return javaCharsToCHARBytes(paramArrayOfchar, 0, paramArrayOfbyte, 0, paramShort, paramInt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected int javaCharsToCHARBytes(char[] paramArrayOfchar, int paramInt1, byte[] paramArrayOfbyte, int paramInt2, short paramShort, int paramInt3) throws SQLException {
/*      */     byte[] arrayOfByte;
/*  779 */     int i = 0;
/*      */     
/*  781 */     switch (paramShort)
/*      */     
/*      */     { 
/*      */ 
/*      */ 
/*      */       
/*      */       case -5:
/*      */       case 2000:
/*  789 */         i = CharacterSet.convertJavaCharsToAL16UTF16Bytes(paramArrayOfchar, paramInt1, paramArrayOfbyte, paramInt2, paramInt3);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  848 */         return i;case 2: case 178: arrayOfByte = this.clientCharSet.convertWithReplacement(new String(paramArrayOfchar, paramInt1, paramInt3)); System.arraycopy(arrayOfByte, 0, paramArrayOfbyte, 0, arrayOfByte.length); i = arrayOfByte.length; return i;case 1: i = CharacterSet.convertJavaCharsToASCIIBytes(paramArrayOfchar, paramInt1, paramArrayOfbyte, paramInt2, paramInt3, this.isStrictASCIIConversion); return i;case 31: i = CharacterSet.convertJavaCharsToISOLATIN1Bytes(paramArrayOfchar, paramInt1, paramArrayOfbyte, paramInt2, paramInt3); return i;case 870: case 871: i = CharacterSet.convertJavaCharsToUTFBytes(paramArrayOfchar, paramInt1, paramArrayOfbyte, paramInt2, paramInt3); return i;case 873: i = CharacterSet.convertJavaCharsToAL32UTF8Bytes(paramArrayOfchar, paramInt1, paramArrayOfbyte, paramInt2, paramInt3); return i;case -1: i = javaCharsToDbCsBytes(paramArrayOfchar, paramInt1, paramArrayOfbyte, paramInt2, paramInt3); return i; }  unexpectedCharset(this.clientCharSetId); return i;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int CHARBytesToJavaChars(byte[] paramArrayOfbyte, int paramInt1, char[] paramArrayOfchar, int paramInt2, int[] paramArrayOfint, int paramInt3, boolean paramBoolean) throws SQLException {
/*  879 */     if (paramBoolean) {
/*  880 */       return NCHARBytesToJavaChars(paramArrayOfbyte, paramInt1, paramArrayOfchar, paramInt2, paramArrayOfint, paramInt3);
/*      */     }
/*  882 */     return CHARBytesToJavaChars(paramArrayOfbyte, paramInt1, paramArrayOfchar, paramInt2, paramArrayOfint, paramInt3);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int CHARBytesToJavaChars(byte[] paramArrayOfbyte, int paramInt1, char[] paramArrayOfchar, int paramInt2, int[] paramArrayOfint, int paramInt3) throws SQLException {
/*  913 */     return _CHARBytesToJavaChars(paramArrayOfbyte, paramInt1, paramArrayOfchar, paramInt2, this.clientCharSetId, paramArrayOfint, paramInt3, this.serverCharSet, this.serverNCharSet, this.clientCharSet, false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int NCHARBytesToJavaChars(byte[] paramArrayOfbyte, int paramInt1, char[] paramArrayOfchar, int paramInt2, int[] paramArrayOfint, int paramInt3) throws SQLException {
/*  931 */     return _CHARBytesToJavaChars(paramArrayOfbyte, paramInt1, paramArrayOfchar, paramInt2, this.serverNCharSetId, paramArrayOfint, paramInt3, this.serverCharSet, this.serverNCharSet, this.clientCharSet, true);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static final int _CHARBytesToJavaChars(byte[] paramArrayOfbyte, int paramInt1, char[] paramArrayOfchar, int paramInt2, short paramShort, int[] paramArrayOfint, int paramInt3, CharacterSet paramCharacterSet1, CharacterSet paramCharacterSet2, CharacterSet paramCharacterSet3, boolean paramBoolean) throws SQLException {
/*  958 */     int i = 0;
/*  959 */     int j = 0;
/*      */     
/*  961 */     switch (paramShort)
/*      */     
/*      */     { 
/*      */       
/*      */       case -5:
/*      */       case 2000:
/*  967 */         j = paramArrayOfint[0] - paramArrayOfint[0] % 2;
/*      */ 
/*      */         
/*  970 */         if (paramInt3 > paramArrayOfchar.length - paramInt2) {
/*  971 */           paramInt3 = paramArrayOfchar.length - paramInt2;
/*      */         }
/*      */ 
/*      */         
/*  975 */         if (paramInt3 * 2 < j) {
/*  976 */           j = paramInt3 * 2;
/*      */         }
/*  978 */         i = CharacterSet.convertAL16UTF16BytesToJavaChars(paramArrayOfbyte, paramInt1, paramArrayOfchar, paramInt2, j, true);
/*      */ 
/*      */ 
/*      */         
/*  982 */         paramArrayOfint[0] = paramArrayOfint[0] - j;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1082 */         return i;case 1: j = paramArrayOfint[0]; if (paramInt3 > paramArrayOfchar.length - paramInt2) paramInt3 = paramArrayOfchar.length - paramInt2;  if (paramInt3 < j) j = paramInt3;  i = CharacterSet.convertASCIIBytesToJavaChars(paramArrayOfbyte, paramInt1, paramArrayOfchar, paramInt2, j); paramArrayOfint[0] = paramArrayOfint[0] - j; return i;case 31: case 178: j = paramArrayOfint[0]; i = paramCharacterSet1.toCharWithReplacement(paramArrayOfbyte, paramInt1, paramArrayOfchar, paramInt2, j); paramArrayOfint[0] = paramArrayOfint[0] - i; return i;case 870: case 871: if (paramInt3 > paramArrayOfchar.length - paramInt2) paramInt3 = paramArrayOfchar.length - paramInt2;  i = CharacterSet.convertUTFBytesToJavaChars(paramArrayOfbyte, paramInt1, paramArrayOfchar, paramInt2, paramArrayOfint, true, paramInt3); return i;case 873: if (paramInt3 > paramArrayOfchar.length - paramInt2) paramInt3 = paramArrayOfchar.length - paramInt2;  i = CharacterSet.convertAL32UTF8BytesToJavaChars(paramArrayOfbyte, paramInt1, paramArrayOfchar, paramInt2, paramArrayOfint, true, paramInt3); return i;case -1: unexpectedCharset((short)-1); return i; }  CharacterSet characterSet = paramCharacterSet3; if (paramBoolean) characterSet = paramCharacterSet2;  String str = characterSet.toStringWithReplacement(paramArrayOfbyte, paramInt1, paramArrayOfint[0]); char[] arrayOfChar = str.toCharArray(); int k = arrayOfChar.length; if (k > paramInt3) k = paramInt3;  i = k; paramArrayOfint[0] = paramArrayOfint[0] - k; System.arraycopy(arrayOfChar, 0, paramArrayOfchar, paramInt2, k); return i;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public byte[] asciiBytesToCHARBytes(byte[] paramArrayOfbyte) {
/*      */     byte b1, b2;
/* 1104 */     byte[] arrayOfByte = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1114 */     switch (this.clientCharSetId)
/*      */     
/*      */     { 
/*      */       case -5:
/* 1118 */         arrayOfByte = new byte[paramArrayOfbyte.length * 2];
/*      */         
/* 1120 */         for (b1 = 0, b2 = 0; b1 < paramArrayOfbyte.length; b1++) {
/*      */           
/* 1122 */           arrayOfByte[b2++] = 0;
/* 1123 */           arrayOfByte[b2++] = paramArrayOfbyte[b1];
/*      */         } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1149 */         return arrayOfByte;case -1: if (this.asciiCharSet == null) this.asciiCharSet = CharacterSet.make(1);  try { arrayOfByte = this.serverCharSet.convert(this.asciiCharSet, paramArrayOfbyte, 0, paramArrayOfbyte.length); } catch (SQLException sQLException) {} return arrayOfByte; }  arrayOfByte = paramArrayOfbyte; return arrayOfByte;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int javaCharsToDbCsBytes(char[] paramArrayOfchar, int paramInt, byte[] paramArrayOfbyte) throws SQLException {
/* 1186 */     return javaCharsToDbCsBytes(paramArrayOfchar, 0, paramArrayOfbyte, 0, paramInt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int javaCharsToDbCsBytes(char[] paramArrayOfchar, int paramInt1, byte[] paramArrayOfbyte, int paramInt2, int paramInt3) throws SQLException {
/* 1225 */     int i = 0;
/*      */ 
/*      */     
/* 1228 */     catchCharsLen(paramArrayOfchar, paramInt1, paramInt3);
/*      */     
/* 1230 */     String str = new String(paramArrayOfchar, paramInt1, paramInt3);
/* 1231 */     byte[] arrayOfByte = this.serverCharSet.convertWithReplacement(str);
/*      */     
/* 1233 */     str = null;
/*      */     
/* 1235 */     if (arrayOfByte != null) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1241 */       i = arrayOfByte.length;
/*      */       
/* 1243 */       catchBytesLen(paramArrayOfbyte, paramInt2, i);
/* 1244 */       System.arraycopy(arrayOfByte, 0, paramArrayOfbyte, paramInt2, i);
/*      */       
/* 1246 */       arrayOfByte = null;
/*      */     } 
/*      */     
/* 1249 */     return i;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final int javaCharsToUcs2Bytes(char[] paramArrayOfchar, int paramInt, byte[] paramArrayOfbyte) throws SQLException {
/* 1282 */     return javaCharsToUcs2Bytes(paramArrayOfchar, 0, paramArrayOfbyte, 0, paramInt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final int javaCharsToUcs2Bytes(char[] paramArrayOfchar, int paramInt1, byte[] paramArrayOfbyte, int paramInt2, int paramInt3) throws SQLException {
/* 1320 */     catchCharsLen(paramArrayOfchar, paramInt1, paramInt3);
/* 1321 */     catchBytesLen(paramArrayOfbyte, paramInt2, paramInt3 * 2);
/*      */     
/* 1323 */     int k = paramInt3 + paramInt1;
/*      */     int j;
/* 1325 */     for (int i = paramInt1; i < k; i++) {
/*      */       
/* 1327 */       paramArrayOfbyte[j++] = (byte)(paramArrayOfchar[i] >> 8 & 0xFF);
/* 1328 */       paramArrayOfbyte[j++] = (byte)(paramArrayOfchar[i] & 0xFF);
/*      */     } 
/*      */     
/* 1331 */     return j - paramInt2;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final int ucs2BytesToJavaChars(byte[] paramArrayOfbyte, int paramInt, char[] paramArrayOfchar) throws SQLException {
/* 1381 */     return CharacterSet.AL16UTF16BytesToJavaChars(paramArrayOfbyte, paramInt, paramArrayOfchar);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final byte[] stringToAsciiBytes(String paramString) {
/* 1403 */     return CharacterSet.stringToASCII(paramString);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final int asciiBytesToJavaChars(byte[] paramArrayOfbyte, int paramInt, char[] paramArrayOfchar) throws SQLException {
/* 1430 */     return CharacterSet.convertASCIIBytesToJavaChars(paramArrayOfbyte, 0, paramArrayOfchar, 0, paramInt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final int javaCharsToAsciiBytes(char[] paramArrayOfchar, int paramInt, byte[] paramArrayOfbyte) throws SQLException {
/* 1458 */     return CharacterSet.convertJavaCharsToASCIIBytes(paramArrayOfchar, 0, paramArrayOfbyte, 0, paramInt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final boolean isCharSetMultibyte(short paramShort) {
/* 1637 */     switch (paramShort) {
/*      */ 
/*      */ 
/*      */       
/*      */       case 1:
/*      */       case 31:
/* 1643 */         return false;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case -5:
/*      */       case -1:
/*      */       case 870:
/*      */       case 871:
/*      */       case 873:
/* 1654 */         return true;
/*      */     } 
/*      */     
/* 1657 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getMaxCharbyteSize() {
/* 1695 */     return _getMaxCharbyteSize(this.clientCharSetId);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getMaxNCharbyteSize() {
/* 1703 */     return _getMaxCharbyteSize(this.serverNCharSetId);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int _getMaxCharbyteSize(short paramShort) {
/* 1711 */     switch (paramShort) {
/*      */ 
/*      */       
/*      */       case 1:
/* 1715 */         return 1;
/*      */       
/*      */       case 31:
/* 1718 */         return 1;
/*      */ 
/*      */       
/*      */       case 870:
/*      */       case 871:
/* 1723 */         return 3;
/*      */ 
/*      */       
/*      */       case -5:
/*      */       case 2000:
/* 1728 */         return 2;
/*      */       
/*      */       case -1:
/* 1731 */         return 4;
/*      */       
/*      */       case 873:
/* 1734 */         return 4;
/*      */     } 
/*      */     
/* 1737 */     return 1;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isUcs2CharSet() {
/* 1748 */     return (this.clientCharSetId == -5);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final int RAWBytesToHexChars(byte[] paramArrayOfbyte, int paramInt, char[] paramArrayOfchar) {
/*      */     byte b2;
/* 1760 */     for (byte b1 = 0; b1 < paramInt; b1++) {
/*      */       
/* 1762 */       paramArrayOfchar[b2++] = (char)RepConversion.nibbleToHex((byte)(paramArrayOfbyte[b1] >> 4 & 0xF));
/*      */ 
/*      */       
/* 1765 */       paramArrayOfchar[b2++] = (char)RepConversion.nibbleToHex((byte)(paramArrayOfbyte[b1] & 0xF));
/*      */     } 
/*      */ 
/*      */     
/* 1769 */     return b2;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final int hexDigit2Nibble(char paramChar) throws SQLException {
/* 1785 */     int i = Character.digit(paramChar, 16);
/*      */     
/* 1787 */     if (i == -1) {
/*      */ 
/*      */       
/* 1790 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 59, "Invalid hex digit: " + paramChar);
/* 1791 */       sQLException.fillInStackTrace();
/* 1792 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/* 1796 */     return i;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final byte[] hexString2Bytes(String paramString) throws SQLException {
/* 1812 */     int i = paramString.length();
/* 1813 */     char[] arrayOfChar = new char[i];
/*      */     
/* 1815 */     paramString.getChars(0, i, arrayOfChar, 0);
/* 1816 */     return hexChars2Bytes(arrayOfChar, 0, i);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final byte[] hexChars2Bytes(char[] paramArrayOfchar, int paramInt1, int paramInt2) throws SQLException {
/*      */     byte[] arrayOfByte;
/* 1824 */     byte b = 0;
/* 1825 */     int i = paramInt1;
/*      */     
/* 1827 */     if (paramInt2 == 0) {
/* 1828 */       return new byte[0];
/*      */     }
/* 1830 */     if (paramInt2 % 2 > 0) {
/*      */       
/* 1832 */       arrayOfByte = new byte[(paramInt2 + 1) / 2];
/* 1833 */       arrayOfByte[b++] = (byte)hexDigit2Nibble(paramArrayOfchar[i++]);
/*      */     }
/*      */     else {
/*      */       
/* 1837 */       arrayOfByte = new byte[paramInt2 / 2];
/*      */     } 
/*      */     
/* 1840 */     for (; b < arrayOfByte.length; b++)
/*      */     {
/* 1842 */       arrayOfByte[b] = (byte)(hexDigit2Nibble(paramArrayOfchar[i++]) << 4 | hexDigit2Nibble(paramArrayOfchar[i++]));
/*      */     }
/*      */     
/* 1845 */     return arrayOfByte;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public InputStream ConvertStream(InputStream paramInputStream, int paramInt) {
/* 1854 */     return new OracleConversionInputStream(this, paramInputStream, paramInt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public InputStream ConvertStream(InputStream paramInputStream, int paramInt1, int paramInt2) {
/* 1863 */     return new OracleConversionInputStream(this, paramInputStream, paramInt1, paramInt2);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public InputStream ConvertStreamInternal(InputStream paramInputStream, int paramInt1, int paramInt2) {
/* 1872 */     return new OracleConversionInputStreamInternal(this, paramInputStream, paramInt1, paramInt2);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public InputStream ConvertStream(Reader paramReader, int paramInt1, int paramInt2, short paramShort) {
/* 1894 */     return new OracleConversionInputStream(this, paramReader, paramInt1, paramInt2, paramShort);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public InputStream ConvertStreamInternal(Reader paramReader, int paramInt1, int paramInt2, short paramShort) {
/* 1906 */     return new OracleConversionInputStreamInternal(this, paramReader, paramInt1, paramInt2, paramShort);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Reader ConvertCharacterStream(InputStream paramInputStream, int paramInt) throws SQLException {
/* 1919 */     return new OracleConversionReader(this, paramInputStream, paramInt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Reader ConvertCharacterStream(InputStream paramInputStream, int paramInt, short paramShort) throws SQLException {
/* 1928 */     OracleConversionReader oracleConversionReader = new OracleConversionReader(this, paramInputStream, paramInt);
/*      */ 
/*      */     
/* 1931 */     oracleConversionReader.setFormOfUse(paramShort);
/*      */     
/* 1933 */     return oracleConversionReader;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public InputStream CharsToStream(char[] paramArrayOfchar, int paramInt1, int paramInt2, int paramInt3) throws SQLException {
/* 1942 */     if (paramInt3 == 10) {
/* 1943 */       return new AsciiStream(paramArrayOfchar, paramInt1, paramInt2);
/*      */     }
/* 1945 */     if (paramInt3 == 11) {
/* 1946 */       return new UnicodeStream(paramArrayOfchar, paramInt1, paramInt2);
/*      */     }
/*      */     
/* 1949 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 39, "unknownConversion");
/* 1950 */     sQLException.fillInStackTrace();
/* 1951 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   class AsciiStream
/*      */     extends OracleBufferedStream
/*      */   {
/*      */     AsciiStream(char[] param1ArrayOfchar, int param1Int1, int param1Int2) {
/* 1961 */       super(param1Int2);
/* 1962 */       this.currentBufferSize = this.initialBufferSize;
/* 1963 */       this.resizableBuffer = new byte[this.currentBufferSize];
/*      */       
/* 1965 */       if (DBConversion.this.serverCharSetId == 1 || !DBConversion.this.isStrictASCIIConversion) {
/*      */         int i; byte b;
/* 1967 */         for (i = param1Int1, b = 0; b < param1Int2; b++) {
/* 1968 */           this.resizableBuffer[b] = (byte)param1ArrayOfchar[i++];
/*      */         }
/*      */       } else {
/*      */         
/* 1972 */         if (DBConversion.this.asciiCharSet == null)
/* 1973 */           DBConversion.this.asciiCharSet = CharacterSet.make(1); 
/* 1974 */         this.resizableBuffer = DBConversion.this.asciiCharSet.convertWithReplacement(new String(param1ArrayOfchar, param1Int1, param1Int2));
/*      */       } 
/*      */       
/* 1977 */       this.count = param1Int2;
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean needBytes() {
/* 1982 */       return (!this.closed && this.pos < this.count);
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean needBytes(int param1Int) {
/* 1987 */       return (!this.closed && this.pos < this.count);
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   class UnicodeStream
/*      */     extends OracleBufferedStream
/*      */   {
/*      */     UnicodeStream(char[] param1ArrayOfchar, int param1Int1, int param1Int2) {
/* 1996 */       super(param1Int2);
/* 1997 */       this.currentBufferSize = this.initialBufferSize;
/* 1998 */       this.resizableBuffer = new byte[this.currentBufferSize]; int i;
/*      */       byte b;
/* 2000 */       for (i = param1Int1, b = 0; b < param1Int2; ) {
/*      */         
/* 2002 */         char c = param1ArrayOfchar[i++];
/*      */         
/* 2004 */         this.resizableBuffer[b++] = (byte)(c >> 8 & 0xFF);
/* 2005 */         this.resizableBuffer[b++] = (byte)(c & 0xFF);
/*      */       } 
/*      */       
/* 2008 */       this.count = param1Int2;
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean needBytes() {
/* 2013 */       return (!this.closed && this.pos < this.count);
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean needBytes(int param1Int) {
/* 2018 */       return (!this.closed && this.pos < this.count);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static final void unexpectedCharset(short paramShort) throws SQLException {
/* 2036 */     SQLException sQLException = DatabaseError.createSqlException((OracleConnection)null, 35, "DBConversion");
/* 2037 */     sQLException.fillInStackTrace();
/* 2038 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected static final void catchBytesLen(byte[] paramArrayOfbyte, int paramInt1, int paramInt2) throws SQLException {
/* 2069 */     if (paramInt1 + paramInt2 > paramArrayOfbyte.length) {
/*      */ 
/*      */       
/* 2072 */       SQLException sQLException = DatabaseError.createSqlException((OracleConnection)null, 39, "catchBytesLen");
/* 2073 */       sQLException.fillInStackTrace();
/* 2074 */       throw sQLException;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected static final void catchCharsLen(char[] paramArrayOfchar, int paramInt1, int paramInt2) throws SQLException {
/* 2105 */     if (paramInt1 + paramInt2 > paramArrayOfchar.length) {
/*      */ 
/*      */       
/* 2108 */       SQLException sQLException = DatabaseError.createSqlException((OracleConnection)null, 39, "catchCharsLen");
/* 2109 */       sQLException.fillInStackTrace();
/* 2110 */       throw sQLException;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final int getUtfLen(char paramChar) {
/* 2127 */     byte b = 0;
/*      */     
/* 2129 */     if ((paramChar & 0xFF80) == 0) {
/*      */       
/* 2131 */       b = 1;
/*      */     }
/* 2133 */     else if ((paramChar & 0xF800) == 0) {
/*      */       
/* 2135 */       b = 2;
/*      */     }
/*      */     else {
/*      */       
/* 2139 */       b = 3;
/*      */     } 
/*      */     
/* 2142 */     return b;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   int encodedByteLength(String paramString, boolean paramBoolean) {
/* 2158 */     int i = 0;
/* 2159 */     if (paramString != null) {
/*      */       
/* 2161 */       i = paramString.length();
/* 2162 */       if (i != 0)
/*      */       {
/* 2164 */         if (paramBoolean) {
/*      */           
/* 2166 */           i = this.isServerNCharSetFixedWidth ? (i * this.maxNCharSize) : this.serverNCharSet.encodedByteLength(paramString);
/*      */         }
/*      */         else {
/*      */           
/* 2170 */           i = this.isServerCharSetFixedWidth ? (i * this.sMaxCharSize) : this.serverCharSet.encodedByteLength(paramString);
/*      */         } 
/*      */       }
/*      */     } 
/* 2174 */     return i;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   int encodedByteLength(char[] paramArrayOfchar, boolean paramBoolean) {
/* 2189 */     int i = 0;
/* 2190 */     if (paramArrayOfchar != null) {
/*      */       
/* 2192 */       i = paramArrayOfchar.length;
/* 2193 */       if (i != 0)
/*      */       {
/* 2195 */         if (paramBoolean) {
/*      */           
/* 2197 */           i = this.isServerNCharSetFixedWidth ? (i * this.maxNCharSize) : this.serverNCharSet.encodedByteLength(paramArrayOfchar);
/*      */         }
/*      */         else {
/*      */           
/* 2201 */           i = this.isServerCharSetFixedWidth ? (i * this.sMaxCharSize) : this.serverCharSet.encodedByteLength(paramArrayOfchar);
/*      */         } 
/*      */       }
/*      */     } 
/* 2205 */     return i;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected OracleConnection getConnectionDuringExceptionHandling() {
/* 2220 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 2249 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*      */   public static final String BUILD_DATE = "Thu_Apr_04_15:09:24_PDT_2013";
/*      */   public static final boolean TRACE = false;
/*      */ }


/* Location:              C:\Users\olatu\OneDrive\Documents\Calypso\syncbase\sync_base.jar!\BOOT-INF\lib\ojdbc-7.jar!\oracle\jdbc\driver\DBConversion.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */