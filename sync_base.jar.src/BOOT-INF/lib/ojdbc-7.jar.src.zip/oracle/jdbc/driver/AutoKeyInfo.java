/*     */ package oracle.jdbc.driver;
/*     */ 
/*     */ import java.sql.SQLException;
/*     */ import oracle.jdbc.internal.OracleStatement;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class AutoKeyInfo
/*     */   extends OracleResultSetMetaData
/*     */ {
/*     */   String originalSql;
/*     */   String newSql;
/*     */   String tableName;
/*  25 */   OracleStatement.SqlKind sqlKind = OracleStatement.SqlKind.UNINITIALIZED;
/*     */   
/*     */   int sqlParserParamCount;
/*     */   
/*     */   String[] sqlParserParamList;
/*     */   
/*     */   boolean useNamedParameter;
/*     */   
/*     */   int current_argument;
/*     */   
/*     */   String[] columnNames;
/*     */   
/*     */   int[] columnIndexes;
/*     */   
/*     */   int numColumns;
/*     */   
/*     */   String[] tableColumnNames;
/*     */   
/*     */   int[] tableColumnTypes;
/*     */   
/*     */   int[] tableMaxLengths;
/*     */   
/*     */   boolean[] tableNullables;
/*     */   short[] tableFormOfUses;
/*     */   int[] tablePrecisions;
/*     */   int[] tableScales;
/*     */   String[] tableTypeNames;
/*     */   int autoKeyType;
/*     */   static final int KEYFLAG = 0;
/*     */   static final int COLUMNAME = 1;
/*     */   static final int COLUMNINDEX = 2;
/*     */   static final char QMARK = '?';
/*     */   int[] returnTypes;
/*     */   Accessor[] returnAccessors;
/*     */   
/*     */   AutoKeyInfo(String paramString) {
/*  61 */     this.originalSql = paramString;
/*  62 */     this.autoKeyType = 0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   AutoKeyInfo(String paramString, String[] paramArrayOfString) {
/*  69 */     this.originalSql = paramString;
/*  70 */     this.columnNames = paramArrayOfString;
/*  71 */     this.autoKeyType = 1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   AutoKeyInfo(String paramString, int[] paramArrayOfint) {
/*  78 */     this.originalSql = paramString;
/*  79 */     this.columnIndexes = paramArrayOfint;
/*  80 */     this.autoKeyType = 2;
/*     */   }
/*     */ 
/*     */   
/*     */   private void parseSql() throws SQLException {
/*  85 */     if (this.originalSql == null) {
/*     */       
/*  87 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/*  88 */       sQLException.fillInStackTrace();
/*  89 */       throw sQLException;
/*     */     } 
/*     */     
/*  92 */     OracleSql oracleSql = SQL_PARSER.get();
/*  93 */     oracleSql.initialize(this.originalSql);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 107 */     this.sqlKind = oracleSql.getSqlKind();
/*     */ 
/*     */     
/* 110 */     if (this.sqlKind == OracleStatement.SqlKind.INSERT) {
/*     */       
/* 112 */       this.sqlParserParamCount = oracleSql.getParameterCount();
/* 113 */       this.sqlParserParamList = oracleSql.getParameterList();
/*     */       
/* 115 */       if (this.sqlParserParamList == OracleSql.EMPTY_LIST) {
/* 116 */         this.useNamedParameter = false;
/*     */       } else {
/*     */         
/* 119 */         this.useNamedParameter = true;
/*     */         
/* 121 */         this.current_argument = this.sqlParserParamCount;
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String generateUniqueNamedParameter() {
/*     */     boolean bool;
/*     */     String str;
/*     */     do {
/* 133 */       bool = false;
/* 134 */       str = Integer.toString(++this.current_argument).intern();
/*     */       
/* 136 */       for (byte b = 0; b < this.sqlParserParamCount; b++) {
/*     */         
/* 138 */         if (this.sqlParserParamList[b] == str) {
/*     */           
/* 140 */           bool = true;
/*     */           break;
/*     */         } 
/*     */       } 
/* 144 */     } while (bool);
/*     */     
/* 146 */     return ":" + str;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   String getNewSql() throws SQLException {
/*     */     try {
/* 158 */       if (this.newSql != null) return this.newSql;
/*     */       
/* 160 */       if (this.sqlKind == OracleStatement.SqlKind.UNINITIALIZED) parseSql();
/*     */       
/* 162 */       switch (this.autoKeyType) {
/*     */         
/*     */         case 0:
/* 165 */           this.newSql = this.originalSql + " RETURNING ROWID INTO " + (this.useNamedParameter ? generateUniqueNamedParameter() : (String)Character.valueOf('?'));
/*     */           
/* 167 */           this.returnTypes = new int[1];
/* 168 */           this.returnTypes[0] = 104;
/*     */           break;
/*     */         case 1:
/* 171 */           getNewSqlByColumnName();
/*     */           break;
/*     */         case 2:
/* 174 */           getNewSqlByColumnIndexes();
/*     */           break;
/*     */       } 
/*     */ 
/*     */       
/* 179 */       this.sqlKind = OracleStatement.SqlKind.UNINITIALIZED;
/* 180 */       this.sqlParserParamList = null;
/* 181 */       return this.newSql;
/*     */     }
/* 183 */     catch (Exception exception) {
/*     */ 
/*     */       
/* 186 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), exception);
/* 187 */       sQLException.fillInStackTrace();
/* 188 */       throw sQLException;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String getNewSqlByColumnName() throws SQLException {
/* 196 */     this.returnTypes = new int[this.columnNames.length];
/*     */ 
/*     */     
/* 199 */     this.columnIndexes = new int[this.columnNames.length];
/*     */     
/* 201 */     StringBuffer stringBuffer = new StringBuffer(this.originalSql);
/* 202 */     stringBuffer.append(" RETURNING ");
/*     */     
/*     */     byte b;
/* 205 */     for (b = 0; b < this.columnNames.length; b++) {
/*     */       
/* 207 */       int i = getReturnParamTypeCode(b, this.columnNames[b], this.columnIndexes);
/* 208 */       this.returnTypes[b] = i;
/*     */       
/* 210 */       stringBuffer.append(this.columnNames[b]);
/*     */       
/* 212 */       if (b < this.columnNames.length - 1) stringBuffer.append(", ");
/*     */     
/*     */     } 
/* 215 */     stringBuffer.append(" INTO ");
/*     */     
/* 217 */     for (b = 0; b < this.columnNames.length - 1; b++)
/*     */     {
/* 219 */       stringBuffer.append((this.useNamedParameter ? generateUniqueNamedParameter() : (String)Character.valueOf('?')) + ", ");
/*     */     }
/*     */     
/* 222 */     stringBuffer.append(this.useNamedParameter ? generateUniqueNamedParameter() : Character.valueOf('?'));
/*     */     
/* 224 */     this.newSql = new String(stringBuffer);
/* 225 */     return this.newSql;
/*     */   }
/*     */ 
/*     */   
/*     */   private String getNewSqlByColumnIndexes() throws SQLException {
/* 230 */     this.returnTypes = new int[this.columnIndexes.length];
/*     */     
/* 232 */     StringBuffer stringBuffer = new StringBuffer(this.originalSql);
/* 233 */     stringBuffer.append(" RETURNING ");
/*     */ 
/*     */     
/*     */     byte b;
/*     */     
/* 238 */     for (b = 0; b < this.columnIndexes.length; b++) {
/*     */       
/* 240 */       int j = this.columnIndexes[b] - 1;
/* 241 */       if (j < 0 || j > this.tableColumnNames.length) {
/*     */ 
/*     */         
/* 244 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/* 245 */         sQLException.fillInStackTrace();
/* 246 */         throw sQLException;
/*     */       } 
/*     */ 
/*     */       
/* 250 */       int i = this.tableColumnTypes[j];
/* 251 */       String str = this.tableColumnNames[j];
/* 252 */       this.returnTypes[b] = i;
/*     */       
/* 254 */       stringBuffer.append(str);
/*     */       
/* 256 */       if (b < this.columnIndexes.length - 1) stringBuffer.append(", ");
/*     */     
/*     */     } 
/* 259 */     stringBuffer.append(" INTO ");
/*     */     
/* 261 */     for (b = 0; b < this.columnIndexes.length - 1; b++)
/*     */     {
/* 263 */       stringBuffer.append((this.useNamedParameter ? generateUniqueNamedParameter() : (String)Character.valueOf('?')) + ", ");
/*     */     }
/*     */     
/* 266 */     stringBuffer.append(this.useNamedParameter ? generateUniqueNamedParameter() : Character.valueOf('?'));
/*     */     
/* 268 */     this.newSql = new String(stringBuffer);
/* 269 */     return this.newSql;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final int getReturnParamTypeCode(int paramInt, String paramString, int[] paramArrayOfint) throws SQLException {
/* 277 */     for (byte b = 0; b < this.tableColumnNames.length; b++) {
/*     */       
/* 279 */       if (paramString.equalsIgnoreCase(this.tableColumnNames[b])) {
/*     */         
/* 281 */         paramArrayOfint[paramInt] = b + 1;
/* 282 */         return this.tableColumnTypes[b];
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 288 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/* 289 */     sQLException.fillInStackTrace();
/* 290 */     throw sQLException;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/* 295 */   private static final ThreadLocal<OracleSql> SQL_PARSER = new ThreadLocal<OracleSql>() {
/*     */       protected OracleSql initialValue() {
/* 297 */         return new OracleSql(null);
/*     */       }
/*     */     };
/*     */ 
/*     */   
/*     */   final boolean isInsertSqlStmt() throws SQLException {
/* 303 */     if (this.sqlKind == OracleStatement.SqlKind.UNINITIALIZED) {
/* 304 */       parseSql();
/*     */     }
/* 306 */     return (this.sqlKind == OracleStatement.SqlKind.INSERT);
/*     */   }
/*     */ 
/*     */   
/*     */   String getTableName() throws SQLException {
/* 311 */     if (this.tableName != null) return this.tableName;
/*     */     
/* 313 */     String str = this.originalSql.trim().toUpperCase();
/*     */     
/* 315 */     int i = str.indexOf("INSERT");
/* 316 */     i = str.indexOf("INTO", i);
/*     */     
/* 318 */     if (i < 0) {
/*     */       
/* 320 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/* 321 */       sQLException.fillInStackTrace();
/* 322 */       throw sQLException;
/*     */     } 
/*     */     
/* 325 */     int j = str.length();
/* 326 */     int k = i + 5;
/*     */     
/* 328 */     for (; k < j && str.charAt(k) == ' '; k++);
/*     */     
/* 330 */     if (k >= j) {
/*     */       
/* 332 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/* 333 */       sQLException.fillInStackTrace();
/* 334 */       throw sQLException;
/*     */     } 
/*     */     
/* 337 */     int m = k + 1;
/*     */     
/* 339 */     while (m < j && str.charAt(m) != ' ' && str.charAt(m) != '(') {
/* 340 */       m++;
/*     */     }
/* 342 */     if (k == m - 1) {
/*     */       
/* 344 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/* 345 */       sQLException.fillInStackTrace();
/* 346 */       throw sQLException;
/*     */     } 
/*     */     
/* 349 */     this.tableName = str.substring(k, m);
/*     */     
/* 351 */     return this.tableName;
/*     */   }
/*     */ 
/*     */   
/*     */   void allocateSpaceForDescribedData(int paramInt) throws SQLException {
/* 356 */     this.numColumns = paramInt;
/*     */     
/* 358 */     this.tableColumnNames = new String[paramInt];
/* 359 */     this.tableColumnTypes = new int[paramInt];
/* 360 */     this.tableMaxLengths = new int[paramInt];
/* 361 */     this.tableNullables = new boolean[paramInt];
/* 362 */     this.tableFormOfUses = new short[paramInt];
/* 363 */     this.tablePrecisions = new int[paramInt];
/* 364 */     this.tableScales = new int[paramInt];
/* 365 */     this.tableTypeNames = new String[paramInt];
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void fillDescribedData(int paramInt1, String paramString1, int paramInt2, int paramInt3, boolean paramBoolean, short paramShort, int paramInt4, int paramInt5, String paramString2) throws SQLException {
/* 373 */     this.tableColumnNames[paramInt1] = paramString1;
/* 374 */     this.tableColumnTypes[paramInt1] = paramInt2;
/* 375 */     this.tableMaxLengths[paramInt1] = paramInt3;
/* 376 */     this.tableNullables[paramInt1] = paramBoolean;
/* 377 */     this.tableFormOfUses[paramInt1] = paramShort;
/* 378 */     this.tablePrecisions[paramInt1] = paramInt4;
/* 379 */     this.tableScales[paramInt1] = paramInt5;
/* 380 */     this.tableTypeNames[paramInt1] = paramString2;
/*     */   }
/*     */   
/*     */   void initMetaData(OracleResultSet paramOracleResultSet) throws SQLException {
/* 384 */     if (this.returnAccessors != null)
/*     */       return; 
/* 386 */     this.returnAccessors = (paramOracleResultSet.getOracleStatement()).accessors;
/*     */ 
/*     */     
/* 389 */     switch (this.autoKeyType) {
/*     */       
/*     */       case 0:
/* 392 */         initMetaDataKeyFlag();
/*     */         break;
/*     */       case 1:
/*     */       case 2:
/* 396 */         initMetaDataColumnIndexes();
/*     */         break;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   void initMetaDataKeyFlag() throws SQLException {
/* 404 */     (this.returnAccessors[0]).columnName = "ROWID";
/* 405 */     (this.returnAccessors[0]).describeType = 104;
/* 406 */     (this.returnAccessors[0]).describeMaxLength = 4;
/* 407 */     (this.returnAccessors[0]).nullable = true;
/* 408 */     (this.returnAccessors[0]).precision = 0;
/* 409 */     (this.returnAccessors[0]).scale = 0;
/* 410 */     (this.returnAccessors[0]).formOfUse = 0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void initMetaDataColumnIndexes() throws SQLException {
/* 418 */     for (byte b = 0; b < this.returnAccessors.length; b++) {
/*     */       
/* 420 */       Accessor accessor = this.returnAccessors[b];
/* 421 */       int i = this.columnIndexes[b] - 1;
/*     */       
/* 423 */       accessor.columnName = this.tableColumnNames[i];
/* 424 */       accessor.describeType = this.tableColumnTypes[i];
/* 425 */       accessor.describeMaxLength = this.tableMaxLengths[i];
/* 426 */       accessor.nullable = this.tableNullables[i];
/* 427 */       accessor.precision = this.tablePrecisions[i];
/* 428 */       accessor.scale = this.tablePrecisions[i];
/* 429 */       accessor.formOfUse = this.tableFormOfUses[i];
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   int getValidColumnIndex(int paramInt) throws SQLException {
/* 439 */     if (paramInt <= 0 || paramInt > this.returnAccessors.length) {
/*     */       
/* 441 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 442 */       sQLException.fillInStackTrace();
/* 443 */       throw sQLException;
/*     */     } 
/*     */     
/* 446 */     return paramInt - 1;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getColumnCount() throws SQLException {
/* 451 */     return this.returnAccessors.length;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getColumnName(int paramInt) throws SQLException {
/* 457 */     if (paramInt <= 0 || paramInt > this.returnAccessors.length) {
/*     */       
/* 459 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 460 */       sQLException.fillInStackTrace();
/* 461 */       throw sQLException;
/*     */     } 
/*     */     
/* 464 */     return (this.returnAccessors[paramInt - 1]).columnName;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getTableName(int paramInt) throws SQLException {
/* 470 */     if (paramInt <= 0 || paramInt > this.returnAccessors.length) {
/*     */       
/* 472 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 473 */       sQLException.fillInStackTrace();
/* 474 */       throw sQLException;
/*     */     } 
/*     */     
/* 477 */     return getTableName();
/*     */   }
/*     */ 
/*     */   
/*     */   Accessor[] getDescription() throws SQLException {
/* 482 */     return this.returnAccessors;
/*     */   }
/*     */ 
/*     */   
/* 486 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*     */   public static final String BUILD_DATE = "Thu_Apr_04_15:09:24_PDT_2013";
/*     */   public static final boolean TRACE = false;
/*     */ }


/* Location:              C:\Users\olatu\OneDrive\Documents\Calypso\syncbase\sync_base.jar!\BOOT-INF\lib\ojdbc-7.jar!\oracle\jdbc\driver\AutoKeyInfo.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */