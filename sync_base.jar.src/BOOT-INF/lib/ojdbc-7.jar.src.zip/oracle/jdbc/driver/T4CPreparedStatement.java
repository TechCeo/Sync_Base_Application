/*      */ package oracle.jdbc.driver;
/*      */ 
/*      */ import java.io.IOException;
/*      */ import java.sql.SQLException;
/*      */ import oracle.jdbc.OracleConnection;
/*      */ import oracle.jdbc.internal.OracleStatement;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ class T4CPreparedStatement
/*      */   extends OraclePreparedStatement
/*      */ {
/*      */   T4CPreparedStatement(PhysicalConnection paramPhysicalConnection, String paramString, int paramInt1, int paramInt2) throws SQLException {
/*   28 */     super(paramPhysicalConnection, paramString, paramPhysicalConnection.defaultExecuteBatch, paramPhysicalConnection.defaultRowPrefetch, paramInt1, paramInt2);
/*      */ 
/*      */     
/*   31 */     this.nbPostPonedColumns = new int[1];
/*   32 */     this.nbPostPonedColumns[0] = 0;
/*   33 */     this.indexOfPostPonedColumn = new int[1][3];
/*   34 */     this.t4Connection = (T4CConnection)paramPhysicalConnection;
/*      */     
/*   36 */     this.theRowidBinder = theStaticT4CRowidBinder;
/*   37 */     this.theRowidNullBinder = theStaticT4CRowidNullBinder;
/*   38 */     this.theURowidBinder = theStaticT4CURowidBinder;
/*   39 */     this.theURowidNullBinder = theStaticT4CURowidNullBinder;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*   46 */   static final byte[] EMPTY_BYTE = new byte[0];
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   T4CConnection t4Connection;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void doOall8(boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3, boolean paramBoolean4, boolean paramBoolean5) throws SQLException, IOException {
/*   58 */     doOall8(paramBoolean1, paramBoolean2, paramBoolean3, paramBoolean4, paramBoolean5, 0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void doOall8(boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3, boolean paramBoolean4, boolean paramBoolean5, int paramInt) throws SQLException, IOException {
/*   72 */     if (paramBoolean1 || paramBoolean4 || !paramBoolean2) {
/*   73 */       this.oacdefSent = null;
/*      */     }
/*   75 */     this.t4Connection.assertLoggedOn("oracle.jdbc.driver.T4CPreparedStatement.doOall8");
/*      */     
/*   77 */     if (this.sqlKind == OracleStatement.SqlKind.UNINITIALIZED) {
/*      */ 
/*      */ 
/*      */       
/*   81 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 439, "sqlKind = " + this.sqlKind);
/*   82 */       sQLException.fillInStackTrace();
/*   83 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/*   87 */     int i = this.rowPrefetch;
/*   88 */     if (paramBoolean3) {
/*   89 */       if (this.maxRows > 0 && this.maxRows <= this.indexOfFirstRow + this.storedRowCount + this.rowPrefetch) {
/*      */         
/*   91 */         i = this.maxRows - this.indexOfFirstRow + this.storedRowCount;
/*   92 */         this.isComplete = true;
/*      */       } 
/*   94 */       this.rowPrefetchInLastFetch = i;
/*   95 */       if (i == 0 && this.isComplete)
/*      */         return; 
/*      */     } 
/*   98 */     int j = this.numberOfDefinePositions;
/*      */     
/*  100 */     if (this.sqlKind.isDML()) {
/*  101 */       j = 0;
/*      */     }
/*      */     
/*  104 */     if (this.accessors != null)
/*  105 */       for (byte b = 0; b < this.accessors.length; b++) {
/*  106 */         if (this.accessors[b] != null)
/*  107 */           (this.accessors[b]).lastRowProcessed = paramInt; 
/*  108 */       }   if (this.outBindAccessors != null) {
/*  109 */       for (byte b = 0; b < this.outBindAccessors.length; b++) {
/*  110 */         if (this.outBindAccessors[b] != null) {
/*  111 */           (this.outBindAccessors[b]).lastRowProcessed = 0;
/*      */         }
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*  118 */     if (this.bindIndicators != null) {
/*      */       
/*  120 */       int k = ((this.bindIndicators[this.bindIndicatorSubRange + 3] & 0xFFFF) << 16) + (this.bindIndicators[this.bindIndicatorSubRange + 4] & 0xFFFF);
/*      */ 
/*      */       
/*  123 */       int m = 0;
/*      */       
/*  125 */       if (this.ibtBindChars != null) {
/*  126 */         m = this.ibtBindChars.length * this.connection.conversion.cMaxCharSize;
/*      */       }
/*  128 */       for (byte b = 0; b < this.numberOfBindPositions; b++) {
/*      */         
/*  130 */         int n = this.bindIndicatorSubRange + 5 + 10 * b;
/*      */ 
/*      */ 
/*      */         
/*  134 */         int i1 = this.bindIndicators[n + 2] & 0xFFFF;
/*      */ 
/*      */ 
/*      */         
/*  138 */         if (i1 != 0) {
/*      */ 
/*      */           
/*  141 */           int i2 = this.bindIndicators[n + 9] & 0xFFFF;
/*      */ 
/*      */ 
/*      */           
/*  145 */           if (i2 == 2) {
/*      */             
/*  147 */             m = Math.max(i1 * this.connection.conversion.maxNCharSize, m);
/*      */           
/*      */           }
/*      */           else {
/*      */             
/*  152 */             m = Math.max(i1 * this.connection.conversion.cMaxCharSize, m);
/*      */           } 
/*      */         } 
/*      */       } 
/*      */ 
/*      */       
/*  158 */       if (this.tmpBindsByteArray == null)
/*      */       {
/*  160 */         this.tmpBindsByteArray = new byte[m];
/*      */       }
/*  162 */       else if (this.tmpBindsByteArray.length < m)
/*      */       {
/*  164 */         this.tmpBindsByteArray = null;
/*  165 */         this.tmpBindsByteArray = new byte[m];
/*      */ 
/*      */       
/*      */       }
/*      */ 
/*      */ 
/*      */     
/*      */     }
/*      */     else {
/*      */ 
/*      */ 
/*      */       
/*  177 */       this.tmpBindsByteArray = null;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  182 */     int[] arrayOfInt1 = this.definedColumnType;
/*  183 */     int[] arrayOfInt2 = this.definedColumnSize;
/*  184 */     int[] arrayOfInt3 = this.definedColumnFormOfUse;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  190 */     if (paramBoolean5 && paramBoolean4 && this.isRowidPrepended) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  195 */       arrayOfInt1 = new int[this.definedColumnType.length + 1];
/*  196 */       System.arraycopy(this.definedColumnType, 0, arrayOfInt1, 1, this.definedColumnType.length);
/*  197 */       arrayOfInt1[0] = -8;
/*  198 */       arrayOfInt2 = new int[this.definedColumnSize.length + 1];
/*  199 */       System.arraycopy(this.definedColumnSize, 0, arrayOfInt2, 1, this.definedColumnSize.length);
/*  200 */       arrayOfInt3 = new int[this.definedColumnFormOfUse.length + 1];
/*  201 */       System.arraycopy(this.definedColumnFormOfUse, 0, arrayOfInt3, 1, this.definedColumnFormOfUse.length);
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  207 */     allocateTmpByteArray();
/*      */     
/*  209 */     T4C8Oall t4C8Oall = this.t4Connection.all8;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     try {
/*  215 */       t4C8Oall.doOALL(paramBoolean1, paramBoolean2, paramBoolean3, paramBoolean4, paramBoolean5, this.sqlKind, this.cursorId, this.sqlObject.getSqlBytes(this.processEscapes, this.convertNcharLiterals), i, this.outBindAccessors, this.numberOfBindPositions, this.accessors, j, this.bindBytes, this.bindChars, this.bindIndicators, this.bindIndicatorSubRange, this.connection.conversion, this.tmpBindsByteArray, this.parameterStream, this.parameterDatum, this.parameterOtype, this, this.ibtBindBytes, this.ibtBindChars, this.ibtBindIndicators, this.oacdefSent, arrayOfInt1, arrayOfInt2, arrayOfInt3, this.registration);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  227 */       int k = t4C8Oall.getCursorId();
/*  228 */       if (k != 0 && this.implicitResultSetStatements == null) {
/*  229 */         this.cursorId = k;
/*      */       }
/*  231 */       this.oacdefSent = t4C8Oall.oacdefBindsSent;
/*  232 */       if (this.connection.isPDBChanged) {
/*  233 */         NTFPDBChangeEvent nTFPDBChangeEvent = new NTFPDBChangeEvent((OracleConnection)this.connection);
/*      */         
/*  235 */         ((T4CConnection)this.connection).notify(nTFPDBChangeEvent);
/*  236 */         this.connection.isPDBChanged = false;
/*      */       }
/*      */     
/*  239 */     } catch (SQLException sQLException) {
/*      */       
/*  241 */       int k = t4C8Oall.getCursorId();
/*  242 */       if (k != 0) {
/*  243 */         this.cursorId = k;
/*      */       }
/*  245 */       if (sQLException.getErrorCode() == DatabaseError.getVendorCode(110)) {
/*      */ 
/*      */         
/*  248 */         this.sqlWarning = DatabaseError.addSqlWarning(this.sqlWarning, 110);
/*      */       
/*      */       }
/*      */       else {
/*      */         
/*  253 */         throw sQLException;
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void allocateTmpByteArray() {
/*  263 */     if (this.tmpByteArray == null) {
/*      */ 
/*      */       
/*  266 */       this.tmpByteArray = new byte[this.sizeTmpByteArray];
/*      */     }
/*  268 */     else if (this.sizeTmpByteArray > this.tmpByteArray.length) {
/*      */ 
/*      */ 
/*      */       
/*  272 */       this.tmpByteArray = new byte[this.sizeTmpByteArray];
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void releaseBuffers() {
/*  284 */     super.releaseBuffers();
/*  285 */     this.tmpByteArray = null;
/*  286 */     this.tmpBindsByteArray = null;
/*      */     
/*  288 */     if (this.t4Connection != null) {
/*      */       
/*  290 */       this.t4Connection.all8.bindChars = null;
/*  291 */       this.t4Connection.all8.bindBytes = null;
/*  292 */       this.t4Connection.all8.tmpBindsByteArray = null;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void allocateRowidAccessor() throws SQLException {
/*  300 */     this.accessors[0] = new T4CRowidAccessor(this, 128, (short)1, -8, false, this.t4Connection.mare);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void reparseOnRedefineIfNeeded() throws SQLException {
/*  313 */     this.needToParse = true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void defineColumnTypeInternal(int paramInt1, int paramInt2, int paramInt3, short paramShort, boolean paramBoolean, String paramString) throws SQLException {
/*  324 */     if (this.connection.disableDefinecolumntype) {
/*      */       return;
/*      */     }
/*      */ 
/*      */     
/*  329 */     if (paramInt2 == -15 || paramInt2 == -9 || paramInt2 == -16)
/*      */     {
/*  331 */       paramShort = 2;
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*  336 */     if (paramInt1 < 1) {
/*      */       
/*  338 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/*  339 */       sQLException.fillInStackTrace();
/*  340 */       throw sQLException;
/*      */     } 
/*      */     
/*  343 */     if (this.currentResultSet != null && !this.currentResultSet.closed) {
/*      */       
/*  345 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 28);
/*  346 */       sQLException.fillInStackTrace();
/*  347 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  354 */     int i = paramInt1 - 1;
/*      */     
/*  356 */     if (this.definedColumnType == null || this.definedColumnType.length <= i)
/*      */     {
/*  358 */       if (this.definedColumnType == null) {
/*      */         
/*  360 */         this.definedColumnType = new int[(i + 1) * 4];
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       }
/*      */       else {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  372 */         int[] arrayOfInt = new int[(i + 1) * 4];
/*      */         
/*  374 */         System.arraycopy(this.definedColumnType, 0, arrayOfInt, 0, this.definedColumnType.length);
/*      */ 
/*      */         
/*  377 */         this.definedColumnType = arrayOfInt;
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*  383 */     this.definedColumnType[i] = paramInt2;
/*      */     
/*  385 */     if (this.definedColumnSize == null || this.definedColumnSize.length <= i)
/*      */     {
/*  387 */       if (this.definedColumnSize == null) {
/*  388 */         this.definedColumnSize = new int[(i + 1) * 4];
/*      */       }
/*      */       else {
/*      */         
/*  392 */         int[] arrayOfInt = new int[(i + 1) * 4];
/*      */         
/*  394 */         System.arraycopy(this.definedColumnSize, 0, arrayOfInt, 0, this.definedColumnSize.length);
/*      */ 
/*      */         
/*  397 */         this.definedColumnSize = arrayOfInt;
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*  402 */     this.definedColumnSize[i] = (paramInt2 == 2005 || paramInt2 == 2004) ? paramInt3 : -1;
/*      */     
/*  404 */     if (this.definedColumnFormOfUse == null || this.definedColumnFormOfUse.length <= i)
/*      */     {
/*  406 */       if (this.definedColumnFormOfUse == null) {
/*  407 */         this.definedColumnFormOfUse = new int[(i + 1) * 4];
/*      */       }
/*      */       else {
/*      */         
/*  411 */         int[] arrayOfInt = new int[(i + 1) * 4];
/*      */         
/*  413 */         System.arraycopy(this.definedColumnFormOfUse, 0, arrayOfInt, 0, this.definedColumnFormOfUse.length);
/*      */ 
/*      */         
/*  416 */         this.definedColumnFormOfUse = arrayOfInt;
/*      */       } 
/*      */     }
/*      */     
/*  420 */     this.definedColumnFormOfUse[i] = paramShort;
/*      */     
/*  422 */     if (this.accessors != null && i < this.accessors.length && this.accessors[i] != null) {
/*      */       
/*  424 */       (this.accessors[i]).definedColumnSize = paramInt3;
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  429 */       if (((this.accessors[i]).internalType == 96 || (this.accessors[i]).internalType == 1) && (paramInt2 == 1 || paramInt2 == 12))
/*      */       {
/*      */ 
/*      */         
/*  433 */         if (paramInt3 <= (this.accessors[i]).oacmxl) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  439 */           this.needToPrepareDefineBuffer = true;
/*  440 */           this.columnsDefinedByUser = true;
/*      */           
/*  442 */           this.accessors[i].initForDataAccess(paramInt2, paramInt3, null);
/*  443 */           this.accessors[i].calculateSizeTmpByteArray();
/*      */         } 
/*      */       }
/*      */     } 
/*      */     
/*  448 */     this.executeDoneForDefines = false;
/*      */   }
/*      */ 
/*      */   
/*      */   public void clearDefines() throws SQLException {
/*  453 */     synchronized (this.connection) {
/*      */       
/*  455 */       super.clearDefines();
/*  456 */       this.definedColumnType = null;
/*  457 */       this.definedColumnSize = null;
/*  458 */       this.definedColumnFormOfUse = null;
/*  459 */       if (this.t4Connection != null && this.t4Connection.all8 != null) {
/*  460 */         this.t4Connection.all8.definesAccessors = null;
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void doSetSnapshotSCN(long paramLong) throws SQLException {
/*  469 */     this.inScn = paramLong; } Accessor allocateAccessor(int paramInt1, int paramInt2, int paramInt3, int paramInt4, short paramShort, String paramString, boolean paramBoolean) throws SQLException { T4CVarcharAccessor t4CVarcharAccessor;
/*      */     T4CNumberAccessor t4CNumberAccessor;
/*      */     T4CVarnumAccessor t4CVarnumAccessor;
/*      */     T4CRawAccessor t4CRawAccessor;
/*      */     T4CBinaryFloatAccessor t4CBinaryFloatAccessor;
/*      */     T4CBinaryDoubleAccessor t4CBinaryDoubleAccessor;
/*      */     T4CRowidAccessor t4CRowidAccessor;
/*      */     T4CResultSetAccessor t4CResultSetAccessor;
/*      */     T4CDateAccessor t4CDateAccessor;
/*      */     T4CBlobAccessor t4CBlobAccessor;
/*      */     T4CClobAccessor t4CClobAccessor;
/*      */     T4CBfileAccessor t4CBfileAccessor;
/*      */     T4CNamedTypeAccessor t4CNamedTypeAccessor;
/*      */     T4CRefTypeAccessor t4CRefTypeAccessor;
/*      */     T4CTimestampAccessor t4CTimestampAccessor;
/*      */     T4CTimestamptzAccessor t4CTimestamptzAccessor;
/*      */     T4CTimestampltzAccessor t4CTimestampltzAccessor;
/*      */     T4CIntervalymAccessor t4CIntervalymAccessor;
/*      */     T4CIntervaldsAccessor t4CIntervaldsAccessor;
/*      */     SQLException sQLException;
/*  489 */     T4CCharAccessor t4CCharAccessor = null;
/*      */     
/*  491 */     switch (paramInt1) {
/*      */ 
/*      */       
/*      */       case 96:
/*  495 */         t4CCharAccessor = new T4CCharAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 8:
/*  501 */         if (!paramBoolean) {
/*      */           
/*  503 */           T4CLongAccessor t4CLongAccessor = new T4CLongAccessor(this, paramInt3, paramInt4, paramShort, paramInt2, this.t4Connection.mare);
/*      */           break;
/*      */         } 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 1:
/*  511 */         t4CVarcharAccessor = new T4CVarcharAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 2:
/*  517 */         t4CNumberAccessor = new T4CNumberAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 6:
/*  523 */         t4CVarnumAccessor = new T4CVarnumAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 24:
/*  529 */         if (!paramBoolean) {
/*      */           
/*  531 */           T4CLongRawAccessor t4CLongRawAccessor = new T4CLongRawAccessor(this, paramInt3, paramInt4, paramShort, paramInt2, this.t4Connection.mare);
/*      */           break;
/*      */         } 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 23:
/*  539 */         if (paramBoolean && paramString != null) {
/*      */           
/*  541 */           SQLException sQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 12, "sqlType=" + paramInt2);
/*  542 */           sQLException1.fillInStackTrace();
/*  543 */           throw sQLException1;
/*      */         } 
/*      */         
/*  546 */         if (paramBoolean) {
/*  547 */           T4COutRawAccessor t4COutRawAccessor = new T4COutRawAccessor(this, paramInt4, paramShort, paramInt2, this.t4Connection.mare);
/*      */           break;
/*      */         } 
/*  550 */         t4CRawAccessor = new T4CRawAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 100:
/*  556 */         t4CBinaryFloatAccessor = new T4CBinaryFloatAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 101:
/*  562 */         t4CBinaryDoubleAccessor = new T4CBinaryDoubleAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 104:
/*  568 */         if (this.sqlKind == OracleStatement.SqlKind.CALL_BLOCK) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  574 */           T4CVarcharAccessor t4CVarcharAccessor1 = new T4CVarcharAccessor(this, 18, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */ 
/*      */ 
/*      */           
/*  578 */           t4CVarcharAccessor1.definedColumnType = -8;
/*      */           break;
/*      */         } 
/*  581 */         t4CRowidAccessor = new T4CRowidAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */         break;
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 102:
/*  588 */         t4CResultSetAccessor = new T4CResultSetAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 12:
/*  594 */         t4CDateAccessor = new T4CDateAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 113:
/*  600 */         t4CBlobAccessor = new T4CBlobAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 112:
/*  606 */         t4CClobAccessor = new T4CClobAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 114:
/*  612 */         t4CBfileAccessor = new T4CBfileAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 109:
/*  618 */         t4CNamedTypeAccessor = new T4CNamedTypeAccessor(this, paramString, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */ 
/*      */         
/*  621 */         t4CNamedTypeAccessor.initMetadata();
/*      */         break;
/*      */ 
/*      */       
/*      */       case 111:
/*  626 */         t4CRefTypeAccessor = new T4CRefTypeAccessor(this, paramString, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */ 
/*      */         
/*  629 */         t4CRefTypeAccessor.initMetadata();
/*      */         break;
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 180:
/*  636 */         t4CTimestampAccessor = new T4CTimestampAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 181:
/*  642 */         t4CTimestamptzAccessor = new T4CTimestamptzAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 231:
/*  648 */         t4CTimestampltzAccessor = new T4CTimestampltzAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 182:
/*  654 */         t4CIntervalymAccessor = new T4CIntervalymAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 183:
/*  660 */         t4CIntervaldsAccessor = new T4CIntervaldsAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */         break;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 995:
/*  676 */         sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 89);
/*  677 */         sQLException.fillInStackTrace();
/*  678 */         throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/*  682 */     return t4CIntervaldsAccessor; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void doDescribe(boolean paramBoolean) throws SQLException {
/*  708 */     if (!this.isOpen) {
/*      */ 
/*      */       
/*  711 */       this.connection.open(this);
/*  712 */       this.isOpen = true;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*      */     try {
/*  718 */       this.t4Connection.needLine();
/*  719 */       this.t4Connection.describe.doODNY(this, 0, this.accessors, this.sqlObject.getSqlBytes(this.processEscapes, this.convertNcharLiterals));
/*  720 */       this.accessors = this.t4Connection.describe.getAccessors();
/*      */       
/*  722 */       this.numberOfDefinePositions = this.t4Connection.describe.numuds;
/*      */       
/*  724 */       for (byte b = 0; b < this.numberOfDefinePositions; b++) {
/*  725 */         this.accessors[b].initMetadata();
/*      */       }
/*  727 */     } catch (IOException iOException) {
/*      */       
/*  729 */       ((T4CConnection)this.connection).handleIOException(iOException);
/*      */ 
/*      */       
/*  732 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException);
/*  733 */       sQLException.fillInStackTrace();
/*  734 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/*  738 */     this.describedWithNames = true;
/*  739 */     this.described = true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void executeForDescribe() throws SQLException {
/*  774 */     this.t4Connection.assertLoggedOn("oracle.jdbc.driver.T4CPreparedStatement.execute_for_describe");
/*      */     try {
/*  776 */       doOall8(true, true, (this.definedColumnType != null), true, (this.definedColumnType != null));
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     }
/*  782 */     catch (SQLException sQLException) {
/*      */ 
/*      */       
/*  785 */       throw sQLException;
/*      */     }
/*  787 */     catch (IOException iOException) {
/*      */       
/*  789 */       ((T4CConnection)this.connection).handleIOException(iOException);
/*      */       
/*  791 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException);
/*  792 */       sQLException.fillInStackTrace();
/*  793 */       throw sQLException;
/*      */     
/*      */     }
/*      */     finally {
/*      */       
/*  798 */       this.rowsProcessed = this.t4Connection.all8.rowsProcessed;
/*  799 */       this.validRows = this.t4Connection.all8.getNumRows();
/*  800 */       if (this.connection.checksumMode.needToCalculateFetchChecksum()) {
/*  801 */         if (this.validRows > 0) {
/*  802 */           calculateCheckSum();
/*  803 */         } else if (this.rowsProcessed > 0) {
/*  804 */           long l = CRC64.updateChecksum(this.checkSum, this.rowsProcessed);
/*      */           
/*  806 */           this.checkSum = l;
/*      */         } 
/*      */       }
/*      */     } 
/*      */     
/*  811 */     this.needToParse = false;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  821 */     if (this.definedColumnType == null) {
/*  822 */       this.implicitDefineForLobPrefetchDone = false;
/*      */     }
/*  824 */     this.aFetchWasDoneDuringDescribe = false;
/*  825 */     if (this.t4Connection.all8.aFetchWasDone) {
/*      */       
/*  827 */       this.aFetchWasDoneDuringDescribe = true;
/*  828 */       this.rowPrefetchInLastFetch = this.rowPrefetch;
/*      */     } 
/*      */ 
/*      */     
/*  832 */     for (byte b = 0; b < this.numberOfDefinePositions; b++) {
/*  833 */       this.accessors[b].initMetadata();
/*      */     }
/*  835 */     this.needToPrepareDefineBuffer = false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void executeForRows(boolean paramBoolean) throws SQLException {
/*      */     try {
/*      */       try {
/*  877 */         boolean bool = false;
/*  878 */         if (this.columnsDefinedByUser) {
/*  879 */           this.needToPrepareDefineBuffer = false;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         }
/*  899 */         else if (this.t4Connection.useLobPrefetch && this.accessors != null && this.defaultLobPrefetchSize != -1 && !this.implicitDefineForLobPrefetchDone && !this.aFetchWasDoneDuringDescribe && this.definedColumnType == null) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  907 */           boolean bool1 = false;
/*  908 */           int[] arrayOfInt1 = new int[this.accessors.length];
/*  909 */           int[] arrayOfInt2 = new int[this.accessors.length];
/*  910 */           int[] arrayOfInt3 = new int[this.accessors.length];
/*      */           
/*  912 */           for (byte b = 0; b < this.accessors.length; b++) {
/*  913 */             if (this.accessors[b] != null) {
/*      */ 
/*      */ 
/*      */               
/*  917 */               arrayOfInt1[b] = getJDBCType((this.accessors[b]).internalType);
/*  918 */               arrayOfInt3[b] = (this.accessors[b]).formOfUse;
/*  919 */               if ((this.accessors[b]).internalType == 113 || (this.accessors[b]).internalType == 112 || (this.accessors[b]).internalType == 114) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */                 
/*  925 */                 bool1 = true;
/*      */                 
/*  927 */                 this.accessors[b].setPrefetchLength(this.defaultLobPrefetchSize);
/*  928 */                 arrayOfInt2[b] = this.defaultLobPrefetchSize;
/*      */               } 
/*      */             } 
/*      */           } 
/*  932 */           if (bool1) {
/*      */             
/*  934 */             this.definedColumnType = arrayOfInt1;
/*  935 */             this.definedColumnSize = arrayOfInt2;
/*  936 */             this.definedColumnFormOfUse = arrayOfInt3;
/*  937 */             bool = true;
/*      */           } 
/*      */         } 
/*      */ 
/*      */ 
/*      */         
/*  943 */         doOall8(this.needToParse, !paramBoolean, true, false, bool);
/*      */         
/*  945 */         this.needToParse = false;
/*  946 */         if (bool) {
/*  947 */           this.implicitDefineForLobPrefetchDone = true;
/*      */         }
/*      */       } finally {
/*      */         
/*  951 */         if (this.implicitResultSetStatements == null) {
/*  952 */           this.validRows = this.t4Connection.all8.getNumRows();
/*      */         } else {
/*  954 */           this.validRows = 0;
/*  955 */         }  calculateCheckSum();
/*      */       }
/*      */     
/*  958 */     } catch (SQLException sQLException) {
/*      */       
/*  960 */       throw sQLException;
/*      */     }
/*  962 */     catch (IOException iOException) {
/*      */       
/*  964 */       ((T4CConnection)this.connection).handleIOException(iOException);
/*      */       
/*  966 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException);
/*  967 */       sQLException.fillInStackTrace();
/*  968 */       throw sQLException;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void fetch(int paramInt, boolean paramBoolean) throws SQLException {
/*  994 */     if (this.rowData != null) {
/*  995 */       if (paramBoolean) {
/*      */         
/*  997 */         this.rowData.setPosition(this.rowData.length());
/*      */       } else {
/*  999 */         this.rowData.reset();
/*      */       } 
/*      */     }
/*      */     
/* 1003 */     if (this.streamList != null)
/*      */     {
/* 1005 */       while (this.nextStream != null) {
/*      */         try {
/* 1007 */           this.nextStream.close();
/*      */         }
/* 1009 */         catch (IOException iOException) {
/* 1010 */           ((T4CConnection)this.connection).handleIOException(iOException);
/*      */           
/* 1012 */           SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException);
/* 1013 */           sQLException.fillInStackTrace();
/* 1014 */           throw sQLException;
/*      */         } 
/*      */         
/* 1017 */         this.nextStream = this.nextStream.nextStream;
/*      */       } 
/*      */     }
/*      */     
/*      */     try {
/* 1022 */       doOall8(false, false, true, false, false, paramInt);
/* 1023 */       this.validRows = this.t4Connection.all8.getNumRows();
/* 1024 */       if (this.validRows != -2) this.validRows -= paramInt; 
/* 1025 */       calculateCheckSum();
/*      */     }
/* 1027 */     catch (IOException iOException) {
/* 1028 */       ((T4CConnection)this.connection).handleIOException(iOException);
/*      */       
/* 1030 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException);
/* 1031 */       sQLException.fillInStackTrace();
/* 1032 */       throw sQLException;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void continueReadRow(int paramInt) throws SQLException {
/*      */     try {
/* 1051 */       if (!this.isFetchStreams)
/*      */       {
/* 1053 */         T4C8Oall t4C8Oall = this.t4Connection.all8;
/*      */         
/* 1055 */         t4C8Oall.continueReadRow(paramInt, this);
/*      */       }
/*      */     
/* 1058 */     } catch (IOException iOException) {
/*      */       
/* 1060 */       ((T4CConnection)this.connection).handleIOException(iOException);
/*      */       
/* 1062 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException);
/* 1063 */       sQLException.fillInStackTrace();
/* 1064 */       throw sQLException;
/*      */     
/*      */     }
/* 1067 */     catch (SQLException sQLException) {
/*      */       
/* 1069 */       if (sQLException.getErrorCode() == DatabaseError.getVendorCode(110)) {
/*      */ 
/*      */         
/* 1072 */         this.sqlWarning = DatabaseError.addSqlWarning(this.sqlWarning, 110);
/*      */       
/*      */       }
/*      */       else {
/*      */         
/* 1077 */         throw sQLException;
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void doClose() throws SQLException {
/* 1101 */     this.t4Connection.assertLoggedOn("oracle.jdbc.driver.T4CPreparedStatement.do_close");
/* 1102 */     if (this.cursorId != 0)
/*      */     {
/* 1104 */       this.t4Connection.closeCursor(this.cursorId);
/*      */     }
/*      */     
/* 1107 */     this.tmpByteArray = null;
/* 1108 */     this.tmpBindsByteArray = null;
/* 1109 */     this.definedColumnType = null;
/* 1110 */     this.definedColumnSize = null;
/* 1111 */     this.definedColumnFormOfUse = null;
/* 1112 */     this.oacdefSent = null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void closeQuery() throws SQLException {
/* 1131 */     this.connection.registerHeartbeat();
/* 1132 */     this.connection.needLine();
/* 1133 */     this.t4Connection.assertLoggedOn("oracle.jdbc.driver.T4CPreparedStatement.closeQuery");
/*      */     
/* 1135 */     if (this.streamList != null)
/*      */     {
/* 1137 */       while (this.nextStream != null) {
/*      */         try {
/* 1139 */           this.nextStream.close();
/*      */         }
/* 1141 */         catch (IOException iOException) {
/* 1142 */           ((T4CConnection)this.connection).handleIOException(iOException);
/*      */           
/* 1144 */           SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException);
/* 1145 */           sQLException.fillInStackTrace();
/* 1146 */           throw sQLException;
/*      */         } 
/*      */         
/* 1149 */         this.nextStream = this.nextStream.nextStream;
/*      */       } 
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   Binder getRowidNullBinder(int paramInt) {
/* 1160 */     if (this.sqlKind == OracleStatement.SqlKind.CALL_BLOCK) {
/*      */ 
/*      */       
/* 1163 */       this.currentRowCharLens[paramInt] = 1;
/* 1164 */       return this.theVarcharNullBinder;
/*      */     } 
/*      */     
/* 1167 */     return this.theRowidNullBinder;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void doLocalInitialization() {
/* 1176 */     super.doLocalInitialization();
/*      */     
/* 1178 */     this.t4Connection.all8.bindChars = this.bindChars;
/* 1179 */     this.t4Connection.all8.bindBytes = this.bindBytes;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/* 1184 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*      */   public static final String BUILD_DATE = "Thu_Apr_04_15:09:24_PDT_2013";
/*      */   public static final boolean TRACE = false;
/*      */ }


/* Location:              C:\Users\olatu\OneDrive\Documents\Calypso\syncbase\sync_base.jar!\BOOT-INF\lib\ojdbc-7.jar!\oracle\jdbc\driver\T4CPreparedStatement.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */