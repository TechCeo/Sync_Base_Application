/*      */ package oracle.jdbc.driver;
/*      */ 
/*      */ import java.io.InputStream;
/*      */ import java.io.Reader;
/*      */ import java.lang.reflect.InvocationTargetException;
/*      */ import java.lang.reflect.Method;
/*      */ import java.lang.reflect.Modifier;
/*      */ import java.math.BigDecimal;
/*      */ import java.math.BigInteger;
/*      */ import java.net.URL;
/*      */ import java.sql.Array;
/*      */ import java.sql.Blob;
/*      */ import java.sql.Clob;
/*      */ import java.sql.Date;
/*      */ import java.sql.NClob;
/*      */ import java.sql.Ref;
/*      */ import java.sql.ResultSet;
/*      */ import java.sql.RowId;
/*      */ import java.sql.SQLException;
/*      */ import java.sql.SQLXML;
/*      */ import java.sql.Struct;
/*      */ import java.sql.Time;
/*      */ import java.sql.Timestamp;
/*      */ import java.util.Calendar;
/*      */ import java.util.Collection;
/*      */ import java.util.Date;
/*      */ import java.util.HashMap;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import oracle.jdbc.OracleArray;
/*      */ import oracle.jdbc.OracleBfile;
/*      */ import oracle.jdbc.OracleBlob;
/*      */ import oracle.jdbc.OracleClob;
/*      */ import oracle.jdbc.OracleData;
/*      */ import oracle.jdbc.OracleOpaque;
/*      */ import oracle.jdbc.OracleRef;
/*      */ import oracle.jdbc.internal.OracleConnection;
/*      */ import oracle.sql.ARRAY;
/*      */ import oracle.sql.BFILE;
/*      */ import oracle.sql.BINARY_DOUBLE;
/*      */ import oracle.sql.BINARY_FLOAT;
/*      */ import oracle.sql.BLOB;
/*      */ import oracle.sql.CHAR;
/*      */ import oracle.sql.CLOB;
/*      */ import oracle.sql.DATE;
/*      */ import oracle.sql.INTERVALDS;
/*      */ import oracle.sql.INTERVALYM;
/*      */ import oracle.sql.NUMBER;
/*      */ import oracle.sql.OPAQUE;
/*      */ import oracle.sql.ORAData;
/*      */ import oracle.sql.RAW;
/*      */ import oracle.sql.REF;
/*      */ import oracle.sql.ROWID;
/*      */ import oracle.sql.STRUCT;
/*      */ import oracle.sql.TIMESTAMP;
/*      */ import oracle.sql.TIMESTAMPLTZ;
/*      */ import oracle.sql.TIMESTAMPTZ;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ abstract class Redirector<T>
/*      */ {
/*      */   private final Class<T> type;
/*      */   
/*      */   private Redirector(Class<T> paramClass) {
/*  117 */     this.type = paramClass;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final Class<T> getTarget() {
/*  144 */     return this.type;
/*      */   }
/*      */   
/*      */   public String toString() {
/*  148 */     return super.toString() + "[" + this.type.getName() + "]";
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static <V> Redirector<V> createObjectRedirector(Class<V> paramClass) {
/*  171 */     return new Redirector<V>(paramClass)
/*      */       {
/*      */         final V redirect(Accessor param1Accessor, int param1Int) throws SQLException
/*      */         {
/*      */           try {
/*  176 */             Object object = param1Accessor.getObject(param1Int);
/*  177 */             Class<V> clazz = getTarget();
/*      */             
/*  179 */             if (object != null && !clazz.isInstance(object)) {
/*      */               
/*  181 */               SQLException sQLException = DatabaseError.createSqlException((OracleConnection)null, 49, clazz.getName());
/*  182 */               sQLException.fillInStackTrace();
/*  183 */               throw sQLException;
/*      */             } 
/*      */             
/*  186 */             return (V)object;
/*      */           }
/*  188 */           catch (ClassCastException classCastException) {
/*      */             
/*  190 */             SQLException sQLException = DatabaseError.createSqlException((OracleConnection)null, 4);
/*  191 */             sQLException.fillInStackTrace();
/*  192 */             throw sQLException;
/*      */           } 
/*      */         }
/*      */       };
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static <V> Redirector<V> createValueOfRedirector(Class<V> paramClass, List<Class> paramList) {
/*  220 */     if (Modifier.isPublic(paramClass.getModifiers())) {
/*      */       
/*  222 */       Method[] arrayOfMethod = paramClass.getDeclaredMethods();
/*  223 */       int i = Integer.MAX_VALUE;
/*  224 */       Method method = null;
/*  225 */       Class<?> clazz = null;
/*  226 */       for (Method method1 : arrayOfMethod) {
/*  227 */         if (Modifier.isStatic(method1.getModifiers()) && Modifier.isPublic(method1.getModifiers()) && method1.getName().equals("valueOf") && (method1.getParameterTypes()).length == 1 && paramClass.isAssignableFrom(method1.getReturnType())) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  233 */           byte b = 0;
/*  234 */           for (Class<?> clazz1 : paramList) {
/*  235 */             if (method1.getParameterTypes()[0].isAssignableFrom(clazz1)) {
/*  236 */               if (b < i) {
/*  237 */                 i = b;
/*  238 */                 method = method1;
/*  239 */                 clazz = clazz1;
/*      */               } 
/*      */               break;
/*      */             } 
/*  243 */             b++;
/*      */           } 
/*      */         } 
/*  246 */         if (i == 0)
/*      */           break; 
/*  248 */       }  if (method != null)
/*      */       {
/*  250 */         return createValueOfRedirector(method, clazz);
/*      */       }
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  256 */     return new Redirector<V>(paramClass)
/*      */       {
/*      */         final V redirect(Accessor param1Accessor, int param1Int) throws SQLException
/*      */         {
/*  260 */           SQLException sQLException = DatabaseError.createSqlException((OracleConnection)null, 4);
/*  261 */           sQLException.fillInStackTrace();
/*  262 */           throw sQLException;
/*      */         }
/*      */       };
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static <V> Redirector<V> createValueOfRedirector(final Method staticValueOf, Class paramClass) {
/*  285 */     final Redirector supportedRedirector = CLASS_TO_REDIRECTOR.get(paramClass);
/*  286 */     return new Redirector<V>(paramClass)
/*      */       {
/*      */         public final V redirect(Accessor param1Accessor, int param1Int) throws SQLException
/*      */         {
/*      */           try {
/*  291 */             if (param1Accessor.isNull(param1Int)) return null; 
/*  292 */             return (V)staticValueOf.invoke(null, new Object[] { this.val$supportedRedirector.redirect(param1Accessor, param1Int) });
/*      */           }
/*  294 */           catch (IllegalAccessException illegalAccessException) {
/*      */             
/*  296 */             SQLException sQLException = DatabaseError.createSqlException((OracleConnection)null, 1, illegalAccessException.getMessage());
/*  297 */             sQLException.fillInStackTrace();
/*  298 */             throw sQLException;
/*      */           
/*      */           }
/*  301 */           catch (IllegalArgumentException illegalArgumentException) {
/*      */             
/*  303 */             SQLException sQLException = DatabaseError.createSqlException((OracleConnection)null, 1, illegalArgumentException.getMessage());
/*  304 */             sQLException.fillInStackTrace();
/*  305 */             throw sQLException;
/*      */           
/*      */           }
/*  308 */           catch (InvocationTargetException invocationTargetException) {
/*  309 */             if (invocationTargetException.getTargetException() instanceof SQLException) {
/*  310 */               throw (SQLException)invocationTargetException.getTargetException();
/*      */             }
/*      */             
/*  313 */             SQLException sQLException = DatabaseError.createSqlException((OracleConnection)null, 1, "Got something other than a SQLException: " + invocationTargetException.getTargetException());
/*  314 */             sQLException.fillInStackTrace();
/*  315 */             throw sQLException;
/*      */           } 
/*      */         }
/*      */       };
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static Map<Class, Redirector> createRedirectorMap(Collection<Class> paramCollection) {
/*  334 */     Map<Class, Redirector> map = (Map)CLASS_TO_ERROR.clone();
/*  335 */     for (Class clazz : paramCollection) {
/*  336 */       assert CLASS_TO_REDIRECTOR.get(clazz) != null : clazz;
/*  337 */       map.put(clazz, CLASS_TO_REDIRECTOR.get(clazz));
/*      */     } 
/*  339 */     return map;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  361 */   private static final HashMap<Class, Redirector> CLASS_TO_REDIRECTOR = new HashMap<>();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static {
/*  370 */     CLASS_TO_REDIRECTOR.put(Array.class, new Redirector<Array>(Array.class)
/*      */         {
/*      */           
/*      */           final Array redirect(Accessor param1Accessor, int param1Int) throws SQLException
/*      */           {
/*  375 */             return (Array)param1Accessor.getARRAY(param1Int);
/*      */           }
/*      */         });
/*      */ 
/*      */     
/*  380 */     CLASS_TO_REDIRECTOR.put(BigDecimal.class, new Redirector<BigDecimal>(BigDecimal.class)
/*      */         {
/*      */           
/*      */           final BigDecimal redirect(Accessor param1Accessor, int param1Int) throws SQLException
/*      */           {
/*  385 */             return param1Accessor.getBigDecimal(param1Int);
/*      */           }
/*      */         });
/*      */ 
/*      */     
/*  390 */     CLASS_TO_REDIRECTOR.put(Blob.class, new Redirector<Blob>(Blob.class)
/*      */         {
/*      */           
/*      */           final Blob redirect(Accessor param1Accessor, int param1Int) throws SQLException
/*      */           {
/*  395 */             return (Blob)param1Accessor.getBLOB(param1Int);
/*      */           }
/*      */         });
/*      */ 
/*      */     
/*  400 */     CLASS_TO_REDIRECTOR.put(Boolean.class, new Redirector<Boolean>(Boolean.class)
/*      */         {
/*      */           
/*      */           final Boolean redirect(Accessor param1Accessor, int param1Int) throws SQLException
/*      */           {
/*  405 */             return Boolean.valueOf(param1Accessor.getBoolean(param1Int));
/*      */           }
/*      */         });
/*      */ 
/*      */     
/*  410 */     CLASS_TO_REDIRECTOR.put(Byte.class, new Redirector<Byte>(Byte.class)
/*      */         {
/*      */           
/*      */           final Byte redirect(Accessor param1Accessor, int param1Int) throws SQLException
/*      */           {
/*  415 */             return Byte.valueOf(param1Accessor.getByte(param1Int));
/*      */           }
/*      */         });
/*      */ 
/*      */     
/*  420 */     CLASS_TO_REDIRECTOR.put(byte[].class, new Redirector<byte[]>(byte[].class)
/*      */         {
/*      */           
/*      */           final byte[] redirect(Accessor param1Accessor, int param1Int) throws SQLException
/*      */           {
/*  425 */             return param1Accessor.getBytes(param1Int);
/*      */           }
/*      */         });
/*      */ 
/*      */     
/*  430 */     CLASS_TO_REDIRECTOR.put(Clob.class, new Redirector<Clob>(Clob.class)
/*      */         {
/*      */           
/*      */           final Clob redirect(Accessor param1Accessor, int param1Int) throws SQLException
/*      */           {
/*  435 */             return (Clob)param1Accessor.getCLOB(param1Int);
/*      */           }
/*      */         });
/*      */ 
/*      */     
/*  440 */     CLASS_TO_REDIRECTOR.put(Date.class, new Redirector<Date>(Date.class)
/*      */         {
/*      */           
/*      */           final Date redirect(Accessor param1Accessor, int param1Int) throws SQLException
/*      */           {
/*  445 */             return param1Accessor.getDate(param1Int);
/*      */           }
/*      */         });
/*      */ 
/*      */     
/*  450 */     CLASS_TO_REDIRECTOR.put(Double.class, new Redirector<Double>(Double.class)
/*      */         {
/*      */           
/*      */           final Double redirect(Accessor param1Accessor, int param1Int) throws SQLException
/*      */           {
/*  455 */             return Double.valueOf(param1Accessor.getDouble(param1Int));
/*      */           }
/*      */         });
/*      */ 
/*      */     
/*  460 */     CLASS_TO_REDIRECTOR.put(Float.class, new Redirector<Float>(Float.class)
/*      */         {
/*      */           
/*      */           final Float redirect(Accessor param1Accessor, int param1Int) throws SQLException
/*      */           {
/*  465 */             return Float.valueOf(param1Accessor.getFloat(param1Int));
/*      */           }
/*      */         });
/*      */ 
/*      */     
/*  470 */     CLASS_TO_REDIRECTOR.put(Integer.class, new Redirector<Integer>(Integer.class)
/*      */         {
/*      */           
/*      */           final Integer redirect(Accessor param1Accessor, int param1Int) throws SQLException
/*      */           {
/*  475 */             return Integer.valueOf(param1Accessor.getInt(param1Int));
/*      */           }
/*      */         });
/*      */ 
/*      */     
/*  480 */     CLASS_TO_REDIRECTOR.put(Long.class, new Redirector<Long>(Long.class)
/*      */         {
/*      */           
/*      */           final Long redirect(Accessor param1Accessor, int param1Int) throws SQLException
/*      */           {
/*  485 */             return Long.valueOf(param1Accessor.getLong(param1Int));
/*      */           }
/*      */         });
/*      */ 
/*      */     
/*  490 */     CLASS_TO_REDIRECTOR.put(NClob.class, new Redirector<NClob>(NClob.class)
/*      */         {
/*      */           
/*      */           final NClob redirect(Accessor param1Accessor, int param1Int) throws SQLException
/*      */           {
/*  495 */             return param1Accessor.getNClob(param1Int);
/*      */           }
/*      */         });
/*      */ 
/*      */     
/*  500 */     CLASS_TO_REDIRECTOR.put(Ref.class, new Redirector<Ref>(Ref.class)
/*      */         {
/*      */           
/*      */           final Ref redirect(Accessor param1Accessor, int param1Int) throws SQLException
/*      */           {
/*  505 */             return (Ref)param1Accessor.getREF(param1Int);
/*      */           }
/*      */         });
/*      */ 
/*      */     
/*  510 */     CLASS_TO_REDIRECTOR.put(RowId.class, new Redirector<RowId>(RowId.class)
/*      */         {
/*      */           
/*      */           final RowId redirect(Accessor param1Accessor, int param1Int) throws SQLException
/*      */           {
/*  515 */             return (RowId)param1Accessor.getROWID(param1Int);
/*      */           }
/*      */         });
/*      */ 
/*      */     
/*  520 */     CLASS_TO_REDIRECTOR.put(Short.class, new Redirector<Short>(Short.class)
/*      */         {
/*      */           
/*      */           final Short redirect(Accessor param1Accessor, int param1Int) throws SQLException
/*      */           {
/*  525 */             return Short.valueOf(param1Accessor.getShort(param1Int));
/*      */           }
/*      */         });
/*      */ 
/*      */     
/*  530 */     CLASS_TO_REDIRECTOR.put(SQLXML.class, new Redirector<SQLXML>(SQLXML.class)
/*      */         {
/*      */           
/*      */           final SQLXML redirect(Accessor param1Accessor, int param1Int) throws SQLException
/*      */           {
/*  535 */             return param1Accessor.getSQLXML(param1Int);
/*      */           }
/*      */         });
/*      */ 
/*      */     
/*  540 */     CLASS_TO_REDIRECTOR.put(String.class, new Redirector<String>(String.class)
/*      */         {
/*      */           
/*      */           final String redirect(Accessor param1Accessor, int param1Int) throws SQLException
/*      */           {
/*  545 */             return param1Accessor.getString(param1Int);
/*      */           }
/*      */         });
/*      */ 
/*      */     
/*  550 */     CLASS_TO_REDIRECTOR.put(Struct.class, new Redirector<Struct>(Struct.class)
/*      */         {
/*      */           
/*      */           final Struct redirect(Accessor param1Accessor, int param1Int) throws SQLException
/*      */           {
/*  555 */             return param1Accessor.getStruct(param1Int);
/*      */           }
/*      */         });
/*      */ 
/*      */     
/*  560 */     CLASS_TO_REDIRECTOR.put(Time.class, new Redirector<Time>(Time.class)
/*      */         {
/*      */           
/*      */           final Time redirect(Accessor param1Accessor, int param1Int) throws SQLException
/*      */           {
/*  565 */             return param1Accessor.getTime(param1Int);
/*      */           }
/*      */         });
/*      */ 
/*      */     
/*  570 */     CLASS_TO_REDIRECTOR.put(Timestamp.class, new Redirector<Timestamp>(Timestamp.class)
/*      */         {
/*      */           
/*      */           final Timestamp redirect(Accessor param1Accessor, int param1Int) throws SQLException
/*      */           {
/*  575 */             return param1Accessor.getTimestamp(param1Int);
/*      */           }
/*      */         });
/*      */ 
/*      */     
/*  580 */     CLASS_TO_REDIRECTOR.put(URL.class, new Redirector<URL>(URL.class)
/*      */         {
/*      */           
/*      */           final URL redirect(Accessor param1Accessor, int param1Int) throws SQLException
/*      */           {
/*  585 */             return param1Accessor.getURL(param1Int);
/*      */           }
/*      */         });
/*      */ 
/*      */     
/*  590 */     CLASS_TO_REDIRECTOR.put(BigInteger.class, new Redirector<BigInteger>(BigInteger.class)
/*      */         {
/*      */           
/*      */           final BigInteger redirect(Accessor param1Accessor, int param1Int) throws SQLException
/*      */           {
/*  595 */             return param1Accessor.getBigInteger(param1Int);
/*      */           }
/*      */         });
/*      */ 
/*      */     
/*  600 */     CLASS_TO_REDIRECTOR.put(Date.class, new Redirector<Date>(Date.class)
/*      */         {
/*      */           
/*      */           final Date redirect(Accessor param1Accessor, int param1Int) throws SQLException
/*      */           {
/*  605 */             return param1Accessor.getJavaUtilDate(param1Int);
/*      */           }
/*      */         });
/*      */ 
/*      */     
/*  610 */     CLASS_TO_REDIRECTOR.put(Calendar.class, new Redirector<Calendar>(Calendar.class)
/*      */         {
/*      */           
/*      */           final Calendar redirect(Accessor param1Accessor, int param1Int) throws SQLException
/*      */           {
/*  615 */             return param1Accessor.getCalendar(param1Int);
/*      */           }
/*      */         });
/*      */ 
/*      */     
/*  620 */     CLASS_TO_REDIRECTOR.put(ARRAY.class, new Redirector<ARRAY>(ARRAY.class)
/*      */         {
/*      */           
/*      */           final ARRAY redirect(Accessor param1Accessor, int param1Int) throws SQLException
/*      */           {
/*  625 */             return param1Accessor.getARRAY(param1Int);
/*      */           }
/*      */         });
/*      */ 
/*      */     
/*  630 */     CLASS_TO_REDIRECTOR.put(BFILE.class, new Redirector<BFILE>(BFILE.class)
/*      */         {
/*      */           
/*      */           final BFILE redirect(Accessor param1Accessor, int param1Int) throws SQLException
/*      */           {
/*  635 */             return param1Accessor.getBFILE(param1Int);
/*      */           }
/*      */         });
/*      */ 
/*      */     
/*  640 */     CLASS_TO_REDIRECTOR.put(BINARY_FLOAT.class, new Redirector<BINARY_FLOAT>(BINARY_FLOAT.class)
/*      */         {
/*      */           
/*      */           final BINARY_FLOAT redirect(Accessor param1Accessor, int param1Int) throws SQLException
/*      */           {
/*  645 */             return param1Accessor.getBINARY_FLOAT(param1Int);
/*      */           }
/*      */         });
/*      */ 
/*      */     
/*  650 */     CLASS_TO_REDIRECTOR.put(BINARY_DOUBLE.class, new Redirector<BINARY_DOUBLE>(BINARY_DOUBLE.class)
/*      */         {
/*      */           
/*      */           final BINARY_DOUBLE redirect(Accessor param1Accessor, int param1Int) throws SQLException
/*      */           {
/*  655 */             return param1Accessor.getBINARY_DOUBLE(param1Int);
/*      */           }
/*      */         });
/*      */ 
/*      */     
/*  660 */     CLASS_TO_REDIRECTOR.put(BLOB.class, new Redirector<BLOB>(BLOB.class)
/*      */         {
/*      */           
/*      */           final BLOB redirect(Accessor param1Accessor, int param1Int) throws SQLException
/*      */           {
/*  665 */             return param1Accessor.getBLOB(param1Int);
/*      */           }
/*      */         });
/*      */ 
/*      */     
/*  670 */     CLASS_TO_REDIRECTOR.put(CHAR.class, new Redirector<CHAR>(CHAR.class)
/*      */         {
/*      */           
/*      */           final CHAR redirect(Accessor param1Accessor, int param1Int) throws SQLException
/*      */           {
/*  675 */             return param1Accessor.getCHAR(param1Int);
/*      */           }
/*      */         });
/*      */ 
/*      */     
/*  680 */     CLASS_TO_REDIRECTOR.put(CLOB.class, new Redirector<CLOB>(CLOB.class)
/*      */         {
/*      */           
/*      */           final CLOB redirect(Accessor param1Accessor, int param1Int) throws SQLException
/*      */           {
/*  685 */             return param1Accessor.getCLOB(param1Int);
/*      */           }
/*      */         });
/*      */ 
/*      */     
/*  690 */     CLASS_TO_REDIRECTOR.put(ResultSet.class, new Redirector<ResultSet>(ResultSet.class)
/*      */         {
/*      */           
/*      */           final ResultSet redirect(Accessor param1Accessor, int param1Int) throws SQLException
/*      */           {
/*  695 */             return param1Accessor.getCursor(param1Int);
/*      */           }
/*      */         });
/*      */ 
/*      */     
/*  700 */     CLASS_TO_REDIRECTOR.put(DATE.class, new Redirector<DATE>(DATE.class)
/*      */         {
/*      */           
/*      */           final DATE redirect(Accessor param1Accessor, int param1Int) throws SQLException
/*      */           {
/*  705 */             return param1Accessor.getDATE(param1Int);
/*      */           }
/*      */         });
/*      */ 
/*      */     
/*  710 */     CLASS_TO_REDIRECTOR.put(INTERVALDS.class, new Redirector<INTERVALDS>(INTERVALDS.class)
/*      */         {
/*      */           
/*      */           final INTERVALDS redirect(Accessor param1Accessor, int param1Int) throws SQLException
/*      */           {
/*  715 */             return param1Accessor.getINTERVALDS(param1Int);
/*      */           }
/*      */         });
/*      */ 
/*      */     
/*  720 */     CLASS_TO_REDIRECTOR.put(INTERVALYM.class, new Redirector<INTERVALYM>(INTERVALYM.class)
/*      */         {
/*      */           
/*      */           final INTERVALYM redirect(Accessor param1Accessor, int param1Int) throws SQLException
/*      */           {
/*  725 */             return param1Accessor.getINTERVALYM(param1Int);
/*      */           }
/*      */         });
/*      */ 
/*      */     
/*  730 */     CLASS_TO_REDIRECTOR.put(NUMBER.class, new Redirector<NUMBER>(NUMBER.class)
/*      */         {
/*      */           
/*      */           final NUMBER redirect(Accessor param1Accessor, int param1Int) throws SQLException
/*      */           {
/*  735 */             return param1Accessor.getNUMBER(param1Int);
/*      */           }
/*      */         });
/*      */ 
/*      */     
/*  740 */     CLASS_TO_REDIRECTOR.put(OPAQUE.class, new Redirector<OPAQUE>(OPAQUE.class)
/*      */         {
/*      */           
/*      */           final OPAQUE redirect(Accessor param1Accessor, int param1Int) throws SQLException
/*      */           {
/*  745 */             return param1Accessor.getOPAQUE(param1Int);
/*      */           }
/*      */         });
/*      */ 
/*      */     
/*  750 */     CLASS_TO_REDIRECTOR.put(ORAData.class, new Redirector<ORAData>(ORAData.class)
/*      */         {
/*      */           
/*      */           final ORAData redirect(Accessor param1Accessor, int param1Int) throws SQLException
/*      */           {
/*  755 */             return param1Accessor.getORAData(param1Int);
/*      */           }
/*      */         });
/*      */ 
/*      */     
/*  760 */     CLASS_TO_REDIRECTOR.put(OracleData.class, new Redirector<OracleData>(OracleData.class)
/*      */         {
/*      */           
/*      */           final OracleData redirect(Accessor param1Accessor, int param1Int) throws SQLException
/*      */           {
/*  765 */             return param1Accessor.getOracleData(param1Int);
/*      */           }
/*      */         });
/*      */ 
/*      */     
/*  770 */     CLASS_TO_REDIRECTOR.put(RAW.class, new Redirector<RAW>(RAW.class)
/*      */         {
/*      */           
/*      */           final RAW redirect(Accessor param1Accessor, int param1Int) throws SQLException
/*      */           {
/*  775 */             return param1Accessor.getRAW(param1Int);
/*      */           }
/*      */         });
/*      */ 
/*      */     
/*  780 */     CLASS_TO_REDIRECTOR.put(REF.class, new Redirector<REF>(REF.class)
/*      */         {
/*      */           
/*      */           final REF redirect(Accessor param1Accessor, int param1Int) throws SQLException
/*      */           {
/*  785 */             return param1Accessor.getREF(param1Int);
/*      */           }
/*      */         });
/*      */ 
/*      */     
/*  790 */     CLASS_TO_REDIRECTOR.put(ROWID.class, new Redirector<ROWID>(ROWID.class)
/*      */         {
/*      */           
/*      */           final ROWID redirect(Accessor param1Accessor, int param1Int) throws SQLException
/*      */           {
/*  795 */             return param1Accessor.getROWID(param1Int);
/*      */           }
/*      */         });
/*      */ 
/*      */     
/*  800 */     CLASS_TO_REDIRECTOR.put(STRUCT.class, new Redirector<STRUCT>(STRUCT.class)
/*      */         {
/*      */           
/*      */           final STRUCT redirect(Accessor param1Accessor, int param1Int) throws SQLException
/*      */           {
/*  805 */             return param1Accessor.getSTRUCT(param1Int);
/*      */           }
/*      */         });
/*      */ 
/*      */     
/*  810 */     CLASS_TO_REDIRECTOR.put(TIMESTAMPLTZ.class, new Redirector<TIMESTAMPLTZ>(TIMESTAMPLTZ.class)
/*      */         {
/*      */           
/*      */           final TIMESTAMPLTZ redirect(Accessor param1Accessor, int param1Int) throws SQLException
/*      */           {
/*  815 */             return param1Accessor.getTIMESTAMPLTZ(param1Int);
/*      */           }
/*      */         });
/*      */ 
/*      */     
/*  820 */     CLASS_TO_REDIRECTOR.put(TIMESTAMPTZ.class, new Redirector<TIMESTAMPTZ>(TIMESTAMPTZ.class)
/*      */         {
/*      */           
/*      */           final TIMESTAMPTZ redirect(Accessor param1Accessor, int param1Int) throws SQLException
/*      */           {
/*  825 */             return param1Accessor.getTIMESTAMPTZ(param1Int);
/*      */           }
/*      */         });
/*      */ 
/*      */     
/*  830 */     CLASS_TO_REDIRECTOR.put(TIMESTAMP.class, new Redirector<TIMESTAMP>(TIMESTAMP.class)
/*      */         {
/*      */           
/*      */           final TIMESTAMP redirect(Accessor param1Accessor, int param1Int) throws SQLException
/*      */           {
/*  835 */             return param1Accessor.getTIMESTAMP(param1Int);
/*      */           }
/*      */         });
/*      */ 
/*      */     
/*  840 */     CLASS_TO_REDIRECTOR.put(OracleArray.class, new Redirector<OracleArray>(OracleArray.class)
/*      */         {
/*      */           
/*      */           final OracleArray redirect(Accessor param1Accessor, int param1Int) throws SQLException
/*      */           {
/*  845 */             return (OracleArray)param1Accessor.getARRAY(param1Int);
/*      */           }
/*      */         });
/*      */ 
/*      */     
/*  850 */     CLASS_TO_REDIRECTOR.put(OracleBlob.class, new Redirector<OracleBlob>(OracleBlob.class)
/*      */         {
/*      */           
/*      */           final OracleBlob redirect(Accessor param1Accessor, int param1Int) throws SQLException
/*      */           {
/*  855 */             return (OracleBlob)param1Accessor.getBLOB(param1Int);
/*      */           }
/*      */         });
/*      */ 
/*      */     
/*  860 */     CLASS_TO_REDIRECTOR.put(OracleClob.class, new Redirector<OracleClob>(OracleClob.class)
/*      */         {
/*      */           
/*      */           final OracleClob redirect(Accessor param1Accessor, int param1Int) throws SQLException
/*      */           {
/*  865 */             return (OracleClob)param1Accessor.getCLOB(param1Int);
/*      */           }
/*      */         });
/*      */ 
/*      */     
/*  870 */     CLASS_TO_REDIRECTOR.put(OracleBfile.class, new Redirector<OracleBfile>(OracleBfile.class)
/*      */         {
/*      */           
/*      */           final OracleBfile redirect(Accessor param1Accessor, int param1Int) throws SQLException
/*      */           {
/*  875 */             return (OracleBfile)param1Accessor.getBFILE(param1Int);
/*      */           }
/*      */         });
/*      */ 
/*      */     
/*  880 */     CLASS_TO_REDIRECTOR.put(OracleRef.class, new Redirector<OracleRef>(OracleRef.class)
/*      */         {
/*      */           
/*      */           final OracleRef redirect(Accessor param1Accessor, int param1Int) throws SQLException
/*      */           {
/*  885 */             return (OracleRef)param1Accessor.getREF(param1Int);
/*      */           }
/*      */         });
/*      */ 
/*      */     
/*  890 */     CLASS_TO_REDIRECTOR.put(OracleOpaque.class, new Redirector<OracleOpaque>(OracleOpaque.class)
/*      */         {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           final OracleOpaque redirect(Accessor param1Accessor, int param1Int) throws SQLException
/*      */           {
/*  899 */             return (OracleOpaque)param1Accessor.getOPAQUE(param1Int);
/*      */           }
/*      */         });
/*      */ 
/*      */     
/*  904 */     CLASS_TO_REDIRECTOR.put(InputStream.class, new Redirector<InputStream>(InputStream.class)
/*      */         {
/*      */           
/*      */           final InputStream redirect(Accessor param1Accessor, int param1Int) throws SQLException
/*      */           {
/*  909 */             return param1Accessor.getBinaryStream(param1Int);
/*      */           }
/*      */         });
/*      */ 
/*      */     
/*  914 */     CLASS_TO_REDIRECTOR.put(Reader.class, new Redirector<Reader>(Reader.class)
/*      */         {
/*      */           
/*      */           final Reader redirect(Accessor param1Accessor, int param1Int) throws SQLException
/*      */           {
/*  919 */             return param1Accessor.getCharacterStream(param1Int);
/*      */           }
/*      */         });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  930 */   private static final HashMap<Class, Redirector> CLASS_TO_ERROR = new HashMap<>();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static {
/*  937 */     CLASS_TO_ERROR.put(Array.class, new Redirector<Array>(Array.class)
/*      */         {
/*      */ 
/*      */           
/*      */           final Array redirect(Accessor param1Accessor, int param1Int) throws SQLException
/*      */           {
/*  943 */             SQLException sQLException = DatabaseError.createSqlException((OracleConnection)null, 4);
/*  944 */             sQLException.fillInStackTrace();
/*  945 */             throw sQLException;
/*      */           }
/*      */         });
/*      */ 
/*      */ 
/*      */     
/*  951 */     CLASS_TO_ERROR.put(BigDecimal.class, new Redirector<BigDecimal>(BigDecimal.class)
/*      */         {
/*      */ 
/*      */           
/*      */           final BigDecimal redirect(Accessor param1Accessor, int param1Int) throws SQLException
/*      */           {
/*  957 */             SQLException sQLException = DatabaseError.createSqlException((OracleConnection)null, 4);
/*  958 */             sQLException.fillInStackTrace();
/*  959 */             throw sQLException;
/*      */           }
/*      */         });
/*      */ 
/*      */ 
/*      */     
/*  965 */     CLASS_TO_ERROR.put(Blob.class, new Redirector<Blob>(Blob.class)
/*      */         {
/*      */ 
/*      */           
/*      */           final Blob redirect(Accessor param1Accessor, int param1Int) throws SQLException
/*      */           {
/*  971 */             SQLException sQLException = DatabaseError.createSqlException((OracleConnection)null, 4);
/*  972 */             sQLException.fillInStackTrace();
/*  973 */             throw sQLException;
/*      */           }
/*      */         });
/*      */ 
/*      */ 
/*      */     
/*  979 */     CLASS_TO_ERROR.put(Boolean.class, new Redirector<Boolean>(Boolean.class)
/*      */         {
/*      */ 
/*      */           
/*      */           final Boolean redirect(Accessor param1Accessor, int param1Int) throws SQLException
/*      */           {
/*  985 */             SQLException sQLException = DatabaseError.createSqlException((OracleConnection)null, 4);
/*  986 */             sQLException.fillInStackTrace();
/*  987 */             throw sQLException;
/*      */           }
/*      */         });
/*      */ 
/*      */ 
/*      */     
/*  993 */     CLASS_TO_ERROR.put(Byte.class, new Redirector<Byte>(Byte.class)
/*      */         {
/*      */ 
/*      */           
/*      */           final Byte redirect(Accessor param1Accessor, int param1Int) throws SQLException
/*      */           {
/*  999 */             SQLException sQLException = DatabaseError.createSqlException((OracleConnection)null, 4);
/* 1000 */             sQLException.fillInStackTrace();
/* 1001 */             throw sQLException;
/*      */           }
/*      */         });
/*      */ 
/*      */ 
/*      */     
/* 1007 */     CLASS_TO_ERROR.put(byte[].class, new Redirector<byte[]>(byte[].class)
/*      */         {
/*      */ 
/*      */           
/*      */           final byte[] redirect(Accessor param1Accessor, int param1Int) throws SQLException
/*      */           {
/* 1013 */             SQLException sQLException = DatabaseError.createSqlException((OracleConnection)null, 4);
/* 1014 */             sQLException.fillInStackTrace();
/* 1015 */             throw sQLException;
/*      */           }
/*      */         });
/*      */ 
/*      */ 
/*      */     
/* 1021 */     CLASS_TO_ERROR.put(Clob.class, new Redirector<Clob>(Clob.class)
/*      */         {
/*      */ 
/*      */           
/*      */           final Clob redirect(Accessor param1Accessor, int param1Int) throws SQLException
/*      */           {
/* 1027 */             SQLException sQLException = DatabaseError.createSqlException((OracleConnection)null, 4);
/* 1028 */             sQLException.fillInStackTrace();
/* 1029 */             throw sQLException;
/*      */           }
/*      */         });
/*      */ 
/*      */ 
/*      */     
/* 1035 */     CLASS_TO_ERROR.put(Date.class, new Redirector<Date>(Date.class)
/*      */         {
/*      */ 
/*      */           
/*      */           final Date redirect(Accessor param1Accessor, int param1Int) throws SQLException
/*      */           {
/* 1041 */             SQLException sQLException = DatabaseError.createSqlException((OracleConnection)null, 4);
/* 1042 */             sQLException.fillInStackTrace();
/* 1043 */             throw sQLException;
/*      */           }
/*      */         });
/*      */ 
/*      */ 
/*      */     
/* 1049 */     CLASS_TO_ERROR.put(Double.class, new Redirector<Double>(Double.class)
/*      */         {
/*      */ 
/*      */           
/*      */           final Double redirect(Accessor param1Accessor, int param1Int) throws SQLException
/*      */           {
/* 1055 */             SQLException sQLException = DatabaseError.createSqlException((OracleConnection)null, 4);
/* 1056 */             sQLException.fillInStackTrace();
/* 1057 */             throw sQLException;
/*      */           }
/*      */         });
/*      */ 
/*      */ 
/*      */     
/* 1063 */     CLASS_TO_ERROR.put(Float.class, new Redirector<Float>(Float.class)
/*      */         {
/*      */ 
/*      */           
/*      */           final Float redirect(Accessor param1Accessor, int param1Int) throws SQLException
/*      */           {
/* 1069 */             SQLException sQLException = DatabaseError.createSqlException((OracleConnection)null, 4);
/* 1070 */             sQLException.fillInStackTrace();
/* 1071 */             throw sQLException;
/*      */           }
/*      */         });
/*      */ 
/*      */ 
/*      */     
/* 1077 */     CLASS_TO_ERROR.put(Integer.class, new Redirector<Integer>(Integer.class)
/*      */         {
/*      */ 
/*      */           
/*      */           final Integer redirect(Accessor param1Accessor, int param1Int) throws SQLException
/*      */           {
/* 1083 */             SQLException sQLException = DatabaseError.createSqlException((OracleConnection)null, 4);
/* 1084 */             sQLException.fillInStackTrace();
/* 1085 */             throw sQLException;
/*      */           }
/*      */         });
/*      */ 
/*      */ 
/*      */     
/* 1091 */     CLASS_TO_ERROR.put(Long.class, new Redirector<Long>(Long.class)
/*      */         {
/*      */ 
/*      */           
/*      */           final Long redirect(Accessor param1Accessor, int param1Int) throws SQLException
/*      */           {
/* 1097 */             SQLException sQLException = DatabaseError.createSqlException((OracleConnection)null, 4);
/* 1098 */             sQLException.fillInStackTrace();
/* 1099 */             throw sQLException;
/*      */           }
/*      */         });
/*      */ 
/*      */ 
/*      */     
/* 1105 */     CLASS_TO_ERROR.put(NClob.class, new Redirector<NClob>(NClob.class)
/*      */         {
/*      */ 
/*      */           
/*      */           final NClob redirect(Accessor param1Accessor, int param1Int) throws SQLException
/*      */           {
/* 1111 */             SQLException sQLException = DatabaseError.createSqlException((OracleConnection)null, 4);
/* 1112 */             sQLException.fillInStackTrace();
/* 1113 */             throw sQLException;
/*      */           }
/*      */         });
/*      */ 
/*      */ 
/*      */     
/* 1119 */     CLASS_TO_ERROR.put(Ref.class, new Redirector<Ref>(Ref.class)
/*      */         {
/*      */ 
/*      */           
/*      */           final Ref redirect(Accessor param1Accessor, int param1Int) throws SQLException
/*      */           {
/* 1125 */             SQLException sQLException = DatabaseError.createSqlException((OracleConnection)null, 4);
/* 1126 */             sQLException.fillInStackTrace();
/* 1127 */             throw sQLException;
/*      */           }
/*      */         });
/*      */ 
/*      */ 
/*      */     
/* 1133 */     CLASS_TO_ERROR.put(RowId.class, new Redirector<RowId>(RowId.class)
/*      */         {
/*      */ 
/*      */           
/*      */           final RowId redirect(Accessor param1Accessor, int param1Int) throws SQLException
/*      */           {
/* 1139 */             SQLException sQLException = DatabaseError.createSqlException((OracleConnection)null, 4);
/* 1140 */             sQLException.fillInStackTrace();
/* 1141 */             throw sQLException;
/*      */           }
/*      */         });
/*      */ 
/*      */ 
/*      */     
/* 1147 */     CLASS_TO_ERROR.put(Short.class, new Redirector<Short>(Short.class)
/*      */         {
/*      */ 
/*      */           
/*      */           final Short redirect(Accessor param1Accessor, int param1Int) throws SQLException
/*      */           {
/* 1153 */             SQLException sQLException = DatabaseError.createSqlException((OracleConnection)null, 4);
/* 1154 */             sQLException.fillInStackTrace();
/* 1155 */             throw sQLException;
/*      */           }
/*      */         });
/*      */ 
/*      */ 
/*      */     
/* 1161 */     CLASS_TO_ERROR.put(SQLXML.class, new Redirector<SQLXML>(SQLXML.class)
/*      */         {
/*      */ 
/*      */           
/*      */           final SQLXML redirect(Accessor param1Accessor, int param1Int) throws SQLException
/*      */           {
/* 1167 */             SQLException sQLException = DatabaseError.createSqlException((OracleConnection)null, 4);
/* 1168 */             sQLException.fillInStackTrace();
/* 1169 */             throw sQLException;
/*      */           }
/*      */         });
/*      */ 
/*      */ 
/*      */     
/* 1175 */     CLASS_TO_ERROR.put(String.class, new Redirector<String>(String.class)
/*      */         {
/*      */ 
/*      */           
/*      */           final String redirect(Accessor param1Accessor, int param1Int) throws SQLException
/*      */           {
/* 1181 */             SQLException sQLException = DatabaseError.createSqlException((OracleConnection)null, 4);
/* 1182 */             sQLException.fillInStackTrace();
/* 1183 */             throw sQLException;
/*      */           }
/*      */         });
/*      */ 
/*      */ 
/*      */     
/* 1189 */     CLASS_TO_ERROR.put(Struct.class, new Redirector<Struct>(Struct.class)
/*      */         {
/*      */ 
/*      */           
/*      */           final Struct redirect(Accessor param1Accessor, int param1Int) throws SQLException
/*      */           {
/* 1195 */             SQLException sQLException = DatabaseError.createSqlException((OracleConnection)null, 4);
/* 1196 */             sQLException.fillInStackTrace();
/* 1197 */             throw sQLException;
/*      */           }
/*      */         });
/*      */ 
/*      */ 
/*      */     
/* 1203 */     CLASS_TO_ERROR.put(Time.class, new Redirector<Time>(Time.class)
/*      */         {
/*      */ 
/*      */           
/*      */           final Time redirect(Accessor param1Accessor, int param1Int) throws SQLException
/*      */           {
/* 1209 */             SQLException sQLException = DatabaseError.createSqlException((OracleConnection)null, 4);
/* 1210 */             sQLException.fillInStackTrace();
/* 1211 */             throw sQLException;
/*      */           }
/*      */         });
/*      */ 
/*      */ 
/*      */     
/* 1217 */     CLASS_TO_ERROR.put(Timestamp.class, new Redirector<Timestamp>(Timestamp.class)
/*      */         {
/*      */ 
/*      */           
/*      */           final Timestamp redirect(Accessor param1Accessor, int param1Int) throws SQLException
/*      */           {
/* 1223 */             SQLException sQLException = DatabaseError.createSqlException((OracleConnection)null, 4);
/* 1224 */             sQLException.fillInStackTrace();
/* 1225 */             throw sQLException;
/*      */           }
/*      */         });
/*      */ 
/*      */ 
/*      */     
/* 1231 */     CLASS_TO_ERROR.put(URL.class, new Redirector<URL>(URL.class)
/*      */         {
/*      */ 
/*      */           
/*      */           final URL redirect(Accessor param1Accessor, int param1Int) throws SQLException
/*      */           {
/* 1237 */             SQLException sQLException = DatabaseError.createSqlException((OracleConnection)null, 4);
/* 1238 */             sQLException.fillInStackTrace();
/* 1239 */             throw sQLException;
/*      */           }
/*      */         });
/*      */ 
/*      */ 
/*      */     
/* 1245 */     CLASS_TO_ERROR.put(BigInteger.class, new Redirector<BigInteger>(BigInteger.class)
/*      */         {
/*      */ 
/*      */           
/*      */           final BigInteger redirect(Accessor param1Accessor, int param1Int) throws SQLException
/*      */           {
/* 1251 */             SQLException sQLException = DatabaseError.createSqlException((OracleConnection)null, 4);
/* 1252 */             sQLException.fillInStackTrace();
/* 1253 */             throw sQLException;
/*      */           }
/*      */         });
/*      */ 
/*      */ 
/*      */     
/* 1259 */     CLASS_TO_ERROR.put(Date.class, new Redirector<Date>(Date.class)
/*      */         {
/*      */ 
/*      */           
/*      */           final Date redirect(Accessor param1Accessor, int param1Int) throws SQLException
/*      */           {
/* 1265 */             SQLException sQLException = DatabaseError.createSqlException((OracleConnection)null, 4);
/* 1266 */             sQLException.fillInStackTrace();
/* 1267 */             throw sQLException;
/*      */           }
/*      */         });
/*      */ 
/*      */ 
/*      */     
/* 1273 */     CLASS_TO_ERROR.put(Calendar.class, new Redirector<Calendar>(Calendar.class)
/*      */         {
/*      */ 
/*      */           
/*      */           final Calendar redirect(Accessor param1Accessor, int param1Int) throws SQLException
/*      */           {
/* 1279 */             SQLException sQLException = DatabaseError.createSqlException((OracleConnection)null, 4);
/* 1280 */             sQLException.fillInStackTrace();
/* 1281 */             throw sQLException;
/*      */           }
/*      */         });
/*      */ 
/*      */ 
/*      */     
/* 1287 */     CLASS_TO_ERROR.put(ARRAY.class, new Redirector<ARRAY>(ARRAY.class)
/*      */         {
/*      */ 
/*      */           
/*      */           final ARRAY redirect(Accessor param1Accessor, int param1Int) throws SQLException
/*      */           {
/* 1293 */             SQLException sQLException = DatabaseError.createSqlException((OracleConnection)null, 4);
/* 1294 */             sQLException.fillInStackTrace();
/* 1295 */             throw sQLException;
/*      */           }
/*      */         });
/*      */ 
/*      */ 
/*      */     
/* 1301 */     CLASS_TO_ERROR.put(BFILE.class, new Redirector<BFILE>(BFILE.class)
/*      */         {
/*      */ 
/*      */           
/*      */           final BFILE redirect(Accessor param1Accessor, int param1Int) throws SQLException
/*      */           {
/* 1307 */             SQLException sQLException = DatabaseError.createSqlException((OracleConnection)null, 4);
/* 1308 */             sQLException.fillInStackTrace();
/* 1309 */             throw sQLException;
/*      */           }
/*      */         });
/*      */ 
/*      */ 
/*      */     
/* 1315 */     CLASS_TO_ERROR.put(BINARY_FLOAT.class, new Redirector<BINARY_FLOAT>(BINARY_FLOAT.class)
/*      */         {
/*      */ 
/*      */           
/*      */           final BINARY_FLOAT redirect(Accessor param1Accessor, int param1Int) throws SQLException
/*      */           {
/* 1321 */             SQLException sQLException = DatabaseError.createSqlException((OracleConnection)null, 4);
/* 1322 */             sQLException.fillInStackTrace();
/* 1323 */             throw sQLException;
/*      */           }
/*      */         });
/*      */ 
/*      */ 
/*      */     
/* 1329 */     CLASS_TO_ERROR.put(BINARY_DOUBLE.class, new Redirector<BINARY_DOUBLE>(BINARY_DOUBLE.class)
/*      */         {
/*      */ 
/*      */           
/*      */           final BINARY_DOUBLE redirect(Accessor param1Accessor, int param1Int) throws SQLException
/*      */           {
/* 1335 */             SQLException sQLException = DatabaseError.createSqlException((OracleConnection)null, 4);
/* 1336 */             sQLException.fillInStackTrace();
/* 1337 */             throw sQLException;
/*      */           }
/*      */         });
/*      */ 
/*      */ 
/*      */     
/* 1343 */     CLASS_TO_ERROR.put(BLOB.class, new Redirector<BLOB>(BLOB.class)
/*      */         {
/*      */ 
/*      */           
/*      */           final BLOB redirect(Accessor param1Accessor, int param1Int) throws SQLException
/*      */           {
/* 1349 */             SQLException sQLException = DatabaseError.createSqlException((OracleConnection)null, 4);
/* 1350 */             sQLException.fillInStackTrace();
/* 1351 */             throw sQLException;
/*      */           }
/*      */         });
/*      */ 
/*      */ 
/*      */     
/* 1357 */     CLASS_TO_ERROR.put(CHAR.class, new Redirector<CHAR>(CHAR.class)
/*      */         {
/*      */ 
/*      */           
/*      */           final CHAR redirect(Accessor param1Accessor, int param1Int) throws SQLException
/*      */           {
/* 1363 */             SQLException sQLException = DatabaseError.createSqlException((OracleConnection)null, 4);
/* 1364 */             sQLException.fillInStackTrace();
/* 1365 */             throw sQLException;
/*      */           }
/*      */         });
/*      */ 
/*      */ 
/*      */     
/* 1371 */     CLASS_TO_ERROR.put(CLOB.class, new Redirector<CLOB>(CLOB.class)
/*      */         {
/*      */ 
/*      */           
/*      */           final CLOB redirect(Accessor param1Accessor, int param1Int) throws SQLException
/*      */           {
/* 1377 */             SQLException sQLException = DatabaseError.createSqlException((OracleConnection)null, 4);
/* 1378 */             sQLException.fillInStackTrace();
/* 1379 */             throw sQLException;
/*      */           }
/*      */         });
/*      */ 
/*      */ 
/*      */     
/* 1385 */     CLASS_TO_ERROR.put(ResultSet.class, new Redirector<ResultSet>(ResultSet.class)
/*      */         {
/*      */ 
/*      */           
/*      */           final ResultSet redirect(Accessor param1Accessor, int param1Int) throws SQLException
/*      */           {
/* 1391 */             SQLException sQLException = DatabaseError.createSqlException((OracleConnection)null, 4);
/* 1392 */             sQLException.fillInStackTrace();
/* 1393 */             throw sQLException;
/*      */           }
/*      */         });
/*      */ 
/*      */ 
/*      */     
/* 1399 */     CLASS_TO_ERROR.put(DATE.class, new Redirector<DATE>(DATE.class)
/*      */         {
/*      */ 
/*      */           
/*      */           final DATE redirect(Accessor param1Accessor, int param1Int) throws SQLException
/*      */           {
/* 1405 */             SQLException sQLException = DatabaseError.createSqlException((OracleConnection)null, 4);
/* 1406 */             sQLException.fillInStackTrace();
/* 1407 */             throw sQLException;
/*      */           }
/*      */         });
/*      */ 
/*      */ 
/*      */     
/* 1413 */     CLASS_TO_ERROR.put(INTERVALDS.class, new Redirector<INTERVALDS>(INTERVALDS.class)
/*      */         {
/*      */ 
/*      */           
/*      */           final INTERVALDS redirect(Accessor param1Accessor, int param1Int) throws SQLException
/*      */           {
/* 1419 */             SQLException sQLException = DatabaseError.createSqlException((OracleConnection)null, 4);
/* 1420 */             sQLException.fillInStackTrace();
/* 1421 */             throw sQLException;
/*      */           }
/*      */         });
/*      */ 
/*      */ 
/*      */     
/* 1427 */     CLASS_TO_ERROR.put(INTERVALYM.class, new Redirector<INTERVALYM>(INTERVALYM.class)
/*      */         {
/*      */ 
/*      */           
/*      */           final INTERVALYM redirect(Accessor param1Accessor, int param1Int) throws SQLException
/*      */           {
/* 1433 */             SQLException sQLException = DatabaseError.createSqlException((OracleConnection)null, 4);
/* 1434 */             sQLException.fillInStackTrace();
/* 1435 */             throw sQLException;
/*      */           }
/*      */         });
/*      */ 
/*      */ 
/*      */     
/* 1441 */     CLASS_TO_ERROR.put(NUMBER.class, new Redirector<NUMBER>(NUMBER.class)
/*      */         {
/*      */ 
/*      */           
/*      */           final NUMBER redirect(Accessor param1Accessor, int param1Int) throws SQLException
/*      */           {
/* 1447 */             SQLException sQLException = DatabaseError.createSqlException((OracleConnection)null, 4);
/* 1448 */             sQLException.fillInStackTrace();
/* 1449 */             throw sQLException;
/*      */           }
/*      */         });
/*      */ 
/*      */ 
/*      */     
/* 1455 */     CLASS_TO_ERROR.put(OPAQUE.class, new Redirector<OPAQUE>(OPAQUE.class)
/*      */         {
/*      */ 
/*      */           
/*      */           final OPAQUE redirect(Accessor param1Accessor, int param1Int) throws SQLException
/*      */           {
/* 1461 */             SQLException sQLException = DatabaseError.createSqlException((OracleConnection)null, 4);
/* 1462 */             sQLException.fillInStackTrace();
/* 1463 */             throw sQLException;
/*      */           }
/*      */         });
/*      */ 
/*      */ 
/*      */     
/* 1469 */     CLASS_TO_ERROR.put(ORAData.class, new Redirector<ORAData>(ORAData.class)
/*      */         {
/*      */ 
/*      */           
/*      */           final ORAData redirect(Accessor param1Accessor, int param1Int) throws SQLException
/*      */           {
/* 1475 */             SQLException sQLException = DatabaseError.createSqlException((OracleConnection)null, 4);
/* 1476 */             sQLException.fillInStackTrace();
/* 1477 */             throw sQLException;
/*      */           }
/*      */         });
/*      */ 
/*      */ 
/*      */     
/* 1483 */     CLASS_TO_ERROR.put(OracleData.class, new Redirector<OracleData>(OracleData.class)
/*      */         {
/*      */ 
/*      */           
/*      */           final OracleData redirect(Accessor param1Accessor, int param1Int) throws SQLException
/*      */           {
/* 1489 */             SQLException sQLException = DatabaseError.createSqlException((OracleConnection)null, 4);
/* 1490 */             sQLException.fillInStackTrace();
/* 1491 */             throw sQLException;
/*      */           }
/*      */         });
/*      */ 
/*      */ 
/*      */     
/* 1497 */     CLASS_TO_ERROR.put(RAW.class, new Redirector<RAW>(RAW.class)
/*      */         {
/*      */ 
/*      */           
/*      */           final RAW redirect(Accessor param1Accessor, int param1Int) throws SQLException
/*      */           {
/* 1503 */             SQLException sQLException = DatabaseError.createSqlException((OracleConnection)null, 4);
/* 1504 */             sQLException.fillInStackTrace();
/* 1505 */             throw sQLException;
/*      */           }
/*      */         });
/*      */ 
/*      */ 
/*      */     
/* 1511 */     CLASS_TO_ERROR.put(REF.class, new Redirector<REF>(REF.class)
/*      */         {
/*      */ 
/*      */           
/*      */           final REF redirect(Accessor param1Accessor, int param1Int) throws SQLException
/*      */           {
/* 1517 */             SQLException sQLException = DatabaseError.createSqlException((OracleConnection)null, 4);
/* 1518 */             sQLException.fillInStackTrace();
/* 1519 */             throw sQLException;
/*      */           }
/*      */         });
/*      */ 
/*      */ 
/*      */     
/* 1525 */     CLASS_TO_ERROR.put(ROWID.class, new Redirector<ROWID>(ROWID.class)
/*      */         {
/*      */ 
/*      */           
/*      */           final ROWID redirect(Accessor param1Accessor, int param1Int) throws SQLException
/*      */           {
/* 1531 */             SQLException sQLException = DatabaseError.createSqlException((OracleConnection)null, 4);
/* 1532 */             sQLException.fillInStackTrace();
/* 1533 */             throw sQLException;
/*      */           }
/*      */         });
/*      */ 
/*      */ 
/*      */     
/* 1539 */     CLASS_TO_ERROR.put(STRUCT.class, new Redirector<STRUCT>(STRUCT.class)
/*      */         {
/*      */ 
/*      */           
/*      */           final STRUCT redirect(Accessor param1Accessor, int param1Int) throws SQLException
/*      */           {
/* 1545 */             SQLException sQLException = DatabaseError.createSqlException((OracleConnection)null, 4);
/* 1546 */             sQLException.fillInStackTrace();
/* 1547 */             throw sQLException;
/*      */           }
/*      */         });
/*      */ 
/*      */ 
/*      */     
/* 1553 */     CLASS_TO_ERROR.put(TIMESTAMPLTZ.class, new Redirector<TIMESTAMPLTZ>(TIMESTAMPLTZ.class)
/*      */         {
/*      */ 
/*      */           
/*      */           final TIMESTAMPLTZ redirect(Accessor param1Accessor, int param1Int) throws SQLException
/*      */           {
/* 1559 */             SQLException sQLException = DatabaseError.createSqlException((OracleConnection)null, 4);
/* 1560 */             sQLException.fillInStackTrace();
/* 1561 */             throw sQLException;
/*      */           }
/*      */         });
/*      */ 
/*      */ 
/*      */     
/* 1567 */     CLASS_TO_ERROR.put(TIMESTAMPTZ.class, new Redirector<TIMESTAMPTZ>(TIMESTAMPTZ.class)
/*      */         {
/*      */ 
/*      */           
/*      */           final TIMESTAMPTZ redirect(Accessor param1Accessor, int param1Int) throws SQLException
/*      */           {
/* 1573 */             SQLException sQLException = DatabaseError.createSqlException((OracleConnection)null, 4);
/* 1574 */             sQLException.fillInStackTrace();
/* 1575 */             throw sQLException;
/*      */           }
/*      */         });
/*      */ 
/*      */ 
/*      */     
/* 1581 */     CLASS_TO_ERROR.put(TIMESTAMP.class, new Redirector<TIMESTAMP>(TIMESTAMP.class)
/*      */         {
/*      */ 
/*      */           
/*      */           final TIMESTAMP redirect(Accessor param1Accessor, int param1Int) throws SQLException
/*      */           {
/* 1587 */             SQLException sQLException = DatabaseError.createSqlException((OracleConnection)null, 4);
/* 1588 */             sQLException.fillInStackTrace();
/* 1589 */             throw sQLException;
/*      */           }
/*      */         });
/*      */ 
/*      */ 
/*      */     
/* 1595 */     CLASS_TO_ERROR.put(OracleArray.class, new Redirector<OracleArray>(OracleArray.class)
/*      */         {
/*      */ 
/*      */           
/*      */           final OracleArray redirect(Accessor param1Accessor, int param1Int) throws SQLException
/*      */           {
/* 1601 */             SQLException sQLException = DatabaseError.createSqlException((OracleConnection)null, 4);
/* 1602 */             sQLException.fillInStackTrace();
/* 1603 */             throw sQLException;
/*      */           }
/*      */         });
/*      */ 
/*      */ 
/*      */     
/* 1609 */     CLASS_TO_ERROR.put(OracleBlob.class, new Redirector<OracleBlob>(OracleBlob.class)
/*      */         {
/*      */ 
/*      */           
/*      */           final OracleBlob redirect(Accessor param1Accessor, int param1Int) throws SQLException
/*      */           {
/* 1615 */             SQLException sQLException = DatabaseError.createSqlException((OracleConnection)null, 4);
/* 1616 */             sQLException.fillInStackTrace();
/* 1617 */             throw sQLException;
/*      */           }
/*      */         });
/*      */ 
/*      */ 
/*      */     
/* 1623 */     CLASS_TO_ERROR.put(OracleClob.class, new Redirector<OracleClob>(OracleClob.class)
/*      */         {
/*      */ 
/*      */           
/*      */           final OracleClob redirect(Accessor param1Accessor, int param1Int) throws SQLException
/*      */           {
/* 1629 */             SQLException sQLException = DatabaseError.createSqlException((OracleConnection)null, 4);
/* 1630 */             sQLException.fillInStackTrace();
/* 1631 */             throw sQLException;
/*      */           }
/*      */         });
/*      */ 
/*      */ 
/*      */     
/* 1637 */     CLASS_TO_ERROR.put(OracleBfile.class, new Redirector<OracleBfile>(OracleBfile.class)
/*      */         {
/*      */ 
/*      */           
/*      */           final OracleBfile redirect(Accessor param1Accessor, int param1Int) throws SQLException
/*      */           {
/* 1643 */             SQLException sQLException = DatabaseError.createSqlException((OracleConnection)null, 4);
/* 1644 */             sQLException.fillInStackTrace();
/* 1645 */             throw sQLException;
/*      */           }
/*      */         });
/*      */ 
/*      */ 
/*      */     
/* 1651 */     CLASS_TO_ERROR.put(OracleRef.class, new Redirector<OracleRef>(OracleRef.class)
/*      */         {
/*      */ 
/*      */           
/*      */           final OracleRef redirect(Accessor param1Accessor, int param1Int) throws SQLException
/*      */           {
/* 1657 */             SQLException sQLException = DatabaseError.createSqlException((OracleConnection)null, 4);
/* 1658 */             sQLException.fillInStackTrace();
/* 1659 */             throw sQLException;
/*      */           }
/*      */         });
/*      */ 
/*      */ 
/*      */     
/* 1665 */     CLASS_TO_ERROR.put(OracleOpaque.class, new Redirector<OracleOpaque>(OracleOpaque.class)
/*      */         {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           final OracleOpaque redirect(Accessor param1Accessor, int param1Int) throws SQLException
/*      */           {
/* 1675 */             SQLException sQLException = DatabaseError.createSqlException((OracleConnection)null, 4);
/* 1676 */             sQLException.fillInStackTrace();
/* 1677 */             throw sQLException;
/*      */           }
/*      */         });
/*      */ 
/*      */ 
/*      */     
/* 1683 */     CLASS_TO_ERROR.put(InputStream.class, new Redirector<InputStream>(InputStream.class)
/*      */         {
/*      */ 
/*      */           
/*      */           final InputStream redirect(Accessor param1Accessor, int param1Int) throws SQLException
/*      */           {
/* 1689 */             SQLException sQLException = DatabaseError.createSqlException((OracleConnection)null, 4);
/* 1690 */             sQLException.fillInStackTrace();
/* 1691 */             throw sQLException;
/*      */           }
/*      */         });
/*      */ 
/*      */ 
/*      */     
/* 1697 */     CLASS_TO_ERROR.put(Reader.class, new Redirector<Reader>(Reader.class)
/*      */         {
/*      */ 
/*      */           
/*      */           final Reader redirect(Accessor param1Accessor, int param1Int) throws SQLException
/*      */           {
/* 1703 */             SQLException sQLException = DatabaseError.createSqlException((OracleConnection)null, 4);
/* 1704 */             sQLException.fillInStackTrace();
/* 1705 */             throw sQLException;
/*      */           }
/*      */         });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static OracleConnection getConnectionDuringExceptionHandling() {
/* 1717 */     return null;
/*      */   }
/*      */ 
/*      */   
/* 1721 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*      */   public static final String BUILD_DATE = "Thu_Apr_04_15:09:24_PDT_2013";
/*      */   public static final boolean TRACE = false;
/*      */   
/*      */   abstract T redirect(Accessor paramAccessor, int paramInt) throws SQLException;
/*      */ }


/* Location:              C:\Users\olatu\OneDrive\Documents\Calypso\syncbase\sync_base.jar!\BOOT-INF\lib\ojdbc-7.jar!\oracle\jdbc\driver\Redirector.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */