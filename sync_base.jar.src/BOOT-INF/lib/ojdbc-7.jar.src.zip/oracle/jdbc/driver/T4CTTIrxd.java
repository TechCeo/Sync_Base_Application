/*      */ package oracle.jdbc.driver;
/*      */ 
/*      */ import java.io.IOException;
/*      */ import java.io.InputStream;
/*      */ import java.io.PrintWriter;
/*      */ import java.io.StringWriter;
/*      */ import java.sql.SQLException;
/*      */ import java.util.BitSet;
/*      */ import java.util.Vector;
/*      */ import oracle.jdbc.internal.OracleConnection;
/*      */ import oracle.jdbc.oracore.OracleTypeADT;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ class T4CTTIrxd
/*      */   extends T4CTTIMsg
/*      */ {
/*   46 */   static final byte[] NO_BYTES = new byte[0];
/*      */ 
/*      */ 
/*      */   
/*      */   byte[] buffer;
/*      */ 
/*      */   
/*      */   byte[] bufferCHAR;
/*      */ 
/*      */   
/*   56 */   BitSet bvcColSent = null;
/*   57 */   int nbOfColumns = 0;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   boolean bvcFound = false;
/*      */ 
/*      */ 
/*      */   
/*      */   static final byte TTICMD_UNAUTHORIZED = 1;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   T4CTTIrxd(T4CConnection paramT4CConnection) {
/*   72 */     super(paramT4CConnection, (byte)7);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void init() {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void setNumberOfColumns(int paramInt) {
/*   86 */     this.nbOfColumns = paramInt;
/*   87 */     this.bvcFound = false;
/*      */     
/*   89 */     if (this.bvcColSent == null || this.bvcColSent.length() < this.nbOfColumns) {
/*      */       
/*   91 */       this.bvcColSent = new BitSet(this.nbOfColumns);
/*      */     }
/*      */     else {
/*      */       
/*   95 */       this.bvcColSent.clear();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void unmarshalBVC(int paramInt) throws SQLException, IOException {
/*  103 */     byte b1 = 0;
/*      */     
/*      */     int i;
/*  106 */     for (i = 0; i < this.bvcColSent.length(); i++) {
/*  107 */       this.bvcColSent.clear(i);
/*      */     }
/*      */     
/*  110 */     i = this.nbOfColumns / 8 + ((this.nbOfColumns % 8 != 0) ? 1 : 0);
/*      */     
/*  112 */     for (byte b2 = 0; b2 < i; b2++) {
/*      */       
/*  114 */       byte b = (byte)(this.meg.unmarshalUB1() & 0xFF);
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  119 */       for (byte b3 = 0; b3 < 8; b3++) {
/*      */         
/*  121 */         if ((b & 1 << b3) != 0) {
/*      */           
/*  123 */           this.bvcColSent.set(b2 * 8 + b3);
/*      */           
/*  125 */           b1++;
/*      */         }
/*      */         else {
/*      */           
/*  129 */           this.bvcColSent.clear(b2 * 8 + b3);
/*      */         } 
/*      */       } 
/*      */     } 
/*      */     
/*  134 */     if (b1 != paramInt) {
/*      */ 
/*      */       
/*  137 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), -1, "INTERNAL ERROR: oracle.jdbc.driver.T4CTTIrxd.unmarshalBVC: bits missing in vector");
/*      */       
/*  139 */       sQLException.fillInStackTrace();
/*  140 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/*  144 */     this.bvcFound = true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void readBitVector(byte[] paramArrayOfbyte) throws SQLException, IOException {
/*      */     byte b;
/*  158 */     for (b = 0; b < this.bvcColSent.length(); b++) {
/*  159 */       this.bvcColSent.clear(b);
/*      */     }
/*  161 */     if (paramArrayOfbyte == null || paramArrayOfbyte.length == 0) {
/*  162 */       this.bvcFound = false;
/*      */     } else {
/*      */       
/*  165 */       for (b = 0; b < paramArrayOfbyte.length; b++) {
/*  166 */         byte b1 = paramArrayOfbyte[b];
/*  167 */         for (byte b2 = 0; b2 < 8; b2++) {
/*  168 */           if ((b1 & 1 << b2) != 0)
/*  169 */             this.bvcColSent.set(b * 8 + b2); 
/*      */         } 
/*      */       } 
/*  172 */       this.bvcFound = true;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   Vector<IOException> marshal(byte[] paramArrayOfbyte1, char[] paramArrayOfchar1, short[] paramArrayOfshort1, int paramInt1, byte[] paramArrayOfbyte2, DBConversion paramDBConversion, InputStream[] paramArrayOfInputStream, byte[][] paramArrayOfbyte, OracleTypeADT[] paramArrayOfOracleTypeADT, byte[] paramArrayOfbyte3, char[] paramArrayOfchar2, short[] paramArrayOfshort2, byte[] paramArrayOfbyte4, int paramInt2, int[] paramArrayOfint1, boolean paramBoolean1, int[] paramArrayOfint2, int[] paramArrayOfint3, int[][] paramArrayOfint, boolean paramBoolean2) throws IOException {
/*  200 */     Vector<IOException> vector = null;
/*      */     
/*      */     try {
/*      */       int k;
/*      */       
/*  205 */       marshalTTCcode();
/*      */ 
/*      */       
/*  208 */       int i = paramArrayOfshort1[paramInt1 + 0] & 0xFFFF;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  230 */       byte b1 = 0;
/*  231 */       int j = paramArrayOfint3[0];
/*  232 */       int[] arrayOfInt = paramArrayOfint[0];
/*      */       
/*  234 */       byte b2 = 0;
/*      */ 
/*      */ 
/*      */       
/*  238 */       if (paramBoolean2) {
/*      */         
/*  240 */         k = 1;
/*  241 */         assert j > 0 : "No postoned columns in RXD";
/*      */       }
/*      */       else {
/*      */         
/*  245 */         for (byte b = 0; b < i; b++) {
/*      */           
/*  247 */           if (b1 < j && arrayOfInt[b1] == b) {
/*      */ 
/*      */             
/*  250 */             b1++;
/*      */             
/*      */             continue;
/*      */           } 
/*  254 */           boolean bool = false;
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  259 */           int m = paramInt1 + 5 + 10 * b;
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  264 */           int i2 = paramArrayOfshort1[m + 0] & 0xFFFF;
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  269 */           if (paramArrayOfbyte4 != null && (paramArrayOfbyte4[b] & 0x20) == 0) {
/*      */ 
/*      */ 
/*      */             
/*  273 */             if (i2 == 998) {
/*  274 */               b2++;
/*      */             }
/*      */             
/*      */             continue;
/*      */           } 
/*  279 */           int n = ((paramArrayOfshort1[m + 7] & 0xFFFF) << 16) + (paramArrayOfshort1[m + 8] & 0xFFFF) + paramInt2;
/*      */ 
/*      */ 
/*      */           
/*  283 */           int i3 = ((paramArrayOfshort1[m + 5] & 0xFFFF) << 16) + (paramArrayOfshort1[m + 6] & 0xFFFF) + paramInt2;
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  288 */           int i1 = paramArrayOfshort1[n] & 0xFFFF;
/*      */           
/*  290 */           short s = paramArrayOfshort1[i3];
/*      */           
/*  292 */           if (i2 == 116) {
/*      */             
/*  294 */             this.meg.marshalUB1((short)1);
/*  295 */             this.meg.marshalUB1((short)0);
/*      */             
/*      */             continue;
/*      */           } 
/*  299 */           if (i2 == 994) {
/*      */             
/*  301 */             s = -1;
/*  302 */             int i4 = paramArrayOfint2[3 + b * 4 + 0];
/*      */ 
/*      */ 
/*      */             
/*  306 */             if (i4 == 109) {
/*  307 */               bool = true;
/*      */             }
/*  309 */           } else if (i2 == 8 || i2 == 24 || (!paramBoolean1 && paramArrayOfint1 != null && paramArrayOfint1.length > b && paramArrayOfint1[b] > this.connection.maxNonStreamBindByteSize)) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*  327 */             if (j >= arrayOfInt.length) {
/*      */               
/*  329 */               int[] arrayOfInt1 = new int[arrayOfInt.length << 1];
/*      */ 
/*      */               
/*  332 */               System.arraycopy(arrayOfInt, 0, arrayOfInt1, 0, arrayOfInt.length);
/*      */ 
/*      */ 
/*      */               
/*  336 */               arrayOfInt = arrayOfInt1;
/*      */             } 
/*      */             
/*  339 */             arrayOfInt[j++] = b;
/*      */ 
/*      */ 
/*      */             
/*      */             continue;
/*      */           } 
/*      */ 
/*      */           
/*  347 */           if (s == -1) {
/*      */             
/*  349 */             if (i2 == 109 || bool) {
/*      */ 
/*      */               
/*  352 */               this.meg.marshalDALC(NO_BYTES);
/*  353 */               this.meg.marshalDALC(NO_BYTES);
/*  354 */               this.meg.marshalDALC(NO_BYTES);
/*  355 */               this.meg.marshalUB2(0);
/*  356 */               this.meg.marshalUB4(0L);
/*  357 */               this.meg.marshalUB2(1);
/*      */               
/*      */               continue;
/*      */             } 
/*  361 */             if (i2 == 998) {
/*      */               
/*  363 */               b2++;
/*  364 */               this.meg.marshalUB4(0L);
/*      */               continue;
/*      */             } 
/*  367 */             if (i2 == 112 || i2 == 113 || i2 == 114) {
/*      */               
/*  369 */               this.meg.marshalUB4(0L);
/*      */               continue;
/*      */             } 
/*  372 */             if (i2 != 8 && i2 != 24) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */               
/*  381 */               this.meg.marshalUB1((short)0);
/*      */               
/*      */               continue;
/*      */             } 
/*      */           } 
/*      */           
/*  387 */           if (i2 == 998) {
/*      */ 
/*      */             
/*  390 */             int i4 = (paramArrayOfshort2[6 + b2 * 8 + 4] & 0xFFFF) << 16 & 0xFFFF000 | paramArrayOfshort2[6 + b2 * 8 + 5] & 0xFFFF;
/*      */ 
/*      */             
/*  393 */             int i5 = (paramArrayOfshort2[6 + b2 * 8 + 6] & 0xFFFF) << 16 & 0xFFFF000 | paramArrayOfshort2[6 + b2 * 8 + 7] & 0xFFFF;
/*      */ 
/*      */             
/*  396 */             int i6 = paramArrayOfshort2[6 + b2 * 8] & 0xFFFF;
/*  397 */             int i7 = paramArrayOfshort2[6 + b2 * 8 + 1] & 0xFFFF;
/*      */             
/*  399 */             this.meg.marshalUB4(i4);
/*      */             
/*  401 */             for (byte b3 = 0; b3 < i4; b3++) {
/*      */               
/*  403 */               int i8 = i5 + b3 * i7;
/*      */               
/*  405 */               if (i6 == 9) {
/*      */                 
/*  407 */                 int i9 = paramArrayOfchar2[i8] / 2;
/*  408 */                 int i10 = 0;
/*  409 */                 i10 = paramDBConversion.javaCharsToCHARBytes(paramArrayOfchar2, i8 + 1, paramArrayOfbyte2, 0, i9);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */                 
/*  415 */                 this.meg.marshalCLR(paramArrayOfbyte2, i10);
/*      */               }
/*      */               else {
/*      */                 
/*  419 */                 i1 = paramArrayOfbyte3[i8];
/*      */                 
/*  421 */                 if (i1 < 1) {
/*  422 */                   this.meg.marshalUB1((short)0);
/*      */                 } else {
/*  424 */                   this.meg.marshalCLR(paramArrayOfbyte3, i8 + 1, i1);
/*      */                 } 
/*      */               } 
/*      */             } 
/*  428 */             b2++;
/*      */ 
/*      */ 
/*      */           
/*      */           }
/*      */           else {
/*      */ 
/*      */ 
/*      */             
/*  437 */             int i4 = paramArrayOfshort1[m + 1] & 0xFFFF;
/*      */ 
/*      */ 
/*      */             
/*  441 */             if (i4 != 0) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */               
/*  447 */               int i5 = ((paramArrayOfshort1[m + 3] & 0xFFFF) << 16) + (paramArrayOfshort1[m + 4] & 0xFFFF) + i4 * paramInt2;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */               
/*  454 */               if (i2 == 6) {
/*      */                 
/*  456 */                 i5++;
/*  457 */                 i1--;
/*      */               }
/*  459 */               else if (i2 == 9) {
/*      */                 
/*  461 */                 i5 += 2;
/*      */                 
/*  463 */                 i1 -= 2;
/*      */               }
/*  465 */               else if (i2 == 114 || i2 == 113 || i2 == 112) {
/*      */ 
/*      */                 
/*  468 */                 this.meg.marshalUB4(i1);
/*      */               } 
/*      */ 
/*      */               
/*  472 */               if (i2 == 109 || i2 == 111) {
/*      */                 
/*  474 */                 if (paramArrayOfbyte == null) {
/*      */ 
/*      */                   
/*  477 */                   SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), -1, "INTERNAL ERROR: oracle.jdbc.driver.T4CTTIrxd.marshal: parameterDatum is null");
/*      */                   
/*  479 */                   sQLException.fillInStackTrace();
/*  480 */                   throw sQLException;
/*      */                 } 
/*      */ 
/*      */                 
/*  484 */                 byte[] arrayOfByte = paramArrayOfbyte[b];
/*      */                 
/*  486 */                 i1 = (arrayOfByte == null) ? 0 : arrayOfByte.length;
/*      */                 
/*  488 */                 if (i2 == 109) {
/*      */                   
/*  490 */                   this.meg.marshalDALC(NO_BYTES);
/*  491 */                   this.meg.marshalDALC(NO_BYTES);
/*  492 */                   this.meg.marshalDALC(NO_BYTES);
/*  493 */                   this.meg.marshalUB2(0);
/*      */                   
/*  495 */                   this.meg.marshalUB4(i1);
/*  496 */                   this.meg.marshalUB2(1);
/*      */                 } 
/*      */                 
/*  499 */                 if (i1 > 0) {
/*  500 */                   this.meg.marshalCLR(arrayOfByte, 0, i1);
/*      */                 }
/*  502 */               } else if (i2 == 104) {
/*      */ 
/*      */ 
/*      */                 
/*  506 */                 i5 += 2;
/*      */                 
/*  508 */                 long[] arrayOfLong = T4CRowidAccessor.stringToRowid(paramArrayOfbyte1, i5, 18);
/*      */                 
/*  510 */                 byte b3 = 14;
/*  511 */                 long l1 = arrayOfLong[0];
/*  512 */                 int i6 = (int)arrayOfLong[1];
/*  513 */                 boolean bool1 = false;
/*  514 */                 long l2 = arrayOfLong[2];
/*  515 */                 int i7 = (int)arrayOfLong[3];
/*      */ 
/*      */                 
/*  518 */                 if (l1 == 0L && i6 == 0 && l2 == 0L && i7 == 0)
/*      */                 {
/*      */ 
/*      */ 
/*      */ 
/*      */                   
/*  524 */                   this.meg.marshalUB1((short)0);
/*      */                 }
/*      */                 else
/*      */                 {
/*  528 */                   this.meg.marshalUB1(b3);
/*  529 */                   this.meg.marshalUB4(l1);
/*  530 */                   this.meg.marshalUB2(i6);
/*  531 */                   this.meg.marshalUB1(bool1);
/*  532 */                   this.meg.marshalUB4(l2);
/*  533 */                   this.meg.marshalUB2(i7);
/*      */                 }
/*      */               
/*  536 */               } else if (i2 == 208) {
/*      */ 
/*      */ 
/*      */                 
/*  540 */                 i5 += 2;
/*  541 */                 i1 -= 2;
/*  542 */                 this.meg.marshalUB4(i1);
/*  543 */                 this.meg.marshalCLR(paramArrayOfbyte1, i5, i1);
/*      */ 
/*      */               
/*      */               }
/*  547 */               else if (i1 < 1) {
/*  548 */                 this.meg.marshalUB1((short)0);
/*      */               } else {
/*  550 */                 this.meg.marshalCLR(paramArrayOfbyte1, i5, i1);
/*      */ 
/*      */               
/*      */               }
/*      */ 
/*      */             
/*      */             }
/*      */             else {
/*      */ 
/*      */               
/*  560 */               int i7 = paramArrayOfshort1[m + 9] & 0xFFFF;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */               
/*  567 */               int i5 = paramArrayOfshort1[m + 2] & 0xFFFF;
/*      */ 
/*      */               
/*  570 */               int i6 = ((paramArrayOfshort1[m + 3] & 0xFFFF) << 16) + (paramArrayOfshort1[m + 4] & 0xFFFF) + i5 * paramInt2 + 1;
/*      */ 
/*      */ 
/*      */ 
/*      */               
/*  575 */               if (i2 == 996) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */                 
/*  584 */                 char c = paramArrayOfchar1[i6 - 1];
/*      */                 
/*  586 */                 if (this.bufferCHAR == null || this.bufferCHAR.length < c) {
/*  587 */                   this.bufferCHAR = new byte[c];
/*      */                 }
/*  589 */                 for (byte b3 = 0; b3 < c; b3++) {
/*      */                   
/*  591 */                   this.bufferCHAR[b3] = (byte)((paramArrayOfchar1[i6 + b3 / 2] & 0xFF00) >> 8 & 0xFF);
/*      */ 
/*      */ 
/*      */                   
/*  595 */                   if (b3 < c - 1) {
/*      */                     
/*  597 */                     this.bufferCHAR[b3 + 1] = (byte)(paramArrayOfchar1[i6 + b3 / 2] & 0xFF & 0xFF);
/*      */ 
/*      */                     
/*  600 */                     b3++;
/*      */                   } 
/*      */                 } 
/*      */                 
/*  604 */                 this.meg.marshalCLR(this.bufferCHAR, c);
/*      */                 
/*  606 */                 if (this.bufferCHAR.length > 4000) {
/*  607 */                   this.bufferCHAR = null;
/*      */                 }
/*      */               } else {
/*      */                 int i8;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */                 
/*  618 */                 if (i2 == 96) {
/*      */ 
/*      */ 
/*      */                   
/*  622 */                   i8 = i1 / 2;
/*  623 */                   i6--;
/*      */                 }
/*      */                 else {
/*      */                   
/*  627 */                   i8 = (i1 - 2) / 2;
/*      */                 } 
/*      */ 
/*      */                 
/*  631 */                 int i9 = 0;
/*      */ 
/*      */ 
/*      */ 
/*      */                 
/*  636 */                 if (i7 == 2) {
/*      */                   
/*  638 */                   i9 = paramDBConversion.javaCharsToNCHARBytes(paramArrayOfchar1, i6, paramArrayOfbyte2, 0, i8);
/*      */                 
/*      */                 }
/*      */                 else {
/*      */                   
/*  643 */                   i9 = paramDBConversion.javaCharsToCHARBytes(paramArrayOfchar1, i6, paramArrayOfbyte2, 0, i8);
/*      */                 } 
/*      */ 
/*      */ 
/*      */ 
/*      */                 
/*  649 */                 this.meg.marshalCLR(paramArrayOfbyte2, i9);
/*      */               } 
/*      */             } 
/*      */           } 
/*      */ 
/*      */           
/*      */           continue;
/*      */         } 
/*      */ 
/*      */         
/*  659 */         k = j;
/*      */       } 
/*      */       
/*  662 */       if (j > 0)
/*      */       {
/*  664 */         for (byte b = 0; b < k; b++) {
/*      */           
/*  666 */           int i6 = arrayOfInt[b];
/*      */           
/*  668 */           int m = paramInt1 + 5 + 10 * i6;
/*      */ 
/*      */ 
/*      */           
/*  672 */           int i4 = paramArrayOfshort1[m + 0] & 0xFFFF;
/*      */ 
/*      */ 
/*      */           
/*  676 */           int n = ((paramArrayOfshort1[m + 7] & 0xFFFF) << 16) + (paramArrayOfshort1[m + 8] & 0xFFFF) + paramInt2;
/*      */ 
/*      */ 
/*      */           
/*  680 */           int i5 = ((paramArrayOfshort1[m + 5] & 0xFFFF) << 16) + (paramArrayOfshort1[m + 6] & 0xFFFF) + paramInt2;
/*      */ 
/*      */ 
/*      */           
/*  684 */           short s = paramArrayOfshort1[i5];
/*  685 */           int i1 = paramArrayOfshort1[n] & 0xFFFF;
/*      */           
/*  687 */           int i2 = paramArrayOfshort1[m + 2] & 0xFFFF;
/*      */ 
/*      */           
/*  690 */           int i3 = ((paramArrayOfshort1[m + 3] & 0xFFFF) << 16) + (paramArrayOfshort1[m + 4] & 0xFFFF) + i2 * paramInt2 + 1;
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  695 */           if (s == -1) {
/*      */             
/*  697 */             this.meg.marshalUB1((short)0);
/*      */ 
/*      */           
/*      */           }
/*  701 */           else if (i4 == 996) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*  710 */             char c = paramArrayOfchar1[i3 - 1];
/*      */             
/*  712 */             if (this.bufferCHAR == null || this.bufferCHAR.length < c) {
/*  713 */               this.bufferCHAR = new byte[c];
/*      */             }
/*  715 */             for (byte b3 = 0; b3 < c; b3++) {
/*      */               
/*  717 */               this.bufferCHAR[b3] = (byte)((paramArrayOfchar1[i3 + b3 / 2] & 0xFF00) >> 8 & 0xFF);
/*      */ 
/*      */ 
/*      */               
/*  721 */               if (b3 < c - 1) {
/*      */                 
/*  723 */                 this.bufferCHAR[b3 + 1] = (byte)(paramArrayOfchar1[i3 + b3 / 2] & 0xFF & 0xFF);
/*      */                 
/*  725 */                 b3++;
/*      */               } 
/*      */             } 
/*      */             
/*  729 */             this.meg.marshalCLR(this.bufferCHAR, c);
/*      */             
/*  731 */             if (this.bufferCHAR.length > 4000) {
/*  732 */               this.bufferCHAR = null;
/*      */             }
/*  734 */           } else if (i4 != 8 && i4 != 24) {
/*      */             int i7;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*  741 */             if (i4 == 96) {
/*      */ 
/*      */ 
/*      */               
/*  745 */               i7 = i1 / 2;
/*  746 */               i3--;
/*      */             }
/*      */             else {
/*      */               
/*  750 */               i7 = (i1 - 2) / 2;
/*      */             } 
/*      */             
/*  753 */             int i8 = paramArrayOfshort1[m + 9] & 0xFFFF;
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*  758 */             int i9 = 0;
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*  763 */             if (i8 == 2) {
/*      */               
/*  765 */               i9 = paramDBConversion.javaCharsToNCHARBytes(paramArrayOfchar1, i3, paramArrayOfbyte2, 0, i7);
/*      */             
/*      */             }
/*      */             else {
/*      */               
/*  770 */               i9 = paramDBConversion.javaCharsToCHARBytes(paramArrayOfchar1, i3, paramArrayOfbyte2, 0, i7);
/*      */             } 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*  776 */             this.meg.marshalCLR(paramArrayOfbyte2, i9);
/*      */           
/*      */           }
/*      */           else {
/*      */             
/*  781 */             int i7 = i6;
/*      */ 
/*      */             
/*  784 */             if (paramArrayOfInputStream != null) {
/*      */               
/*  786 */               InputStream inputStream = paramArrayOfInputStream[i7];
/*      */               
/*  788 */               if (inputStream != null) {
/*      */                 
/*      */                 try {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */                   
/*  796 */                   this.meg.marshalCLR(inputStream, 0);
/*  797 */                 } catch (IOException iOException) {
/*  798 */                   if (vector == null) {
/*  799 */                     vector = new Vector();
/*      */                   }
/*  801 */                   vector.add(iOException);
/*      */                 } 
/*      */               }
/*      */             } 
/*      */           } 
/*      */         } 
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  821 */       paramArrayOfint3[0] = j;
/*  822 */       paramArrayOfint[0] = arrayOfInt;
/*      */     }
/*  824 */     catch (SQLException sQLException) {
/*      */       
/*  826 */       IOException iOException = new IOException();
/*  827 */       iOException.initCause(sQLException);
/*  828 */       throw iOException;
/*      */     } 
/*      */     
/*  831 */     return vector;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   boolean unmarshal(Accessor[] paramArrayOfAccessor, int paramInt) throws SQLException, IOException {
/*  842 */     return unmarshal(paramArrayOfAccessor, 0, paramInt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void copyRowsAsNeeded(Accessor[] paramArrayOfAccessor, int paramInt) throws SQLException, IOException {
/*  878 */     int[] arrayOfInt = new int[this.nbOfColumns];
/*  879 */     byte b1 = 0;
/*  880 */     int i = Math.min(paramInt, paramArrayOfAccessor.length);
/*  881 */     for (byte b2 = 0; b2 < i; b2++) {
/*  882 */       Accessor accessor = paramArrayOfAccessor[b2];
/*  883 */       if (!accessor.isUseLess && !this.bvcColSent.get(accessor.physicalColumnIndex)) {
/*  884 */         arrayOfInt[b1++] = b2;
/*      */       }
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  891 */     long l = -1L;
/*  892 */     while (b1 > 0) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  897 */       int j = 0;
/*  898 */       Accessor accessor = paramArrayOfAccessor[arrayOfInt[j]];
/*  899 */       long l1 = accessor.getOffset(accessor.getPreviousRowProcessed());
/*      */       
/*      */       int k;
/*  902 */       for (k = 1; k < b1; k++) {
/*  903 */         int m = arrayOfInt[k];
/*  904 */         accessor = paramArrayOfAccessor[arrayOfInt[k]];
/*  905 */         long l2 = accessor.getOffset(accessor.getPreviousRowProcessed());
/*  906 */         if (l2 < l1) {
/*  907 */           l1 = l2;
/*  908 */           j = k;
/*  909 */           if (l2 == -1L) {
/*      */             break;
/*      */           }
/*      */         } 
/*      */       } 
/*  914 */       k = arrayOfInt[j];
/*  915 */       accessor = paramArrayOfAccessor[k];
/*      */       
/*  917 */       assert accessor.isNull(accessor.getPreviousRowProcessed()) || l < l1 : "lastOffset: " + l + "\tleastOffset: " + l1 + "\tindexOfLeastOffet: " + j;
/*      */ 
/*      */       
/*  920 */       l = l1;
/*      */       try {
/*  922 */         accessor.copyRow();
/*      */       }
/*  924 */       catch (AssertionError assertionError1) {
/*  925 */         String str = dumpIndicesOfColumnsToBeCopied(b1, arrayOfInt, paramArrayOfAccessor);
/*      */ 
/*      */         
/*  928 */         AssertionError assertionError2 = new AssertionError(str + "\nlastOffset: " + l + "\tleastOffset: " + l1 + "\tindexOfLeastOffet: " + j);
/*      */ 
/*      */ 
/*      */         
/*  932 */         assertionError2.initCause(assertionError1);
/*  933 */         throw assertionError2;
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/*  938 */       arrayOfInt[j] = arrayOfInt[--b1];
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   boolean unmarshal(Accessor[] paramArrayOfAccessor, int paramInt1, int paramInt2) throws SQLException, IOException {
/*      */     int i;
/*  953 */     for (i = paramInt1; i < paramInt2 && i < paramArrayOfAccessor.length; i++) {
/*      */       
/*  955 */       if (paramArrayOfAccessor[i] != null)
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  972 */         if ((paramArrayOfAccessor[i]).physicalColumnIndex < 0) {
/*      */ 
/*      */ 
/*      */           
/*  976 */           byte b1 = 0;
/*      */           
/*  978 */           for (byte b2 = 0; b2 < paramInt2 && b2 < paramArrayOfAccessor.length; b2++) {
/*      */             
/*  980 */             if (paramArrayOfAccessor[b2] != null) {
/*      */               
/*  982 */               (paramArrayOfAccessor[b2]).physicalColumnIndex = b1;
/*      */               
/*  984 */               if (!(paramArrayOfAccessor[b2]).isUseLess)
/*  985 */                 b1++; 
/*      */             } 
/*      */           } 
/*      */         } 
/*      */       }
/*      */     } 
/*  991 */     if (this.bvcFound && paramInt1 == 0)
/*      */     {
/*      */       
/*  994 */       copyRowsAsNeeded(paramArrayOfAccessor, paramInt2);
/*      */     }
/*  996 */     for (i = paramInt1; i < paramInt2 && i < paramArrayOfAccessor.length; i++) {
/*      */       
/*  998 */       if (paramArrayOfAccessor[i] != null)
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1008 */         if (!this.bvcFound || (paramArrayOfAccessor[i]).isUseLess || this.bvcColSent.get((paramArrayOfAccessor[i]).physicalColumnIndex)) {
/*      */ 
/*      */ 
/*      */           
/* 1012 */           if ((paramArrayOfAccessor[i]).statement.statementType == 2 || (paramArrayOfAccessor[i]).statement.sqlKind.isPlsqlOrCall())
/*      */           {
/*      */ 
/*      */             
/* 1016 */             paramArrayOfAccessor[i].setCapacity(1);
/*      */           }
/*      */           
/* 1019 */           if (paramArrayOfAccessor[i].unmarshalOneRow())
/* 1020 */             return true; 
/*      */         } 
/*      */       }
/*      */     } 
/* 1024 */     this.bvcFound = false;
/* 1025 */     return false;
/*      */   }
/*      */ 
/*      */   
/* 1029 */   static int call_count = 0;
/*      */ 
/*      */ 
/*      */   
/*      */   String dumpIndicesOfColumnsToBeCopied(int paramInt, int[] paramArrayOfint, Accessor[] paramArrayOfAccessor) throws SQLException {
/* 1034 */     StringWriter stringWriter = new StringWriter();
/* 1035 */     PrintWriter printWriter = new PrintWriter(stringWriter);
/* 1036 */     printWriter.println("dump indicesOfColumnsToBeCopied call_count: " + call_count++ + " numColumnsToBeCopied: " + paramInt);
/* 1037 */     for (byte b = 0; b < paramInt; b++) {
/*      */       
/* 1039 */       long l = paramArrayOfAccessor[paramArrayOfint[b]].getOffset(0);
/* 1040 */       printWriter.println("copy order: " + b + " index: " + paramArrayOfint[b] + " offset: " + l);
/*      */     } 
/* 1042 */     printWriter.println();
/* 1043 */     return stringWriter.toString();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   boolean unmarshal(Accessor[] paramArrayOfAccessor, int paramInt1, int paramInt2, int paramInt3) throws SQLException, IOException {
/* 1050 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected OracleConnection getConnectionDuringExceptionHandling() {
/* 1065 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/* 1070 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*      */   public static final String BUILD_DATE = "Thu_Apr_04_15:09:24_PDT_2013";
/*      */   public static final boolean TRACE = false;
/*      */ }


/* Location:              C:\Users\olatu\OneDrive\Documents\Calypso\syncbase\sync_base.jar!\BOOT-INF\lib\ojdbc-7.jar!\oracle\jdbc\driver\T4CTTIrxd.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */