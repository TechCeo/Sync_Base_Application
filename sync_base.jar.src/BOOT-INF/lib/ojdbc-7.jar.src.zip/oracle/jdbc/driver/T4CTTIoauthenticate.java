/*      */ package oracle.jdbc.driver;
/*      */ 
/*      */ import java.io.IOException;
/*      */ import java.io.UnsupportedEncodingException;
/*      */ import java.net.InetAddress;
/*      */ import java.security.NoSuchAlgorithmException;
/*      */ import java.security.spec.InvalidKeySpecException;
/*      */ import java.sql.SQLException;
/*      */ import java.util.Locale;
/*      */ import java.util.Properties;
/*      */ import java.util.TimeZone;
/*      */ import oracle.jdbc.internal.OracleConnection;
/*      */ import oracle.jdbc.util.RepConversion;
/*      */ import oracle.net.ano.AuthenticationService;
/*      */ import oracle.security.o3logon.O3LoginClientHelper;
/*      */ import oracle.security.o5logon.O5Logon;
/*      */ import oracle.sql.ZONEIDMAP;
/*      */ import oracle.sql.converter.CharacterSetMetaData;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ final class T4CTTIoauthenticate
/*      */   extends T4CTTIfun
/*      */ {
/*      */   byte[] terminal;
/*      */   byte[] enableTempLobRefCnt;
/*      */   byte[] machine;
/*      */   byte[] sysUserName;
/*      */   byte[] processID;
/*      */   byte[] programName;
/*      */   byte[] encryptedSK;
/*      */   byte[] internalName;
/*      */   byte[] externalName;
/*      */   byte[] alterSession;
/*      */   byte[] aclValue;
/*      */   byte[] clientname;
/*   94 */   byte[] editionName = null;
/*      */   
/*      */   byte[] driverName;
/*      */   
/*      */   String ressourceManagerId;
/*      */   
/*      */   boolean bUseO5Logon;
/*      */   
/*      */   int verifierType;
/*      */   
/*      */   static final int ZTVT_ORCL_7 = 2361;
/*      */   
/*      */   static final int ZTVT_SSH1 = 6949;
/*      */   
/*      */   static final int ZTVT_NTV = 7809;
/*      */   
/*      */   static final int ZTVT_SMD5 = 59694;
/*      */   
/*      */   static final int ZTVT_MD5 = 40674;
/*      */   
/*      */   static final int ZTVT_SH1 = 45394;
/*      */   
/*      */   static final int ZTVT_SHA512 = 18453;
/*      */   
/*      */   byte[] salt;
/*      */   
/*      */   byte[] encryptedKB;
/*      */   
/*      */   boolean isSessionTZ = true;
/*      */   
/*      */   static final int SERVER_VERSION_81 = 8100;
/*      */   
/*      */   static final int KPZ_LOGON = 1;
/*      */   
/*      */   static final int KPZ_CPW = 2;
/*      */   
/*      */   static final int KPZ_SRVAUTH = 4;
/*      */   
/*      */   static final int KPZ_ENCRYPTED_PASSWD = 256;
/*      */   
/*      */   static final int KPZ_LOGON_MIGRATE = 16;
/*      */   
/*      */   static final int KPZ_LOGON_SYSDBA = 32;
/*      */   
/*      */   static final int KPZ_LOGON_SYSOPER = 64;
/*      */   
/*      */   static final int KPZ_LOGON_PRELIMAUTH = 128;
/*      */   
/*      */   static final int KPZ_PASSWD_ENCRYPTED = 256;
/*      */   
/*      */   static final int KPZ_LOGON_DBCONC = 512;
/*      */   
/*      */   static final int KPZ_PROXY_AUTH = 1024;
/*      */   
/*      */   static final int KPZ_SESSION_CACHE = 2048;
/*      */   
/*      */   static final int KPZ_PASSWD_IS_VFR = 4096;
/*      */   
/*      */   static final int KPZ_LOGON_SYSASM = 4194304;
/*      */   
/*      */   static final int KPZ_SESSION_QCACHE = 8388608;
/*      */   
/*      */   static final int KPZ_LOGON_SYSBKP = 16777216;
/*      */   
/*      */   static final int KPZ_LOGON_SYSDGD = 33554432;
/*      */   
/*      */   static final int KPZ_LOGON_SYSKMT = 67108864;
/*      */   
/*      */   static final String AUTH_TERMINAL = "AUTH_TERMINAL";
/*      */   
/*      */   static final String AUTH_PROGRAM_NM = "AUTH_PROGRAM_NM";
/*      */   
/*      */   static final String AUTH_MACHINE = "AUTH_MACHINE";
/*      */   
/*      */   static final String AUTH_PID = "AUTH_PID";
/*      */   
/*      */   static final String AUTH_SID = "AUTH_SID";
/*      */   
/*      */   static final String AUTH_SESSKEY = "AUTH_SESSKEY";
/*      */   
/*      */   static final String AUTH_VFR_DATA = "AUTH_VFR_DATA";
/*      */   
/*      */   static final String AUTH_PASSWORD = "AUTH_PASSWORD";
/*      */   
/*      */   static final String AUTH_INTERNALNAME = "AUTH_INTERNALNAME_";
/*      */   
/*      */   static final String AUTH_EXTERNALNAME = "AUTH_EXTERNALNAME_";
/*      */   static final String AUTH_ACL = "AUTH_ACL";
/*      */   static final String AUTH_ALTER_SESSION = "AUTH_ALTER_SESSION";
/*      */   static final String AUTH_INITIAL_CLIENT_ROLE = "INITIAL_CLIENT_ROLE";
/*      */   static final String AUTH_VERSION_SQL = "AUTH_VERSION_SQL";
/*      */   static final String AUTH_VERSION_NO = "AUTH_VERSION_NO";
/*      */   static final String AUTH_XACTION_TRAITS = "AUTH_XACTION_TRAITS";
/*      */   static final String AUTH_VERSION_STATUS = "AUTH_VERSION_STATUS";
/*      */   static final String AUTH_SERIAL_NUM = "AUTH_SERIAL_NUM";
/*      */   static final String AUTH_SESSION_ID = "AUTH_SESSION_ID";
/*      */   static final String AUTH_CLIENT_CERTIFICATE = "AUTH_CLIENT_CERTIFICATE";
/*      */   static final String AUTH_PROXY_CLIENT_NAME = "PROXY_CLIENT_NAME";
/*      */   static final String AUTH_CLIENT_DN = "AUTH_CLIENT_DISTINGUISHED_NAME";
/*      */   static final String AUTH_INSTANCENAME = "AUTH_INSTANCENAME";
/*      */   static final String AUTH_DBNAME = "AUTH_DBNAME";
/*      */   static final String AUTH_INSTANCE_NO = "AUTH_INSTANCE_NO";
/*      */   static final String AUTH_DB_ID = "AUTH_DB_ID";
/*      */   static final String AUTH_SC_SERVER_HOST = "AUTH_SC_SERVER_HOST";
/*      */   static final String AUTH_SC_INSTANCE_NAME = "AUTH_SC_INSTANCE_NAME";
/*      */   static final String AUTH_SC_INSTANCE_ID = "AUTH_SC_INSTANCE_ID";
/*      */   static final String AUTH_SC_INSTANCE_START_TIME = "AUTH_SC_INSTANCE_START_TIME";
/*      */   static final String AUTH_SC_DBUNIQUE_NAME = "AUTH_SC_DBUNIQUE_NAME";
/*      */   static final String AUTH_SC_SERVICE_NAME = "AUTH_SC_SERVICE_NAME";
/*      */   static final String AUTH_SC_SVC_FLAGS = "AUTH_SC_SVC_FLAGS";
/*      */   static final String AUTH_SC_DB_DOMAIN = "AUTH_SC_DB_DOMAIN";
/*      */   static final String AUTH_SESSION_CLIENT_CSET = "SESSION_CLIENT_CHARSET";
/*      */   static final String AUTH_SESSION_CLIENT_LTYPE = "SESSION_CLIENT_LIB_TYPE";
/*      */   static final String AUTH_SESSION_CLIENT_DRVNM = "SESSION_CLIENT_DRIVER_NAME";
/*      */   static final String AUTH_SESSION_CLIENT_VSN = "SESSION_CLIENT_VERSION";
/*      */   static final String AUTH_NLS_LXLAN = "AUTH_NLS_LXLAN";
/*      */   static final String AUTH_NLS_LXCTERRITORY = "AUTH_NLS_LXCTERRITORY";
/*      */   static final String AUTH_NLS_LXCCURRENCY = "AUTH_NLS_LXCCURRENCY";
/*      */   static final String AUTH_NLS_LXCISOCURR = "AUTH_NLS_LXCISOCURR";
/*      */   static final String AUTH_NLS_LXCNUMERICS = "AUTH_NLS_LXCNUMERICS";
/*      */   static final String AUTH_NLS_LXCDATEFM = "AUTH_NLS_LXCDATEFM";
/*      */   static final String AUTH_NLS_LXCDATELANG = "AUTH_NLS_LXCDATELANG";
/*      */   static final String AUTH_NLS_LXCSORT = "AUTH_NLS_LXCSORT";
/*      */   static final String AUTH_NLS_LXCCALENDAR = "AUTH_NLS_LXCCALENDAR";
/*      */   static final String AUTH_NLS_LXCUNIONCUR = "AUTH_NLS_LXCUNIONCUR";
/*      */   static final String AUTH_NLS_LXCTIMEFM = "AUTH_NLS_LXCTIMEFM";
/*      */   static final String AUTH_NLS_LXCSTMPFM = "AUTH_NLS_LXCSTMPFM";
/*      */   static final String AUTH_NLS_LXCTTZNFM = "AUTH_NLS_LXCTTZNFM";
/*      */   static final String AUTH_NLS_LXCSTZNFM = "AUTH_NLS_LXCSTZNFM";
/*      */   static final String SESSION_CLIENT_LOBATTR = "SESSION_CLIENT_LOBATTR";
/*      */   static final String AUTH_KPPL_CONN_CLASS = "AUTH_KPPL_CONN_CLASS";
/*      */   static final String AUTH_KPPL_PURITY = "AUTH_KPPL_PURITY";
/*      */   static final String AUTH_KPPL_TAG = "AUTH_KPPL_TAG";
/*      */   static final String AUTH_KPPL_WAIT = "AUTH_KPPL_WAIT";
/*      */   static final String KPPL_PURITY_DEFAULT = "0";
/*      */   static final String KPPL_PURITY_NEW = "1";
/*      */   static final String KPPL_PURITY_SELF = "2";
/*      */   static final String AUTH_CONNECT_STRING = "AUTH_CONNECT_STRING";
/*      */   static final String DRIVER_NAME_DEFAULT = "jdbcthin";
/*      */   static final int KPU_LIB_UNKN = 0;
/*      */   static final int KPU_LIB_DEF = 1;
/*      */   static final int KPU_LIB_EI = 2;
/*      */   static final int KPU_LIB_XE = 3;
/*      */   static final int KPU_LIB_ICUS = 4;
/*      */   static final int KPU_LIB_OCI = 5;
/*      */   static final int KPU_LIB_THIN = 10;
/*      */   static final String AUTH_ORA_EDITION = "AUTH_ORA_EDITION";
/*      */   static final String AUTH_COPYRIGHT = "AUTH_COPYRIGHT";
/*      */   static final String COPYRIGHT_STR = "\"Oracle\nEverybody follows\nSpeedy bits exchange\nStars await to glow\"\nThe preceding key is copyrighted by Oracle Corporation.\nDuplication of this key is not allowed without permission\nfrom Oracle Corporation. Copyright 2003 Oracle Corporation.";
/*      */   static final String SESSION_TIME_ZONE = "SESSION_TIME_ZONE";
/*      */   static final String SESSION_NLS_LXCCHARSET = "SESSION_NLS_LXCCHARSET";
/*      */   static final String SESSION_NLS_LXCNLSLENSEM = "SESSION_NLS_LXCNLSLENSEM";
/*      */   static final String SESSION_NLS_LXCNCHAREXCP = "SESSION_NLS_LXCNCHAREXCP";
/*      */   static final String SESSION_NLS_LXCNCHARIMP = "SESSION_NLS_LXCNCHARIMP";
/*      */   public static final int AUTH_FLAG_O5LOGON = 0;
/*      */   public static final int AUTH_FLAG_NONO5LOGON = 1;
/*  250 */   String sessionTimeZone = null;
/*  251 */   byte[] serverCompileTimeCapabilities = null;
/*      */   private T4CKvaldfList keyValList;
/*      */   private byte[] user; private long logonMode; private byte[][] outKeys; private byte[][] outValues; private int[] outFlags; private int outNbPairs; O5Logon o5logonHelper; void marshal() throws IOException { if (this.user != null && this.user.length > 0) { this.meg.marshalPTR(); this.meg.marshalSB4(this.user.length); } else { this.meg.marshalNULLPTR(); this.meg.marshalSB4(0); }  this.meg.marshalUB4(this.logonMode); this.meg.marshalPTR(); this.meg.marshalUB4(this.keyValList.size()); this.meg.marshalPTR(); this.meg.marshalPTR(); if (this.user != null && this.user.length > 0) this.meg.marshalCHR(this.user);  this.meg.marshalKEYVAL(this.keyValList.getKeys(), this.keyValList.getValues(), this.keyValList.getFlags(), this.keyValList.size()); } private void doOAUTH(byte[] paramArrayOfbyte1, byte[] paramArrayOfbyte2, long paramLong, String paramString, boolean paramBoolean, byte[] paramArrayOfbyte3, byte[] paramArrayOfbyte4, byte[][] paramArrayOfbyte, int paramInt1, int paramInt2) throws IOException, SQLException { setFunCode((short)115); this.user = paramArrayOfbyte1; this.logonMode = paramLong | 0x1L; if (paramBoolean) this.logonMode |= 0x400L;  if (paramArrayOfbyte1 != null && paramArrayOfbyte1.length != 0 && paramArrayOfbyte2 != null && paramString != "RADIUS") this.logonMode |= 0x100L;  this.keyValList = new T4CKvaldfList(this.meg.conv); if (paramArrayOfbyte2 != null) this.keyValList.add("AUTH_PASSWORD", paramArrayOfbyte2);  if (paramArrayOfbyte != null) for (byte b = 0; b < paramArrayOfbyte.length; b++) this.keyValList.add("INITIAL_CLIENT_ROLE", paramArrayOfbyte[b]);   if (paramArrayOfbyte3 != null) this.keyValList.add("AUTH_CLIENT_DISTINGUISHED_NAME", paramArrayOfbyte3);  if (paramArrayOfbyte4 != null) this.keyValList.add("AUTH_CLIENT_CERTIFICATE", paramArrayOfbyte4);  this.keyValList.add("AUTH_TERMINAL", this.terminal); if (this.bUseO5Logon && this.encryptedKB != null) this.keyValList.add("AUTH_SESSKEY", this.encryptedKB, (byte)1);  if (this.programName != null) this.keyValList.add("AUTH_PROGRAM_NM", this.programName);  if (this.clientname != null) this.keyValList.add("PROXY_CLIENT_NAME", this.clientname);  this.keyValList.add("AUTH_MACHINE", this.machine); this.keyValList.add("AUTH_PID", this.processID); if (!this.ressourceManagerId.equals("0000")) { byte[] arrayOfByte = this.meg.conv.StringToCharBytes("AUTH_INTERNALNAME_"); arrayOfByte[arrayOfByte.length - 1] = 0; this.keyValList.add(arrayOfByte, this.internalName); arrayOfByte = this.meg.conv.StringToCharBytes("AUTH_EXTERNALNAME_"); arrayOfByte[arrayOfByte.length - 1] = 0; this.keyValList.add(arrayOfByte, this.externalName); }  this.keyValList.add("AUTH_ACL", this.aclValue); this.keyValList.add("AUTH_ALTER_SESSION", this.alterSession, (byte)1); if (this.editionName != null)
/*      */       this.keyValList.add("AUTH_ORA_EDITION", this.editionName);  this.keyValList.add("SESSION_CLIENT_LOBATTR", this.enableTempLobRefCnt); this.keyValList.add("SESSION_CLIENT_DRIVER_NAME", this.driverName); this.keyValList.add("SESSION_CLIENT_VERSION", this.meg.conv.StringToCharBytes(Integer.toString(versionStringToInt(this.connection.getMetaData().getDriverVersion()), 10))); if (paramInt1 != -1)
/*      */       this.keyValList.add("AUTH_SESSION_ID", this.meg.conv.StringToCharBytes(Integer.toString(paramInt1)));  if (paramInt2 != -1)
/*      */       this.keyValList.add("AUTH_SERIAL_NUM", this.meg.conv.StringToCharBytes(Integer.toString(paramInt2)));  if (this.connection.drcpEnabled) { this.keyValList.add("AUTH_KPPL_CONN_CLASS", this.meg.conv.StringToCharBytes(this.connection.drcpConnectionClass)); this.keyValList.add("AUTH_KPPL_PURITY", this.meg.conv.StringToCharBytes("2")); if (this.connection.drcpTagName != null)
/*  257 */         this.keyValList.add("AUTH_KPPL_TAG", this.meg.conv.StringToCharBytes(this.connection.drcpTagName));  }  this.keyValList.add("AUTH_CONNECT_STRING", this.meg.conv.StringToCharBytes(this.connection.net.getConnectionString())); this.keyValList.add("AUTH_COPYRIGHT", this.meg.conv.StringToCharBytes("\"Oracle\nEverybody follows\nSpeedy bits exchange\nStars await to glow\"\nThe preceding key is copyrighted by Oracle Corporation.\nDuplication of this key is not allowed without permission\nfrom Oracle Corporation. Copyright 2003 Oracle Corporation.")); this.outNbPairs = 0; this.outKeys = (byte[][])null; this.outValues = (byte[][])null; this.outFlags = new int[0]; doRPC(); } T4CTTIoauthenticate(T4CConnection paramT4CConnection, String paramString, byte[] paramArrayOfbyte) throws SQLException { super(paramT4CConnection, (byte)3);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  271 */     this.keyValList = null;
/*  272 */     this.user = null;
/*      */ 
/*      */ 
/*      */     
/*  276 */     this.outKeys = (byte[][])null;
/*  277 */     this.outValues = (byte[][])null;
/*  278 */     this.outFlags = new int[0];
/*  279 */     this.outNbPairs = 0;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  614 */     this.o5logonHelper = new O5Logon(); this.ressourceManagerId = paramString; this.serverCompileTimeCapabilities = paramArrayOfbyte; setSessionFields(paramT4CConnection); this.isSessionTZ = true; this.bUseO5Logon = false; }
/*      */   void doOSESSKEY(String paramString, long paramLong) throws IOException, SQLException { setFunCode((short)118); this.user = this.meg.conv.StringToCharBytes(paramString); this.logonMode = paramLong | 0x1L; this.keyValList = new T4CKvaldfList(this.meg.conv); this.keyValList.add("AUTH_TERMINAL", this.terminal); if (this.programName != null)
/*      */       this.keyValList.add("AUTH_PROGRAM_NM", this.programName);  this.keyValList.add("AUTH_MACHINE", this.machine); this.keyValList.add("AUTH_PID", this.processID); this.keyValList.add("AUTH_SID", this.sysUserName); this.outNbPairs = 0; this.outKeys = (byte[][])null; this.outValues = (byte[][])null;
/*      */     this.outFlags = new int[0];
/*  618 */     doRPC(); } void doOAUTH(String paramString1, String paramString2, long paramLong) throws IOException, SQLException { byte[] arrayOfByte1 = null;
/*  619 */     if (paramString1 != null && paramString1.length() > 0) {
/*  620 */       arrayOfByte1 = this.meg.conv.StringToCharBytes(paramString1);
/*      */     }
/*  622 */     byte[] arrayOfByte2 = null;
/*  623 */     byte[] arrayOfByte3 = null;
/*  624 */     byte[] arrayOfByte4 = null;
/*      */     
/*  626 */     String str = this.connection.net.getAuthenticationAdaptorName();
/*      */ 
/*      */ 
/*      */     
/*  630 */     if (paramString1 != null && paramString1.length() != 0) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  635 */       if (str != "RADIUS" && this.encryptedSK.length > 16 && !this.bUseO5Logon) {
/*      */ 
/*      */ 
/*      */         
/*  639 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 413);
/*  640 */         sQLException.fillInStackTrace();
/*  641 */         throw sQLException;
/*      */       } 
/*      */       
/*  644 */       if (this.bUseO5Logon && (this.encryptedSK == null || (this.encryptedSK.length != 64 && this.encryptedSK.length != 96))) {
/*      */ 
/*      */         
/*  647 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 413);
/*  648 */         sQLException.fillInStackTrace();
/*  649 */         throw sQLException;
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  659 */       String str1 = paramString1.trim();
/*  660 */       String str2 = null;
/*  661 */       if (paramString2 != null)
/*      */       {
/*      */         
/*  664 */         str2 = paramString2.trim();
/*      */       }
/*  666 */       paramString2 = null;
/*      */       
/*  668 */       String str3 = str1;
/*  669 */       String str4 = str2;
/*      */       
/*  671 */       if (str1.startsWith("\"") || str1.endsWith("\"")) {
/*  672 */         str3 = removeQuotes(str1);
/*      */       }
/*  674 */       if (str2 != null && str2.startsWith("\"") && str2.endsWith("\""))
/*      */       {
/*  676 */         str4 = removeQuotes(str2);
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  682 */       if (str4 != null) {
/*  683 */         arrayOfByte2 = this.meg.conv.StringToCharBytes(str4);
/*      */       }
/*  685 */       if (str != "RADIUS") {
/*      */         
/*  687 */         if (arrayOfByte2 == null) {
/*      */           
/*  689 */           arrayOfByte4 = null;
/*      */         }
/*  691 */         else if (this.bUseO5Logon) {
/*      */           
/*  693 */           if (this.verifierType != 2361 && this.verifierType != 40674 && this.verifierType != 59694 && this.verifierType != 45394 && this.verifierType != 6949 && this.verifierType != 18453) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*  703 */             SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 451);
/*  704 */             sQLException.fillInStackTrace();
/*  705 */             throw sQLException;
/*      */           } 
/*      */ 
/*      */           
/*  709 */           this.encryptedKB = new byte[this.encryptedSK.length];
/*  710 */           for (byte b1 = 0; b1 < this.encryptedKB.length; ) { this.encryptedKB[b1] = 1; b1++; }
/*      */           
/*  712 */           int[] arrayOfInt = new int[1];
/*  713 */           byte[] arrayOfByte = new byte[256];
/*  714 */           for (byte b2 = 0; b2 < 'Ā'; ) { arrayOfByte[b2] = 0; b2++; }
/*      */           
/*      */           try {
/*  717 */             this.o5logonHelper.generateOAuthResponse(this.verifierType, this.salt, str3, str4, arrayOfByte2, this.encryptedSK, this.encryptedKB, arrayOfByte, arrayOfInt, this.meg.conv.isServerCSMultiByte, this.serverCompileTimeCapabilities[4]);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           }
/*  730 */           catch (Exception exception) {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  739 */           arrayOfByte4 = new byte[arrayOfInt[0]];
/*  740 */           System.arraycopy(arrayOfByte, 0, arrayOfByte4, 0, arrayOfInt[0]);
/*      */         } else {
/*      */           byte b;
/*      */           
/*  744 */           O3LoginClientHelper o3LoginClientHelper = new O3LoginClientHelper(this.meg.conv.isServerCSMultiByte);
/*      */           
/*  746 */           byte[] arrayOfByte5 = o3LoginClientHelper.getSessionKey(str3, str4, this.encryptedSK);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  752 */           if (arrayOfByte2.length % 8 > 0) {
/*  753 */             b = (byte)(8 - arrayOfByte2.length % 8);
/*      */           } else {
/*  755 */             b = 0;
/*      */           } 
/*  757 */           arrayOfByte3 = new byte[arrayOfByte2.length + b];
/*      */           
/*  759 */           System.arraycopy(arrayOfByte2, 0, arrayOfByte3, 0, arrayOfByte2.length);
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  764 */           byte[] arrayOfByte6 = o3LoginClientHelper.getEPasswd(arrayOfByte5, arrayOfByte3);
/*      */ 
/*      */           
/*  767 */           arrayOfByte4 = new byte[2 * arrayOfByte3.length + 1];
/*      */ 
/*      */           
/*  770 */           if (arrayOfByte4.length < 2 * arrayOfByte6.length) {
/*      */             
/*  772 */             SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 413);
/*  773 */             sQLException.fillInStackTrace();
/*  774 */             throw sQLException;
/*      */           } 
/*      */           
/*  777 */           RepConversion.bArray2Nibbles(arrayOfByte6, arrayOfByte4);
/*      */ 
/*      */           
/*  780 */           arrayOfByte4[arrayOfByte4.length - 1] = RepConversion.nibbleToHex(b);
/*      */         
/*      */         }
/*      */ 
/*      */       
/*      */       }
/*  786 */       else if (arrayOfByte2 != null) {
/*      */         
/*  788 */         if (this.connection.net.getSessionAttributes().getNTAdapter() instanceof oracle.net.nt.TcpsNTAdapter) {
/*      */           
/*  790 */           arrayOfByte4 = arrayOfByte2;
/*      */         } else {
/*      */           byte b1;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  798 */           if ((arrayOfByte2.length + 1) % 8 > 0) {
/*  799 */             b1 = (byte)(8 - (arrayOfByte2.length + 1) % 8);
/*      */           } else {
/*  801 */             b1 = 0;
/*      */           } 
/*  803 */           arrayOfByte3 = new byte[arrayOfByte2.length + 1 + b1];
/*      */           
/*  805 */           System.arraycopy(arrayOfByte2, 0, arrayOfByte3, 0, arrayOfByte2.length);
/*  806 */           byte[] arrayOfByte = AuthenticationService.obfuscatePasswordForRadius(arrayOfByte3);
/*      */ 
/*      */           
/*  809 */           arrayOfByte4 = new byte[arrayOfByte.length * 2];
/*      */           
/*  811 */           for (byte b2 = 0; b2 < arrayOfByte.length; b2++) {
/*      */             
/*  813 */             byte b3 = (byte)((arrayOfByte[b2] & 0xF0) >> 4);
/*  814 */             byte b4 = (byte)(arrayOfByte[b2] & 0xF);
/*  815 */             arrayOfByte4[b2 * 2] = (byte)((b3 < 10) ? (b3 + 48) : (b3 - 10 + 97));
/*      */             
/*  817 */             arrayOfByte4[b2 * 2 + 1] = (byte)((b4 < 10) ? (b4 + 48) : (b4 - 10 + 97));
/*      */           } 
/*      */         } 
/*      */       } 
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  825 */     doOAUTH(arrayOfByte1, arrayOfByte4, paramLong, str, false, (byte[])null, (byte[])null, (byte[][])null, -1, -1);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  836 */     if (str != "RADIUS" && this.bUseO5Logon)
/*      */     
/*  838 */     { String str1 = this.connection.sessionProperties.getProperty("AUTH_SVR_RESPONSE");
/*      */       
/*  840 */       try { if (!this.o5logonHelper.validateServerIdentity(str1))
/*      */         {
/*      */           
/*  843 */           SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 452);
/*  844 */           sQLException.fillInStackTrace();
/*  845 */           throw sQLException;
/*      */         }
/*      */          }
/*  848 */       catch (Exception exception)
/*      */       
/*  850 */       { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 452);
/*  851 */         sQLException.fillInStackTrace();
/*  852 */         throw sQLException; }  }  } void readRPA() throws IOException, SQLException { this.outNbPairs = this.meg.unmarshalUB2(); this.outKeys = new byte[this.outNbPairs][]; this.outValues = new byte[this.outNbPairs][]; this.outFlags = this.meg.unmarshalKEYVAL(this.outKeys, this.outValues, this.outNbPairs); }
/*      */   void processError() throws SQLException { if (getFunCode() == 118) { if (this.oer.getRetCode() != 28035 || this.connection.net.getAuthenticationAdaptorName() != "RADIUS")
/*      */         this.oer.processError();  } else { super.processError(); }  }
/*      */   protected void processRPA() throws SQLException { if (getFunCode() == 115) { Properties properties = new Properties(); for (byte b = 0; b < this.outNbPairs; b++) { String str1 = this.meg.conv.CharBytesToString(this.outKeys[b], (this.outKeys[b]).length).trim(); String str2 = ""; if (this.outValues[b] != null)
/*      */           str2 = this.meg.conv.CharBytesToString(this.outValues[b], (this.outValues[b]).length).trim();  properties.setProperty(str1, str2); }  String str = properties.getProperty("AUTH_VERSION_NO"); if (str != null)
/*      */         try { int i = (new Integer(str)).intValue(); } catch (NumberFormatException numberFormatException) {}  properties.setProperty("SERVER_HOST", properties.getProperty("AUTH_SC_SERVER_HOST", "")); properties.setProperty("INSTANCE_NAME", properties.getProperty("AUTH_SC_INSTANCE_NAME", "")); properties.setProperty("DATABASE_NAME", properties.getProperty("AUTH_SC_DBUNIQUE_NAME", "")); properties.setProperty("SERVICE_NAME", properties.getProperty("AUTH_SC_SERVICE_NAME", "")); properties.setProperty("SESSION_TIME_ZONE", this.sessionTimeZone); this.connection.sessionProperties = properties; } else if (getFunCode() == 118) { if (this.connection.net.getAuthenticationAdaptorName() != "RADIUS") { if (this.outKeys == null || this.outKeys.length < 1) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 438); sQLException.fillInStackTrace(); throw sQLException; }  byte b1 = -1; byte b2 = -1; try { for (byte b = 0; b < this.outKeys.length; b++) { String str = new String(this.outKeys[b], "US-ASCII"); if (str.equals("AUTH_SESSKEY")) { b1 = b; } else if (str.equals("AUTH_VFR_DATA")) { b2 = b; }  if (b2 != -1 && b1 != -1)
/*      */               break;  }  } catch (UnsupportedEncodingException unsupportedEncodingException) {} if (b1 == -1) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 438); sQLException.fillInStackTrace(); throw sQLException; }  this.encryptedSK = this.outValues[b1]; if (b2 != -1) { this.bUseO5Logon = true; this.salt = this.outValues[b2]; this.verifierType = this.outFlags[b2]; }
/*      */          if (!this.bUseO5Logon)
/*      */           if (this.encryptedSK == null || this.encryptedSK.length != 16) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 438); sQLException.fillInStackTrace(); throw sQLException; }
/*      */             }
/*      */        }
/*      */      }
/*  864 */   void doOAUTH(int paramInt1, Properties paramProperties, int paramInt2, int paramInt3) throws IOException, SQLException { byte[] arrayOfByte1 = null;
/*  865 */     byte[] arrayOfByte2 = null;
/*  866 */     String[] arrayOfString = null;
/*  867 */     byte[][] arrayOfByte = (byte[][])null;
/*  868 */     byte[] arrayOfByte3 = null;
/*      */     
/*  870 */     if (paramInt1 == 1) {
/*      */       
/*  872 */       String str1 = paramProperties.getProperty("PROXY_USER_NAME");
/*  873 */       String str2 = paramProperties.getProperty("PROXY_USER_PASSWORD");
/*  874 */       if (str2 != null)
/*  875 */         str1 = str1 + "/" + str2; 
/*  876 */       arrayOfByte3 = this.meg.conv.StringToCharBytes(str1);
/*      */     }
/*  878 */     else if (paramInt1 == 2) {
/*      */       
/*  880 */       String str = paramProperties.getProperty("PROXY_DISTINGUISHED_NAME");
/*      */ 
/*      */       
/*  883 */       arrayOfByte1 = this.meg.conv.StringToCharBytes(str);
/*      */     } else {
/*      */ 
/*      */       
/*      */       try {
/*      */         
/*  889 */         arrayOfByte2 = (byte[])paramProperties.get("PROXY_CERTIFICATE");
/*      */         
/*  891 */         StringBuffer stringBuffer = new StringBuffer();
/*      */ 
/*      */ 
/*      */         
/*  895 */         for (byte b = 0; b < arrayOfByte2.length; b++) {
/*      */           
/*  897 */           String str = Integer.toHexString(0xFF & arrayOfByte2[b]);
/*  898 */           int i = str.length();
/*      */           
/*  900 */           if (i == 0) {
/*  901 */             stringBuffer.append("00");
/*  902 */           } else if (i == 1) {
/*      */             
/*  904 */             stringBuffer.append('0');
/*  905 */             stringBuffer.append(str);
/*      */           } else {
/*      */             
/*  908 */             stringBuffer.append(str);
/*      */           } 
/*      */         } 
/*  911 */         arrayOfByte2 = stringBuffer.toString().getBytes();
/*      */       }
/*  913 */       catch (Exception exception) {}
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*      */     try {
/*  919 */       arrayOfString = (String[])paramProperties.get("PROXY_ROLES");
/*      */     }
/*  921 */     catch (Exception exception) {}
/*      */     
/*  923 */     if (arrayOfString != null) {
/*      */       
/*  925 */       arrayOfByte = new byte[arrayOfString.length][];
/*      */       
/*  927 */       for (byte b = 0; b < arrayOfString.length; b++) {
/*  928 */         arrayOfByte[b] = this.meg.conv.StringToCharBytes(arrayOfString[b]);
/*      */       }
/*      */     } 
/*  931 */     doOAUTH(arrayOfByte3, (byte[])null, 0L, (String)null, true, arrayOfByte1, arrayOfByte2, arrayOfByte, paramInt2, paramInt3); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void setSessionFields(T4CConnection paramT4CConnection) throws SQLException {
/*  955 */     String str1 = this.connection.thinVsessionTerminal;
/*  956 */     String str2 = this.connection.thinVsessionMachine;
/*  957 */     String str3 = this.connection.thinVsessionOsuser;
/*  958 */     String str4 = this.connection.thinVsessionProgram;
/*  959 */     String str5 = this.connection.thinVsessionProcess;
/*  960 */     String str6 = this.connection.thinVsessionIname;
/*  961 */     String str7 = this.connection.thinVsessionEname;
/*  962 */     String str8 = this.connection.proxyClientName;
/*  963 */     String str9 = this.connection.driverNameAttribute;
/*  964 */     String str10 = this.connection.editionName;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  975 */     if (this.connection.enableTempLobRefCnt) {
/*  976 */       this.enableTempLobRefCnt = (new String("1")).getBytes();
/*      */     } else {
/*  978 */       this.enableTempLobRefCnt = (new String("0")).getBytes();
/*      */     } 
/*  980 */     if (str2 == null) {
/*      */       
/*      */       try {
/*      */ 
/*      */         
/*  985 */         str2 = InetAddress.getLocalHost().getHostName();
/*      */       }
/*  987 */       catch (Exception exception) {
/*      */         
/*  989 */         str2 = "jdbcclient";
/*      */       } 
/*      */     }
/*      */     
/*  993 */     if (str7 == null) {
/*  994 */       str7 = "jdbc_" + this.ressourceManagerId;
/*      */     }
/*  996 */     if (str9 == null) {
/*  997 */       str9 = "jdbcthin";
/*      */     }
/*      */     
/* 1000 */     this.terminal = this.meg.conv.StringToCharBytes(str1);
/* 1001 */     this.machine = this.meg.conv.StringToCharBytes(str2);
/* 1002 */     this.sysUserName = this.meg.conv.StringToCharBytes(str3);
/* 1003 */     this.programName = this.meg.conv.StringToCharBytes(str4);
/* 1004 */     this.processID = this.meg.conv.StringToCharBytes(str5);
/* 1005 */     this.internalName = this.meg.conv.StringToCharBytes(str6);
/* 1006 */     this.externalName = this.meg.conv.StringToCharBytes(str7);
/* 1007 */     if (str8 != null)
/* 1008 */       this.clientname = this.meg.conv.StringToCharBytes(str8); 
/* 1009 */     if (str10 != null)
/* 1010 */       this.editionName = this.meg.conv.StringToCharBytes(str10); 
/* 1011 */     this.driverName = this.meg.conv.StringToCharBytes(str9);
/*      */     
/* 1013 */     TimeZone timeZone = TimeZone.getDefault();
/*      */ 
/*      */     
/* 1016 */     String str11 = timeZone.getID();
/*      */     
/* 1018 */     if (!ZONEIDMAP.isValidRegion(str11) || !paramT4CConnection.timezoneAsRegion) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1027 */       int i = timeZone.getOffset(System.currentTimeMillis());
/* 1028 */       int j = i / 3600000;
/* 1029 */       int k = i / 60000 % 60;
/*      */       
/* 1031 */       str11 = ((j < 0) ? ("" + j) : ("+" + j)) + ((k < 10) ? (":0" + k) : (":" + k));
/*      */     } 
/*      */ 
/*      */     
/* 1035 */     this.sessionTimeZone = str11;
/* 1036 */     paramT4CConnection.sessionTimeZone = str11;
/*      */     
/* 1038 */     String str12 = CharacterSetMetaData.getNLSLanguage(Locale.getDefault(Locale.Category.FORMAT));
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1047 */     String str13 = CharacterSetMetaData.getNLSTerritory(Locale.getDefault(Locale.Category.FORMAT));
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1056 */     if (str12 == null || str13 == null) {
/*      */       
/* 1058 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 176);
/* 1059 */       sQLException.fillInStackTrace();
/* 1060 */       throw sQLException;
/*      */     } 
/*      */     
/* 1063 */     this.alterSession = this.meg.conv.StringToCharBytes("ALTER SESSION SET " + (this.isSessionTZ ? ("TIME_ZONE='" + this.sessionTimeZone + "'") : "") + " NLS_LANGUAGE='" + str12 + "' NLS_TERRITORY='" + str13 + "' ");
/*      */ 
/*      */ 
/*      */     
/* 1067 */     this.aclValue = this.meg.conv.StringToCharBytes("4400");
/* 1068 */     this.alterSession[this.alterSession.length - 1] = 0;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   String removeQuotes(String paramString) {
/* 1082 */     int i = 0, j = paramString.length() - 1;
/*      */     int k;
/* 1084 */     for (k = 0; k < paramString.length(); k++) {
/*      */       
/* 1086 */       if (paramString.charAt(k) != '"') {
/*      */         
/* 1088 */         i = k;
/*      */         
/*      */         break;
/*      */       } 
/*      */     } 
/*      */     
/* 1094 */     for (k = paramString.length() - 1; k >= 0; k--) {
/*      */       
/* 1096 */       if (paramString.charAt(k) != '"') {
/*      */         
/* 1098 */         j = k;
/*      */         
/*      */         break;
/*      */       } 
/*      */     } 
/*      */     
/* 1104 */     return paramString.substring(i, j + 1);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private int versionStringToInt(String paramString) throws SQLException {
/* 1133 */     String[] arrayOfString = paramString.split("\\.");
/* 1134 */     int i = Integer.parseInt(arrayOfString[0].replaceAll("\\D", ""));
/* 1135 */     int j = Integer.parseInt(arrayOfString[1].replaceAll("\\D", ""));
/* 1136 */     int k = Integer.parseInt(arrayOfString[2].replaceAll("\\D", ""));
/* 1137 */     int m = Integer.parseInt(arrayOfString[3].replaceAll("\\D", ""));
/* 1138 */     int n = Integer.parseInt(arrayOfString[4].replaceAll("\\D", ""));
/* 1139 */     return i << 24 | j << 20 | k << 12 | m << 8 | n;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private String versionIntToString(int paramInt) throws SQLException {
/* 1151 */     int i = (paramInt & 0xFF000000) >> 24 & 0xFF;
/* 1152 */     int j = (paramInt & 0xF00000) >> 20 & 0xFF;
/* 1153 */     int k = (paramInt & 0xFF000) >> 12 & 0xFF;
/* 1154 */     int m = (paramInt & 0xF00) >> 8 & 0xFF;
/* 1155 */     int n = paramInt & 0xFF;
/* 1156 */     return "" + i + "." + j + "." + k + "." + m + "." + n;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected OracleConnection getConnectionDuringExceptionHandling() {
/* 1172 */     return this.connection;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public byte[] getDerivedKeyJdbc(byte[] paramArrayOfbyte, int paramInt) throws NoSuchAlgorithmException, InvalidKeySpecException, SQLException {
/* 1185 */     if (this.verifierType == 2361) {
/*      */       
/* 1187 */       paramInt |= 0x1;
/*      */     } else {
/*      */       
/* 1190 */       paramInt |= 0x0;
/*      */     } 
/* 1192 */     return this.o5logonHelper.getDerivedKey(paramArrayOfbyte, paramInt);
/*      */   }
/*      */ 
/*      */   
/* 1196 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*      */   public static final String BUILD_DATE = "Thu_Apr_04_15:09:24_PDT_2013";
/*      */   public static final boolean TRACE = false;
/*      */ }


/* Location:              C:\Users\olatu\OneDrive\Documents\Calypso\syncbase\sync_base.jar!\BOOT-INF\lib\ojdbc-7.jar!\oracle\jdbc\driver\T4CTTIoauthenticate.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */