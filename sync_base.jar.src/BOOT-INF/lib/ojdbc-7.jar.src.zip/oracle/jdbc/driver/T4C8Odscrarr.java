/*     */ package oracle.jdbc.driver;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.sql.SQLException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class T4C8Odscrarr
/*     */   extends T4CTTIfun
/*     */ {
/*     */   private static final byte OPERATIONFLAGS = 7;
/*     */   private static final long SQLPARSEVERSION = 2L;
/*     */   byte[] sqltext;
/*     */   T4CTTIdcb dcb;
/*  44 */   int cursor_id = 0;
/*     */ 
/*     */   
/*  47 */   int numuds = 0;
/*     */ 
/*     */ 
/*     */   
/*     */   private static final boolean UDSARRAYO2U = true;
/*     */ 
/*     */ 
/*     */   
/*     */   private static final boolean NUMUDSO2U = true;
/*     */ 
/*     */   
/*  58 */   OracleStatement statement = null;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Accessor[] accessors;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   T4C8Odscrarr(T4CConnection paramT4CConnection) {
/*  69 */     super(paramT4CConnection, (byte)3);
/*     */ 
/*     */     
/*  72 */     setFunCode((short)98);
/*  73 */     this.dcb = new T4CTTIdcb(paramT4CConnection);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void doODNY(OracleStatement paramOracleStatement, int paramInt, Accessor[] paramArrayOfAccessor, byte[] paramArrayOfbyte) throws IOException, SQLException {
/*  84 */     this.numuds = 0;
/*  85 */     this.cursor_id = paramOracleStatement.cursorId;
/*  86 */     this.statement = paramOracleStatement;
/*     */     
/*  88 */     if (paramArrayOfbyte != null && paramArrayOfbyte.length > 0) {
/*  89 */       this.sqltext = paramArrayOfbyte;
/*     */     } else {
/*  91 */       this.sqltext = PhysicalConnection.EMPTY_BYTE_ARRAY;
/*     */     } 
/*  93 */     this.dcb.init(paramOracleStatement, paramInt);
/*  94 */     this.accessors = paramArrayOfAccessor;
/*  95 */     this.numuds = 0;
/*  96 */     doRPC();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void marshal() throws IOException {
/* 119 */     this.meg.marshalUB1((short)7);
/* 120 */     this.meg.marshalSWORD(this.cursor_id);
/*     */ 
/*     */     
/* 123 */     if (this.sqltext.length == 0) {
/* 124 */       this.meg.marshalNULLPTR();
/*     */     } else {
/* 126 */       this.meg.marshalPTR();
/*     */     } 
/* 128 */     this.meg.marshalSB4(this.sqltext.length);
/*     */     
/* 130 */     this.meg.marshalUB4(2L);
/*     */     
/* 132 */     this.meg.marshalO2U(true);
/* 133 */     this.meg.marshalO2U(true);
/*     */ 
/*     */ 
/*     */     
/* 137 */     this.meg.marshalCHR(this.sqltext);
/* 138 */     this.sqltext = PhysicalConnection.EMPTY_BYTE_ARRAY;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Accessor[] getAccessors() {
/* 175 */     return this.accessors;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void readRPA() throws IOException, SQLException {
/* 182 */     this.accessors = this.dcb.receiveCommon(this.accessors, true);
/* 183 */     this.numuds = this.dcb.numuds;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/* 188 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*     */   public static final String BUILD_DATE = "Thu_Apr_04_15:09:24_PDT_2013";
/*     */   public static final boolean TRACE = false;
/*     */ }


/* Location:              C:\Users\olatu\OneDrive\Documents\Calypso\syncbase\sync_base.jar!\BOOT-INF\lib\ojdbc-7.jar!\oracle\jdbc\driver\T4C8Odscrarr.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */