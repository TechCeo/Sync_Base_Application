/*     */ package oracle.jdbc.driver;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.sql.SQLException;
/*     */ import java.sql.SQLWarning;
/*     */ import oracle.jdbc.internal.OracleConnection;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class T4CTTIspfp
/*     */   extends T4CTTIfun
/*     */ {
/*     */   T4CTTIspfp(T4CConnection paramT4CConnection) {
/*  57 */     super(paramT4CConnection, (byte)3);
/*     */     
/*  59 */     setFunCode((short)138);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   void doOSPFPPUT() throws IOException, SQLException {
/*  65 */     doRPC();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void marshal() throws IOException {
/*  72 */     this.meg.marshalPTR();
/*  73 */     this.meg.marshalSWORD(100);
/*  74 */     this.meg.marshalPTR();
/*  75 */     this.meg.marshalPTR();
/*  76 */     this.meg.marshalSWORD(0);
/*  77 */     this.meg.marshalNULLPTR();
/*  78 */     this.meg.marshalSWORD(0);
/*  79 */     this.meg.marshalNULLPTR();
/*  80 */     this.meg.marshalNULLPTR();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void readRPA() throws IOException, SQLException {
/*  87 */     int i = this.meg.unmarshalUB2();
/*  88 */     byte[] arrayOfByte = this.meg.unmarshalNBytes(i);
/*  89 */     if (i > 1) {
/*     */       
/*  91 */       String str = this.meg.conv.CharBytesToString(arrayOfByte, i, true);
/*  92 */       SQLWarning sQLWarning1 = new SQLWarning(str);
/*  93 */       SQLWarning sQLWarning2 = this.connection.getWarnings();
/*  94 */       if (sQLWarning2 == null) {
/*  95 */         this.connection.setWarnings(sQLWarning1);
/*     */       } else {
/*  97 */         sQLWarning2.setNextWarning(sQLWarning1);
/*     */       } 
/*  99 */     }  this.meg.unmarshalUB2();
/* 100 */     this.meg.unmarshalUB2();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected OracleConnection getConnectionDuringExceptionHandling() {
/* 115 */     return this.connection;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/* 120 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*     */   public static final String BUILD_DATE = "Thu_Apr_04_15:09:24_PDT_2013";
/*     */   public static final boolean TRACE = false;
/*     */ }


/* Location:              C:\Users\olatu\OneDrive\Documents\Calypso\syncbase\sync_base.jar!\BOOT-INF\lib\ojdbc-7.jar!\oracle\jdbc\driver\T4CTTIspfp.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */