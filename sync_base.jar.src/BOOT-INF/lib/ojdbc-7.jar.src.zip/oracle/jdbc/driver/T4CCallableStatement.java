/*      */ package oracle.jdbc.driver;
/*      */ 
/*      */ import java.io.IOException;
/*      */ import java.sql.SQLException;
/*      */ import oracle.jdbc.OracleConnection;
/*      */ import oracle.jdbc.internal.OracleStatement;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ class T4CCallableStatement
/*      */   extends OracleCallableStatement
/*      */ {
/*      */   T4CCallableStatement(PhysicalConnection paramPhysicalConnection, String paramString, int paramInt1, int paramInt2) throws SQLException {
/*   25 */     super(paramPhysicalConnection, paramString, paramPhysicalConnection.defaultExecuteBatch, paramPhysicalConnection.defaultRowPrefetch, paramInt1, paramInt2);
/*      */     
/*   27 */     this.t4Connection = (T4CConnection)paramPhysicalConnection;
/*   28 */     this.nbPostPonedColumns = new int[1];
/*   29 */     this.nbPostPonedColumns[0] = 0;
/*   30 */     this.indexOfPostPonedColumn = new int[1][3];
/*      */     
/*   32 */     this.theRowidBinder = theStaticT4CRowidBinder;
/*   33 */     this.theRowidNullBinder = theStaticT4CRowidNullBinder;
/*   34 */     this.theURowidBinder = theStaticT4CURowidBinder;
/*   35 */     this.theURowidNullBinder = theStaticT4CURowidNullBinder;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*   41 */   static final byte[] EMPTY_BYTE = new byte[0];
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   T4CConnection t4Connection;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void doOall8(boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3, boolean paramBoolean4, boolean paramBoolean5) throws SQLException, IOException {
/*   53 */     doOall8(paramBoolean1, paramBoolean2, paramBoolean3, paramBoolean4, paramBoolean5, 0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void doOall8(boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3, boolean paramBoolean4, boolean paramBoolean5, int paramInt) throws SQLException, IOException {
/*   67 */     if (paramBoolean1 || paramBoolean4 || !paramBoolean2) {
/*   68 */       this.oacdefSent = null;
/*      */     }
/*   70 */     this.t4Connection.assertLoggedOn("oracle.jdbc.driver.T4CCallableStatement.doOall8");
/*      */     
/*   72 */     if (this.sqlKind == OracleStatement.SqlKind.UNINITIALIZED) {
/*      */ 
/*      */ 
/*      */       
/*   76 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 439, "sqlKind = " + this.sqlKind);
/*   77 */       sQLException.fillInStackTrace();
/*   78 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/*   82 */     int i = this.rowPrefetch;
/*   83 */     if (paramBoolean3) {
/*   84 */       if (this.maxRows > 0 && this.maxRows <= this.indexOfFirstRow + this.storedRowCount + this.rowPrefetch) {
/*      */         
/*   86 */         i = this.maxRows - this.indexOfFirstRow + this.storedRowCount;
/*   87 */         this.isComplete = true;
/*      */       } 
/*   89 */       this.rowPrefetchInLastFetch = i;
/*   90 */       if (i == 0 && this.isComplete)
/*      */         return; 
/*      */     } 
/*   93 */     int j = this.numberOfDefinePositions;
/*      */     
/*   95 */     if (this.sqlKind.isDML()) {
/*   96 */       j = 0;
/*      */     }
/*      */     
/*   99 */     if (this.accessors != null)
/*  100 */       for (byte b = 0; b < this.accessors.length; b++) {
/*  101 */         if (this.accessors[b] != null)
/*  102 */           (this.accessors[b]).lastRowProcessed = paramInt; 
/*  103 */       }   if (this.outBindAccessors != null) {
/*  104 */       for (byte b = 0; b < this.outBindAccessors.length; b++) {
/*  105 */         if (this.outBindAccessors[b] != null) {
/*  106 */           (this.outBindAccessors[b]).lastRowProcessed = 0;
/*      */         }
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*  113 */     if (this.bindIndicators != null) {
/*      */       
/*  115 */       int k = ((this.bindIndicators[this.bindIndicatorSubRange + 3] & 0xFFFF) << 16) + (this.bindIndicators[this.bindIndicatorSubRange + 4] & 0xFFFF);
/*      */ 
/*      */       
/*  118 */       int m = 0;
/*      */       
/*  120 */       if (this.ibtBindChars != null) {
/*  121 */         m = this.ibtBindChars.length * this.connection.conversion.cMaxCharSize;
/*      */       }
/*  123 */       for (byte b = 0; b < this.numberOfBindPositions; b++) {
/*      */         
/*  125 */         int n = this.bindIndicatorSubRange + 5 + 10 * b;
/*      */ 
/*      */ 
/*      */         
/*  129 */         int i1 = this.bindIndicators[n + 2] & 0xFFFF;
/*      */ 
/*      */ 
/*      */         
/*  133 */         if (i1 != 0) {
/*      */ 
/*      */           
/*  136 */           int i2 = this.bindIndicators[n + 9] & 0xFFFF;
/*      */ 
/*      */ 
/*      */           
/*  140 */           if (i2 == 2) {
/*      */             
/*  142 */             m = Math.max(i1 * this.connection.conversion.maxNCharSize, m);
/*      */           
/*      */           }
/*      */           else {
/*      */             
/*  147 */             m = Math.max(i1 * this.connection.conversion.cMaxCharSize, m);
/*      */           } 
/*      */         } 
/*      */       } 
/*      */ 
/*      */       
/*  153 */       if (this.tmpBindsByteArray == null)
/*      */       {
/*  155 */         this.tmpBindsByteArray = new byte[m];
/*      */       }
/*  157 */       else if (this.tmpBindsByteArray.length < m)
/*      */       {
/*  159 */         this.tmpBindsByteArray = null;
/*  160 */         this.tmpBindsByteArray = new byte[m];
/*      */ 
/*      */       
/*      */       }
/*      */ 
/*      */ 
/*      */     
/*      */     }
/*      */     else {
/*      */ 
/*      */ 
/*      */       
/*  172 */       this.tmpBindsByteArray = null;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  177 */     int[] arrayOfInt1 = this.definedColumnType;
/*  178 */     int[] arrayOfInt2 = this.definedColumnSize;
/*  179 */     int[] arrayOfInt3 = this.definedColumnFormOfUse;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  185 */     if (paramBoolean5 && paramBoolean4 && this.isRowidPrepended) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  190 */       arrayOfInt1 = new int[this.definedColumnType.length + 1];
/*  191 */       System.arraycopy(this.definedColumnType, 0, arrayOfInt1, 1, this.definedColumnType.length);
/*  192 */       arrayOfInt1[0] = -8;
/*  193 */       arrayOfInt2 = new int[this.definedColumnSize.length + 1];
/*  194 */       System.arraycopy(this.definedColumnSize, 0, arrayOfInt2, 1, this.definedColumnSize.length);
/*  195 */       arrayOfInt3 = new int[this.definedColumnFormOfUse.length + 1];
/*  196 */       System.arraycopy(this.definedColumnFormOfUse, 0, arrayOfInt3, 1, this.definedColumnFormOfUse.length);
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  202 */     allocateTmpByteArray();
/*      */     
/*  204 */     T4C8Oall t4C8Oall = this.t4Connection.all8;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     try {
/*  210 */       t4C8Oall.doOALL(paramBoolean1, paramBoolean2, paramBoolean3, paramBoolean4, paramBoolean5, this.sqlKind, this.cursorId, this.sqlObject.getSqlBytes(this.processEscapes, this.convertNcharLiterals), i, this.outBindAccessors, this.numberOfBindPositions, this.accessors, j, this.bindBytes, this.bindChars, this.bindIndicators, this.bindIndicatorSubRange, this.connection.conversion, this.tmpBindsByteArray, this.parameterStream, this.parameterDatum, this.parameterOtype, this, this.ibtBindBytes, this.ibtBindChars, this.ibtBindIndicators, this.oacdefSent, arrayOfInt1, arrayOfInt2, arrayOfInt3, this.registration);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  222 */       int k = t4C8Oall.getCursorId();
/*  223 */       if (k != 0 && this.implicitResultSetStatements == null) {
/*  224 */         this.cursorId = k;
/*      */       }
/*  226 */       this.oacdefSent = t4C8Oall.oacdefBindsSent;
/*  227 */       if (this.connection.isPDBChanged) {
/*  228 */         NTFPDBChangeEvent nTFPDBChangeEvent = new NTFPDBChangeEvent((OracleConnection)this.connection);
/*      */         
/*  230 */         ((T4CConnection)this.connection).notify(nTFPDBChangeEvent);
/*  231 */         this.connection.isPDBChanged = false;
/*      */       }
/*      */     
/*  234 */     } catch (SQLException sQLException) {
/*      */       
/*  236 */       int k = t4C8Oall.getCursorId();
/*  237 */       if (k != 0) {
/*  238 */         this.cursorId = k;
/*      */       }
/*  240 */       if (sQLException.getErrorCode() == DatabaseError.getVendorCode(110)) {
/*      */ 
/*      */         
/*  243 */         this.sqlWarning = DatabaseError.addSqlWarning(this.sqlWarning, 110);
/*      */       
/*      */       }
/*      */       else {
/*      */         
/*  248 */         throw sQLException;
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void allocateTmpByteArray() {
/*  258 */     if (this.tmpByteArray == null) {
/*      */ 
/*      */       
/*  261 */       this.tmpByteArray = new byte[this.sizeTmpByteArray];
/*      */     }
/*  263 */     else if (this.sizeTmpByteArray > this.tmpByteArray.length) {
/*      */ 
/*      */ 
/*      */       
/*  267 */       this.tmpByteArray = new byte[this.sizeTmpByteArray];
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void releaseBuffers() {
/*  279 */     super.releaseBuffers();
/*  280 */     this.tmpByteArray = null;
/*  281 */     this.tmpBindsByteArray = null;
/*      */     
/*  283 */     if (this.t4Connection != null) {
/*      */       
/*  285 */       this.t4Connection.all8.bindChars = null;
/*  286 */       this.t4Connection.all8.bindBytes = null;
/*  287 */       this.t4Connection.all8.tmpBindsByteArray = null;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void allocateRowidAccessor() throws SQLException {
/*  295 */     this.accessors[0] = new T4CRowidAccessor(this, 128, (short)1, -8, false, this.t4Connection.mare);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void reparseOnRedefineIfNeeded() throws SQLException {
/*  308 */     this.needToParse = true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void defineColumnTypeInternal(int paramInt1, int paramInt2, int paramInt3, short paramShort, boolean paramBoolean, String paramString) throws SQLException {
/*  319 */     if (this.connection.disableDefinecolumntype) {
/*      */       return;
/*      */     }
/*      */ 
/*      */     
/*  324 */     if (paramInt2 == -15 || paramInt2 == -9 || paramInt2 == -16)
/*      */     {
/*  326 */       paramShort = 2;
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*  331 */     if (paramInt1 < 1) {
/*      */       
/*  333 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/*  334 */       sQLException.fillInStackTrace();
/*  335 */       throw sQLException;
/*      */     } 
/*      */     
/*  338 */     if (this.currentResultSet != null && !this.currentResultSet.closed) {
/*      */       
/*  340 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 28);
/*  341 */       sQLException.fillInStackTrace();
/*  342 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  349 */     int i = paramInt1 - 1;
/*      */     
/*  351 */     if (this.definedColumnType == null || this.definedColumnType.length <= i)
/*      */     {
/*  353 */       if (this.definedColumnType == null) {
/*      */         
/*  355 */         this.definedColumnType = new int[(i + 1) * 4];
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       }
/*      */       else {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  367 */         int[] arrayOfInt = new int[(i + 1) * 4];
/*      */         
/*  369 */         System.arraycopy(this.definedColumnType, 0, arrayOfInt, 0, this.definedColumnType.length);
/*      */ 
/*      */         
/*  372 */         this.definedColumnType = arrayOfInt;
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*  378 */     this.definedColumnType[i] = paramInt2;
/*      */     
/*  380 */     if (this.definedColumnSize == null || this.definedColumnSize.length <= i)
/*      */     {
/*  382 */       if (this.definedColumnSize == null) {
/*  383 */         this.definedColumnSize = new int[(i + 1) * 4];
/*      */       }
/*      */       else {
/*      */         
/*  387 */         int[] arrayOfInt = new int[(i + 1) * 4];
/*      */         
/*  389 */         System.arraycopy(this.definedColumnSize, 0, arrayOfInt, 0, this.definedColumnSize.length);
/*      */ 
/*      */         
/*  392 */         this.definedColumnSize = arrayOfInt;
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*  397 */     this.definedColumnSize[i] = (paramInt2 == 2005 || paramInt2 == 2004) ? paramInt3 : -1;
/*      */     
/*  399 */     if (this.definedColumnFormOfUse == null || this.definedColumnFormOfUse.length <= i)
/*      */     {
/*  401 */       if (this.definedColumnFormOfUse == null) {
/*  402 */         this.definedColumnFormOfUse = new int[(i + 1) * 4];
/*      */       }
/*      */       else {
/*      */         
/*  406 */         int[] arrayOfInt = new int[(i + 1) * 4];
/*      */         
/*  408 */         System.arraycopy(this.definedColumnFormOfUse, 0, arrayOfInt, 0, this.definedColumnFormOfUse.length);
/*      */ 
/*      */         
/*  411 */         this.definedColumnFormOfUse = arrayOfInt;
/*      */       } 
/*      */     }
/*      */     
/*  415 */     this.definedColumnFormOfUse[i] = paramShort;
/*      */     
/*  417 */     if (this.accessors != null && i < this.accessors.length && this.accessors[i] != null) {
/*      */       
/*  419 */       (this.accessors[i]).definedColumnSize = paramInt3;
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  424 */       if (((this.accessors[i]).internalType == 96 || (this.accessors[i]).internalType == 1) && (paramInt2 == 1 || paramInt2 == 12))
/*      */       {
/*      */ 
/*      */         
/*  428 */         if (paramInt3 <= (this.accessors[i]).oacmxl) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  434 */           this.needToPrepareDefineBuffer = true;
/*  435 */           this.columnsDefinedByUser = true;
/*      */           
/*  437 */           this.accessors[i].initForDataAccess(paramInt2, paramInt3, null);
/*  438 */           this.accessors[i].calculateSizeTmpByteArray();
/*      */         } 
/*      */       }
/*      */     } 
/*      */     
/*  443 */     this.executeDoneForDefines = false;
/*      */   }
/*      */ 
/*      */   
/*      */   public void clearDefines() throws SQLException {
/*  448 */     synchronized (this.connection) {
/*      */       
/*  450 */       super.clearDefines();
/*  451 */       this.definedColumnType = null;
/*  452 */       this.definedColumnSize = null;
/*  453 */       this.definedColumnFormOfUse = null;
/*  454 */       if (this.t4Connection != null && this.t4Connection.all8 != null) {
/*  455 */         this.t4Connection.all8.definesAccessors = null;
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void doSetSnapshotSCN(long paramLong) throws SQLException {
/*  464 */     this.inScn = paramLong; } Accessor allocateAccessor(int paramInt1, int paramInt2, int paramInt3, int paramInt4, short paramShort, String paramString, boolean paramBoolean) throws SQLException { T4CVarcharAccessor t4CVarcharAccessor;
/*      */     T4CNumberAccessor t4CNumberAccessor;
/*      */     T4CVarnumAccessor t4CVarnumAccessor;
/*      */     T4CRawAccessor t4CRawAccessor;
/*      */     T4CBinaryFloatAccessor t4CBinaryFloatAccessor;
/*      */     T4CBinaryDoubleAccessor t4CBinaryDoubleAccessor;
/*      */     T4CRowidAccessor t4CRowidAccessor;
/*      */     T4CResultSetAccessor t4CResultSetAccessor;
/*      */     T4CDateAccessor t4CDateAccessor;
/*      */     T4CBlobAccessor t4CBlobAccessor;
/*      */     T4CClobAccessor t4CClobAccessor;
/*      */     T4CBfileAccessor t4CBfileAccessor;
/*      */     T4CNamedTypeAccessor t4CNamedTypeAccessor;
/*      */     T4CRefTypeAccessor t4CRefTypeAccessor;
/*      */     T4CTimestampAccessor t4CTimestampAccessor;
/*      */     T4CTimestamptzAccessor t4CTimestamptzAccessor;
/*      */     T4CTimestampltzAccessor t4CTimestampltzAccessor;
/*      */     T4CIntervalymAccessor t4CIntervalymAccessor;
/*      */     T4CIntervaldsAccessor t4CIntervaldsAccessor;
/*      */     SQLException sQLException;
/*  484 */     T4CCharAccessor t4CCharAccessor = null;
/*      */     
/*  486 */     switch (paramInt1) {
/*      */ 
/*      */       
/*      */       case 96:
/*  490 */         t4CCharAccessor = new T4CCharAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 8:
/*  496 */         if (!paramBoolean) {
/*      */           
/*  498 */           T4CLongAccessor t4CLongAccessor = new T4CLongAccessor(this, paramInt3, paramInt4, paramShort, paramInt2, this.t4Connection.mare);
/*      */           break;
/*      */         } 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 1:
/*  506 */         t4CVarcharAccessor = new T4CVarcharAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 2:
/*  512 */         t4CNumberAccessor = new T4CNumberAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 6:
/*  518 */         t4CVarnumAccessor = new T4CVarnumAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 24:
/*  524 */         if (!paramBoolean) {
/*      */           
/*  526 */           T4CLongRawAccessor t4CLongRawAccessor = new T4CLongRawAccessor(this, paramInt3, paramInt4, paramShort, paramInt2, this.t4Connection.mare);
/*      */           break;
/*      */         } 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 23:
/*  534 */         if (paramBoolean && paramString != null) {
/*      */           
/*  536 */           SQLException sQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 12, "sqlType=" + paramInt2);
/*  537 */           sQLException1.fillInStackTrace();
/*  538 */           throw sQLException1;
/*      */         } 
/*      */         
/*  541 */         if (paramBoolean) {
/*  542 */           T4COutRawAccessor t4COutRawAccessor = new T4COutRawAccessor(this, paramInt4, paramShort, paramInt2, this.t4Connection.mare);
/*      */           break;
/*      */         } 
/*  545 */         t4CRawAccessor = new T4CRawAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 100:
/*  551 */         t4CBinaryFloatAccessor = new T4CBinaryFloatAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 101:
/*  557 */         t4CBinaryDoubleAccessor = new T4CBinaryDoubleAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 104:
/*  563 */         if (this.sqlKind == OracleStatement.SqlKind.CALL_BLOCK) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  569 */           T4CVarcharAccessor t4CVarcharAccessor1 = new T4CVarcharAccessor(this, 18, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */ 
/*      */ 
/*      */           
/*  573 */           t4CVarcharAccessor1.definedColumnType = -8;
/*      */           break;
/*      */         } 
/*  576 */         t4CRowidAccessor = new T4CRowidAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */         break;
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 102:
/*  583 */         t4CResultSetAccessor = new T4CResultSetAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 12:
/*  589 */         t4CDateAccessor = new T4CDateAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 113:
/*  595 */         t4CBlobAccessor = new T4CBlobAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 112:
/*  601 */         t4CClobAccessor = new T4CClobAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 114:
/*  607 */         t4CBfileAccessor = new T4CBfileAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 109:
/*  613 */         t4CNamedTypeAccessor = new T4CNamedTypeAccessor(this, paramString, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */ 
/*      */         
/*  616 */         t4CNamedTypeAccessor.initMetadata();
/*      */         break;
/*      */ 
/*      */       
/*      */       case 111:
/*  621 */         t4CRefTypeAccessor = new T4CRefTypeAccessor(this, paramString, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */ 
/*      */         
/*  624 */         t4CRefTypeAccessor.initMetadata();
/*      */         break;
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 180:
/*  631 */         t4CTimestampAccessor = new T4CTimestampAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 181:
/*  637 */         t4CTimestamptzAccessor = new T4CTimestamptzAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 231:
/*  643 */         t4CTimestampltzAccessor = new T4CTimestampltzAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 182:
/*  649 */         t4CIntervalymAccessor = new T4CIntervalymAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 183:
/*  655 */         t4CIntervaldsAccessor = new T4CIntervaldsAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */         break;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 995:
/*  671 */         sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 89);
/*  672 */         sQLException.fillInStackTrace();
/*  673 */         throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/*  677 */     return t4CIntervaldsAccessor; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void doDescribe(boolean paramBoolean) throws SQLException {
/*  703 */     if (!this.isOpen) {
/*      */ 
/*      */       
/*  706 */       this.connection.open(this);
/*  707 */       this.isOpen = true;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*      */     try {
/*  713 */       this.t4Connection.needLine();
/*  714 */       this.t4Connection.describe.doODNY(this, 0, this.accessors, this.sqlObject.getSqlBytes(this.processEscapes, this.convertNcharLiterals));
/*  715 */       this.accessors = this.t4Connection.describe.getAccessors();
/*      */       
/*  717 */       this.numberOfDefinePositions = this.t4Connection.describe.numuds;
/*      */       
/*  719 */       for (byte b = 0; b < this.numberOfDefinePositions; b++) {
/*  720 */         this.accessors[b].initMetadata();
/*      */       }
/*  722 */     } catch (IOException iOException) {
/*      */       
/*  724 */       ((T4CConnection)this.connection).handleIOException(iOException);
/*      */ 
/*      */       
/*  727 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException);
/*  728 */       sQLException.fillInStackTrace();
/*  729 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/*  733 */     this.describedWithNames = true;
/*  734 */     this.described = true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void executeForDescribe() throws SQLException {
/*  769 */     this.t4Connection.assertLoggedOn("oracle.jdbc.driver.T4CCallableStatement.execute_for_describe");
/*      */     try {
/*  771 */       doOall8(true, true, (this.definedColumnType != null), true, (this.definedColumnType != null));
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     }
/*  777 */     catch (SQLException sQLException) {
/*      */ 
/*      */       
/*  780 */       throw sQLException;
/*      */     }
/*  782 */     catch (IOException iOException) {
/*      */       
/*  784 */       ((T4CConnection)this.connection).handleIOException(iOException);
/*      */       
/*  786 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException);
/*  787 */       sQLException.fillInStackTrace();
/*  788 */       throw sQLException;
/*      */     
/*      */     }
/*      */     finally {
/*      */       
/*  793 */       this.rowsProcessed = this.t4Connection.all8.rowsProcessed;
/*  794 */       this.validRows = this.t4Connection.all8.getNumRows();
/*  795 */       if (this.connection.checksumMode.needToCalculateFetchChecksum()) {
/*  796 */         if (this.validRows > 0) {
/*  797 */           calculateCheckSum();
/*  798 */         } else if (this.rowsProcessed > 0) {
/*  799 */           long l = CRC64.updateChecksum(this.checkSum, this.rowsProcessed);
/*      */           
/*  801 */           this.checkSum = l;
/*      */         } 
/*      */       }
/*      */     } 
/*      */     
/*  806 */     this.needToParse = false;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  816 */     if (this.definedColumnType == null) {
/*  817 */       this.implicitDefineForLobPrefetchDone = false;
/*      */     }
/*  819 */     this.aFetchWasDoneDuringDescribe = false;
/*  820 */     if (this.t4Connection.all8.aFetchWasDone) {
/*      */       
/*  822 */       this.aFetchWasDoneDuringDescribe = true;
/*  823 */       this.rowPrefetchInLastFetch = this.rowPrefetch;
/*      */     } 
/*      */ 
/*      */     
/*  827 */     for (byte b = 0; b < this.numberOfDefinePositions; b++) {
/*  828 */       this.accessors[b].initMetadata();
/*      */     }
/*  830 */     this.needToPrepareDefineBuffer = false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void executeForRows(boolean paramBoolean) throws SQLException {
/*      */     try {
/*      */       try {
/*  872 */         boolean bool = false;
/*  873 */         if (this.columnsDefinedByUser) {
/*  874 */           this.needToPrepareDefineBuffer = false;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         }
/*  894 */         else if (this.t4Connection.useLobPrefetch && this.accessors != null && this.defaultLobPrefetchSize != -1 && !this.implicitDefineForLobPrefetchDone && !this.aFetchWasDoneDuringDescribe && this.definedColumnType == null) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  902 */           boolean bool1 = false;
/*  903 */           int[] arrayOfInt1 = new int[this.accessors.length];
/*  904 */           int[] arrayOfInt2 = new int[this.accessors.length];
/*  905 */           int[] arrayOfInt3 = new int[this.accessors.length];
/*      */           
/*  907 */           for (byte b = 0; b < this.accessors.length; b++) {
/*  908 */             if (this.accessors[b] != null) {
/*      */ 
/*      */ 
/*      */               
/*  912 */               arrayOfInt1[b] = getJDBCType((this.accessors[b]).internalType);
/*  913 */               arrayOfInt3[b] = (this.accessors[b]).formOfUse;
/*  914 */               if ((this.accessors[b]).internalType == 113 || (this.accessors[b]).internalType == 112 || (this.accessors[b]).internalType == 114) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */                 
/*  920 */                 bool1 = true;
/*      */                 
/*  922 */                 this.accessors[b].setPrefetchLength(this.defaultLobPrefetchSize);
/*  923 */                 arrayOfInt2[b] = this.defaultLobPrefetchSize;
/*      */               } 
/*      */             } 
/*      */           } 
/*  927 */           if (bool1) {
/*      */             
/*  929 */             this.definedColumnType = arrayOfInt1;
/*  930 */             this.definedColumnSize = arrayOfInt2;
/*  931 */             this.definedColumnFormOfUse = arrayOfInt3;
/*  932 */             bool = true;
/*      */           } 
/*      */         } 
/*      */ 
/*      */ 
/*      */         
/*  938 */         doOall8(this.needToParse, !paramBoolean, true, false, bool);
/*      */         
/*  940 */         this.needToParse = false;
/*  941 */         if (bool) {
/*  942 */           this.implicitDefineForLobPrefetchDone = true;
/*      */         }
/*      */       } finally {
/*      */         
/*  946 */         if (this.implicitResultSetStatements == null) {
/*  947 */           this.validRows = this.t4Connection.all8.getNumRows();
/*      */         } else {
/*  949 */           this.validRows = 0;
/*  950 */         }  calculateCheckSum();
/*      */       }
/*      */     
/*  953 */     } catch (SQLException sQLException) {
/*      */       
/*  955 */       throw sQLException;
/*      */     }
/*  957 */     catch (IOException iOException) {
/*      */       
/*  959 */       ((T4CConnection)this.connection).handleIOException(iOException);
/*      */       
/*  961 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException);
/*  962 */       sQLException.fillInStackTrace();
/*  963 */       throw sQLException;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void fetch(int paramInt, boolean paramBoolean) throws SQLException {
/*  989 */     if (this.rowData != null) {
/*  990 */       if (paramBoolean) {
/*      */         
/*  992 */         this.rowData.setPosition(this.rowData.length());
/*      */       } else {
/*  994 */         this.rowData.reset();
/*      */       } 
/*      */     }
/*      */     
/*  998 */     if (this.streamList != null)
/*      */     {
/* 1000 */       while (this.nextStream != null) {
/*      */         try {
/* 1002 */           this.nextStream.close();
/*      */         }
/* 1004 */         catch (IOException iOException) {
/* 1005 */           ((T4CConnection)this.connection).handleIOException(iOException);
/*      */           
/* 1007 */           SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException);
/* 1008 */           sQLException.fillInStackTrace();
/* 1009 */           throw sQLException;
/*      */         } 
/*      */         
/* 1012 */         this.nextStream = this.nextStream.nextStream;
/*      */       } 
/*      */     }
/*      */     
/*      */     try {
/* 1017 */       doOall8(false, false, true, false, false, paramInt);
/* 1018 */       this.validRows = this.t4Connection.all8.getNumRows();
/* 1019 */       if (this.validRows != -2) this.validRows -= paramInt; 
/* 1020 */       calculateCheckSum();
/*      */     }
/* 1022 */     catch (IOException iOException) {
/* 1023 */       ((T4CConnection)this.connection).handleIOException(iOException);
/*      */       
/* 1025 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException);
/* 1026 */       sQLException.fillInStackTrace();
/* 1027 */       throw sQLException;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void continueReadRow(int paramInt) throws SQLException {
/*      */     try {
/* 1046 */       if (!this.isFetchStreams)
/*      */       {
/* 1048 */         T4C8Oall t4C8Oall = this.t4Connection.all8;
/*      */         
/* 1050 */         t4C8Oall.continueReadRow(paramInt, this);
/*      */       }
/*      */     
/* 1053 */     } catch (IOException iOException) {
/*      */       
/* 1055 */       ((T4CConnection)this.connection).handleIOException(iOException);
/*      */       
/* 1057 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException);
/* 1058 */       sQLException.fillInStackTrace();
/* 1059 */       throw sQLException;
/*      */     
/*      */     }
/* 1062 */     catch (SQLException sQLException) {
/*      */       
/* 1064 */       if (sQLException.getErrorCode() == DatabaseError.getVendorCode(110)) {
/*      */ 
/*      */         
/* 1067 */         this.sqlWarning = DatabaseError.addSqlWarning(this.sqlWarning, 110);
/*      */       
/*      */       }
/*      */       else {
/*      */         
/* 1072 */         throw sQLException;
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void doClose() throws SQLException {
/* 1096 */     this.t4Connection.assertLoggedOn("oracle.jdbc.driver.T4CCallableStatement.do_close");
/* 1097 */     if (this.cursorId != 0)
/*      */     {
/* 1099 */       this.t4Connection.closeCursor(this.cursorId);
/*      */     }
/*      */     
/* 1102 */     this.tmpByteArray = null;
/* 1103 */     this.tmpBindsByteArray = null;
/* 1104 */     this.definedColumnType = null;
/* 1105 */     this.definedColumnSize = null;
/* 1106 */     this.definedColumnFormOfUse = null;
/* 1107 */     this.oacdefSent = null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void closeQuery() throws SQLException {
/* 1126 */     this.connection.registerHeartbeat();
/* 1127 */     this.connection.needLine();
/* 1128 */     this.t4Connection.assertLoggedOn("oracle.jdbc.driver.T4CCallableStatement.closeQuery");
/*      */     
/* 1130 */     if (this.streamList != null)
/*      */     {
/* 1132 */       while (this.nextStream != null) {
/*      */         try {
/* 1134 */           this.nextStream.close();
/*      */         }
/* 1136 */         catch (IOException iOException) {
/* 1137 */           ((T4CConnection)this.connection).handleIOException(iOException);
/*      */           
/* 1139 */           SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException);
/* 1140 */           sQLException.fillInStackTrace();
/* 1141 */           throw sQLException;
/*      */         } 
/*      */         
/* 1144 */         this.nextStream = this.nextStream.nextStream;
/*      */       } 
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   Binder getRowidNullBinder(int paramInt) {
/* 1155 */     if (this.sqlKind == OracleStatement.SqlKind.CALL_BLOCK) {
/*      */ 
/*      */       
/* 1158 */       this.currentRowCharLens[paramInt] = 1;
/* 1159 */       return this.theVarcharNullBinder;
/*      */     } 
/*      */     
/* 1162 */     return this.theRowidNullBinder;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   Accessor allocateIndexTableAccessor(PlsqlIbtBindInfo paramPlsqlIbtBindInfo, short paramShort) throws SQLException {
/* 1172 */     return new T4CPlsqlIndexTableAccessor(this, paramPlsqlIbtBindInfo, paramShort, this.t4Connection.mare);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void endOfResultSet(boolean paramBoolean) throws SQLException {
/* 1182 */     super.endOfResultSet(paramBoolean);
/* 1183 */     this.rowData.free();
/*      */   }
/*      */ 
/*      */ 
/*      */   
/* 1188 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*      */   public static final String BUILD_DATE = "Thu_Apr_04_15:09:24_PDT_2013";
/*      */   public static final boolean TRACE = false;
/*      */ }


/* Location:              C:\Users\olatu\OneDrive\Documents\Calypso\syncbase\sync_base.jar!\BOOT-INF\lib\ojdbc-7.jar!\oracle\jdbc\driver\T4CCallableStatement.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */