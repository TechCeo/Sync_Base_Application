/*     */ package oracle.jdbc.driver;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.sql.SQLException;
/*     */ import oracle.jdbc.internal.XSEvent;
/*     */ import oracle.jdbc.internal.XSKeyval;
/*     */ import oracle.jdbc.internal.XSNamespace;
/*     */ import oracle.jdbc.internal.XSPrincipal;
/*     */ import oracle.jdbc.internal.XSSessionNamespace;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class NTFXSEvent
/*     */   extends XSEvent
/*     */ {
/*     */   private final XSNamespaceI[] kpxssyncns;
/*     */   private final XSNamespaceI[] kpxssyncinvalidns;
/*     */   private final XSPrincipalI[] kpxssyncroles;
/*     */   private final XSSessionNamespaceI[] kpxssyncsessns;
/*     */   private final int kpxssyncrolever;
/*     */   private final int kpxssyncsessflg;
/*     */   private final int kpxssynccacheflg;
/*     */   private final XSKeyvalI kvl;
/*     */   
/*     */   public XSNamespace[] getNamespaces() {
/*  55 */     return (XSNamespace[])this.kpxssyncns;
/*     */   }
/*     */   
/*     */   public XSNamespace[] getInvalidNamespaces() {
/*  59 */     return (XSNamespace[])this.kpxssyncinvalidns;
/*     */   }
/*     */   
/*     */   public XSPrincipal[] getSessionRoles() {
/*  63 */     return (XSPrincipal[])this.kpxssyncroles;
/*     */   }
/*     */   
/*     */   public XSSessionNamespace[] getSessionNamespaces() {
/*  67 */     return (XSSessionNamespace[])this.kpxssyncsessns;
/*     */   }
/*     */   
/*     */   public int getRoleVersion() {
/*  71 */     return this.kpxssyncrolever;
/*     */   }
/*     */   
/*     */   public long getSessionFlags() {
/*  75 */     return this.kpxssyncsessflg;
/*     */   }
/*     */   
/*     */   public long getCacheFlags() {
/*  79 */     return this.kpxssynccacheflg;
/*     */   }
/*     */   
/*     */   public XSKeyval getKeyval() {
/*  83 */     return this.kvl;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   NTFXSEvent(T4CConnection paramT4CConnection) throws SQLException, IOException {
/*  89 */     super(paramT4CConnection);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 125 */     T4CMAREngine t4CMAREngine = paramT4CConnection.getMarshalEngine();
/* 126 */     int i = (int)t4CMAREngine.unmarshalUB4();
/* 127 */     if (i > 0)
/* 128 */       t4CMAREngine.unmarshalUB1(); 
/* 129 */     this.kpxssyncns = new XSNamespaceI[i]; int j;
/* 130 */     for (j = 0; j < i; j++)
/*     */     {
/* 132 */       this.kpxssyncns[j] = XSNamespaceI.unmarshal(t4CMAREngine);
/*     */     }
/*     */     
/* 135 */     j = (int)t4CMAREngine.unmarshalUB4();
/* 136 */     if (j > 0)
/* 137 */       t4CMAREngine.unmarshalUB1(); 
/* 138 */     this.kpxssyncinvalidns = new XSNamespaceI[j]; int k;
/* 139 */     for (k = 0; k < j; k++)
/*     */     {
/* 141 */       this.kpxssyncinvalidns[k] = XSNamespaceI.unmarshal(t4CMAREngine);
/*     */     }
/*     */ 
/*     */     
/* 145 */     k = (int)t4CMAREngine.unmarshalUB4();
/* 146 */     if (k > 0)
/* 147 */       t4CMAREngine.unmarshalUB1(); 
/* 148 */     this.kpxssyncroles = new XSPrincipalI[k]; int m;
/* 149 */     for (m = 0; m < k; m++)
/*     */     {
/* 151 */       this.kpxssyncroles[m] = XSPrincipalI.unmarshal(t4CMAREngine);
/*     */     }
/*     */ 
/*     */     
/* 155 */     m = (int)t4CMAREngine.unmarshalUB4();
/* 156 */     if (m > 0)
/* 157 */       t4CMAREngine.unmarshalUB1(); 
/* 158 */     this.kpxssyncsessns = new XSSessionNamespaceI[m]; short s;
/* 159 */     for (s = 0; s < m; s++) {
/*     */       
/* 161 */       t4CMAREngine.unmarshalUB1();
/* 162 */       t4CMAREngine.unmarshalUB1();
/* 163 */       t4CMAREngine.unmarshalUB1();
/* 164 */       this.kpxssyncsessns[s] = XSSessionNamespaceI.unmarshal(t4CMAREngine);
/*     */     } 
/*     */     
/* 167 */     this.kpxssyncrolever = (int)t4CMAREngine.unmarshalUB4();
/* 168 */     this.kpxssyncsessflg = (int)t4CMAREngine.unmarshalUB4();
/* 169 */     this.kpxssynccacheflg = (int)t4CMAREngine.unmarshalUB4();
/*     */     
/* 171 */     s = t4CMAREngine.unmarshalUB1();
/* 172 */     if (s != 0) {
/*     */       
/* 174 */       t4CMAREngine.unmarshalUB1();
/* 175 */       t4CMAREngine.unmarshalUB1();
/*     */       
/* 177 */       this.kvl = XSKeyvalI.unmarshal(t4CMAREngine);
/*     */     }
/*     */     else {
/*     */       
/* 181 */       this.kvl = null;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/* 186 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*     */   public static final String BUILD_DATE = "Thu_Apr_04_15:09:24_PDT_2013";
/*     */   public static final boolean TRACE = false;
/*     */ }


/* Location:              C:\Users\olatu\OneDrive\Documents\Calypso\syncbase\sync_base.jar!\BOOT-INF\lib\ojdbc-7.jar!\oracle\jdbc\driver\NTFXSEvent.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */