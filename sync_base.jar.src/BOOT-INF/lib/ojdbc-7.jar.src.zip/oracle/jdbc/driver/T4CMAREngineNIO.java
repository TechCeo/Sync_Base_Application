/*     */ package oracle.jdbc.driver;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.nio.ByteBuffer;
/*     */ import java.nio.ByteOrder;
/*     */ import java.sql.SQLException;
/*     */ import oracle.net.ns.BreakNetException;
/*     */ import oracle.net.ns.Communication;
/*     */ import oracle.net.ns.NIONSDataChannel;
/*     */ import oracle.net.ns.NetException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class T4CMAREngineNIO
/*     */   extends T4CMAREngine
/*     */ {
/*     */   NIONSDataChannel nsDataChannel;
/*     */   ByteBuffer dataBuffer;
/*     */   private boolean bytesReadyToGo = false;
/*     */   private boolean bufferReadyToWriteInto = false;
/*     */   int bytesWrittenSoFar;
/*     */   int bytesToWriteInNextCall;
/*     */   
/*     */   final void prepareForReading() throws IOException {
/*     */     try {
/*  92 */       if (this.bytesReadyToGo) {
/*     */         
/*  94 */         this.nsDataChannel.writeDataToSocketChannel();
/*  95 */         this.bytesReadyToGo = false;
/*  96 */         this.nsDataChannel.readDataFromSocketChannel();
/*     */       } 
/*     */       
/*  99 */       while (!this.dataBuffer.hasRemaining()) {
/* 100 */         this.nsDataChannel.readDataFromSocketChannel();
/*     */       }
/*     */       
/* 103 */       this.bufferReadyToWriteInto = false;
/*     */     }
/* 105 */     catch (BreakNetException breakNetException) {
/*     */ 
/*     */       
/* 108 */       this.net.sendReset();
/* 109 */       throw breakNetException;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   final void prepareForWriting() throws IOException {
/* 119 */     if (!this.bufferReadyToWriteInto) {
/*     */       
/* 121 */       this.dataBuffer.clear();
/* 122 */       this.dataBuffer.limit(this.dataBuffer.capacity());
/* 123 */       this.bufferReadyToWriteInto = true;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static void valueToUNV(long paramLong, byte[] paramArrayOfbyte) {
/* 130 */     paramArrayOfbyte[0] = 0;
/* 131 */     if (paramLong == 0L)
/*     */       return; 
/* 133 */     byte b1 = 0;
/* 134 */     boolean bool1 = true;
/* 135 */     boolean bool2 = (paramLong < 0L) ? true : false;
/* 136 */     long l = bool2 ? -paramLong : paramLong;
/* 137 */     for (byte b2 = 0; b2 < 8; b2++) {
/*     */ 
/*     */       
/* 140 */       byte b = (byte)(int)(l >>> 8 * (7 - b2) & 0xFFL);
/* 141 */       if (!bool1 || b != 0) {
/*     */         
/* 143 */         bool1 = false;
/* 144 */         paramArrayOfbyte[++b1] = b;
/*     */       } 
/*     */     } 
/* 147 */     paramArrayOfbyte[0] = (byte)b1;
/* 148 */     if (bool2) {
/* 149 */       paramArrayOfbyte[0] = (byte)(paramArrayOfbyte[0] | Byte.MIN_VALUE);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   final void marshalSB1(byte paramByte) throws IOException {
/* 172 */     prepareForWriting();
/*     */     
/* 174 */     if (this.dataBuffer.remaining() < 1)
/* 175 */       this.nsDataChannel.writeDataToSocketChannel(); 
/* 176 */     this.dataBuffer.put(paramByte);
/* 177 */     this.bytesReadyToGo = true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   final void marshalUB1(short paramShort) throws IOException {
/* 190 */     marshalSB1((byte)paramShort);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   final void marshalSB2(short paramShort) throws IOException {
/* 203 */     prepareForWriting();
/*     */     
/* 205 */     if (this.dataBuffer.remaining() < 3)
/* 206 */       this.nsDataChannel.writeDataToSocketChannel(); 
/* 207 */     if (this.types.rep[1] != 1) {
/*     */       
/* 209 */       this.dataBuffer.putShort(paramShort);
/*     */     
/*     */     }
/* 212 */     else if (paramShort == 0) {
/* 213 */       this.dataBuffer.put((byte)0);
/*     */     } else {
/*     */       
/* 216 */       boolean bool = (paramShort < 0) ? true : false;
/* 217 */       short s = (short)(bool ? -paramShort : paramShort);
/* 218 */       if (s <= 255) {
/*     */         
/* 220 */         if (bool) {
/* 221 */           this.dataBuffer.put((byte)-127);
/*     */         } else {
/* 223 */           this.dataBuffer.put((byte)1);
/* 224 */         }  this.dataBuffer.put((byte)s);
/*     */       
/*     */       }
/*     */       else {
/*     */         
/* 229 */         if (bool) {
/* 230 */           this.dataBuffer.put((byte)-126);
/*     */         } else {
/* 232 */           this.dataBuffer.put((byte)2);
/* 233 */         }  this.dataBuffer.putShort(s);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   final void marshalUB2(int paramInt) throws IOException {
/* 249 */     prepareForWriting();
/*     */     
/* 251 */     if (this.dataBuffer.remaining() < 3)
/* 252 */       this.nsDataChannel.writeDataToSocketChannel(); 
/* 253 */     if (this.types.rep[1] != 1) {
/*     */       
/* 255 */       this.dataBuffer.putShort((short)paramInt);
/*     */     
/*     */     }
/* 258 */     else if (paramInt == 0) {
/* 259 */       this.dataBuffer.put((byte)0);
/*     */     
/*     */     }
/* 262 */     else if (paramInt <= 255) {
/*     */ 
/*     */       
/* 265 */       this.dataBuffer.put((byte)1);
/* 266 */       this.dataBuffer.put((byte)paramInt);
/*     */     
/*     */     }
/*     */     else {
/*     */       
/* 271 */       this.dataBuffer.put((byte)2);
/* 272 */       this.dataBuffer.putShort((short)paramInt);
/*     */     } 
/*     */ 
/*     */     
/* 276 */     this.bytesReadyToGo = true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   final void marshalSB4(int paramInt) throws IOException {
/* 290 */     prepareForWriting();
/*     */     
/* 292 */     if (this.dataBuffer.remaining() < 5)
/* 293 */       this.nsDataChannel.writeDataToSocketChannel(); 
/* 294 */     if (this.types.rep[2] != 1) {
/*     */       
/* 296 */       this.dataBuffer.putInt(paramInt);
/*     */ 
/*     */     
/*     */     }
/* 300 */     else if (paramInt == 0) {
/* 301 */       this.dataBuffer.put((byte)0);
/*     */     } else {
/*     */       
/* 304 */       boolean bool = (paramInt < 0) ? true : false;
/* 305 */       int i = bool ? -paramInt : paramInt;
/* 306 */       if (i <= 255) {
/*     */ 
/*     */         
/* 309 */         if (!bool) {
/* 310 */           this.dataBuffer.put((byte)1);
/*     */         } else {
/* 312 */           this.dataBuffer.put((byte)-127);
/* 313 */         }  this.dataBuffer.put((byte)i);
/*     */       }
/* 315 */       else if (i <= 65535) {
/*     */ 
/*     */         
/* 318 */         if (!bool) {
/* 319 */           this.dataBuffer.put((byte)2);
/*     */         } else {
/* 321 */           this.dataBuffer.put((byte)-126);
/* 322 */         }  this.dataBuffer.putShort((short)i);
/*     */       }
/* 324 */       else if (i < 26) {
/*     */ 
/*     */         
/* 327 */         valueToUNV(paramInt, this.tmpBuffer10);
/* 328 */         this.dataBuffer.put(this.tmpBuffer10, 0, this.tmpBuffer10[0] + 1);
/*     */       
/*     */       }
/*     */       else {
/*     */         
/* 333 */         if (!bool) {
/* 334 */           this.dataBuffer.put((byte)4);
/*     */         } else {
/* 336 */           this.dataBuffer.put((byte)-124);
/* 337 */         }  this.dataBuffer.putInt(i);
/*     */       } 
/*     */     } 
/*     */     
/* 341 */     this.bytesReadyToGo = true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   final void marshalUB4(long paramLong) throws IOException {
/* 354 */     prepareForWriting();
/*     */     
/* 356 */     if (this.dataBuffer.remaining() < 5)
/* 357 */       this.nsDataChannel.writeDataToSocketChannel(); 
/* 358 */     if (this.types.rep[2] != 1) {
/*     */       
/* 360 */       this.dataBuffer.putInt((int)paramLong);
/*     */ 
/*     */     
/*     */     }
/* 364 */     else if (paramLong == 0L) {
/* 365 */       this.dataBuffer.put((byte)0);
/* 366 */     } else if (paramLong <= 255L) {
/*     */       
/* 368 */       this.dataBuffer.put((byte)1);
/* 369 */       this.dataBuffer.put((byte)(int)paramLong);
/*     */     }
/* 371 */     else if (paramLong <= 65535L) {
/*     */       
/* 373 */       this.dataBuffer.put((byte)2);
/* 374 */       this.dataBuffer.putShort((short)(int)paramLong);
/*     */     }
/* 376 */     else if (paramLong <= 16777215L) {
/*     */ 
/*     */       
/* 379 */       valueToUNV(paramLong, this.tmpBuffer10);
/* 380 */       this.dataBuffer.put(this.tmpBuffer10, 0, this.tmpBuffer10[0] + 1);
/*     */     
/*     */     }
/*     */     else {
/*     */       
/* 385 */       this.dataBuffer.put((byte)4);
/* 386 */       this.dataBuffer.putInt((int)paramLong);
/*     */     } 
/*     */     
/* 389 */     this.bytesReadyToGo = true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   final void marshalSB8(long paramLong) throws IOException {
/* 402 */     prepareForWriting();
/*     */     
/* 404 */     if (this.dataBuffer.remaining() < 9)
/* 405 */       this.nsDataChannel.writeDataToSocketChannel(); 
/* 406 */     if (this.types.rep[3] != 1)
/* 407 */       throw new IOException("TODO: SB8 in UNV representation only"); 
/* 408 */     valueToUNV(paramLong, this.tmpBuffer10);
/* 409 */     this.dataBuffer.put(this.tmpBuffer10, 0, this.tmpBuffer10[0] + 1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   final void marshalUB8(long paramLong) throws IOException {
/* 421 */     prepareForWriting();
/*     */     
/* 423 */     if (this.dataBuffer.remaining() < 9)
/* 424 */       this.nsDataChannel.writeDataToSocketChannel(); 
/* 425 */     if (paramLong == 0L)
/* 426 */       this.dataBuffer.put((byte)0); 
/* 427 */     if (this.types.rep[3] != 1) {
/* 428 */       throw new IOException("TODO: UB8 in UNV representation only");
/*     */     }
/* 430 */     this.tmpBuffer10[0] = 0;
/* 431 */     byte b1 = 0;
/* 432 */     for (byte b2 = 0; b2 < 8; b2++) {
/*     */ 
/*     */       
/* 435 */       byte b = (byte)(int)(paramLong >>> 8 * (7 - b2) & 0xFFL);
/* 436 */       if (b != 0)
/*     */       {
/*     */         
/* 439 */         this.tmpBuffer10[++b1] = b; } 
/*     */     } 
/* 441 */     this.tmpBuffer10[0] = (byte)b1;
/* 442 */     this.dataBuffer.put(this.tmpBuffer10, 0, this.tmpBuffer10[0] + 1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   final void marshalB1Array(byte[] paramArrayOfbyte) throws IOException {
/* 453 */     marshalB1Array(paramArrayOfbyte, 0, paramArrayOfbyte.length);
/*     */   }
/*     */   
/* 456 */   T4CMAREngineNIO(Communication paramCommunication) throws SQLException, IOException { this.bytesWrittenSoFar = 0; this.bytesToWriteInNextCall = 0;
/*     */     if (paramCommunication == null) {
/*     */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 433);
/*     */       sQLException.fillInStackTrace();
/*     */       throw sQLException;
/*     */     } 
/*     */     this.net = paramCommunication;
/*     */     this.nsDataChannel = (paramCommunication.getSessionAttributes()).dataChannel;
/*     */     this.dataBuffer = (paramCommunication.getSessionAttributes()).payloadDataBuffer;
/*     */     this.types = new T4CTypeRep(this, true);
/*     */     this.types.setRep((byte)1, (byte)2);
/*     */     this.dataBuffer.order(ByteOrder.LITTLE_ENDIAN); } final void marshalB1Array(byte[] paramArrayOfbyte, int paramInt1, int paramInt2) throws IOException {
/* 468 */     prepareForWriting();
/* 469 */     this.bytesWrittenSoFar = 0;
/* 470 */     this.bytesToWriteInNextCall = 0;
/*     */     
/* 472 */     while (this.bytesWrittenSoFar < paramInt2) {
/*     */       
/* 474 */       if (this.dataBuffer.remaining() == 0)
/* 475 */         this.nsDataChannel.writeDataToSocketChannel(); 
/* 476 */       this.bytesToWriteInNextCall = Math.min(this.dataBuffer.remaining(), paramInt2 - this.bytesWrittenSoFar);
/* 477 */       this.dataBuffer.put(paramArrayOfbyte, paramInt1 + this.bytesWrittenSoFar, this.bytesToWriteInNextCall);
/* 478 */       this.bytesWrittenSoFar += this.bytesToWriteInNextCall;
/*     */     } 
/* 480 */     this.bytesReadyToGo = true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   final byte unmarshalSB1() throws SQLException, IOException {
/* 505 */     return (byte)unmarshalSB2();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   final short unmarshalUB1() throws SQLException, IOException {
/* 522 */     prepareForReading();
/* 523 */     return (short)(this.dataBuffer.get() & 0xFF);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   final short unmarshalSB2() throws SQLException, IOException {
/* 540 */     prepareForReading();
/* 541 */     if (this.types.rep[1] != 1 && this.dataBuffer.remaining() >= 2)
/*     */     {
/*     */       
/* 544 */       return this.dataBuffer.getShort();
/*     */     }
/*     */     
/* 547 */     return (short)unmarshalUB2();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   final int unmarshalUB2() throws SQLException, IOException {
/* 569 */     int i = (int)buffer2Value((byte)1);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 577 */     return i & 0xFFFF;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   final int unmarshalSB4() throws SQLException, IOException {
/* 592 */     prepareForReading();
/* 593 */     if (this.types.rep[1] != 1 && this.dataBuffer.remaining() >= 4)
/*     */     {
/*     */       
/* 596 */       return this.dataBuffer.getInt();
/*     */     }
/*     */     
/* 599 */     return (int)buffer2Value((byte)2);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   final long unmarshalUB4() throws SQLException, IOException {
/* 615 */     return unmarshalSB4() & 0xFFFFFFFFL;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   byte[] unmarshalNBytes(int paramInt) throws SQLException, IOException {
/* 632 */     byte[] arrayOfByte = new byte[paramInt];
/* 633 */     getNBytes(arrayOfByte, 0, paramInt);
/* 634 */     return arrayOfByte;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   int unmarshalNBytes(byte[] paramArrayOfbyte, int paramInt1, int paramInt2) throws SQLException, IOException {
/* 651 */     return getNBytes(paramArrayOfbyte, paramInt1, paramInt2);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   int getNBytes(byte[] paramArrayOfbyte, int paramInt1, int paramInt2) throws SQLException, IOException {
/* 670 */     if (paramInt1 + paramInt2 > paramArrayOfbyte.length)
/*     */     {
/* 672 */       paramInt2 = paramArrayOfbyte.length - paramInt1;
/*     */     }
/*     */     
/* 675 */     boolean bool = false;
/* 676 */     prepareForReading();
/* 677 */     int i = 0;
/* 678 */     while (i < paramInt2) {
/*     */       
/* 680 */       if (!this.dataBuffer.hasRemaining())
/* 681 */         prepareForReading(); 
/* 682 */       int j = this.dataBuffer.position();
/* 683 */       this.dataBuffer.get(paramArrayOfbyte, paramInt1 + i, Math.min(paramInt2 - i, this.dataBuffer.remaining()));
/* 684 */       i += this.dataBuffer.position() - j;
/*     */     } 
/* 686 */     return i;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   byte[] getNBytes(int paramInt) throws SQLException, IOException {
/* 702 */     return unmarshalNBytes(paramInt);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   byte[] unmarshalTEXT(int paramInt) throws SQLException, IOException {
/*     */     byte[] arrayOfByte2;
/* 720 */     byte b = 0;
/*     */ 
/*     */ 
/*     */     
/* 724 */     byte[] arrayOfByte1 = new byte[paramInt];
/*     */ 
/*     */     
/* 727 */     while (b < paramInt) {
/*     */       
/* 729 */       prepareForReading();
/* 730 */       arrayOfByte1[b] = this.dataBuffer.get();
/*     */       
/* 732 */       if (arrayOfByte1[b++] == 0) {
/*     */         break;
/*     */       }
/*     */     } 
/*     */     
/* 737 */     if (arrayOfByte1.length == --b) {
/*     */       
/* 739 */       arrayOfByte2 = arrayOfByte1;
/*     */     }
/*     */     else {
/*     */       
/* 743 */       arrayOfByte2 = new byte[b];
/*     */       
/* 745 */       System.arraycopy(arrayOfByte1, 0, arrayOfByte2, 0, b);
/*     */     } 
/*     */     
/* 748 */     return arrayOfByte2;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   final long buffer2Value(byte paramByte) throws SQLException, IOException {
/* 767 */     long l = 0L;
/* 768 */     byte b = this.types.rep[paramByte];
/* 769 */     int i = 0;
/* 770 */     boolean bool = false;
/* 771 */     if (b == 1) {
/*     */ 
/*     */       
/* 774 */       prepareForReading();
/* 775 */       i = this.dataBuffer.get();
/* 776 */       if (i == 0)
/* 777 */         return 0L; 
/* 778 */       if ((i & 0x80) > 0)
/*     */       {
/* 780 */         i &= 0x7F;
/* 781 */         bool = true;
/*     */       }
/*     */     
/*     */     } else {
/*     */       
/* 786 */       switch (paramByte) {
/*     */         
/*     */         case 1:
/* 789 */           i = 2;
/*     */           break;
/*     */         case 2:
/* 792 */           i = 4;
/*     */           break;
/*     */         case 3:
/* 795 */           i = 8;
/*     */           break;
/*     */       } 
/*     */     } 
/* 799 */     if (this.dataBuffer.remaining() >= i && (i == 1 || i == 2 || i == 4 || i == 8)) {
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 804 */       prepareForReading();
/* 805 */       if (i == 1) {
/* 806 */         l = this.dataBuffer.get() & 0xFFL;
/* 807 */       } else if (i == 2) {
/* 808 */         l = this.dataBuffer.getShort() & 0xFFFFL;
/* 809 */       } else if (i == 4) {
/* 810 */         l = this.dataBuffer.getInt() & 0xFFFFFFFFFFFFFFFFL;
/*     */       } else {
/* 812 */         l = this.dataBuffer.getLong();
/*     */       }
/*     */     
/*     */     } else {
/*     */       
/* 817 */       unmarshalNBytes(this.tmpBuffer8, 0, i);
/* 818 */       for (byte b1 = 0; b1 < i; b1++) {
/*     */         
/* 820 */         if (b == 1 || b != 2) {
/* 821 */           l |= (this.tmpBuffer8[b1] & 0xFFL) << 8 * (i - b1 - 1);
/*     */         } else {
/* 823 */           l |= (this.tmpBuffer8[b1] & 0xFFL) << 8 * b1;
/*     */         } 
/*     */       } 
/* 826 */     }  if (bool)
/* 827 */       l *= -1L; 
/* 828 */     return l;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   void setByteOrder(byte paramByte) {
/* 834 */     if (paramByte == 2) {
/* 835 */       this.dataBuffer.order(ByteOrder.LITTLE_ENDIAN);
/*     */     } else {
/* 837 */       this.dataBuffer.order(ByteOrder.BIG_ENDIAN);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   protected void flush() throws IOException {
/* 843 */     this.nsDataChannel.writeDataToSocketChannel();
/* 844 */     this.bytesReadyToGo = false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void writeZeroCopyIO(byte[] paramArrayOfbyte, int paramInt1, int paramInt2) throws IOException, NetException {
/* 852 */     this.net.writeZeroCopyIO(paramArrayOfbyte, paramInt1, paramInt2);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/* 857 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*     */   public static final String BUILD_DATE = "Thu_Apr_04_15:09:24_PDT_2013";
/*     */   public static final boolean TRACE = false;
/*     */ }


/* Location:              C:\Users\olatu\OneDrive\Documents\Calypso\syncbase\sync_base.jar!\BOOT-INF\lib\ojdbc-7.jar!\oracle\jdbc\driver\T4CMAREngineNIO.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */