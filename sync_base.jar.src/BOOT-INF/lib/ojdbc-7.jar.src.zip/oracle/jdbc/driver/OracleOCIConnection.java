/*     */ package oracle.jdbc.driver;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.sql.SQLException;
/*     */ import java.util.Properties;
/*     */ import oracle.jdbc.pool.OracleOCIConnectionPool;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class OracleOCIConnection
/*     */   extends T2CConnection
/*     */ {
/*  29 */   OracleOCIConnectionPool ociConnectionPool = null;
/*     */ 
/*     */ 
/*     */   
/*     */   boolean isPool = false;
/*     */ 
/*     */ 
/*     */   
/*     */   boolean aliasing = false;
/*     */ 
/*     */ 
/*     */   
/*     */   public OracleOCIConnection(String paramString, Properties paramProperties, Object paramObject) throws SQLException {
/*  42 */     this(paramString, paramProperties, (OracleDriverExtension)paramObject);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   OracleOCIConnection(String paramString, Properties paramProperties, OracleDriverExtension paramOracleDriverExtension) throws SQLException {
/*  58 */     super(paramString, paramProperties, paramOracleDriverExtension);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized byte[] getConnectionId() throws SQLException {
/*  70 */     byte[] arrayOfByte = t2cGetConnectionId(this.m_nativeState);
/*     */     
/*  72 */     if (arrayOfByte == null) {
/*     */       
/*  74 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 254, "Cannot create a ByteArray for the connectionId");
/*  75 */       sQLException.fillInStackTrace();
/*  76 */       throw sQLException;
/*     */     } 
/*     */     
/*  79 */     this.aliasing = true;
/*     */     
/*  81 */     return arrayOfByte;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized void passwordChange(String paramString1, String paramString2, String paramString3) throws SQLException, IOException {
/* 100 */     ociPasswordChange(paramString1, paramString2, paramString3);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized void close() throws SQLException {
/* 113 */     if (this.lifecycle == 2 || this.lifecycle == 4 || this.aliasing) {
/*     */       return;
/*     */     }
/* 116 */     super.close();
/*     */     
/* 118 */     this.ociConnectionPool.connectionClosed((oracle.jdbc.oci.OracleOCIConnection)this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized void setConnectionPool(OracleOCIConnectionPool paramOracleOCIConnectionPool) {
/* 128 */     this.ociConnectionPool = paramOracleOCIConnectionPool;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized void setStmtCacheSize(int paramInt, boolean paramBoolean) throws SQLException {
/* 144 */     super.setStmtCacheSize(paramInt, paramBoolean);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/* 149 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*     */   public static final String BUILD_DATE = "Thu_Apr_04_15:09:24_PDT_2013";
/*     */   public static final boolean TRACE = false;
/*     */ }


/* Location:              C:\Users\olatu\OneDrive\Documents\Calypso\syncbase\sync_base.jar!\BOOT-INF\lib\ojdbc-7.jar!\oracle\jdbc\driver\OracleOCIConnection.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */