/*    */ package oracle.jdbc.driver;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.sql.SQLException;
/*    */ import oracle.jdbc.internal.ReplayContext;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class T4CTTIoappcontreplay
/*    */   extends T4CTTIfun
/*    */ {
/*    */   private byte[] replayCtxts_kpdxcAppContReplay;
/*    */   private int flags_kpdxcAppContReplay;
/*    */   
/*    */   T4CTTIoappcontreplay(T4CConnection paramT4CConnection) {
/* 59 */     super(paramT4CConnection, (byte)17);
/*    */     
/* 61 */     setFunCode((short)177);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   void doOAPPCONTREPLAY(ReplayContext paramReplayContext) throws IOException, SQLException {
/* 71 */     this.replayCtxts_kpdxcAppContReplay = paramReplayContext.getContext();
/* 72 */     this.flags_kpdxcAppContReplay = 0;
/* 73 */     doPigRPC();
/*    */   }
/*    */ 
/*    */   
/*    */   void marshal() throws IOException {
/* 78 */     this.meg.marshalPTR();
/* 79 */     this.meg.marshalUB4(1L);
/* 80 */     this.meg.marshalUB4(this.flags_kpdxcAppContReplay);
/*    */     
/* 82 */     this.meg.marshalUB4(this.replayCtxts_kpdxcAppContReplay.length);
/* 83 */     this.meg.marshalCLR(this.replayCtxts_kpdxcAppContReplay, 0, this.replayCtxts_kpdxcAppContReplay.length);
/*    */   }
/*    */ }


/* Location:              C:\Users\olatu\OneDrive\Documents\Calypso\syncbase\sync_base.jar!\BOOT-INF\lib\ojdbc-7.jar!\oracle\jdbc\driver\T4CTTIoappcontreplay.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */