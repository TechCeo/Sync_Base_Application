/*      */ package oracle.jdbc.driver;
/*      */ 
/*      */ import java.io.InputStream;
/*      */ import java.io.Reader;
/*      */ import java.sql.Blob;
/*      */ import java.sql.Clob;
/*      */ import java.sql.PreparedStatement;
/*      */ import java.sql.ResultSetMetaData;
/*      */ import java.sql.SQLException;
/*      */ import java.sql.SQLWarning;
/*      */ import java.sql.Statement;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Iterator;
/*      */ import oracle.jdbc.OracleResultSet;
/*      */ import oracle.sql.BLOB;
/*      */ import oracle.sql.CLOB;
/*      */ import oracle.sql.Datum;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ class UpdatableResultSet
/*      */   extends GeneratedUpdatableResultSet
/*      */ {
/*      */   static final int concurrencyType = 1008;
/*      */   static final int BEGIN_COLUMN_INDEX = 0;
/*      */   private int wasNull;
/*   59 */   private static int _MIN_STREAM_SIZE = 4000; OracleResultSet resultSet; boolean isCachedRset; OracleStatement scrollStmt; ResultSetMetaData rsetMetaData; private int columnCount; private OraclePreparedStatement deleteStmt; private OraclePreparedStatement insertStmt; private OraclePreparedStatement updateStmt; private int[] indexColsChanged; private Object[] rowBuffer; private boolean[] m_nullIndicator; private int[][] typeInfo; private boolean isInserting; private boolean isUpdating; ArrayList tempClobsToFree; ArrayList tempBlobsToFree; void ensureOpen() throws SQLException { if (this.closed) {
/*      */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 10); sQLException.fillInStackTrace(); throw sQLException;
/*      */     }  if (this.resultSet == null || this.scrollStmt == null || this.scrollStmt.closed) {
/*      */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9); sQLException.fillInStackTrace(); throw sQLException;
/*      */     }  }
/*      */   public void close() throws SQLException { if (this.closed)
/*      */       return;  synchronized (this.connection) {
/*      */       super.close(); if (this.resultSet != null)
/*      */         this.resultSet.close();  if (this.insertStmt != null)
/*      */         this.insertStmt.close();  if (this.updateStmt != null)
/*      */         this.updateStmt.close();  if (this.deleteStmt != null)
/*      */         this.deleteStmt.close();  if (this.scrollStmt != null)
/*      */         this.scrollStmt.notifyCloseRset();  cancelRowInserts(); this.connection = LogicalConnection.closedConnection; this.resultSet = null; this.scrollStmt = null; this.rsetMetaData = null; this.scrollStmt = null; this.deleteStmt = null; this.insertStmt = null; this.updateStmt = null; this.indexColsChanged = null; this.rowBuffer = null; this.m_nullIndicator = null; this.typeInfo = (int[][])null;
/*      */     }  }
/*      */   public boolean wasNull() throws SQLException { synchronized (this.connection) {
/*      */       ensureOpen(); switch (this.wasNull) {
/*      */         case 1:
/*      */           return true;
/*      */         case 2:
/*      */           return false;
/*      */         case 4:
/*      */           return this.resultSet.wasNull();
/*      */       }  SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 24); sQLException.fillInStackTrace(); throw sQLException;
/*      */     }  }
/*      */   public Statement getStatement() throws SQLException { synchronized (this.connection) {
/*      */       ensureOpen();
/*      */       return (Statement)this.scrollStmt;
/*      */     }  }
/*      */   public SQLWarning getWarnings() throws SQLException { synchronized (this.connection) {
/*      */       ensureOpen();
/*      */       SQLWarning sQLWarning1 = this.resultSet.getWarnings();
/*      */       if (this.sqlWarning == null)
/*      */         return sQLWarning1; 
/*      */       SQLWarning sQLWarning2 = this.sqlWarning;
/*      */       while (sQLWarning2.getNextWarning() != null)
/*      */         sQLWarning2 = sQLWarning2.getNextWarning(); 
/*      */       sQLWarning2.setNextWarning(sQLWarning1);
/*      */       return this.sqlWarning;
/*      */     }  }
/*   98 */   UpdatableResultSet(OracleStatement paramOracleStatement, OracleResultSet paramOracleResultSet) throws SQLException { super(paramOracleStatement, paramOracleResultSet);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  550 */     this.tempClobsToFree = null;
/*  551 */     this.tempBlobsToFree = null; this.resultSet = paramOracleResultSet; this.scrollStmt = paramOracleStatement; this.deleteStmt = null; this.insertStmt = null; this.updateStmt = null; this.indexColsChanged = null; this.rowBuffer = null; this.m_nullIndicator = null; this.typeInfo = (int[][])null; this.isInserting = false; this.isUpdating = false; this.wasNull = -1; this.rsetMetaData = null; this.columnCount = 0; getInternalMetadata(); this.isCachedRset = true; }
/*      */   public void clearWarnings() throws SQLException { synchronized (this.connection) { ensureOpen(); this.sqlWarning = null; this.resultSet.clearWarnings(); }
/*      */      }
/*      */   public OracleResultSet.AuthorizationIndicator getAuthorizationIndicator(int paramInt) throws SQLException { synchronized (this.connection) { ensureOpen(); if (this.isRowDeleted) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 82); sQLException.fillInStackTrace(); throw sQLException; }
/*      */        return this.resultSet.getAuthorizationIndicator(paramInt); }
/*  556 */      } void addToTempLobsToFree(Clob paramClob) { if (this.tempClobsToFree == null)
/*  557 */       this.tempClobsToFree = new ArrayList(); 
/*  558 */     this.tempClobsToFree.add(paramClob); }
/*      */   public boolean next() throws SQLException { synchronized (this.connection) { ensureOpen(); cancelRowChanges(); if (this.isRowDeleted) { this.isRowDeleted = false; return this.resultSet.isValidRow(); }  return this.resultSet.next(); }  }
/*      */   public boolean isBeforeFirst() throws SQLException { synchronized (this.connection) { ensureOpen(); if (this.isRowDeleted) return this.resultSet.isFirst();  return this.resultSet.isBeforeFirst(); }  }
/*      */   public boolean isAfterLast() throws SQLException { synchronized (this.connection) { ensureOpen(); return this.resultSet.isAfterLast(); }  }
/*      */   public boolean isFirst() throws SQLException { synchronized (this.connection) { ensureOpen(); if (this.isRowDeleted) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 82); sQLException.fillInStackTrace(); throw sQLException; }  return this.resultSet.isFirst(); }  }
/*      */   public boolean isLast() throws SQLException { synchronized (this.connection) { ensureOpen(); if (this.isRowDeleted) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 82); sQLException.fillInStackTrace(); throw sQLException; }  return this.resultSet.isLast(); }  }
/*      */   public void beforeFirst() throws SQLException { synchronized (this.connection) { ensureOpen(); cancelRowChanges(); this.isRowDeleted = false; this.resultSet.beforeFirst(); }  }
/*  565 */   public void afterLast() throws SQLException { synchronized (this.connection) { ensureOpen(); cancelRowChanges(); this.isRowDeleted = false; this.resultSet.afterLast(); }  } public boolean first() throws SQLException { synchronized (this.connection) { ensureOpen(); cancelRowChanges(); this.isRowDeleted = false; return this.resultSet.first(); }  } void addToTempLobsToFree(Blob paramBlob) { if (this.tempBlobsToFree == null)
/*  566 */       this.tempBlobsToFree = new ArrayList(); 
/*  567 */     this.tempBlobsToFree.add(paramBlob); } public boolean last() throws SQLException { synchronized (this.connection) { ensureOpen(); cancelRowChanges(); this.isRowDeleted = false; return this.resultSet.last(); }  }
/*      */   public int getRow() throws SQLException { synchronized (this.connection) { ensureOpen(); if (this.isRowDeleted) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 82); sQLException.fillInStackTrace(); throw sQLException; }  return this.resultSet.getRow(); }  }
/*      */   public boolean absolute(int paramInt) throws SQLException { synchronized (this.connection) { ensureOpen(); cancelRowChanges(); this.isRowDeleted = false; return this.resultSet.absolute(paramInt); }  }
/*      */   public boolean relative(int paramInt) throws SQLException { synchronized (this.connection) { ensureOpen(); cancelRowChanges(); if (this.isRowDeleted) { paramInt--; this.isRowDeleted = false; }  return this.resultSet.relative(paramInt); }
/*      */      }
/*      */   public boolean previous() throws SQLException { synchronized (this.connection) { ensureOpen(); cancelRowChanges(); this.isRowDeleted = false; return this.resultSet.previous(); }
/*      */      }
/*  574 */   void cleanTempLobs() { cleanTempClobs(this.tempClobsToFree);
/*  575 */     cleanTempBlobs(this.tempBlobsToFree);
/*  576 */     this.tempClobsToFree = null;
/*  577 */     this.tempBlobsToFree = null; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void cleanTempBlobs(ArrayList paramArrayList) {
/*  584 */     if (paramArrayList != null) {
/*      */       
/*  586 */       Iterator<BLOB> iterator = paramArrayList.iterator();
/*      */       
/*  588 */       while (iterator.hasNext()) {
/*      */ 
/*      */         
/*      */         try {
/*  592 */           ((BLOB)iterator.next()).freeTemporary();
/*      */         }
/*  594 */         catch (SQLException sQLException) {}
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void cleanTempClobs(ArrayList paramArrayList) {
/*  606 */     if (paramArrayList != null) {
/*      */       
/*  608 */       Iterator<CLOB> iterator = paramArrayList.iterator();
/*      */       
/*  610 */       while (iterator.hasNext()) {
/*      */ 
/*      */         
/*      */         try {
/*  614 */           ((CLOB)iterator.next()).freeTemporary();
/*      */         }
/*  616 */         catch (SQLException sQLException) {}
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ResultSetMetaData getMetaData() throws SQLException {
/*  636 */     return this.resultSet.getMetaData();
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public int findColumn(String paramString) throws SQLException {
/*  642 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  649 */       ensureOpen();
/*  650 */       return this.resultSet.findColumn(paramString);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setFetchDirection(int paramInt) throws SQLException {
/*  661 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  668 */       ensureOpen();
/*  669 */       this.resultSet.setFetchDirection(paramInt);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public int getFetchDirection() throws SQLException {
/*  676 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  683 */       ensureOpen();
/*  684 */       return this.resultSet.getFetchDirection();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void setFetchSize(int paramInt) throws SQLException {
/*  691 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  698 */       ensureOpen();
/*  699 */       this.resultSet.setFetchSize(paramInt);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public int getFetchSize() throws SQLException {
/*  706 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  713 */       ensureOpen();
/*  714 */       return this.resultSet.getFetchSize();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getType() throws SQLException {
/*  727 */     ensureOpen();
/*  728 */     return this.scrollStmt.realRsetType.getType();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getConcurrency() throws SQLException {
/*  740 */     ensureOpen();
/*  741 */     return 1008;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public String getCursorName() throws SQLException {
/*  747 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  755 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 23, "getCursorName");
/*  756 */       sQLException.fillInStackTrace();
/*  757 */       throw sQLException;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean rowUpdated() throws SQLException {
/*  775 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean rowInserted() throws SQLException {
/*  787 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean rowDeleted() throws SQLException {
/*  799 */     return this.isRowDeleted;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void insertRow() throws SQLException {
/*  805 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  812 */       ensureOpen();
/*  813 */       if (this.isRowDeleted) {
/*  814 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 82);
/*  815 */         sQLException.fillInStackTrace();
/*  816 */         throw sQLException;
/*      */       } 
/*  818 */       if (!isOnInsertRow()) {
/*      */         
/*  820 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 83);
/*  821 */         sQLException.fillInStackTrace();
/*  822 */         throw sQLException;
/*      */       } 
/*      */       
/*  825 */       prepareInsertRowStatement();
/*  826 */       prepareInsertRowBinds();
/*  827 */       executeInsertRow();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateRow() throws SQLException {
/*  834 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  841 */       ensureOpen();
/*  842 */       if (this.isRowDeleted) {
/*  843 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 82);
/*  844 */         sQLException.fillInStackTrace();
/*  845 */         throw sQLException;
/*      */       } 
/*      */ 
/*      */       
/*  849 */       if (isOnInsertRow()) {
/*      */         
/*  851 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 84);
/*  852 */         sQLException.fillInStackTrace();
/*  853 */         throw sQLException;
/*      */       } 
/*      */       
/*  856 */       int i = getNumColumnsChanged();
/*      */       
/*  858 */       if (i > 0) {
/*      */         
/*  860 */         prepareUpdateRowStatement(i);
/*  861 */         prepareUpdateRowBinds(i);
/*  862 */         executeUpdateRow();
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void deleteRow() throws SQLException {
/*  870 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  877 */       ensureOpen();
/*      */       
/*  879 */       if (this.isRowDeleted) {
/*  880 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 82);
/*  881 */         sQLException.fillInStackTrace();
/*  882 */         throw sQLException;
/*      */       } 
/*      */       
/*  885 */       if (isOnInsertRow()) {
/*      */         
/*  887 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 84);
/*  888 */         sQLException.fillInStackTrace();
/*  889 */         throw sQLException;
/*      */       } 
/*      */       
/*  892 */       prepareDeleteRowStatement();
/*  893 */       prepareDeleteRowBinds();
/*  894 */       executeDeleteRow();
/*  895 */       this.isRowDeleted = true;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void refreshRow() throws SQLException {
/*  902 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  909 */       ensureOpen();
/*  910 */       if (this.isRowDeleted) {
/*  911 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 82);
/*  912 */         sQLException.fillInStackTrace();
/*  913 */         throw sQLException;
/*      */       } 
/*      */       
/*  916 */       if (isOnInsertRow()) {
/*      */         
/*  918 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 84);
/*  919 */         sQLException.fillInStackTrace();
/*  920 */         throw sQLException;
/*      */       } 
/*      */       
/*  923 */       this.resultSet.refreshRow();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void cancelRowUpdates() throws SQLException {
/*  930 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  937 */       ensureOpen();
/*  938 */       if (this.isUpdating) {
/*      */         
/*  940 */         this.isUpdating = false;
/*      */         
/*  942 */         clearRowBuffer();
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void moveToInsertRow() throws SQLException {
/*  950 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  957 */       ensureOpen();
/*  958 */       if (isOnInsertRow())
/*      */         return; 
/*  960 */       this.isRowDeleted = false;
/*  961 */       this.isInserting = true;
/*      */ 
/*      */       
/*  964 */       if (this.rowBuffer == null) {
/*  965 */         this.rowBuffer = new Object[getColumnCount()];
/*      */       }
/*  967 */       if (this.m_nullIndicator == null) {
/*  968 */         this.m_nullIndicator = new boolean[getColumnCount()];
/*      */       }
/*  970 */       clearRowBuffer();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void moveToCurrentRow() throws SQLException {
/*  977 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  984 */       ensureOpen();
/*  985 */       if (this.isRowDeleted) {
/*  986 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 82);
/*  987 */         sQLException.fillInStackTrace();
/*  988 */         throw sQLException;
/*      */       } 
/*  990 */       cancelRowInserts();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <T> T getObject(int paramInt, Class<T> paramClass) throws SQLException {
/* 1005 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1012 */       assert paramClass != null : "type: null";
/* 1013 */       ensureOpen();
/* 1014 */       if (this.isRowDeleted) {
/* 1015 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 82);
/* 1016 */         sQLException.fillInStackTrace();
/* 1017 */         throw sQLException;
/*      */       } 
/* 1019 */       Object object = null;
/* 1020 */       setIsNull(3);
/* 1021 */       if (isOnInsertRow() || (isUpdatingRow() && isRowBufferUpdatedAt(paramInt))) {
/*      */         
/* 1023 */         Datum datum = getRowBufferDatumAt(paramInt);
/* 1024 */         setIsNull((datum == null));
/* 1025 */         if (datum != null) {
/* 1026 */           object = datum.toClass(paramClass);
/*      */         }
/*      */       } else {
/* 1029 */         setIsNull(4);
/* 1030 */         object = this.resultSet.getObject(paramInt, paramClass);
/*      */       } 
/* 1032 */       return (T)object;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateNull(int paramInt) throws SQLException {
/* 1042 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1049 */       if (this.isRowDeleted) {
/* 1050 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 82);
/* 1051 */         sQLException.fillInStackTrace();
/* 1052 */         throw sQLException;
/*      */       } 
/* 1054 */       setRowBufferAt(paramInt, (Datum)null);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   int getColumnCount() throws SQLException {
/* 1069 */     if (this.columnCount == 0) {
/* 1070 */       this.columnCount = this.resultSet.getColumnCount();
/*      */     }
/* 1072 */     return this.columnCount;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   ResultSetMetaData getInternalMetadata() throws SQLException {
/* 1082 */     if (this.rsetMetaData == null) {
/* 1083 */       this.rsetMetaData = this.resultSet.getMetaData();
/*      */     }
/* 1085 */     return this.rsetMetaData;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private void cancelRowChanges() throws SQLException {
/* 1091 */     synchronized (this.connection) {
/*      */       
/* 1093 */       if (this.isInserting) {
/* 1094 */         cancelRowInserts();
/*      */       }
/* 1096 */       if (this.isUpdating) {
/* 1097 */         cancelRowUpdates();
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   boolean isOnInsertRow() {
/* 1108 */     return this.isInserting;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void cancelRowInserts() {
/* 1118 */     if (this.isInserting) {
/*      */       
/* 1120 */       this.isInserting = false;
/*      */       
/* 1122 */       clearRowBuffer();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   boolean isUpdatingRow() {
/* 1133 */     return this.isUpdating;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void clearRowBuffer() {
/* 1143 */     if (this.rowBuffer != null)
/*      */     {
/* 1145 */       for (byte b = 0; b < this.rowBuffer.length; b++) {
/* 1146 */         this.rowBuffer[b] = null;
/*      */       }
/*      */     }
/* 1149 */     if (this.m_nullIndicator != null)
/*      */     {
/* 1151 */       for (byte b = 0; b < this.m_nullIndicator.length; b++) {
/* 1152 */         this.m_nullIndicator[b] = false;
/*      */       }
/*      */     }
/* 1155 */     if (this.typeInfo != null)
/*      */     {
/* 1157 */       for (byte b = 0; b < this.typeInfo.length; b++) {
/* 1158 */         if (this.typeInfo[b] != null)
/* 1159 */           for (byte b1 = 0; b1 < (this.typeInfo[b]).length; b1++)
/* 1160 */             this.typeInfo[b][b1] = 0;  
/*      */       } 
/*      */     }
/* 1163 */     cleanTempLobs();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void setRowBufferAt(int paramInt, Datum paramDatum) throws SQLException {
/* 1174 */     setRowBufferAt(paramInt, paramDatum, (int[])null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void setRowBufferAt(int paramInt, Object paramObject, int[] paramArrayOfint) throws SQLException {
/* 1185 */     if (!this.isInserting) {
/*      */       
/* 1187 */       if (isBeforeFirst() || isAfterLast() || getRow() == 0) {
/*      */         
/* 1189 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 82);
/* 1190 */         sQLException.fillInStackTrace();
/* 1191 */         throw sQLException;
/*      */       } 
/*      */       
/* 1194 */       this.isUpdating = true;
/*      */     } 
/*      */     
/* 1197 */     if (paramInt < 1 || paramInt > getColumnCount()) {
/*      */       
/* 1199 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68, "setRowBufferAt");
/* 1200 */       sQLException.fillInStackTrace();
/* 1201 */       throw sQLException;
/*      */     } 
/*      */     
/* 1204 */     if (this.rowBuffer == null) {
/* 1205 */       this.rowBuffer = new Object[getColumnCount()];
/*      */     }
/* 1207 */     if (this.m_nullIndicator == null) {
/*      */       
/* 1209 */       this.m_nullIndicator = new boolean[getColumnCount()];
/*      */       
/* 1211 */       for (byte b = 0; b < getColumnCount(); b++) {
/* 1212 */         this.m_nullIndicator[b] = false;
/*      */       }
/*      */     } 
/* 1215 */     if (paramArrayOfint != null) {
/*      */       
/* 1217 */       if (this.typeInfo == null)
/*      */       {
/* 1219 */         this.typeInfo = new int[getColumnCount()][];
/*      */       }
/*      */       
/* 1222 */       this.typeInfo[paramInt - 1] = paramArrayOfint;
/*      */     } 
/*      */     
/* 1225 */     this.rowBuffer[paramInt - 1] = paramObject;
/* 1226 */     this.m_nullIndicator[paramInt - 1] = (paramObject == null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected Datum getRowBufferDatumAt(int paramInt) throws SQLException {
/* 1236 */     if (paramInt < 1 || paramInt > getColumnCount()) {
/*      */       
/* 1238 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68, "getRowBufferDatumAt");
/* 1239 */       sQLException.fillInStackTrace();
/* 1240 */       throw sQLException;
/*      */     } 
/*      */     
/* 1243 */     Datum datum = null;
/*      */     
/* 1245 */     if (this.rowBuffer != null) {
/*      */       
/* 1247 */       Object object = this.rowBuffer[paramInt - 1];
/*      */       
/* 1249 */       if (object != null)
/*      */       {
/* 1251 */         if (object instanceof Datum) {
/*      */           
/* 1253 */           datum = (Datum)object;
/*      */         }
/*      */         else {
/*      */           
/* 1257 */           OracleResultSetMetaData oracleResultSetMetaData = (OracleResultSetMetaData)getInternalMetadata();
/* 1258 */           datum = SQLUtil.makeOracleDatum(this.connection, object, oracleResultSetMetaData.getColumnType(paramInt), null, oracleResultSetMetaData.isNCHAR(paramInt));
/*      */ 
/*      */ 
/*      */           
/* 1262 */           this.rowBuffer[paramInt - 1] = datum;
/*      */         } 
/*      */       }
/*      */     } 
/*      */     
/* 1267 */     return datum;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected Object getRowBufferAt(int paramInt) throws SQLException {
/* 1277 */     if (paramInt < 1 || paramInt > getColumnCount()) {
/*      */       
/* 1279 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68, "getRowBufferDatumAt");
/* 1280 */       sQLException.fillInStackTrace();
/* 1281 */       throw sQLException;
/*      */     } 
/*      */     
/* 1284 */     if (this.rowBuffer != null)
/*      */     {
/* 1286 */       return this.rowBuffer[paramInt - 1];
/*      */     }
/*      */     
/* 1289 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean isRowBufferUpdatedAt(int paramInt) throws SQLException {
/* 1296 */     if (paramInt < 1 || paramInt > getColumnCount()) {
/*      */       
/* 1298 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68, "getRowBufferDatumAt");
/* 1299 */       sQLException.fillInStackTrace();
/* 1300 */       throw sQLException;
/*      */     } 
/*      */     
/* 1303 */     if (this.rowBuffer == null) return false; 
/* 1304 */     return (this.rowBuffer[paramInt - 1] != null || this.m_nullIndicator[paramInt - 1]);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void prepareInsertRowStatement() throws SQLException {
/* 1315 */     if (this.insertStmt == null) {
/* 1316 */       String str = this.scrollStmt.sqlObject.getInsertSqlForUpdatableResultSet(this);
/* 1317 */       PreparedStatement preparedStatement = this.connection.prepareStatement(str);
/* 1318 */       this.insertStmt = (OraclePreparedStatement)((OraclePreparedStatementWrapper)preparedStatement).preparedStatement;
/* 1319 */       this.insertStmt.setQueryTimeout(this.scrollStmt.getQueryTimeout());
/* 1320 */       if (this.scrollStmt.sqlObject.generatedSqlNeedEscapeProcessing()) {
/* 1321 */         this.insertStmt.setEscapeProcessing(true);
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void prepareInsertRowBinds() throws SQLException {
/* 1331 */     int i = 1;
/*      */ 
/*      */     
/* 1334 */     i = prepareSubqueryBinds(this.insertStmt, i);
/*      */     
/* 1336 */     OracleResultSetMetaData oracleResultSetMetaData = (OracleResultSetMetaData)getInternalMetadata();
/*      */     
/* 1338 */     for (byte b = 1; b <= getColumnCount(); b++) {
/* 1339 */       Object object = getRowBufferAt(b);
/* 1340 */       if (object != null) {
/* 1341 */         if (object instanceof Reader) {
/* 1342 */           if (oracleResultSetMetaData.isNCHAR(b)) {
/* 1343 */             this.insertStmt.setFormOfUse(i + b - 1, (short)2);
/*      */           }
/* 1345 */           this.insertStmt.setCharacterStream(i + b - 1, (Reader)object, this.typeInfo[b - 1][0]);
/*      */         
/*      */         }
/* 1348 */         else if (object instanceof InputStream) {
/* 1349 */           if (this.typeInfo[b - 1][1] == 2) {
/* 1350 */             this.insertStmt.setBinaryStream(i + b - 1, (InputStream)object, this.typeInfo[b - 1][0]);
/*      */ 
/*      */           
/*      */           }
/* 1354 */           else if (this.typeInfo[b - 1][1] == 1) {
/* 1355 */             this.insertStmt.setAsciiStream(i + b - 1, (InputStream)object, this.typeInfo[b - 1][0]);
/*      */           }
/*      */         
/*      */         }
/*      */         else {
/*      */           
/* 1361 */           Datum datum = getRowBufferDatumAt(b);
/* 1362 */           if (oracleResultSetMetaData.isNCHAR(b)) {
/* 1363 */             this.insertStmt.setFormOfUse(i + b - 1, (short)2);
/*      */           }
/*      */           
/* 1366 */           this.insertStmt.setOracleObject(i + b - 1, datum);
/*      */         } 
/*      */       } else {
/*      */         
/* 1370 */         int j = getInternalMetadata().getColumnType(b);
/* 1371 */         if (j == 2006 || j == 2002 || j == 2008 || j == 2007 || j == 2003 || j == 2009) {
/*      */ 
/*      */ 
/*      */           
/* 1375 */           this.insertStmt.setNull(i + b - 1, j, getInternalMetadata().getColumnTypeName(b));
/*      */         
/*      */         }
/*      */         else {
/*      */           
/* 1380 */           this.insertStmt.setNull(i + b - 1, j);
/*      */         } 
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void executeInsertRow() throws SQLException {
/* 1393 */     if (this.insertStmt.executeUpdate() != 1) {
/*      */       
/* 1395 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 85);
/* 1396 */       sQLException.fillInStackTrace();
/* 1397 */       throw sQLException;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private int getNumColumnsChanged() throws SQLException {
/* 1410 */     byte b = 0;
/*      */     
/* 1412 */     if (this.indexColsChanged == null) {
/* 1413 */       this.indexColsChanged = new int[getColumnCount()];
/*      */     }
/* 1415 */     if (this.rowBuffer != null)
/*      */     {
/* 1417 */       for (byte b1 = 0; b1 < getColumnCount(); b1++) {
/*      */         
/* 1419 */         if (this.rowBuffer[b1] != null || (this.rowBuffer[b1] == null && this.m_nullIndicator[b1]))
/*      */         {
/*      */           
/* 1422 */           this.indexColsChanged[b++] = b1;
/*      */         }
/*      */       } 
/*      */     }
/*      */     
/* 1427 */     return b;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void prepareUpdateRowStatement(int paramInt) throws SQLException {
/* 1441 */     if (this.updateStmt != null) this.updateStmt.close();
/*      */     
/* 1443 */     String str = this.scrollStmt.sqlObject.getUpdateSqlForUpdatableResultSet(this, paramInt, this.rowBuffer, this.indexColsChanged);
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1448 */     PreparedStatement preparedStatement = this.connection.prepareStatement(str);
/* 1449 */     this.updateStmt = (OraclePreparedStatement)((OraclePreparedStatementWrapper)preparedStatement).preparedStatement;
/* 1450 */     this.updateStmt.setQueryTimeout(this.scrollStmt.getQueryTimeout());
/* 1451 */     if (this.scrollStmt.sqlObject.generatedSqlNeedEscapeProcessing()) {
/* 1452 */       this.updateStmt.setEscapeProcessing(true);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void prepareUpdateRowBinds(int paramInt) throws SQLException {
/* 1463 */     int i = 1;
/*      */ 
/*      */     
/* 1466 */     i = prepareSubqueryBinds(this.updateStmt, i);
/*      */     
/* 1468 */     OracleResultSetMetaData oracleResultSetMetaData = (OracleResultSetMetaData)getInternalMetadata();
/*      */     
/* 1470 */     for (byte b = 0; b < paramInt; b++) {
/* 1471 */       int j = this.indexColsChanged[b];
/* 1472 */       Object object = getRowBufferAt(j + 1);
/*      */       
/* 1474 */       if (object != null) {
/* 1475 */         if (object instanceof Reader) {
/* 1476 */           if (oracleResultSetMetaData.isNCHAR(j + 1))
/* 1477 */             this.updateStmt.setFormOfUse(i, (short)2); 
/* 1478 */           this.updateStmt.setCharacterStream(i++, (Reader)object, this.typeInfo[j][0]);
/*      */         
/*      */         }
/* 1481 */         else if (object instanceof InputStream) {
/* 1482 */           if (this.typeInfo[j][1] == 2) {
/*      */ 
/*      */             
/* 1485 */             this.updateStmt.setBinaryStream(i++, (InputStream)object, this.typeInfo[j][0]);
/*      */           }
/* 1487 */           else if (this.typeInfo[j][1] == 1) {
/*      */             
/* 1489 */             this.updateStmt.setAsciiStream(i++, (InputStream)object, this.typeInfo[j][0]);
/*      */           } 
/*      */         } else {
/*      */           
/* 1493 */           Datum datum = getRowBufferDatumAt(j + 1);
/*      */           
/* 1495 */           if (oracleResultSetMetaData.isNCHAR(j + 1))
/* 1496 */             this.updateStmt.setFormOfUse(i, (short)2); 
/* 1497 */           this.updateStmt.setOracleObject(i++, datum);
/*      */         } 
/*      */       } else {
/*      */         
/* 1501 */         int k = getInternalMetadata().getColumnType(j + 1);
/*      */         
/* 1503 */         if (k == 2006 || k == 2002 || k == 2008 || k == 2007 || k == 2003 || k == 2009) {
/*      */ 
/*      */ 
/*      */           
/* 1507 */           this.updateStmt.setNull(i++, k, getInternalMetadata().getColumnTypeName(j + 1));
/*      */         }
/*      */         else {
/*      */           
/* 1511 */           if (oracleResultSetMetaData.isNCHAR(j + 1)) {
/* 1512 */             this.updateStmt.setFormOfUse(i, (short)2);
/*      */           }
/* 1514 */           this.updateStmt.setNull(i++, k);
/*      */         } 
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/* 1520 */     prepareCompareSelfBinds(this.updateStmt, i);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void executeUpdateRow() throws SQLException {
/*      */     try {
/* 1530 */       if (this.updateStmt.executeUpdate() == 0) {
/*      */         
/* 1532 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 85);
/* 1533 */         sQLException.fillInStackTrace();
/* 1534 */         throw sQLException;
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/* 1539 */       if (this.isCachedRset) {
/*      */         
/* 1541 */         refreshRows(getRow(), 1);
/* 1542 */         cancelRowUpdates();
/*      */       } 
/*      */     } finally {
/*      */       
/* 1546 */       if (this.updateStmt != null) {
/* 1547 */         this.updateStmt.close();
/* 1548 */         this.updateStmt = null;
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   int refreshRows(int paramInt1, int paramInt2) throws SQLException {
/* 1564 */     return this.resultSet.refreshRows(paramInt1, paramInt2);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void prepareDeleteRowStatement() throws SQLException {
/* 1574 */     if (this.deleteStmt == null) {
/* 1575 */       String str = this.scrollStmt.sqlObject.getDeleteSqlForUpdatableResultSet(this);
/* 1576 */       PreparedStatement preparedStatement = this.connection.prepareStatement(str);
/* 1577 */       this.deleteStmt = (OraclePreparedStatement)((OraclePreparedStatementWrapper)preparedStatement).preparedStatement;
/* 1578 */       this.deleteStmt.setQueryTimeout(this.scrollStmt.getQueryTimeout());
/* 1579 */       if (this.scrollStmt.sqlObject.generatedSqlNeedEscapeProcessing()) {
/* 1580 */         this.deleteStmt.setEscapeProcessing(true);
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void prepareDeleteRowBinds() throws SQLException {
/* 1591 */     int i = 1;
/*      */ 
/*      */     
/* 1594 */     i = prepareSubqueryBinds(this.deleteStmt, i);
/*      */ 
/*      */     
/* 1597 */     prepareCompareSelfBinds(this.deleteStmt, i);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void executeDeleteRow() throws SQLException {
/* 1609 */     if (this.deleteStmt.executeUpdate() == 0) {
/*      */       
/* 1611 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 85);
/* 1612 */       sQLException.fillInStackTrace();
/* 1613 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 1618 */     if (this.isCachedRset) removeCurrentRowFromCache();
/*      */   
/*      */   }
/*      */ 
/*      */   
/*      */   void removeCurrentRowFromCache() throws SQLException {
/* 1624 */     this.resultSet.removeCurrentRowFromCache();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private int prepareCompareSelfBinds(OraclePreparedStatement paramOraclePreparedStatement, int paramInt) throws SQLException {
/* 1633 */     paramOraclePreparedStatement.setRowId(paramInt, ((InsensitiveScrollableResultSet)this.resultSet).getPrependedRowId());
/*      */     
/* 1635 */     return paramInt + 1;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private int prepareSubqueryBinds(OraclePreparedStatement paramOraclePreparedStatement, int paramInt) throws SQLException {
/* 1643 */     return paramInt + this.scrollStmt.copyBinds((Statement)paramOraclePreparedStatement, paramInt - 1);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void setIsNull(int paramInt) {
/* 1650 */     this.wasNull = paramInt;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void setIsNull(boolean paramBoolean) {
/* 1657 */     setIsNull(paramBoolean ? 1 : 2);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected void doneFetchingRows(boolean paramBoolean) throws SQLException {
/* 1663 */     this.resultSet.doneFetchingRows(paramBoolean);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   OracleStatement getOracleStatement() throws SQLException {
/* 1674 */     return (this.resultSet == null) ? null : this.resultSet.getOracleStatement();
/*      */   }
/*      */ 
/*      */ 
/*      */   
/* 1679 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*      */   public static final String BUILD_DATE = "Thu_Apr_04_15:09:24_PDT_2013";
/*      */   public static final boolean TRACE = false;
/*      */ }


/* Location:              C:\Users\olatu\OneDrive\Documents\Calypso\syncbase\sync_base.jar!\BOOT-INF\lib\ojdbc-7.jar!\oracle\jdbc\driver\UpdatableResultSet.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */