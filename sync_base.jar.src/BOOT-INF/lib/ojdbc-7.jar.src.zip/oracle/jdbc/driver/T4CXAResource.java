/*      */ package oracle.jdbc.driver;
/*      */ 
/*      */ import java.io.IOException;
/*      */ import java.sql.Connection;
/*      */ import java.sql.SQLException;
/*      */ import javax.sql.XAConnection;
/*      */ import javax.transaction.xa.XAException;
/*      */ import javax.transaction.xa.XAResource;
/*      */ import javax.transaction.xa.Xid;
/*      */ import oracle.jdbc.internal.OracleConnection;
/*      */ import oracle.jdbc.xa.OracleXAConnection;
/*      */ import oracle.jdbc.xa.OracleXAException;
/*      */ import oracle.jdbc.xa.OracleXid;
/*      */ import oracle.jdbc.xa.client.OracleXADataSource;
/*      */ import oracle.jdbc.xa.client.OracleXAResource;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ class T4CXAResource
/*      */   extends OracleXAResource
/*      */ {
/*      */   T4CConnection physicalConn;
/*   35 */   int[] applicationValueArr = new int[1];
/*      */   
/*      */   boolean isTransLoose = false;
/*      */   
/*      */   byte[] context;
/*      */   
/*      */   int errorNumber;
/*      */   
/*      */   private String password;
/*      */   
/*      */   T4CXAResource(T4CConnection paramT4CConnection, OracleXAConnection paramOracleXAConnection, boolean paramBoolean) throws XAException {
/*   46 */     super((Connection)paramT4CConnection, paramOracleXAConnection);
/*      */     
/*   48 */     this.physicalConn = paramT4CConnection;
/*   49 */     this.isTransLoose = paramBoolean;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected int doStart(Xid paramXid, int paramInt) throws XAException {
/*   57 */     synchronized (this.physicalConn) {
/*      */       
/*   59 */       int i = -1;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*   83 */       if (this.isTransLoose) {
/*   84 */         paramInt |= 0x10000;
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*   91 */       int j = paramInt & 0x8200000;
/*      */ 
/*      */       
/*   94 */       if (j == 134217728 && OracleXid.isLocalTransaction(paramXid)) {
/*   95 */         return 0;
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  134 */       this.applicationValueArr[0] = 0;
/*      */ 
/*      */ 
/*      */       
/*      */       try {
/*      */         try {
/*  140 */           T4CTTIOtxse t4CTTIOtxse = this.physicalConn.otxse;
/*  141 */           byte[] arrayOfByte1 = null;
/*  142 */           byte[] arrayOfByte2 = paramXid.getGlobalTransactionId();
/*  143 */           byte[] arrayOfByte3 = paramXid.getBranchQualifier();
/*      */           
/*  145 */           int k = 0;
/*  146 */           int m = 0;
/*      */           
/*  148 */           if (arrayOfByte2 != null && arrayOfByte3 != null) {
/*      */             
/*  150 */             k = Math.min(arrayOfByte2.length, 64);
/*  151 */             m = Math.min(arrayOfByte3.length, 64);
/*  152 */             arrayOfByte1 = new byte[128];
/*      */             
/*  154 */             System.arraycopy(arrayOfByte2, 0, arrayOfByte1, 0, k);
/*  155 */             System.arraycopy(arrayOfByte3, 0, arrayOfByte1, k, m);
/*      */           } 
/*      */           
/*  158 */           int n = 0;
/*      */ 
/*      */           
/*  161 */           if ((paramInt & 0x200000) != 0 || (paramInt & 0x8000000) != 0) {
/*  162 */             n |= 0x4;
/*      */           } else {
/*  164 */             n |= 0x1;
/*      */           } 
/*  166 */           if ((paramInt & 0x100) != 0) {
/*  167 */             n |= 0x100;
/*      */           }
/*  169 */           if ((paramInt & 0x200) != 0) {
/*  170 */             n |= 0x200;
/*      */           }
/*  172 */           if ((paramInt & 0x400) != 0) {
/*  173 */             n |= 0x400;
/*      */           }
/*  175 */           if ((paramInt & 0x10000) != 0) {
/*  176 */             n |= 0x10000;
/*      */           }
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  182 */           this.physicalConn.needLine();
/*  183 */           t4CTTIOtxse.doOTXSE(1, null, arrayOfByte1, paramXid.getFormatId(), k, m, this.timeout, n, this.applicationValueArr);
/*      */ 
/*      */ 
/*      */           
/*  187 */           this.applicationValueArr[0] = t4CTTIOtxse.getApplicationValue();
/*  188 */           byte[] arrayOfByte4 = t4CTTIOtxse.getContext();
/*      */ 
/*      */ 
/*      */           
/*  192 */           if (arrayOfByte4 != null) {
/*  193 */             this.context = arrayOfByte4;
/*      */           }
/*  195 */           i = 0;
/*  196 */           this.physicalConn.currentlyInTransaction = true;
/*      */         }
/*  198 */         catch (IOException iOException) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  205 */           SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException);
/*  206 */           sQLException.fillInStackTrace();
/*  207 */           throw sQLException;
/*      */         }
/*      */       
/*      */       }
/*  211 */       catch (SQLException sQLException) {
/*      */ 
/*      */ 
/*      */         
/*  215 */         i = sQLException.getErrorCode();
/*      */ 
/*      */ 
/*      */         
/*  219 */         if (i == 0) {
/*  220 */           throw new XAException(-6);
/*      */         }
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  260 */       return i;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected int doEnd(Xid paramXid, int paramInt, boolean paramBoolean) throws XAException {
/*  269 */     synchronized (this.physicalConn) {
/*      */       
/*  271 */       int i = -1;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       try {
/*  294 */         T4CTTIOtxse t4CTTIOtxse = this.physicalConn.otxse;
/*  295 */         byte[] arrayOfByte1 = null;
/*  296 */         byte[] arrayOfByte2 = paramXid.getGlobalTransactionId();
/*  297 */         byte[] arrayOfByte3 = paramXid.getBranchQualifier();
/*      */         
/*  299 */         int j = 0;
/*  300 */         int k = 0;
/*      */         
/*  302 */         if (arrayOfByte2 != null && arrayOfByte3 != null) {
/*      */           
/*  304 */           j = Math.min(arrayOfByte2.length, 64);
/*  305 */           k = Math.min(arrayOfByte3.length, 64);
/*  306 */           arrayOfByte1 = new byte[128];
/*      */           
/*  308 */           System.arraycopy(arrayOfByte2, 0, arrayOfByte1, 0, j);
/*  309 */           System.arraycopy(arrayOfByte3, 0, arrayOfByte1, j, k);
/*      */         } 
/*      */ 
/*      */ 
/*      */         
/*  314 */         if (this.context == null) {
/*      */           
/*  316 */           i = doStart(paramXid, 134217728);
/*      */           
/*  318 */           if (i != 0) {
/*  319 */             return i;
/*      */           }
/*      */         } 
/*  322 */         byte[] arrayOfByte4 = this.context;
/*  323 */         int m = 0;
/*  324 */         if ((paramInt & 0x2) == 2) {
/*      */           
/*  326 */           m = 1048576;
/*  327 */         } else if ((paramInt & 0x2000000) == 33554432 && (paramInt & 0x100000) != 1048576) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  340 */           m = 1048576;
/*      */         } 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  346 */         this.applicationValueArr[0] = this.applicationValueArr[0] >> 16;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  354 */         this.physicalConn.needLine();
/*  355 */         t4CTTIOtxse.doOTXSE(2, arrayOfByte4, arrayOfByte1, paramXid.getFormatId(), j, k, this.timeout, m, this.applicationValueArr);
/*      */ 
/*      */ 
/*      */         
/*  359 */         this.applicationValueArr[0] = t4CTTIOtxse.getApplicationValue();
/*  360 */         byte[] arrayOfByte5 = t4CTTIOtxse.getContext();
/*      */ 
/*      */         
/*  363 */         if (arrayOfByte5 != null) {
/*  364 */           this.context = arrayOfByte5;
/*      */         }
/*  366 */         i = 0;
/*  367 */         this.physicalConn.currentlyInTransaction = false;
/*      */       }
/*  369 */       catch (IOException iOException) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  376 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException);
/*  377 */         sQLException.fillInStackTrace();
/*  378 */         throw sQLException;
/*      */ 
/*      */       
/*      */       }
/*  382 */       catch (SQLException sQLException) {
/*      */ 
/*      */ 
/*      */         
/*  386 */         i = sQLException.getErrorCode();
/*      */ 
/*      */ 
/*      */         
/*  390 */         if (i == 0) {
/*  391 */           throw new XAException(-6);
/*      */         }
/*      */       } 
/*  394 */       return i;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void doCommit(Xid paramXid, boolean paramBoolean) throws SQLException, XAException {
/*  413 */     synchronized (this.physicalConn) {
/*      */ 
/*      */       
/*  416 */       byte b = paramBoolean ? 4 : 2;
/*      */ 
/*      */       
/*      */       try {
/*  420 */         int i = doTransaction(paramXid, 1, b);
/*      */ 
/*      */         
/*  423 */         if (!paramBoolean || (i != 2 && i != 4))
/*      */         {
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  429 */           if (paramBoolean || i != 5) {
/*      */ 
/*      */ 
/*      */             
/*  433 */             if (i == 8) {
/*  434 */               throw new XAException(106);
/*      */             }
/*  436 */             throw new XAException(-6);
/*  437 */           }  }  this.physicalConn.currentlyInTransaction = false;
/*      */       }
/*  439 */       catch (SQLException sQLException) {
/*      */         
/*  441 */         int i = sQLException.getErrorCode();
/*  442 */         if (i == 24756) {
/*      */ 
/*      */ 
/*      */           
/*  446 */           kputxrec(paramXid, 1, this.timeout + 120, sQLException);
/*      */         }
/*  448 */         else if (i == 24780) {
/*      */ 
/*      */ 
/*      */           
/*  452 */           OracleXADataSource oracleXADataSource = null;
/*  453 */           XAConnection xAConnection = null;
/*      */ 
/*      */           
/*      */           try {
/*  457 */             oracleXADataSource = new OracleXADataSource();
/*      */             
/*  459 */             oracleXADataSource.setURL(this.physicalConn.url);
/*  460 */             oracleXADataSource.setUser(this.physicalConn.userName);
/*  461 */             this.physicalConn.getPasswordInternal(this);
/*  462 */             oracleXADataSource.setPassword(this.password);
/*      */             
/*  464 */             xAConnection = oracleXADataSource.getXAConnection();
/*      */             
/*  466 */             XAResource xAResource = xAConnection.getXAResource();
/*      */             
/*  468 */             xAResource.commit(paramXid, paramBoolean);
/*  469 */             this.physicalConn.currentlyInTransaction = false;
/*      */           }
/*  471 */           catch (SQLException sQLException1) {
/*      */ 
/*      */ 
/*      */             
/*  475 */             XAException xAException = new XAException(-6);
/*  476 */             xAException.initCause(sQLException1);
/*  477 */             throw xAException;
/*      */           } finally {
/*      */ 
/*      */             
/*      */             try {
/*      */               
/*  483 */               if (xAConnection != null) {
/*  484 */                 xAConnection.close();
/*      */               }
/*  486 */               if (oracleXADataSource != null) {
/*  487 */                 oracleXADataSource.close();
/*      */               }
/*  489 */             } catch (Exception exception) {}
/*      */           }
/*      */         
/*      */         }
/*      */         else {
/*      */           
/*  495 */           throw sQLException;
/*      */         } 
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected int doPrepare(Xid paramXid) throws XAException, SQLException {
/*  506 */     synchronized (this.physicalConn) {
/*      */       
/*  508 */       byte b = -1;
/*      */       try {
/*  510 */         int i = doTransaction(paramXid, 3, 0);
/*      */ 
/*      */         
/*  513 */         if (i == 8)
/*      */         {
/*      */           
/*  516 */           throw new XAException(106);
/*      */         }
/*  518 */         if (i == 4) {
/*      */ 
/*      */           
/*  521 */           b = 3;
/*      */         }
/*  523 */         else if (i == 1) {
/*      */ 
/*      */           
/*  526 */           b = 0;
/*      */         } else {
/*  528 */           if (i == 3)
/*      */           {
/*      */ 
/*      */ 
/*      */             
/*  533 */             throw new XAException(100);
/*      */           }
/*      */ 
/*      */ 
/*      */           
/*  538 */           throw new XAException(-6);
/*      */         }
/*      */       
/*  541 */       } catch (SQLException sQLException) {
/*      */         
/*  543 */         int i = sQLException.getErrorCode();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  549 */         if (i == 25351) {
/*      */ 
/*      */           
/*  552 */           XAException xAException = new XAException(-6);
/*  553 */           xAException.initCause(sQLException);
/*  554 */           throw xAException;
/*      */         } 
/*  556 */         throw sQLException;
/*      */       } 
/*  558 */       return b;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected int doForget(Xid paramXid) throws XAException, SQLException {
/*  567 */     synchronized (this.physicalConn) {
/*      */       
/*  569 */       boolean bool = false;
/*      */       
/*  571 */       if (OracleXid.isLocalTransaction(paramXid)) {
/*  572 */         return 24771;
/*      */       }
/*      */ 
/*      */       
/*  576 */       int i = doStart(paramXid, 134217728);
/*      */       
/*  578 */       if (i != 24756) {
/*      */ 
/*      */ 
/*      */         
/*  582 */         if (i == 0) {
/*      */           
/*      */           try {
/*      */ 
/*      */ 
/*      */             
/*  588 */             doEnd(paramXid, 0, false);
/*      */           }
/*  590 */           catch (Exception exception) {}
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  596 */         if (i == 0 || i == 2079 || i == 24754 || i == 24761 || i == 24774 || i == 24776 || i == 25351)
/*      */         {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  603 */           return 24769; } 
/*  604 */         if (i == 24752) {
/*  605 */           return 24771;
/*      */         }
/*  607 */         return i;
/*      */       } 
/*      */       
/*  610 */       kputxrec(paramXid, 4, 1, null);
/*      */       
/*  612 */       return bool;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void doRollback(Xid paramXid) throws XAException, SQLException {
/*  620 */     synchronized (this.physicalConn) {
/*      */ 
/*      */       
/*      */       try {
/*  624 */         int i = doTransaction(paramXid, 2, 3);
/*      */ 
/*      */         
/*  627 */         if (i == 8)
/*  628 */           throw new XAException(106); 
/*  629 */         if (i == 3)
/*      */         
/*      */         { 
/*      */ 
/*      */ 
/*      */           
/*  635 */           this.physicalConn.currentlyInTransaction = false; } else { throw new XAException(-6); }
/*      */       
/*  637 */       } catch (SQLException sQLException) {
/*      */         
/*  639 */         int i = sQLException.getErrorCode();
/*      */ 
/*      */         
/*  642 */         if (i == 24756) {
/*      */ 
/*      */ 
/*      */           
/*  646 */           kputxrec(paramXid, 2, this.timeout + 120, sQLException);
/*      */         }
/*  648 */         else if (i == 24780) {
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  653 */           OracleXADataSource oracleXADataSource = null;
/*  654 */           XAConnection xAConnection = null;
/*      */ 
/*      */           
/*      */           try {
/*  658 */             oracleXADataSource = new OracleXADataSource();
/*      */             
/*  660 */             oracleXADataSource.setURL(this.physicalConn.url);
/*  661 */             oracleXADataSource.setUser(this.physicalConn.userName);
/*  662 */             this.physicalConn.getPasswordInternal(this);
/*  663 */             oracleXADataSource.setPassword(this.password);
/*      */             
/*  665 */             xAConnection = oracleXADataSource.getXAConnection();
/*      */             
/*  667 */             XAResource xAResource = xAConnection.getXAResource();
/*      */             
/*  669 */             xAResource.rollback(paramXid);
/*  670 */             this.physicalConn.currentlyInTransaction = false;
/*      */           }
/*  672 */           catch (SQLException sQLException1) {
/*      */ 
/*      */             
/*  675 */             XAException xAException = new XAException(-6);
/*  676 */             xAException.initCause(sQLException1);
/*  677 */             throw xAException;
/*      */           } finally {
/*      */ 
/*      */             
/*      */             try {
/*      */               
/*  683 */               if (xAConnection != null) {
/*  684 */                 xAConnection.close();
/*      */               }
/*  686 */               if (oracleXADataSource != null) {
/*  687 */                 oracleXADataSource.close();
/*      */               }
/*  689 */             } catch (Exception exception) {}
/*      */           }
/*      */         
/*  692 */         } else if (i != 25402) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  698 */           throw sQLException;
/*      */         } 
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   int doTransaction(Xid paramXid, int paramInt1, int paramInt2) throws SQLException {
/*  719 */     int i = -1;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     try {
/*  725 */       T4CTTIOtxen t4CTTIOtxen = this.physicalConn.otxen;
/*  726 */       byte[] arrayOfByte1 = null;
/*  727 */       byte[] arrayOfByte2 = paramXid.getGlobalTransactionId();
/*  728 */       byte[] arrayOfByte3 = paramXid.getBranchQualifier();
/*      */       
/*  730 */       int j = 0;
/*  731 */       int k = 0;
/*      */       
/*  733 */       if (arrayOfByte2 != null && arrayOfByte3 != null) {
/*      */         
/*  735 */         j = Math.min(arrayOfByte2.length, 64);
/*  736 */         k = Math.min(arrayOfByte3.length, 64);
/*  737 */         arrayOfByte1 = new byte[128];
/*      */         
/*  739 */         System.arraycopy(arrayOfByte2, 0, arrayOfByte1, 0, j);
/*  740 */         System.arraycopy(arrayOfByte3, 0, arrayOfByte1, j, k);
/*      */       } 
/*      */       
/*  743 */       byte[] arrayOfByte4 = this.context;
/*      */       
/*  745 */       this.physicalConn.needLine();
/*  746 */       t4CTTIOtxen.doOTXEN(paramInt1, arrayOfByte4, arrayOfByte1, paramXid.getFormatId(), j, k, this.timeout, paramInt2, 0);
/*      */       
/*  748 */       i = t4CTTIOtxen.getOutStateFromServer();
/*      */ 
/*      */     
/*      */     }
/*  752 */     catch (IOException iOException) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  761 */       this.physicalConn.handleIOException(iOException);
/*      */       
/*  763 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException);
/*  764 */       sQLException.fillInStackTrace();
/*  765 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/*  769 */     return i;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void kputxrec(Xid paramXid, int paramInt1, int paramInt2, SQLException paramSQLException) throws XAException, SQLException {
/*      */     byte b1, b2;
/*  786 */     switch (paramInt1) {
/*      */ 
/*      */       
/*      */       case 1:
/*  790 */         b1 = 3;
/*      */         break;
/*      */ 
/*      */       
/*      */       case 4:
/*  795 */         b1 = 2;
/*      */         break;
/*      */ 
/*      */       
/*      */       default:
/*  800 */         b1 = 0;
/*      */         break;
/*      */     } 
/*      */     
/*  804 */     int i = 0;
/*      */ 
/*      */     
/*  807 */     while (paramInt2-- > 0) {
/*      */       
/*  809 */       i = doTransaction(paramXid, 5, b1);
/*      */       
/*  811 */       if (i == 7) {
/*      */         
/*      */         try {
/*      */ 
/*      */           
/*  816 */           Thread.sleep(1000L);
/*      */         }
/*  818 */         catch (Exception exception) {}
/*      */       }
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  828 */     if (i == 7)
/*      */     {
/*      */ 
/*      */       
/*  832 */       throw new XAException(-6);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  841 */     byte b = -1;
/*      */     
/*  843 */     switch (i) {
/*      */ 
/*      */       
/*      */       case 3:
/*  847 */         if (paramInt1 == 1) {
/*  848 */           byte b3 = 7;
/*      */           
/*      */           break;
/*      */         } 
/*  852 */         b2 = 8;
/*  853 */         b = -3;
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 0:
/*  859 */         if (paramInt1 == 4) {
/*      */           
/*  861 */           b2 = 8;
/*  862 */           b = -3;
/*      */           
/*      */           break;
/*      */         } 
/*  866 */         b2 = 7;
/*  867 */         if (paramInt1 == 1) {
/*  868 */           b = -4;
/*      */         }
/*      */         break;
/*      */ 
/*      */       
/*      */       case 2:
/*  874 */         if (paramInt1 == 4) {
/*      */           
/*  876 */           b2 = 8;
/*      */ 
/*      */           
/*  879 */           b = -6;
/*      */           break;
/*      */         } 
/*      */       case 5:
/*  883 */         if (paramInt1 == 4) {
/*      */           
/*  885 */           b2 = 7;
/*      */           
/*      */           break;
/*      */         } 
/*  889 */         b = 7;
/*  890 */         b2 = 8;
/*      */         break;
/*      */ 
/*      */       
/*      */       case 4:
/*  895 */         if (paramInt1 == 4) {
/*      */           
/*  897 */           b2 = 7;
/*      */           
/*      */           break;
/*      */         } 
/*  901 */         b = 6;
/*  902 */         b2 = 8;
/*      */         break;
/*      */ 
/*      */       
/*      */       case 6:
/*  907 */         if (paramInt1 == 4) {
/*      */           
/*  909 */           b2 = 7;
/*      */           
/*      */           break;
/*      */         } 
/*  913 */         b = 5;
/*  914 */         b2 = 8;
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       default:
/*  920 */         b = -3;
/*  921 */         b2 = 8;
/*      */         break;
/*      */     } 
/*      */ 
/*      */     
/*  926 */     T4CTTIk2rpc t4CTTIk2rpc = this.physicalConn.k2rpc;
/*      */ 
/*      */     
/*      */     try {
/*  930 */       t4CTTIk2rpc.doOK2RPC(3, b2);
/*      */     }
/*  932 */     catch (IOException iOException) {
/*      */ 
/*      */       
/*  935 */       XAException xAException = new XAException(-7);
/*  936 */       xAException.initCause(iOException);
/*  937 */       throw xAException;
/*      */     }
/*  939 */     catch (SQLException sQLException) {
/*      */ 
/*      */       
/*  942 */       XAException xAException = new XAException(-6);
/*  943 */       xAException.initCause(sQLException);
/*  944 */       throw xAException;
/*      */     } 
/*      */     
/*  947 */     if (b != -1) {
/*      */ 
/*      */ 
/*      */       
/*  951 */       OracleXAException oracleXAException = null;
/*  952 */       if (paramSQLException != null) {
/*      */         
/*  954 */         oracleXAException = new OracleXAException(paramSQLException.getErrorCode(), b);
/*  955 */         oracleXAException.initCause(paramSQLException);
/*      */       } else {
/*      */         
/*  958 */         oracleXAException = new OracleXAException(0, b);
/*      */       } 
/*  960 */       throw oracleXAException;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final void setPasswordInternal(String paramString) {
/*  969 */     this.password = paramString;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected OracleConnection getConnectionDuringExceptionHandling() {
/*  983 */     return this.physicalConn;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1060 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*      */   public static final String BUILD_DATE = "Thu_Apr_04_15:09:24_PDT_2013";
/*      */   public static final boolean TRACE = false;
/*      */ }


/* Location:              C:\Users\olatu\OneDrive\Documents\Calypso\syncbase\sync_base.jar!\BOOT-INF\lib\ojdbc-7.jar!\oracle\jdbc\driver\T4CXAResource.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */