/*     */ package oracle.jdbc.driver;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.nio.ByteBuffer;
/*     */ import java.sql.SQLException;
/*     */ import oracle.jdbc.aq.AQMessageProperties;
/*     */ import oracle.jdbc.aq.AQNotificationEvent;
/*     */ import oracle.sql.TIMESTAMP;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class NTFAQEvent
/*     */   extends AQNotificationEvent
/*     */ {
/*     */   private String registrationString;
/*     */   private int namespace;
/*     */   private byte[] payload;
/*  47 */   private String queueName = null;
/*  48 */   private byte[] messageId = null;
/*  49 */   private String consumerName = null;
/*     */   private NTFConnection conn;
/*     */   private AQMessagePropertiesI msgProp;
/*  52 */   private AQNotificationEvent.EventType eventType = AQNotificationEvent.EventType.REGULAR;
/*  53 */   private AQNotificationEvent.AdditionalEventType additionalEventType = AQNotificationEvent.AdditionalEventType.NONE;
/*     */   
/*     */   private ByteBuffer dataBuffer;
/*     */   
/*     */   private boolean isReady = false;
/*     */   
/*     */   private short databaseVersion;
/*     */   
/*     */   NTFAQEvent(NTFConnection paramNTFConnection, short paramShort) throws IOException, InterruptedException {
/*  62 */     super(paramNTFConnection);
/*     */     
/*  64 */     this.conn = paramNTFConnection;
/*  65 */     int i = this.conn.readInt();
/*  66 */     byte[] arrayOfByte = new byte[i];
/*  67 */     this.conn.readBuffer(arrayOfByte, 0, i);
/*  68 */     this.dataBuffer = ByteBuffer.wrap(arrayOfByte);
/*  69 */     this.databaseVersion = paramShort;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void initEvent() throws SQLException {
/*  76 */     byte b1 = this.dataBuffer.get();
/*  77 */     int i = this.dataBuffer.getInt();
/*  78 */     byte[] arrayOfByte1 = new byte[i];
/*  79 */     this.dataBuffer.get(arrayOfByte1, 0, i);
/*  80 */     this.registrationString = this.conn.charset.toString(arrayOfByte1, 0, i);
/*     */ 
/*     */ 
/*     */     
/*  84 */     byte b2 = this.dataBuffer.get();
/*  85 */     int j = this.dataBuffer.getInt();
/*  86 */     byte[] arrayOfByte2 = new byte[j];
/*  87 */     this.dataBuffer.get(arrayOfByte2, 0, j);
/*  88 */     this.namespace = arrayOfByte2[0];
/*     */ 
/*     */     
/*  91 */     byte b3 = this.dataBuffer.get();
/*  92 */     int k = this.dataBuffer.getInt();
/*  93 */     if (k > 0) {
/*     */       
/*  95 */       this.payload = new byte[k];
/*  96 */       this.dataBuffer.get(this.payload, 0, k);
/*     */     } else {
/*     */       
/*  99 */       this.payload = null;
/*     */     } 
/* 101 */     if (this.dataBuffer.hasRemaining()) {
/*     */       
/* 103 */       int m = 0;
/* 104 */       if (this.databaseVersion >= 10200) {
/*     */ 
/*     */         
/* 107 */         byte b = this.dataBuffer.get();
/* 108 */         int i23 = this.dataBuffer.getInt();
/* 109 */         m = this.dataBuffer.getInt();
/*     */       } 
/*     */ 
/*     */       
/* 113 */       byte b4 = this.dataBuffer.get();
/* 114 */       int n = this.dataBuffer.getInt();
/* 115 */       byte[] arrayOfByte3 = new byte[n];
/* 116 */       this.dataBuffer.get(arrayOfByte3, 0, n);
/* 117 */       this.queueName = this.conn.charset.toString(arrayOfByte3, 0, n);
/*     */ 
/*     */ 
/*     */       
/* 121 */       byte b5 = this.dataBuffer.get();
/* 122 */       int i1 = this.dataBuffer.getInt();
/* 123 */       this.messageId = new byte[i1];
/* 124 */       this.dataBuffer.get(this.messageId, 0, i1);
/*     */ 
/*     */       
/* 127 */       byte b6 = this.dataBuffer.get();
/* 128 */       int i2 = this.dataBuffer.getInt();
/* 129 */       byte[] arrayOfByte4 = new byte[i2];
/* 130 */       this.dataBuffer.get(arrayOfByte4, 0, i2);
/* 131 */       this.consumerName = this.conn.charset.toString(arrayOfByte4, 0, i2);
/*     */ 
/*     */ 
/*     */       
/* 135 */       byte b7 = this.dataBuffer.get();
/* 136 */       int i3 = this.dataBuffer.getInt();
/* 137 */       byte[] arrayOfByte5 = new byte[i3];
/* 138 */       this.dataBuffer.get(arrayOfByte5, 0, i3);
/*     */ 
/*     */       
/* 141 */       byte b8 = this.dataBuffer.get();
/* 142 */       int i4 = this.dataBuffer.getInt();
/* 143 */       int i5 = this.dataBuffer.getInt();
/* 144 */       if (arrayOfByte5[0] == 1)
/* 145 */         i5 = -i5; 
/* 146 */       int i6 = i5;
/*     */ 
/*     */       
/* 149 */       byte b9 = this.dataBuffer.get();
/* 150 */       int i7 = this.dataBuffer.getInt();
/* 151 */       int i8 = this.dataBuffer.getInt();
/*     */ 
/*     */       
/* 154 */       byte b10 = this.dataBuffer.get();
/* 155 */       int i9 = this.dataBuffer.getInt();
/* 156 */       byte[] arrayOfByte6 = new byte[i9];
/* 157 */       this.dataBuffer.get(arrayOfByte6, 0, i9);
/*     */ 
/*     */       
/* 160 */       byte b11 = this.dataBuffer.get();
/* 161 */       int i10 = this.dataBuffer.getInt();
/* 162 */       int i11 = this.dataBuffer.getInt();
/* 163 */       if (arrayOfByte6[0] == 1)
/* 164 */         i11 = -i11; 
/* 165 */       int i12 = i11;
/*     */ 
/*     */       
/* 168 */       byte b12 = this.dataBuffer.get();
/* 169 */       int i13 = this.dataBuffer.getInt();
/* 170 */       int i14 = this.dataBuffer.getInt();
/*     */ 
/*     */       
/* 173 */       byte b13 = this.dataBuffer.get();
/* 174 */       int i15 = this.dataBuffer.getInt();
/* 175 */       byte[] arrayOfByte7 = new byte[i15];
/* 176 */       this.dataBuffer.get(arrayOfByte7, 0, i15);
/* 177 */       TIMESTAMP tIMESTAMP = new TIMESTAMP(arrayOfByte7);
/*     */ 
/*     */       
/* 180 */       byte b14 = this.dataBuffer.get();
/* 181 */       int i16 = this.dataBuffer.getInt();
/* 182 */       byte[] arrayOfByte8 = new byte[i16];
/* 183 */       this.dataBuffer.get(arrayOfByte8, 0, i16);
/* 184 */       byte b15 = arrayOfByte8[0];
/*     */ 
/*     */       
/* 187 */       byte b16 = this.dataBuffer.get();
/* 188 */       int i17 = this.dataBuffer.getInt();
/* 189 */       byte[] arrayOfByte9 = new byte[i17];
/* 190 */       this.dataBuffer.get(arrayOfByte9, 0, i17);
/* 191 */       String str1 = this.conn.charset.toString(arrayOfByte9, 0, i17);
/*     */ 
/*     */ 
/*     */       
/* 195 */       byte b17 = this.dataBuffer.get();
/* 196 */       int i18 = this.dataBuffer.getInt();
/* 197 */       byte[] arrayOfByte10 = new byte[i18];
/* 198 */       this.dataBuffer.get(arrayOfByte10, 0, i18);
/* 199 */       String str2 = this.conn.charset.toString(arrayOfByte10, 0, i18);
/*     */ 
/*     */ 
/*     */       
/* 203 */       byte b18 = this.dataBuffer.get();
/* 204 */       int i19 = this.dataBuffer.getInt();
/* 205 */       byte[] arrayOfByte11 = null;
/* 206 */       if (i19 > 0) {
/*     */         
/* 208 */         arrayOfByte11 = new byte[i19];
/* 209 */         this.dataBuffer.get(arrayOfByte11, 0, i19);
/*     */       } 
/*     */ 
/*     */       
/* 213 */       byte b19 = this.dataBuffer.get();
/* 214 */       int i20 = this.dataBuffer.getInt();
/* 215 */       byte[] arrayOfByte12 = new byte[i20];
/* 216 */       this.dataBuffer.get(arrayOfByte12, 0, i20);
/* 217 */       String str3 = this.conn.charset.toString(arrayOfByte12, 0, i20);
/*     */ 
/*     */ 
/*     */       
/* 221 */       byte b20 = this.dataBuffer.get();
/* 222 */       int i21 = this.dataBuffer.getInt();
/* 223 */       byte[] arrayOfByte13 = new byte[i21];
/* 224 */       this.dataBuffer.get(arrayOfByte13, 0, i21);
/* 225 */       String str4 = this.conn.charset.toString(arrayOfByte13, 0, i21);
/*     */ 
/*     */ 
/*     */       
/* 229 */       byte b21 = this.dataBuffer.get();
/* 230 */       int i22 = this.dataBuffer.getInt();
/* 231 */       byte b22 = this.dataBuffer.get();
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 236 */       this.msgProp = new AQMessagePropertiesI();
/* 237 */       this.msgProp.setAttempts(i14);
/* 238 */       this.msgProp.setCorrelation(str2);
/* 239 */       this.msgProp.setDelay(i8);
/* 240 */       this.msgProp.setEnqueueTime(tIMESTAMP.timestampValue());
/* 241 */       this.msgProp.setMessageState(AQMessageProperties.MessageState.getMessageState(b15));
/* 242 */       if (this.databaseVersion >= 10200)
/* 243 */         this.msgProp.setDeliveryMode(AQMessageProperties.DeliveryMode.getDeliveryMode(m)); 
/* 244 */       this.msgProp.setPreviousQueueMessageId(arrayOfByte11);
/* 245 */       AQAgentI aQAgentI = new AQAgentI();
/* 246 */       aQAgentI.setAddress(str4);
/* 247 */       aQAgentI.setName(str3);
/* 248 */       aQAgentI.setProtocol(b22);
/* 249 */       this.msgProp.setSender(aQAgentI);
/*     */       
/* 251 */       this.msgProp.setPriority(i6);
/* 252 */       this.msgProp.setExpiration(i12);
/* 253 */       this.msgProp.setExceptionQueue(str1);
/*     */     } 
/* 255 */     this.isReady = true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AQMessageProperties getMessageProperties() throws SQLException {
/* 267 */     if (!this.isReady)
/* 268 */       initEvent(); 
/* 269 */     return this.msgProp;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getRegistration() throws SQLException {
/* 281 */     if (!this.isReady)
/* 282 */       initEvent(); 
/* 283 */     return this.registrationString;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AQNotificationEvent.EventType getEventType() {
/* 295 */     return this.eventType;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AQNotificationEvent.AdditionalEventType getAdditionalEventType() {
/* 307 */     return this.additionalEventType;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void setEventType(AQNotificationEvent.EventType paramEventType) throws IOException {
/* 314 */     this.eventType = paramEventType;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void setAdditionalEventType(AQNotificationEvent.AdditionalEventType paramAdditionalEventType) {
/* 321 */     this.additionalEventType = paramAdditionalEventType;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] getPayload() throws SQLException {
/* 333 */     if (!this.isReady)
/* 334 */       initEvent(); 
/* 335 */     return this.payload;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getQueueName() throws SQLException {
/* 347 */     if (!this.isReady)
/* 348 */       initEvent(); 
/* 349 */     return this.queueName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] getMessageId() throws SQLException {
/* 361 */     if (!this.isReady)
/* 362 */       initEvent(); 
/* 363 */     return this.messageId;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getConsumerName() throws SQLException {
/* 375 */     if (!this.isReady)
/* 376 */       initEvent(); 
/* 377 */     return this.consumerName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getConnectionInformation() {
/* 389 */     return this.conn.connectionDescription;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 397 */     if (!this.isReady) {
/*     */       
/*     */       try {
/*     */         
/* 401 */         initEvent();
/*     */       }
/* 403 */       catch (SQLException sQLException) {
/*     */         
/* 405 */         return sQLException.getMessage();
/*     */       } 
/*     */     }
/* 408 */     StringBuffer stringBuffer = new StringBuffer();
/* 409 */     stringBuffer.append("Connection information  : " + this.conn.connectionDescription + "\n");
/* 410 */     stringBuffer.append("Event type              : " + this.eventType + "\n");
/* 411 */     if (this.additionalEventType != AQNotificationEvent.AdditionalEventType.NONE)
/* 412 */       stringBuffer.append("Additional event type   : " + this.additionalEventType + "\n"); 
/* 413 */     stringBuffer.append("Namespace               : " + this.namespace + "\n");
/* 414 */     stringBuffer.append("Registration            : " + this.registrationString + "\n");
/* 415 */     stringBuffer.append("Queue name              : " + this.queueName + "\n");
/* 416 */     stringBuffer.append("Consumer name           : " + this.consumerName + "\n");
/* 417 */     if (this.payload != null) {
/*     */       
/* 419 */       stringBuffer.append("Payload length          : " + this.payload.length + "\n");
/* 420 */       stringBuffer.append("Payload (first 50 bytes): " + byteBufferToHexString(this.payload, 50) + "\n");
/*     */     } else {
/*     */       
/* 423 */       stringBuffer.append("Payload                 : null\n");
/* 424 */     }  stringBuffer.append("Message ID              : " + byteBufferToHexString(this.messageId, 50) + "\n");
/* 425 */     if (this.msgProp != null)
/* 426 */       stringBuffer.append(this.msgProp.toString()); 
/* 427 */     return stringBuffer.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   static final String byteBufferToHexString(byte[] paramArrayOfbyte, int paramInt) {
/* 433 */     if (paramArrayOfbyte == null) {
/* 434 */       return null;
/*     */     }
/* 436 */     byte b = 0;
/* 437 */     boolean bool = true;
/* 438 */     StringBuffer stringBuffer = new StringBuffer();
/* 439 */     while (b < paramArrayOfbyte.length && b < paramInt) {
/*     */       
/* 441 */       if (!bool) {
/* 442 */         stringBuffer.append(' ');
/*     */       } else {
/* 444 */         bool = false;
/* 445 */       }  String str = Integer.toHexString(paramArrayOfbyte[b] & 0xFF);
/* 446 */       if (str.length() == 1)
/* 447 */         str = "0" + str; 
/* 448 */       stringBuffer.append(str);
/* 449 */       b++;
/*     */     } 
/* 451 */     return stringBuffer.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 457 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*     */   public static final String BUILD_DATE = "Thu_Apr_04_15:09:24_PDT_2013";
/*     */   public static final boolean TRACE = false;
/*     */ }


/* Location:              C:\Users\olatu\OneDrive\Documents\Calypso\syncbase\sync_base.jar!\BOOT-INF\lib\ojdbc-7.jar!\oracle\jdbc\driver\NTFAQEvent.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */