/*     */ package oracle.jdbc.driver;
/*     */ 
/*     */ import java.io.EOFException;
/*     */ import java.io.IOException;
/*     */ import java.net.InetAddress;
/*     */ import java.net.Socket;
/*     */ import java.nio.ByteBuffer;
/*     */ import java.nio.channels.SelectionKey;
/*     */ import java.nio.channels.Selector;
/*     */ import java.nio.channels.SocketChannel;
/*     */ import java.util.Iterator;
/*     */ import oracle.jdbc.aq.AQNotificationEvent;
/*     */ import oracle.jdbc.dcn.DatabaseChangeEvent;
/*     */ import oracle.sql.CharacterSet;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class NTFConnection
/*     */   extends Thread
/*     */ {
/*     */   private static final int NS_HEADER_SIZE = 10;
/*     */   private SocketChannel channel;
/*  71 */   private ByteBuffer inBuffer = null;
/*  72 */   private ByteBuffer outBuffer = null;
/*     */ 
/*     */   
/*     */   private int currentNSPacketLength;
/*     */ 
/*     */   
/*     */   private int currentNSPacketType;
/*     */ 
/*     */   
/*     */   private ByteBuffer currentNSPacketDataBuffer;
/*     */   
/*     */   private boolean needsToBeClosed = false;
/*     */   
/*     */   private NTFManager ntfManager;
/*     */   
/*  87 */   private Selector selector = null;
/*  88 */   private Iterator iterator = null;
/*  89 */   private SelectionKey aKey = null;
/*     */   
/*     */   int remotePort;
/*     */   
/*     */   String remoteAddress;
/*     */   
/*     */   String remoteName;
/*     */   int localPort;
/*     */   String localAddress;
/*     */   String localName;
/*     */   String connectionDescription;
/* 100 */   CharacterSet charset = null;
/*     */   
/*     */   static final int NSPTCN = 1;
/*     */   
/*     */   static final int NSPTAC = 2;
/*     */   
/*     */   static final int NSPTAK = 3;
/*     */   
/*     */   static final int NSPTRF = 4;
/*     */   
/*     */   static final int NSPTRD = 5;
/*     */   
/*     */   static final int NSPTDA = 6;
/*     */   static final int NSPTNL = 7;
/*     */   static final int NSPTAB = 9;
/*     */   static final int NSPTRS = 11;
/*     */   static final int NSPTMK = 12;
/*     */   static final int NSPTAT = 13;
/*     */   static final int NSPTCNL = 14;
/*     */   static final int NSPTHI = 19;
/*     */   static final short KPDNFY_TIMEOUT = 1;
/*     */   static final short KPDNFY_GROUPING = 2;
/*     */   
/*     */   NTFConnection(NTFManager paramNTFManager, SocketChannel paramSocketChannel) {
/*     */     try {
/* 125 */       this.ntfManager = paramNTFManager;
/* 126 */       this.channel = paramSocketChannel;
/* 127 */       this.channel.configureBlocking(false);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 139 */       this.inBuffer = ByteBuffer.allocate(4096);
/* 140 */       this.outBuffer = ByteBuffer.allocate(2048);
/* 141 */       Socket socket = this.channel.socket();
/* 142 */       InetAddress inetAddress1 = socket.getInetAddress();
/* 143 */       InetAddress inetAddress2 = socket.getLocalAddress();
/* 144 */       this.remotePort = socket.getPort();
/* 145 */       this.localPort = socket.getLocalPort();
/* 146 */       this.remoteAddress = inetAddress1.getHostAddress();
/* 147 */       this.remoteName = inetAddress1.getHostName();
/* 148 */       this.localAddress = inetAddress2.getHostAddress();
/* 149 */       this.localName = inetAddress2.getHostName();
/* 150 */       this.connectionDescription = "local=" + this.localName + "/" + this.localAddress + ":" + this.localPort + ", remote=" + this.remoteName + "/" + this.remoteAddress + ":" + this.remotePort;
/*     */ 
/*     */ 
/*     */     
/*     */     }
/* 155 */     catch (IOException iOException) {}
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void run() {
/*     */     
/* 166 */     try { this.selector = Selector.open();
/* 167 */       this.channel.register(this.selector, 1);
/*     */       
/* 169 */       int i = 0;
/*     */ 
/*     */       
/* 172 */       this.inBuffer.limit(0);
/*     */       
/* 174 */       while (!this.needsToBeClosed) {
/*     */ 
/*     */         
/* 177 */         if (!this.inBuffer.hasRemaining()) {
/*     */           do {
/* 179 */             i = readFromNetwork();
/*     */           }
/* 181 */           while (i == 0);
/*     */         }
/* 183 */         unmarshalOneNSPacket();
/*     */       }  }
/* 185 */     catch (IOException iOException)
/*     */     
/*     */     { 
/*     */       try {
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 193 */         this.selector.close();
/* 194 */         this.channel.close();
/* 195 */       } catch (IOException iOException1) {} } catch (InterruptedException interruptedException) { try { this.selector.close(); this.channel.close(); } catch (IOException iOException) {} } finally { try { this.selector.close(); this.channel.close(); } catch (IOException iOException) {} }
/*     */   
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int readFromNetwork() throws IOException, InterruptedException {
/* 225 */     this.inBuffer.compact();
/*     */     
/*     */     while (true) {
/* 228 */       if (this.iterator == null || !this.iterator.hasNext()) {
/*     */ 
/*     */ 
/*     */         
/* 232 */         this.selector.select();
/*     */ 
/*     */ 
/*     */         
/* 236 */         if (this.needsToBeClosed)
/*     */         {
/* 238 */           throw new InterruptedException();
/*     */         }
/* 240 */         this.iterator = this.selector.selectedKeys().iterator(); continue;
/*     */       } 
/* 242 */       this.aKey = this.iterator.next();
/*     */       
/* 244 */       if ((this.aKey.readyOps() & 0x1) == 1) {
/*     */         break;
/*     */       }
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 255 */     int i = this.channel.read(this.inBuffer);
/*     */     
/* 257 */     if (i < 0)
/*     */     {
/* 259 */       throw new EOFException(); } 
/* 260 */     if (i > 0)
/*     */     {
/*     */       
/* 263 */       this.inBuffer.flip();
/*     */     }
/*     */ 
/*     */     
/* 267 */     this.iterator.remove();
/*     */     
/* 269 */     return i;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void getNextNSPacket() throws IOException, InterruptedException {
/* 286 */     while (!this.inBuffer.hasRemaining() || this.inBuffer.remaining() < 10) {
/* 287 */       int k = readFromNetwork();
/*     */     }
/*     */     
/* 290 */     this.currentNSPacketLength = this.inBuffer.getShort();
/*     */     
/* 292 */     this.inBuffer.position(this.inBuffer.position() + 2);
/* 293 */     this.currentNSPacketType = this.inBuffer.get();
/* 294 */     this.inBuffer.position(this.inBuffer.position() + 5);
/*     */ 
/*     */ 
/*     */     
/* 298 */     while (this.inBuffer.remaining() < this.currentNSPacketLength - 10) {
/* 299 */       int k = readFromNetwork();
/*     */     }
/*     */ 
/*     */     
/* 303 */     int i = this.inBuffer.limit();
/* 304 */     int j = this.inBuffer.position() + this.currentNSPacketLength - 10;
/*     */ 
/*     */ 
/*     */     
/* 308 */     this.inBuffer.limit(j);
/* 309 */     this.currentNSPacketDataBuffer = this.inBuffer.slice();
/* 310 */     this.inBuffer.limit(i);
/*     */     
/* 312 */     this.inBuffer.position(j);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void unmarshalOneNSPacket() throws IOException, InterruptedException {
/* 331 */     getNextNSPacket();
/*     */ 
/*     */ 
/*     */     
/* 335 */     if (this.currentNSPacketDataBuffer.hasRemaining()) {
/* 336 */       byte[] arrayOfByte; switch (this.currentNSPacketType) {
/*     */ 
/*     */         
/*     */         case 1:
/* 340 */           arrayOfByte = new byte[] { 0, 24, 0, 0, 2, 0, 0, 0, 1, 52, 0, 0, 8, 0, Byte.MAX_VALUE, -1, 1, 0, 0, 0, 0, 24, 65, 1 };
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 345 */           this.outBuffer.clear();
/* 346 */           this.outBuffer.put(arrayOfByte);
/* 347 */           this.outBuffer.limit(24);
/* 348 */           this.outBuffer.rewind();
/* 349 */           this.channel.write(this.outBuffer);
/*     */           break;
/*     */         
/*     */         case 6:
/* 353 */           if (this.currentNSPacketDataBuffer.get(0) == -34 && this.currentNSPacketDataBuffer.get(1) == -83) {
/*     */ 
/*     */ 
/*     */             
/* 357 */             byte[] arrayOfByte1 = { 0, Byte.MAX_VALUE, 0, 0, 6, 0, 0, 0, 0, 0, -34, -83, -66, -17, 0, 117, 10, 32, 1, 0, 0, 4, 0, 0, 4, 0, 3, 0, 0, 0, 0, 0, 4, 0, 5, 10, 32, 1, 0, 0, 2, 0, 6, 0, 31, 0, 14, 0, 1, -34, -83, -66, -17, 0, 3, 0, 0, 0, 2, 0, 4, 0, 1, 0, 1, 0, 2, 0, 0, 0, 0, 0, 4, 0, 5, 10, 32, 1, 0, 0, 2, 0, 6, -5, -1, 0, 2, 0, 2, 0, 0, 0, 0, 0, 4, 0, 5, 10, 32, 1, 0, 0, 1, 0, 2, 0, 0, 3, 0, 2, 0, 0, 0, 0, 0, 4, 0, 5, 10, 32, 1, 0, 0, 1, 0, 2, 0 };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */             
/* 375 */             this.outBuffer.clear();
/* 376 */             this.outBuffer.put(arrayOfByte1);
/* 377 */             this.outBuffer.limit(arrayOfByte1.length);
/* 378 */             this.outBuffer.rewind();
/* 379 */             this.channel.write(this.outBuffer);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */             
/*     */             break;
/*     */           } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 424 */           unmarshalNSDataPacket();
/*     */           break;
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void unmarshalNSDataPacket() throws IOException, InterruptedException {
/* 499 */     short s1 = readShort();
/*     */ 
/*     */     
/* 502 */     int i = readInt();
/*     */     
/* 504 */     byte b1 = readByte();
/* 505 */     int j = readInt();
/* 506 */     short s2 = readShort();
/* 507 */     if (this.charset == null || this.charset.getOracleId() != s2) {
/* 508 */       this.charset = CharacterSet.make(s2);
/*     */     }
/*     */     
/* 511 */     byte b2 = readByte();
/* 512 */     int k = readInt();
/* 513 */     short s3 = readShort();
/*     */ 
/*     */     
/* 516 */     byte b3 = readByte();
/* 517 */     int m = readInt();
/* 518 */     short s4 = readShort();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 524 */     int n = (i - 21) / 9;
/* 525 */     int[] arrayOfInt = new int[n];
/* 526 */     for (byte b = 0; b < n; b++) {
/*     */       
/* 528 */       byte b4 = readByte();
/* 529 */       int i2 = readInt();
/* 530 */       byte[] arrayOfByte = new byte[i2];
/* 531 */       readBuffer(arrayOfByte, 0, i2);
/*     */ 
/*     */ 
/*     */       
/* 535 */       for (byte b5 = 0; b5 < i2; b5++) {
/* 536 */         if (b5 < 4)
/* 537 */           arrayOfInt[b] = arrayOfInt[b] | (arrayOfByte[b5] & 0xFF) << 8 * (i2 - b5 - 1); 
/*     */       } 
/*     */     } 
/* 540 */     NTFDCNEvent nTFDCNEvent = null;
/* 541 */     NTFAQEvent nTFAQEvent = null;
/* 542 */     int i1 = 0;
/* 543 */     short s5 = 0;
/* 544 */     NTFRegistration[] arrayOfNTFRegistration = null;
/*     */     
/* 546 */     if (s1 >= 2) {
/*     */ 
/*     */       
/* 549 */       short s = readShort();
/* 550 */       arrayOfNTFRegistration = new NTFRegistration[arrayOfInt.length];
/* 551 */       for (byte b4 = 0; b4 < arrayOfInt.length; b4++) {
/*     */         
/* 553 */         arrayOfNTFRegistration[b4] = this.ntfManager.getRegistration(arrayOfInt[b4]);
/* 554 */         if (arrayOfNTFRegistration[b4] != null) {
/*     */           
/* 556 */           i1 = arrayOfNTFRegistration[b4].getNamespace();
/* 557 */           s5 = arrayOfNTFRegistration[b4].getDatabaseVersion();
/*     */         } 
/*     */       } 
/*     */       
/* 561 */       if (i1 == 2) {
/*     */ 
/*     */         
/* 564 */         nTFDCNEvent = new NTFDCNEvent(this, s5);
/*     */       }
/* 566 */       else if (i1 == 1) {
/*     */ 
/*     */         
/* 569 */         nTFAQEvent = new NTFAQEvent(this, s5);
/*     */       }
/* 571 */       else if (i1 == 0) {
/*     */       
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 584 */     short s6 = 0;
/* 585 */     if (s1 >= 3) {
/*     */ 
/*     */       
/* 588 */       short s = readShort();
/* 589 */       int i2 = readInt();
/* 590 */       byte b4 = readByte();
/* 591 */       int i3 = readInt();
/* 592 */       s6 = readShort();
/* 593 */       if (i1 == 2 && nTFDCNEvent != null) {
/*     */ 
/*     */         
/* 596 */         nTFDCNEvent.setAdditionalEventType(DatabaseChangeEvent.AdditionalEventType.getEventType(s6));
/*     */ 
/*     */         
/* 599 */         if (s6 == 1) {
/* 600 */           nTFDCNEvent.setEventType(DatabaseChangeEvent.EventType.DEREG);
/*     */         }
/* 602 */       } else if (i1 == 1 && nTFAQEvent != null) {
/*     */ 
/*     */         
/* 605 */         nTFAQEvent.setAdditionalEventType(AQNotificationEvent.AdditionalEventType.getEventType(s6));
/*     */ 
/*     */         
/* 608 */         if (s6 == 1) {
/* 609 */           nTFAQEvent.setEventType(AQNotificationEvent.EventType.DEREG);
/*     */         }
/*     */       } 
/*     */     } 
/* 613 */     if (s1 > 3);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 618 */     if (arrayOfNTFRegistration != null) {
/*     */       
/* 620 */       if (i1 == 2)
/* 621 */         for (byte b4 = 0; b4 < arrayOfNTFRegistration.length; b4++) {
/* 622 */           if (arrayOfNTFRegistration[b4] != null && nTFDCNEvent != null)
/*     */           {
/* 624 */             arrayOfNTFRegistration[b4].notify(nTFDCNEvent); } 
/*     */         }  
/* 626 */       if (i1 == 1) {
/* 627 */         for (byte b4 = 0; b4 < arrayOfNTFRegistration.length; b4++) {
/* 628 */           if (arrayOfNTFRegistration[b4] != null && nTFAQEvent != null)
/*     */           {
/* 630 */             arrayOfNTFRegistration[b4].notify(nTFAQEvent);
/*     */           }
/*     */         } 
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void closeThisConnection() {
/* 643 */     this.needsToBeClosed = true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   byte readByte() throws IOException, InterruptedException {
/* 655 */     byte b = 0;
/* 656 */     if (this.currentNSPacketDataBuffer.hasRemaining()) {
/*     */       
/* 658 */       b = this.currentNSPacketDataBuffer.get();
/*     */     }
/*     */     else {
/*     */       
/* 662 */       getNextNSPacket();
/* 663 */       this.currentNSPacketDataBuffer.get();
/*     */     } 
/* 665 */     return b;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   short readShort() throws IOException, InterruptedException {
/* 675 */     short s = 0;
/* 676 */     if (this.currentNSPacketDataBuffer.remaining() >= 2) {
/*     */       
/* 678 */       s = this.currentNSPacketDataBuffer.getShort();
/*     */ 
/*     */     
/*     */     }
/*     */     else {
/*     */ 
/*     */       
/* 685 */       int i = readByte() & 0xFF;
/* 686 */       int j = readByte() & 0xFF;
/* 687 */       s = (short)(i << 8 | j);
/*     */     } 
/* 689 */     return s;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   int readInt() throws IOException, InterruptedException {
/* 699 */     int i = 0;
/* 700 */     if (this.currentNSPacketDataBuffer.remaining() >= 4) {
/*     */       
/* 702 */       i = this.currentNSPacketDataBuffer.getInt();
/*     */ 
/*     */     
/*     */     }
/*     */     else {
/*     */ 
/*     */       
/* 709 */       int j = readByte() & 0xFF;
/* 710 */       int k = readByte() & 0xFF;
/* 711 */       int m = readByte() & 0xFF;
/* 712 */       int n = readByte() & 0xFF;
/* 713 */       i = j << 24 | k << 16 | m << 8 | n;
/*     */     } 
/* 715 */     return i;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   long readLong() throws IOException, InterruptedException {
/* 725 */     long l = 0L;
/* 726 */     if (this.currentNSPacketDataBuffer.remaining() >= 8) {
/*     */       
/* 728 */       l = this.currentNSPacketDataBuffer.getLong();
/*     */ 
/*     */     
/*     */     }
/*     */     else {
/*     */ 
/*     */       
/* 735 */       long l1 = (readByte() & 0xFF);
/* 736 */       long l2 = (readByte() & 0xFF);
/* 737 */       long l3 = (readByte() & 0xFF);
/* 738 */       long l4 = (readByte() & 0xFF);
/* 739 */       long l5 = (readByte() & 0xFF);
/* 740 */       long l6 = (readByte() & 0xFF);
/* 741 */       long l7 = (readByte() & 0xFF);
/* 742 */       long l8 = (readByte() & 0xFF);
/* 743 */       l = l1 << 56L | l2 << 48L | l3 << 40L | l4 << 32L | l5 << 24L | l6 << 16L | l7 << 8L | l8;
/*     */     } 
/* 745 */     return l;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void readBuffer(byte[] paramArrayOfbyte, int paramInt1, int paramInt2) throws IOException, InterruptedException {
/* 758 */     if (this.currentNSPacketDataBuffer.remaining() >= paramInt2) {
/*     */       
/* 760 */       this.currentNSPacketDataBuffer.get(paramArrayOfbyte, paramInt1, paramInt2);
/*     */     }
/*     */     else {
/*     */       
/* 764 */       boolean bool = false;
/* 765 */       int i = 0;
/* 766 */       int j = 0;
/* 767 */       int k = this.currentNSPacketDataBuffer.remaining();
/* 768 */       this.currentNSPacketDataBuffer.get(paramArrayOfbyte, paramInt1, k);
/* 769 */       paramInt1 += k;
/* 770 */       i += k;
/*     */       
/* 772 */       while (!bool) {
/*     */         
/* 774 */         getNextNSPacket();
/* 775 */         k = this.currentNSPacketDataBuffer.remaining();
/* 776 */         j = Math.min(k, paramInt2 - i);
/*     */         
/* 778 */         this.currentNSPacketDataBuffer.get(paramArrayOfbyte, paramInt1, j);
/* 779 */         paramInt1 += j;
/* 780 */         i += j;
/* 781 */         if (i == paramInt2) {
/* 782 */           bool = true;
/*     */         }
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String packetToString(ByteBuffer paramByteBuffer) throws IOException {
/* 794 */     byte b = 0;
/*     */     
/* 796 */     char[] arrayOfChar = new char[8];
/* 797 */     StringBuffer stringBuffer = new StringBuffer();
/* 798 */     int i = paramByteBuffer.position();
/*     */     
/* 800 */     while (paramByteBuffer.hasRemaining()) {
/* 801 */       byte b1 = paramByteBuffer.get();
/* 802 */       String str = Integer.toHexString(b1 & 0xFF);
/* 803 */       str = str.toUpperCase();
/* 804 */       if (str.length() == 1)
/* 805 */         str = "0" + str; 
/* 806 */       stringBuffer.append(str);
/* 807 */       stringBuffer.append(' ');
/* 808 */       if (b1 > 32 && b1 < Byte.MAX_VALUE) {
/* 809 */         arrayOfChar[b] = (char)b1;
/*     */       } else {
/* 811 */         arrayOfChar[b] = '.';
/* 812 */       }  b++;
/* 813 */       if (b == 8) {
/* 814 */         stringBuffer.append('|');
/* 815 */         stringBuffer.append(arrayOfChar);
/* 816 */         stringBuffer.append('|');
/* 817 */         stringBuffer.append('\n');
/* 818 */         b = 0;
/*     */       } 
/*     */     } 
/* 821 */     if (b != 0) {
/* 822 */       int j = 8 - b; byte b1;
/* 823 */       for (b1 = 0; b1 < j * 3; b1++)
/* 824 */         stringBuffer.append(' '); 
/* 825 */       stringBuffer.append('|');
/* 826 */       stringBuffer.append(arrayOfChar, 0, b);
/* 827 */       for (b1 = 0; b1 < j; b1++)
/* 828 */         stringBuffer.append(' '); 
/* 829 */       stringBuffer.append('|');
/* 830 */       stringBuffer.append('\n');
/*     */     } 
/* 832 */     stringBuffer.append("\nEnd of Packet\n\n");
/* 833 */     paramByteBuffer.position(i);
/* 834 */     return stringBuffer.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/* 839 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*     */   public static final String BUILD_DATE = "Thu_Apr_04_15:09:24_PDT_2013";
/*     */   public static final boolean TRACE = false;
/*     */ }


/* Location:              C:\Users\olatu\OneDrive\Documents\Calypso\syncbase\sync_base.jar!\BOOT-INF\lib\ojdbc-7.jar!\oracle\jdbc\driver\NTFConnection.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */