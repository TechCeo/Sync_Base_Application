/*     */ package oracle.jdbc.driver;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.sql.SQLException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class T4CTTIaqjms
/*     */ {
/*     */   int aqjmshdrpcnt;
/*     */   byte[] aqjmshdrprop;
/*     */   int aqjmsusrprpcnt;
/*     */   byte[] aqjmsuserprop;
/*  55 */   int aqjmsflags = 1;
/*     */   
/*     */   T4CMAREngine mar;
/*     */ 
/*     */   
/*     */   T4CTTIaqjms(T4CConnection paramT4CConnection) {
/*  61 */     this.mar = paramT4CConnection.mare;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void marshal() throws IOException {
/*  68 */     this.mar.marshalUB4(this.aqjmshdrpcnt);
/*  69 */     if (this.aqjmshdrprop != null && this.aqjmshdrprop.length != 0) {
/*     */       
/*  71 */       this.mar.marshalSWORD(this.aqjmshdrprop.length);
/*  72 */       this.mar.marshalCLR(this.aqjmshdrprop, 0, this.aqjmshdrprop.length);
/*     */     }
/*     */     else {
/*     */       
/*  76 */       this.mar.marshalSWORD(0);
/*     */     } 
/*  78 */     this.mar.marshalUB4(this.aqjmsusrprpcnt);
/*  79 */     if (this.aqjmsuserprop != null && this.aqjmsuserprop.length != 0) {
/*     */       
/*  81 */       this.mar.marshalSWORD(this.aqjmsuserprop.length);
/*  82 */       this.mar.marshalCLR(this.aqjmsuserprop, 0, this.aqjmsuserprop.length);
/*     */     }
/*     */     else {
/*     */       
/*  86 */       this.mar.marshalSWORD(0);
/*     */     } 
/*     */     
/*  89 */     this.mar.marshalUB4(this.aqjmsflags);
/*     */   }
/*     */ 
/*     */   
/*     */   void receive() throws SQLException, IOException {
/*  94 */     this.aqjmshdrpcnt = (int)this.mar.unmarshalUB4();
/*     */     
/*  96 */     int i = this.mar.unmarshalSWORD();
/*  97 */     if (i > 0) {
/*     */       
/*  99 */       this.aqjmshdrprop = new byte[i];
/* 100 */       int[] arrayOfInt = new int[1];
/* 101 */       this.mar.unmarshalCLR(this.aqjmshdrprop, 0, arrayOfInt, i);
/*     */     
/*     */     }
/*     */     else {
/*     */       
/* 106 */       this.aqjmshdrprop = null;
/*     */     } 
/* 108 */     this.aqjmsusrprpcnt = (int)this.mar.unmarshalUB4();
/*     */     
/* 110 */     int j = this.mar.unmarshalSWORD();
/* 111 */     if (j > 0) {
/*     */       
/* 113 */       this.aqjmsuserprop = new byte[j];
/* 114 */       int[] arrayOfInt = new int[1];
/* 115 */       this.mar.unmarshalCLR(this.aqjmsuserprop, 0, arrayOfInt, j);
/*     */     
/*     */     }
/*     */     else {
/*     */       
/* 120 */       this.aqjmsuserprop = null;
/*     */     } 
/*     */     
/* 123 */     this.aqjmsflags = (int)this.mar.unmarshalUB4();
/*     */   }
/*     */ }


/* Location:              C:\Users\olatu\OneDrive\Documents\Calypso\syncbase\sync_base.jar!\BOOT-INF\lib\ojdbc-7.jar!\oracle\jdbc\driver\T4CTTIaqjms.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */