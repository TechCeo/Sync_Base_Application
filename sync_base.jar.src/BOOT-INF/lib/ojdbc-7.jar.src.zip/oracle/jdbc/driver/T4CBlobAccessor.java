/*     */ package oracle.jdbc.driver;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.sql.SQLException;
/*     */ import oracle.jdbc.OracleResultSetMetaData;
/*     */ import oracle.sql.BLOB;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class T4CBlobAccessor
/*     */   extends BlobAccessor
/*     */ {
/*     */   T4CMAREngine mare;
/*     */   final int[] meta;
/*     */   
/*     */   T4CBlobAccessor(OracleStatement paramOracleStatement, int paramInt1, short paramShort, int paramInt2, boolean paramBoolean, T4CMAREngine paramT4CMAREngine) throws SQLException {
/*  41 */     super(paramOracleStatement, 4000, paramShort, paramInt2, paramBoolean);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 119 */     this.meta = new int[1]; this.mare = paramT4CMAREngine; } T4CBlobAccessor(OracleStatement paramOracleStatement, int paramInt1, boolean paramBoolean, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, short paramShort, int paramInt7, int paramInt8, T4CMAREngine paramT4CMAREngine) throws SQLException { super(paramOracleStatement, 4000, paramBoolean, paramInt2, paramInt3, paramInt4, paramInt5, paramInt6, paramShort); this.meta = new int[1];
/*     */     this.mare = paramT4CMAREngine;
/*     */     this.definedColumnType = paramInt7;
/*     */     this.definedColumnSize = paramInt8; } public T4CMAREngine getMAREngine() {
/*     */     return this.mare;
/*     */   } public void unmarshalColumnMetadata() throws SQLException, IOException {
/*     */     if (this.statement.statementType != 2 && !this.statement.sqlKind.isPlsqlOrCall() && this.securityAttribute == OracleResultSetMetaData.SecurityAttribute.ENABLED)
/*     */       setRowMetadata(this.lastRowProcessed, (byte)this.mare.unmarshalUB1()); 
/*     */   }
/* 128 */   boolean unmarshalOneRow() throws SQLException, IOException { boolean bool = false;
/* 129 */     if (!isUseless())
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 135 */       if (isUnexpected()) {
/*     */ 
/*     */         
/* 138 */         long l = this.rowData.getPosition();
/* 139 */         unmarshalColumnMetadata();
/* 140 */         unmarshalBytes();
/* 141 */         this.rowData.setPosition(l);
/* 142 */         setNull(this.lastRowProcessed, true);
/*     */       }
/* 144 */       else if (isNullByDescribe()) {
/*     */ 
/*     */         
/* 147 */         setNull(this.lastRowProcessed, true);
/* 148 */         unmarshalColumnMetadata();
/* 149 */         if (this.statement.connection.versionNumber < 9200) processIndicator(0);
/*     */       
/*     */       } else {
/*     */         
/* 153 */         unmarshalColumnMetadata();
/* 154 */         bool = unmarshalBytes();
/*     */       }  } 
/* 156 */     this.previousRowProcessed = this.lastRowProcessed;
/* 157 */     this.lastRowProcessed++;
/* 158 */     return bool; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void copyRow() throws SQLException, IOException {
/* 165 */     throw new NoSuchMethodError("oracle.jdbc.driver.T4C_lobAccessor.copyRow");
/*     */   }
/*     */   public void processIndicator(int paramInt) throws IOException, SQLException { if ((this.internalType == 1 && this.describeType == 112) || (this.internalType == 23 && this.describeType == 113)) {
/*     */       this.mare.unmarshalUB2(); this.mare.unmarshalUB2();
/*     */     } else if (this.statement.connection.versionNumber < 9200) {
/*     */       this.mare.unmarshalSB2();
/*     */       if (!this.statement.sqlKind.isPlsqlOrCall())
/*     */         this.mare.unmarshalSB2(); 
/*     */     } else if (this.statement.sqlKind.isPlsqlOrCall() || this.isDMLReturnedParam) {
/*     */       this.mare.processIndicator((paramInt <= 0), paramInt);
/*     */     }  } int getPreviousRowProcessed() { if (this.previousRowProcessed == -1)
/*     */       this.previousRowProcessed = this.statement.rowPrefetchInLastFetch - 1; 
/* 177 */     return this.previousRowProcessed; } byte[] getBytes(int paramInt) throws SQLException { if (isNull(paramInt)) return null; 
/* 178 */     if (isPrefetched()) {
/*     */       
/* 180 */       if (getPrefetchedLength(paramInt) > 2147483647L) {
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 185 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 151);
/* 186 */         sQLException.fillInStackTrace();
/* 187 */         throw sQLException;
/*     */       } 
/*     */       
/* 190 */       if (getPrefetchedDataLength(paramInt) == getPrefetchedLength(paramInt))
/*     */       {
/* 192 */         return getPrefetchedData(paramInt);
/*     */       }
/*     */       
/* 195 */       assert getPrefetchedDataLength(paramInt) <= getPrefetchedLength(paramInt) : " prefetchDataLength=" + getPrefetchedDataLength(paramInt) + " > length=" + getPrefetchedLength(paramInt);
/*     */ 
/*     */       
/* 198 */       BLOB bLOB = getBLOB(paramInt);
/* 199 */       if (bLOB == null) return null; 
/* 200 */       return bLOB.getBytes(1L, (int)getPrefetchedLength(paramInt));
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 205 */     return super.getBytes(paramInt); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean unmarshalBytes() throws IOException, SQLException {
/* 213 */     int i = (int)this.mare.unmarshalUB4();
/*     */     
/* 215 */     if (i == 0) {
/* 216 */       setNull(this.lastRowProcessed, true);
/* 217 */       processIndicator(0);
/*     */     } else {
/*     */       
/* 220 */       if (isPrefetched()) unmarshalPrefetchData(); 
/* 221 */       setOffset(this.lastRowProcessed);
/* 222 */       int j = ((DynamicByteArray)this.rowData).unmarshalCLR(this.mare);
/* 223 */       setNull(this.lastRowProcessed, (j == 0));
/* 224 */       setLength(this.lastRowProcessed, j);
/* 225 */       processIndicator(j);
/*     */     } 
/* 227 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void unmarshalPrefetchData() throws SQLException, IOException {
/* 236 */     setPrefetchedLength(this.lastRowProcessed, this.mare.unmarshalSB8());
/*     */     
/* 238 */     setPrefetchedChunkSize(this.lastRowProcessed, (int)this.mare.unmarshalUB4());
/*     */ 
/*     */     
/* 241 */     setPrefetchedDataOffset(this.lastRowProcessed);
/* 242 */     if (getPrefetchLength() > 0)
/* 243 */     { setPrefetchedDataLength(this.lastRowProcessed, ((DynamicByteArray)this.rowData).unmarshalCLR(this.mare)); }
/* 244 */     else { setPrefetchedDataLength(this.lastRowProcessed, 0); }
/*     */   
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Object getObject(int paramInt) throws SQLException {
/* 252 */     if (this.definedColumnType == 0)
/* 253 */       return super.getObject(paramInt); 
/* 254 */     if (isNull(paramInt)) return null; 
/* 255 */     if (this.definedColumnType == 2004) {
/* 256 */       return getBLOB(paramInt);
/*     */     }
/* 258 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4);
/* 259 */     sQLException.fillInStackTrace();
/* 260 */     throw sQLException;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 267 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*     */   public static final String BUILD_DATE = "Thu_Apr_04_15:09:24_PDT_2013";
/*     */   public static final boolean TRACE = false;
/*     */ }


/* Location:              C:\Users\olatu\OneDrive\Documents\Calypso\syncbase\sync_base.jar!\BOOT-INF\lib\ojdbc-7.jar!\oracle\jdbc\driver\T4CBlobAccessor.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */