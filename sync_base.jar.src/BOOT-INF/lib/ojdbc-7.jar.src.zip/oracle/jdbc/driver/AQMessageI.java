/*     */ package oracle.jdbc.driver;
/*     */ 
/*     */ import java.sql.Connection;
/*     */ import java.sql.SQLException;
/*     */ import oracle.jdbc.OracleConnection;
/*     */ import oracle.jdbc.aq.AQMessage;
/*     */ import oracle.jdbc.aq.AQMessageProperties;
/*     */ import oracle.jdbc.internal.OracleConnection;
/*     */ import oracle.jdbc.oracore.OracleTypeADT;
/*     */ import oracle.sql.ANYDATA;
/*     */ import oracle.sql.OPAQUE;
/*     */ import oracle.sql.OpaqueDescriptor;
/*     */ import oracle.sql.RAW;
/*     */ import oracle.sql.STRUCT;
/*     */ import oracle.sql.StructDescriptor;
/*     */ import oracle.sql.TypeDescriptor;
/*     */ import oracle.xdb.XMLType;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class AQMessageI
/*     */   implements AQMessage
/*     */ {
/*  64 */   private byte[] id = null;
/*  65 */   private AQMessagePropertiesI properties = null;
/*  66 */   private byte[] toid = null;
/*     */   
/*     */   private byte[] payload;
/*     */   
/*     */   private STRUCT payLoadSTRUCT;
/*     */   
/*     */   private ANYDATA payLoadANYDATA;
/*     */   
/*     */   private RAW payLoadRAW;
/*     */   private XMLType payLoadXMLType;
/*     */   private Connection conn;
/*     */   private String typeName;
/*     */   private TypeDescriptor sd;
/*     */   
/*     */   AQMessageI(AQMessagePropertiesI paramAQMessagePropertiesI, Connection paramConnection) {
/*  81 */     this.properties = paramAQMessagePropertiesI;
/*  82 */     this.conn = paramConnection;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   AQMessageI(AQMessagePropertiesI paramAQMessagePropertiesI) throws SQLException {
/*  90 */     this.properties = paramAQMessagePropertiesI;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void setTypeName(String paramString) {
/*  97 */     this.typeName = paramString;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void setTypeDescriptor(TypeDescriptor paramTypeDescriptor) {
/* 104 */     this.sd = paramTypeDescriptor;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] getMessageId() {
/* 116 */     return this.id;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void setMessageId(byte[] paramArrayOfbyte) throws SQLException {
/* 123 */     this.id = paramArrayOfbyte;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AQMessageProperties getMessageProperties() {
/* 135 */     return this.properties;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   AQMessagePropertiesI getMessagePropertiesI() {
/* 142 */     return this.properties;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setPayload(byte[] paramArrayOfbyte) throws SQLException {
/* 160 */     this.payload = paramArrayOfbyte;
/* 161 */     this.toid = TypeDescriptor.RAWTOID;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setPayload(byte[] paramArrayOfbyte1, byte[] paramArrayOfbyte2) throws SQLException {
/* 174 */     this.payload = paramArrayOfbyte1;
/* 175 */     this.toid = paramArrayOfbyte2;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setPayload(STRUCT paramSTRUCT) throws SQLException {
/* 188 */     this.payload = paramSTRUCT.toBytes();
/* 189 */     this.payLoadSTRUCT = paramSTRUCT;
/* 190 */     this.toid = paramSTRUCT.getDescriptor().getOracleTypeADT().getTOID();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setPayload(ANYDATA paramANYDATA) throws SQLException {
/* 203 */     this.payload = paramANYDATA.toDatum(this.conn).shareBytes();
/* 204 */     this.payLoadANYDATA = paramANYDATA;
/* 205 */     this.toid = TypeDescriptor.ANYDATATOID;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setPayload(RAW paramRAW) throws SQLException {
/* 217 */     this.payload = paramRAW.shareBytes();
/* 218 */     this.payLoadRAW = paramRAW;
/* 219 */     this.toid = TypeDescriptor.RAWTOID;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setPayload(XMLType paramXMLType) throws SQLException {
/* 231 */     this.payload = paramXMLType.toBytes();
/* 232 */     this.payLoadXMLType = paramXMLType;
/* 233 */     this.toid = TypeDescriptor.XMLTYPETOID;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] getPayload() {
/* 245 */     return this.payload;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RAW getRAWPayload() throws SQLException {
/* 257 */     RAW rAW = null;
/* 258 */     if (this.payLoadRAW != null) {
/* 259 */       rAW = this.payLoadRAW;
/* 260 */     } else if (isRAWPayload()) {
/*     */       
/* 262 */       this.payLoadRAW = new RAW(this.payload);
/* 263 */       rAW = this.payLoadRAW;
/*     */     }
/*     */     else {
/*     */       
/* 267 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 193);
/* 268 */       sQLException.fillInStackTrace();
/* 269 */       throw sQLException;
/*     */     } 
/* 271 */     return rAW;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isRAWPayload() throws SQLException {
/* 284 */     if (this.toid == null || this.toid.length != 16) {
/*     */       
/* 286 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 252);
/* 287 */       sQLException.fillInStackTrace();
/* 288 */       throw sQLException;
/*     */     } 
/*     */     
/* 291 */     if (compareToid(this.toid, TypeDescriptor.RAWTOID)) {
/* 292 */       return true;
/*     */     }
/* 294 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public STRUCT getSTRUCTPayload() throws SQLException {
/* 307 */     STRUCT sTRUCT = null;
/*     */     
/* 309 */     if (!isSTRUCTPayload()) {
/*     */       
/* 311 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 193);
/* 312 */       sQLException.fillInStackTrace();
/* 313 */       throw sQLException;
/*     */     } 
/*     */     
/* 316 */     if (this.payLoadSTRUCT != null) {
/* 317 */       sTRUCT = this.payLoadSTRUCT;
/*     */     } else {
/*     */       
/* 320 */       if (this.sd == null) {
/*     */         
/* 322 */         this.typeName = OracleTypeADT.toid2typename(this.conn, this.toid);
/* 323 */         this.sd = TypeDescriptor.getTypeDescriptor(this.typeName, (OracleConnection)this.conn);
/*     */       } 
/*     */       
/* 326 */       if (this.sd instanceof StructDescriptor) {
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 331 */         sTRUCT = new STRUCT((StructDescriptor)this.sd, this.payload, this.conn);
/* 332 */         this.payLoadSTRUCT = sTRUCT;
/*     */       }
/*     */       else {
/*     */         
/* 336 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 193);
/* 337 */         sQLException.fillInStackTrace();
/* 338 */         throw sQLException;
/*     */       } 
/*     */     } 
/*     */     
/* 342 */     return sTRUCT;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isSTRUCTPayload() throws SQLException {
/* 354 */     if (this.toid == null || this.toid.length != 16) {
/*     */       
/* 356 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 252);
/* 357 */       sQLException.fillInStackTrace();
/* 358 */       throw sQLException;
/*     */     } 
/*     */     
/* 361 */     boolean bool1 = true;
/*     */     
/* 363 */     boolean bool2 = true;
/* 364 */     for (byte b = 0; b < 15; b++) {
/* 365 */       if (this.toid[b] != 0) {
/*     */         
/* 367 */         bool2 = false;
/*     */         break;
/*     */       } 
/*     */     } 
/* 371 */     if (bool2 || isRAWPayload() || isANYDATAPayload()) {
/* 372 */       bool1 = false;
/*     */     }
/* 374 */     return bool1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ANYDATA getANYDATAPayload() throws SQLException {
/* 386 */     ANYDATA aNYDATA = null;
/*     */     
/* 388 */     if (this.payLoadANYDATA != null) {
/* 389 */       aNYDATA = this.payLoadANYDATA;
/* 390 */     } else if (isANYDATAPayload()) {
/*     */       
/* 392 */       OpaqueDescriptor opaqueDescriptor = OpaqueDescriptor.createDescriptor("SYS.ANYDATA", this.conn);
/*     */       
/* 394 */       OPAQUE oPAQUE = new OPAQUE(opaqueDescriptor, this.payload, this.conn);
/* 395 */       this.payLoadANYDATA = new ANYDATA(oPAQUE);
/* 396 */       aNYDATA = this.payLoadANYDATA;
/*     */     }
/*     */     else {
/*     */       
/* 400 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 193);
/* 401 */       sQLException.fillInStackTrace();
/* 402 */       throw sQLException;
/*     */     } 
/* 404 */     return aNYDATA;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isANYDATAPayload() throws SQLException {
/* 416 */     if (this.toid == null || this.toid.length != 16) {
/*     */       
/* 418 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 252);
/* 419 */       sQLException.fillInStackTrace();
/* 420 */       throw sQLException;
/*     */     } 
/* 422 */     if ((this.typeName != null && this.typeName.equals("SYS.ANYDATA")) || compareToid(this.toid, TypeDescriptor.ANYDATATOID))
/*     */     {
/* 424 */       return true;
/*     */     }
/* 426 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public XMLType getXMLTypePayload() throws SQLException {
/* 438 */     XMLType xMLType = null;
/*     */     
/* 440 */     if (this.payLoadXMLType != null) {
/* 441 */       xMLType = this.payLoadXMLType;
/* 442 */     } else if (isXMLTypePayload()) {
/*     */       
/* 444 */       OpaqueDescriptor opaqueDescriptor = OpaqueDescriptor.createDescriptor("SYS.XMLTYPE", this.conn);
/*     */       
/* 446 */       OPAQUE oPAQUE = new OPAQUE(opaqueDescriptor, this.payload, this.conn);
/* 447 */       this.payLoadXMLType = XMLType.createXML(oPAQUE);
/* 448 */       xMLType = this.payLoadXMLType;
/*     */     }
/*     */     else {
/*     */       
/* 452 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 193);
/* 453 */       sQLException.fillInStackTrace();
/* 454 */       throw sQLException;
/*     */     } 
/* 456 */     return xMLType;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isXMLTypePayload() throws SQLException {
/* 468 */     if (this.toid == null || this.toid.length != 16) {
/*     */       
/* 470 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 252);
/* 471 */       sQLException.fillInStackTrace();
/* 472 */       throw sQLException;
/*     */     } 
/* 474 */     if ((this.typeName != null && this.typeName.equals("SYS.XMLTYPE")) || compareToid(this.toid, TypeDescriptor.XMLTYPETOID))
/*     */     {
/* 476 */       return true;
/*     */     }
/* 478 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] getPayloadTOID() {
/* 485 */     return this.toid;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static boolean compareToid(byte[] paramArrayOfbyte1, byte[] paramArrayOfbyte2) {
/* 492 */     boolean bool = false;
/*     */     
/* 494 */     if (paramArrayOfbyte1 != null)
/*     */     {
/* 496 */       if (paramArrayOfbyte1 == paramArrayOfbyte2) {
/* 497 */         bool = true;
/* 498 */       } else if (paramArrayOfbyte1.length == paramArrayOfbyte2.length) {
/*     */         
/* 500 */         boolean bool1 = true;
/* 501 */         for (byte b = 0; b < paramArrayOfbyte1.length; b++) {
/* 502 */           if (paramArrayOfbyte1[b] != paramArrayOfbyte2[b]) {
/*     */             
/* 504 */             bool1 = false; break;
/*     */           } 
/*     */         } 
/* 507 */         if (bool1)
/* 508 */           bool = true; 
/*     */       } 
/*     */     }
/* 511 */     return bool;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 523 */     StringBuffer stringBuffer = new StringBuffer();
/* 524 */     stringBuffer.append("Message Properties={");
/* 525 */     stringBuffer.append(this.properties);
/* 526 */     stringBuffer.append("} ");
/* 527 */     return stringBuffer.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected OracleConnection getConnectionDuringExceptionHandling() {
/* 542 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/* 547 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*     */   public static final String BUILD_DATE = "Thu_Apr_04_15:09:24_PDT_2013";
/*     */   public static final boolean TRACE = false;
/*     */ }


/* Location:              C:\Users\olatu\OneDrive\Documents\Calypso\syncbase\sync_base.jar!\BOOT-INF\lib\ojdbc-7.jar!\oracle\jdbc\driver\AQMessageI.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */