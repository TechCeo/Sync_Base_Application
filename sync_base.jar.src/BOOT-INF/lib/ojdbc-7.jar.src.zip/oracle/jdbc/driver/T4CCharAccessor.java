/*     */ package oracle.jdbc.driver;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.sql.Connection;
/*     */ import java.sql.Date;
/*     */ import java.sql.SQLException;
/*     */ import java.sql.Time;
/*     */ import java.sql.Timestamp;
/*     */ import java.util.Calendar;
/*     */ import oracle.jdbc.OracleResultSetMetaData;
/*     */ import oracle.jdbc.internal.OracleConnection;
/*     */ import oracle.sql.DATE;
/*     */ import oracle.sql.Datum;
/*     */ import oracle.sql.NUMBER;
/*     */ import oracle.sql.RAW;
/*     */ import oracle.sql.TIMESTAMP;
/*     */ import oracle.sql.TIMESTAMPLTZ;
/*     */ import oracle.sql.TIMESTAMPTZ;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class T4CCharAccessor
/*     */   extends CharAccessor
/*     */   implements T4CAccessor
/*     */ {
/*     */   T4CMAREngine mare;
/*     */   boolean underlyingLong = false;
/*     */   private T4CMarshaller marshaller;
/*     */   
/*     */   T4CCharAccessor(OracleStatement paramOracleStatement, int paramInt1, short paramShort, int paramInt2, boolean paramBoolean, T4CMAREngine paramT4CMAREngine) throws SQLException {
/*  59 */     super(paramOracleStatement, paramInt1, paramShort, paramInt2, paramBoolean);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 703 */     this.marshaller = null; this.mare = paramT4CMAREngine; calculateSizeTmpByteArray(); } public T4CMAREngine getMAREngine() { return this.mare; } public void unmarshalColumnMetadata() throws SQLException, IOException { if (this.statement.statementType != 2 && !this.statement.sqlKind.isPlsqlOrCall() && this.securityAttribute == OracleResultSetMetaData.SecurityAttribute.ENABLED) setRowMetadata(this.lastRowProcessed, (byte)this.mare.unmarshalUB1());  } public void processIndicator(int paramInt) throws IOException, SQLException { if ((this.internalType == 1 && this.describeType == 112) || (this.internalType == 23 && this.describeType == 113)) { this.mare.unmarshalUB2(); this.mare.unmarshalUB2(); } else if (this.statement.connection.versionNumber < 9200) { this.mare.unmarshalSB2(); if (!this.statement.sqlKind.isPlsqlOrCall()) this.mare.unmarshalSB2();  } else if (this.statement.sqlKind.isPlsqlOrCall() || this.isDMLReturnedParam) { this.mare.processIndicator((paramInt <= 0), paramInt); }  } int getPreviousRowProcessed() { if (this.previousRowProcessed == -1) this.previousRowProcessed = this.statement.rowPrefetchInLastFetch - 1;  return this.previousRowProcessed; } void copyRow() throws SQLException, IOException { if (this.isNullByDescribe) { setNull(this.lastRowProcessed, true); } else if (this.lastRowProcessed == 0) { if (this.previousRowProcessed == -1) this.previousRowProcessed = this.statement.rowPrefetchInLastFetch - 1;  long l = getOffset(this.previousRowProcessed); setNull(this.lastRowProcessed, isNull(this.previousRowProcessed)); this.rowMetadata[this.lastRowProcessed] = this.rowMetadata[this.previousRowProcessed]; if (!isNull(this.previousRowProcessed)) { setOffset(this.lastRowProcessed); ((DynamicByteArray)this.rowData).copyLeft(l, getLength(this.previousRowProcessed)); setLength(this.lastRowProcessed, getLength(this.previousRowProcessed)); }  } else { setNull(this.lastRowProcessed, isNull(this.previousRowProcessed)); this.rowMetadata[this.lastRowProcessed] = this.rowMetadata[this.previousRowProcessed]; setOffset(this.lastRowProcessed, getOffset(this.previousRowProcessed)); setLength(this.lastRowProcessed, getLength(this.previousRowProcessed)); }  this.previousRowProcessed = this.lastRowProcessed; this.lastRowProcessed++; } boolean unmarshalOneRow() throws SQLException, IOException { return getMarshaller().unmarshalOneRow(this); } T4CCharAccessor(OracleStatement paramOracleStatement, int paramInt1, boolean paramBoolean, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, short paramShort, int paramInt7, int paramInt8, int paramInt9, T4CMAREngine paramT4CMAREngine) throws SQLException { super(paramOracleStatement, paramInt1, paramBoolean, paramInt2, paramInt3, paramInt4, paramInt5, paramInt6, paramShort); this.marshaller = null; this.mare = paramT4CMAREngine; this.definedColumnType = paramInt8; this.definedColumnSize = paramInt9; calculateSizeTmpByteArray(); this.oacmxl = paramInt7; if (this.oacmxl == -1) { this.underlyingLong = true; this.oacmxl = 4000; }  }
/*     */   int readStreamFromWire(byte[] paramArrayOfbyte, int paramInt1, int paramInt2, int[] paramArrayOfint, boolean[] paramArrayOfboolean1, boolean[] paramArrayOfboolean2, T4CMAREngine paramT4CMAREngine, T4CTTIoer paramT4CTTIoer) throws SQLException, IOException { return getMarshaller().readStreamFromWire(paramArrayOfbyte, paramInt1, paramInt2, paramArrayOfint, paramArrayOfboolean1, paramArrayOfboolean2, paramT4CMAREngine, paramT4CTTIoer); }
/* 705 */   NUMBER getNUMBER(int paramInt) throws SQLException { NUMBER nUMBER = null; if (this.definedColumnType == 0) { nUMBER = super.getNUMBER(paramInt); } else { String str = getString(paramInt); if (str != null) return T4CVarcharAccessor.StringToNUMBER(str.trim());  }  return nUMBER; } DATE getDATE(int paramInt) throws SQLException { DATE dATE = null; if (this.definedColumnType == 0) { dATE = super.getDATE(paramInt); } else { Date date = getDate(paramInt); if (date != null) dATE = new DATE(date);  }  return dATE; } TIMESTAMP getTIMESTAMP(int paramInt) throws SQLException { TIMESTAMP tIMESTAMP = null; if (this.definedColumnType == 0) { tIMESTAMP = super.getTIMESTAMP(paramInt); } else { String str = getString(paramInt); if (str != null) { int[] arrayOfInt = new int[1]; Calendar calendar = T4CVarcharAccessor.DATEStringToCalendar(str, (String)this.statement.connection.sessionProperties.get("AUTH_NLS_LXCSTMPFM"), arrayOfInt); Timestamp timestamp = new Timestamp(calendar.getTimeInMillis()); timestamp.setNanos(arrayOfInt[0]); tIMESTAMP = new TIMESTAMP(timestamp); }  }  return tIMESTAMP; } TIMESTAMPTZ getTIMESTAMPTZ(int paramInt) throws SQLException { TIMESTAMPTZ tIMESTAMPTZ = null; if (this.definedColumnType == 0) { tIMESTAMPTZ = super.getTIMESTAMPTZ(paramInt); } else { String str = getString(paramInt); if (str != null) { int[] arrayOfInt = new int[1]; Calendar calendar = T4CVarcharAccessor.DATEStringToCalendar(str, (String)this.statement.connection.sessionProperties.get("AUTH_NLS_LXCSTZNFM"), arrayOfInt); Timestamp timestamp = new Timestamp(calendar.getTimeInMillis()); timestamp.setNanos(arrayOfInt[0]); tIMESTAMPTZ = new TIMESTAMPTZ((Connection)this.statement.connection, timestamp, calendar); }  }  return tIMESTAMPTZ; } private final T4CMarshaller getMarshaller() { if (this.marshaller == null) this.marshaller = (this.describeType == 8) ? T4CMarshaller.LONG : T4CMarshaller.CHAR; 
/* 706 */     return this.marshaller; } TIMESTAMPLTZ getTIMESTAMPLTZ(int paramInt) throws SQLException { TIMESTAMPLTZ tIMESTAMPLTZ = null; if (this.definedColumnType == 0) { tIMESTAMPLTZ = super.getTIMESTAMPLTZ(paramInt); } else { String str = getString(paramInt); if (str != null) { int[] arrayOfInt = new int[1]; Calendar calendar = T4CVarcharAccessor.DATEStringToCalendar(str, (String)this.statement.connection.sessionProperties.get("AUTH_NLS_LXCSTZNFM"), arrayOfInt); Timestamp timestamp = new Timestamp(calendar.getTimeInMillis()); timestamp.setNanos(arrayOfInt[0]); tIMESTAMPLTZ = new TIMESTAMPLTZ((Connection)this.statement.connection, timestamp, calendar); }  }  return tIMESTAMPLTZ; } RAW getRAW(int paramInt) throws SQLException { RAW rAW = null; if (this.definedColumnType == 0) { rAW = super.getRAW(paramInt); } else if (!this.rowNull[paramInt]) { if (this.definedColumnType == -2 || this.definedColumnType == -3 || this.definedColumnType == -4) { rAW = new RAW(getBytesFromHexChars(paramInt)); } else { rAW = new RAW(getBytes(paramInt)); }  }  return rAW; }
/*     */   Datum getOracleObject(int paramInt) throws SQLException { if (this.definedColumnType == 0) return super.getOracleObject(paramInt);  Datum datum = null; if (this.rowNull == null) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21); sQLException.fillInStackTrace(); throw sQLException; }  if (!this.rowNull[paramInt]) { switch (this.definedColumnType) { case -16: case -15: case -9: case -1: case 1: case 12: return super.getOracleObject(paramInt);case -7: case -6: case -5: case 2: case 3: case 4: case 5: case 6: case 7: case 8: case 16: return (Datum)getNUMBER(paramInt);case 91: return (Datum)getDATE(paramInt);case 92: return (Datum)getDATE(paramInt);case 93: return (Datum)getTIMESTAMP(paramInt);case -101: return (Datum)getTIMESTAMPTZ(paramInt);case -102: return (Datum)getTIMESTAMPLTZ(paramInt);case -4: case -3: case -2: return (Datum)getRAW(paramInt);case -8: return (Datum)getROWID(paramInt); }  SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4); sQLException.fillInStackTrace(); throw sQLException; }  return datum; }
/*     */   byte getByte(int paramInt) throws SQLException { byte b = 0; if (this.definedColumnType == 0) { b = super.getByte(paramInt); } else { NUMBER nUMBER = getNUMBER(paramInt); if (nUMBER != null) b = nUMBER.byteValue();  }  return b; }
/*     */   int getInt(int paramInt) throws SQLException { int i = 0; if (this.definedColumnType == 0) { i = super.getInt(paramInt); } else { NUMBER nUMBER = getNUMBER(paramInt); if (nUMBER != null) i = nUMBER.intValue();  }  return i; }
/*     */   short getShort(int paramInt) throws SQLException { short s = 0; if (this.definedColumnType == 0) { s = super.getShort(paramInt); } else { NUMBER nUMBER = getNUMBER(paramInt); if (nUMBER != null) s = nUMBER.shortValue();  }  return s; }
/* 711 */   Object getObject(int paramInt) throws SQLException { if (this.definedColumnType == 0)
/* 712 */       return super.getObject(paramInt); 
/* 713 */     if (isUnexpected()) {
/* 714 */       SQLException sQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
/* 715 */       sQLException1.fillInStackTrace();
/* 716 */       throw sQLException1;
/*     */     } 
/* 718 */     if (isNull(paramInt)) return null;
/*     */     
/* 720 */     switch (this.definedColumnType) {
/*     */       
/*     */       case -16:
/*     */       case -15:
/*     */       case -9:
/*     */       case -1:
/*     */       case 1:
/*     */       case 12:
/* 728 */         return getString(paramInt);
/*     */       
/*     */       case 2:
/*     */       case 3:
/* 732 */         return getBigDecimal(paramInt);
/*     */       
/*     */       case 4:
/* 735 */         return Integer.valueOf(getInt(paramInt));
/*     */       
/*     */       case -6:
/* 738 */         return Byte.valueOf(getByte(paramInt));
/*     */       
/*     */       case 5:
/* 741 */         return Short.valueOf(getShort(paramInt));
/*     */       
/*     */       case -7:
/*     */       case 16:
/* 745 */         return Boolean.valueOf(getBoolean(paramInt));
/*     */       
/*     */       case -5:
/* 748 */         return Long.valueOf(getLong(paramInt));
/*     */       
/*     */       case 7:
/* 751 */         return Float.valueOf(getFloat(paramInt));
/*     */       
/*     */       case 6:
/*     */       case 8:
/* 755 */         return Double.valueOf(getDouble(paramInt));
/*     */       
/*     */       case 91:
/* 758 */         return getDate(paramInt);
/*     */       
/*     */       case 92:
/* 761 */         return getTime(paramInt);
/*     */       
/*     */       case 93:
/* 764 */         return getTimestamp(paramInt);
/*     */       
/*     */       case -4:
/*     */       case -3:
/*     */       case -2:
/* 769 */         return getBytesFromHexChars(paramInt);
/*     */     } 
/*     */ 
/*     */     
/* 773 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4);
/* 774 */     sQLException.fillInStackTrace();
/* 775 */     throw sQLException; } long getLong(int paramInt) throws SQLException { long l = 0L; if (this.definedColumnType == 0) { l = super.getLong(paramInt); } else { NUMBER nUMBER = getNUMBER(paramInt); if (nUMBER != null) l = nUMBER.longValue();  }  return l; }
/*     */   float getFloat(int paramInt) throws SQLException { float f = 0.0F; if (this.definedColumnType == 0) { f = super.getFloat(paramInt); } else { NUMBER nUMBER = getNUMBER(paramInt); if (nUMBER != null)
/*     */         f = nUMBER.floatValue();  }  return f; }
/*     */   double getDouble(int paramInt) throws SQLException { double d = 0.0D; if (this.definedColumnType == 0) { d = super.getDouble(paramInt); } else { NUMBER nUMBER = getNUMBER(paramInt); if (nUMBER != null)
/*     */         d = nUMBER.doubleValue();  }  return d; }
/*     */   Date getDate(int paramInt) throws SQLException { Date date = null; if (this.definedColumnType == 0) { date = super.getDate(paramInt); } else { String str = getString(paramInt); if (str != null) { int[] arrayOfInt = new int[1]; try { date = new Date(T4CVarcharAccessor.DATEStringToCalendar(str, (String)this.statement.connection.sessionProperties.get("AUTH_NLS_LXCDATEFM"), arrayOfInt).getTimeInMillis()); } catch (NumberFormatException numberFormatException) { SQLException sQLException = DatabaseError.createSqlException((OracleConnection)null, 132, (Object)null, numberFormatException); sQLException.fillInStackTrace(); throw sQLException; }  }  }  return date; }
/*     */   Timestamp getTimestamp(int paramInt) throws SQLException { Timestamp timestamp = null; if (this.definedColumnType == 0) { timestamp = super.getTimestamp(paramInt); } else { String str = getString(paramInt); if (str != null) { int[] arrayOfInt = new int[1]; try { Calendar calendar = T4CVarcharAccessor.DATEStringToCalendar(str, (String)this.statement.connection.sessionProperties.get("AUTH_NLS_LXCSTMPFM"), arrayOfInt); timestamp = new Timestamp(calendar.getTimeInMillis()); timestamp.setNanos(arrayOfInt[0]); } catch (NumberFormatException numberFormatException) { SQLException sQLException = DatabaseError.createSqlException((OracleConnection)null, 132, (Object)null, numberFormatException); sQLException.fillInStackTrace(); throw sQLException; }  }  }  return timestamp; }
/*     */   Time getTime(int paramInt) throws SQLException { Time time = null; if (this.definedColumnType == 0) { time = super.getTime(paramInt); } else { String str = getString(paramInt); if (str != null) { int[] arrayOfInt = new int[1]; try { Calendar calendar = T4CVarcharAccessor.DATEStringToCalendar(str, (String)this.statement.connection.sessionProperties.get("AUTH_NLS_LXCSTZNFM"), arrayOfInt); time = new Time(calendar.getTimeInMillis()); } catch (NumberFormatException numberFormatException) { SQLException sQLException = DatabaseError.createSqlException((OracleConnection)null, 132, (Object)null, numberFormatException); sQLException.fillInStackTrace(); throw sQLException; }  }  }  return time; }
/* 783 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*     */   public static final String BUILD_DATE = "Thu_Apr_04_15:09:24_PDT_2013";
/*     */   public static final boolean TRACE = false;
/*     */ }


/* Location:              C:\Users\olatu\OneDrive\Documents\Calypso\syncbase\sync_base.jar!\BOOT-INF\lib\ojdbc-7.jar!\oracle\jdbc\driver\T4CCharAccessor.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */