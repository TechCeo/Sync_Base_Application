/*      */ package oracle.jdbc.driver;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ class OracleParameterMetaDataParserStates
/*      */ {
/*      */   private static final int BASE = 0;
/*      */   private static final int PARAMETER = 1;
/*      */   private static final int TOKEN = 2;
/*      */   private static final int I_NSERT = 3;
/*      */   private static final int IN_SERT = 4;
/*      */   private static final int INS_ERT = 5;
/*      */   private static final int INSE_RT = 6;
/*      */   private static final int INSER_T = 7;
/*      */   private static final int INSERT_ = 8;
/*      */   private static final int U_PDATE = 9;
/*      */   private static final int UP_DATE = 10;
/*      */   private static final int UPD_ATE = 11;
/*      */   private static final int UPDA_TE = 12;
/*      */   private static final int UPDAT_E = 13;
/*      */   private static final int UPDATE_ = 14;
/*      */   private static final int KNOW_KIND = 15;
/*      */   private static final int K_STRING = 16;
/*      */   private static final int K_NAME = 17;
/*      */   public static final int K_C_COMMENT = 18;
/*      */   private static final int K_C_COMMENT_1 = 19;
/*      */   public static final int K_COMMENT = 20;
/*      */   private static final int K_PARAMETER = 21;
/*      */   private static final int TOKEN_KK = 22;
/*      */   private static final int FROM_t_W_HERE = 23;
/*      */   private static final int FROM_t_WH_ERE = 24;
/*      */   private static final int FROM_t_WHE_RE = 25;
/*      */   private static final int FROM_t_WHER_E = 26;
/*      */   private static final int FROM_t_WHERE_ = 27;
/*      */   private static final int INSERT_xINTO = 28;
/*      */   private static final int I_NTO_t_c_ = 29;
/*      */   private static final int IN_TO_t_c_ = 30;
/*      */   private static final int INT_O_t_c_ = 31;
/*      */   private static final int INTO__t_c_ = 32;
/*      */   private static final int INTO_xt_c_ = 33;
/*      */   private static final int INTO_T_c_ = 34;
/*      */   private static final int INTO_t_xc_ = 35;
/*      */   private static final int INTO_t_C_ = 36;
/*      */   private static final int INTO_t_c__ = 37;
/*      */   private static final int INTO_t_c_xBIND_ = 38;
/*      */   private static final int INTO_t_c_BIND_ = 39;
/*      */   private static final int INTO_t_c_BIND_K_PARAMETER_ = 40;
/*      */   private static final int INTO_t_c_BIND_K_STRING = 41;
/*      */   private static final int INTO_t_c_BIND_K_N_tick = 42;
/*      */   private static final int INTO_t_c_BIND_K_NCHAR = 43;
/*      */   private static final int INTO_t_c_BIND_K_NCHAR_tick = 44;
/*      */   private static final int INTO_t_c_BIND_K_Q_tick = 45;
/*      */   private static final int INTO_t_c_BIND_K_QTick_ = 46;
/*      */   private static final int INTO_t_c_BIND_K_QTick_char = 47;
/*      */   private static final int INTO_t_c_BIND_K_QTick_char_tick = 48;
/*      */   private static final int UPDATE_xt_SET_c_ = 49;
/*      */   private static final int UPDATE_T_SET_c_ = 50;
/*      */   private static final int UPDATE_t_xSET_c_ = 51;
/*      */   private static final int UPDATE_t_S_ET_c_ = 52;
/*      */   private static final int UPDATE_t_SE_T_c_ = 53;
/*      */   private static final int F_ROM_t_WHERE = 54;
/*      */   private static final int FR_OM_t_WHERE = 55;
/*      */   private static final int FRO_M_t_WHERE = 56;
/*      */   private static final int FROM__t_WHERE = 57;
/*      */   private static final int FROM_xt_WHERE = 58;
/*      */   private static final int FROM_T_WHERE = 59;
/*      */   private static final int FROM_t_COMMA_WHERE = 60;
/*      */   private static final int FROM_t_xWHERE = 61;
/*      */   private static final int XXX_W_HERE_c_op_bind_ = 62;
/*      */   private static final int XXX_WH_ERE_c_op_bind_ = 63;
/*      */   private static final int XXX_WHE_RE_c_op_bind_ = 64;
/*      */   private static final int XXX_WHER_E_c_op_bind_ = 65;
/*      */   private static final int XXX_WHERE__c_op_bind_ = 66;
/*      */   private static final int XXX__c_op_bind_ = 67;
/*      */   public static final int XXX_xc_op_bind_ = 68;
/*      */   private static final int XXX_C_op_bind_ = 69;
/*      */   private static final int XXX_c__op_bind_ = 70;
/*      */   private static final int XXX_c_I_S_NOT_NULL_ = 71;
/*      */   private static final int XXX_c_IS__NOT_NULL_ = 72;
/*      */   private static final int XXX_c_IS_xNOT_NULL_ = 73;
/*      */   private static final int XXX_c_IS_N_OT_NULL_ = 74;
/*      */   private static final int XXX_c_IS_NO_T_NULL_ = 75;
/*      */   private static final int XXX_c_IS_NOT__NULL_ = 76;
/*      */   private static final int XXX_c_IS_NOT_xNULL_ = 77;
/*      */   private static final int XXX_c_IS_NOT_N_ULL_ = 78;
/*      */   private static final int XXX_c_IS_NOT_NU_LL_ = 79;
/*      */   private static final int XXX_c_IS_NOT_NUL_L_ = 80;
/*      */   private static final int XXX_c_IS_NOT_NULL__ = 81;
/*      */   private static final int XXX_c_xop_bind_ = 82;
/*      */   private static final int XXX_c_OP_bind_ = 83;
/*      */   private static final int XXX_c_OP2_bind_ = 84;
/*      */   private static final int XXX_c_op__bind_ = 85;
/*      */   private static final int XXX_c_op_BIND_ = 86;
/*      */   private static final int XXX__c_op_xbind_O_R_ = 87;
/*      */   private static final int XXX__c_op_xbind_OR__ = 88;
/*      */   private static final int XXX__c_op_xbind_A_ND_ = 89;
/*      */   private static final int XXX__c_op_xbind_AN_D_ = 90;
/*      */   private static final int XXX__c_op_xbind_AND__ = 91;
/*      */   private static final int XXX_c_op_K_STRING = 92;
/*      */   private static final int XXX_c_op_K_N_tick = 93;
/*      */   private static final int XXX_c_op_K_NCHAR = 94;
/*      */   private static final int XXX_c_op_K_NCHAR_tick = 95;
/*      */   private static final int SKIP_PARAMETER_WHITESPACE = 96;
/*      */   private static final int LAST_STATE = 97;
/*  760 */   public static final String[] PARSER_STATE_NAME = new String[] { "BASE", "PARAMETER", "TOKEN", "I_NSERT", "IN_SERT", "INS_ERT", "INSE_RT", "INSER_T", "INSERT_", "U_PDATE", "UP_DATE", "UPD_ATE", "UPDA_TE", "UPDAT_E", "UPDATE_", "KNOW_KIND", "K_STRING", "K_NAME", "K_C_COMMENT", "K_C_COMMENT_1", "K_COMMENT", "K_PARAMETER", "TOKEN_KK", "FROM_t_W_HERE", "FROM_t_WH_ERE", "FROM_t_WHE_RE", "FROM_t_WHER_E", "FROM_t_WHERE_", "INSERT_xINTO", "I_NTO_t_c_", "IN_TO_t_c_", "INT_O_t_c_", "INTO__t_c_", "INTO_xt_c_", "INTO_T_c_", "INTO_t_xc_", "INTO_t_C_", "INTO_t_c__", "INTO_t_c_xBIND_", "INTO_t_c_BIND_", "INTO_t_c_BIND_K_PARAMETER_", "INTO_t_c_BIND_K_STRING", "INTO_t_c_BIND_K_N_tick", "INTO_t_c_BIND_K_NCHAR", "INTO_t_c_BIND_K_NCHAR_tick", "INTO_t_c_BIND_K_Q_tick", "INTO_t_c_BIND_K_QTick_", "INTO_t_c_BIND_K_QTick_char", "INTO_t_c_BIND_K_QTick_char_tick", "UPDATE_xt_SET_c_", "UPDATE_T_SET_c_", "UPDATE_t_xSET_c_", "UPDATE_t_S_ET_c_", "UPDATE_t_SE_T_c_", "F_ROM_t_WHERE", "FR_OM_t_WHERE", "FRO_M_t_WHERE", "FROM__t_WHERE", "FROM_xt_WHERE", "FROM_T_WHERE", "FROM_t_COMMA_WHERE", "FROM_t_xWHERE", "XXX_W_HERE_c_op_bind_", "XXX_WH_ERE_c_op_bind_", "XXX_WHE_RE_c_op_bind_", "XXX_WHER_E_c_op_bind_", "XXX_WHERE__c_op_bind_", "XXX__c_op_bind_", "XXX_xc_op_bind_", "XXX_C_op_bind_", "XXX_c__op_bind_", "XXX_c_I_S_NOT_NULL_", "XXX_c_IS__NOT_NULL_", "XXX_c_IS_xNOT_NULL_", "XXX_c_IS_N_OT_NULL_", "XXX_c_IS_NO_T_NULL_", "XXX_c_IS_NOT__NULL_", "XXX_c_IS_NOT_xNULL_", "XXX_c_IS_NOT_N_ULL_", "XXX_c_IS_NOT_NU_LL_", "XXX_c_IS_NOT_NUL_L_", "XXX_c_IS_NOT_NULL__", "XXX_c_xop_bind_", "XXX_c_OP_bind_", "XXX_c_OP2_bind_", "XXX_c_op__bind_", "XXX_c_op_BIND_", "XXX__c_op_xbind_O_R_", "XXX__c_op_xbind_OR__", "XXX__c_op_xbind_A_ND_", "XXX__c_op_xbind_AN_D_", "XXX__c_op_xbind_AND__", "XXX_c_op_K_STRING", "XXX_c_op_K_N_tick", "XXX_c_op_K_NCHAR", "XXX_c_op_K_NCHAR_tick", "SKIP_PARAMETER_WHITESPACE" };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  860 */   static final int[][] TRANSITION = new int[97][];
/*      */   
/*      */   static final int NO_ACTION = 0;
/*      */   
/*      */   static final int OTHER_ACTION = 1;
/*      */   
/*      */   static final int WHERE_ACTION = 2;
/*      */   static final int PARAMETER_ACTION = 3;
/*      */   static final int END_PARAMETER_ACTION = 4;
/*      */   static final int COUNT_BIND_ACTION = 5;
/*      */   static final int START_NCHAR_LITERAL_ACTION = 6;
/*      */   static final int END_NCHAR_LITERAL_ACTION = 7;
/*      */   static final int SAVE_DELIMITER_ACTION = 8;
/*      */   static final int LOOK_FOR_DELIMITER_ACTION = 9;
/*      */   static final int RECORD_TABLE_NAME_ACTION = 10;
/*      */   static final int END_RECORD_TABLE_NAME_ACTION = 11;
/*      */   static final int DONE_RECORD_TABLE_NAME_ACTION = 12;
/*      */   static final int START_RECORD_COLUMN_NAME_ACTION = 13;
/*      */   static final int RECORD_COLUMN_NAME_ACTION = 14;
/*      */   static final int END_RECORD_COLUMN_NAME_ACTION = 15;
/*      */   static final int DONE_RECORD_COLUMN_NAME_ACTION = 16;
/*      */   static final int NO_PARAMETER_METADATA_ACTION = 17;
/*      */   static final int BEGIN_COMMENT_ACTION = 18;
/*      */   static final int END_COMMENT_ACTION = 19;
/*      */   static final int RESET_RECORDING_ACTION = 20;
/*  885 */   public static final String[] CBI_ACTION_NAME = new String[] { "NO_ACTION", "OTHER_ACTION", "WHERE_ACTION", "PARAMETER_ACTION", "END_PARAMETER_ACTION", "COUNT_BIND_ACTION", "START_NCHAR_LITERAL_ACTION", "END_NCHAR_LITERAL_ACTION", "SAVE_DELIMITER_ACTION", "LOOK_FOR_DELIMITER_ACTION", "RECORD_TABLE_NAME_ACTION", "END_RECORD_TABLE_NAME_ACTION", "DONE_RECORD_TABLE_NAME_ACTION", "START_RECORD_COLUMN_NAME_ACTION", "RECORD_COLUMN_NAME_ACTION", "END_RECORD_COLUMN_NAME_ACTION", "DONE_RECORD_COLUMN_NAME_ACTION", "NO_PARAMETER_METADATA_ACTION", "BEGIN_COMMENT_ACTION", "END_COMMENT_ACTION", "RESET_RECORDING_ACTION" };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  909 */   static final int[][] ACTION = new int[97][];
/*      */   
/*      */   static final int INITIAL_STATE = 0;
/*      */   
/*      */   static final int RESTART_STATE = 22;
/*      */   
/*      */   static final int cMax = 127;
/*      */   
/*      */   private static final int cMaxLength = 128;
/*      */   
/*      */   private static final int[] copy(int[] paramArrayOfint) {
/*  920 */     int[] arrayOfInt = new int[paramArrayOfint.length];
/*  921 */     System.arraycopy(paramArrayOfint, 0, arrayOfInt, 0, paramArrayOfint.length);
/*  922 */     return arrayOfInt;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private static final int[] newArray(int paramInt1, int paramInt2) {
/*  928 */     int[] arrayOfInt = new int[paramInt1];
/*      */     
/*  930 */     for (byte b = 0; b < paramInt1; b++) {
/*  931 */       arrayOfInt[b] = paramInt2;
/*      */     }
/*  933 */     return arrayOfInt;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private static final int[] copyReplacing(int[] paramArrayOfint, int paramInt1, int paramInt2) {
/*  939 */     int[] arrayOfInt = new int[paramArrayOfint.length];
/*      */     
/*  941 */     for (byte b = 0; b < arrayOfInt.length; b++) {
/*      */       
/*  943 */       int i = paramArrayOfint[b];
/*      */       
/*  945 */       if (i == paramInt1) {
/*  946 */         arrayOfInt[b] = paramInt2;
/*      */       } else {
/*  948 */         arrayOfInt[b] = i;
/*      */       } 
/*      */     } 
/*  951 */     return arrayOfInt;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static final int[] copyReplacing(int[] paramArrayOfint, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/*  960 */     int[] arrayOfInt = new int[paramArrayOfint.length];
/*      */     
/*  962 */     for (byte b = 0; b < arrayOfInt.length; b++) {
/*      */       
/*  964 */       int i = paramArrayOfint[b];
/*      */       
/*  966 */       if (i == paramInt1) {
/*  967 */         arrayOfInt[b] = paramInt2;
/*  968 */       } else if (i == paramInt3) {
/*  969 */         arrayOfInt[b] = paramInt4;
/*      */       } else {
/*  971 */         arrayOfInt[b] = i;
/*      */       } 
/*      */     } 
/*  974 */     return arrayOfInt;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static {
/*      */     try {
/*  989 */       int[] arrayOfInt1 = { 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 2, 2, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 15, 15, 15, 15, 15, 15, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 15, 15, 15, 15, 2, 15, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 15, 15, 15, 15, 15 };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1026 */       int[] arrayOfInt2 = copy(arrayOfInt1);
/* 1027 */       arrayOfInt2[45] = 20;
/* 1028 */       arrayOfInt2[47] = 18;
/* 1029 */       arrayOfInt2[58] = 1;
/*      */ 
/*      */ 
/*      */       
/* 1033 */       int[] arrayOfInt3 = copyReplacing(arrayOfInt2, 15, 0);
/* 1034 */       arrayOfInt3[73] = 3;
/* 1035 */       arrayOfInt3[105] = 3;
/* 1036 */       arrayOfInt3[85] = 9;
/* 1037 */       arrayOfInt3[117] = 9;
/*      */ 
/*      */ 
/*      */       
/* 1041 */       int[] arrayOfInt4 = copyReplacing(arrayOfInt2, 2, 22);
/* 1042 */       arrayOfInt4[34] = 17;
/* 1043 */       arrayOfInt4[39] = 16;
/* 1044 */       arrayOfInt4[45] = 20;
/* 1045 */       arrayOfInt4[47] = 18;
/* 1046 */       arrayOfInt4[58] = 96;
/* 1047 */       arrayOfInt4[32] = 15;
/* 1048 */       arrayOfInt4[32] = 15;
/* 1049 */       arrayOfInt4[9] = 15;
/* 1050 */       arrayOfInt4[10] = 15;
/* 1051 */       arrayOfInt4[13] = 15;
/* 1052 */       arrayOfInt4[61] = 15;
/*      */ 
/*      */       
/* 1055 */       int[] arrayOfInt5 = copyReplacing(arrayOfInt4, 2, 22);
/* 1056 */       arrayOfInt5[70] = 54;
/* 1057 */       arrayOfInt5[102] = 54;
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1062 */       TRANSITION[0] = arrayOfInt3;
/* 1063 */       TRANSITION[1] = copyReplacing(arrayOfInt2, 2, 1);
/* 1064 */       TRANSITION[2] = arrayOfInt2;
/*      */       
/* 1066 */       TRANSITION[3] = copy(arrayOfInt2);
/* 1067 */       TRANSITION[3][78] = 4;
/* 1068 */       TRANSITION[3][110] = 4;
/* 1069 */       TRANSITION[4] = copy(arrayOfInt2);
/* 1070 */       TRANSITION[4][83] = 5;
/* 1071 */       TRANSITION[4][115] = 5;
/* 1072 */       TRANSITION[5] = copy(arrayOfInt2);
/* 1073 */       TRANSITION[5][69] = 6;
/* 1074 */       TRANSITION[5][101] = 6;
/* 1075 */       TRANSITION[6] = copy(arrayOfInt2);
/* 1076 */       TRANSITION[6][82] = 7;
/* 1077 */       TRANSITION[6][114] = 7;
/* 1078 */       TRANSITION[7] = copy(arrayOfInt2);
/* 1079 */       TRANSITION[7][84] = 8;
/* 1080 */       TRANSITION[7][116] = 8;
/* 1081 */       TRANSITION[8] = copyReplacing(arrayOfInt4, 15, 28);
/*      */       
/* 1083 */       TRANSITION[9] = copy(arrayOfInt2);
/* 1084 */       TRANSITION[9][80] = 10;
/* 1085 */       TRANSITION[9][112] = 10;
/* 1086 */       TRANSITION[10] = copy(arrayOfInt2);
/* 1087 */       TRANSITION[10][68] = 11;
/* 1088 */       TRANSITION[10][100] = 11;
/* 1089 */       TRANSITION[11] = copy(arrayOfInt2);
/* 1090 */       TRANSITION[11][65] = 12;
/* 1091 */       TRANSITION[11][97] = 12;
/* 1092 */       TRANSITION[12] = copy(arrayOfInt2);
/* 1093 */       TRANSITION[12][84] = 13;
/* 1094 */       TRANSITION[12][116] = 13;
/* 1095 */       TRANSITION[13] = copy(arrayOfInt2);
/* 1096 */       TRANSITION[13][69] = 14;
/* 1097 */       TRANSITION[13][101] = 14;
/* 1098 */       TRANSITION[14] = copyReplacing(arrayOfInt5, 15, 49, 22, 50);
/*      */ 
/*      */       
/* 1101 */       TRANSITION[14][47] = 18;
/* 1102 */       TRANSITION[14][45] = 20;
/*      */ 
/*      */       
/* 1105 */       TRANSITION[22] = arrayOfInt4;
/* 1106 */       TRANSITION[18] = newArray(128, 18);
/* 1107 */       TRANSITION[18][42] = 19;
/* 1108 */       TRANSITION[19] = newArray(128, 18);
/* 1109 */       TRANSITION[19][42] = 19;
/* 1110 */       TRANSITION[19][47] = 15;
/* 1111 */       TRANSITION[20] = newArray(128, 20);
/* 1112 */       TRANSITION[20][10] = 15;
/* 1113 */       TRANSITION[17] = newArray(128, 17);
/* 1114 */       TRANSITION[17][34] = 15;
/* 1115 */       TRANSITION[16] = newArray(128, 16);
/* 1116 */       TRANSITION[16][39] = 15;
/* 1117 */       TRANSITION[21] = copyReplacing(arrayOfInt4, 22, 21, 15, 68);
/*      */ 
/*      */       
/* 1120 */       TRANSITION[21][47] = 18;
/* 1121 */       TRANSITION[21][45] = 20;
/*      */       
/* 1123 */       TRANSITION[96] = copyReplacing(arrayOfInt4, 22, 21);
/* 1124 */       TRANSITION[96][32] = 96;
/* 1125 */       TRANSITION[96][10] = 96;
/* 1126 */       TRANSITION[96][13] = 96;
/* 1127 */       TRANSITION[96][9] = 96;
/*      */       
/* 1129 */       TRANSITION[28] = copyReplacing(arrayOfInt4, 15, 28);
/* 1130 */       TRANSITION[28][73] = 29;
/* 1131 */       TRANSITION[28][105] = 29;
/* 1132 */       TRANSITION[28][47] = 18;
/* 1133 */       TRANSITION[28][45] = 20;
/*      */       
/* 1135 */       TRANSITION[29] = copy(arrayOfInt4);
/* 1136 */       TRANSITION[29][78] = 30;
/* 1137 */       TRANSITION[29][110] = 30;
/* 1138 */       TRANSITION[30] = copy(arrayOfInt4);
/* 1139 */       TRANSITION[30][84] = 31;
/* 1140 */       TRANSITION[30][116] = 31;
/* 1141 */       TRANSITION[31] = copy(arrayOfInt4);
/* 1142 */       TRANSITION[31][79] = 32;
/* 1143 */       TRANSITION[31][111] = 32;
/*      */       
/* 1145 */       TRANSITION[32] = copyReplacing(arrayOfInt5, 15, 33);
/* 1146 */       TRANSITION[32][47] = 18;
/* 1147 */       TRANSITION[32][45] = 20;
/* 1148 */       TRANSITION[32][40] = 15;
/*      */       
/* 1150 */       TRANSITION[33] = copyReplacing(arrayOfInt4, 22, 34, 15, 33);
/*      */ 
/*      */       
/* 1153 */       TRANSITION[33][40] = 15;
/* 1154 */       TRANSITION[33][47] = 18;
/* 1155 */       TRANSITION[33][45] = 20;
/*      */ 
/*      */ 
/*      */       
/* 1159 */       TRANSITION[34] = copyReplacing(arrayOfInt4, 22, 34, 15, 38);
/*      */       
/* 1161 */       TRANSITION[34][47] = 18;
/* 1162 */       TRANSITION[34][45] = 20;
/* 1163 */       TRANSITION[34][40] = 36;
/* 1164 */       TRANSITION[34][32] = 35;
/* 1165 */       TRANSITION[34][10] = 35;
/* 1166 */       TRANSITION[34][9] = 35;
/* 1167 */       TRANSITION[34][13] = 35;
/*      */       
/* 1169 */       TRANSITION[35] = newArray(128, 38);
/* 1170 */       TRANSITION[35][40] = 36;
/* 1171 */       TRANSITION[35][47] = 18;
/*      */       
/* 1173 */       TRANSITION[35][45] = 20;
/*      */       
/* 1175 */       TRANSITION[36] = newArray(128, 36);
/* 1176 */       TRANSITION[36][44] = 36;
/* 1177 */       TRANSITION[36][41] = 37;
/*      */       
/* 1179 */       TRANSITION[37] = copyReplacing(arrayOfInt4, 22, 38, 15, 39);
/*      */ 
/*      */       
/* 1182 */       TRANSITION[38] = copyReplacing(arrayOfInt4, 22, 38, 15, 39);
/*      */ 
/*      */       
/* 1185 */       TRANSITION[38][40] = 39;
/*      */       
/* 1187 */       TRANSITION[39] = newArray(128, 39);
/* 1188 */       TRANSITION[39][58] = 40;
/* 1189 */       TRANSITION[39][78] = 42;
/* 1190 */       TRANSITION[39][110] = 42;
/* 1191 */       TRANSITION[39][81] = 45;
/* 1192 */       TRANSITION[39][113] = 45;
/* 1193 */       TRANSITION[39][39] = 41;
/*      */       
/* 1195 */       TRANSITION[40] = copyReplacing(arrayOfInt4, 22, 40, 15, 39);
/*      */ 
/*      */       
/* 1198 */       TRANSITION[40][44] = 39;
/*      */ 
/*      */       
/* 1201 */       TRANSITION[41] = newArray(128, 41);
/*      */       
/* 1203 */       TRANSITION[41][39] = 39;
/*      */       
/* 1205 */       TRANSITION[42] = copyReplacing(arrayOfInt4, 22, 39);
/*      */       
/* 1207 */       TRANSITION[42][39] = 43;
/*      */       
/* 1209 */       TRANSITION[43] = newArray(128, 43);
/*      */       
/* 1211 */       TRANSITION[43][39] = 44;
/*      */       
/* 1213 */       TRANSITION[44] = newArray(128, 39);
/*      */       
/* 1215 */       TRANSITION[44][39] = 43;
/*      */       
/* 1217 */       TRANSITION[45] = newArray(128, 39);
/*      */       
/* 1219 */       TRANSITION[45][39] = 46;
/* 1220 */       TRANSITION[46] = newArray(128, 47);
/*      */       
/* 1222 */       TRANSITION[47] = newArray(128, 47);
/*      */       
/* 1224 */       TRANSITION[48] = newArray(128, 47);
/* 1225 */       TRANSITION[48][39] = 15;
/*      */ 
/*      */       
/* 1228 */       TRANSITION[49] = copyReplacing(arrayOfInt5, 15, 49, 22, 50);
/*      */ 
/*      */       
/* 1231 */       TRANSITION[49][40] = 15;
/* 1232 */       TRANSITION[49][47] = 18;
/* 1233 */       TRANSITION[49][45] = 20;
/*      */       
/* 1235 */       TRANSITION[50] = copyReplacing(arrayOfInt4, 22, 50, 15, 51);
/*      */ 
/*      */ 
/*      */       
/* 1239 */       TRANSITION[50][47] = 18;
/* 1240 */       TRANSITION[50][45] = 20;
/*      */       
/* 1242 */       TRANSITION[51] = copyReplacing(arrayOfInt5, 15, 51);
/* 1243 */       TRANSITION[51][83] = 52;
/* 1244 */       TRANSITION[51][115] = 52;
/* 1245 */       TRANSITION[51][47] = 18;
/*      */       
/* 1247 */       TRANSITION[51][45] = 20;
/*      */       
/* 1249 */       TRANSITION[52] = copy(arrayOfInt5);
/* 1250 */       TRANSITION[52][69] = 53;
/* 1251 */       TRANSITION[52][101] = 53;
/*      */       
/* 1253 */       TRANSITION[53] = copy(arrayOfInt5);
/* 1254 */       TRANSITION[53][84] = 67;
/* 1255 */       TRANSITION[53][116] = 67;
/*      */ 
/*      */       
/* 1258 */       TRANSITION[54] = copy(arrayOfInt5);
/* 1259 */       TRANSITION[54][114] = 55;
/* 1260 */       TRANSITION[54][82] = 55;
/*      */       
/* 1262 */       TRANSITION[55] = copy(arrayOfInt5);
/* 1263 */       TRANSITION[55][111] = 56;
/* 1264 */       TRANSITION[55][79] = 56;
/*      */       
/* 1266 */       TRANSITION[56] = copy(arrayOfInt5);
/* 1267 */       TRANSITION[56][109] = 57;
/* 1268 */       TRANSITION[56][77] = 57;
/*      */       
/* 1270 */       TRANSITION[57] = copyReplacing(arrayOfInt2, 2, 59, 15, 58);
/*      */ 
/*      */       
/* 1273 */       TRANSITION[57][47] = 18;
/* 1274 */       TRANSITION[57][45] = 20;
/*      */       
/* 1276 */       TRANSITION[58] = copyReplacing(arrayOfInt5, 15, 58, 22, 59);
/*      */ 
/*      */       
/* 1279 */       TRANSITION[58][40] = 15;
/* 1280 */       TRANSITION[58][47] = 18;
/*      */       
/* 1282 */       TRANSITION[58][45] = 20;
/*      */       
/* 1284 */       TRANSITION[59] = copyReplacing(arrayOfInt5, 15, 59, 22, 59);
/*      */ 
/*      */       
/* 1287 */       TRANSITION[59][44] = 60;
/* 1288 */       TRANSITION[59][119] = 23;
/* 1289 */       TRANSITION[59][87] = 23;
/* 1290 */       TRANSITION[59][47] = 18;
/* 1291 */       TRANSITION[59][45] = 20;
/* 1292 */       TRANSITION[59][40] = 15;
/* 1293 */       TRANSITION[60] = copyReplacing(arrayOfInt5, 15, 57);
/*      */ 
/*      */       
/* 1296 */       TRANSITION[61] = copy(arrayOfInt5);
/* 1297 */       TRANSITION[61][47] = 18;
/* 1298 */       TRANSITION[61][45] = 20;
/*      */       
/* 1300 */       TRANSITION[61][87] = 23;
/* 1301 */       TRANSITION[61][119] = 23;
/*      */       
/* 1303 */       TRANSITION[23] = copyReplacing(arrayOfInt4, 15, 59, 22, 59);
/*      */ 
/*      */       
/* 1306 */       TRANSITION[23][72] = 24;
/* 1307 */       TRANSITION[23][104] = 24;
/* 1308 */       TRANSITION[24] = copyReplacing(arrayOfInt4, 15, 59, 22, 59);
/*      */ 
/*      */       
/* 1311 */       TRANSITION[24][69] = 25;
/* 1312 */       TRANSITION[24][101] = 25;
/* 1313 */       TRANSITION[25] = copyReplacing(arrayOfInt4, 15, 59, 22, 59);
/*      */ 
/*      */       
/* 1316 */       TRANSITION[25][82] = 26;
/* 1317 */       TRANSITION[25][114] = 26;
/* 1318 */       TRANSITION[26] = copyReplacing(arrayOfInt4, 15, 59, 22, 59);
/*      */ 
/*      */       
/* 1321 */       TRANSITION[26][69] = 27;
/* 1322 */       TRANSITION[26][101] = 27;
/* 1323 */       TRANSITION[27] = copyReplacing(arrayOfInt5, 15, 67, 22, 59);
/*      */ 
/*      */       
/* 1326 */       TRANSITION[27][47] = 18;
/* 1327 */       TRANSITION[27][45] = 20;
/*      */ 
/*      */       
/* 1330 */       TRANSITION[67] = copyReplacing(arrayOfInt5, 15, 68, 22, 69);
/*      */ 
/*      */       
/* 1333 */       TRANSITION[67][47] = 18;
/* 1334 */       TRANSITION[67][45] = 20;
/*      */       
/* 1336 */       TRANSITION[62] = copyReplacing(arrayOfInt5, 15, 68, 22, 69);
/*      */ 
/*      */       
/* 1339 */       TRANSITION[62][104] = 63;
/* 1340 */       TRANSITION[62][72] = 63;
/*      */       
/* 1342 */       TRANSITION[63] = copyReplacing(arrayOfInt5, 15, 68, 22, 69);
/*      */ 
/*      */       
/* 1345 */       TRANSITION[63][101] = 64;
/* 1346 */       TRANSITION[63][69] = 64;
/*      */       
/* 1348 */       TRANSITION[64] = copyReplacing(arrayOfInt5, 15, 68, 22, 69);
/*      */ 
/*      */       
/* 1351 */       TRANSITION[64][114] = 65;
/* 1352 */       TRANSITION[64][82] = 65;
/*      */       
/* 1354 */       TRANSITION[65] = copyReplacing(arrayOfInt5, 15, 68, 22, 69);
/*      */ 
/*      */       
/* 1357 */       TRANSITION[65][101] = 66;
/* 1358 */       TRANSITION[65][69] = 66;
/*      */       
/* 1360 */       TRANSITION[66] = copyReplacing(arrayOfInt5, 15, 68, 22, 69);
/*      */ 
/*      */ 
/*      */       
/* 1364 */       TRANSITION[68] = copyReplacing(arrayOfInt5, 15, 68, 22, 69);
/*      */ 
/*      */       
/* 1367 */       TRANSITION[68][79] = 87;
/* 1368 */       TRANSITION[68][111] = 87;
/* 1369 */       TRANSITION[68][65] = 89;
/* 1370 */       TRANSITION[68][97] = 89;
/* 1371 */       TRANSITION[68][87] = 62;
/* 1372 */       TRANSITION[68][119] = 62;
/* 1373 */       TRANSITION[68][47] = 18;
/* 1374 */       TRANSITION[68][45] = 20;
/* 1375 */       TRANSITION[87] = copyReplacing(arrayOfInt4, 22, 69);
/*      */       
/* 1377 */       TRANSITION[87][82] = 88;
/* 1378 */       TRANSITION[87][114] = 88;
/*      */       
/* 1380 */       TRANSITION[88] = copyReplacing(arrayOfInt4, 22, 69, 15, 68);
/*      */ 
/*      */       
/* 1383 */       TRANSITION[88][47] = 18;
/* 1384 */       TRANSITION[88][45] = 20;
/*      */       
/* 1386 */       TRANSITION[89] = copyReplacing(arrayOfInt4, 22, 69);
/*      */       
/* 1388 */       TRANSITION[89][78] = 90;
/* 1389 */       TRANSITION[89][110] = 90;
/*      */       
/* 1391 */       TRANSITION[90] = copyReplacing(arrayOfInt4, 22, 69);
/*      */       
/* 1393 */       TRANSITION[90][68] = 91;
/* 1394 */       TRANSITION[90][100] = 91;
/*      */       
/* 1396 */       TRANSITION[91] = copyReplacing(arrayOfInt4, 22, 69, 15, 68);
/*      */ 
/*      */       
/* 1399 */       TRANSITION[91][47] = 18;
/* 1400 */       TRANSITION[91][45] = 20;
/*      */       
/* 1402 */       TRANSITION[69] = copyReplacing(arrayOfInt4, 22, 69, 15, 82);
/*      */ 
/*      */       
/* 1405 */       TRANSITION[69][47] = 18;
/* 1406 */       TRANSITION[69][45] = 20;
/* 1407 */       TRANSITION[69][62] = 83;
/* 1408 */       TRANSITION[69][60] = 83;
/* 1409 */       TRANSITION[69][61] = 83;
/* 1410 */       TRANSITION[69][46] = 69;
/*      */       
/* 1412 */       TRANSITION[70] = copyReplacing(arrayOfInt4, 22, 67, 15, 82);
/*      */ 
/*      */       
/* 1415 */       TRANSITION[70][105] = 71;
/* 1416 */       TRANSITION[70][73] = 71;
/*      */       
/* 1418 */       TRANSITION[82] = copyReplacing(arrayOfInt5, 15, 82, 22, 69);
/*      */ 
/*      */       
/* 1421 */       TRANSITION[82][105] = 71;
/* 1422 */       TRANSITION[82][73] = 71;
/* 1423 */       TRANSITION[82][47] = 18;
/* 1424 */       TRANSITION[82][45] = 20;
/* 1425 */       TRANSITION[82][105] = 71;
/* 1426 */       TRANSITION[82][73] = 71;
/* 1427 */       TRANSITION[82][62] = 83;
/* 1428 */       TRANSITION[82][60] = 83;
/* 1429 */       TRANSITION[82][61] = 83;
/* 1430 */       TRANSITION[82][63] = 86;
/*      */ 
/*      */       
/* 1433 */       TRANSITION[71] = copy(arrayOfInt4);
/* 1434 */       TRANSITION[71][83] = 72;
/* 1435 */       TRANSITION[71][115] = 72;
/*      */       
/* 1437 */       TRANSITION[72] = copyReplacing(arrayOfInt5, 15, 73);
/* 1438 */       TRANSITION[72][47] = 18;
/* 1439 */       TRANSITION[72][45] = 20;
/* 1440 */       TRANSITION[72][78] = 74;
/* 1441 */       TRANSITION[72][110] = 74;
/*      */       
/* 1443 */       TRANSITION[73] = copyReplacing(arrayOfInt5, 15, 73);
/* 1444 */       TRANSITION[73][110] = 74;
/* 1445 */       TRANSITION[73][78] = 74;
/*      */       
/* 1447 */       TRANSITION[73][47] = 18;
/* 1448 */       TRANSITION[73][45] = 20;
/* 1449 */       TRANSITION[74] = copy(arrayOfInt4);
/* 1450 */       TRANSITION[74][111] = 75;
/* 1451 */       TRANSITION[74][79] = 75;
/* 1452 */       TRANSITION[74][117] = 79;
/* 1453 */       TRANSITION[74][85] = 79;
/*      */       
/* 1455 */       TRANSITION[75] = copy(arrayOfInt4);
/* 1456 */       TRANSITION[75][116] = 76;
/* 1457 */       TRANSITION[75][84] = 76;
/*      */       
/* 1459 */       TRANSITION[76] = copyReplacing(arrayOfInt5, 15, 77);
/* 1460 */       TRANSITION[77] = copy(arrayOfInt4);
/* 1461 */       TRANSITION[77][110] = 78;
/* 1462 */       TRANSITION[77][78] = 78;
/* 1463 */       TRANSITION[77][47] = 18;
/* 1464 */       TRANSITION[77][45] = 20;
/*      */       
/* 1466 */       TRANSITION[78] = copy(arrayOfInt4);
/* 1467 */       TRANSITION[78][117] = 79;
/* 1468 */       TRANSITION[78][85] = 79;
/*      */       
/* 1470 */       TRANSITION[79] = copy(arrayOfInt4);
/* 1471 */       TRANSITION[79][108] = 80;
/* 1472 */       TRANSITION[79][76] = 80;
/*      */       
/* 1474 */       TRANSITION[80] = copy(arrayOfInt4);
/* 1475 */       TRANSITION[80][108] = 81;
/* 1476 */       TRANSITION[80][76] = 81;
/*      */       
/* 1478 */       TRANSITION[81] = copyReplacing(arrayOfInt5, 15, 68);
/*      */       
/* 1480 */       TRANSITION[81][47] = 18;
/* 1481 */       TRANSITION[81][45] = 20;
/*      */       
/* 1483 */       TRANSITION[83] = copyReplacing(arrayOfInt5, 15, 85);
/*      */       
/* 1485 */       TRANSITION[83][47] = 18;
/* 1486 */       TRANSITION[83][45] = 20;
/* 1487 */       TRANSITION[83][62] = 84;
/* 1488 */       TRANSITION[83][39] = 92;
/* 1489 */       TRANSITION[83][78] = 93;
/* 1490 */       TRANSITION[83][110] = 93;
/* 1491 */       TRANSITION[83][63] = 67;
/*      */       
/* 1493 */       TRANSITION[84] = copyReplacing(arrayOfInt5, 15, 85);
/*      */       
/* 1495 */       TRANSITION[84][47] = 18;
/* 1496 */       TRANSITION[84][45] = 20;
/* 1497 */       TRANSITION[84][39] = 92;
/* 1498 */       TRANSITION[84][78] = 93;
/* 1499 */       TRANSITION[84][110] = 93;
/* 1500 */       TRANSITION[84][63] = 67;
/*      */       
/* 1502 */       TRANSITION[85] = copyReplacing(arrayOfInt4, 15, 85, 22, 68);
/*      */ 
/*      */ 
/*      */       
/* 1506 */       TRANSITION[85][47] = 18;
/* 1507 */       TRANSITION[85][45] = 20;
/* 1508 */       TRANSITION[85][39] = 92;
/* 1509 */       TRANSITION[85][78] = 93;
/* 1510 */       TRANSITION[85][110] = 93;
/* 1511 */       TRANSITION[85][63] = 86;
/*      */       
/* 1513 */       TRANSITION[86] = copyReplacing(arrayOfInt5, 15, 68, 22, 86);
/*      */ 
/*      */       
/* 1516 */       TRANSITION[86][47] = 18;
/* 1517 */       TRANSITION[86][45] = 20;
/* 1518 */       TRANSITION[86][39] = 92;
/* 1519 */       TRANSITION[86][78] = 93;
/* 1520 */       TRANSITION[86][110] = 93;
/* 1521 */       TRANSITION[92] = newArray(128, 92);
/*      */       
/* 1523 */       TRANSITION[92][39] = 68;
/*      */       
/* 1525 */       TRANSITION[93] = copyReplacing(arrayOfInt4, 22, 68);
/*      */       
/* 1527 */       TRANSITION[93][39] = 94;
/*      */       
/* 1529 */       TRANSITION[94] = newArray(128, 94);
/*      */       
/* 1531 */       TRANSITION[94][39] = 95;
/*      */       
/* 1533 */       TRANSITION[95] = newArray(128, 68);
/*      */       
/* 1535 */       TRANSITION[95][39] = 94;
/*      */       
/* 1537 */       TRANSITION[85][45] = 20;
/*      */ 
/*      */       
/* 1540 */       TRANSITION[15] = arrayOfInt5;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1546 */       int[] arrayOfInt6 = newArray(128, 0);
/*      */       
/* 1548 */       int[] arrayOfInt7 = copy(arrayOfInt6);
/* 1549 */       for (byte b1 = 0; b1 < arrayOfInt7.length; b1++) {
/* 1550 */         if (arrayOfInt4[b1] != 22) {
/* 1551 */           arrayOfInt7[b1] = 2;
/*      */         } else {
/* 1553 */           arrayOfInt7[b1] = 10;
/*      */         } 
/* 1555 */       }  int[] arrayOfInt8 = new int[128];
/*      */       
/* 1557 */       for (byte b2 = 0; b2 < arrayOfInt8.length; b2++) {
/* 1558 */         if (TRANSITION[1][b2] == 1) {
/* 1559 */           arrayOfInt8[b2] = 3;
/*      */         } else {
/* 1561 */           arrayOfInt8[b2] = 4;
/*      */         } 
/* 1563 */       }  int[] arrayOfInt9 = new int[128];
/*      */       
/* 1565 */       for (byte b3 = 0; b3 < arrayOfInt9.length; b3++) {
/* 1566 */         if (TRANSITION[21][b3] == 21) {
/* 1567 */           arrayOfInt9[b3] = 3;
/*      */         } else {
/* 1569 */           arrayOfInt9[b3] = 4;
/*      */         } 
/*      */       } 
/* 1572 */       int[] arrayOfInt10 = copy(arrayOfInt9);
/* 1573 */       arrayOfInt10[32] = 0;
/* 1574 */       arrayOfInt10[10] = 0;
/* 1575 */       arrayOfInt10[9] = 0;
/* 1576 */       arrayOfInt10[13] = 0;
/*      */       
/* 1578 */       int[] arrayOfInt11 = copy(arrayOfInt6);
/* 1579 */       arrayOfInt11[44] = 5;
/*      */       
/* 1581 */       arrayOfInt11[41] = 5;
/*      */       
/* 1583 */       int[] arrayOfInt12 = copy(arrayOfInt10);
/* 1584 */       arrayOfInt12[44] = 5;
/* 1585 */       arrayOfInt12[41] = 5;
/*      */ 
/*      */       
/* 1588 */       int[] arrayOfInt13 = copy(arrayOfInt6);
/* 1589 */       for (byte b4 = 0; b4 < arrayOfInt13.length; b4++) {
/* 1590 */         if (arrayOfInt4[b4] != 15)
/* 1591 */           arrayOfInt13[b4] = 10; 
/*      */       } 
/* 1593 */       arrayOfInt13[44] = 11;
/* 1594 */       arrayOfInt13[32] = 11;
/* 1595 */       arrayOfInt13[9] = 11;
/* 1596 */       arrayOfInt13[10] = 11;
/* 1597 */       arrayOfInt13[13] = 11;
/* 1598 */       arrayOfInt13[40] = 13;
/*      */ 
/*      */       
/* 1601 */       arrayOfInt13[47] = 18;
/* 1602 */       arrayOfInt13[45] = 18;
/*      */       
/* 1604 */       int[] arrayOfInt14 = copy(arrayOfInt13);
/* 1605 */       arrayOfInt14[32] = 10;
/* 1606 */       arrayOfInt14[40] = 17;
/*      */       
/* 1608 */       int[] arrayOfInt15 = copy(arrayOfInt6);
/* 1609 */       for (byte b5 = 0; b5 < arrayOfInt15.length; b5++) {
/* 1610 */         if (arrayOfInt4[b5] == 1) {
/* 1611 */           arrayOfInt15[b5] = 0;
/* 1612 */         } else if (arrayOfInt4[b5] != 22) {
/* 1613 */           arrayOfInt15[b5] = 12;
/*      */         } 
/*      */       } 
/* 1616 */       int[] arrayOfInt16 = copyReplacing(arrayOfInt6, 0, 14);
/*      */ 
/*      */       
/* 1619 */       arrayOfInt16[44] = 15;
/* 1620 */       arrayOfInt16[41] = 16;
/*      */       
/* 1622 */       int[] arrayOfInt17 = copyReplacing(arrayOfInt8, 3, 13);
/*      */ 
/*      */ 
/*      */       
/* 1626 */       arrayOfInt17[58] = 0;
/* 1627 */       for (byte b6 = 0; b6 < arrayOfInt17.length; b6++) {
/* 1628 */         if (arrayOfInt17[b6] == 4)
/* 1629 */           arrayOfInt17[b6] = 0; 
/*      */       } 
/* 1631 */       arrayOfInt17[47] = 18;
/* 1632 */       arrayOfInt17[45] = 18;
/*      */ 
/*      */       
/* 1635 */       int[] arrayOfInt18 = copyReplacing(arrayOfInt17, 13, 14);
/*      */ 
/*      */ 
/*      */       
/* 1639 */       arrayOfInt18[46] = 14;
/* 1640 */       arrayOfInt18[40] = 17;
/*      */       
/* 1642 */       int[] arrayOfInt19 = copyReplacing(arrayOfInt17, 0, 17, 13, 14);
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1647 */       int[] arrayOfInt20 = copy(arrayOfInt6);
/* 1648 */       arrayOfInt20[47] = 18;
/* 1649 */       arrayOfInt20[45] = 18;
/*      */       
/* 1651 */       int[] arrayOfInt21 = copy(arrayOfInt6);
/* 1652 */       arrayOfInt21[47] = 19;
/* 1653 */       int[] arrayOfInt22 = copy(arrayOfInt6);
/* 1654 */       arrayOfInt22[10] = 19;
/*      */       
/* 1656 */       int[] arrayOfInt23 = copy(arrayOfInt6);
/* 1657 */       arrayOfInt23[32] = 20;
/* 1658 */       arrayOfInt23[10] = 20;
/* 1659 */       arrayOfInt23[9] = 20;
/* 1660 */       arrayOfInt23[45] = 20;
/* 1661 */       arrayOfInt23[47] = 20;
/*      */       
/* 1663 */       int[] arrayOfInt24 = copy(arrayOfInt6);
/* 1664 */       arrayOfInt24[39] = 6;
/*      */       
/* 1666 */       int[] arrayOfInt25 = copyReplacing(arrayOfInt6, 0, 7);
/* 1667 */       arrayOfInt25[39] = 0;
/*      */       
/* 1669 */       int[] arrayOfInt26 = copyReplacing(arrayOfInt6, 0, 8);
/*      */       
/* 1671 */       int[] arrayOfInt27 = copyReplacing(arrayOfInt6, 0, 9);
/*      */       
/* 1673 */       int[] arrayOfInt28 = copy(arrayOfInt27);
/* 1674 */       arrayOfInt28[39] = 0;
/*      */       
/* 1676 */       ACTION[0] = arrayOfInt6;
/* 1677 */       ACTION[1] = arrayOfInt8;
/* 1678 */       ACTION[96] = arrayOfInt10;
/* 1679 */       ACTION[2] = arrayOfInt20;
/* 1680 */       ACTION[3] = arrayOfInt6;
/* 1681 */       ACTION[4] = arrayOfInt6;
/* 1682 */       ACTION[5] = arrayOfInt6;
/* 1683 */       ACTION[6] = arrayOfInt6;
/* 1684 */       ACTION[7] = arrayOfInt6;
/* 1685 */       ACTION[8] = arrayOfInt6;
/* 1686 */       ACTION[9] = arrayOfInt6;
/* 1687 */       ACTION[10] = arrayOfInt6;
/* 1688 */       ACTION[11] = arrayOfInt6;
/* 1689 */       ACTION[12] = arrayOfInt6;
/* 1690 */       ACTION[13] = arrayOfInt6;
/* 1691 */       ACTION[14] = arrayOfInt6;
/* 1692 */       ACTION[22] = arrayOfInt6;
/* 1693 */       ACTION[16] = arrayOfInt6;
/* 1694 */       ACTION[17] = arrayOfInt6;
/* 1695 */       ACTION[18] = arrayOfInt20;
/* 1696 */       ACTION[19] = arrayOfInt21;
/* 1697 */       ACTION[20] = arrayOfInt22;
/* 1698 */       ACTION[21] = arrayOfInt9;
/* 1699 */       ACTION[15] = arrayOfInt6;
/*      */       
/* 1701 */       ACTION[28] = arrayOfInt20;
/* 1702 */       ACTION[29] = arrayOfInt6;
/* 1703 */       ACTION[30] = arrayOfInt6;
/* 1704 */       ACTION[31] = arrayOfInt6;
/* 1705 */       ACTION[32] = arrayOfInt6;
/* 1706 */       ACTION[33] = arrayOfInt13;
/*      */       
/* 1708 */       ACTION[34] = arrayOfInt13;
/*      */       
/* 1710 */       ACTION[35] = arrayOfInt15;
/*      */ 
/*      */       
/* 1713 */       ACTION[36] = arrayOfInt16;
/* 1714 */       ACTION[37] = arrayOfInt6;
/* 1715 */       ACTION[38] = arrayOfInt6;
/* 1716 */       ACTION[39] = arrayOfInt11;
/* 1717 */       ACTION[40] = arrayOfInt12;
/* 1718 */       ACTION[41] = arrayOfInt6;
/* 1719 */       ACTION[42] = arrayOfInt24;
/* 1720 */       ACTION[43] = arrayOfInt6;
/* 1721 */       ACTION[44] = arrayOfInt25;
/* 1722 */       ACTION[45] = arrayOfInt19;
/* 1723 */       ACTION[46] = arrayOfInt26;
/* 1724 */       ACTION[47] = arrayOfInt27;
/* 1725 */       ACTION[48] = arrayOfInt28;
/*      */       
/* 1727 */       ACTION[49] = arrayOfInt13;
/* 1728 */       ACTION[50] = arrayOfInt13;
/* 1729 */       ACTION[51] = arrayOfInt20;
/* 1730 */       ACTION[52] = arrayOfInt6;
/* 1731 */       ACTION[53] = arrayOfInt6;
/*      */       
/* 1733 */       ACTION[54] = arrayOfInt6;
/* 1734 */       ACTION[55] = arrayOfInt6;
/* 1735 */       ACTION[56] = arrayOfInt6;
/* 1736 */       ACTION[57] = arrayOfInt14;
/* 1737 */       ACTION[58] = arrayOfInt14;
/* 1738 */       ACTION[59] = arrayOfInt14;
/* 1739 */       ACTION[60] = arrayOfInt15;
/* 1740 */       ACTION[61] = arrayOfInt6;
/*      */       
/* 1742 */       ACTION[62] = arrayOfInt18;
/* 1743 */       ACTION[63] = arrayOfInt18;
/* 1744 */       ACTION[64] = arrayOfInt18;
/* 1745 */       ACTION[65] = arrayOfInt18;
/* 1746 */       ACTION[66] = arrayOfInt7;
/*      */       
/* 1748 */       ACTION[67] = arrayOfInt17;
/* 1749 */       ACTION[68] = arrayOfInt17;
/* 1750 */       ACTION[89] = arrayOfInt6;
/* 1751 */       ACTION[90] = arrayOfInt6;
/* 1752 */       ACTION[91] = arrayOfInt23;
/* 1753 */       ACTION[87] = arrayOfInt6;
/* 1754 */       ACTION[88] = arrayOfInt6;
/* 1755 */       ACTION[69] = arrayOfInt18;
/* 1756 */       ACTION[70] = arrayOfInt6;
/* 1757 */       ACTION[71] = arrayOfInt6;
/* 1758 */       ACTION[72] = arrayOfInt20;
/* 1759 */       ACTION[73] = arrayOfInt6;
/* 1760 */       ACTION[74] = arrayOfInt6;
/* 1761 */       ACTION[75] = arrayOfInt6;
/* 1762 */       ACTION[76] = arrayOfInt20;
/* 1763 */       ACTION[77] = arrayOfInt6;
/* 1764 */       ACTION[78] = arrayOfInt6;
/* 1765 */       ACTION[79] = arrayOfInt6;
/* 1766 */       ACTION[80] = arrayOfInt6;
/* 1767 */       ACTION[81] = arrayOfInt6;
/*      */       
/* 1769 */       ACTION[82] = arrayOfInt20;
/* 1770 */       ACTION[83] = arrayOfInt20;
/* 1771 */       ACTION[84] = arrayOfInt6;
/* 1772 */       ACTION[85] = arrayOfInt20;
/* 1773 */       ACTION[86] = arrayOfInt6;
/*      */       
/* 1775 */       ACTION[92] = arrayOfInt6;
/* 1776 */       ACTION[93] = arrayOfInt24;
/* 1777 */       ACTION[94] = arrayOfInt6;
/* 1778 */       ACTION[95] = arrayOfInt25;
/*      */       
/* 1780 */       ACTION[23] = arrayOfInt13;
/* 1781 */       ACTION[24] = arrayOfInt13;
/* 1782 */       ACTION[25] = arrayOfInt13;
/* 1783 */       ACTION[26] = arrayOfInt13;
/* 1784 */       ACTION[27] = arrayOfInt7;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     }
/*      */     catch (Throwable throwable) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1796 */       throwable.printStackTrace();
/*      */     } 
/*      */   }
/*      */ }


/* Location:              C:\Users\olatu\OneDrive\Documents\Calypso\syncbase\sync_base.jar!\BOOT-INF\lib\ojdbc-7.jar!\oracle\jdbc\driver\OracleParameterMetaDataParserStates.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */