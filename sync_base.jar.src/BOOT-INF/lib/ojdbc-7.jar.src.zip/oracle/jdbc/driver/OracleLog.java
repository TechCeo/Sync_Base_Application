/*     */ package oracle.jdbc.driver;
/*     */ 
/*     */ import java.security.AccessController;
/*     */ import java.security.PrivilegedAction;
/*     */ import java.util.logging.Level;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class OracleLog
/*     */ {
/*     */   private static final int maxPrintBytes = 512;
/*     */   public static final boolean TRACE = false;
/*     */   
/*     */   public static boolean isDebugZip() {
/*  69 */     boolean bool = true;
/*     */ 
/*     */     
/*  72 */     bool = false;
/*  73 */     return bool;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isPrivateLogAvailable() {
/*  88 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isEnabled() {
/* 102 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean registerClassNameAndGetCurrentTraceSetting(Class paramClass) {
/* 113 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void setTrace(boolean paramBoolean) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void initialize() {
/* 137 */     setupFromSystemProperties();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void setupFromSystemProperties() {
/* 148 */     boolean bool = false;
/* 149 */     securityExceptionWhileGettingSystemProperties = false;
/*     */     
/*     */     try {
/* 152 */       String str = null;
/* 153 */       str = getSystemProperty("oracle.jdbc.Trace", null);
/* 154 */       if (str != null && str.compareTo("true") == 0) {
/* 155 */         bool = true;
/*     */       }
/* 157 */     } catch (SecurityException securityException) {
/*     */       
/* 159 */       securityExceptionWhileGettingSystemProperties = true;
/*     */     } 
/* 161 */     setTrace(bool);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static String getSystemProperty(String paramString) {
/* 178 */     return getSystemProperty(paramString, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static String getSystemProperty(String paramString1, String paramString2) {
/* 186 */     if (paramString1 != null) {
/*     */       
/* 188 */       final String fstr = paramString1;
/* 189 */       final String fdefaultValue = paramString2;
/* 190 */       final String[] retStr = { paramString2 };
/* 191 */       AccessController.doPrivileged(new PrivilegedAction()
/*     */           {
/*     */             public Object run()
/*     */             {
/* 195 */               retStr[0] = System.getProperty(fstr, fdefaultValue);
/* 196 */               return null;
/*     */             }
/*     */           });
/* 199 */       return arrayOfString[0];
/*     */     } 
/* 201 */     return paramString2;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String argument() {
/* 211 */     return "";
/*     */   }
/*     */   
/*     */   public static String argument(boolean paramBoolean) {
/* 215 */     return Boolean.toString(paramBoolean);
/*     */   }
/*     */   
/*     */   public static String argument(byte paramByte) {
/* 219 */     return Byte.toString(paramByte);
/*     */   }
/*     */   
/*     */   public static String argument(short paramShort) {
/* 223 */     return Short.toString(paramShort);
/*     */   }
/*     */   
/*     */   public static String argument(int paramInt) {
/* 227 */     return Integer.toString(paramInt);
/*     */   }
/*     */   
/*     */   public static String argument(long paramLong) {
/* 231 */     return Long.toString(paramLong);
/*     */   }
/*     */   
/*     */   public static String argument(float paramFloat) {
/* 235 */     return Float.toString(paramFloat);
/*     */   }
/*     */   
/*     */   public static String argument(double paramDouble) {
/* 239 */     return Double.toString(paramDouble);
/*     */   }
/*     */   
/*     */   public static String argument(Object paramObject) {
/* 243 */     if (paramObject == null) return "null"; 
/* 244 */     if (paramObject instanceof String) return "\"" + (String)paramObject + "\""; 
/* 245 */     return paramObject.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String byteToHexString(byte paramByte) {
/* 267 */     StringBuffer stringBuffer = new StringBuffer("");
/* 268 */     int i = 0xFF & paramByte;
/*     */     
/* 270 */     if (i <= 15) {
/* 271 */       stringBuffer.append("0x0");
/*     */     } else {
/* 273 */       stringBuffer.append("0x");
/*     */     } 
/* 275 */     stringBuffer.append(Integer.toHexString(i));
/*     */     
/* 277 */     return stringBuffer.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String bytesToPrintableForm(String paramString, byte[] paramArrayOfbyte) {
/* 298 */     boolean bool = (paramArrayOfbyte == null) ? false : paramArrayOfbyte.length;
/*     */     
/* 300 */     return bytesToPrintableForm(paramString, paramArrayOfbyte, bool);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String bytesToPrintableForm(String paramString, byte[] paramArrayOfbyte, int paramInt) {
/* 324 */     String str = null;
/*     */     
/* 326 */     if (paramArrayOfbyte == null) {
/* 327 */       str = paramString + ": null";
/*     */     } else {
/* 329 */       str = paramString + " (" + paramArrayOfbyte.length + " bytes):\n" + bytesToFormattedStr(paramArrayOfbyte, paramInt, "  ");
/*     */     } 
/*     */     
/* 332 */     return str;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String bytesToFormattedStr(byte[] paramArrayOfbyte, int paramInt, String paramString) {
/* 359 */     StringBuffer stringBuffer = new StringBuffer("");
/*     */     
/* 361 */     if (paramString == null) {
/* 362 */       paramString = new String("");
/*     */     }
/* 364 */     stringBuffer.append(paramString);
/*     */     
/* 366 */     if (paramArrayOfbyte == null) {
/*     */       
/* 368 */       stringBuffer.append("byte [] is null");
/*     */       
/* 370 */       return stringBuffer.toString();
/*     */     } 
/*     */     
/* 373 */     for (byte b = 0; b < paramInt; b++) {
/*     */       
/* 375 */       if (b >= 'Ȁ') {
/*     */         
/* 377 */         stringBuffer.append("\n" + paramString + "... last " + (paramInt - 512) + " bytes were not printed to limit the output size");
/*     */ 
/*     */         
/*     */         break;
/*     */       } 
/*     */       
/* 383 */       if (b > 0 && b % 20 == 0) {
/* 384 */         stringBuffer.append("\n" + paramString);
/*     */       }
/* 386 */       if (b % 20 == 10) {
/* 387 */         stringBuffer.append(" ");
/*     */       }
/* 389 */       int i = 0xFF & paramArrayOfbyte[b];
/*     */       
/* 391 */       if (i <= 15) {
/* 392 */         stringBuffer.append("0");
/*     */       }
/* 394 */       stringBuffer.append(Integer.toHexString(i) + " ");
/*     */     } 
/*     */     
/* 397 */     return stringBuffer.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static byte[] strToUcs2Bytes(String paramString) {
/* 414 */     if (paramString == null) {
/* 415 */       return null;
/*     */     }
/* 417 */     return charsToUcs2Bytes(paramString.toCharArray());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static byte[] charsToUcs2Bytes(char[] paramArrayOfchar) {
/* 434 */     if (paramArrayOfchar == null) {
/* 435 */       return null;
/*     */     }
/* 437 */     return charsToUcs2Bytes(paramArrayOfchar, paramArrayOfchar.length);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static byte[] charsToUcs2Bytes(char[] paramArrayOfchar, int paramInt) {
/* 456 */     if (paramArrayOfchar == null) {
/* 457 */       return null;
/*     */     }
/* 459 */     if (paramInt < 0) {
/* 460 */       return null;
/*     */     }
/* 462 */     return charsToUcs2Bytes(paramArrayOfchar, paramInt, 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static byte[] charsToUcs2Bytes(char[] paramArrayOfchar, int paramInt1, int paramInt2) {
/* 474 */     if (paramArrayOfchar == null) {
/* 475 */       return null;
/*     */     }
/* 477 */     if (paramInt1 > paramArrayOfchar.length - paramInt2) {
/* 478 */       paramInt1 = paramArrayOfchar.length - paramInt2;
/*     */     }
/* 480 */     if (paramInt1 < 0) {
/* 481 */       return null;
/*     */     }
/* 483 */     byte[] arrayOfByte = new byte[2 * paramInt1]; byte b;
/*     */     int i;
/* 485 */     for (i = paramInt2, b = 0; i < paramInt1; i++) {
/*     */       
/* 487 */       arrayOfByte[b++] = (byte)(paramArrayOfchar[i] >> 8 & 0xFF);
/* 488 */       arrayOfByte[b++] = (byte)(paramArrayOfchar[i] & 0xFF);
/*     */     } 
/*     */     
/* 491 */     return arrayOfByte;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String toPrintableStr(String paramString, int paramInt) {
/* 509 */     if (paramString == null)
/*     */     {
/* 511 */       return "null";
/*     */     }
/*     */     
/* 514 */     if (paramString.length() > paramInt)
/*     */     {
/* 516 */       return paramString.substring(0, paramInt - 1) + "\n ... the actual length was " + paramString.length();
/*     */     }
/*     */ 
/*     */     
/* 520 */     return paramString;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 532 */   public static final Level INTERNAL_ERROR = OracleLevel.INTERNAL_ERROR;
/* 533 */   public static final Level TRACE_1 = OracleLevel.TRACE_1;
/* 534 */   public static final Level TRACE_10 = OracleLevel.TRACE_10;
/* 535 */   public static final Level TRACE_16 = OracleLevel.TRACE_16;
/* 536 */   public static final Level TRACE_20 = OracleLevel.TRACE_20;
/* 537 */   public static final Level TRACE_30 = OracleLevel.TRACE_30;
/* 538 */   public static final Level TRACE_32 = OracleLevel.TRACE_32;
/*     */ 
/*     */ 
/*     */   
/*     */   static boolean securityExceptionWhileGettingSystemProperties;
/*     */ 
/*     */ 
/*     */   
/*     */   static {
/* 547 */     initialize();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String toHex(long paramLong, int paramInt) {
/*     */     String str;
/* 556 */     switch (paramInt) {
/*     */       
/*     */       case 1:
/* 559 */         str = "00" + Long.toString(paramLong & 0xFFL, 16);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 586 */         return "0x" + str.substring(str.length() - 2 * paramInt);case 2: str = "0000" + Long.toString(paramLong & 0xFFFFL, 16); return "0x" + str.substring(str.length() - 2 * paramInt);case 3: str = "000000" + Long.toString(paramLong & 0xFFFFFFL, 16); return "0x" + str.substring(str.length() - 2 * paramInt);case 4: str = "00000000" + Long.toString(paramLong & 0xFFFFFFFFL, 16); return "0x" + str.substring(str.length() - 2 * paramInt);case 5: str = "0000000000" + Long.toString(paramLong & 0xFFFFFFFFFFL, 16); return "0x" + str.substring(str.length() - 2 * paramInt);case 6: str = "000000000000" + Long.toString(paramLong & 0xFFFFFFFFFFFFL, 16); return "0x" + str.substring(str.length() - 2 * paramInt);case 7: str = "00000000000000" + Long.toString(paramLong & 0xFFFFFFFFFFFFFFL, 16); return "0x" + str.substring(str.length() - 2 * paramInt);
/*     */       case 8:
/*     */         return toHex(paramLong >> 32L, 4) + toHex(paramLong, 4).substring(2);
/*     */     } 
/*     */     return "more than 8 bytes"; } public static String toHex(byte paramByte) {
/* 591 */     String str = "00" + Integer.toHexString(paramByte & 0xFF);
/* 592 */     return "0x" + str.substring(str.length() - 2);
/*     */   }
/*     */ 
/*     */   
/*     */   public static String toHex(short paramShort) {
/* 597 */     return toHex(paramShort, 2);
/*     */   }
/*     */ 
/*     */   
/*     */   public static String toHex(int paramInt) {
/* 602 */     return toHex(paramInt, 4);
/*     */   }
/*     */ 
/*     */   
/*     */   public static String toHex(byte[] paramArrayOfbyte, int paramInt) {
/* 607 */     if (paramArrayOfbyte == null)
/* 608 */       return "null"; 
/* 609 */     if (paramInt > paramArrayOfbyte.length)
/* 610 */       return "byte array not long enough"; 
/* 611 */     String str = "[";
/* 612 */     int i = Math.min(64, paramInt);
/* 613 */     for (byte b = 0; b < i; b++)
/*     */     {
/* 615 */       str = str + toHex(paramArrayOfbyte[b]) + " ";
/*     */     }
/* 617 */     if (i < paramInt)
/* 618 */       str = str + "..."; 
/* 619 */     return str + "]";
/*     */   }
/*     */ 
/*     */   
/*     */   public static String toHex(byte[] paramArrayOfbyte) {
/* 624 */     if (paramArrayOfbyte == null)
/* 625 */       return "null"; 
/* 626 */     return toHex(paramArrayOfbyte, paramArrayOfbyte.length);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static class OracleLevel
/*     */     extends Level
/*     */   {
/* 634 */     static final OracleLevel INTERNAL_ERROR = new OracleLevel("INTERNAL_ERROR", 1100);
/* 635 */     static final OracleLevel TRACE_1 = new OracleLevel("TRACE_1", Level.FINE.intValue());
/* 636 */     static final OracleLevel TRACE_10 = new OracleLevel("TRACE_10", 446);
/* 637 */     static final OracleLevel TRACE_16 = new OracleLevel("TRACE_16", Level.FINER.intValue());
/* 638 */     static final OracleLevel TRACE_20 = new OracleLevel("TRACE_20", 376);
/* 639 */     static final OracleLevel TRACE_30 = new OracleLevel("TRACE_30", 316);
/* 640 */     static final OracleLevel TRACE_32 = new OracleLevel("TRACE_32", Level.FINEST.intValue());
/*     */     
/*     */     OracleLevel(String param1String, int param1Int) {
/* 643 */       super(param1String, param1Int);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\olatu\OneDrive\Documents\Calypso\syncbase\sync_base.jar!\BOOT-INF\lib\ojdbc-7.jar!\oracle\jdbc\driver\OracleLog.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */