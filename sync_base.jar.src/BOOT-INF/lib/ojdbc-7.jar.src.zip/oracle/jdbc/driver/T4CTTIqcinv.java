/*    */ package oracle.jdbc.driver;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.sql.SQLException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class T4CTTIqcinv
/*    */   extends T4CTTIMsg
/*    */ {
/*    */   long kpdqcqid;
/*    */   long kpdqcopflg;
/* 47 */   T4CTTIkscn kpdqcscn = null;
/*    */   
/*    */   T4CTTIqcinv(T4CConnection paramT4CConnection) {
/* 50 */     super(paramT4CConnection, (byte)0);
/*    */   }
/*    */   
/*    */   void unmarshal() throws SQLException, IOException {
/* 54 */     this.kpdqcqid = this.meg.unmarshalSB8();
/* 55 */     this.kpdqcopflg = this.meg.unmarshalUB4();
/* 56 */     this.kpdqcscn = new T4CTTIkscn(this.connection);
/* 57 */     this.kpdqcscn.unmarshal();
/*    */   }
/*    */ }


/* Location:              C:\Users\olatu\OneDrive\Documents\Calypso\syncbase\sync_base.jar!\BOOT-INF\lib\ojdbc-7.jar!\oracle\jdbc\driver\T4CTTIqcinv.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */