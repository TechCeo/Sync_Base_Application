/*     */ package oracle.jdbc.driver;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.sql.SQLException;
/*     */ import oracle.jdbc.aq.AQFactory;
/*     */ import oracle.jdbc.aq.AQMessageProperties;
/*     */ import oracle.jdbc.internal.JMSFactory;
/*     */ import oracle.jdbc.internal.JMSMessageProperties;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class T4CTTIkpdnrmp
/*     */ {
/*     */   byte[] messageId;
/*     */   AQMessagePropertiesI aqMessageProperties;
/*     */   JMSMessagePropertiesI jmsMessageProperties;
/*  51 */   private T4CTTIaqm aqm = null;
/*  52 */   private T4CTTIaqjms aqjms = null;
/*  53 */   private T4Ctoh toh = null;
/*     */   
/*     */   T4CMAREngine mar;
/*     */ 
/*     */   
/*     */   T4CTTIkpdnrmp(T4CConnection paramT4CConnection) {
/*  59 */     this.toh = new T4Ctoh();
/*  60 */     this.aqm = new T4CTTIaqm(paramT4CConnection, this.toh);
/*  61 */     this.mar = paramT4CConnection.mare;
/*  62 */     this.aqjms = new T4CTTIaqjms(paramT4CConnection);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void receive() throws SQLException, IOException {
/*  69 */     int i = this.mar.unmarshalSWORD();
/*  70 */     if (i > 0) {
/*     */       
/*  72 */       this.messageId = new byte[i];
/*  73 */       int[] arrayOfInt = new int[1];
/*     */ 
/*     */       
/*  76 */       this.mar.unmarshalCLR(this.messageId, 0, arrayOfInt, this.messageId.length);
/*  77 */       i = arrayOfInt[0];
/*     */     } 
/*     */ 
/*     */     
/*  81 */     int j = this.mar.unmarshalSWORD();
/*  82 */     if (j > 0) {
/*     */ 
/*     */       
/*  85 */       this.mar.unmarshalUB1();
/*     */ 
/*     */       
/*  88 */       this.aqm.receive();
/*     */ 
/*     */       
/*  91 */       this.aqMessageProperties = (AQMessagePropertiesI)AQFactory.createAQMessageProperties();
/*  92 */       this.aqMessageProperties.setPriority(this.aqm.aqmpri);
/*  93 */       this.aqMessageProperties.setDelay(this.aqm.aqmdel);
/*  94 */       this.aqMessageProperties.setExpiration(this.aqm.aqmexp);
/*  95 */       if (this.aqm.aqmcorBytes != null) {
/*     */         
/*  97 */         String str = this.mar.conv.CharBytesToString(this.aqm.aqmcorBytes, this.aqm.aqmcorBytesLength, true);
/*     */         
/*  99 */         this.aqMessageProperties.setCorrelation(str);
/*     */       } 
/* 101 */       this.aqMessageProperties.setAttempts(this.aqm.aqmatt);
/* 102 */       if (this.aqm.aqmeqnBytes != null) {
/*     */         
/* 104 */         String str = this.mar.conv.CharBytesToString(this.aqm.aqmeqnBytes, this.aqm.aqmeqnBytesLength, true);
/*     */         
/* 106 */         this.aqMessageProperties.setExceptionQueue(str);
/*     */       } 
/* 108 */       this.aqMessageProperties.setMessageState(AQMessageProperties.MessageState.getMessageState(this.aqm.aqmsta));
/* 109 */       if (this.aqm.aqmeqt != null)
/* 110 */         this.aqMessageProperties.setEnqueueTime(this.aqm.aqmeqt.timestampValue()); 
/* 111 */       AQAgentI aQAgentI = new AQAgentI();
/* 112 */       if (this.aqm.senderAgentName != null) {
/* 113 */         aQAgentI.setName(this.mar.conv.CharBytesToString(this.aqm.senderAgentName, this.aqm.senderAgentNameLength, true));
/*     */       }
/*     */ 
/*     */       
/* 117 */       if (this.aqm.senderAgentAddress != null) {
/* 118 */         aQAgentI.setAddress(this.mar.conv.CharBytesToString(this.aqm.senderAgentAddress, this.aqm.senderAgentAddressLength, true));
/*     */       }
/*     */ 
/*     */       
/* 122 */       aQAgentI.setProtocol(this.aqm.senderAgentProtocol);
/*     */       
/* 124 */       this.aqMessageProperties.setSender(aQAgentI);
/* 125 */       this.aqMessageProperties.setPreviousQueueMessageId(this.aqm.originalMsgId);
/* 126 */       this.aqMessageProperties.setDeliveryMode(AQMessageProperties.DeliveryMode.getDeliveryMode(this.aqm.aqmflg));
/*     */ 
/*     */       
/* 129 */       if (this.aqm.aqmetiBytes != null) {
/*     */         
/* 131 */         String str = this.mar.conv.CharBytesToString(this.aqm.aqmetiBytes, this.aqm.aqmetiBytes.length, true);
/*     */         
/* 133 */         this.aqMessageProperties.setTransactionGroup(str);
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 139 */     int k = this.mar.unmarshalSWORD();
/* 140 */     if (k > 0) {
/*     */ 
/*     */       
/* 143 */       this.mar.unmarshalUB1();
/*     */ 
/*     */       
/* 146 */       this.aqjms.receive();
/*     */ 
/*     */       
/* 149 */       this.jmsMessageProperties = (JMSMessagePropertiesI)JMSFactory.createJMSMessageProperties();
/* 150 */       this.jmsMessageProperties.setHeaderProperties(this.mar.conv.CharBytesToString(this.aqjms.aqjmshdrprop, this.aqjms.aqjmshdrprop.length));
/* 151 */       this.jmsMessageProperties.setUserProperties(this.mar.conv.CharBytesToString(this.aqjms.aqjmsuserprop, this.aqjms.aqjmsuserprop.length));
/* 152 */       this.jmsMessageProperties.setJMSMessageType(JMSMessageProperties.JMSMessageType.getJMSMessageType(this.aqjms.aqjmsflags));
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AQMessagePropertiesI getAqMessageProperties() {
/* 160 */     return this.aqMessageProperties;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JMSMessagePropertiesI getJmsMessageProperties() {
/* 167 */     return this.jmsMessageProperties;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] getMessageId() {
/* 174 */     return this.messageId;
/*     */   }
/*     */ 
/*     */   
/* 178 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*     */   public static final String BUILD_DATE = "Thu_Apr_04_15:09:24_PDT_2013";
/*     */   public static final boolean TRACE = false;
/*     */ }


/* Location:              C:\Users\olatu\OneDrive\Documents\Calypso\syncbase\sync_base.jar!\BOOT-INF\lib\ojdbc-7.jar!\oracle\jdbc\driver\T4CTTIkpdnrmp.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */