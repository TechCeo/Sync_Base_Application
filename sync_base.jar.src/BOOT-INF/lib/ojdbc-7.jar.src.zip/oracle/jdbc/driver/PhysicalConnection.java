/*       */ package oracle.jdbc.driver;
/*       */ import java.lang.reflect.Field;
/*       */ import java.lang.reflect.Modifier;
/*       */ import java.math.BigDecimal;
/*       */ import java.math.BigInteger;
/*       */ import java.net.InetAddress;
/*       */ import java.net.UnknownHostException;
/*       */ import java.security.AccessController;
/*       */ import java.security.NoSuchAlgorithmException;
/*       */ import java.security.Permission;
/*       */ import java.security.PrivilegedAction;
/*       */ import java.security.spec.InvalidKeySpecException;
/*       */ import java.sql.Array;
/*       */ import java.sql.Blob;
/*       */ import java.sql.CallableStatement;
/*       */ import java.sql.ClientInfoStatus;
/*       */ import java.sql.Clob;
/*       */ import java.sql.Connection;
/*       */ import java.sql.DatabaseMetaData;
/*       */ import java.sql.Date;
/*       */ import java.sql.DriverManager;
/*       */ import java.sql.NClob;
/*       */ import java.sql.PreparedStatement;
/*       */ import java.sql.ResultSet;
/*       */ import java.sql.ResultSetMetaData;
/*       */ import java.sql.SQLClientInfoException;
/*       */ import java.sql.SQLException;
/*       */ import java.sql.SQLPermission;
/*       */ import java.sql.SQLWarning;
/*       */ import java.sql.SQLXML;
/*       */ import java.sql.Savepoint;
/*       */ import java.sql.Statement;
/*       */ import java.sql.Struct;
/*       */ import java.sql.Time;
/*       */ import java.sql.Timestamp;
/*       */ import java.util.ArrayList;
/*       */ import java.util.Arrays;
/*       */ import java.util.Calendar;
/*       */ import java.util.EnumSet;
/*       */ import java.util.Enumeration;
/*       */ import java.util.HashMap;
/*       */ import java.util.Hashtable;
/*       */ import java.util.Map;
/*       */ import java.util.Properties;
/*       */ import java.util.TimeZone;
/*       */ import java.util.Vector;
/*       */ import java.util.concurrent.Executor;
/*       */ import java.util.regex.Pattern;
/*       */ import javax.transaction.xa.XAResource;
/*       */ import oracle.jdbc.LogicalTransactionId;
/*       */ import oracle.jdbc.LogicalTransactionIdEventListener;
/*       */ import oracle.jdbc.OracleCallableStatement;
/*       */ import oracle.jdbc.OracleConnection;
/*       */ import oracle.jdbc.OracleDatabaseMetaData;
/*       */ import oracle.jdbc.OracleOCIFailover;
/*       */ import oracle.jdbc.OraclePreparedStatement;
/*       */ import oracle.jdbc.OracleSQLPermission;
/*       */ import oracle.jdbc.OracleSavepoint;
/*       */ import oracle.jdbc.OracleStatement;
/*       */ import oracle.jdbc.aq.AQDequeueOptions;
/*       */ import oracle.jdbc.aq.AQEnqueueOptions;
/*       */ import oracle.jdbc.aq.AQMessage;
/*       */ import oracle.jdbc.aq.AQMessageProperties;
/*       */ import oracle.jdbc.aq.AQNotificationRegistration;
/*       */ import oracle.jdbc.dcn.DatabaseChangeRegistration;
/*       */ import oracle.jdbc.internal.JMSDequeueOptions;
/*       */ import oracle.jdbc.internal.JMSEnqueueOptions;
/*       */ import oracle.jdbc.internal.JMSFactory;
/*       */ import oracle.jdbc.internal.JMSMessage;
/*       */ import oracle.jdbc.internal.JMSNotificationRegistration;
/*       */ import oracle.jdbc.internal.KeywordValueLong;
/*       */ import oracle.jdbc.internal.OracleConnection;
/*       */ import oracle.jdbc.internal.OracleStatement;
/*       */ import oracle.jdbc.internal.PDBChangeEventListener;
/*       */ import oracle.jdbc.internal.ReplayContext;
/*       */ import oracle.jdbc.internal.XSEventListener;
/*       */ import oracle.jdbc.internal.XSKeyval;
/*       */ import oracle.jdbc.internal.XSNamespace;
/*       */ import oracle.jdbc.internal.XSPrincipal;
/*       */ import oracle.jdbc.internal.XSSecureId;
/*       */ import oracle.jdbc.internal.XSSessionParameters;
/*       */ import oracle.jdbc.oracore.OracleTypeADT;
/*       */ import oracle.jdbc.pool.OracleConnectionCacheCallback;
/*       */ import oracle.jdbc.pool.OraclePooledConnection;
/*       */ import oracle.net.nt.CustomSSLSocketFactory;
/*       */ import oracle.security.pki.OracleSecretStore;
/*       */ import oracle.security.pki.OracleWallet;
/*       */ import oracle.sql.ARRAY;
/*       */ import oracle.sql.ArrayDescriptor;
/*       */ import oracle.sql.BFILE;
/*       */ import oracle.sql.BINARY_DOUBLE;
/*       */ import oracle.sql.BINARY_FLOAT;
/*       */ import oracle.sql.BLOB;
/*       */ import oracle.sql.BlobDBAccess;
/*       */ import oracle.sql.CLOB;
/*       */ import oracle.sql.CharacterSet;
/*       */ import oracle.sql.ClobDBAccess;
/*       */ import oracle.sql.CustomDatum;
/*       */ import oracle.sql.DATE;
/*       */ import oracle.sql.Datum;
/*       */ import oracle.sql.INTERVALDS;
/*       */ import oracle.sql.INTERVALYM;
/*       */ import oracle.sql.NCLOB;
/*       */ import oracle.sql.NUMBER;
/*       */ import oracle.sql.SQLName;
/*       */ import oracle.sql.StructDescriptor;
/*       */ import oracle.sql.TIMESTAMP;
/*       */ import oracle.sql.TIMESTAMPLTZ;
/*       */ import oracle.sql.TIMESTAMPTZ;
/*       */ import oracle.sql.TIMEZONETAB;
/*       */ import oracle.sql.TypeDescriptor;
/*       */ 
/*       */ abstract class PhysicalConnection extends OracleConnection {
/*       */   public static final String SECRET_STORE_CONNECT = "oracle.security.client.connect_string";
/*       */   public static final String SECRET_STORE_USERNAME = "oracle.security.client.username";
/*       */   public static final String SECRET_STORE_PASSWORD = "oracle.security.client.password";
/*       */   public static final String SECRET_STORE_DEFAULT_USERNAME = "oracle.security.client.default_username";
/*       */   public static final String SECRET_STORE_DEFAULT_PASSWORD = "oracle.security.client.default_password";
/*   119 */   static final CRC64 CHECKSUM = new CRC64();
/*       */   public static final char slash_character = '/';
/*       */   public static final char at_sign_character = '@';
/*       */   public static final char left_square_bracket_character = '[';
/*       */   public static final char right_square_bracket_character = ']';
/*   124 */   static final byte[] EMPTY_BYTE_ARRAY = new byte[0];
/*   125 */   static final char[] EMPTY_CHAR_ARRAY = new char[0];
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   static final int STREAM_CHUNK_SIZE = 32768;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*   141 */   long outScn = 0L;
/*       */   
/*   143 */   char[][] charOutput = new char[1][];
/*   144 */   byte[][] byteOutput = new byte[1][];
/*   145 */   short[][] shortOutput = new short[1][];
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*   151 */   Properties sessionProperties = null;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*   158 */   private static final String[] END_TO_END_CLIENTINFO_KEYS = new String[] { "OCSID.ACTION", "OCSID.CLIENTID", "OCSID.ECID", "OCSID.MODULE", "OCSID.DBOP" };
/*       */   
/*       */   private static final String END_TO_END_CLIENTINFO_KEY_SEQ_NO = "OCSID.SEQUENCE_NUMBER";
/*       */   
/*       */   boolean retainV9BindBehavior;
/*       */   
/*       */   String userName;
/*       */   
/*       */   String database;
/*       */   
/*       */   boolean defaultautocommit;
/*       */   
/*       */   String protocol;
/*       */   
/*       */   int streamChunkSize;
/*       */   
/*       */   boolean setFloatAndDoubleUseBinary;
/*       */   
/*       */   String ocidll;
/*       */   
/*       */   String thinVsessionTerminal;
/*       */   
/*       */   String thinVsessionMachine;
/*       */   
/*       */   String thinVsessionOsuser;
/*       */   
/*       */   String thinVsessionProgram;
/*       */   
/*       */   String thinVsessionProcess;
/*       */   
/*       */   String thinVsessionIname;
/*       */   
/*       */   String thinVsessionEname;
/*       */   String thinNetProfile;
/*       */   String thinNetAuthenticationServices;
/*       */   String thinNetAuthenticationKrb5Mutual;
/*       */   String thinNetAuthenticationKrb5CcName;
/*       */   String thinNetEncryptionLevel;
/*       */   String thinNetEncryptionTypes;
/*       */   String thinNetChecksumLevel;
/*       */   String thinNetChecksumTypes;
/*       */   String thinNetCryptoSeed;
/*       */   boolean thinTcpNoDelay;
/*       */   String thinReadTimeout;
/*       */   String thinNetConnectTimeout;
/*       */   boolean thinNetDisableOutOfBandBreak;
/*       */   boolean thinNetUseZeroCopyIO;
/*       */   boolean use1900AsYearForTime;
/*       */   boolean timestamptzInGmt;
/*       */   boolean timezoneAsRegion;
/*       */   String thinSslServerDnMatch;
/*       */   String thinSslVersion;
/*       */   String thinSslCipherSuites;
/*       */   String thinJavaxNetSslKeystore;
/*       */   String thinJavaxNetSslKeystoretype;
/*       */   String thinJavaxNetSslKeystorepassword;
/*       */   String thinJavaxNetSslTruststore;
/*       */   String thinJavaxNetSslTruststoretype;
/*       */   String thinJavaxNetSslTruststorepassword;
/*       */   String thinSslKeymanagerfactoryAlgorithm;
/*       */   String thinSslTrustmanagerfactoryAlgorithm;
/*       */   String thinNetOldsyntax;
/*       */   String thinNamingContextInitial;
/*       */   String thinNamingProviderUrl;
/*       */   String thinNamingSecurityAuthentication;
/*       */   String thinNamingSecurityPrincipal;
/*       */   String thinNamingSecurityCredentials;
/*       */   String thinJndiLdapConnectTimeout;
/*       */   String thinJndiLdapReadTimeout;
/*       */   String walletLocation;
/*       */   String walletPassword;
/*       */   String proxyClientName;
/*       */   boolean useNio;
/*       */   String ociDriverCharset;
/*       */   String editionName;
/*       */   String logonCap;
/*       */   boolean useOCIDefaultDefines;
/*       */   String internalLogon;
/*       */   boolean createDescriptorUseCurrentSchemaForSchemaName;
/*       */   long ociSvcCtxHandle;
/*       */   long ociEnvHandle;
/*       */   long ociErrHandle;
/*       */   boolean prelimAuth;
/*       */   boolean jmsNotificationConnection;
/*       */   boolean nlsLangBackdoor;
/*       */   String setNewPassword;
/*       */   boolean spawnNewThreadToCancel;
/*       */   int defaultExecuteBatch;
/*       */   int defaultRowPrefetch;
/*       */   int defaultLobPrefetchSize;
/*       */   boolean enableDataInLocator;
/*       */   boolean enableReadDataInLocator;
/*       */   boolean overrideEnableReadDataInLocator;
/*       */   boolean reportRemarks;
/*       */   boolean includeSynonyms;
/*       */   boolean restrictGettables;
/*       */   boolean accumulateBatchResult;
/*       */   boolean useFetchSizeWithLongColumn;
/*       */   boolean processEscapes;
/*       */   boolean fixedString;
/*       */   boolean defaultnchar;
/*       */   boolean permitTimestampDateMismatch;
/*       */   String resourceManagerId;
/*       */   boolean disableDefinecolumntype;
/*       */   boolean convertNcharLiterals;
/*       */   boolean autoCommitSpecCompliant;
/*       */   boolean j2ee13Compliant;
/*       */   boolean mapDateToTimestamp;
/*       */   boolean useThreadLocalBufferCache;
/*       */   String driverNameAttribute;
/*       */   int maxCachedBufferSize;
/*       */   int implicitStatementCacheSize;
/*       */   boolean lobStreamPosStandardCompliant;
/*       */   boolean isStrictAsciiConversion;
/*       */   String drcpConnectionClass;
/*       */   String drcpTagName;
/*       */   String blockSourceImpl;
/*       */   boolean thinForceDnsLoadBalancing;
/*       */   boolean enableTempLobRefCnt;
/*       */   boolean keepAlive;
/*       */   String sqlTranslationProfile;
/*       */   String sqlErrorTranslationFile;
/*       */   boolean ignoreReplayContextFromAuthentication;
/*       */   boolean javaNetNio;
/*       */   boolean nsDirectBuffer;
/*       */   boolean plsqlVarcharParameter4KOnly;
/*       */   String targetInstanceName;
/*       */   boolean enableOCIFAN;
/*       */   public OracleConnection.ChecksumMode checksumMode;
/*       */   boolean isPDBChanged;
/*       */   boolean autocommit;
/*       */   String url;
/*       */   String savedUser;
/*       */   int commitOption;
/*   292 */   int ociConnectionPoolMinLimit = 0;
/*   293 */   int ociConnectionPoolMaxLimit = 0;
/*   294 */   int ociConnectionPoolIncrement = 0;
/*   295 */   int ociConnectionPoolTimeout = 0;
/*       */   boolean ociConnectionPoolNoWait = false;
/*       */   boolean ociConnectionPoolTransactionDistributed = false;
/*   298 */   String ociConnectionPoolLogonMode = null;
/*       */   boolean ociConnectionPoolIsPooling = false;
/*   300 */   Object ociConnectionPoolObject = null;
/*   301 */   Object ociConnectionPoolConnID = null;
/*   302 */   String ociConnectionPoolProxyType = null;
/*   303 */   Integer ociConnectionPoolProxyNumRoles = Integer.valueOf(0);
/*   304 */   Object ociConnectionPoolProxyRoles = null;
/*   305 */   String ociConnectionPoolProxyUserName = null;
/*   306 */   String ociConnectionPoolProxyPassword = null;
/*   307 */   String ociConnectionPoolProxyDistinguishedName = null;
/*   308 */   Object ociConnectionPoolProxyCertificate = null;
/*       */   
/*   310 */   static NTFManager ntfManager = new NTFManager();
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*   321 */   public int protocolId = -3;
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   OracleTimeout timeout;
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   DBConversion conversion;
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   boolean xaWantsError;
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   boolean usingXA;
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*   346 */   int txnMode = 0;
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   byte[] fdo;
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   Boolean bigEndian;
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   OracleStatement statements;
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   int lifecycle;
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   static final int OPEN = 1;
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   static final int CLOSING = 2;
/*       */ 
/*       */ 
/*       */   
/*       */   static final int CLOSED = 4;
/*       */ 
/*       */ 
/*       */   
/*       */   static final int ABORTED = 8;
/*       */ 
/*       */ 
/*       */   
/*       */   static final int BLOCKED = 16;
/*       */ 
/*       */ 
/*       */   
/*       */   boolean clientIdSet = false;
/*       */ 
/*       */ 
/*       */   
/*   396 */   String clientId = null;
/*       */ 
/*       */ 
/*       */   
/*       */   int txnLevel;
/*       */ 
/*       */ 
/*       */   
/*       */   Map map;
/*       */ 
/*       */ 
/*       */   
/*       */   Map javaObjectMap;
/*       */ 
/*       */ 
/*       */   
/*   412 */   final Hashtable[] descriptorCacheStack = new Hashtable[2];
/*       */   
/*   414 */   int dci = 0;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   OracleStatement statementHoldingLine;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*   426 */   OracleDatabaseMetaData databaseMetaData = null;
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   LogicalConnection logicalConnectionAttached;
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   boolean isProxy = false;
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*   441 */   OracleSql sqlObj = null;
/*       */ 
/*       */   
/*   444 */   SQLWarning sqlWarning = null;
/*       */ 
/*       */ 
/*       */   
/*       */   boolean readOnly = false;
/*       */ 
/*       */ 
/*       */   
/*   452 */   LRUStatementCache statementCache = null;
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   boolean clearStatementMetaData = false;
/*       */ 
/*       */ 
/*       */   
/*   461 */   OracleCloseCallback closeCallback = null;
/*   462 */   Object privateData = null;
/*       */ 
/*       */   
/*   465 */   Statement savepointStatement = null;
/*       */ 
/*       */   
/*       */   boolean isUsable = true;
/*       */   
/*   470 */   TimeZone defaultTimeZone = null;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   static final int END_TO_END_DBOP_INDEX = 4;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   static final int END_TO_END_STATE_INDEX_MAX_POST_1200 = 5;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*   504 */   final int[] endToEndMaxLength = new int[5];
/*       */   
/*       */   boolean endToEndAnyChanged = false;
/*   507 */   final boolean[] endToEndHasChanged = new boolean[5];
/*   508 */   short endToEndECIDSequenceNumber = Short.MIN_VALUE;
/*       */ 
/*       */   
/*       */   static final int DMS_NONE = 0;
/*       */ 
/*       */   
/*       */   static final int DMS_10G = 1;
/*       */   
/*       */   static final int DMS_11 = 2;
/*       */   
/*   518 */   String[] endToEndValues = new String[5];
/*   519 */   final int whichDMS = 0;
/*       */ 
/*       */ 
/*       */   
/*   523 */   OracleConnection wrapper = null;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   int minVcsBindSize;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   int maxRawBytesSql;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   int maxRawBytesPlsql;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   int maxVcsCharsSql;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   int maxVcsNCharsSql;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   int maxVcsBytesPlsql;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   int maxVcsBytesPlsqlOut;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   int maxIbtVarcharElementLength;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   int maxVarcharLength;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   int maxNVarcharLength;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   int maxRawLength;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*   595 */   String instanceName = null;
/*   596 */   String dbName = null;
/*       */   OracleDriverExtension driverExtension;
/*       */   static final String uninitializedMarker = "";
/*   599 */   String databaseProductVersion = "";
/*   600 */   short versionNumber = -1;
/*       */ 
/*       */ 
/*       */   
/*       */   int namedTypeAccessorByteLen;
/*       */ 
/*       */ 
/*       */   
/*       */   int refTypeAccessorByteLen;
/*       */ 
/*       */   
/*       */   CharacterSet setCHARCharSetObj;
/*       */ 
/*       */   
/*       */   CharacterSet setCHARNCharSetObj;
/*       */ 
/*       */   
/*       */   protected final Object cancelInProgressLockForThin;
/*       */ 
/*       */   
/*       */   boolean plsqlCompilerWarnings = false;
/*       */ 
/*       */   
/*       */   private boolean savedAutoCommitFlag;
/*       */ 
/*       */   
/*       */   private int savedTxnMode;
/*       */ 
/*       */   
/*       */   private BlockSource blockSource;
/*       */ 
/*       */   
/*   632 */   int thinACLastLtxidHash = 0;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   LogicalTransactionId thinACCurrentLTXID;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*   646 */   ReplayContext[] thinACReplayContextReceived = new ReplayContext[10];
/*   647 */   int thinACReplayContextReceivedCurrent = 0;
/*       */   
/*   649 */   ReplayContext thinACLastReplayContextReceived = null;
/*       */   
/*   651 */   enum DrcpState { STATEFUL, STATELESS; }
/*   652 */   DrcpState drcpState = DrcpState.STATELESS; boolean currentlyInTransaction = false;
/*       */   boolean drcpEnabled = false;
/*       */   
/*       */   protected BlockSource setBlockSource() {
/*   656 */     return BlockSource.createBlockSource(this.useThreadLocalBufferCache, BlockSource.Implementation.THREADED);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   int getMaxSizeForVarchar(OracleStatement.SqlKind paramSqlKind, int paramInt, boolean paramBoolean) throws SQLException {
/*   861 */     int i = 0;
/*   862 */     if (paramSqlKind == OracleStatement.SqlKind.PLSQL_BLOCK) {
/*   863 */       if (paramInt > 0) {
/*   864 */         i = Math.max(this.maxVcsBytesPlsql, paramInt);
/*       */       }
/*   866 */       else if (paramBoolean) {
/*   867 */         i = 4000;
/*       */       } else {
/*       */         
/*   870 */         i = this.maxVcsBytesPlsqlOut;
/*       */       } 
/*       */     } else {
/*       */       
/*   874 */       i = this.maxVarcharLength;
/*       */     } 
/*   876 */     return i;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   void additionalInitialization() throws SQLException {}
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static final String propertyVariableName(String paramString) {
/*   891 */     char[] arrayOfChar = new char[paramString.length()];
/*   892 */     paramString.getChars(0, paramString.length(), arrayOfChar, 0);
/*   893 */     String str = "";
/*   894 */     for (byte b = 0; b < arrayOfChar.length; b++) {
/*       */       
/*   896 */       if (Character.isUpperCase(arrayOfChar[b]))
/*   897 */         str = str + "_"; 
/*   898 */       str = str + Character.toUpperCase(arrayOfChar[b]);
/*       */     } 
/*   900 */     return str;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private void initializeUserDefaults(Properties paramProperties) {
/*   913 */     for (String str : OracleDriver.DEFAULT_CONNECTION_PROPERTIES.stringPropertyNames()) {
/*   914 */       if (!paramProperties.containsKey(str)) {
/*   915 */         paramProperties.setProperty(str, OracleDriver.DEFAULT_CONNECTION_PROPERTIES.getProperty(str));
/*       */       }
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private void readConnectionProperties(String paramString, Properties paramProperties) throws SQLException {
/*   942 */     initializeUserDefaults(paramProperties);
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*   947 */     String str1 = null;
/*       */ 
/*       */     
/*   950 */     str1 = null;
/*   951 */     if (paramProperties != null)
/*       */     {
/*   953 */       str1 = paramProperties.getProperty("oracle.jdbc.RetainV9LongBindBehavior");
/*       */     }
/*   955 */     if (str1 == null)
/*   956 */       str1 = getSystemProperty("oracle.jdbc.RetainV9LongBindBehavior", (String)null); 
/*   957 */     if (str1 == null) {
/*   958 */       str1 = "false";
/*       */     }
/*       */     
/*   961 */     this.retainV9BindBehavior = (str1 != null && str1.equalsIgnoreCase("true"));
/*       */ 
/*       */     
/*   964 */     str1 = null;
/*   965 */     if (paramProperties != null) {
/*       */       
/*   967 */       str1 = paramProperties.getProperty("user");
/*   968 */       if (str1 == null)
/*   969 */         str1 = paramProperties.getProperty("oracle.jdbc.user"); 
/*       */     } 
/*   971 */     if (str1 == null)
/*   972 */       str1 = getSystemProperty("oracle.jdbc.user", (String)null); 
/*   973 */     if (str1 == null) {
/*   974 */       str1 = null;
/*       */     }
/*       */     
/*   977 */     this.userName = str1;
/*       */ 
/*       */     
/*   980 */     str1 = null;
/*   981 */     if (paramProperties != null) {
/*       */       
/*   983 */       str1 = paramProperties.getProperty("database");
/*   984 */       if (str1 == null)
/*   985 */         str1 = paramProperties.getProperty("oracle.jdbc.database"); 
/*       */     } 
/*   987 */     if (str1 == null)
/*   988 */       str1 = getSystemProperty("oracle.jdbc.database", (String)null); 
/*   989 */     if (str1 == null) {
/*   990 */       str1 = null;
/*       */     }
/*       */     
/*   993 */     this.database = str1;
/*       */ 
/*       */     
/*   996 */     str1 = null;
/*   997 */     if (paramProperties != null) {
/*       */       
/*   999 */       str1 = paramProperties.getProperty("autoCommit");
/*  1000 */       if (str1 == null)
/*  1001 */         str1 = paramProperties.getProperty("oracle.jdbc.autoCommit"); 
/*       */     } 
/*  1003 */     if (str1 == null)
/*  1004 */       str1 = getSystemProperty("oracle.jdbc.autoCommit", (String)null); 
/*  1005 */     if (str1 == null) {
/*  1006 */       str1 = "true";
/*       */     }
/*       */     
/*  1009 */     this.defaultautocommit = (str1 != null && str1.equalsIgnoreCase("true"));
/*       */ 
/*       */     
/*  1012 */     str1 = null;
/*  1013 */     if (paramProperties != null) {
/*       */       
/*  1015 */       str1 = paramProperties.getProperty("protocol");
/*  1016 */       if (str1 == null)
/*  1017 */         str1 = paramProperties.getProperty("oracle.jdbc.protocol"); 
/*       */     } 
/*  1019 */     if (str1 == null)
/*  1020 */       str1 = getSystemProperty("oracle.jdbc.protocol", (String)null); 
/*  1021 */     if (str1 == null) {
/*  1022 */       str1 = null;
/*       */     }
/*       */     
/*  1025 */     this.protocol = str1;
/*       */ 
/*       */     
/*  1028 */     str1 = null;
/*  1029 */     if (paramProperties != null)
/*       */     {
/*  1031 */       str1 = paramProperties.getProperty("oracle.jdbc.StreamChunkSize");
/*       */     }
/*  1033 */     if (str1 == null)
/*  1034 */       str1 = getSystemProperty("oracle.jdbc.StreamChunkSize", (String)null); 
/*  1035 */     if (str1 == null) {
/*  1036 */       str1 = "32767";
/*       */     }
/*       */     try {
/*  1039 */       this.streamChunkSize = Integer.parseInt(str1);
/*  1040 */     } catch (NumberFormatException numberFormatException) {
/*       */ 
/*       */ 
/*       */       
/*  1044 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 190, "Property is 'streamChunkSize'");
/*  1045 */       sQLException.fillInStackTrace();
/*  1046 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*  1052 */     str1 = null;
/*  1053 */     if (paramProperties != null) {
/*       */       
/*  1055 */       str1 = paramProperties.getProperty("SetFloatAndDoubleUseBinary");
/*  1056 */       if (str1 == null)
/*  1057 */         str1 = paramProperties.getProperty("oracle.jdbc.SetFloatAndDoubleUseBinary"); 
/*       */     } 
/*  1059 */     if (str1 == null)
/*  1060 */       str1 = getSystemProperty("oracle.jdbc.SetFloatAndDoubleUseBinary", (String)null); 
/*  1061 */     if (str1 == null) {
/*  1062 */       str1 = "false";
/*       */     }
/*       */     
/*  1065 */     this.setFloatAndDoubleUseBinary = (str1 != null && str1.equalsIgnoreCase("true"));
/*       */ 
/*       */     
/*  1068 */     str1 = null;
/*  1069 */     if (paramProperties != null)
/*       */     {
/*  1071 */       str1 = paramProperties.getProperty("oracle.jdbc.ocinativelibrary");
/*       */     }
/*  1073 */     if (str1 == null)
/*  1074 */       str1 = getSystemProperty("oracle.jdbc.ocinativelibrary", (String)null); 
/*  1075 */     if (str1 == null) {
/*  1076 */       str1 = null;
/*       */     }
/*       */     
/*  1079 */     this.ocidll = str1;
/*       */ 
/*       */     
/*  1082 */     str1 = null;
/*  1083 */     if (paramProperties != null) {
/*       */       
/*  1085 */       str1 = paramProperties.getProperty("v$session.terminal");
/*  1086 */       if (str1 == null)
/*  1087 */         str1 = paramProperties.getProperty("oracle.jdbc.v$session.terminal"); 
/*       */     } 
/*  1089 */     if (str1 == null)
/*  1090 */       str1 = getSystemProperty("oracle.jdbc.v$session.terminal", (String)null); 
/*  1091 */     if (str1 == null) {
/*  1092 */       str1 = "unknown";
/*       */     }
/*       */     
/*  1095 */     this.thinVsessionTerminal = str1;
/*       */ 
/*       */     
/*  1098 */     str1 = null;
/*  1099 */     if (paramProperties != null) {
/*       */       
/*  1101 */       str1 = paramProperties.getProperty("v$session.machine");
/*  1102 */       if (str1 == null)
/*  1103 */         str1 = paramProperties.getProperty("oracle.jdbc.v$session.machine"); 
/*       */     } 
/*  1105 */     if (str1 == null)
/*  1106 */       str1 = getSystemProperty("oracle.jdbc.v$session.machine", (String)null); 
/*  1107 */     if (str1 == null) {
/*  1108 */       str1 = null;
/*       */     }
/*       */     
/*  1111 */     this.thinVsessionMachine = str1;
/*       */ 
/*       */     
/*  1114 */     str1 = null;
/*  1115 */     if (paramProperties != null) {
/*       */       
/*  1117 */       str1 = paramProperties.getProperty("v$session.osuser");
/*  1118 */       if (str1 == null)
/*  1119 */         str1 = paramProperties.getProperty("oracle.jdbc.v$session.osuser"); 
/*       */     } 
/*  1121 */     if (str1 == null)
/*  1122 */       str1 = getSystemProperty("oracle.jdbc.v$session.osuser", (String)null); 
/*  1123 */     if (str1 == null) {
/*  1124 */       str1 = null;
/*       */     }
/*       */     
/*  1127 */     this.thinVsessionOsuser = str1;
/*       */ 
/*       */     
/*  1130 */     str1 = null;
/*  1131 */     if (paramProperties != null) {
/*       */       
/*  1133 */       str1 = paramProperties.getProperty("v$session.program");
/*  1134 */       if (str1 == null)
/*  1135 */         str1 = paramProperties.getProperty("oracle.jdbc.v$session.program"); 
/*       */     } 
/*  1137 */     if (str1 == null)
/*  1138 */       str1 = getSystemProperty("oracle.jdbc.v$session.program", (String)null); 
/*  1139 */     if (str1 == null) {
/*  1140 */       str1 = "JDBC Thin Client";
/*       */     }
/*       */     
/*  1143 */     this.thinVsessionProgram = str1;
/*       */ 
/*       */     
/*  1146 */     str1 = null;
/*  1147 */     if (paramProperties != null) {
/*       */       
/*  1149 */       str1 = paramProperties.getProperty("v$session.process");
/*  1150 */       if (str1 == null)
/*  1151 */         str1 = paramProperties.getProperty("oracle.jdbc.v$session.process"); 
/*       */     } 
/*  1153 */     if (str1 == null)
/*  1154 */       str1 = getSystemProperty("oracle.jdbc.v$session.process", (String)null); 
/*  1155 */     if (str1 == null) {
/*  1156 */       str1 = "1234";
/*       */     }
/*       */     
/*  1159 */     this.thinVsessionProcess = str1;
/*       */ 
/*       */     
/*  1162 */     str1 = null;
/*  1163 */     if (paramProperties != null) {
/*       */       
/*  1165 */       str1 = paramProperties.getProperty("v$session.iname");
/*  1166 */       if (str1 == null)
/*  1167 */         str1 = paramProperties.getProperty("oracle.jdbc.v$session.iname"); 
/*       */     } 
/*  1169 */     if (str1 == null)
/*  1170 */       str1 = getSystemProperty("oracle.jdbc.v$session.iname", (String)null); 
/*  1171 */     if (str1 == null) {
/*  1172 */       str1 = "jdbc_ttc_impl";
/*       */     }
/*       */     
/*  1175 */     this.thinVsessionIname = str1;
/*       */ 
/*       */     
/*  1178 */     str1 = null;
/*  1179 */     if (paramProperties != null) {
/*       */       
/*  1181 */       str1 = paramProperties.getProperty("v$session.ename");
/*  1182 */       if (str1 == null)
/*  1183 */         str1 = paramProperties.getProperty("oracle.jdbc.v$session.ename"); 
/*       */     } 
/*  1185 */     if (str1 == null)
/*  1186 */       str1 = getSystemProperty("oracle.jdbc.v$session.ename", (String)null); 
/*  1187 */     if (str1 == null) {
/*  1188 */       str1 = null;
/*       */     }
/*       */     
/*  1191 */     this.thinVsessionEname = str1;
/*       */ 
/*       */     
/*  1194 */     str1 = null;
/*  1195 */     if (paramProperties != null)
/*       */     {
/*  1197 */       str1 = paramProperties.getProperty("oracle.net.profile");
/*       */     }
/*  1199 */     if (str1 == null)
/*  1200 */       str1 = getSystemProperty("oracle.net.profile", (String)null); 
/*  1201 */     if (str1 == null) {
/*  1202 */       str1 = null;
/*       */     }
/*       */     
/*  1205 */     this.thinNetProfile = str1;
/*       */ 
/*       */     
/*  1208 */     str1 = null;
/*  1209 */     if (paramProperties != null)
/*       */     {
/*  1211 */       str1 = paramProperties.getProperty("oracle.net.authentication_services");
/*       */     }
/*  1213 */     if (str1 == null)
/*  1214 */       str1 = getSystemProperty("oracle.net.authentication_services", (String)null); 
/*  1215 */     if (str1 == null) {
/*  1216 */       str1 = null;
/*       */     }
/*       */     
/*  1219 */     this.thinNetAuthenticationServices = str1;
/*       */ 
/*       */     
/*  1222 */     str1 = null;
/*  1223 */     if (paramProperties != null)
/*       */     {
/*  1225 */       str1 = paramProperties.getProperty("oracle.net.kerberos5_mutual_authentication");
/*       */     }
/*  1227 */     if (str1 == null)
/*  1228 */       str1 = getSystemProperty("oracle.net.kerberos5_mutual_authentication", (String)null); 
/*  1229 */     if (str1 == null) {
/*  1230 */       str1 = null;
/*       */     }
/*       */     
/*  1233 */     this.thinNetAuthenticationKrb5Mutual = str1;
/*       */ 
/*       */     
/*  1236 */     str1 = null;
/*  1237 */     if (paramProperties != null)
/*       */     {
/*  1239 */       str1 = paramProperties.getProperty("oracle.net.kerberos5_cc_name");
/*       */     }
/*  1241 */     if (str1 == null)
/*  1242 */       str1 = getSystemProperty("oracle.net.kerberos5_cc_name", (String)null); 
/*  1243 */     if (str1 == null) {
/*  1244 */       str1 = null;
/*       */     }
/*       */     
/*  1247 */     this.thinNetAuthenticationKrb5CcName = str1;
/*       */ 
/*       */     
/*  1250 */     str1 = null;
/*  1251 */     if (paramProperties != null)
/*       */     {
/*  1253 */       str1 = paramProperties.getProperty("oracle.net.encryption_client");
/*       */     }
/*  1255 */     if (str1 == null)
/*  1256 */       str1 = getSystemProperty("oracle.net.encryption_client", (String)null); 
/*  1257 */     if (str1 == null) {
/*  1258 */       str1 = null;
/*       */     }
/*       */     
/*  1261 */     this.thinNetEncryptionLevel = str1;
/*       */ 
/*       */     
/*  1264 */     str1 = null;
/*  1265 */     if (paramProperties != null)
/*       */     {
/*  1267 */       str1 = paramProperties.getProperty("oracle.net.encryption_types_client");
/*       */     }
/*  1269 */     if (str1 == null)
/*  1270 */       str1 = getSystemProperty("oracle.net.encryption_types_client", (String)null); 
/*  1271 */     if (str1 == null) {
/*  1272 */       str1 = null;
/*       */     }
/*       */     
/*  1275 */     this.thinNetEncryptionTypes = str1;
/*       */ 
/*       */     
/*  1278 */     str1 = null;
/*  1279 */     if (paramProperties != null)
/*       */     {
/*  1281 */       str1 = paramProperties.getProperty("oracle.net.crypto_checksum_client");
/*       */     }
/*  1283 */     if (str1 == null)
/*  1284 */       str1 = getSystemProperty("oracle.net.crypto_checksum_client", (String)null); 
/*  1285 */     if (str1 == null) {
/*  1286 */       str1 = null;
/*       */     }
/*       */     
/*  1289 */     this.thinNetChecksumLevel = str1;
/*       */ 
/*       */     
/*  1292 */     str1 = null;
/*  1293 */     if (paramProperties != null)
/*       */     {
/*  1295 */       str1 = paramProperties.getProperty("oracle.net.crypto_checksum_types_client");
/*       */     }
/*  1297 */     if (str1 == null)
/*  1298 */       str1 = getSystemProperty("oracle.net.crypto_checksum_types_client", (String)null); 
/*  1299 */     if (str1 == null) {
/*  1300 */       str1 = null;
/*       */     }
/*       */     
/*  1303 */     this.thinNetChecksumTypes = str1;
/*       */ 
/*       */     
/*  1306 */     str1 = null;
/*  1307 */     if (paramProperties != null)
/*       */     {
/*  1309 */       str1 = paramProperties.getProperty("oracle.net.crypto_seed");
/*       */     }
/*  1311 */     if (str1 == null)
/*  1312 */       str1 = getSystemProperty("oracle.net.crypto_seed", (String)null); 
/*  1313 */     if (str1 == null) {
/*  1314 */       str1 = null;
/*       */     }
/*       */     
/*  1317 */     this.thinNetCryptoSeed = str1;
/*       */ 
/*       */     
/*  1320 */     str1 = null;
/*  1321 */     if (paramProperties != null)
/*       */     {
/*  1323 */       str1 = paramProperties.getProperty("oracle.jdbc.TcpNoDelay");
/*       */     }
/*  1325 */     if (str1 == null)
/*  1326 */       str1 = getSystemProperty("oracle.jdbc.TcpNoDelay", (String)null); 
/*  1327 */     if (str1 == null) {
/*  1328 */       str1 = "false";
/*       */     }
/*       */     
/*  1331 */     this.thinTcpNoDelay = (str1 != null && str1.equalsIgnoreCase("true"));
/*       */ 
/*       */     
/*  1334 */     str1 = null;
/*  1335 */     if (paramProperties != null)
/*       */     {
/*  1337 */       str1 = paramProperties.getProperty("oracle.jdbc.ReadTimeout");
/*       */     }
/*  1339 */     if (str1 == null)
/*  1340 */       str1 = getSystemProperty("oracle.jdbc.ReadTimeout", (String)null); 
/*  1341 */     if (str1 == null) {
/*  1342 */       str1 = null;
/*       */     }
/*       */     
/*  1345 */     this.thinReadTimeout = str1;
/*       */ 
/*       */     
/*  1348 */     str1 = null;
/*  1349 */     if (paramProperties != null)
/*       */     {
/*  1351 */       str1 = paramProperties.getProperty("oracle.net.CONNECT_TIMEOUT");
/*       */     }
/*  1353 */     if (str1 == null)
/*  1354 */       str1 = getSystemProperty("oracle.net.CONNECT_TIMEOUT", (String)null); 
/*  1355 */     if (str1 == null) {
/*  1356 */       str1 = null;
/*       */     }
/*       */     
/*  1359 */     this.thinNetConnectTimeout = str1;
/*       */ 
/*       */     
/*  1362 */     str1 = null;
/*  1363 */     if (paramProperties != null)
/*       */     {
/*  1365 */       str1 = paramProperties.getProperty("oracle.net.disableOob");
/*       */     }
/*  1367 */     if (str1 == null)
/*  1368 */       str1 = getSystemProperty("oracle.net.disableOob", (String)null); 
/*  1369 */     if (str1 == null) {
/*  1370 */       str1 = "false";
/*       */     }
/*       */     
/*  1373 */     this.thinNetDisableOutOfBandBreak = (str1 != null && str1.equalsIgnoreCase("true"));
/*       */ 
/*       */     
/*  1376 */     str1 = null;
/*  1377 */     if (paramProperties != null)
/*       */     {
/*  1379 */       str1 = paramProperties.getProperty("oracle.net.useZeroCopyIO");
/*       */     }
/*  1381 */     if (str1 == null)
/*  1382 */       str1 = getSystemProperty("oracle.net.useZeroCopyIO", (String)null); 
/*  1383 */     if (str1 == null) {
/*  1384 */       str1 = "true";
/*       */     }
/*       */     
/*  1387 */     this.thinNetUseZeroCopyIO = (str1 != null && str1.equalsIgnoreCase("true"));
/*       */ 
/*       */     
/*  1390 */     str1 = null;
/*  1391 */     if (paramProperties != null)
/*       */     {
/*  1393 */       str1 = paramProperties.getProperty("oracle.jdbc.use1900AsYearForTime");
/*       */     }
/*  1395 */     if (str1 == null)
/*  1396 */       str1 = getSystemProperty("oracle.jdbc.use1900AsYearForTime", (String)null); 
/*  1397 */     if (str1 == null) {
/*  1398 */       str1 = "false";
/*       */     }
/*       */     
/*  1401 */     this.use1900AsYearForTime = (str1 != null && str1.equalsIgnoreCase("true"));
/*       */ 
/*       */     
/*  1404 */     str1 = null;
/*  1405 */     if (paramProperties != null)
/*       */     {
/*  1407 */       str1 = paramProperties.getProperty("oracle.jdbc.timestampTzInGmt");
/*       */     }
/*  1409 */     if (str1 == null)
/*  1410 */       str1 = getSystemProperty("oracle.jdbc.timestampTzInGmt", (String)null); 
/*  1411 */     if (str1 == null) {
/*  1412 */       str1 = "true";
/*       */     }
/*       */     
/*  1415 */     this.timestamptzInGmt = (str1 != null && str1.equalsIgnoreCase("true"));
/*       */ 
/*       */     
/*  1418 */     str1 = null;
/*  1419 */     if (paramProperties != null)
/*       */     {
/*  1421 */       str1 = paramProperties.getProperty("oracle.jdbc.timezoneAsRegion");
/*       */     }
/*  1423 */     if (str1 == null)
/*  1424 */       str1 = getSystemProperty("oracle.jdbc.timezoneAsRegion", (String)null); 
/*  1425 */     if (str1 == null) {
/*  1426 */       str1 = "true";
/*       */     }
/*       */     
/*  1429 */     this.timezoneAsRegion = (str1 != null && str1.equalsIgnoreCase("true"));
/*       */ 
/*       */     
/*  1432 */     str1 = null;
/*  1433 */     if (paramProperties != null)
/*       */     {
/*  1435 */       str1 = paramProperties.getProperty("oracle.net.ssl_server_dn_match");
/*       */     }
/*  1437 */     if (str1 == null)
/*  1438 */       str1 = getSystemProperty("oracle.net.ssl_server_dn_match", (String)null); 
/*  1439 */     if (str1 == null) {
/*  1440 */       str1 = null;
/*       */     }
/*       */     
/*  1443 */     this.thinSslServerDnMatch = str1;
/*       */ 
/*       */     
/*  1446 */     str1 = null;
/*  1447 */     if (paramProperties != null)
/*       */     {
/*  1449 */       str1 = paramProperties.getProperty("oracle.net.ssl_version");
/*       */     }
/*  1451 */     if (str1 == null)
/*  1452 */       str1 = getSystemProperty("oracle.net.ssl_version", (String)null); 
/*  1453 */     if (str1 == null) {
/*  1454 */       str1 = null;
/*       */     }
/*       */     
/*  1457 */     this.thinSslVersion = str1;
/*       */ 
/*       */     
/*  1460 */     str1 = null;
/*  1461 */     if (paramProperties != null)
/*       */     {
/*  1463 */       str1 = paramProperties.getProperty("oracle.net.ssl_cipher_suites");
/*       */     }
/*  1465 */     if (str1 == null)
/*  1466 */       str1 = getSystemProperty("oracle.net.ssl_cipher_suites", (String)null); 
/*  1467 */     if (str1 == null) {
/*  1468 */       str1 = null;
/*       */     }
/*       */     
/*  1471 */     this.thinSslCipherSuites = str1;
/*       */ 
/*       */     
/*  1474 */     str1 = null;
/*  1475 */     if (paramProperties != null)
/*       */     {
/*  1477 */       str1 = paramProperties.getProperty("javax.net.ssl.keyStore");
/*       */     }
/*  1479 */     if (str1 == null)
/*  1480 */       str1 = getSystemProperty("javax.net.ssl.keyStore", (String)null); 
/*  1481 */     if (str1 == null) {
/*  1482 */       str1 = null;
/*       */     }
/*       */     
/*  1485 */     this.thinJavaxNetSslKeystore = str1;
/*       */ 
/*       */     
/*  1488 */     str1 = null;
/*  1489 */     if (paramProperties != null)
/*       */     {
/*  1491 */       str1 = paramProperties.getProperty("javax.net.ssl.keyStoreType");
/*       */     }
/*  1493 */     if (str1 == null)
/*  1494 */       str1 = getSystemProperty("javax.net.ssl.keyStoreType", (String)null); 
/*  1495 */     if (str1 == null) {
/*  1496 */       str1 = null;
/*       */     }
/*       */     
/*  1499 */     this.thinJavaxNetSslKeystoretype = str1;
/*       */ 
/*       */     
/*  1502 */     str1 = null;
/*  1503 */     if (paramProperties != null)
/*       */     {
/*  1505 */       str1 = paramProperties.getProperty("javax.net.ssl.keyStorePassword");
/*       */     }
/*  1507 */     if (str1 == null)
/*  1508 */       str1 = getSystemProperty("javax.net.ssl.keyStorePassword", (String)null); 
/*  1509 */     if (str1 == null) {
/*  1510 */       str1 = null;
/*       */     }
/*       */     
/*  1513 */     this.thinJavaxNetSslKeystorepassword = str1;
/*       */ 
/*       */     
/*  1516 */     str1 = null;
/*  1517 */     if (paramProperties != null)
/*       */     {
/*  1519 */       str1 = paramProperties.getProperty("javax.net.ssl.trustStore");
/*       */     }
/*  1521 */     if (str1 == null)
/*  1522 */       str1 = getSystemProperty("javax.net.ssl.trustStore", (String)null); 
/*  1523 */     if (str1 == null) {
/*  1524 */       str1 = null;
/*       */     }
/*       */     
/*  1527 */     this.thinJavaxNetSslTruststore = str1;
/*       */ 
/*       */     
/*  1530 */     str1 = null;
/*  1531 */     if (paramProperties != null)
/*       */     {
/*  1533 */       str1 = paramProperties.getProperty("javax.net.ssl.trustStoreType");
/*       */     }
/*  1535 */     if (str1 == null)
/*  1536 */       str1 = getSystemProperty("javax.net.ssl.trustStoreType", (String)null); 
/*  1537 */     if (str1 == null) {
/*  1538 */       str1 = null;
/*       */     }
/*       */     
/*  1541 */     this.thinJavaxNetSslTruststoretype = str1;
/*       */ 
/*       */     
/*  1544 */     str1 = null;
/*  1545 */     if (paramProperties != null)
/*       */     {
/*  1547 */       str1 = paramProperties.getProperty("javax.net.ssl.trustStorePassword");
/*       */     }
/*  1549 */     if (str1 == null)
/*  1550 */       str1 = getSystemProperty("javax.net.ssl.trustStorePassword", (String)null); 
/*  1551 */     if (str1 == null) {
/*  1552 */       str1 = null;
/*       */     }
/*       */     
/*  1555 */     this.thinJavaxNetSslTruststorepassword = str1;
/*       */ 
/*       */     
/*  1558 */     str1 = null;
/*  1559 */     if (paramProperties != null) {
/*       */       
/*  1561 */       str1 = paramProperties.getProperty("ssl.keyManagerFactory.algorithm");
/*  1562 */       if (str1 == null)
/*  1563 */         str1 = paramProperties.getProperty("oracle.jdbc.ssl.keyManagerFactory.algorithm"); 
/*       */     } 
/*  1565 */     if (str1 == null)
/*  1566 */       str1 = getSystemProperty("oracle.jdbc.ssl.keyManagerFactory.algorithm", (String)null); 
/*  1567 */     if (str1 == null) {
/*  1568 */       str1 = null;
/*       */     }
/*       */     
/*  1571 */     this.thinSslKeymanagerfactoryAlgorithm = str1;
/*       */ 
/*       */     
/*  1574 */     str1 = null;
/*  1575 */     if (paramProperties != null) {
/*       */       
/*  1577 */       str1 = paramProperties.getProperty("ssl.trustManagerFactory.algorithm");
/*  1578 */       if (str1 == null)
/*  1579 */         str1 = paramProperties.getProperty("oracle.jdbc.ssl.trustManagerFactory.algorithm"); 
/*       */     } 
/*  1581 */     if (str1 == null)
/*  1582 */       str1 = getSystemProperty("oracle.jdbc.ssl.trustManagerFactory.algorithm", (String)null); 
/*  1583 */     if (str1 == null) {
/*  1584 */       str1 = null;
/*       */     }
/*       */     
/*  1587 */     this.thinSslTrustmanagerfactoryAlgorithm = str1;
/*       */ 
/*       */     
/*  1590 */     str1 = null;
/*  1591 */     if (paramProperties != null)
/*       */     {
/*  1593 */       str1 = paramProperties.getProperty("oracle.net.oldSyntax");
/*       */     }
/*  1595 */     if (str1 == null)
/*  1596 */       str1 = getSystemProperty("oracle.net.oldSyntax", (String)null); 
/*  1597 */     if (str1 == null) {
/*  1598 */       str1 = null;
/*       */     }
/*       */     
/*  1601 */     this.thinNetOldsyntax = str1;
/*       */ 
/*       */     
/*  1604 */     str1 = null;
/*  1605 */     if (paramProperties != null)
/*       */     {
/*  1607 */       str1 = paramProperties.getProperty("java.naming.factory.initial");
/*       */     }
/*  1609 */     if (str1 == null) {
/*  1610 */       str1 = null;
/*       */     }
/*       */     
/*  1613 */     this.thinNamingContextInitial = str1;
/*       */ 
/*       */     
/*  1616 */     str1 = null;
/*  1617 */     if (paramProperties != null)
/*       */     {
/*  1619 */       str1 = paramProperties.getProperty("java.naming.provider.url");
/*       */     }
/*  1621 */     if (str1 == null) {
/*  1622 */       str1 = null;
/*       */     }
/*       */     
/*  1625 */     this.thinNamingProviderUrl = str1;
/*       */ 
/*       */     
/*  1628 */     str1 = null;
/*  1629 */     if (paramProperties != null)
/*       */     {
/*  1631 */       str1 = paramProperties.getProperty("java.naming.security.authentication");
/*       */     }
/*  1633 */     if (str1 == null) {
/*  1634 */       str1 = null;
/*       */     }
/*       */     
/*  1637 */     this.thinNamingSecurityAuthentication = str1;
/*       */ 
/*       */     
/*  1640 */     str1 = null;
/*  1641 */     if (paramProperties != null)
/*       */     {
/*  1643 */       str1 = paramProperties.getProperty("java.naming.security.principal");
/*       */     }
/*  1645 */     if (str1 == null) {
/*  1646 */       str1 = null;
/*       */     }
/*       */     
/*  1649 */     this.thinNamingSecurityPrincipal = str1;
/*       */ 
/*       */     
/*  1652 */     str1 = null;
/*  1653 */     if (paramProperties != null)
/*       */     {
/*  1655 */       str1 = paramProperties.getProperty("java.naming.security.credentials");
/*       */     }
/*  1657 */     if (str1 == null) {
/*  1658 */       str1 = null;
/*       */     }
/*       */     
/*  1661 */     this.thinNamingSecurityCredentials = str1;
/*       */ 
/*       */     
/*  1664 */     str1 = null;
/*  1665 */     if (paramProperties != null) {
/*       */       
/*  1667 */       str1 = paramProperties.getProperty("com.sun.jndi.ldap.connect.timeout");
/*  1668 */       if (str1 == null)
/*  1669 */         str1 = paramProperties.getProperty("oracle.jdbc.com.sun.jndi.ldap.connect.timeout"); 
/*       */     } 
/*  1671 */     if (str1 == null)
/*  1672 */       str1 = getSystemProperty("oracle.jdbc.com.sun.jndi.ldap.connect.timeout", (String)null); 
/*  1673 */     if (str1 == null) {
/*  1674 */       str1 = null;
/*       */     }
/*       */     
/*  1677 */     this.thinJndiLdapConnectTimeout = str1;
/*       */ 
/*       */     
/*  1680 */     str1 = null;
/*  1681 */     if (paramProperties != null) {
/*       */       
/*  1683 */       str1 = paramProperties.getProperty("com.sun.jndi.ldap.read.timeout");
/*  1684 */       if (str1 == null)
/*  1685 */         str1 = paramProperties.getProperty("oracle.jdbc.com.sun.jndi.ldap.read.timeout"); 
/*       */     } 
/*  1687 */     if (str1 == null)
/*  1688 */       str1 = getSystemProperty("oracle.jdbc.com.sun.jndi.ldap.read.timeout", (String)null); 
/*  1689 */     if (str1 == null) {
/*  1690 */       str1 = null;
/*       */     }
/*       */     
/*  1693 */     this.thinJndiLdapReadTimeout = str1;
/*       */ 
/*       */     
/*  1696 */     str1 = null;
/*  1697 */     if (paramProperties != null)
/*       */     {
/*  1699 */       str1 = paramProperties.getProperty("oracle.net.wallet_location");
/*       */     }
/*  1701 */     if (str1 == null)
/*  1702 */       str1 = getSystemProperty("oracle.net.wallet_location", (String)null); 
/*  1703 */     if (str1 == null) {
/*  1704 */       str1 = null;
/*       */     }
/*       */     
/*  1707 */     this.walletLocation = str1;
/*       */ 
/*       */     
/*  1710 */     str1 = null;
/*  1711 */     if (paramProperties != null)
/*       */     {
/*  1713 */       str1 = paramProperties.getProperty("oracle.net.wallet_password");
/*       */     }
/*  1715 */     if (str1 == null)
/*  1716 */       str1 = getSystemProperty("oracle.net.wallet_password", (String)null); 
/*  1717 */     if (str1 == null) {
/*  1718 */       str1 = null;
/*       */     }
/*       */     
/*  1721 */     this.walletPassword = str1;
/*       */ 
/*       */     
/*  1724 */     str1 = null;
/*  1725 */     if (paramProperties != null)
/*       */     {
/*  1727 */       str1 = paramProperties.getProperty("oracle.jdbc.proxyClientName");
/*       */     }
/*  1729 */     if (str1 == null)
/*  1730 */       str1 = getSystemProperty("oracle.jdbc.proxyClientName", (String)null); 
/*  1731 */     if (str1 == null) {
/*  1732 */       str1 = null;
/*       */     }
/*       */     
/*  1735 */     this.proxyClientName = str1;
/*       */ 
/*       */     
/*  1738 */     str1 = null;
/*  1739 */     if (paramProperties != null)
/*       */     {
/*  1741 */       str1 = paramProperties.getProperty("oracle.jdbc.useNio");
/*       */     }
/*  1743 */     if (str1 == null)
/*  1744 */       str1 = getSystemProperty("oracle.jdbc.useNio", (String)null); 
/*  1745 */     if (str1 == null) {
/*  1746 */       str1 = "false";
/*       */     }
/*       */     
/*  1749 */     this.useNio = (str1 != null && str1.equalsIgnoreCase("true"));
/*       */ 
/*       */     
/*  1752 */     str1 = null;
/*  1753 */     if (paramProperties != null) {
/*       */       
/*  1755 */       str1 = paramProperties.getProperty("JDBCDriverCharSetId");
/*  1756 */       if (str1 == null)
/*  1757 */         str1 = paramProperties.getProperty("oracle.jdbc.JDBCDriverCharSetId"); 
/*       */     } 
/*  1759 */     if (str1 == null)
/*  1760 */       str1 = getSystemProperty("oracle.jdbc.JDBCDriverCharSetId", (String)null); 
/*  1761 */     if (str1 == null) {
/*  1762 */       str1 = null;
/*       */     }
/*       */     
/*  1765 */     this.ociDriverCharset = str1;
/*       */ 
/*       */     
/*  1768 */     str1 = null;
/*  1769 */     if (paramProperties != null)
/*       */     {
/*  1771 */       str1 = paramProperties.getProperty("oracle.jdbc.editionName");
/*       */     }
/*  1773 */     if (str1 == null)
/*  1774 */       str1 = getSystemProperty("oracle.jdbc.editionName", (String)null); 
/*  1775 */     if (str1 == null) {
/*  1776 */       str1 = null;
/*       */     }
/*       */     
/*  1779 */     this.editionName = str1;
/*       */ 
/*       */     
/*  1782 */     str1 = null;
/*  1783 */     if (paramProperties != null)
/*       */     {
/*  1785 */       str1 = paramProperties.getProperty("oracle.jdbc.thinLogonCapability");
/*       */     }
/*  1787 */     if (str1 == null)
/*  1788 */       str1 = getSystemProperty("oracle.jdbc.thinLogonCapability", (String)null); 
/*  1789 */     if (str1 == null) {
/*  1790 */       str1 = "o5";
/*       */     }
/*       */     
/*  1793 */     this.logonCap = str1;
/*       */ 
/*       */     
/*  1796 */     str1 = null;
/*  1797 */     if (paramProperties != null)
/*       */     {
/*  1799 */       str1 = paramProperties.getProperty("oracle.jdbc.useOCIDefaultDefines");
/*       */     }
/*  1801 */     if (str1 == null)
/*  1802 */       str1 = getSystemProperty("oracle.jdbc.useOCIDefaultDefines", (String)null); 
/*  1803 */     if (str1 == null) {
/*  1804 */       str1 = "false";
/*       */     }
/*       */     
/*  1807 */     this.useOCIDefaultDefines = (str1 != null && str1.equalsIgnoreCase("true"));
/*       */ 
/*       */     
/*  1810 */     str1 = null;
/*  1811 */     if (paramProperties != null) {
/*       */       
/*  1813 */       str1 = paramProperties.getProperty("internal_logon");
/*  1814 */       if (str1 == null)
/*  1815 */         str1 = paramProperties.getProperty("oracle.jdbc.internal_logon"); 
/*       */     } 
/*  1817 */     if (str1 == null)
/*  1818 */       str1 = getSystemProperty("oracle.jdbc.internal_logon", (String)null); 
/*  1819 */     if (str1 == null) {
/*  1820 */       str1 = null;
/*       */     }
/*       */     
/*  1823 */     this.internalLogon = str1;
/*       */ 
/*       */     
/*  1826 */     str1 = null;
/*  1827 */     if (paramProperties != null)
/*       */     {
/*  1829 */       str1 = paramProperties.getProperty("oracle.jdbc.createDescriptorUseCurrentSchemaForSchemaName");
/*       */     }
/*  1831 */     if (str1 == null)
/*  1832 */       str1 = getSystemProperty("oracle.jdbc.createDescriptorUseCurrentSchemaForSchemaName", (String)null); 
/*  1833 */     if (str1 == null) {
/*  1834 */       str1 = "false";
/*       */     }
/*       */     
/*  1837 */     this.createDescriptorUseCurrentSchemaForSchemaName = (str1 != null && str1.equalsIgnoreCase("true"));
/*       */ 
/*       */     
/*  1840 */     str1 = null;
/*  1841 */     if (paramProperties != null) {
/*       */       
/*  1843 */       str1 = paramProperties.getProperty("OCISvcCtxHandle");
/*  1844 */       if (str1 == null)
/*  1845 */         str1 = paramProperties.getProperty("oracle.jdbc.OCISvcCtxHandle"); 
/*       */     } 
/*  1847 */     if (str1 == null)
/*  1848 */       str1 = getSystemProperty("oracle.jdbc.OCISvcCtxHandle", (String)null); 
/*  1849 */     if (str1 == null) {
/*  1850 */       str1 = "0";
/*       */     }
/*       */     try {
/*  1853 */       this.ociSvcCtxHandle = Long.parseLong(str1);
/*  1854 */     } catch (NumberFormatException numberFormatException) {
/*       */ 
/*       */ 
/*       */       
/*  1858 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 190, "Property is 'ociSvcCtxHandle'");
/*  1859 */       sQLException.fillInStackTrace();
/*  1860 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*  1866 */     str1 = null;
/*  1867 */     if (paramProperties != null) {
/*       */       
/*  1869 */       str1 = paramProperties.getProperty("OCIEnvHandle");
/*  1870 */       if (str1 == null)
/*  1871 */         str1 = paramProperties.getProperty("oracle.jdbc.OCIEnvHandle"); 
/*       */     } 
/*  1873 */     if (str1 == null)
/*  1874 */       str1 = getSystemProperty("oracle.jdbc.OCIEnvHandle", (String)null); 
/*  1875 */     if (str1 == null) {
/*  1876 */       str1 = "0";
/*       */     }
/*       */     try {
/*  1879 */       this.ociEnvHandle = Long.parseLong(str1);
/*  1880 */     } catch (NumberFormatException numberFormatException) {
/*       */ 
/*       */ 
/*       */       
/*  1884 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 190, "Property is 'ociEnvHandle'");
/*  1885 */       sQLException.fillInStackTrace();
/*  1886 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*  1892 */     str1 = null;
/*  1893 */     if (paramProperties != null) {
/*       */       
/*  1895 */       str1 = paramProperties.getProperty("OCIErrHandle");
/*  1896 */       if (str1 == null)
/*  1897 */         str1 = paramProperties.getProperty("oracle.jdbc.OCIErrHandle"); 
/*       */     } 
/*  1899 */     if (str1 == null)
/*  1900 */       str1 = getSystemProperty("oracle.jdbc.OCIErrHandle", (String)null); 
/*  1901 */     if (str1 == null) {
/*  1902 */       str1 = "0";
/*       */     }
/*       */     try {
/*  1905 */       this.ociErrHandle = Long.parseLong(str1);
/*  1906 */     } catch (NumberFormatException numberFormatException) {
/*       */ 
/*       */ 
/*       */       
/*  1910 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 190, "Property is 'ociErrHandle'");
/*  1911 */       sQLException.fillInStackTrace();
/*  1912 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*  1918 */     str1 = null;
/*  1919 */     if (paramProperties != null) {
/*       */       
/*  1921 */       str1 = paramProperties.getProperty("prelim_auth");
/*  1922 */       if (str1 == null)
/*  1923 */         str1 = paramProperties.getProperty("oracle.jdbc.prelim_auth"); 
/*       */     } 
/*  1925 */     if (str1 == null)
/*  1926 */       str1 = getSystemProperty("oracle.jdbc.prelim_auth", (String)null); 
/*  1927 */     if (str1 == null) {
/*  1928 */       str1 = "false";
/*       */     }
/*       */     
/*  1931 */     this.prelimAuth = (str1 != null && str1.equalsIgnoreCase("true"));
/*       */ 
/*       */     
/*  1934 */     str1 = null;
/*  1935 */     if (paramProperties != null)
/*       */     {
/*  1937 */       str1 = paramProperties.getProperty("oracle.jdbc.jmsNotification");
/*       */     }
/*  1939 */     if (str1 == null)
/*  1940 */       str1 = getSystemProperty("oracle.jdbc.jmsNotification", (String)null); 
/*  1941 */     if (str1 == null) {
/*  1942 */       str1 = "false";
/*       */     }
/*       */     
/*  1945 */     this.jmsNotificationConnection = (str1 != null && str1.equalsIgnoreCase("true"));
/*       */ 
/*       */     
/*  1948 */     str1 = null;
/*  1949 */     if (paramProperties != null)
/*       */     {
/*  1951 */       str1 = paramProperties.getProperty("oracle.jdbc.ociNlsLangBackwardCompatible");
/*       */     }
/*  1953 */     if (str1 == null)
/*  1954 */       str1 = getSystemProperty("oracle.jdbc.ociNlsLangBackwardCompatible", (String)null); 
/*  1955 */     if (str1 == null) {
/*  1956 */       str1 = "false";
/*       */     }
/*       */     
/*  1959 */     this.nlsLangBackdoor = (str1 != null && str1.equalsIgnoreCase("true"));
/*       */ 
/*       */     
/*  1962 */     str1 = null;
/*  1963 */     if (paramProperties != null) {
/*       */       
/*  1965 */       str1 = paramProperties.getProperty("OCINewPassword");
/*  1966 */       if (str1 == null)
/*  1967 */         str1 = paramProperties.getProperty("oracle.jdbc.OCINewPassword"); 
/*       */     } 
/*  1969 */     if (str1 == null)
/*  1970 */       str1 = getSystemProperty("oracle.jdbc.OCINewPassword", (String)null); 
/*  1971 */     if (str1 == null) {
/*  1972 */       str1 = null;
/*       */     }
/*       */     
/*  1975 */     this.setNewPassword = str1;
/*       */ 
/*       */     
/*  1978 */     str1 = null;
/*  1979 */     if (paramProperties != null)
/*       */     {
/*  1981 */       str1 = paramProperties.getProperty("oracle.jdbc.spawnNewThreadToCancel");
/*       */     }
/*  1983 */     if (str1 == null)
/*  1984 */       str1 = getSystemProperty("oracle.jdbc.spawnNewThreadToCancel", (String)null); 
/*  1985 */     if (str1 == null) {
/*  1986 */       str1 = "false";
/*       */     }
/*       */     
/*  1989 */     this.spawnNewThreadToCancel = (str1 != null && str1.equalsIgnoreCase("true"));
/*       */ 
/*       */     
/*  1992 */     str1 = null;
/*  1993 */     if (paramProperties != null) {
/*       */       
/*  1995 */       str1 = paramProperties.getProperty("defaultExecuteBatch");
/*  1996 */       if (str1 == null)
/*  1997 */         str1 = paramProperties.getProperty("oracle.jdbc.defaultExecuteBatch"); 
/*       */     } 
/*  1999 */     if (str1 == null)
/*  2000 */       str1 = getSystemProperty("oracle.jdbc.defaultExecuteBatch", (String)null); 
/*  2001 */     if (str1 == null) {
/*  2002 */       str1 = "1";
/*       */     }
/*       */     try {
/*  2005 */       this.defaultExecuteBatch = Integer.parseInt(str1);
/*  2006 */     } catch (NumberFormatException numberFormatException) {
/*       */ 
/*       */ 
/*       */       
/*  2010 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 190, "Property is 'defaultExecuteBatch'");
/*  2011 */       sQLException.fillInStackTrace();
/*  2012 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*  2018 */     str1 = null;
/*  2019 */     if (paramProperties != null) {
/*       */       
/*  2021 */       str1 = paramProperties.getProperty("defaultRowPrefetch");
/*  2022 */       if (str1 == null)
/*  2023 */         str1 = paramProperties.getProperty("oracle.jdbc.defaultRowPrefetch"); 
/*       */     } 
/*  2025 */     if (str1 == null)
/*  2026 */       str1 = getSystemProperty("oracle.jdbc.defaultRowPrefetch", (String)null); 
/*  2027 */     if (str1 == null) {
/*  2028 */       str1 = "10";
/*       */     }
/*       */     try {
/*  2031 */       this.defaultRowPrefetch = Integer.parseInt(str1);
/*  2032 */     } catch (NumberFormatException numberFormatException) {
/*       */ 
/*       */ 
/*       */       
/*  2036 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 190, "Property is 'defaultRowPrefetch'");
/*  2037 */       sQLException.fillInStackTrace();
/*  2038 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*  2044 */     str1 = null;
/*  2045 */     if (paramProperties != null)
/*       */     {
/*  2047 */       str1 = paramProperties.getProperty("oracle.jdbc.defaultLobPrefetchSize");
/*       */     }
/*  2049 */     if (str1 == null)
/*  2050 */       str1 = getSystemProperty("oracle.jdbc.defaultLobPrefetchSize", (String)null); 
/*  2051 */     if (str1 == null) {
/*  2052 */       str1 = "4000";
/*       */     }
/*       */     try {
/*  2055 */       this.defaultLobPrefetchSize = Integer.parseInt(str1);
/*  2056 */     } catch (NumberFormatException numberFormatException) {
/*       */ 
/*       */ 
/*       */       
/*  2060 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 190, "Property is 'defaultLobPrefetchSize'");
/*  2061 */       sQLException.fillInStackTrace();
/*  2062 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*  2068 */     str1 = null;
/*  2069 */     if (paramProperties != null)
/*       */     {
/*  2071 */       str1 = paramProperties.getProperty("oracle.jdbc.enableDataInLocator");
/*       */     }
/*  2073 */     if (str1 == null)
/*  2074 */       str1 = getSystemProperty("oracle.jdbc.enableDataInLocator", (String)null); 
/*  2075 */     if (str1 == null) {
/*  2076 */       str1 = "true";
/*       */     }
/*       */     
/*  2079 */     this.enableDataInLocator = (str1 != null && str1.equalsIgnoreCase("true"));
/*       */ 
/*       */     
/*  2082 */     str1 = null;
/*  2083 */     if (paramProperties != null)
/*       */     {
/*  2085 */       str1 = paramProperties.getProperty("oracle.jdbc.enableReadDataInLocator");
/*       */     }
/*  2087 */     if (str1 == null)
/*  2088 */       str1 = getSystemProperty("oracle.jdbc.enableReadDataInLocator", (String)null); 
/*  2089 */     if (str1 == null) {
/*  2090 */       str1 = "true";
/*       */     }
/*       */     
/*  2093 */     this.enableReadDataInLocator = (str1 != null && str1.equalsIgnoreCase("true"));
/*       */ 
/*       */     
/*  2096 */     str1 = null;
/*  2097 */     if (paramProperties != null)
/*       */     {
/*  2099 */       str1 = paramProperties.getProperty("oracle.jdbc.overrideEnableReadDataInLocator");
/*       */     }
/*  2101 */     if (str1 == null)
/*  2102 */       str1 = getSystemProperty("oracle.jdbc.overrideEnableReadDataInLocator", (String)null); 
/*  2103 */     if (str1 == null) {
/*  2104 */       str1 = "false";
/*       */     }
/*       */     
/*  2107 */     this.overrideEnableReadDataInLocator = (str1 != null && str1.equalsIgnoreCase("true"));
/*       */ 
/*       */     
/*  2110 */     str1 = null;
/*  2111 */     if (paramProperties != null) {
/*       */       
/*  2113 */       str1 = paramProperties.getProperty("remarksReporting");
/*  2114 */       if (str1 == null)
/*  2115 */         str1 = paramProperties.getProperty("oracle.jdbc.remarksReporting"); 
/*       */     } 
/*  2117 */     if (str1 == null)
/*  2118 */       str1 = getSystemProperty("oracle.jdbc.remarksReporting", (String)null); 
/*  2119 */     if (str1 == null) {
/*  2120 */       str1 = "false";
/*       */     }
/*       */     
/*  2123 */     this.reportRemarks = (str1 != null && str1.equalsIgnoreCase("true"));
/*       */ 
/*       */     
/*  2126 */     str1 = null;
/*  2127 */     if (paramProperties != null) {
/*       */       
/*  2129 */       str1 = paramProperties.getProperty("includeSynonyms");
/*  2130 */       if (str1 == null)
/*  2131 */         str1 = paramProperties.getProperty("oracle.jdbc.includeSynonyms"); 
/*       */     } 
/*  2133 */     if (str1 == null)
/*  2134 */       str1 = getSystemProperty("oracle.jdbc.includeSynonyms", (String)null); 
/*  2135 */     if (str1 == null) {
/*  2136 */       str1 = "false";
/*       */     }
/*       */     
/*  2139 */     this.includeSynonyms = (str1 != null && str1.equalsIgnoreCase("true"));
/*       */ 
/*       */     
/*  2142 */     str1 = null;
/*  2143 */     if (paramProperties != null) {
/*       */       
/*  2145 */       str1 = paramProperties.getProperty("restrictGetTables");
/*  2146 */       if (str1 == null)
/*  2147 */         str1 = paramProperties.getProperty("oracle.jdbc.restrictGetTables"); 
/*       */     } 
/*  2149 */     if (str1 == null)
/*  2150 */       str1 = getSystemProperty("oracle.jdbc.restrictGetTables", (String)null); 
/*  2151 */     if (str1 == null) {
/*  2152 */       str1 = "false";
/*       */     }
/*       */     
/*  2155 */     this.restrictGettables = (str1 != null && str1.equalsIgnoreCase("true"));
/*       */ 
/*       */     
/*  2158 */     str1 = null;
/*  2159 */     if (paramProperties != null) {
/*       */       
/*  2161 */       str1 = paramProperties.getProperty("AccumulateBatchResult");
/*  2162 */       if (str1 == null)
/*  2163 */         str1 = paramProperties.getProperty("oracle.jdbc.AccumulateBatchResult"); 
/*       */     } 
/*  2165 */     if (str1 == null)
/*  2166 */       str1 = getSystemProperty("oracle.jdbc.AccumulateBatchResult", (String)null); 
/*  2167 */     if (str1 == null) {
/*  2168 */       str1 = "true";
/*       */     }
/*       */     
/*  2171 */     this.accumulateBatchResult = (str1 != null && str1.equalsIgnoreCase("true"));
/*       */ 
/*       */     
/*  2174 */     str1 = null;
/*  2175 */     if (paramProperties != null) {
/*       */       
/*  2177 */       str1 = paramProperties.getProperty("useFetchSizeWithLongColumn");
/*  2178 */       if (str1 == null)
/*  2179 */         str1 = paramProperties.getProperty("oracle.jdbc.useFetchSizeWithLongColumn"); 
/*       */     } 
/*  2181 */     if (str1 == null)
/*  2182 */       str1 = getSystemProperty("oracle.jdbc.useFetchSizeWithLongColumn", (String)null); 
/*  2183 */     if (str1 == null) {
/*  2184 */       str1 = "false";
/*       */     }
/*       */     
/*  2187 */     this.useFetchSizeWithLongColumn = (str1 != null && str1.equalsIgnoreCase("true"));
/*       */ 
/*       */     
/*  2190 */     str1 = null;
/*  2191 */     if (paramProperties != null) {
/*       */       
/*  2193 */       str1 = paramProperties.getProperty("processEscapes");
/*  2194 */       if (str1 == null)
/*  2195 */         str1 = paramProperties.getProperty("oracle.jdbc.processEscapes"); 
/*       */     } 
/*  2197 */     if (str1 == null)
/*  2198 */       str1 = getSystemProperty("oracle.jdbc.processEscapes", (String)null); 
/*  2199 */     if (str1 == null) {
/*  2200 */       str1 = "true";
/*       */     }
/*       */     
/*  2203 */     this.processEscapes = (str1 != null && str1.equalsIgnoreCase("true"));
/*       */ 
/*       */     
/*  2206 */     str1 = null;
/*  2207 */     if (paramProperties != null) {
/*       */       
/*  2209 */       str1 = paramProperties.getProperty("fixedString");
/*  2210 */       if (str1 == null)
/*  2211 */         str1 = paramProperties.getProperty("oracle.jdbc.fixedString"); 
/*       */     } 
/*  2213 */     if (str1 == null)
/*  2214 */       str1 = getSystemProperty("oracle.jdbc.fixedString", (String)null); 
/*  2215 */     if (str1 == null) {
/*  2216 */       str1 = "false";
/*       */     }
/*       */     
/*  2219 */     this.fixedString = (str1 != null && str1.equalsIgnoreCase("true"));
/*       */ 
/*       */     
/*  2222 */     str1 = null;
/*  2223 */     if (paramProperties != null) {
/*       */       
/*  2225 */       str1 = paramProperties.getProperty("defaultNChar");
/*  2226 */       if (str1 == null)
/*  2227 */         str1 = paramProperties.getProperty("oracle.jdbc.defaultNChar"); 
/*       */     } 
/*  2229 */     if (str1 == null)
/*  2230 */       str1 = getSystemProperty("oracle.jdbc.defaultNChar", (String)null); 
/*  2231 */     if (str1 == null) {
/*  2232 */       str1 = "false";
/*       */     }
/*       */     
/*  2235 */     this.defaultnchar = (str1 != null && str1.equalsIgnoreCase("true"));
/*       */ 
/*       */     
/*  2238 */     str1 = null;
/*  2239 */     if (paramProperties != null)
/*       */     {
/*  2241 */       str1 = paramProperties.getProperty("oracle.jdbc.internal.permitBindDateDefineTimestampMismatch");
/*       */     }
/*  2243 */     if (str1 == null)
/*  2244 */       str1 = getSystemProperty("oracle.jdbc.internal.permitBindDateDefineTimestampMismatch", (String)null); 
/*  2245 */     if (str1 == null) {
/*  2246 */       str1 = "false";
/*       */     }
/*       */     
/*  2249 */     this.permitTimestampDateMismatch = (str1 != null && str1.equalsIgnoreCase("true"));
/*       */ 
/*       */     
/*  2252 */     str1 = null;
/*  2253 */     if (paramProperties != null) {
/*       */       
/*  2255 */       str1 = paramProperties.getProperty("RessourceManagerId");
/*  2256 */       if (str1 == null)
/*  2257 */         str1 = paramProperties.getProperty("oracle.jdbc.RessourceManagerId"); 
/*       */     } 
/*  2259 */     if (str1 == null)
/*  2260 */       str1 = getSystemProperty("oracle.jdbc.RessourceManagerId", (String)null); 
/*  2261 */     if (str1 == null) {
/*  2262 */       str1 = "0000";
/*       */     }
/*       */     
/*  2265 */     this.resourceManagerId = str1;
/*       */ 
/*       */     
/*  2268 */     str1 = null;
/*  2269 */     if (paramProperties != null) {
/*       */       
/*  2271 */       str1 = paramProperties.getProperty("disableDefineColumnType");
/*  2272 */       if (str1 == null)
/*  2273 */         str1 = paramProperties.getProperty("oracle.jdbc.disableDefineColumnType"); 
/*       */     } 
/*  2275 */     if (str1 == null)
/*  2276 */       str1 = getSystemProperty("oracle.jdbc.disableDefineColumnType", (String)null); 
/*  2277 */     if (str1 == null) {
/*  2278 */       str1 = "false";
/*       */     }
/*       */     
/*  2281 */     this.disableDefinecolumntype = (str1 != null && str1.equalsIgnoreCase("true"));
/*       */ 
/*       */     
/*  2284 */     str1 = null;
/*  2285 */     if (paramProperties != null)
/*       */     {
/*  2287 */       str1 = paramProperties.getProperty("oracle.jdbc.convertNcharLiterals");
/*       */     }
/*  2289 */     if (str1 == null)
/*  2290 */       str1 = getSystemProperty("oracle.jdbc.convertNcharLiterals", (String)null); 
/*  2291 */     if (str1 == null) {
/*  2292 */       str1 = "true";
/*       */     }
/*       */     
/*  2295 */     this.convertNcharLiterals = (str1 != null && str1.equalsIgnoreCase("true"));
/*       */ 
/*       */     
/*  2298 */     str1 = null;
/*  2299 */     if (paramProperties != null)
/*       */     {
/*  2301 */       str1 = paramProperties.getProperty("oracle.jdbc.autoCommitSpecCompliant");
/*       */     }
/*  2303 */     if (str1 == null)
/*  2304 */       str1 = getSystemProperty("oracle.jdbc.autoCommitSpecCompliant", (String)null); 
/*  2305 */     if (str1 == null) {
/*  2306 */       str1 = "true";
/*       */     }
/*       */     
/*  2309 */     this.autoCommitSpecCompliant = (str1 != null && str1.equalsIgnoreCase("true"));
/*       */ 
/*       */     
/*  2312 */     str1 = null;
/*  2313 */     if (paramProperties != null)
/*       */     {
/*  2315 */       str1 = paramProperties.getProperty("oracle.jdbc.J2EE13Compliant");
/*       */     }
/*  2317 */     if (str1 == null)
/*  2318 */       str1 = getSystemProperty("oracle.jdbc.J2EE13Compliant", (String)null); 
/*  2319 */     if (str1 == null) {
/*  2320 */       str1 = "false";
/*       */     }
/*       */     
/*  2323 */     this.j2ee13Compliant = (str1 != null && str1.equalsIgnoreCase("true"));
/*       */ 
/*       */     
/*  2326 */     str1 = null;
/*  2327 */     if (paramProperties != null)
/*       */     {
/*  2329 */       str1 = paramProperties.getProperty("oracle.jdbc.mapDateToTimestamp");
/*       */     }
/*  2331 */     if (str1 == null)
/*  2332 */       str1 = getSystemProperty("oracle.jdbc.mapDateToTimestamp", (String)null); 
/*  2333 */     if (str1 == null) {
/*  2334 */       str1 = "true";
/*       */     }
/*       */     
/*  2337 */     this.mapDateToTimestamp = (str1 != null && str1.equalsIgnoreCase("true"));
/*       */ 
/*       */     
/*  2340 */     str1 = null;
/*  2341 */     if (paramProperties != null)
/*       */     {
/*  2343 */       str1 = paramProperties.getProperty("oracle.jdbc.useThreadLocalBufferCache");
/*       */     }
/*  2345 */     if (str1 == null)
/*  2346 */       str1 = getSystemProperty("oracle.jdbc.useThreadLocalBufferCache", (String)null); 
/*  2347 */     if (str1 == null) {
/*  2348 */       str1 = "false";
/*       */     }
/*       */     
/*  2351 */     this.useThreadLocalBufferCache = (str1 != null && str1.equalsIgnoreCase("true"));
/*       */ 
/*       */     
/*  2354 */     str1 = null;
/*  2355 */     if (paramProperties != null)
/*       */     {
/*  2357 */       str1 = paramProperties.getProperty("oracle.jdbc.driverNameAttribute");
/*       */     }
/*  2359 */     if (str1 == null)
/*  2360 */       str1 = getSystemProperty("oracle.jdbc.driverNameAttribute", (String)null); 
/*  2361 */     if (str1 == null) {
/*  2362 */       str1 = null;
/*       */     }
/*       */     
/*  2365 */     this.driverNameAttribute = str1;
/*       */ 
/*       */     
/*  2368 */     str1 = null;
/*  2369 */     if (paramProperties != null)
/*       */     {
/*  2371 */       str1 = paramProperties.getProperty("oracle.jdbc.maxCachedBufferSize");
/*       */     }
/*  2373 */     if (str1 == null)
/*  2374 */       str1 = getSystemProperty("oracle.jdbc.maxCachedBufferSize", (String)null); 
/*  2375 */     if (str1 == null) {
/*  2376 */       str1 = "30";
/*       */     }
/*       */     try {
/*  2379 */       this.maxCachedBufferSize = Integer.parseInt(str1);
/*  2380 */     } catch (NumberFormatException numberFormatException) {
/*       */ 
/*       */ 
/*       */       
/*  2384 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 190, "Property is 'maxCachedBufferSize'");
/*  2385 */       sQLException.fillInStackTrace();
/*  2386 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*  2392 */     str1 = null;
/*  2393 */     if (paramProperties != null)
/*       */     {
/*  2395 */       str1 = paramProperties.getProperty("oracle.jdbc.implicitStatementCacheSize");
/*       */     }
/*  2397 */     if (str1 == null)
/*  2398 */       str1 = getSystemProperty("oracle.jdbc.implicitStatementCacheSize", (String)null); 
/*  2399 */     if (str1 == null) {
/*  2400 */       str1 = "0";
/*       */     }
/*       */     try {
/*  2403 */       this.implicitStatementCacheSize = Integer.parseInt(str1);
/*  2404 */     } catch (NumberFormatException numberFormatException) {
/*       */ 
/*       */ 
/*       */       
/*  2408 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 190, "Property is 'implicitStatementCacheSize'");
/*  2409 */       sQLException.fillInStackTrace();
/*  2410 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*  2416 */     str1 = null;
/*  2417 */     if (paramProperties != null)
/*       */     {
/*  2419 */       str1 = paramProperties.getProperty("oracle.jdbc.LobStreamPosStandardCompliant");
/*       */     }
/*  2421 */     if (str1 == null)
/*  2422 */       str1 = getSystemProperty("oracle.jdbc.LobStreamPosStandardCompliant", (String)null); 
/*  2423 */     if (str1 == null) {
/*  2424 */       str1 = "false";
/*       */     }
/*       */     
/*  2427 */     this.lobStreamPosStandardCompliant = (str1 != null && str1.equalsIgnoreCase("true"));
/*       */ 
/*       */     
/*  2430 */     str1 = null;
/*  2431 */     if (paramProperties != null)
/*       */     {
/*  2433 */       str1 = paramProperties.getProperty("oracle.jdbc.strictASCIIConversion");
/*       */     }
/*  2435 */     if (str1 == null)
/*  2436 */       str1 = getSystemProperty("oracle.jdbc.strictASCIIConversion", (String)null); 
/*  2437 */     if (str1 == null) {
/*  2438 */       str1 = "false";
/*       */     }
/*       */     
/*  2441 */     this.isStrictAsciiConversion = (str1 != null && str1.equalsIgnoreCase("true"));
/*       */ 
/*       */     
/*  2444 */     str1 = null;
/*  2445 */     if (paramProperties != null)
/*       */     {
/*  2447 */       str1 = paramProperties.getProperty("oracle.jdbc.DRCPConnectionClass");
/*       */     }
/*  2449 */     if (str1 == null)
/*  2450 */       str1 = getSystemProperty("oracle.jdbc.DRCPConnectionClass", (String)null); 
/*  2451 */     if (str1 == null) {
/*  2452 */       str1 = null;
/*       */     }
/*       */     
/*  2455 */     this.drcpConnectionClass = str1;
/*       */ 
/*       */     
/*  2458 */     str1 = null;
/*  2459 */     if (paramProperties != null)
/*       */     {
/*  2461 */       str1 = paramProperties.getProperty("oracle.jdbc.DRCPTagName");
/*       */     }
/*  2463 */     if (str1 == null) {
/*  2464 */       str1 = null;
/*       */     }
/*       */     
/*  2467 */     this.drcpTagName = str1;
/*       */ 
/*       */     
/*  2470 */     str1 = null;
/*  2471 */     if (str1 == null)
/*  2472 */       str1 = getSystemProperty("oracle.jdbc.blockSourceImplementation", (String)null); 
/*  2473 */     if (str1 == null) {
/*  2474 */       str1 = "THREADED";
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*  2480 */     this.blockSourceImpl = str1;
/*       */ 
/*       */     
/*  2483 */     str1 = null;
/*  2484 */     if (paramProperties != null)
/*       */     {
/*  2486 */       str1 = paramProperties.getProperty("oracle.jdbc.thinForceDNSLoadBalancing");
/*       */     }
/*  2488 */     if (str1 == null)
/*  2489 */       str1 = getSystemProperty("oracle.jdbc.thinForceDNSLoadBalancing", (String)null); 
/*  2490 */     if (str1 == null) {
/*  2491 */       str1 = "false";
/*       */     }
/*       */     
/*  2494 */     this.thinForceDnsLoadBalancing = (str1 != null && str1.equalsIgnoreCase("true"));
/*       */ 
/*       */     
/*  2497 */     str1 = null;
/*  2498 */     if (paramProperties != null)
/*       */     {
/*  2500 */       str1 = paramProperties.getProperty("oracle.jdbc.enableTempLobRefCnt");
/*       */     }
/*  2502 */     if (str1 == null)
/*  2503 */       str1 = getSystemProperty("oracle.jdbc.enableTempLobRefCnt", (String)null); 
/*  2504 */     if (str1 == null) {
/*  2505 */       str1 = "true";
/*       */     }
/*       */     
/*  2508 */     this.enableTempLobRefCnt = (str1 != null && str1.equalsIgnoreCase("true"));
/*       */ 
/*       */     
/*  2511 */     str1 = null;
/*  2512 */     if (paramProperties != null)
/*       */     {
/*  2514 */       str1 = paramProperties.getProperty("oracle.net.keepAlive");
/*       */     }
/*  2516 */     if (str1 == null)
/*  2517 */       str1 = getSystemProperty("oracle.net.keepAlive", (String)null); 
/*  2518 */     if (str1 == null) {
/*  2519 */       str1 = "false";
/*       */     }
/*       */     
/*  2522 */     this.keepAlive = (str1 != null && str1.equalsIgnoreCase("true"));
/*       */ 
/*       */     
/*  2525 */     str1 = null;
/*  2526 */     if (paramProperties != null)
/*       */     {
/*  2528 */       str1 = paramProperties.getProperty("oracle.jdbc.sqlTranslationProfile");
/*       */     }
/*  2530 */     if (str1 == null)
/*  2531 */       str1 = getSystemProperty("oracle.jdbc.sqlTranslationProfile", (String)null); 
/*  2532 */     if (str1 == null) {
/*  2533 */       str1 = null;
/*       */     }
/*       */     
/*  2536 */     this.sqlTranslationProfile = str1;
/*       */ 
/*       */     
/*  2539 */     str1 = null;
/*  2540 */     if (paramProperties != null)
/*       */     {
/*  2542 */       str1 = paramProperties.getProperty("oracle.jdbc.sqlErrorTranslationFile");
/*       */     }
/*  2544 */     if (str1 == null)
/*  2545 */       str1 = getSystemProperty("oracle.jdbc.sqlErrorTranslationFile", (String)null); 
/*  2546 */     if (str1 == null) {
/*  2547 */       str1 = null;
/*       */     }
/*       */     
/*  2550 */     this.sqlErrorTranslationFile = str1;
/*       */ 
/*       */     
/*  2553 */     str1 = null;
/*  2554 */     if (paramProperties != null)
/*       */     {
/*  2556 */       str1 = paramProperties.getProperty("oracle.jdbc.ignoreReplayContextFromAuthentication");
/*       */     }
/*  2558 */     if (str1 == null) {
/*  2559 */       str1 = "false";
/*       */     }
/*       */     
/*  2562 */     this.ignoreReplayContextFromAuthentication = (str1 != null && str1.equalsIgnoreCase("true"));
/*       */ 
/*       */     
/*  2565 */     str1 = null;
/*  2566 */     if (paramProperties != null)
/*       */     {
/*  2568 */       str1 = paramProperties.getProperty("oracle.jdbc.javaNetNio");
/*       */     }
/*  2570 */     if (str1 == null)
/*  2571 */       str1 = getSystemProperty("oracle.jdbc.javaNetNio", (String)null); 
/*  2572 */     if (str1 == null) {
/*  2573 */       str1 = "false";
/*       */     }
/*       */     
/*  2576 */     this.javaNetNio = (str1 != null && str1.equalsIgnoreCase("true"));
/*       */ 
/*       */     
/*  2579 */     str1 = null;
/*  2580 */     if (paramProperties != null)
/*       */     {
/*  2582 */       str1 = paramProperties.getProperty("oracle.jdbc.nsDirectBuffer");
/*       */     }
/*  2584 */     if (str1 == null)
/*  2585 */       str1 = getSystemProperty("oracle.jdbc.nsDirectBuffer", (String)null); 
/*  2586 */     if (str1 == null) {
/*  2587 */       str1 = "false";
/*       */     }
/*       */     
/*  2590 */     this.nsDirectBuffer = (str1 != null && str1.equalsIgnoreCase("true"));
/*       */ 
/*       */     
/*  2593 */     str1 = null;
/*  2594 */     if (paramProperties != null)
/*       */     {
/*  2596 */       str1 = paramProperties.getProperty("oracle.jdbc.plsqlVarcharParameter4KOnly");
/*       */     }
/*  2598 */     if (str1 == null)
/*  2599 */       str1 = getSystemProperty("oracle.jdbc.plsqlVarcharParameter4KOnly", (String)null); 
/*  2600 */     if (str1 == null) {
/*  2601 */       str1 = "false";
/*       */     }
/*       */     
/*  2604 */     this.plsqlVarcharParameter4KOnly = (str1 != null && str1.equalsIgnoreCase("true"));
/*       */ 
/*       */     
/*  2607 */     str1 = null;
/*  2608 */     if (paramProperties != null)
/*       */     {
/*  2610 */       str1 = paramProperties.getProperty("oracle.jdbc.targetInstanceName");
/*       */     }
/*  2612 */     if (str1 == null)
/*  2613 */       str1 = getSystemProperty("oracle.jdbc.targetInstanceName", (String)null); 
/*  2614 */     if (str1 == null) {
/*  2615 */       str1 = null;
/*       */     }
/*       */     
/*  2618 */     this.targetInstanceName = str1;
/*       */ 
/*       */     
/*  2621 */     str1 = null;
/*  2622 */     if (paramProperties != null)
/*       */     {
/*  2624 */       str1 = paramProperties.getProperty("oracle.jdbc.enableOCIFastApplicationNotification");
/*       */     }
/*  2626 */     if (str1 == null)
/*  2627 */       str1 = getSystemProperty("oracle.jdbc.enableOCIFastApplicationNotification", (String)null); 
/*  2628 */     if (str1 == null) {
/*  2629 */       str1 = "false";
/*       */     }
/*       */     
/*  2632 */     this.enableOCIFAN = (str1 != null && str1.equalsIgnoreCase("true"));
/*       */ 
/*       */ 
/*       */     
/*  2636 */     str1 = null;
/*  2637 */     if (paramProperties != null)
/*  2638 */       str1 = paramProperties.getProperty("oracle.jdbc.commitOption"); 
/*  2639 */     if (str1 == null)
/*  2640 */       str1 = getSystemProperty("oracle.jdbc.commitOption", (String)null); 
/*  2641 */     if (str1 != null) {
/*       */       
/*  2643 */       this.commitOption = 0;
/*  2644 */       String[] arrayOfString = str1.split(",");
/*  2645 */       if (arrayOfString != null && arrayOfString.length > 0)
/*       */       {
/*  2647 */         for (String str : arrayOfString) {
/*  2648 */           if (str.trim() != "") {
/*  2649 */             this.commitOption |= OracleConnection.CommitOption.valueOf(str.trim()).getCode();
/*       */           }
/*       */         } 
/*       */       }
/*       */     } 
/*  2654 */     str1 = null;
/*  2655 */     if (paramProperties != null)
/*       */     {
/*  2657 */       str1 = paramProperties.getProperty("oracle.jdbc.calculateChecksum");
/*       */     }
/*  2659 */     if (str1 == null)
/*  2660 */       str1 = getSystemProperty("oracle.jdbc.calculateChecksum", (String)null); 
/*  2661 */     if (str1 == null) {
/*  2662 */       this.checksumMode = OracleConnection.ChecksumMode.NO_CHECKSUM;
/*       */     } else {
/*       */       
/*  2665 */       this.checksumMode = OracleConnection.ChecksumMode.valueOf(str1);
/*       */     } 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*  2671 */     this.includeSynonyms = parseConnectionProperty_boolean(paramProperties, "synonyms", (byte)3, this.includeSynonyms);
/*       */ 
/*       */     
/*  2674 */     this.reportRemarks = parseConnectionProperty_boolean(paramProperties, "remarks", (byte)3, this.reportRemarks);
/*       */ 
/*       */     
/*  2677 */     this.defaultRowPrefetch = parseConnectionProperty_int(paramProperties, "prefetch", (byte)3, this.defaultRowPrefetch);
/*       */ 
/*       */     
/*  2680 */     this.defaultRowPrefetch = parseConnectionProperty_int(paramProperties, "rowPrefetch", (byte)3, this.defaultRowPrefetch);
/*       */ 
/*       */     
/*  2683 */     this.defaultExecuteBatch = parseConnectionProperty_int(paramProperties, "batch", (byte)3, this.defaultExecuteBatch);
/*       */ 
/*       */     
/*  2686 */     this.defaultExecuteBatch = parseConnectionProperty_int(paramProperties, "executeBatch", (byte)3, this.defaultExecuteBatch);
/*       */ 
/*       */     
/*  2689 */     this.proxyClientName = parseConnectionProperty_String(paramProperties, "PROXY_CLIENT_NAME", (byte)1, this.proxyClientName);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*  2695 */     if (this.defaultRowPrefetch <= 0) {
/*  2696 */       this.defaultRowPrefetch = Integer.parseInt("10");
/*       */     }
/*  2698 */     if (this.defaultExecuteBatch <= 0) {
/*  2699 */       this.defaultExecuteBatch = Integer.parseInt("1");
/*       */     }
/*  2701 */     if (this.defaultLobPrefetchSize < -1) {
/*       */       
/*  2703 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 267);
/*  2704 */       sQLException.fillInStackTrace();
/*  2705 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */     
/*  2709 */     if (this.thinVsessionOsuser == null) {
/*       */       
/*  2711 */       this.thinVsessionOsuser = getSystemProperty("user.name", (String)null);
/*  2712 */       if (this.thinVsessionOsuser == null) {
/*  2713 */         this.thinVsessionOsuser = "jdbcuser";
/*       */       }
/*       */     } 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*  2720 */     if (this.thinNetConnectTimeout == CONNECTION_PROPERTY_THIN_NET_CONNECT_TIMEOUT_DEFAULT) {
/*       */       
/*  2722 */       int i = DriverManager.getLoginTimeout();
/*  2723 */       if (i != 0) {
/*  2724 */         this.thinNetConnectTimeout = "" + (i * 1000);
/*       */       }
/*       */     } 
/*       */     
/*  2728 */     this.autocommit = this.defaultautocommit;
/*       */ 
/*       */ 
/*       */     
/*  2732 */     this.url = paramString;
/*  2733 */     Hashtable hashtable = parseUrl(this.url, this.walletLocation, this.walletPassword);
/*       */     
/*  2735 */     if (this.userName == CONNECTION_PROPERTY_USER_NAME_DEFAULT)
/*  2736 */       this.userName = (String)hashtable.get("user"); 
/*  2737 */     String[] arrayOfString1 = new String[1];
/*  2738 */     String[] arrayOfString2 = new String[1];
/*  2739 */     this.userName = parseLoginOption(this.userName, paramProperties, arrayOfString1, arrayOfString2);
/*  2740 */     if (arrayOfString1[0] != null)
/*  2741 */       this.internalLogon = arrayOfString1[0]; 
/*  2742 */     if (arrayOfString2[0] != null) {
/*  2743 */       this.proxyClientName = arrayOfString2[0];
/*       */     }
/*  2745 */     String str2 = paramProperties.getProperty("password", CONNECTION_PROPERTY_PASSWORD_DEFAULT);
/*       */     
/*  2747 */     if (str2 == CONNECTION_PROPERTY_PASSWORD_DEFAULT)
/*  2748 */       str2 = (String)hashtable.get("password"); 
/*  2749 */     initializePassword(str2);
/*       */     
/*  2751 */     if (this.database == CONNECTION_PROPERTY_DATABASE_DEFAULT) {
/*  2752 */       this.database = paramProperties.getProperty("server", CONNECTION_PROPERTY_DATABASE_DEFAULT);
/*       */     }
/*  2754 */     if (this.database == CONNECTION_PROPERTY_DATABASE_DEFAULT) {
/*  2755 */       this.database = (String)hashtable.get("database");
/*       */     }
/*  2757 */     this.protocol = (String)hashtable.get("protocol");
/*       */ 
/*       */     
/*  2760 */     if (this.protocol == null) {
/*       */ 
/*       */       
/*  2763 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 40, "Protocol is not specified in URL");
/*  2764 */       sQLException.fillInStackTrace();
/*  2765 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */ 
/*       */     
/*  2770 */     if (this.protocol.equals("oci8") || this.protocol.equals("oci")) {
/*  2771 */       this.database = translateConnStr(this.database);
/*       */       
/*  2773 */       if (null != this.targetInstanceName && !"".equals(this.targetInstanceName)) {
/*  2774 */         this.database = createNamedInstanceUrl(this.database, this.targetInstanceName);
/*       */       }
/*       */     } 
/*  2777 */     if (paramProperties.getProperty("is_connection_pooling") == "true")
/*       */     {
/*       */       
/*  2780 */       if (this.database == null) {
/*  2781 */         this.database = "";
/*       */       }
/*       */     }
/*  2784 */     if (this.userName != null && !this.userName.startsWith("\"")) {
/*       */ 
/*       */       
/*  2787 */       char[] arrayOfChar = this.userName.toCharArray();
/*  2788 */       for (byte b = 0; b < arrayOfChar.length; b++)
/*  2789 */         arrayOfChar[b] = Character.toUpperCase(arrayOfChar[b]); 
/*  2790 */       this.userName = String.copyValueOf(arrayOfChar);
/*       */     } 
/*       */ 
/*       */     
/*  2794 */     this.xaWantsError = false;
/*  2795 */     this.usingXA = false;
/*       */     
/*  2797 */     readOCIConnectionPoolProperties(paramProperties);
/*  2798 */     validateConnectionProperties();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private void readOCIConnectionPoolProperties(Properties paramProperties) throws SQLException {
/*  2807 */     this.ociConnectionPoolMinLimit = parseConnectionProperty_int(paramProperties, "connpool_min_limit", (byte)1, 0);
/*       */ 
/*       */     
/*  2810 */     this.ociConnectionPoolMaxLimit = parseConnectionProperty_int(paramProperties, "connpool_max_limit", (byte)1, 0);
/*       */ 
/*       */     
/*  2813 */     this.ociConnectionPoolIncrement = parseConnectionProperty_int(paramProperties, "connpool_increment", (byte)1, 0);
/*       */ 
/*       */     
/*  2816 */     this.ociConnectionPoolTimeout = parseConnectionProperty_int(paramProperties, "connpool_timeout", (byte)1, 0);
/*       */ 
/*       */     
/*  2819 */     this.ociConnectionPoolNoWait = parseConnectionProperty_boolean(paramProperties, "connpool_nowait", (byte)1, false);
/*       */ 
/*       */     
/*  2822 */     this.ociConnectionPoolTransactionDistributed = parseConnectionProperty_boolean(paramProperties, "transactions_distributed", (byte)1, false);
/*       */ 
/*       */     
/*  2825 */     this.ociConnectionPoolLogonMode = parseConnectionProperty_String(paramProperties, "connection_pool", (byte)1, (String)null);
/*       */ 
/*       */     
/*  2828 */     this.ociConnectionPoolIsPooling = parseConnectionProperty_boolean(paramProperties, "is_connection_pooling", (byte)1, false);
/*       */ 
/*       */     
/*  2831 */     this.ociConnectionPoolObject = parseConnectionProperty_Object(paramProperties, "connpool_object", (Object)null);
/*       */     
/*  2833 */     this.ociConnectionPoolConnID = parseConnectionProperty_Object(paramProperties, "connection_id", (Object)null);
/*       */     
/*  2835 */     this.ociConnectionPoolProxyType = parseConnectionProperty_String(paramProperties, "proxytype", (byte)1, (String)null);
/*       */ 
/*       */     
/*  2838 */     this.ociConnectionPoolProxyNumRoles = (Integer)parseConnectionProperty_Object(paramProperties, "proxy_num_roles", Integer.valueOf(0));
/*       */     
/*  2840 */     this.ociConnectionPoolProxyRoles = parseConnectionProperty_Object(paramProperties, "proxy_roles", (Object)null);
/*       */     
/*  2842 */     this.ociConnectionPoolProxyUserName = parseConnectionProperty_String(paramProperties, "proxy_user_name", (byte)1, (String)null);
/*       */ 
/*       */     
/*  2845 */     this.ociConnectionPoolProxyPassword = parseConnectionProperty_String(paramProperties, "proxy_password", (byte)1, (String)null);
/*       */ 
/*       */     
/*  2848 */     this.ociConnectionPoolProxyDistinguishedName = parseConnectionProperty_String(paramProperties, "proxy_distinguished_name", (byte)1, (String)null);
/*       */ 
/*       */     
/*  2851 */     this.ociConnectionPoolProxyCertificate = parseConnectionProperty_Object(paramProperties, "proxy_certificate", (Object)null);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*  2858 */   private static final Pattern driverNameAttributePattern = Pattern.compile("[\\x20-\\x7e]{0,8}");
/*       */ 
/*       */ 
/*       */   
/*       */   static final String CONNECT_DATA_KEYWORD = "CONNECT_DATA";
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   void validateConnectionProperties() throws SQLException {
/*  2868 */     if (this.driverNameAttribute != null && !driverNameAttributePattern.matcher(this.driverNameAttribute).matches()) {
/*       */ 
/*       */       
/*  2871 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 257);
/*  2872 */       sQLException.fillInStackTrace();
/*  2873 */       throw sQLException;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static final Object parseConnectionProperty_Object(Properties paramProperties, String paramString, Object paramObject) throws SQLException {
/*  2890 */     Object object = paramObject;
/*  2891 */     if (paramProperties != null) {
/*       */       
/*  2893 */       Object object1 = paramProperties.get(paramString);
/*  2894 */       if (object1 != null)
/*  2895 */         object = object1; 
/*       */     } 
/*  2897 */     return object;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static final String parseConnectionProperty_String(Properties paramProperties, String paramString1, byte paramByte, String paramString2) throws SQLException {
/*  2926 */     String str = null;
/*  2927 */     if ((paramByte == 1 || paramByte == 3) && paramProperties != null) {
/*       */ 
/*       */       
/*  2930 */       str = paramProperties.getProperty(paramString1);
/*  2931 */       if (str == null && !paramString1.startsWith("oracle.") && !paramString1.startsWith("java.") && !paramString1.startsWith("javax."))
/*  2932 */         str = paramProperties.getProperty("oracle.jdbc." + paramString1); 
/*       */     } 
/*  2934 */     if (str == null && (paramByte == 2 || paramByte == 3))
/*       */     {
/*       */       
/*  2937 */       if (paramString1.startsWith("oracle.") || paramString1.startsWith("java.") || paramString1.startsWith("javax.")) {
/*  2938 */         str = getSystemProperty(paramString1, (String)null);
/*       */       } else {
/*  2940 */         str = getSystemProperty("oracle.jdbc." + paramString1, (String)null);
/*       */       }  } 
/*  2942 */     if (str == null)
/*  2943 */       str = paramString2; 
/*  2944 */     return str;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static final int parseConnectionProperty_int(Properties paramProperties, String paramString, byte paramByte, int paramInt) throws SQLException {
/*  2955 */     int i = paramInt;
/*  2956 */     String str = parseConnectionProperty_String(paramProperties, paramString, paramByte, (String)null);
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*  2961 */     if (str != null) {
/*       */       
/*       */       try {
/*       */         
/*  2965 */         i = Integer.parseInt(str);
/*       */       }
/*  2967 */       catch (NumberFormatException numberFormatException) {
/*       */ 
/*       */ 
/*       */         
/*  2971 */         SQLException sQLException = DatabaseError.createSqlException((OracleConnection)null, 190, "Property is '" + paramString + "' and value is '" + str + "'");
/*  2972 */         sQLException.fillInStackTrace();
/*  2973 */         throw sQLException;
/*       */       } 
/*       */     }
/*       */ 
/*       */     
/*  2978 */     return i;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static final long parseConnectionProperty_long(Properties paramProperties, String paramString, byte paramByte, long paramLong) throws SQLException {
/*  2989 */     long l = paramLong;
/*  2990 */     String str = parseConnectionProperty_String(paramProperties, paramString, paramByte, (String)null);
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*  2995 */     if (str != null) {
/*       */       
/*       */       try {
/*       */         
/*  2999 */         l = Long.parseLong(str);
/*       */       }
/*  3001 */       catch (NumberFormatException numberFormatException) {
/*       */ 
/*       */ 
/*       */         
/*  3005 */         SQLException sQLException = DatabaseError.createSqlException((OracleConnection)null, 190, "Property is '" + paramString + "' and value is '" + str + "'");
/*  3006 */         sQLException.fillInStackTrace();
/*  3007 */         throw sQLException;
/*       */       } 
/*       */     }
/*       */ 
/*       */     
/*  3012 */     return l;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static final boolean parseConnectionProperty_boolean(Properties paramProperties, String paramString, byte paramByte, boolean paramBoolean) throws SQLException {
/*  3023 */     boolean bool = paramBoolean;
/*  3024 */     String str = parseConnectionProperty_String(paramProperties, paramString, paramByte, (String)null);
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*  3029 */     if (str != null)
/*       */     {
/*  3031 */       if (str.equalsIgnoreCase("false")) {
/*  3032 */         bool = false;
/*  3033 */       } else if (str.equalsIgnoreCase("true")) {
/*  3034 */         bool = true;
/*       */       }  } 
/*  3036 */     return bool;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static String parseLoginOption(String paramString, Properties paramProperties, String[] paramArrayOfString1, String[] paramArrayOfString2) {
/*  3056 */     int j = 0;
/*  3057 */     String str1 = null;
/*  3058 */     String str2 = null;
/*       */ 
/*       */     
/*  3061 */     if (paramString == null) {
/*  3062 */       return null;
/*       */     }
/*  3064 */     int k = paramString.length();
/*       */     
/*  3066 */     if (k == 0) {
/*  3067 */       return null;
/*       */     }
/*       */     
/*  3070 */     int i = paramString.indexOf('[');
/*  3071 */     if (i > 0) {
/*  3072 */       j = paramString.indexOf(']');
/*  3073 */       str2 = paramString.substring(i + 1, j);
/*  3074 */       str2 = str2.trim();
/*       */       
/*  3076 */       if (str2.length() > 0) {
/*  3077 */         paramArrayOfString2[0] = str2;
/*       */       }
/*       */       
/*  3080 */       paramString = paramString.substring(0, i) + paramString.substring(j + 1, k);
/*       */     } 
/*       */ 
/*       */ 
/*       */     
/*  3085 */     String str3 = paramString.toLowerCase();
/*       */ 
/*       */     
/*  3088 */     i = str3.lastIndexOf(" as ");
/*       */     
/*  3090 */     if (i == -1 || i < str3.lastIndexOf("\"")) {
/*  3091 */       return paramString;
/*       */     }
/*       */ 
/*       */ 
/*       */     
/*  3096 */     str1 = paramString.substring(0, i);
/*       */     
/*  3098 */     i += 4;
/*       */ 
/*       */     
/*  3101 */     while (i < k && str3.charAt(i) == ' ') {
/*  3102 */       i++;
/*       */     }
/*  3104 */     if (i == k) {
/*  3105 */       return paramString;
/*       */     }
/*  3107 */     String str4 = str3.substring(i).trim();
/*       */     
/*  3109 */     if (str4.length() > 0) {
/*  3110 */       paramArrayOfString1[0] = str4;
/*       */     }
/*  3112 */     return str1;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   static final Hashtable parseUrl(String paramString1, String paramString2, String paramString3) throws SQLException {
/*  3133 */     Hashtable<Object, Object> hashtable = new Hashtable<>(5);
/*  3134 */     int i = paramString1.indexOf(':', paramString1.indexOf(':') + 1) + 1;
/*  3135 */     int j = paramString1.length();
/*       */ 
/*       */     
/*  3138 */     if (i == j) {
/*  3139 */       return hashtable;
/*       */     }
/*  3141 */     int k = paramString1.indexOf(':', i);
/*       */ 
/*       */     
/*  3144 */     if (k == -1)
/*       */     {
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*  3150 */       return hashtable;
/*       */     }
/*       */ 
/*       */     
/*  3154 */     hashtable.put("protocol", paramString1.substring(i, k));
/*       */     
/*  3156 */     int m = k + 1;
/*  3157 */     int n = paramString1.indexOf('/', m);
/*       */     
/*  3159 */     int i1 = paramString1.indexOf('@', m);
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*  3164 */     if (i1 > m && m > i && n == -1) {
/*       */ 
/*       */       
/*  3167 */       SQLException sQLException = DatabaseError.createSqlException((OracleConnection)null, 67);
/*  3168 */       sQLException.fillInStackTrace();
/*  3169 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */     
/*  3173 */     if (i1 == -1) {
/*  3174 */       i1 = j;
/*       */     }
/*  3176 */     if (n == -1) {
/*  3177 */       n = i1;
/*       */     }
/*  3179 */     if (n < i1 && n != m && i1 != m) {
/*       */       
/*  3181 */       hashtable.put("user", paramString1.substring(m, n));
/*  3182 */       hashtable.put("password", paramString1.substring(n + 1, i1));
/*       */     } 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*  3188 */     if (n <= i1 && (n == m || i1 == m))
/*       */     {
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*  3195 */       if (i1 < j) {
/*       */         
/*  3197 */         String str = paramString1.substring(i1 + 1);
/*  3198 */         String[] arrayOfString = getSecretStoreCredentials(str, paramString2, paramString3);
/*  3199 */         if (arrayOfString[0] != null || arrayOfString[1] != null) {
/*       */           
/*  3201 */           hashtable.put("user", arrayOfString[0]);
/*  3202 */           hashtable.put("password", arrayOfString[1]);
/*       */         } 
/*       */       } 
/*       */     }
/*       */ 
/*       */     
/*  3208 */     if (i1 < j) {
/*  3209 */       hashtable.put("database", paramString1.substring(i1 + 1));
/*       */     }
/*  3211 */     return hashtable;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static final synchronized String[] getSecretStoreCredentials(String paramString1, String paramString2, String paramString3) throws SQLException {
/*  3373 */     String[] arrayOfString = new String[2];
/*  3374 */     arrayOfString[0] = null;
/*  3375 */     arrayOfString[1] = null;
/*       */     
/*  3377 */     if (paramString2 != null) {
/*       */       
/*       */       try {
/*       */         
/*  3381 */         if (paramString2.startsWith("(")) {
/*  3382 */           paramString2 = "file:" + CustomSSLSocketFactory.processWalletLocation(paramString2);
/*       */         }
/*  3384 */         OracleWallet oracleWallet = new OracleWallet();
/*  3385 */         if (oracleWallet.exists(paramString2)) {
/*       */ 
/*       */ 
/*       */           
/*  3389 */           char[] arrayOfChar = null;
/*  3390 */           if (paramString3 != null) {
/*  3391 */             arrayOfChar = paramString3.toCharArray();
/*       */           }
/*       */ 
/*       */           
/*  3395 */           oracleWallet.open(paramString2, arrayOfChar);
/*  3396 */           OracleSecretStore oracleSecretStore = oracleWallet.getSecretStore();
/*       */ 
/*       */ 
/*       */           
/*  3400 */           if (oracleSecretStore.containsAlias("oracle.security.client.default_username")) {
/*  3401 */             arrayOfString[0] = new String(oracleSecretStore.getSecret("oracle.security.client.default_username"));
/*       */           }
/*  3403 */           if (oracleSecretStore.containsAlias("oracle.security.client.default_password")) {
/*  3404 */             arrayOfString[1] = new String(oracleSecretStore.getSecret("oracle.security.client.default_password"));
/*       */           }
/*       */           
/*  3407 */           Enumeration<String> enumeration = oracleWallet.getSecretStore().internalAliases();
/*       */           
/*  3409 */           String str = null;
/*  3410 */           while (enumeration.hasMoreElements()) {
/*       */             
/*  3412 */             str = enumeration.nextElement();
/*  3413 */             if (str.startsWith("oracle.security.client.connect_string"))
/*       */             {
/*  3415 */               if (paramString1.equalsIgnoreCase(new String(oracleSecretStore.getSecret(str)))) {
/*       */ 
/*       */                 
/*  3418 */                 String str1 = str.substring("oracle.security.client.connect_string".length());
/*  3419 */                 arrayOfString[0] = new String(oracleSecretStore.getSecret("oracle.security.client.username" + str1));
/*       */                 
/*  3421 */                 arrayOfString[1] = new String(oracleSecretStore.getSecret("oracle.security.client.password" + str1));
/*       */ 
/*       */                 
/*       */                 break;
/*       */               } 
/*       */             }
/*       */           } 
/*       */         } 
/*  3429 */       } catch (NoClassDefFoundError noClassDefFoundError) {
/*       */ 
/*       */         
/*  3432 */         SQLException sQLException = DatabaseError.createSqlException((OracleConnection)null, 167, noClassDefFoundError);
/*  3433 */         sQLException.fillInStackTrace();
/*  3434 */         throw sQLException;
/*       */       
/*       */       }
/*  3437 */       catch (Exception exception) {
/*       */         
/*  3439 */         if (exception instanceof RuntimeException) throw (RuntimeException)exception;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*  3449 */         SQLException sQLException = DatabaseError.createSqlException((OracleConnection)null, 168, exception);
/*  3450 */         sQLException.fillInStackTrace();
/*  3451 */         throw sQLException;
/*       */       } 
/*       */     }
/*       */ 
/*       */     
/*  3456 */     return arrayOfString;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private String translateConnStr(String paramString) throws SQLException {
/*  3475 */     int i = 0;
/*  3476 */     int j = 0;
/*       */     
/*  3478 */     if (paramString == null || paramString.equals("")) {
/*  3479 */       return paramString;
/*       */     }
/*       */     
/*  3482 */     if (paramString.indexOf(')') != -1) {
/*  3483 */       return paramString;
/*       */     }
/*  3485 */     boolean bool = false;
/*  3486 */     if (paramString.indexOf('[') != -1) {
/*       */ 
/*       */       
/*  3489 */       i = paramString.indexOf(']');
/*  3490 */       if (i == -1) {
/*       */         
/*  3492 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 67, paramString);
/*  3493 */         sQLException.fillInStackTrace();
/*  3494 */         throw sQLException;
/*       */       } 
/*  3496 */       bool = true;
/*       */     } 
/*       */     
/*  3499 */     i = paramString.indexOf(':', i);
/*  3500 */     if (i == -1)
/*  3501 */       return paramString; 
/*  3502 */     j = paramString.indexOf(':', i + 1);
/*  3503 */     if (j == -1) {
/*  3504 */       return paramString;
/*       */     }
/*       */     
/*  3507 */     if (paramString.indexOf(':', j + 1) != -1) {
/*       */ 
/*       */       
/*  3510 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 67, paramString);
/*  3511 */       sQLException.fillInStackTrace();
/*  3512 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */     
/*  3516 */     String str1 = null;
/*  3517 */     if (bool) {
/*  3518 */       str1 = paramString.substring(1, i - 1);
/*       */     } else {
/*  3520 */       str1 = paramString.substring(0, i);
/*       */     } 
/*  3522 */     String str2 = paramString.substring(i + 1, j);
/*  3523 */     String str3 = paramString.substring(j + 1, paramString.length());
/*       */     
/*  3525 */     return "(DESCRIPTION=(ADDRESS=(PROTOCOL=tcp)(HOST=" + str1 + ")(PORT=" + str2 + "))(CONNECT_DATA=(SID=" + str3 + ")))";
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private String createNamedInstanceUrl(String paramString1, String paramString2) {
/*  3547 */     StringBuffer stringBuffer = new StringBuffer(paramString1);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*  3554 */     int i = stringBuffer.indexOf("CONNECT_DATA");
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*  3559 */     if (i != -1) {
/*  3560 */       int j = stringBuffer.indexOf("=", i + "CONNECT_DATA".length());
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*  3565 */       if (j != -1) {
/*  3566 */         stringBuffer.insert(j + 1, "(INSTANCE_NAME=" + paramString2 + ")");
/*       */       }
/*       */     } 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*  3575 */     return stringBuffer.toString();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   protected static String getSystemPropertyPollInterval() {
/*  3585 */     return getSystemProperty("oracle.jdbc.TimeoutPollInterval", "1000");
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   static String getSqlTranslationProfile() {
/*  3592 */     return getSystemProperty("oracle.jdbc.sqlTranslationProfile", (String)null);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   static String getSystemPropertyFastConnectionFailover(String paramString) {
/*  3600 */     return getSystemProperty("oracle.jdbc.FastConnectionFailover", paramString);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   static String getSystemPropertyJserverVersion() {
/*  3608 */     return getSystemProperty("oracle.jserver.version", (String)null);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static String getSystemProperty(String paramString1, String paramString2) {
/*  3615 */     if (paramString1 != null) {
/*       */       
/*  3617 */       final String fstr = paramString1;
/*  3618 */       final String fdefaultValue = paramString2;
/*  3619 */       final String[] rets = { paramString2 };
/*  3620 */       AccessController.doPrivileged(new PrivilegedAction()
/*       */           {
/*       */             public Object run()
/*       */             {
/*  3624 */               rets[0] = System.getProperty(fstr, fdefaultValue);
/*  3625 */               return null;
/*       */             }
/*       */           });
/*  3628 */       return arrayOfString[0];
/*       */     } 
/*       */     
/*  3631 */     return paramString2;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public Properties getProperties() {
/*  3647 */     Properties properties = new Properties();
/*       */     
/*       */     try {
/*  3650 */       Class<?> clazz1 = null;
/*  3651 */       Class<?> clazz2 = null;
/*       */       
/*       */       try {
/*  3654 */         clazz1 = Class.forName("oracle.jdbc.OracleConnection");
/*  3655 */         clazz2 = Class.forName("oracle.jdbc.driver.PhysicalConnection");
/*       */       }
/*  3657 */       catch (ClassNotFoundException classNotFoundException) {}
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*  3664 */       Field[] arrayOfField = clazz2.getDeclaredFields();
/*  3665 */       for (byte b = 0; b < arrayOfField.length; b++) {
/*       */         
/*  3667 */         int i = arrayOfField[b].getModifiers();
/*  3668 */         if (!Modifier.isStatic(i)) {
/*       */ 
/*       */           
/*  3671 */           String str1 = arrayOfField[b].getName();
/*       */ 
/*       */           
/*  3674 */           String str2 = "CONNECTION_PROPERTY_" + propertyVariableName(str1);
/*       */ 
/*       */ 
/*       */           
/*  3678 */           Field field = null;
/*       */ 
/*       */           
/*       */           try {
/*  3682 */             field = clazz1.getField(str2);
/*       */           }
/*  3684 */           catch (NoSuchFieldException noSuchFieldException) {}
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*  3690 */           if (!str2.matches(".*PASSWORD.*")) {
/*       */ 
/*       */             
/*  3693 */             String str3 = (String)field.get(null);
/*  3694 */             String str4 = arrayOfField[b].getType().getName();
/*  3695 */             if (str4.equals("boolean"))
/*       */             
/*  3697 */             { boolean bool = arrayOfField[b].getBoolean(this);
/*  3698 */               if (bool) {
/*  3699 */                 properties.setProperty(str3, "true");
/*       */               } else {
/*  3701 */                 properties.setProperty(str3, "false");
/*       */               }  }
/*  3703 */             else if (str4.equals("int"))
/*       */             
/*  3705 */             { int j = arrayOfField[b].getInt(this);
/*  3706 */               properties.setProperty(str3, Integer.toString(j)); }
/*       */             
/*  3708 */             else if (str4.equals("long"))
/*       */             
/*  3710 */             { long l = arrayOfField[b].getLong(this);
/*  3711 */               properties.setProperty(str3, Long.toString(l)); }
/*       */             
/*  3713 */             else if (str4.equals("java.lang.String"))
/*       */             
/*  3715 */             { String str = (String)arrayOfField[b].get(this);
/*  3716 */               if (str != null)
/*  3717 */                 properties.setProperty(str3, str);  } 
/*       */           } 
/*       */         } 
/*       */       } 
/*  3721 */     } catch (IllegalAccessException illegalAccessException) {}
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*  3726 */     return properties;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized Connection _getPC() {
/*  3752 */     return null;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized OracleConnection getPhysicalConnection() {
/*  3773 */     return this;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized boolean isLogicalConnection() {
/*  3791 */     return false;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   void initialize(Hashtable paramHashtable, Map paramMap1, Map paramMap2) throws SQLException {
/*  3804 */     this.clearStatementMetaData = false;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*  3810 */     if (paramHashtable != null) {
/*  3811 */       this.descriptorCacheStack[this.dci] = paramHashtable;
/*       */     } else {
/*  3813 */       this.descriptorCacheStack[this.dci] = new Hashtable<>(10);
/*       */     } 
/*  3815 */     this.map = paramMap1;
/*       */     
/*  3817 */     if (paramMap2 != null) {
/*  3818 */       this.javaObjectMap = paramMap2;
/*       */     } else {
/*  3820 */       this.javaObjectMap = new Hashtable<>(10);
/*       */     } 
/*  3822 */     this.lifecycle = 1;
/*  3823 */     this.txnLevel = 2;
/*       */ 
/*       */     
/*  3826 */     this.clientIdSet = false;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   void initializeSetCHARCharSetObjs() {
/*  3834 */     this.setCHARNCharSetObj = this.conversion.getDriverNCharSetObj();
/*  3835 */     this.setCHARCharSetObj = this.conversion.getDriverCharSetObj();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   OracleTimeout getTimeout() throws SQLException {
/*  3849 */     if (this.timeout == null)
/*       */     {
/*  3851 */       this.timeout = OracleTimeout.newTimeout(this.url);
/*       */     }
/*       */     
/*  3854 */     return this.timeout;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized Statement createStatement() throws SQLException {
/*  3878 */     return createStatement(-1, -1);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized Statement createStatement(int paramInt1, int paramInt2) throws SQLException {
/*  3905 */     if (this.lifecycle != 1) {
/*       */       
/*  3907 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 8);
/*  3908 */       sQLException.fillInStackTrace();
/*  3909 */       throw sQLException;
/*       */     } 
/*       */     
/*  3912 */     OracleStatement oracleStatement = null;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*  3918 */     oracleStatement = this.driverExtension.allocateStatement(this, paramInt1, paramInt2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*  3925 */     return (Statement)new OracleStatementWrapper((OracleStatement)oracleStatement);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized PreparedStatement prepareStatement(String paramString) throws SQLException {
/*  3951 */     return prepareStatement(paramString, -1, -1);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized PreparedStatement prepareStatementWithKey(String paramString) throws SQLException {
/*       */     OraclePreparedStatementWrapper oraclePreparedStatementWrapper;
/*  3977 */     if (this.lifecycle != 1) {
/*       */       
/*  3979 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 8);
/*  3980 */       sQLException.fillInStackTrace();
/*  3981 */       throw sQLException;
/*       */     } 
/*       */     
/*  3984 */     if (paramString == null) {
/*  3985 */       return null;
/*       */     }
/*  3987 */     if (!isStatementCacheInitialized()) {
/*       */       
/*  3989 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 95);
/*  3990 */       sQLException.fillInStackTrace();
/*  3991 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*  3998 */     OraclePreparedStatement oraclePreparedStatement = null;
/*       */     
/*  4000 */     oraclePreparedStatement = (OraclePreparedStatement)this.statementCache.searchExplicitCache(paramString);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*  4011 */     if (oraclePreparedStatement != null) {
/*  4012 */       oraclePreparedStatementWrapper = new OraclePreparedStatementWrapper((OraclePreparedStatement)oraclePreparedStatement);
/*       */     }
/*  4014 */     return (PreparedStatement)oraclePreparedStatementWrapper;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized PreparedStatement prepareStatement(String paramString, int paramInt1, int paramInt2) throws SQLException {
/*  4045 */     OraclePreparedStatement oraclePreparedStatement = prepareStatementInternal(paramString, paramInt1, paramInt2);
/*       */     
/*  4047 */     return (PreparedStatement)new OraclePreparedStatementWrapper((OraclePreparedStatement)oraclePreparedStatement);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   OraclePreparedStatement prepareStatementInternal(String paramString, int paramInt1, int paramInt2) throws SQLException {
/*  4069 */     if (paramString == null || paramString.length() == 0) {
/*       */       
/*  4071 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 104);
/*  4072 */       sQLException.fillInStackTrace();
/*  4073 */       throw sQLException;
/*       */     } 
/*       */     
/*  4076 */     if (this.lifecycle != 1) {
/*       */       
/*  4078 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 8);
/*  4079 */       sQLException.fillInStackTrace();
/*  4080 */       throw sQLException;
/*       */     } 
/*       */     
/*  4083 */     OraclePreparedStatement oraclePreparedStatement = null;
/*       */ 
/*       */     
/*  4086 */     if (this.statementCache != null) {
/*  4087 */       OracleResultSet.ResultSetType resultSetType = OracleResultSet.ResultSetType.typeFor(paramInt1, paramInt2);
/*  4088 */       if (resultSetType == OracleResultSet.ResultSetType.UNKNOWN) resultSetType = OracleStatement.DEFAULT_RESULT_SET_TYPE; 
/*  4089 */       oraclePreparedStatement = (OraclePreparedStatement)this.statementCache.searchImplicitCache(paramString, 1, resultSetType.ordinal(), this);
/*       */     } 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*  4097 */     if (oraclePreparedStatement == null) {
/*  4098 */       oraclePreparedStatement = this.driverExtension.allocatePreparedStatement(this, paramString, paramInt1, paramInt2);
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*  4110 */     return oraclePreparedStatement;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized CallableStatement prepareCall(String paramString) throws SQLException {
/*  4134 */     return prepareCall(paramString, -1, -1);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized CallableStatement prepareCall(String paramString, int paramInt1, int paramInt2) throws SQLException {
/*  4168 */     if (paramString == null || paramString.length() == 0) {
/*       */       
/*  4170 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 104);
/*  4171 */       sQLException.fillInStackTrace();
/*  4172 */       throw sQLException;
/*       */     } 
/*       */     
/*  4175 */     if (this.lifecycle != 1) {
/*       */       
/*  4177 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 8);
/*  4178 */       sQLException.fillInStackTrace();
/*  4179 */       throw sQLException;
/*       */     } 
/*       */     
/*  4182 */     OracleCallableStatement oracleCallableStatement = null;
/*       */     
/*  4184 */     if (this.statementCache != null) {
/*  4185 */       OracleResultSet.ResultSetType resultSetType = OracleResultSet.ResultSetType.typeFor(paramInt1, paramInt2);
/*  4186 */       if (resultSetType == OracleResultSet.ResultSetType.UNKNOWN) resultSetType = OracleStatement.DEFAULT_RESULT_SET_TYPE; 
/*  4187 */       oracleCallableStatement = (OracleCallableStatement)this.statementCache.searchImplicitCache(paramString, 2, resultSetType.ordinal(), this);
/*       */     } 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*  4195 */     if (oracleCallableStatement == null) {
/*  4196 */       oracleCallableStatement = this.driverExtension.allocateCallableStatement(this, paramString, paramInt1, paramInt2);
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*  4207 */     return (CallableStatement)new OracleCallableStatementWrapper((OracleCallableStatement)oracleCallableStatement);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized CallableStatement prepareCallWithKey(String paramString) throws SQLException {
/*       */     OracleCallableStatementWrapper oracleCallableStatementWrapper;
/*  4232 */     if (this.lifecycle != 1) {
/*       */       
/*  4234 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 8);
/*  4235 */       sQLException.fillInStackTrace();
/*  4236 */       throw sQLException;
/*       */     } 
/*       */     
/*  4239 */     if (paramString == null) {
/*  4240 */       return null;
/*       */     }
/*  4242 */     if (!isStatementCacheInitialized()) {
/*       */       
/*  4244 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 95);
/*  4245 */       sQLException.fillInStackTrace();
/*  4246 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*  4253 */     OracleCallableStatement oracleCallableStatement = null;
/*       */     
/*  4255 */     oracleCallableStatement = (OracleCallableStatement)this.statementCache.searchExplicitCache(paramString);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*  4265 */     if (oracleCallableStatement != null) {
/*  4266 */       oracleCallableStatementWrapper = new OracleCallableStatementWrapper((OracleCallableStatement)oracleCallableStatement);
/*       */     }
/*  4268 */     return (CallableStatement)oracleCallableStatementWrapper;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public String nativeSQL(String paramString) throws SQLException {
/*  4285 */     if (this.sqlObj == null)
/*       */     {
/*  4287 */       this.sqlObj = new OracleSql(this.conversion);
/*       */     }
/*       */     
/*  4290 */     this.sqlObj.initialize(paramString);
/*       */     
/*  4292 */     return this.sqlObj.getSql(this.processEscapes, this.convertNcharLiterals);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized void setAutoCommit(boolean paramBoolean) throws SQLException {
/*  4309 */     if (paramBoolean) {
/*  4310 */       disallowGlobalTxnMode(116);
/*       */     }
/*  4312 */     if (this.lifecycle != 1) {
/*       */       
/*  4314 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 8);
/*  4315 */       sQLException.fillInStackTrace();
/*  4316 */       throw sQLException;
/*       */     } 
/*       */     
/*  4319 */     needLine();
/*  4320 */     doSetAutoCommit(paramBoolean);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public boolean getAutoCommit() throws SQLException {
/*  4334 */     if (this.lifecycle != 1) {
/*       */       
/*  4336 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 8);
/*  4337 */       sQLException.fillInStackTrace();
/*  4338 */       throw sQLException;
/*       */     } 
/*       */     
/*  4341 */     return this.autocommit;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void cancel() throws SQLException {
/*  4365 */     OracleStatement oracleStatement = this.statements;
/*       */     
/*  4367 */     if (this.lifecycle != 1 && this.lifecycle != 16) {
/*       */       
/*  4369 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 8);
/*  4370 */       sQLException.fillInStackTrace();
/*  4371 */       throw sQLException;
/*       */     } 
/*       */     
/*  4374 */     boolean bool = false;
/*       */     
/*  4376 */     while (oracleStatement != null) {
/*       */ 
/*       */       
/*       */       try {
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*  4384 */         if (oracleStatement.doCancel()) {
/*  4385 */           bool = true;
/*       */         }
/*  4387 */       } catch (SQLException sQLException) {}
/*       */ 
/*       */ 
/*       */       
/*  4391 */       oracleStatement = oracleStatement.next;
/*       */     } 
/*       */ 
/*       */     
/*  4395 */     if (!bool) {
/*  4396 */       cancelOperationOnServer(false);
/*       */     }
/*       */   }
/*       */ 
/*       */ 
/*       */   
/*       */   public void commit(EnumSet<OracleConnection.CommitOption> paramEnumSet) throws SQLException {
/*  4403 */     int i = 0;
/*  4404 */     if (paramEnumSet != null) {
/*       */       
/*  4406 */       if ((paramEnumSet.contains(OracleConnection.CommitOption.WRITEBATCH) && paramEnumSet.contains(OracleConnection.CommitOption.WRITEIMMED)) || (paramEnumSet.contains(OracleConnection.CommitOption.WAIT) && paramEnumSet.contains(OracleConnection.CommitOption.NOWAIT))) {
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*  4412 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 191);
/*  4413 */         sQLException.fillInStackTrace();
/*  4414 */         throw sQLException;
/*       */       } 
/*       */ 
/*       */       
/*  4418 */       for (OracleConnection.CommitOption commitOption : paramEnumSet)
/*  4419 */         i |= commitOption.getCode(); 
/*       */     } 
/*  4421 */     commit(i);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   synchronized void commit(int paramInt) throws SQLException {
/*  4437 */     disallowGlobalTxnMode(114);
/*       */ 
/*       */     
/*  4440 */     if (this.autoCommitSpecCompliant && getAutoCommit()) {
/*       */       
/*  4442 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 273);
/*  4443 */       sQLException.fillInStackTrace();
/*  4444 */       throw sQLException;
/*       */     } 
/*       */     
/*  4447 */     if (this.lifecycle != 1) {
/*       */       
/*  4449 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 8);
/*  4450 */       sQLException.fillInStackTrace();
/*  4451 */       throw sQLException;
/*       */     } 
/*       */     
/*  4454 */     OracleStatement oracleStatement = this.statements;
/*       */     
/*  4456 */     while (oracleStatement != null) {
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*  4461 */       if (!oracleStatement.closed) {
/*  4462 */         oracleStatement.sendBatch();
/*       */       }
/*  4464 */       oracleStatement = oracleStatement.next;
/*       */     } 
/*  4466 */     if (((paramInt & OracleConnection.CommitOption.WRITEBATCH.getCode()) != 0 && (paramInt & OracleConnection.CommitOption.WRITEIMMED.getCode()) != 0) || ((paramInt & OracleConnection.CommitOption.WAIT.getCode()) != 0 && (paramInt & OracleConnection.CommitOption.NOWAIT.getCode()) != 0)) {
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*  4472 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 191);
/*  4473 */       sQLException.fillInStackTrace();
/*  4474 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*  4481 */     registerHeartbeat();
/*       */     
/*  4483 */     needLine();
/*  4484 */     doCommit(paramInt);
/*       */   }
/*       */ 
/*       */ 
/*       */   
/*       */   public void commit() throws SQLException {
/*  4490 */     commit(this.commitOption);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized void rollback() throws SQLException {
/*  4504 */     disallowGlobalTxnMode(115);
/*       */ 
/*       */     
/*  4507 */     if (this.autoCommitSpecCompliant && getAutoCommit()) {
/*       */       
/*  4509 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 274);
/*  4510 */       sQLException.fillInStackTrace();
/*  4511 */       throw sQLException;
/*       */     } 
/*       */     
/*  4514 */     if (this.lifecycle != 1) {
/*       */       
/*  4516 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 8);
/*  4517 */       sQLException.fillInStackTrace();
/*  4518 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */     
/*  4522 */     OracleStatement oracleStatement = this.statements;
/*       */     
/*  4524 */     while (oracleStatement != null) {
/*       */       
/*  4526 */       if (oracleStatement.isOracleBatchStyle()) {
/*  4527 */         oracleStatement.clearBatch();
/*       */       }
/*  4529 */       oracleStatement = oracleStatement.next;
/*       */     } 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*  4536 */     registerHeartbeat();
/*       */     
/*  4538 */     needLine();
/*  4539 */     doRollback();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized void close() throws SQLException {
/*  4558 */     if (this.lifecycle == 2 || this.lifecycle == 4) {
/*       */       return;
/*       */     }
/*       */ 
/*       */ 
/*       */     
/*  4564 */     needLineUnchecked();
/*       */ 
/*       */     
/*       */     try {
/*  4568 */       if (this.closeCallback != null) {
/*  4569 */         this.closeCallback.beforeClose(this, this.privateData);
/*       */       }
/*  4571 */       closeStatementCache();
/*  4572 */       closeStatements(false);
/*       */       
/*  4574 */       if (this.lifecycle == 1) this.lifecycle = 2;
/*       */ 
/*       */       
/*  4577 */       if (this.isProxy)
/*       */       {
/*  4579 */         close(1);
/*       */       }
/*       */       
/*  4582 */       if (this.timeZoneTab != null) {
/*  4583 */         this.timeZoneTab.freeInstance();
/*       */       }
/*  4585 */       logoff();
/*  4586 */       cleanup();
/*       */       
/*  4588 */       if (this.timeout != null) {
/*  4589 */         this.timeout.close();
/*       */       }
/*  4591 */       if (this.closeCallback != null) {
/*  4592 */         this.closeCallback.afterClose(this.privateData);
/*       */       }
/*       */     } finally {
/*       */       
/*  4596 */       this.lifecycle = 4;
/*  4597 */       this.isUsable = false;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public String getDataIntegrityAlgorithmName() throws SQLException {
/*  4608 */     SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException();
/*  4609 */     sQLException.fillInStackTrace();
/*  4610 */     throw sQLException;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public String getEncryptionAlgorithmName() throws SQLException {
/*  4617 */     SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException();
/*  4618 */     sQLException.fillInStackTrace();
/*  4619 */     throw sQLException;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public String getAuthenticationAdaptorName() throws SQLException {
/*  4626 */     SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException();
/*  4627 */     sQLException.fillInStackTrace();
/*  4628 */     throw sQLException;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void closeInternal(boolean paramBoolean) throws SQLException {
/*  4638 */     SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException();
/*  4639 */     sQLException.fillInStackTrace();
/*  4640 */     throw sQLException;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void cleanupAndClose(boolean paramBoolean) throws SQLException {
/*  4651 */     SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException();
/*  4652 */     sQLException.fillInStackTrace();
/*  4653 */     throw sQLException;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   void cleanupAndClose() throws SQLException {
/*  4664 */     if (this.lifecycle != 1) {
/*       */       return;
/*       */     }
/*       */ 
/*       */ 
/*       */     
/*  4670 */     this.lifecycle = 16;
/*       */ 
/*       */     
/*  4673 */     cancel();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   synchronized void closeLogicalConnection() throws SQLException {
/*  4680 */     if (this.lifecycle == 1 || this.lifecycle == 16 || this.lifecycle == 2) {
/*       */ 
/*       */ 
/*       */       
/*  4684 */       this.savepointStatement = null;
/*  4685 */       closeStatements(true);
/*       */       
/*  4687 */       if (this.clientIdSet) {
/*  4688 */         clearClientIdentifier(this.clientId);
/*       */       }
/*  4690 */       this.logicalConnectionAttached = null;
/*  4691 */       this.lifecycle = 1;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized void close(Properties paramProperties) throws SQLException {
/*  4716 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 152);
/*  4717 */     sQLException.fillInStackTrace();
/*  4718 */     throw sQLException;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized void close(int paramInt) throws SQLException {
/*  4739 */     if ((paramInt & 0x1000) != 0) {
/*       */       
/*  4741 */       close();
/*       */       
/*       */       return;
/*       */     } 
/*       */     
/*  4746 */     if ((paramInt & 0x1) != 0 && this.isProxy) {
/*       */       
/*  4748 */       purgeStatementCache();
/*  4749 */       closeStatements(false);
/*  4750 */       this.descriptorCacheStack[this.dci--] = null;
/*       */       
/*  4752 */       closeProxySession();
/*       */       
/*  4754 */       this.isProxy = false;
/*       */ 
/*       */       
/*  4757 */       this.autocommit = this.savedAutoCommitFlag;
/*  4758 */       this.txnMode = this.savedTxnMode;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*  4765 */   private static final OracleSQLPermission CALL_ORACLE_ABORT_PERMISSION = new OracleSQLPermission("callAbort"); static final String DATABASE_NAME = "DATABASE_NAME"; static final String SERVER_HOST = "SERVER_HOST"; static final String INSTANCE_NAME = "INSTANCE_NAME"; static final String SERVICE_NAME = "SERVICE_NAME"; Hashtable clientData; private BufferCacheStore connectionBufferCacheStore; private static ThreadLocal<BufferCacheStore> threadLocalBufferCacheStore; private int pingResult; String sessionTimeZone; String databaseTimeZone;
/*       */   Calendar dbTzCalendar;
/*       */   static final String SETCLIENTINFO_PERMISSION_NAME = "clientInfo.";
/*       */   
/*       */   public void abort() throws SQLException {
/*  4770 */     SecurityManager securityManager = System.getSecurityManager();
/*  4771 */     if (securityManager != null) {
/*  4772 */       securityManager.checkPermission((Permission)CALL_ORACLE_ABORT_PERMISSION);
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*  4780 */     if (this.lifecycle == 4 || this.lifecycle == 8) {
/*       */       return;
/*       */     }
/*       */     
/*  4784 */     this.lifecycle = 8;
/*       */ 
/*       */     
/*  4787 */     doAbort();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   void closeProxySession() throws SQLException {
/*  4800 */     SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException();
/*  4801 */     sQLException.fillInStackTrace();
/*  4802 */     throw sQLException;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public Properties getServerSessionInfo() throws SQLException {
/*  4824 */     SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException();
/*  4825 */     sQLException.fillInStackTrace();
/*  4826 */     throw sQLException;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized void applyConnectionAttributes(Properties paramProperties) throws SQLException {
/*  4844 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 152);
/*  4845 */     sQLException.fillInStackTrace();
/*  4846 */     throw sQLException;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized Properties getConnectionAttributes() throws SQLException {
/*  4864 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 152);
/*  4865 */     sQLException.fillInStackTrace();
/*  4866 */     throw sQLException;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized Properties getUnMatchedConnectionAttributes() throws SQLException {
/*  4884 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 152);
/*  4885 */     sQLException.fillInStackTrace();
/*  4886 */     throw sQLException;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized void setAbandonedTimeoutEnabled(boolean paramBoolean) throws SQLException {
/*  4905 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 152);
/*  4906 */     sQLException.fillInStackTrace();
/*  4907 */     throw sQLException;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized void registerConnectionCacheCallback(OracleConnectionCacheCallback paramOracleConnectionCacheCallback, Object paramObject, int paramInt) throws SQLException {
/*  4925 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 152);
/*  4926 */     sQLException.fillInStackTrace();
/*  4927 */     throw sQLException;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public OracleConnectionCacheCallback getConnectionCacheCallbackObj() throws SQLException {
/*  4945 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 152);
/*  4946 */     sQLException.fillInStackTrace();
/*  4947 */     throw sQLException;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public Object getConnectionCacheCallbackPrivObj() throws SQLException {
/*  4964 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 152);
/*  4965 */     sQLException.fillInStackTrace();
/*  4966 */     throw sQLException;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public int getConnectionCacheCallbackFlag() throws SQLException {
/*  4983 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 152);
/*  4984 */     sQLException.fillInStackTrace();
/*  4985 */     throw sQLException;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized void setConnectionReleasePriority(int paramInt) throws SQLException {
/*  5003 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 152);
/*  5004 */     sQLException.fillInStackTrace();
/*  5005 */     throw sQLException;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public int getConnectionReleasePriority() throws SQLException {
/*  5022 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 152);
/*  5023 */     sQLException.fillInStackTrace();
/*  5024 */     throw sQLException;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized boolean isClosed() throws SQLException {
/*  5042 */     return (this.lifecycle != 1);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized boolean isProxySession() {
/*  5054 */     return this.isProxy;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized void openProxySession(int paramInt, Properties paramProperties) throws SQLException {
/*  5068 */     boolean bool = true;
/*       */     
/*  5070 */     if (this.isProxy) {
/*       */       
/*  5072 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 149);
/*  5073 */       sQLException.fillInStackTrace();
/*  5074 */       throw sQLException;
/*       */     } 
/*       */     
/*  5077 */     String str1 = paramProperties.getProperty("PROXY_USER_NAME");
/*  5078 */     String str2 = paramProperties.getProperty("PROXY_USER_PASSWORD");
/*  5079 */     String str3 = paramProperties.getProperty("PROXY_DISTINGUISHED_NAME");
/*       */     
/*  5081 */     Object object = paramProperties.get("PROXY_CERTIFICATE");
/*       */     
/*  5083 */     if (paramInt == 1) {
/*       */       
/*  5085 */       if (str1 == null && str2 == null)
/*       */       {
/*  5087 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 150);
/*  5088 */         sQLException.fillInStackTrace();
/*  5089 */         throw sQLException;
/*       */       }
/*       */     
/*  5092 */     } else if (paramInt == 2) {
/*       */       
/*  5094 */       if (str3 == null)
/*       */       {
/*  5096 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 150);
/*  5097 */         sQLException.fillInStackTrace();
/*  5098 */         throw sQLException;
/*       */       }
/*       */     
/*  5101 */     } else if (paramInt == 3) {
/*       */       
/*  5103 */       if (object == null) {
/*       */         
/*  5105 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 150);
/*  5106 */         sQLException.fillInStackTrace();
/*  5107 */         throw sQLException;
/*       */       } 
/*       */ 
/*       */       
/*       */       try {
/*  5112 */         byte[] arrayOfByte = (byte[])object;
/*       */       }
/*  5114 */       catch (ClassCastException classCastException) {
/*       */ 
/*       */         
/*  5117 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 150);
/*  5118 */         sQLException.fillInStackTrace();
/*  5119 */         throw sQLException;
/*       */       }
/*       */     
/*       */     }
/*       */     else {
/*       */       
/*  5125 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 150);
/*  5126 */       sQLException.fillInStackTrace();
/*  5127 */       throw sQLException;
/*       */     } 
/*       */     
/*  5130 */     purgeStatementCache();
/*  5131 */     closeStatements(false);
/*       */ 
/*       */ 
/*       */     
/*       */     try {
/*  5136 */       doProxySession(paramInt, paramProperties);
/*  5137 */       this.dci++;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*  5147 */       this.savedAutoCommitFlag = this.autocommit;
/*  5148 */       this.autocommit = this.defaultautocommit;
/*  5149 */       this.savedTxnMode = this.txnMode;
/*  5150 */       this.txnMode = 0;
/*  5151 */       bool = false;
/*       */     
/*       */     }
/*       */     finally {
/*       */       
/*  5156 */       if (bool == true) {
/*  5157 */         closeProxySession();
/*       */       }
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   void doProxySession(int paramInt, Properties paramProperties) throws SQLException {
/*  5168 */     SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException();
/*  5169 */     sQLException.fillInStackTrace();
/*  5170 */     throw sQLException;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   void cleanup() {
/*  5180 */     this.fdo = null;
/*  5181 */     this.conversion = null;
/*  5182 */     this.statements = null;
/*  5183 */     this.descriptorCacheStack[this.dci] = null;
/*  5184 */     this.map = null;
/*  5185 */     this.javaObjectMap = null;
/*  5186 */     this.statementHoldingLine = null;
/*  5187 */     this.sqlObj = null;
/*  5188 */     this.isProxy = false;
/*  5189 */     this.blockSource = null;
/*  5190 */     this.connectionBufferCacheStore = null;
/*  5191 */     threadLocalBufferCacheStore = null;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized DatabaseMetaData getMetaData() throws SQLException {
/*  5213 */     if (this.lifecycle != 1) {
/*       */       
/*  5215 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 8);
/*  5216 */       sQLException.fillInStackTrace();
/*  5217 */       throw sQLException;
/*       */     } 
/*       */     
/*  5220 */     if (this.databaseMetaData == null) {
/*  5221 */       this.databaseMetaData = new OracleDatabaseMetaData(this);
/*       */     }
/*  5223 */     return (DatabaseMetaData)this.databaseMetaData;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setReadOnly(boolean paramBoolean) throws SQLException {
/*  5245 */     if (this.lifecycle != 1) {
/*       */       
/*  5247 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 8);
/*  5248 */       sQLException.fillInStackTrace();
/*  5249 */       throw sQLException;
/*       */     } 
/*       */     
/*  5252 */     this.readOnly = paramBoolean;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public boolean isReadOnly() throws SQLException {
/*  5272 */     if (this.lifecycle != 1) {
/*       */       
/*  5274 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 8);
/*  5275 */       sQLException.fillInStackTrace();
/*  5276 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */     
/*  5280 */     return this.readOnly;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setCatalog(String paramString) throws SQLException {
/*  5297 */     if (this.lifecycle != 1) {
/*       */       
/*  5299 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 8);
/*  5300 */       sQLException.fillInStackTrace();
/*  5301 */       throw sQLException;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public String getCatalog() throws SQLException {
/*  5320 */     if (this.lifecycle != 1) {
/*       */       
/*  5322 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 8);
/*  5323 */       sQLException.fillInStackTrace();
/*  5324 */       throw sQLException;
/*       */     } 
/*       */     
/*  5327 */     return null;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized void setTransactionIsolation(int paramInt) throws SQLException {
/*  5342 */     if (this.lifecycle != 1) {
/*       */       
/*  5344 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 8);
/*  5345 */       sQLException.fillInStackTrace();
/*  5346 */       throw sQLException;
/*       */     } 
/*       */     
/*  5349 */     if (this.txnLevel == paramInt) {
/*       */       return;
/*       */     }
/*  5352 */     Statement statement = createStatement();
/*       */     
/*       */     try {
/*       */       SQLException sQLException;
/*  5356 */       switch (paramInt) {
/*       */ 
/*       */ 
/*       */         
/*       */         case 2:
/*  5361 */           statement.execute("ALTER SESSION SET ISOLATION_LEVEL = READ COMMITTED");
/*       */           
/*  5363 */           this.txnLevel = 2;
/*       */           break;
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         case 8:
/*  5370 */           statement.execute("ALTER SESSION SET ISOLATION_LEVEL = SERIALIZABLE");
/*       */           
/*  5372 */           this.txnLevel = 8;
/*       */           break;
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         default:
/*  5379 */           sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 30);
/*  5380 */           sQLException.fillInStackTrace();
/*  5381 */           throw sQLException;
/*       */       } 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     } finally {
/*  5389 */       statement.close();
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public int getTransactionIsolation() throws SQLException {
/*  5404 */     if (this.lifecycle != 1) {
/*       */       
/*  5406 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 8);
/*  5407 */       sQLException.fillInStackTrace();
/*  5408 */       throw sQLException;
/*       */     } 
/*       */     
/*  5411 */     return this.txnLevel;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized void setAutoClose(boolean paramBoolean) throws SQLException {
/*  5429 */     if (!paramBoolean) {
/*       */       
/*  5431 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 31);
/*  5432 */       sQLException.fillInStackTrace();
/*  5433 */       throw sQLException;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public boolean getAutoClose() throws SQLException {
/*  5450 */     return true;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public SQLWarning getWarnings() throws SQLException {
/*  5466 */     if (this.lifecycle != 1) {
/*       */       
/*  5468 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 8);
/*  5469 */       sQLException.fillInStackTrace();
/*  5470 */       throw sQLException;
/*       */     } 
/*       */     
/*  5473 */     return this.sqlWarning;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void clearWarnings() throws SQLException {
/*  5486 */     if (this.lifecycle != 1) {
/*       */       
/*  5488 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 8);
/*  5489 */       sQLException.fillInStackTrace();
/*  5490 */       throw sQLException;
/*       */     } 
/*       */     
/*  5493 */     this.sqlWarning = null;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   void setWarnings(SQLWarning paramSQLWarning) {
/*  5500 */     this.sqlWarning = paramSQLWarning;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setDefaultRowPrefetch(int paramInt) throws SQLException {
/*  5549 */     if (paramInt <= 0) {
/*       */       
/*  5551 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 20);
/*  5552 */       sQLException.fillInStackTrace();
/*  5553 */       throw sQLException;
/*       */     } 
/*       */     
/*  5556 */     this.defaultRowPrefetch = paramInt;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public int getDefaultRowPrefetch() {
/*  5588 */     return this.defaultRowPrefetch;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public boolean getTimestamptzInGmt() {
/*  5600 */     return this.timestamptzInGmt;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public boolean getUse1900AsYearForTime() {
/*  5612 */     return this.use1900AsYearForTime;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized void setDefaultExecuteBatch(int paramInt) throws SQLException {
/*  5659 */     if (paramInt <= 0) {
/*       */       
/*  5661 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 42);
/*  5662 */       sQLException.fillInStackTrace();
/*  5663 */       throw sQLException;
/*       */     } 
/*       */     
/*  5666 */     this.defaultExecuteBatch = paramInt;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized int getDefaultExecuteBatch() {
/*  5699 */     return this.defaultExecuteBatch;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized void setRemarksReporting(boolean paramBoolean) {
/*  5727 */     this.reportRemarks = paramBoolean;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized boolean getRemarksReporting() {
/*  5745 */     return this.reportRemarks;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setIncludeSynonyms(boolean paramBoolean) {
/*  5771 */     this.includeSynonyms = paramBoolean;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized String[] getEndToEndMetrics() throws SQLException {
/*       */     String[] arrayOfString;
/*  5790 */     if (this.endToEndValues == null) {
/*       */       
/*  5792 */       arrayOfString = null;
/*       */     }
/*       */     else {
/*       */       
/*  5796 */       arrayOfString = new String[4];
/*       */       
/*  5798 */       System.arraycopy(this.endToEndValues, 0, arrayOfString, 0, 4);
/*       */     } 
/*  5800 */     return arrayOfString;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public short getEndToEndECIDSequenceNumber() throws SQLException {
/*  5823 */     return this.endToEndECIDSequenceNumber;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized void setEndToEndMetrics(String[] paramArrayOfString, short paramShort) throws SQLException {
/*  5843 */     String[] arrayOfString = new String[paramArrayOfString.length];
/*       */     
/*  5845 */     System.arraycopy(paramArrayOfString, 0, arrayOfString, 0, paramArrayOfString.length);
/*  5846 */     setEndToEndMetricsInternal(arrayOfString, paramShort);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   void setEndToEndMetricsInternal(String[] paramArrayOfString, short paramShort) throws SQLException {
/*  5861 */     if (paramArrayOfString != this.endToEndValues) {
/*  5862 */       if (paramArrayOfString.length != 4) {
/*       */         
/*  5864 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 156);
/*  5865 */         sQLException.fillInStackTrace();
/*  5866 */         throw sQLException;
/*       */       } 
/*       */       
/*       */       byte b;
/*  5870 */       for (b = 0; b < 4; b++) {
/*  5871 */         String str = paramArrayOfString[b];
/*  5872 */         if (str != null && str.length() > this.endToEndMaxLength[b]) {
/*       */           
/*  5874 */           SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 159, str);
/*  5875 */           sQLException.fillInStackTrace();
/*  5876 */           throw sQLException;
/*       */         } 
/*       */       } 
/*       */ 
/*       */       
/*  5881 */       if (this.endToEndValues != null) {
/*  5882 */         for (b = 0; b < 4; b++) {
/*  5883 */           String str = paramArrayOfString[b];
/*       */           
/*  5885 */           if ((str == null && this.endToEndValues[b] != null) || (str != null && !str.equals(this.endToEndValues[b]))) {
/*       */             
/*  5887 */             this.endToEndHasChanged[b] = true;
/*  5888 */             this.endToEndAnyChanged = true;
/*       */           } 
/*       */         } 
/*       */ 
/*       */         
/*  5893 */         this.endToEndHasChanged[0] = this.endToEndHasChanged[0] | this.endToEndHasChanged[3];
/*       */       }
/*       */       else {
/*       */         
/*  5897 */         for (b = 0; b < 4; b++) {
/*  5898 */           this.endToEndHasChanged[b] = true;
/*       */         }
/*  5900 */         this.endToEndAnyChanged = true;
/*       */       } 
/*  5902 */       System.arraycopy(paramArrayOfString, 0, this.endToEndValues, 0, 4);
/*       */       
/*  5904 */       for (b = 0; b < 4; b++) {
/*  5905 */         if (paramArrayOfString[b] == null) { this.clientInfo.remove(END_TO_END_CLIENTINFO_KEYS[b]); }
/*  5906 */         else { this.clientInfo.put(END_TO_END_CLIENTINFO_KEYS[b], paramArrayOfString[b]); }
/*       */       
/*       */       } 
/*       */     } 
/*  5910 */     this.endToEndECIDSequenceNumber = paramShort;
/*  5911 */     this.clientInfo.put("OCSID.SEQUENCE_NUMBER", Short.toString(paramShort));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   void updateSystemContext() throws SQLException {}
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   void resetSystemContext() {}
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   void updateSystemContext11() throws SQLException {}
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public boolean getIncludeSynonyms() {
/*  5975 */     return this.includeSynonyms;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setRestrictGetTables(boolean paramBoolean) {
/*  6021 */     this.restrictGettables = paramBoolean;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public boolean getRestrictGetTables() {
/*  6042 */     return this.restrictGettables;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setDefaultFixedString(boolean paramBoolean) {
/*  6076 */     this.fixedString = paramBoolean;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   void setDefaultNChar(boolean paramBoolean) {
/*  6090 */     this.defaultnchar = paramBoolean;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public boolean getDefaultFixedString() {
/*  6123 */     return this.fixedString;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   int getNlsRatio() {
/*  6136 */     return 1;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public int getC2SNlsRatio() {
/*  6148 */     return 1;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   synchronized void addStatement(OracleStatement paramOracleStatement) {
/*  6157 */     if (paramOracleStatement.next != null) {
/*  6158 */       throw new Error("add_statement called twice on " + paramOracleStatement);
/*       */     }
/*  6160 */     paramOracleStatement.next = this.statements;
/*       */     
/*  6162 */     if (this.statements != null) {
/*  6163 */       this.statements.prev = paramOracleStatement;
/*       */     }
/*  6165 */     this.statements = paramOracleStatement;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   synchronized void removeStatement(OracleStatement paramOracleStatement) {
/*  6184 */     OracleStatement oracleStatement1 = paramOracleStatement.prev;
/*  6185 */     OracleStatement oracleStatement2 = paramOracleStatement.next;
/*       */     
/*  6187 */     if (oracleStatement1 == null) {
/*       */       
/*  6189 */       if (this.statements != paramOracleStatement) {
/*       */         return;
/*       */       }
/*  6192 */       this.statements = oracleStatement2;
/*       */     } else {
/*       */       
/*  6195 */       oracleStatement1.next = oracleStatement2;
/*       */     } 
/*  6197 */     if (oracleStatement2 != null) {
/*  6198 */       oracleStatement2.prev = oracleStatement1;
/*       */     }
/*  6200 */     paramOracleStatement.next = null;
/*  6201 */     paramOracleStatement.prev = null;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   synchronized void closeStatements(boolean paramBoolean) throws SQLException {
/*  6223 */     OracleStatement oracleStatement = this.statements;
/*       */     
/*  6225 */     while (oracleStatement != null) {
/*       */       
/*  6227 */       OracleStatement oracleStatement1 = oracleStatement.nextChild;
/*       */       
/*  6229 */       if (oracleStatement.serverCursor) {
/*       */         
/*  6231 */         oracleStatement.close();
/*  6232 */         removeStatement(oracleStatement);
/*       */       } 
/*       */       
/*  6235 */       oracleStatement = oracleStatement1;
/*       */     } 
/*       */ 
/*       */     
/*  6239 */     oracleStatement = this.statements;
/*       */     
/*  6241 */     while (oracleStatement != null) {
/*       */       
/*  6243 */       OracleStatement oracleStatement1 = oracleStatement.next;
/*       */       
/*  6245 */       if (paramBoolean) {
/*  6246 */         oracleStatement.close();
/*       */       } else {
/*  6248 */         oracleStatement.hardClose();
/*  6249 */         oracleStatement.closeWrapper();
/*  6250 */       }  removeStatement(oracleStatement);
/*       */       
/*  6252 */       oracleStatement = oracleStatement1;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   final void purgeStatementCache() throws SQLException {
/*  6263 */     if (isStatementCacheInitialized()) {
/*       */       
/*  6265 */       this.statementCache.purgeImplicitCache();
/*  6266 */       this.statementCache.purgeExplicitCache();
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   final void closeStatementCache() throws SQLException {
/*  6276 */     if (isStatementCacheInitialized()) {
/*       */ 
/*       */ 
/*       */       
/*  6280 */       this.statementCache.close();
/*       */       
/*  6282 */       this.statementCache = null;
/*  6283 */       this.clearStatementMetaData = true;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   void needLine() throws SQLException {
/*  6292 */     if (this.lifecycle != 1) {
/*       */       
/*  6294 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 8);
/*  6295 */       sQLException.fillInStackTrace();
/*  6296 */       throw sQLException;
/*       */     } 
/*       */     
/*  6299 */     needLineUnchecked();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   synchronized void needLineUnchecked() throws SQLException {
/*  6309 */     if (this.statementHoldingLine != null)
/*       */     {
/*  6311 */       this.statementHoldingLine.freeLine();
/*       */     }
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   synchronized void holdLine(OracleStatement paramOracleStatement) {
/*  6319 */     holdLine((OracleStatement)paramOracleStatement);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   synchronized void holdLine(OracleStatement paramOracleStatement) {
/*  6328 */     this.statementHoldingLine = paramOracleStatement;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   synchronized void releaseLine() {
/*  6336 */     releaseLineForCancel();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   void releaseLineForCancel() {
/*  6345 */     this.statementHoldingLine = null;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized void startup(String paramString, int paramInt) throws SQLException {
/*  6358 */     if (this.lifecycle != 1) {
/*       */       
/*  6360 */       SQLException sQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 8);
/*  6361 */       sQLException1.fillInStackTrace();
/*  6362 */       throw sQLException1;
/*       */     } 
/*       */ 
/*       */     
/*  6366 */     SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException();
/*  6367 */     sQLException.fillInStackTrace();
/*  6368 */     throw sQLException;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized void startup(OracleConnection.DatabaseStartupMode paramDatabaseStartupMode) throws SQLException {
/*  6381 */     if (this.lifecycle != 1) {
/*       */       
/*  6383 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 8);
/*  6384 */       sQLException.fillInStackTrace();
/*  6385 */       throw sQLException;
/*       */     } 
/*  6387 */     if (paramDatabaseStartupMode == null) {
/*       */       
/*  6389 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/*  6390 */       sQLException.fillInStackTrace();
/*  6391 */       throw sQLException;
/*       */     } 
/*       */     
/*  6394 */     needLine();
/*  6395 */     doStartup(paramDatabaseStartupMode.getMode());
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   void doStartup(int paramInt) throws SQLException {
/*  6404 */     SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException();
/*  6405 */     sQLException.fillInStackTrace();
/*  6406 */     throw sQLException;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized void shutdown(OracleConnection.DatabaseShutdownMode paramDatabaseShutdownMode) throws SQLException {
/*  6420 */     if (this.lifecycle != 1) {
/*       */       
/*  6422 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 8);
/*  6423 */       sQLException.fillInStackTrace();
/*  6424 */       throw sQLException;
/*       */     } 
/*  6426 */     if (paramDatabaseShutdownMode == null) {
/*       */       
/*  6428 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/*  6429 */       sQLException.fillInStackTrace();
/*  6430 */       throw sQLException;
/*       */     } 
/*       */     
/*  6433 */     needLine();
/*  6434 */     doShutdown(paramDatabaseShutdownMode.getMode());
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   void doShutdown(int paramInt) throws SQLException {
/*  6443 */     SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException();
/*  6444 */     sQLException.fillInStackTrace();
/*  6445 */     throw sQLException;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized void archive(int paramInt1, int paramInt2, String paramString) throws SQLException {
/*  6461 */     if (this.lifecycle != 1) {
/*       */       
/*  6463 */       SQLException sQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 8);
/*  6464 */       sQLException1.fillInStackTrace();
/*  6465 */       throw sQLException1;
/*       */     } 
/*       */ 
/*       */     
/*  6469 */     SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException();
/*  6470 */     sQLException.fillInStackTrace();
/*  6471 */     throw sQLException;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized void registerSQLType(String paramString1, String paramString2) throws SQLException {
/*  6490 */     if (paramString1 == null || paramString2 == null) {
/*       */       
/*  6492 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/*  6493 */       sQLException.fillInStackTrace();
/*  6494 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */     
/*       */     try {
/*  6499 */       registerSQLType(paramString1, Class.forName(paramString2));
/*       */     }
/*  6501 */     catch (ClassNotFoundException classNotFoundException) {
/*       */ 
/*       */       
/*  6504 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 1, "Class not found: " + paramString2);
/*  6505 */       sQLException.fillInStackTrace();
/*  6506 */       throw sQLException;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized void registerSQLType(String paramString, Class<?> paramClass) throws SQLException {
/*  6522 */     if (paramString == null || paramClass == null) {
/*       */       
/*  6524 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/*  6525 */       sQLException.fillInStackTrace();
/*  6526 */       throw sQLException;
/*       */     } 
/*       */     
/*  6529 */     if (this.map == null) this.map = new Hashtable<>(10);
/*       */     
/*  6531 */     this.map.put(paramString, paramClass);
/*  6532 */     this.map.put(paramClass.getName(), paramString);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized String getSQLType(Object paramObject) throws SQLException {
/*  6545 */     if (paramObject != null && this.map != null) {
/*       */       
/*  6547 */       String str = paramObject.getClass().getName();
/*       */       
/*  6549 */       return (String)this.map.get(str);
/*       */     } 
/*       */     
/*  6552 */     return null;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized Object getJavaObject(String paramString) throws SQLException {
/*  6565 */     Object object = null;
/*       */ 
/*       */     
/*       */     try {
/*  6569 */       if (paramString != null && this.map != null)
/*       */       {
/*  6571 */         Class<Object> clazz = (Class)this.map.get(paramString);
/*       */         
/*  6573 */         object = clazz.newInstance();
/*       */       }
/*       */     
/*  6576 */     } catch (IllegalAccessException illegalAccessException) {
/*       */       
/*  6578 */       illegalAccessException.printStackTrace();
/*       */     }
/*  6580 */     catch (InstantiationException instantiationException) {
/*       */       
/*  6582 */       instantiationException.printStackTrace();
/*       */     } 
/*       */     
/*  6585 */     return object;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized void putDescriptor(String paramString, Object paramObject) throws SQLException {
/*  6598 */     if (paramString != null && paramObject != null) {
/*       */       
/*  6600 */       if (this.descriptorCacheStack[this.dci] == null) {
/*  6601 */         this.descriptorCacheStack[this.dci] = new Hashtable<>(10);
/*       */       }
/*  6603 */       ((TypeDescriptor)paramObject).fixupConnection(this);
/*  6604 */       this.descriptorCacheStack[this.dci].put(paramString, paramObject);
/*       */     }
/*       */     else {
/*       */       
/*  6608 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/*  6609 */       sQLException.fillInStackTrace();
/*  6610 */       throw sQLException;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized Object getDescriptor(String paramString) {
/*  6622 */     Object object = null;
/*       */     
/*  6624 */     if (paramString != null) {
/*  6625 */       if (this.descriptorCacheStack[this.dci] != null)
/*  6626 */         object = this.descriptorCacheStack[this.dci].get(paramString); 
/*  6627 */       if (object == null && this.dci == 1 && this.descriptorCacheStack[0] != null) {
/*  6628 */         object = this.descriptorCacheStack[0].get(paramString);
/*       */       }
/*       */     } 
/*  6631 */     return object;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized void removeDescriptor(String paramString) {
/*  6644 */     if (paramString != null && this.descriptorCacheStack[this.dci] != null)
/*  6645 */       this.descriptorCacheStack[this.dci].remove(paramString); 
/*  6646 */     if (paramString != null && this.dci == 1 && this.descriptorCacheStack[0] != null) {
/*  6647 */       this.descriptorCacheStack[0].remove(paramString);
/*       */     }
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized void removeAllDescriptor() {
/*  6659 */     for (byte b = 0; b <= this.dci; b++) {
/*  6660 */       if (this.descriptorCacheStack[b] != null) {
/*  6661 */         this.descriptorCacheStack[b].clear();
/*       */       }
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public int numberOfDescriptorCacheEntries() {
/*  6678 */     int i = 0;
/*  6679 */     for (byte b = 0; b <= this.dci; b++) {
/*  6680 */       if (this.descriptorCacheStack[b] != null)
/*  6681 */         i += this.descriptorCacheStack[b].size(); 
/*       */     } 
/*  6683 */     return i;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public Enumeration descriptorCacheKeys() {
/*  6696 */     if (this.dci == 0) {
/*  6697 */       if (this.descriptorCacheStack[this.dci] != null) {
/*  6698 */         return this.descriptorCacheStack[this.dci].keys();
/*       */       }
/*  6700 */       return null;
/*       */     } 
/*  6702 */     if (this.descriptorCacheStack[0] == null && this.descriptorCacheStack[1] != null)
/*  6703 */       return this.descriptorCacheStack[1].keys(); 
/*  6704 */     if (this.descriptorCacheStack[1] == null && this.descriptorCacheStack[0] != null)
/*  6705 */       return this.descriptorCacheStack[0].keys(); 
/*  6706 */     if (this.descriptorCacheStack[0] == null && this.descriptorCacheStack[1] == null) {
/*  6707 */       return null;
/*       */     }
/*  6709 */     Vector vector = new Vector(this.descriptorCacheStack[1].keySet());
/*  6710 */     vector.addAll(this.descriptorCacheStack[0].keySet());
/*  6711 */     return vector.elements();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized void putDescriptor(byte[] paramArrayOfbyte, Object paramObject) throws SQLException {
/*  6725 */     if (paramArrayOfbyte != null && paramObject != null) {
/*       */       
/*  6727 */       if (this.descriptorCacheStack[this.dci] == null) {
/*  6728 */         this.descriptorCacheStack[this.dci] = new Hashtable<>(10);
/*       */       }
/*  6730 */       this.descriptorCacheStack[this.dci].put(new ByteArrayKey(paramArrayOfbyte), paramObject);
/*       */     }
/*       */     else {
/*       */       
/*  6734 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/*  6735 */       sQLException.fillInStackTrace();
/*  6736 */       throw sQLException;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized Object getDescriptor(byte[] paramArrayOfbyte) {
/*  6748 */     Object object = null;
/*       */     
/*  6750 */     if (paramArrayOfbyte != null) {
/*  6751 */       ByteArrayKey byteArrayKey = new ByteArrayKey(paramArrayOfbyte);
/*  6752 */       if (this.descriptorCacheStack[this.dci] != null)
/*  6753 */         object = this.descriptorCacheStack[this.dci].get(byteArrayKey); 
/*  6754 */       if (object == null && this.dci == 1 && this.descriptorCacheStack[0] != null) {
/*  6755 */         object = this.descriptorCacheStack[0].get(byteArrayKey);
/*       */       }
/*       */     } 
/*  6758 */     return object;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public short getJdbcCsId() throws SQLException {
/*  6779 */     if (this.conversion == null) {
/*       */ 
/*       */       
/*  6782 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 65);
/*  6783 */       sQLException.fillInStackTrace();
/*  6784 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */     
/*  6788 */     return this.conversion.getClientCharSet();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public short getDbCsId() throws SQLException {
/*  6808 */     if (this.conversion == null) {
/*       */ 
/*       */       
/*  6811 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 65);
/*  6812 */       sQLException.fillInStackTrace();
/*  6813 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */     
/*  6817 */     return this.conversion.getServerCharSetId();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   short getNCsId() throws SQLException {
/*  6824 */     if (this.conversion == null) {
/*       */ 
/*       */       
/*  6827 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 65);
/*  6828 */       sQLException.fillInStackTrace();
/*  6829 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */     
/*  6833 */     return this.conversion.getNCharSetId();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public short getStructAttrCsId() throws SQLException {
/*  6854 */     return getDbCsId();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public short getStructAttrNCsId() throws SQLException {
/*  6866 */     return getNCsId();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized Map getTypeMap() throws SQLException {
/*  6877 */     if (this.map == null) {
/*  6878 */       this.map = new Hashtable<>(10);
/*       */     }
/*  6880 */     return this.map;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized void setTypeMap(Map paramMap) throws SQLException {
/*  6893 */     if (this.lifecycle != 1) {
/*       */       
/*  6895 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 8);
/*  6896 */       sQLException.fillInStackTrace();
/*  6897 */       throw sQLException;
/*       */     } 
/*       */     
/*  6900 */     this.map = paramMap;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized void setUsingXAFlag(boolean paramBoolean) {
/*  6913 */     this.usingXA = paramBoolean;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized boolean getUsingXAFlag() {
/*  6925 */     return this.usingXA;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized void setXAErrorFlag(boolean paramBoolean) {
/*  6938 */     this.xaWantsError = paramBoolean;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized boolean getXAErrorFlag() {
/*  6950 */     return this.xaWantsError;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   String getPropertyFromDatabase(String paramString) throws SQLException {
/*  6958 */     String str = null;
/*  6959 */     Statement statement = null;
/*  6960 */     ResultSet resultSet = null;
/*  6961 */     beginNonRequestCalls();
/*       */     
/*       */     try {
/*  6964 */       statement = createStatement();
/*  6965 */       statement.setFetchSize(1);
/*  6966 */       resultSet = statement.executeQuery(paramString);
/*  6967 */       if (resultSet.next()) {
/*  6968 */         str = resultSet.getString(1);
/*       */       }
/*       */     } finally {
/*       */       
/*  6972 */       if (resultSet != null)
/*  6973 */         resultSet.close(); 
/*  6974 */       if (statement != null) {
/*  6975 */         statement.close();
/*       */       }
/*       */ 
/*       */ 
/*       */       
/*  6980 */       endNonRequestCalls();
/*       */     } 
/*  6982 */     return str;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized String getUserName() throws SQLException {
/*  6995 */     if (this.userName == null) {
/*  6996 */       this.userName = getPropertyFromDatabase("SELECT USER FROM DUAL");
/*       */     }
/*  6998 */     return this.userName;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public String getCurrentSchema() throws SQLException {
/*  7018 */     return getPropertyFromDatabase("SELECT SYS_CONTEXT('USERENV', 'CURRENT_SCHEMA') FROM DUAL");
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public String getDefaultSchemaNameForNamedTypes() throws SQLException {
/*  7041 */     String str = null;
/*       */     
/*  7043 */     if (this.createDescriptorUseCurrentSchemaForSchemaName) {
/*  7044 */       str = getCurrentSchema();
/*       */     } else {
/*  7046 */       str = getUserName();
/*       */     } 
/*  7048 */     return str;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized void setStartTime(long paramLong) throws SQLException {
/*  7071 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 152);
/*  7072 */     sQLException.fillInStackTrace();
/*  7073 */     throw sQLException;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized long getStartTime() throws SQLException {
/*  7089 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 152);
/*  7090 */     sQLException.fillInStackTrace();
/*  7091 */     throw sQLException;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   void registerHeartbeat() throws SQLException {
/*  7104 */     if (this.logicalConnectionAttached != null) {
/*  7105 */       this.logicalConnectionAttached.registerHeartbeat();
/*       */     }
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public int getHeartbeatNoChangeCount() throws SQLException {
/*  7117 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 152);
/*  7118 */     sQLException.fillInStackTrace();
/*  7119 */     throw sQLException;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized byte[] getFDO(boolean paramBoolean) throws SQLException {
/*  7131 */     if (this.fdo == null && paramBoolean) {
/*  7132 */       CallableStatement callableStatement = null;
/*  7133 */       beginNonRequestCalls();
/*       */       try {
/*  7135 */         callableStatement = prepareCall("begin :1 := dbms_pickler.get_format (:2); end;");
/*       */ 
/*       */         
/*  7138 */         callableStatement.registerOutParameter(1, 2);
/*  7139 */         callableStatement.registerOutParameter(2, -4);
/*  7140 */         callableStatement.execute();
/*       */         
/*  7142 */         this.fdo = callableStatement.getBytes(2);
/*       */       } finally {
/*       */         
/*  7145 */         if (callableStatement != null) {
/*  7146 */           callableStatement.close();
/*       */         }
/*  7148 */         callableStatement = null;
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*  7153 */         endNonRequestCalls();
/*       */       } 
/*       */     } 
/*       */     
/*  7157 */     return this.fdo;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized void setFDO(byte[] paramArrayOfbyte) throws SQLException {
/*  7168 */     this.fdo = paramArrayOfbyte;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized boolean getBigEndian() throws SQLException {
/*  7179 */     if (this.bigEndian == null) {
/*       */       
/*  7181 */       int[] arrayOfInt = Util.toJavaUnsignedBytes(getFDO(true));
/*       */ 
/*       */ 
/*       */       
/*  7185 */       int i = arrayOfInt[6 + arrayOfInt[5] + arrayOfInt[6] + 5];
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*  7190 */       int j = (byte)(i & 0x10);
/*       */       
/*  7192 */       if (j < 0) {
/*  7193 */         j = j + 256;
/*       */       }
/*  7195 */       if (j > 0) {
/*  7196 */         this.bigEndian = Boolean.TRUE;
/*       */       } else {
/*  7198 */         this.bigEndian = Boolean.FALSE;
/*       */       } 
/*       */     } 
/*  7201 */     return this.bigEndian.booleanValue();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setHoldability(int paramInt) throws SQLException {
/*  7235 */     if (this.lifecycle != 1) {
/*       */       
/*  7237 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 8);
/*  7238 */       sQLException.fillInStackTrace();
/*  7239 */       throw sQLException;
/*       */     } 
/*       */     
/*  7242 */     if (!getMetaData().supportsResultSetHoldability(paramInt)) {
/*       */       
/*  7244 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 162);
/*  7245 */       sQLException.fillInStackTrace();
/*  7246 */       throw sQLException;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public int getHoldability() throws SQLException {
/*  7279 */     if (this.lifecycle != 1) {
/*       */       
/*  7281 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 8);
/*  7282 */       sQLException.fillInStackTrace();
/*  7283 */       throw sQLException;
/*       */     } 
/*       */     
/*  7286 */     return 1;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized Savepoint setSavepoint() throws SQLException {
/*  7300 */     return (Savepoint)oracleSetSavepoint();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized Savepoint setSavepoint(String paramString) throws SQLException {
/*  7315 */     return (Savepoint)oracleSetSavepoint(paramString);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized void rollback(Savepoint paramSavepoint) throws SQLException {
/*  7331 */     disallowGlobalTxnMode(115);
/*       */ 
/*       */     
/*  7334 */     if (this.autocommit) {
/*       */       
/*  7336 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 121);
/*  7337 */       sQLException.fillInStackTrace();
/*  7338 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */ 
/*       */     
/*  7343 */     if (this.savepointStatement == null)
/*       */     {
/*  7345 */       this.savepointStatement = createStatement();
/*       */     }
/*       */     
/*  7348 */     String str = null;
/*  7349 */     if (paramSavepoint != null) {
/*       */       
/*       */       try {
/*       */         
/*  7353 */         str = paramSavepoint.getSavepointName();
/*       */       }
/*  7355 */       catch (SQLException sQLException) {
/*       */         
/*  7357 */         str = "ORACLE_SVPT_" + paramSavepoint.getSavepointId();
/*       */       } 
/*       */     }
/*       */ 
/*       */     
/*  7362 */     this.savepointStatement.executeUpdate("ROLLBACK TO " + str);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized void releaseSavepoint(Savepoint paramSavepoint) throws SQLException {
/*  7377 */     SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException();
/*  7378 */     sQLException.fillInStackTrace();
/*  7379 */     throw sQLException;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public Statement createStatement(int paramInt1, int paramInt2, int paramInt3) throws SQLException {
/*  7430 */     if (!getMetaData().supportsResultSetHoldability(paramInt3)) {
/*       */       
/*  7432 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 162);
/*  7433 */       sQLException.fillInStackTrace();
/*  7434 */       throw sQLException;
/*       */     } 
/*       */     
/*  7437 */     return createStatement(paramInt1, paramInt2);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public PreparedStatement prepareStatement(String paramString, int paramInt1, int paramInt2, int paramInt3) throws SQLException {
/*  7493 */     if (!getMetaData().supportsResultSetHoldability(paramInt3)) {
/*       */       
/*  7495 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 162);
/*  7496 */       sQLException.fillInStackTrace();
/*  7497 */       throw sQLException;
/*       */     } 
/*       */     
/*  7500 */     return prepareStatement(paramString, paramInt1, paramInt2);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public CallableStatement prepareCall(String paramString, int paramInt1, int paramInt2, int paramInt3) throws SQLException {
/*  7554 */     if (!getMetaData().supportsResultSetHoldability(paramInt3)) {
/*       */       
/*  7556 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 162);
/*  7557 */       sQLException.fillInStackTrace();
/*  7558 */       throw sQLException;
/*       */     } 
/*       */     
/*  7561 */     return prepareCall(paramString, paramInt1, paramInt2);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public PreparedStatement prepareStatement(String paramString, int paramInt) throws SQLException {
/*  7616 */     AutoKeyInfo autoKeyInfo = new AutoKeyInfo(paramString);
/*  7617 */     if (paramInt == 2 || !autoKeyInfo.isInsertSqlStmt())
/*       */     {
/*  7619 */       return prepareStatement(paramString);
/*       */     }
/*  7621 */     if (paramInt != 1) {
/*       */       
/*  7623 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/*  7624 */       sQLException.fillInStackTrace();
/*  7625 */       throw sQLException;
/*       */     } 
/*       */     
/*  7628 */     String str = autoKeyInfo.getNewSql();
/*  7629 */     OraclePreparedStatement oraclePreparedStatement = (OraclePreparedStatement)prepareStatement(str);
/*  7630 */     OraclePreparedStatement oraclePreparedStatement1 = (OraclePreparedStatement)((OraclePreparedStatementWrapper)oraclePreparedStatement).preparedStatement;
/*       */     
/*  7632 */     oraclePreparedStatement1.isAutoGeneratedKey = true;
/*  7633 */     oraclePreparedStatement1.autoKeyInfo = autoKeyInfo;
/*  7634 */     oraclePreparedStatement1.registerReturnParamsForAutoKey();
/*  7635 */     return (PreparedStatement)oraclePreparedStatement;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public PreparedStatement prepareStatement(String paramString, int[] paramArrayOfint) throws SQLException {
/*  7689 */     AutoKeyInfo autoKeyInfo = new AutoKeyInfo(paramString, paramArrayOfint);
/*       */     
/*  7691 */     if (!autoKeyInfo.isInsertSqlStmt()) return prepareStatement(paramString);
/*       */     
/*  7693 */     if (paramArrayOfint == null || paramArrayOfint.length == 0) {
/*       */       
/*  7695 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/*  7696 */       sQLException.fillInStackTrace();
/*  7697 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */ 
/*       */     
/*  7702 */     doDescribeTable(autoKeyInfo);
/*       */     
/*  7704 */     String str = autoKeyInfo.getNewSql();
/*  7705 */     OraclePreparedStatement oraclePreparedStatement = (OraclePreparedStatement)prepareStatement(str);
/*  7706 */     OraclePreparedStatement oraclePreparedStatement1 = (OraclePreparedStatement)((OraclePreparedStatementWrapper)oraclePreparedStatement).preparedStatement;
/*       */     
/*  7708 */     oraclePreparedStatement1.isAutoGeneratedKey = true;
/*  7709 */     oraclePreparedStatement1.autoKeyInfo = autoKeyInfo;
/*  7710 */     oraclePreparedStatement1.registerReturnParamsForAutoKey();
/*  7711 */     return (PreparedStatement)oraclePreparedStatement;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public PreparedStatement prepareStatement(String paramString, String[] paramArrayOfString) throws SQLException {
/*  7766 */     AutoKeyInfo autoKeyInfo = new AutoKeyInfo(paramString, paramArrayOfString);
/*  7767 */     if (!autoKeyInfo.isInsertSqlStmt()) return prepareStatement(paramString);
/*       */     
/*  7769 */     if (paramArrayOfString == null || paramArrayOfString.length == 0) {
/*       */       
/*  7771 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/*  7772 */       sQLException.fillInStackTrace();
/*  7773 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */     
/*  7777 */     doDescribeTable(autoKeyInfo);
/*       */     
/*  7779 */     String str = autoKeyInfo.getNewSql();
/*  7780 */     OraclePreparedStatement oraclePreparedStatement = (OraclePreparedStatement)prepareStatement(str);
/*  7781 */     OraclePreparedStatement oraclePreparedStatement1 = (OraclePreparedStatement)((OraclePreparedStatementWrapper)oraclePreparedStatement).preparedStatement;
/*       */     
/*  7783 */     oraclePreparedStatement1.isAutoGeneratedKey = true;
/*  7784 */     oraclePreparedStatement1.autoKeyInfo = autoKeyInfo;
/*  7785 */     oraclePreparedStatement1.registerReturnParamsForAutoKey();
/*  7786 */     return (PreparedStatement)oraclePreparedStatement;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized OracleSavepoint oracleSetSavepoint() throws SQLException {
/*  7817 */     disallowGlobalTxnMode(117);
/*       */ 
/*       */     
/*  7820 */     if (this.autocommit) {
/*       */       
/*  7822 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 120);
/*  7823 */       sQLException.fillInStackTrace();
/*  7824 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */ 
/*       */     
/*  7829 */     if (this.savepointStatement == null)
/*       */     {
/*  7831 */       this.savepointStatement = createStatement();
/*       */     }
/*       */     
/*  7834 */     OracleSavepoint oracleSavepoint = new OracleSavepoint();
/*       */     
/*  7836 */     String str = "SAVEPOINT ORACLE_SVPT_" + oracleSavepoint.getSavepointId();
/*       */     
/*  7838 */     this.savepointStatement.executeUpdate(str);
/*       */ 
/*       */     
/*  7841 */     return (OracleSavepoint)oracleSavepoint;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized OracleSavepoint oracleSetSavepoint(String paramString) throws SQLException {
/*       */     String str;
/*  7873 */     disallowGlobalTxnMode(117);
/*       */ 
/*       */     
/*  7876 */     if (this.autocommit) {
/*       */       
/*  7878 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 120);
/*  7879 */       sQLException.fillInStackTrace();
/*  7880 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */ 
/*       */     
/*  7885 */     if (this.savepointStatement == null)
/*       */     {
/*  7887 */       this.savepointStatement = createStatement();
/*       */     }
/*       */     
/*  7890 */     OracleSavepoint oracleSavepoint = new OracleSavepoint(paramString);
/*       */     
/*  7892 */     if (oracleSavepoint.getType() == 1) {
/*  7893 */       str = "SAVEPOINT ORACLE_SVPT_" + oracleSavepoint.getSavepointId();
/*       */     } else {
/*  7895 */       str = "SAVEPOINT " + oracleSavepoint.getSavepointName();
/*       */     } 
/*  7897 */     this.savepointStatement.executeUpdate(str);
/*       */ 
/*       */     
/*  7900 */     return (OracleSavepoint)oracleSavepoint;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized void oracleRollback(OracleSavepoint paramOracleSavepoint) throws SQLException {
/*  7933 */     disallowGlobalTxnMode(115);
/*       */ 
/*       */     
/*  7936 */     if (this.autocommit) {
/*       */       
/*  7938 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 121);
/*  7939 */       sQLException.fillInStackTrace();
/*  7940 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */ 
/*       */     
/*  7945 */     if (this.savepointStatement == null)
/*       */     {
/*  7947 */       this.savepointStatement = createStatement();
/*       */     }
/*       */     
/*  7950 */     String str = null;
/*  7951 */     if (paramOracleSavepoint != null) {
/*       */       
/*       */       try {
/*       */         
/*  7955 */         str = paramOracleSavepoint.getSavepointName();
/*       */       }
/*  7957 */       catch (SQLException sQLException) {
/*       */         
/*  7959 */         str = "ORACLE_SVPT_" + paramOracleSavepoint.getSavepointId();
/*       */       } 
/*       */     }
/*       */ 
/*       */     
/*  7964 */     this.savepointStatement.executeUpdate("ROLLBACK TO " + str);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized void oracleReleaseSavepoint(OracleSavepoint paramOracleSavepoint) throws SQLException {
/*  7997 */     SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException();
/*  7998 */     sQLException.fillInStackTrace();
/*  7999 */     throw sQLException;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   void disallowGlobalTxnMode(int paramInt) throws SQLException {
/*  8020 */     if (this.txnMode == 1) {
/*       */       
/*  8022 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), paramInt);
/*  8023 */       sQLException.fillInStackTrace();
/*  8024 */       throw sQLException;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setTxnMode(int paramInt) {
/*  8038 */     this.txnMode = paramInt;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public int getTxnMode() {
/*  8045 */     return this.txnMode;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized Object getClientData(Object paramObject) {
/*  8074 */     if (this.clientData == null)
/*       */     {
/*  8076 */       return null;
/*       */     }
/*       */     
/*  8079 */     return this.clientData.get(paramObject);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized Object setClientData(Object paramObject1, Object paramObject2) {
/*  8106 */     if (this.clientData == null)
/*       */     {
/*  8108 */       this.clientData = new Hashtable<>();
/*       */     }
/*       */     
/*  8111 */     return this.clientData.put(paramObject1, paramObject2);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized Object removeClientData(Object paramObject) {
/*  8132 */     if (this.clientData == null)
/*       */     {
/*  8134 */       return null;
/*       */     }
/*       */     
/*  8137 */     return this.clientData.remove(paramObject);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public BlobDBAccess createBlobDBAccess() throws SQLException {
/*  8145 */     SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException();
/*  8146 */     sQLException.fillInStackTrace();
/*  8147 */     throw sQLException;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public ClobDBAccess createClobDBAccess() throws SQLException {
/*  8156 */     SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException();
/*  8157 */     sQLException.fillInStackTrace();
/*  8158 */     throw sQLException;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public BfileDBAccess createBfileDBAccess() throws SQLException {
/*  8167 */     SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException();
/*  8168 */     sQLException.fillInStackTrace();
/*  8169 */     throw sQLException;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   void printState() {
/*       */     try {
/*  8195 */       short s1 = getJdbcCsId();
/*       */ 
/*       */       
/*  8198 */       short s2 = getDbCsId();
/*       */ 
/*       */       
/*  8201 */       short s3 = getStructAttrCsId();
/*       */     
/*       */     }
/*  8204 */     catch (SQLException sQLException) {
/*       */       
/*  8206 */       sQLException.printStackTrace();
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public String getProtocolType() {
/*  8218 */     return this.protocol;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public String getURL() {
/*  8234 */     return this.url;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized void setStmtCacheSize(int paramInt) throws SQLException {
/*  8253 */     setStatementCacheSize(paramInt);
/*  8254 */     setImplicitCachingEnabled(true);
/*  8255 */     setExplicitCachingEnabled(true);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized void setStmtCacheSize(int paramInt, boolean paramBoolean) throws SQLException {
/*  8275 */     setStatementCacheSize(paramInt);
/*  8276 */     setImplicitCachingEnabled(true);
/*       */ 
/*       */     
/*  8279 */     setExplicitCachingEnabled(true);
/*       */     
/*  8281 */     this.clearStatementMetaData = paramBoolean;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized int getStmtCacheSize() {
/*  8300 */     int i = 0;
/*       */ 
/*       */     
/*       */     try {
/*  8304 */       i = getStatementCacheSize();
/*       */     }
/*  8306 */     catch (SQLException sQLException) {}
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*  8312 */     if (i == -1)
/*       */     {
/*       */ 
/*       */ 
/*       */       
/*  8317 */       i = 0;
/*       */     }
/*       */     
/*  8320 */     return i;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized void setStatementCacheSize(int paramInt) throws SQLException {
/*  8346 */     if (this.statementCache == null) {
/*       */       
/*  8348 */       this.statementCache = new LRUStatementCache(paramInt);
/*       */ 
/*       */     
/*       */     }
/*       */     else {
/*       */ 
/*       */       
/*  8355 */       this.statementCache.resize(paramInt);
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized int getStatementCacheSize() throws SQLException {
/*  8379 */     if (this.statementCache == null) {
/*  8380 */       return -1;
/*       */     }
/*  8382 */     return this.statementCache.getCacheSize();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized void setImplicitCachingEnabled(boolean paramBoolean) throws SQLException {
/*  8410 */     if (this.statementCache == null)
/*       */     {
/*       */ 
/*       */ 
/*       */       
/*  8415 */       this.statementCache = new LRUStatementCache(0);
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*  8422 */     this.statementCache.setImplicitCachingEnabled(paramBoolean);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized boolean getImplicitCachingEnabled() throws SQLException {
/*  8446 */     if (this.statementCache == null) {
/*  8447 */       return false;
/*       */     }
/*  8449 */     return this.statementCache.getImplicitCachingEnabled();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized void setExplicitCachingEnabled(boolean paramBoolean) throws SQLException {
/*  8477 */     if (this.statementCache == null)
/*       */     {
/*       */ 
/*       */ 
/*       */       
/*  8482 */       this.statementCache = new LRUStatementCache(0);
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*  8489 */     this.statementCache.setExplicitCachingEnabled(paramBoolean);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized boolean getExplicitCachingEnabled() throws SQLException {
/*  8513 */     if (this.statementCache == null) {
/*  8514 */       return false;
/*       */     }
/*  8516 */     return this.statementCache.getExplicitCachingEnabled();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized void purgeImplicitCache() throws SQLException {
/*  8540 */     if (this.statementCache != null) {
/*  8541 */       this.statementCache.purgeImplicitCache();
/*       */     }
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized void purgeExplicitCache() throws SQLException {
/*  8565 */     if (this.statementCache != null) {
/*  8566 */       this.statementCache.purgeExplicitCache();
/*       */     }
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized PreparedStatement getStatementWithKey(String paramString) throws SQLException {
/*  8593 */     if (this.statementCache != null) {
/*       */       
/*  8595 */       OracleStatement oracleStatement = this.statementCache.searchExplicitCache(paramString);
/*       */ 
/*       */       
/*  8598 */       if (oracleStatement == null || oracleStatement.statementType == 1) {
/*  8599 */         return (PreparedStatement)oracleStatement;
/*       */       }
/*       */ 
/*       */       
/*  8603 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 125);
/*  8604 */       sQLException.fillInStackTrace();
/*  8605 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */ 
/*       */     
/*  8610 */     return null;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized CallableStatement getCallWithKey(String paramString) throws SQLException {
/*  8637 */     if (this.statementCache != null) {
/*       */       
/*  8639 */       OracleStatement oracleStatement = this.statementCache.searchExplicitCache(paramString);
/*       */ 
/*       */       
/*  8642 */       if (oracleStatement == null || oracleStatement.statementType == 2) {
/*  8643 */         return (CallableStatement)oracleStatement;
/*       */       }
/*       */ 
/*       */       
/*  8647 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 125);
/*  8648 */       sQLException.fillInStackTrace();
/*  8649 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */ 
/*       */     
/*  8654 */     return null;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   synchronized void cacheImplicitStatement(OraclePreparedStatement paramOraclePreparedStatement, String paramString, int paramInt, OracleResultSet.ResultSetType paramResultSetType) throws SQLException {
/*  8670 */     if (this.statementCache == null) {
/*       */       
/*  8672 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 95);
/*  8673 */       sQLException.fillInStackTrace();
/*  8674 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */     
/*  8678 */     this.statementCache.addToImplicitCache(paramOraclePreparedStatement, paramString, paramInt, paramResultSetType.ordinal());
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   synchronized void cacheExplicitStatement(OraclePreparedStatement paramOraclePreparedStatement, String paramString) throws SQLException {
/*  8695 */     if (this.statementCache == null) {
/*       */       
/*  8697 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 95);
/*  8698 */       sQLException.fillInStackTrace();
/*  8699 */       throw sQLException;
/*       */     } 
/*       */     
/*  8702 */     this.statementCache.addToExplicitCache(paramOraclePreparedStatement, paramString);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized boolean isStatementCacheInitialized() {
/*  8717 */     if (this.statementCache == null)
/*  8718 */       return false; 
/*  8719 */     if (this.statementCache.getCacheSize() == 0) {
/*  8720 */       return false;
/*       */     }
/*  8722 */     return true;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   BlockSource getBlockSource() {
/*  8732 */     return this.blockSource;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static final class BufferCacheStore
/*       */   {
/*  8767 */     static int MAX_CACHED_BUFFER_SIZE = Integer.MAX_VALUE;
/*       */     final BufferCache<byte[]> byteBufferCache;
/*       */     final BufferCache<char[]> charBufferCache;
/*       */     
/*       */     BufferCacheStore() {
/*  8772 */       this(MAX_CACHED_BUFFER_SIZE);
/*       */     }
/*       */     
/*       */     BufferCacheStore(int param1Int) {
/*  8776 */       this.byteBufferCache = (BufferCache)new BufferCache<>(param1Int);
/*  8777 */       this.charBufferCache = (BufferCache)new BufferCache<>(param1Int);
/*       */     }
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private BufferCacheStore getBufferCacheStore() {
/*  8788 */     if (this.useThreadLocalBufferCache) {
/*  8789 */       if (threadLocalBufferCacheStore == null) {
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*  8802 */         BufferCacheStore.MAX_CACHED_BUFFER_SIZE = this.maxCachedBufferSize;
/*  8803 */         threadLocalBufferCacheStore = new ThreadLocal<BufferCacheStore>()
/*       */           {
/*       */             protected PhysicalConnection.BufferCacheStore initialValue()
/*       */             {
/*  8807 */               return new PhysicalConnection.BufferCacheStore();
/*       */             }
/*       */           };
/*       */       } 
/*  8811 */       return threadLocalBufferCacheStore.get();
/*       */     } 
/*       */     
/*  8814 */     if (this.connectionBufferCacheStore == null)
/*       */     {
/*  8816 */       this.connectionBufferCacheStore = new BufferCacheStore(this.maxCachedBufferSize);
/*       */     }
/*  8818 */     return this.connectionBufferCacheStore;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   void cacheBuffer(byte[] paramArrayOfbyte) {
/*  8829 */     if (paramArrayOfbyte != null) {
/*  8830 */       BufferCacheStore bufferCacheStore = getBufferCacheStore();
/*  8831 */       bufferCacheStore.byteBufferCache.put(paramArrayOfbyte);
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   void cacheBuffer(char[] paramArrayOfchar) {
/*  8843 */     if (paramArrayOfchar != null) {
/*  8844 */       BufferCacheStore bufferCacheStore = getBufferCacheStore();
/*  8845 */       bufferCacheStore.charBufferCache.put(paramArrayOfchar);
/*       */     } 
/*       */   }
/*       */ 
/*       */   
/*       */   public void cacheBufferSync(char[] paramArrayOfchar) {
/*  8851 */     synchronized (this) {
/*  8852 */       cacheBuffer(paramArrayOfchar);
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   byte[] getByteBuffer(int paramInt) {
/*  8864 */     BufferCacheStore bufferCacheStore = getBufferCacheStore();
/*  8865 */     return bufferCacheStore.byteBufferCache.get(byte.class, paramInt);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   char[] getCharBuffer(int paramInt) {
/*  8877 */     BufferCacheStore bufferCacheStore = getBufferCacheStore();
/*  8878 */     return bufferCacheStore.charBufferCache.get(char.class, paramInt);
/*       */   }
/*       */ 
/*       */   
/*       */   public char[] getCharBufferSync(int paramInt) {
/*  8883 */     synchronized (this) {
/*  8884 */       return getCharBuffer(paramInt);
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public OracleConnection.BufferCacheStatistics getByteBufferCacheStatistics() {
/*  8895 */     BufferCacheStore bufferCacheStore = getBufferCacheStore();
/*  8896 */     return bufferCacheStore.byteBufferCache.getStatistics();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public OracleConnection.BufferCacheStatistics getCharBufferCacheStatistics() {
/*  8907 */     BufferCacheStore bufferCacheStore = getBufferCacheStore();
/*  8908 */     return bufferCacheStore.charBufferCache.getStatistics();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized void registerTAFCallback(OracleOCIFailover paramOracleOCIFailover, Object paramObject) throws SQLException {
/*  8936 */     SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException();
/*  8937 */     sQLException.fillInStackTrace();
/*  8938 */     throw sQLException;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public String getDatabaseProductVersion() throws SQLException {
/*  8956 */     if (this.databaseProductVersion == "") {
/*       */       
/*  8958 */       needLine();
/*       */       
/*  8960 */       this.databaseProductVersion = doGetDatabaseProductVersion();
/*       */     } 
/*       */     
/*  8963 */     return this.databaseProductVersion;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   synchronized boolean getReportRemarks() {
/*  8975 */     return this.reportRemarks;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public short getVersionNumber() throws SQLException {
/*  8987 */     if (this.versionNumber == -1)
/*       */     {
/*  8989 */       synchronized (this) {
/*       */         
/*  8991 */         if (this.versionNumber == -1) {
/*       */           
/*  8993 */           needLine();
/*       */           
/*  8995 */           this.versionNumber = doGetVersionNumber();
/*       */         } 
/*       */       } 
/*       */     }
/*       */     
/*  9000 */     return this.versionNumber;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   synchronized void registerCloseCallback(OracleCloseCallback paramOracleCloseCallback, Object paramObject) {
/*  9013 */     this.closeCallback = paramOracleCloseCallback;
/*  9014 */     this.privateData = paramObject;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setCreateStatementAsRefCursor(boolean paramBoolean) {}
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public boolean getCreateStatementAsRefCursor() {
/*  9072 */     return false;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public int pingDatabase() throws SQLException {
/*  9088 */     if (this.lifecycle != 1)
/*  9089 */       return -1; 
/*  9090 */     return doPingDatabase();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public int pingDatabase(int paramInt) throws SQLException {
/*  9108 */     if (this.lifecycle != 1)
/*  9109 */       return -1; 
/*  9110 */     if (paramInt == 0) {
/*  9111 */       return pingDatabase();
/*       */     }
/*       */     
/*       */     try {
/*  9115 */       this.pingResult = -2;
/*  9116 */       Thread thread = new Thread(new Runnable() {
/*       */             public void run() {
/*       */               try {
/*  9119 */                 PhysicalConnection.this.pingResult = PhysicalConnection.this.doPingDatabase();
/*       */               }
/*  9121 */               catch (Throwable throwable) {}
/*       */             }
/*       */           });
/*  9124 */       thread.start();
/*  9125 */       thread.join((paramInt * 1000));
/*  9126 */       return this.pingResult;
/*       */     }
/*  9128 */     catch (InterruptedException interruptedException) {
/*  9129 */       return -3;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   int doPingDatabase() throws SQLException {
/*  9138 */     Statement statement = null;
/*       */ 
/*       */     
/*       */     try {
/*  9142 */       statement = createStatement();
/*       */       
/*  9144 */       ((OracleStatement)statement).defineColumnType(1, 12, 1);
/*  9145 */       statement.executeQuery("SELECT 'x' FROM DUAL");
/*       */     }
/*  9147 */     catch (SQLException sQLException) {
/*       */       
/*  9149 */       return -1;
/*       */     }
/*       */     finally {
/*       */       
/*  9153 */       if (statement != null) {
/*  9154 */         statement.close();
/*       */       }
/*       */     } 
/*  9157 */     return 0;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized Map getJavaObjectTypeMap() {
/*  9173 */     return this.javaObjectMap;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized void setJavaObjectTypeMap(Map paramMap) {
/*  9183 */     this.javaObjectMap = paramMap;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void clearClientIdentifier(String paramString) throws SQLException {
/*  9203 */     if (paramString != null && paramString.length() != 0) {
/*       */ 
/*       */ 
/*       */       
/*  9207 */       String[] arrayOfString = getEndToEndMetrics();
/*       */       
/*  9209 */       if (arrayOfString != null && paramString.equals(arrayOfString[1])) {
/*       */ 
/*       */         
/*  9212 */         arrayOfString[1] = null;
/*       */         
/*  9214 */         setEndToEndMetrics(arrayOfString, getEndToEndECIDSequenceNumber());
/*       */       } 
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setClientIdentifier(String paramString) throws SQLException {
/*  9241 */     String[] arrayOfString = getEndToEndMetrics();
/*       */     
/*  9243 */     if (arrayOfString == null)
/*       */     {
/*  9245 */       arrayOfString = new String[4];
/*       */     }
/*       */ 
/*       */     
/*  9249 */     arrayOfString[1] = paramString;
/*       */     
/*  9251 */     setEndToEndMetrics(arrayOfString, getEndToEndECIDSequenceNumber());
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   protected PhysicalConnection()
/*       */   {
/*  9263 */     this.sessionTimeZone = null;
/*  9264 */     this.databaseTimeZone = null;
/*  9265 */     this.dbTzCalendar = null;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/* 11519 */     this.clientInfo = new Properties();
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/* 11599 */     this.lastEndToEndSequenceNumber = -1;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/* 13559 */     this.timeZoneVersionNumber = -1;
/* 13560 */     this.timeZoneTab = null;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/* 13787 */     this.closeExecutor = null;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/* 14076 */     this.varTypeMaxLenCompat = 0; this.cancelInProgressLockForThin = new Object(); } PhysicalConnection(String paramString, Properties paramProperties, OracleDriverExtension paramOracleDriverExtension) throws SQLException { this.sessionTimeZone = null; this.databaseTimeZone = null; this.dbTzCalendar = null; this.clientInfo = new Properties(); this.lastEndToEndSequenceNumber = -1; this.timeZoneVersionNumber = -1; this.timeZoneTab = null; this.closeExecutor = null; this.varTypeMaxLenCompat = 0; this.cancelInProgressLockForThin = new Object(); readConnectionProperties(paramString, paramProperties); this.driverExtension = paramOracleDriverExtension; this.blockSource = setBlockSource(); initialize((Hashtable)null, (Map)null, (Map)null); additionalInitialization(); this.logicalConnectionAttached = null; try { needLine(); if (this.drcpConnectionClass != null && this.url.matches("(?i)(.*\\(SERVER=POOLED\\).*)|(.*:POOLED)")) { this.drcpConnectionClass = this.drcpConnectionClass.trim(); this.drcpEnabled = (this.drcpConnectionClass.length() > 0); }  logon(); if (this.drcpEnabled) this.drcpState = DrcpState.STATEFUL;  setAutoCommit(this.autocommit); short s = getVersionNumber(); if (s >= 12100) this.endToEndMaxLength[4] = 64;  if (s >= 11202) { this.endToEndMaxLength[0] = 64; this.endToEndMaxLength[1] = 64; this.endToEndMaxLength[2] = 64; this.endToEndMaxLength[3] = 64; } else if (s >= 11000) { this.endToEndMaxLength[0] = 32; this.endToEndMaxLength[1] = 64; this.endToEndMaxLength[2] = 64; this.endToEndMaxLength[3] = 48; } else if (s >= 10000) { this.endToEndMaxLength[0] = 32; this.endToEndMaxLength[1] = 64; this.endToEndMaxLength[2] = 64; this.endToEndMaxLength[3] = 48; } else { this.endToEndMaxLength[0] = 32; this.endToEndMaxLength[1] = 64; this.endToEndMaxLength[2] = 64; this.endToEndMaxLength[3] = 48; }  if ((((s >= 12000) ? 1 : 0) & ((this.varTypeMaxLenCompat == 2) ? 1 : 0)) != 0) { this.minVcsBindSize = 32766; this.maxRawBytesSql = 32766; this.maxRawBytesPlsql = 32766; this.maxVcsCharsSql = 32766; this.maxVcsNCharsSql = 32766; this.maxVcsBytesPlsql = 32766; this.maxVcsBytesPlsqlOut = 32767; this.maxIbtVarcharElementLength = 32766; this.maxVarcharLength = 32767; this.maxNVarcharLength = 32766; this.maxRawLength = 32767; } else if (s >= 11202) { this.minVcsBindSize = 4001; this.maxRawBytesSql = 4000; this.maxRawBytesPlsql = 32766; this.maxVcsCharsSql = 32766; this.maxVcsNCharsSql = 32766; this.maxVcsBytesPlsql = 32766; this.maxVcsBytesPlsqlOut = 32767; this.maxIbtVarcharElementLength = 32766; this.maxVarcharLength = 4000; this.maxNVarcharLength = 4000; this.maxRawLength = 2000; } else if (s >= 11000) { this.minVcsBindSize = 4001; this.maxRawBytesSql = 4000; this.maxRawBytesPlsql = 32766; this.maxVcsCharsSql = 32766; this.maxVcsNCharsSql = 32766; this.maxVcsBytesPlsql = 32766; this.maxVcsBytesPlsqlOut = 32767; this.maxIbtVarcharElementLength = 32766; this.maxVarcharLength = 4000; this.maxNVarcharLength = 4000; this.maxRawLength = 2000; } else if (s >= 10000) { this.minVcsBindSize = 4001; this.maxRawBytesSql = 4000; this.maxRawBytesPlsql = 32512; this.maxVcsCharsSql = 32766; this.maxVcsNCharsSql = 32766; this.maxVcsBytesPlsql = 32512; this.maxVcsBytesPlsqlOut = 32512; this.maxIbtVarcharElementLength = 32766; this.maxVarcharLength = 4000; this.maxNVarcharLength = 4000; this.maxRawLength = 2000; }  initializeSetCHARCharSetObjs(); if (this.implicitStatementCacheSize > 0) { setStatementCacheSize(this.implicitStatementCacheSize); setImplicitCachingEnabled(true); }  } catch (SQLException sQLException) { this.lifecycle = 2; try { logoff(); } catch (SQLException sQLException1) {} this.lifecycle = 4; throw sQLException; }  this.txnMode = 0; }
/*       */   public void setSessionTimeZone(String paramString) throws SQLException { Statement statement = null; Object object = null; try { statement = createStatement(); statement.executeUpdate("ALTER SESSION SET TIME_ZONE = '" + paramString + "'"); if (this.dbTzCalendar == null) setDbTzCalendar(getDatabaseTimeZone());  } catch (SQLException sQLException) { throw sQLException; } finally { if (statement != null) statement.close();  }  this.sessionTimeZone = paramString; }
/*       */   public String getDatabaseTimeZone() throws SQLException { if (this.databaseTimeZone == null) this.databaseTimeZone = getPropertyFromDatabase("SELECT DBTIMEZONE FROM DUAL");  return this.databaseTimeZone; }
/*       */   public String getSessionTimeZone() { return this.sessionTimeZone; }
/*       */   private static String to2DigitString(int paramInt) { String str; if (paramInt < 10) { str = "0" + paramInt; } else { str = "" + paramInt; }  return str; }
/*       */   String tzToOffset(String paramString) { if (paramString == null) return paramString;  char c = paramString.charAt(0); if (c != '-' && c != '+') { TimeZone timeZone = TimeZone.getTimeZone(paramString); int i = timeZone.getOffset(System.currentTimeMillis()); if (i != 0) { int j = i / 60000; int k = j / 60; j -= k * 60; if (i > 0) { paramString = "+" + to2DigitString(k) + ":" + to2DigitString(j); } else { paramString = "-" + to2DigitString(-k) + ":" + to2DigitString(-j); }  } else { paramString = "+00:00"; }  }  return paramString; }
/*       */   public String getSessionTimeZoneOffset() throws SQLException { String str = getPropertyFromDatabase("SELECT SESSIONTIMEZONE FROM DUAL"); if (str != null) str = tzToOffset(str.trim());  return str; }
/*       */   private void setDbTzCalendar(String paramString) { char c = paramString.charAt(0); if (c == '-' || c == '+') paramString = "GMT" + paramString;  TimeZone timeZone = TimeZone.getTimeZone(paramString); this.dbTzCalendar = new GregorianCalendar(timeZone); }
/*       */   Calendar getDbTzCalendar() throws SQLException { if (this.dbTzCalendar == null) setDbTzCalendar(getDatabaseTimeZone());  Calendar calendar = null; if (this.dbTzCalendar != null) calendar = (Calendar)this.dbTzCalendar.clone();  return calendar; }
/* 14085 */   void setAccumulateBatchResult(boolean paramBoolean) { this.accumulateBatchResult = paramBoolean; } boolean isAccumulateBatchResult() { return this.accumulateBatchResult; } void setJ2EE13Compliant(boolean paramBoolean) { this.j2ee13Compliant = paramBoolean; } boolean getJ2EE13Compliant() { return this.j2ee13Compliant; } public Class classForNameAndSchema(String paramString1, String paramString2) throws ClassNotFoundException { return Class.forName(paramString1); } Class safelyGetClassForName(String paramString) throws ClassNotFoundException { return Class.forName(paramString); } public int getHeapAllocSize() throws SQLException { if (this.lifecycle != 1) { SQLException sQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 8); sQLException1.fillInStackTrace(); throw sQLException1; }  SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException(); sQLException.fillInStackTrace(); throw sQLException; } public int getOCIEnvHeapAllocSize() throws SQLException { if (this.lifecycle != 1) { SQLException sQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 8); sQLException1.fillInStackTrace(); throw sQLException1; }  SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException(); sQLException.fillInStackTrace(); throw sQLException; } static OracleConnection unwrapCompletely(OracleConnection paramOracleConnection) { OracleConnection oracleConnection1 = paramOracleConnection; OracleConnection oracleConnection2 = oracleConnection1; while (true) { if (oracleConnection2 == null) return (OracleConnection)oracleConnection1;  oracleConnection1 = oracleConnection2; oracleConnection2 = oracleConnection1.unwrap(); }  } public void setWrapper(OracleConnection paramOracleConnection) { this.wrapper = paramOracleConnection; } public OracleConnection unwrap() { return null; } public OracleConnection getWrapper() { if (this.wrapper != null) return this.wrapper;  return (OracleConnection)this; } static OracleConnection _physicalConnectionWithin(Connection paramConnection) { OracleConnection oracleConnection = null; if (paramConnection != null) oracleConnection = unwrapCompletely((OracleConnection)paramConnection);  return oracleConnection; } public OracleConnection physicalConnectionWithin() { return this; } public long getTdoCState(String paramString1, String paramString2) throws SQLException { return 0L; } public long getTdoCState(String paramString) throws SQLException { return 0L; } void getOracleTypeADT(OracleTypeADT paramOracleTypeADT) throws SQLException {} public Datum toDatum(CustomDatum paramCustomDatum) throws SQLException { return paramCustomDatum.toDatum(this); } public short getNCharSet() { return this.conversion.getNCharSetId(); } public ResultSet newArrayDataResultSet(Datum[] paramArrayOfDatum, long paramLong, int paramInt, Map paramMap) throws SQLException { return (ResultSet)new ArrayDataResultSet(this, paramArrayOfDatum, paramLong, paramInt, paramMap); } public ResultSet newArrayDataResultSet(ARRAY paramARRAY, long paramLong, int paramInt, Map paramMap) throws SQLException { return (ResultSet)new ArrayDataResultSet(this, paramARRAY, paramLong, paramInt, paramMap); } public ResultSet newArrayLocatorResultSet(ArrayDescriptor paramArrayDescriptor, byte[] paramArrayOfbyte, long paramLong, int paramInt, Map paramMap) throws SQLException { return (ResultSet)ArrayLocatorResultSet.create(this, paramArrayDescriptor, paramArrayOfbyte, paramLong, paramInt, paramMap); } public ResultSetMetaData newStructMetaData(StructDescriptor paramStructDescriptor) throws SQLException { return (ResultSetMetaData)new StructMetaData(paramStructDescriptor); } public int CHARBytesToJavaChars(byte[] paramArrayOfbyte, int paramInt, char[] paramArrayOfchar) throws SQLException { int[] arrayOfInt = new int[1]; arrayOfInt[0] = paramInt; return this.conversion.CHARBytesToJavaChars(paramArrayOfbyte, 0, paramArrayOfchar, 0, arrayOfInt, paramArrayOfchar.length); } public int NCHARBytesToJavaChars(byte[] paramArrayOfbyte, int paramInt, char[] paramArrayOfchar) throws SQLException { int[] arrayOfInt = new int[1]; return this.conversion.NCHARBytesToJavaChars(paramArrayOfbyte, 0, paramArrayOfchar, 0, arrayOfInt, paramArrayOfchar.length); } public boolean IsNCharFixedWith() { return this.conversion.IsNCharFixedWith(); } public short getDriverCharSet() { return this.conversion.getClientCharSet(); } public int getMaxCharSize() throws SQLException { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 58); sQLException.fillInStackTrace(); throw sQLException; } public int getMaxCharbyteSize() { return this.conversion.getMaxCharbyteSize(); } public int getMaxNCharbyteSize() { return this.conversion.getMaxNCharbyteSize(); } public boolean isCharSetMultibyte(short paramShort) { return DBConversion.isCharSetMultibyte(paramShort); } public int javaCharsToCHARBytes(char[] paramArrayOfchar, int paramInt, byte[] paramArrayOfbyte) throws SQLException { return this.conversion.javaCharsToCHARBytes(paramArrayOfchar, paramInt, paramArrayOfbyte); } public int javaCharsToNCHARBytes(char[] paramArrayOfchar, int paramInt, byte[] paramArrayOfbyte) throws SQLException { return this.conversion.javaCharsToNCHARBytes(paramArrayOfchar, paramInt, paramArrayOfbyte); } final void getPropertyForPooledConnection(OraclePooledConnection paramOraclePooledConnection, String paramString) throws SQLException { Hashtable<Object, Object> hashtable = new Hashtable<>(); hashtable.put("obj_type_map", this.javaObjectMap); Properties properties = new Properties(); properties.put("user", this.userName); properties.put("password", paramString); properties.put("connection_url", this.url); properties.put("connect_auto_commit", "" + this.autocommit); properties.put("trans_isolation", "" + this.txnLevel); if (getStatementCacheSize() != -1) { properties.put("stmt_cache_size", "" + getStatementCacheSize()); properties.put("implicit_cache_enabled", "" + getImplicitCachingEnabled()); properties.put("explict_cache_enabled", "" + getExplicitCachingEnabled()); }  properties.put("defaultExecuteBatch", "" + this.defaultExecuteBatch); properties.put("defaultRowPrefetch", "" + this.defaultRowPrefetch); properties.put("remarksReporting", "" + this.reportRemarks); properties.put("AccumulateBatchResult", "" + this.accumulateBatchResult); properties.put("oracle.jdbc.J2EE13Compliant", "" + this.j2ee13Compliant); properties.put("processEscapes", "" + this.processEscapes); properties.put("restrictGetTables", "" + this.restrictGettables); properties.put("includeSynonyms", "" + this.includeSynonyms); properties.put("fixedString", "" + this.fixedString); hashtable.put("connection_properties", properties); paramOraclePooledConnection.setProperties(hashtable); } public Properties getDBAccessProperties() throws SQLException { SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException(); sQLException.fillInStackTrace(); throw sQLException; } public Properties getOCIHandles() throws SQLException { SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException(); sQLException.fillInStackTrace(); throw sQLException; } void logoff() throws SQLException {} int getDefaultStreamChunkSize() { return 32768; } public OracleStatement refCursorCursorToStatement(int paramInt) throws SQLException { SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException(); sQLException.fillInStackTrace(); throw sQLException; } public Connection getLogicalConnection(OraclePooledConnection paramOraclePooledConnection, boolean paramBoolean) throws SQLException { if (this.logicalConnectionAttached != null) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 143); sQLException.fillInStackTrace(); throw sQLException; }  LogicalConnection logicalConnection = new LogicalConnection(paramOraclePooledConnection, this, paramBoolean); this.logicalConnectionAttached = logicalConnection; return (Connection)logicalConnection; } public void getForm(OracleTypeADT paramOracleTypeADT, OracleTypeCLOB paramOracleTypeCLOB, int paramInt) throws SQLException {} public CLOB createClob(byte[] paramArrayOfbyte) throws SQLException { NCLOB nCLOB; CLOB cLOB = new CLOB((OracleConnection)this, paramArrayOfbyte); if (cLOB.isNCLOB()) nCLOB = new NCLOB(cLOB);  return (CLOB)nCLOB; } public CLOB createClobWithUnpickledBytes(byte[] paramArrayOfbyte) throws SQLException { NCLOB nCLOB; CLOB cLOB = new CLOB((OracleConnection)this, paramArrayOfbyte, true); if (cLOB.isNCLOB()) nCLOB = new NCLOB(cLOB);  return (CLOB)nCLOB; } public CLOB createClob(byte[] paramArrayOfbyte, short paramShort) throws SQLException { if (paramShort == 2) return (CLOB)new NCLOB((OracleConnection)this, paramArrayOfbyte);  return new CLOB((OracleConnection)this, paramArrayOfbyte, paramShort); } public BLOB createBlob(byte[] paramArrayOfbyte) throws SQLException { return new BLOB((OracleConnection)this, paramArrayOfbyte); } public BLOB createBlobWithUnpickledBytes(byte[] paramArrayOfbyte) throws SQLException { return new BLOB((OracleConnection)this, paramArrayOfbyte, true); } public BFILE createBfile(byte[] paramArrayOfbyte) throws SQLException { return new BFILE((OracleConnection)this, paramArrayOfbyte); } public ARRAY createARRAY(String paramString, Object paramObject) throws SQLException { ArrayDescriptor arrayDescriptor = ArrayDescriptor.createDescriptor(paramString, (Connection)this); return new ARRAY(arrayDescriptor, (Connection)this, paramObject); } public Array createOracleArray(String paramString, Object paramObject) throws SQLException { return (Array)createARRAY(paramString, paramObject); } public BINARY_DOUBLE createBINARY_DOUBLE(double paramDouble) throws SQLException { return new BINARY_DOUBLE(paramDouble); } public BINARY_FLOAT createBINARY_FLOAT(float paramFloat) throws SQLException { return new BINARY_FLOAT(paramFloat); } public DATE createDATE(Date paramDate) throws SQLException { return new DATE(paramDate); } public DATE createDATE(Time paramTime) throws SQLException { return new DATE(paramTime); } public DATE createDATE(Timestamp paramTimestamp) throws SQLException { return new DATE(paramTimestamp); } public DATE createDATE(Date paramDate, Calendar paramCalendar) throws SQLException { return new DATE(paramDate); } public DATE createDATE(Time paramTime, Calendar paramCalendar) throws SQLException { return new DATE(paramTime); } public DATE createDATE(Timestamp paramTimestamp, Calendar paramCalendar) throws SQLException { return new DATE(paramTimestamp); } public DATE createDATE(String paramString) throws SQLException { return new DATE(paramString); } public INTERVALDS createINTERVALDS(String paramString) throws SQLException { return new INTERVALDS(paramString); } public INTERVALYM createINTERVALYM(String paramString) throws SQLException { return new INTERVALYM(paramString); } public NUMBER createNUMBER(boolean paramBoolean) throws SQLException { return new NUMBER(paramBoolean); } public NUMBER createNUMBER(byte paramByte) throws SQLException { return new NUMBER(paramByte); } public NUMBER createNUMBER(short paramShort) throws SQLException { return new NUMBER(paramShort); } public NUMBER createNUMBER(int paramInt) throws SQLException { return new NUMBER(paramInt); } public NUMBER createNUMBER(long paramLong) throws SQLException { return new NUMBER(paramLong); } public NUMBER createNUMBER(float paramFloat) throws SQLException { return new NUMBER(paramFloat); } public NUMBER createNUMBER(double paramDouble) throws SQLException { return new NUMBER(paramDouble); } public NUMBER createNUMBER(BigDecimal paramBigDecimal) throws SQLException { return new NUMBER(paramBigDecimal); } public NUMBER createNUMBER(BigInteger paramBigInteger) throws SQLException { return new NUMBER(paramBigInteger); } public NUMBER createNUMBER(String paramString, int paramInt) throws SQLException { return new NUMBER(paramString, paramInt); } public Array createArrayOf(String paramString, Object[] paramArrayOfObject) throws SQLException { SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException(); sQLException.fillInStackTrace(); throw sQLException; } public Struct createStruct(String paramString, Object[] paramArrayOfObject) throws SQLException { try { StructDescriptor structDescriptor = StructDescriptor.createDescriptor(paramString, (Connection)this); return (Struct)new STRUCT(structDescriptor, (Connection)this, paramArrayOfObject); } catch (SQLException sQLException) { if (sQLException.getErrorCode() == 17049) removeAllDescriptor();  throw sQLException; }  } public TIMESTAMP createTIMESTAMP(Date paramDate) throws SQLException { return new TIMESTAMP(paramDate); } public TIMESTAMP createTIMESTAMP(DATE paramDATE) throws SQLException { return new TIMESTAMP(paramDATE); } public TIMESTAMP createTIMESTAMP(Time paramTime) throws SQLException { return new TIMESTAMP(paramTime); } public TIMESTAMP createTIMESTAMP(Timestamp paramTimestamp) throws SQLException { return new TIMESTAMP(paramTimestamp); } public TIMESTAMP createTIMESTAMP(String paramString) throws SQLException { return new TIMESTAMP(paramString); } public TIMESTAMPTZ createTIMESTAMPTZ(Date paramDate) throws SQLException { return new TIMESTAMPTZ((Connection)this, paramDate); } public TIMESTAMPTZ createTIMESTAMPTZ(Date paramDate, Calendar paramCalendar) throws SQLException { return new TIMESTAMPTZ((Connection)this, paramDate, paramCalendar); } public TIMESTAMPTZ createTIMESTAMPTZ(Time paramTime) throws SQLException { return new TIMESTAMPTZ((Connection)this, paramTime); } public TIMESTAMPTZ createTIMESTAMPTZ(Time paramTime, Calendar paramCalendar) throws SQLException { return new TIMESTAMPTZ((Connection)this, paramTime, paramCalendar); } public TIMESTAMPTZ createTIMESTAMPTZ(Timestamp paramTimestamp) throws SQLException { return new TIMESTAMPTZ((Connection)this, paramTimestamp); } public TIMESTAMPTZ createTIMESTAMPTZ(Timestamp paramTimestamp, Calendar paramCalendar) throws SQLException { return new TIMESTAMPTZ((Connection)this, paramTimestamp, paramCalendar); } public TIMESTAMPTZ createTIMESTAMPTZ(String paramString) throws SQLException { return new TIMESTAMPTZ((Connection)this, paramString); } public TIMESTAMPTZ createTIMESTAMPTZ(String paramString, Calendar paramCalendar) throws SQLException { return new TIMESTAMPTZ((Connection)this, paramString, paramCalendar); } public TIMESTAMPTZ createTIMESTAMPTZ(DATE paramDATE) throws SQLException { return new TIMESTAMPTZ((Connection)this, paramDATE); } public TIMESTAMPLTZ createTIMESTAMPLTZ(Date paramDate, Calendar paramCalendar) throws SQLException { return new TIMESTAMPLTZ((Connection)this, paramCalendar, paramDate); } public TIMESTAMPLTZ createTIMESTAMPLTZ(Time paramTime, Calendar paramCalendar) throws SQLException { return new TIMESTAMPLTZ((Connection)this, paramCalendar, paramTime); } public TIMESTAMPLTZ createTIMESTAMPLTZ(Timestamp paramTimestamp, Calendar paramCalendar) throws SQLException { return new TIMESTAMPLTZ((Connection)this, paramCalendar, paramTimestamp); } public TIMESTAMPLTZ createTIMESTAMPLTZ(String paramString, Calendar paramCalendar) throws SQLException { return new TIMESTAMPLTZ((Connection)this, paramCalendar, paramString); } public TIMESTAMPLTZ createTIMESTAMPLTZ(DATE paramDATE, Calendar paramCalendar) throws SQLException { return new TIMESTAMPLTZ((Connection)this, paramCalendar, paramDATE); } public Blob createBlob() throws SQLException { if (this.lifecycle != 1) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 8); sQLException.fillInStackTrace(); throw sQLException; }  return (Blob)createTemporaryBlob((Connection)this, true, 10); } public Clob createClob() throws SQLException { if (this.lifecycle != 1) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 8); sQLException.fillInStackTrace(); throw sQLException; }  return (Clob)createTemporaryClob((Connection)this, true, 10, (short)1); } public NClob createNClob() throws SQLException { if (this.lifecycle != 1) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 8); sQLException.fillInStackTrace(); throw sQLException; }  return (NClob)createTemporaryClob((Connection)this, true, 10, (short)2); } public SQLXML createSQLXML() throws SQLException { if (this.lifecycle != 1) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 8); sQLException.fillInStackTrace(); throw sQLException; }  return (SQLXML)new XMLType((Connection)this, (String)null); } public boolean isDescriptorSharable(OracleConnection paramOracleConnection) throws SQLException { PhysicalConnection physicalConnection1 = this; PhysicalConnection physicalConnection2 = (PhysicalConnection)paramOracleConnection.getPhysicalConnection(); return (physicalConnection1 == physicalConnection2 || physicalConnection1.url.equals(physicalConnection2.url) || (physicalConnection2.protocol != null && physicalConnection2.protocol.equals("kprb"))); } boolean useLittleEndianSetCHARBinder() throws SQLException { return false; } public void setPlsqlWarnings(String paramString) throws SQLException { if (paramString == null) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68); sQLException.fillInStackTrace(); throw sQLException; }  if (paramString != null && (paramString = paramString.trim()).length() > 0 && !OracleSql.isValidPlsqlWarning(paramString)) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68); sQLException.fillInStackTrace(); throw sQLException; }  String str1 = "ALTER SESSION SET PLSQL_WARNINGS=" + paramString; String str2 = "ALTER SESSION SET EVENTS='10933 TRACE NAME CONTEXT LEVEL 32768'"; Statement statement = null; try { statement = createStatement(-1, -1); statement.execute(str1); if (paramString.equals("'DISABLE:ALL'")) { this.plsqlCompilerWarnings = false; } else { statement.execute(str2); this.plsqlCompilerWarnings = true; }  } finally { if (statement != null) statement.close();  }  } void internalClose() throws SQLException { this.lifecycle = 4; OracleStatement oracleStatement = this.statements; while (oracleStatement != null) { OracleStatement oracleStatement1 = oracleStatement.nextChild; if (oracleStatement.serverCursor) { oracleStatement.internalClose(); removeStatement(oracleStatement); }  oracleStatement = oracleStatement1; }  oracleStatement = this.statements; while (oracleStatement != null) { OracleStatement oracleStatement1 = oracleStatement.next; oracleStatement.internalClose(); oracleStatement = oracleStatement1; }  this.statements = null; } public XAResource getXAResource() throws SQLException { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 164); sQLException.fillInStackTrace(); throw sQLException; } protected void doDescribeTable(AutoKeyInfo paramAutoKeyInfo) throws SQLException { SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException(); sQLException.fillInStackTrace(); throw sQLException; } static final List<String> RESERVED_NAMESPACES = Arrays.asList(new String[] { "SYS" }); static final Pattern SUPPORTED_NAME_PATTERN = Pattern.compile("\\w+\\.\\w+"); protected final Properties clientInfo; private short lastEndToEndSequenceNumber; static final String RAW_STR = "RAW"; static final String SYS_RAW_STR = "SYS.RAW"; static final String SYS_ANYDATA_STR = "SYS.ANYDATA"; static final String SYS_XMLTYPE_STR = "SYS.XMLTYPE"; public int getVarTypeMaxLenCompat() throws SQLException { return this.varTypeMaxLenCompat; }
/*       */   int timeZoneVersionNumber; TIMEZONETAB timeZoneTab; public void setClientInfo(String paramString1, String paramString2) throws SQLClientInfoException { SecurityManager securityManager = System.getSecurityManager(); if (securityManager != null) { OracleSQLPermission oracleSQLPermission = new OracleSQLPermission("clientInfo." + paramString1); securityManager.checkPermission((Permission)oracleSQLPermission); }  setClientInfoInternal(paramString1, paramString2); } public void setClientInfo(Properties paramProperties) throws SQLClientInfoException { SecurityManager securityManager = System.getSecurityManager(); if (securityManager != null) { OracleSQLPermission oracleSQLPermission = new OracleSQLPermission("clientInfo.*"); securityManager.checkPermission((Permission)oracleSQLPermission); }  this.clientInfo.clear(); HashMap<Object, Object> hashMap = new HashMap<>(); for (String str1 : paramProperties.stringPropertyNames()) { String str2 = paramProperties.getProperty(str1); try { setClientInfoInternal(str1, str2); } catch (SQLClientInfoException sQLClientInfoException) { hashMap.put(str1, ClientInfoStatus.REASON_UNKNOWN_PROPERTY); }  }  if (!hashMap.isEmpty()) { SQLClientInfoException sQLClientInfoException = DatabaseError.createSQLClientInfoException(253, (Map)hashMap, null); sQLClientInfoException.fillInStackTrace(); throw sQLClientInfoException; }  } void setClientInfoInternal(String paramString1, String paramString2) throws SQLClientInfoException { if (!SUPPORTED_NAME_PATTERN.matcher(paramString1).matches()) { SQLClientInfoException sQLClientInfoException = DatabaseError.createSQLClientInfoException(253, null, null); sQLClientInfoException.fillInStackTrace(); throw sQLClientInfoException; }  String[] arrayOfString = paramString1.split("\\.", 2); if (RESERVED_NAMESPACES.contains(arrayOfString[0])) { SQLClientInfoException sQLClientInfoException = DatabaseError.createSQLClientInfoException(276, null, null); sQLClientInfoException.fillInStackTrace(); throw sQLClientInfoException; }  String str1 = arrayOfString[0]; String str2 = arrayOfString[1]; try { if (str1.equals("OCSID")) { if (str2.equals("ACTION")) { if (paramString2 != null && paramString2.length() > this.endToEndMaxLength[0]) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 159, paramString2); sQLException.fillInStackTrace(); throw sQLException; }  if ((paramString2 == null && this.endToEndValues[0] != null) || (paramString2 != null && !paramString2.equals(this.endToEndValues[0]))) { this.endToEndValues[0] = paramString2; this.endToEndHasChanged[0] = true; this.endToEndAnyChanged = true; }  } else if (str2.equals("CLIENTID")) { if (paramString2 != null && paramString2.length() > this.endToEndMaxLength[1]) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 159, paramString2); sQLException.fillInStackTrace(); throw sQLException; }  if ((paramString2 == null && this.endToEndValues[1] != null) || (paramString2 != null && !paramString2.equals(this.endToEndValues[1]))) { this.endToEndValues[1] = paramString2; this.endToEndHasChanged[1] = true; this.endToEndAnyChanged = true; }  } else if (str2.equals("ECID")) { if (paramString2 != null && paramString2.length() > this.endToEndMaxLength[2]) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 159, paramString2); sQLException.fillInStackTrace(); throw sQLException; }  if ((paramString2 == null && this.endToEndValues[2] != null) || (paramString2 != null && !paramString2.equals(this.endToEndValues[2]))) { this.endToEndValues[2] = paramString2; this.endToEndHasChanged[2] = true; this.endToEndAnyChanged = true; }  } else if (str2.equals("MODULE")) { if (paramString2 != null && paramString2.length() > this.endToEndMaxLength[3]) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 159, paramString2); sQLException.fillInStackTrace(); throw sQLException; }  if ((paramString2 == null && this.endToEndValues[3] != null) || (paramString2 != null && !paramString2.equals(this.endToEndValues[3]))) { this.endToEndValues[3] = paramString2; this.endToEndHasChanged[3] = true; this.endToEndHasChanged[0] = true; this.endToEndAnyChanged = true; }  } else if (str2.equals("SEQUENCE_NUMBER")) { short s = 0; if (paramString2 != null) try { s = Short.valueOf(paramString2).shortValue(); } catch (NumberFormatException numberFormatException) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 160, paramString2); sQLException.fillInStackTrace(); throw sQLException; }   this.endToEndECIDSequenceNumber = s; this.endToEndAnyChanged = true; } else if (str2.equals("DBOP")) { if (paramString2 != null && paramString2.length() > this.endToEndMaxLength[4]) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 159, paramString2); sQLException.fillInStackTrace(); throw sQLException; }  if ((paramString2 == null && this.endToEndValues[4] != null) || (paramString2 != null && !paramString2.equals(this.endToEndValues[4]))) { this.endToEndValues[4] = paramString2; this.endToEndHasChanged[4] = true; this.endToEndAnyChanged = true; }  } else { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 253, "OCSID." + str2); sQLException.fillInStackTrace(); throw sQLException; }  } else { if (str2.length() > 30) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 171); sQLException.fillInStackTrace(); throw sQLException; }  if (paramString2 != null && paramString2.length() > 4000) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 172); sQLException.fillInStackTrace(); throw sQLException; }  doSetApplicationContext(str1, str2, (paramString2 == null) ? "" : paramString2); }  if (paramString2 == null) { this.clientInfo.remove(paramString1); } else { this.clientInfo.put(paramString1, paramString2); }  } catch (SQLException sQLException) { SQLClientInfoException sQLClientInfoException = DatabaseError.createSQLClientInfoException(1, null, sQLException); sQLClientInfoException.fillInStackTrace(); throw sQLClientInfoException; }  } public String getClientInfo(String paramString) throws SQLException { if (isClosed()) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 8); sQLException.fillInStackTrace(); throw sQLException; }  if (paramString == null) return null;  if (!SUPPORTED_NAME_PATTERN.matcher(paramString).matches()) { SQLClientInfoException sQLClientInfoException = DatabaseError.createSQLClientInfoException(253, null, null); sQLClientInfoException.fillInStackTrace(); throw sQLClientInfoException; }  return this.clientInfo.getProperty(paramString); } public Properties getClientInfo() throws SQLException { if (isClosed()) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 8); sQLException.fillInStackTrace(); throw sQLException; }  return (Properties)this.clientInfo.clone(); } public void setApplicationContext(String paramString1, String paramString2, String paramString3) throws SQLException { if (paramString2 == null) throw new NullPointerException();  if (paramString1 == null || paramString1.equals("")) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 170); sQLException.fillInStackTrace(); throw sQLException; }  setClientInfoInternal(paramString1 + "." + paramString2, paramString3); } void doSetApplicationContext(String paramString1, String paramString2, String paramString3) throws SQLException { SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException(); sQLException.fillInStackTrace(); throw sQLException; } public void clearAllApplicationContext(String paramString) throws SQLException { if (paramString == null) throw new NullPointerException();  if (paramString.equals("")) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 170); sQLException.fillInStackTrace(); throw sQLException; }  doClearAllApplicationContext(paramString); if (!paramString.equals("OCSID")) for (String str : this.clientInfo.stringPropertyNames()) { if (str.startsWith(paramString + ".")) this.clientInfo.remove(str);  }   } void doClearAllApplicationContext(String paramString) throws SQLException { SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException(); sQLException.fillInStackTrace(); throw sQLException; } public byte[] createLightweightSession(String paramString, KeywordValueLong[] paramArrayOfKeywordValueLong, int paramInt, KeywordValueLong[][] paramArrayOfKeywordValueLong1, int[] paramArrayOfint) throws SQLException { SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException(); sQLException.fillInStackTrace(); throw sQLException; } void executeLightweightSessionRoundtrip(int paramInt1, byte[] paramArrayOfbyte, KeywordValueLong[] paramArrayOfKeywordValueLong, int paramInt2, KeywordValueLong[][] paramArrayOfKeywordValueLong1, int[] paramArrayOfint) throws SQLException { SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException(); sQLException.fillInStackTrace(); throw sQLException; } public void executeLightweightSessionPiggyback(int paramInt1, byte[] paramArrayOfbyte, KeywordValueLong[] paramArrayOfKeywordValueLong, int paramInt2) throws SQLException { SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException(); sQLException.fillInStackTrace(); throw sQLException; } public void doXSNamespaceOp(OracleConnection.XSOperationCode paramXSOperationCode, byte[] paramArrayOfbyte, XSNamespace[] paramArrayOfXSNamespace, XSNamespace[][] paramArrayOfXSNamespace1, XSSecureId paramXSSecureId) throws SQLException { SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException(); sQLException.fillInStackTrace(); throw sQLException; } public void doXSNamespaceOp(OracleConnection.XSOperationCode paramXSOperationCode, byte[] paramArrayOfbyte, XSNamespace[] paramArrayOfXSNamespace, XSSecureId paramXSSecureId) throws SQLException { SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException(); sQLException.fillInStackTrace(); throw sQLException; } public byte[] doXSSessionCreateOp(OracleConnection.XSSessionOperationCode paramXSSessionOperationCode, XSSecureId paramXSSecureId, byte[] paramArrayOfbyte, XSPrincipal paramXSPrincipal, String paramString, XSNamespace[] paramArrayOfXSNamespace, OracleConnection.XSSessionModeFlag paramXSSessionModeFlag, XSKeyval paramXSKeyval) throws SQLException { SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException(); sQLException.fillInStackTrace(); throw sQLException; } public void doXSSessionDestroyOp(byte[] paramArrayOfbyte1, XSSecureId paramXSSecureId, byte[] paramArrayOfbyte2) throws SQLException { SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException(); sQLException.fillInStackTrace(); throw sQLException; } public void doXSSessionDetachOp(int paramInt, byte[] paramArrayOfbyte, XSSecureId paramXSSecureId, boolean paramBoolean) throws SQLException { SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException(); sQLException.fillInStackTrace(); throw sQLException; } public void doXSSessionChangeOp(OracleConnection.XSSessionSetOperationCode paramXSSessionSetOperationCode, byte[] paramArrayOfbyte, XSSecureId paramXSSecureId, XSSessionParameters paramXSSessionParameters) throws SQLException { SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException(); sQLException.fillInStackTrace(); throw sQLException; } public void doXSSessionAttachOp(int paramInt1, byte[] paramArrayOfbyte1, XSSecureId paramXSSecureId, byte[] paramArrayOfbyte2, XSPrincipal paramXSPrincipal, String[] paramArrayOfString1, String[] paramArrayOfString2, String[] paramArrayOfString3, XSNamespace[] paramArrayOfXSNamespace1, XSNamespace[] paramArrayOfXSNamespace2, XSNamespace[] paramArrayOfXSNamespace3, TIMESTAMPTZ paramTIMESTAMPTZ1, TIMESTAMPTZ paramTIMESTAMPTZ2, int paramInt2, long paramLong, XSKeyval paramXSKeyval, int[] paramArrayOfint) throws SQLException { SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException(); sQLException.fillInStackTrace(); throw sQLException; } public void enqueue(String paramString, AQEnqueueOptions paramAQEnqueueOptions, AQMessage paramAQMessage) throws SQLException { AQMessageI aQMessageI = (AQMessageI)paramAQMessage; byte[][] arrayOfByte = new byte[1][]; doEnqueue(paramString, paramAQEnqueueOptions, aQMessageI.getMessagePropertiesI(), aQMessageI.getPayloadTOID(), aQMessageI.getPayload(), arrayOfByte, aQMessageI.isRAWPayload()); if (arrayOfByte[0] != null) aQMessageI.setMessageId(arrayOfByte[0]);  } public AQMessage dequeue(String paramString, AQDequeueOptions paramAQDequeueOptions, byte[] paramArrayOfbyte) throws SQLException { byte[][] arrayOfByte1 = new byte[1][]; AQMessagePropertiesI aQMessagePropertiesI = new AQMessagePropertiesI(); byte[][] arrayOfByte2 = new byte[1][]; boolean bool = false; bool = doDequeue(paramString, paramAQDequeueOptions, aQMessagePropertiesI, paramArrayOfbyte, arrayOfByte2, arrayOfByte1, AQMessageI.compareToid(paramArrayOfbyte, TypeDescriptor.RAWTOID)); AQMessageI aQMessageI = null; if (bool) { aQMessageI = new AQMessageI(aQMessagePropertiesI, (Connection)this); aQMessageI.setPayload(arrayOfByte2[0], paramArrayOfbyte); aQMessageI.setMessageId(arrayOfByte1[0]); }  return aQMessageI; } public AQMessage dequeue(String paramString1, AQDequeueOptions paramAQDequeueOptions, String paramString2) throws SQLException { byte[] arrayOfByte = null; TypeDescriptor typeDescriptor = null; if ("RAW".equals(paramString2) || "SYS.RAW".equals(paramString2)) { arrayOfByte = TypeDescriptor.RAWTOID; } else if ("SYS.ANYDATA".equals(paramString2)) { arrayOfByte = TypeDescriptor.ANYDATATOID; } else if ("SYS.XMLTYPE".equals(paramString2)) { arrayOfByte = TypeDescriptor.XMLTYPETOID; } else { typeDescriptor = TypeDescriptor.getTypeDescriptor(paramString2, (OracleConnection)this); arrayOfByte = ((OracleTypeADT)typeDescriptor.getPickler()).getTOID(); }  AQMessageI aQMessageI = (AQMessageI)dequeue(paramString1, paramAQDequeueOptions, arrayOfByte); if (aQMessageI != null) { aQMessageI.setTypeName(paramString2); aQMessageI.setTypeDescriptor(typeDescriptor); }  return aQMessageI; } synchronized void doEnqueue(String paramString, AQEnqueueOptions paramAQEnqueueOptions, AQMessagePropertiesI paramAQMessagePropertiesI, byte[] paramArrayOfbyte1, byte[] paramArrayOfbyte2, byte[][] paramArrayOfbyte, boolean paramBoolean) throws SQLException { SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException(); sQLException.fillInStackTrace(); throw sQLException; } synchronized boolean doDequeue(String paramString, AQDequeueOptions paramAQDequeueOptions, AQMessagePropertiesI paramAQMessagePropertiesI, byte[] paramArrayOfbyte, byte[][] paramArrayOfbyte1, byte[][] paramArrayOfbyte2, boolean paramBoolean) throws SQLException { SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException(); sQLException.fillInStackTrace(); throw sQLException; } public void jmsEnqueue(String paramString, JMSEnqueueOptions paramJMSEnqueueOptions, JMSMessage paramJMSMessage, AQMessageProperties paramAQMessageProperties) throws SQLException { byte[][] arrayOfByte = new byte[1][]; AQMessagePropertiesI aQMessagePropertiesI = (AQMessagePropertiesI)paramAQMessageProperties; doJMSEnqueue(paramString, paramJMSEnqueueOptions, aQMessagePropertiesI, paramJMSMessage.getJMSMessageProperties(), paramJMSMessage.getToid(), paramJMSMessage.getPayload(), arrayOfByte); if (arrayOfByte[0] != null) paramJMSMessage.setMessageId(arrayOfByte[0]);  } synchronized void doJMSEnqueue(String paramString, JMSEnqueueOptions paramJMSEnqueueOptions, AQMessagePropertiesI paramAQMessagePropertiesI, JMSMessageProperties paramJMSMessageProperties, byte[] paramArrayOfbyte1, byte[] paramArrayOfbyte2, byte[][] paramArrayOfbyte) throws SQLException {} public JMSMessage jmsDequeue(String paramString1, JMSDequeueOptions paramJMSDequeueOptions, String paramString2) throws SQLException { return jmsDequeue(paramString1, paramJMSDequeueOptions); } public JMSMessage jmsDequeue(String paramString, JMSDequeueOptions paramJMSDequeueOptions) throws SQLException { byte[] arrayOfByte = TypeDescriptor.RAWTOID; byte[][] arrayOfByte1 = new byte[1][]; AQMessagePropertiesI aQMessagePropertiesI = new AQMessagePropertiesI(); JMSMessagePropertiesI jMSMessagePropertiesI = new JMSMessagePropertiesI(); byte[][] arrayOfByte2 = new byte[1][]; boolean bool = false; bool = doJmsDequeue(paramString, paramJMSDequeueOptions, aQMessagePropertiesI, jMSMessagePropertiesI, arrayOfByte, arrayOfByte2, arrayOfByte1); JMSMessage jMSMessage = null; if (bool) { jMSMessage = JMSFactory.createJMSMessage(jMSMessagePropertiesI); jMSMessage.setPayload(arrayOfByte2[0]); jMSMessage.setMessageId(arrayOfByte1[0]); jMSMessage.setJMSMessageProperties(jMSMessagePropertiesI); jMSMessage.setAQMessageProperties(aQMessagePropertiesI); }  return jMSMessage; } synchronized boolean doJmsDequeue(String paramString, JMSDequeueOptions paramJMSDequeueOptions, AQMessagePropertiesI paramAQMessagePropertiesI, JMSMessagePropertiesI paramJMSMessagePropertiesI, byte[] paramArrayOfbyte, byte[][] paramArrayOfbyte1, byte[][] paramArrayOfbyte2) throws SQLException { return true; } public boolean isV8Compatible() throws SQLException { return this.mapDateToTimestamp; } public boolean getMapDateToTimestamp() { return this.mapDateToTimestamp; } public byte getInstanceProperty(OracleConnection.InstanceProperty paramInstanceProperty) throws SQLException { SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException(); sQLException.fillInStackTrace(); throw sQLException; } public Map<String, JMSNotificationRegistration> registerJMSNotification(String[] paramArrayOfString, Map<String, Properties> paramMap) throws SQLException { if (paramArrayOfString == null || paramMap == null) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68, "name and options cannot be null"); sQLException.fillInStackTrace(); throw sQLException; }  return doRegisterJMSNotification(paramArrayOfString, paramMap); } Map<String, JMSNotificationRegistration> doRegisterJMSNotification(String[] paramArrayOfString, Map<String, Properties> paramMap) throws SQLException { SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException(); sQLException.fillInStackTrace(); throw sQLException; } public void unregisterJMSNotification(JMSNotificationRegistration paramJMSNotificationRegistration) throws SQLException { if (paramJMSNotificationRegistration == null) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68, "registration cannot be null"); sQLException.fillInStackTrace(); throw sQLException; }  NTFJMSRegistration nTFJMSRegistration = (NTFJMSRegistration)paramJMSNotificationRegistration; doUnregisterJMSNotification(nTFJMSRegistration); } void doUnregisterJMSNotification(NTFJMSRegistration paramNTFJMSRegistration) throws SQLException { SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException(); sQLException.fillInStackTrace(); throw sQLException; } public void ackJMSNotification(JMSNotificationRegistration paramJMSNotificationRegistration, byte[] paramArrayOfbyte, JMSNotificationRegistration.Directive paramDirective) throws SQLException { if (paramDirective == null || paramJMSNotificationRegistration == null || paramArrayOfbyte == null) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68, "directive,registration or lastMessageID cannot be null"); sQLException.fillInStackTrace(); throw sQLException; }  short s = paramDirective.getCode(); doAckJMSNtfn((NTFJMSRegistration)paramJMSNotificationRegistration, paramArrayOfbyte, s); } void doAckJMSNtfn(NTFJMSRegistration paramNTFJMSRegistration, byte[] paramArrayOfbyte, short paramShort) throws SQLException { SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException(); sQLException.fillInStackTrace(); throw sQLException; } public AQNotificationRegistration[] registerAQNotification(String[] paramArrayOfString, Properties[] paramArrayOfProperties, Properties paramProperties) throws SQLException { String str = readNTFlocalhost(paramProperties); int i = readNTFtcpport(paramProperties); NTFAQRegistration[] arrayOfNTFAQRegistration = doRegisterAQNotification(paramArrayOfString, str, i, paramArrayOfProperties); return (AQNotificationRegistration[])arrayOfNTFAQRegistration; } NTFAQRegistration[] doRegisterAQNotification(String[] paramArrayOfString, String paramString, int paramInt, Properties[] paramArrayOfProperties) throws SQLException { SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException(); sQLException.fillInStackTrace(); throw sQLException; } public void unregisterAQNotification(AQNotificationRegistration paramAQNotificationRegistration) throws SQLException { NTFAQRegistration nTFAQRegistration = (NTFAQRegistration)paramAQNotificationRegistration; doUnregisterAQNotification(nTFAQRegistration); } void doUnregisterAQNotification(NTFAQRegistration paramNTFAQRegistration) throws SQLException { SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException(); sQLException.fillInStackTrace(); throw sQLException; } private String readNTFlocalhost(Properties paramProperties) throws SQLException { String str = null; try { str = paramProperties.getProperty("NTF_LOCAL_HOST", InetAddress.getLocalHost().getHostAddress()); } catch (UnknownHostException unknownHostException) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 240); sQLException.fillInStackTrace(); throw sQLException; } catch (SecurityException securityException) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 241); sQLException.fillInStackTrace(); throw sQLException; }  return str; } private int readNTFtcpport(Properties paramProperties) throws SQLException { int i = 0; try { i = Integer.parseInt(paramProperties.getProperty("NTF_LOCAL_TCP_PORT", "0")); if (i < 0) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 242); sQLException.fillInStackTrace(); throw sQLException; }  } catch (NumberFormatException numberFormatException) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 242); sQLException.fillInStackTrace(); throw sQLException; }  return i; } int readNTFtimeout(Properties paramProperties) throws SQLException { int i = 0; try { i = Integer.parseInt(paramProperties.getProperty("NTF_TIMEOUT", "0")); } catch (NumberFormatException numberFormatException) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 243); sQLException.fillInStackTrace(); throw sQLException; }  return i; } public DatabaseChangeRegistration registerDatabaseChangeNotification(Properties paramProperties) throws SQLException { String str = readNTFlocalhost(paramProperties); int i = readNTFtcpport(paramProperties); int j = readNTFtimeout(paramProperties); int k = 0; try { k = Integer.parseInt(paramProperties.getProperty("DCN_NOTIFY_CHANGELAG", "0")); } catch (NumberFormatException numberFormatException) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 244); sQLException.fillInStackTrace(); throw sQLException; }  NTFDCNRegistration nTFDCNRegistration = doRegisterDatabaseChangeNotification(str, i, paramProperties, j, k); ntfManager.addRegistration(nTFDCNRegistration); return nTFDCNRegistration; } NTFDCNRegistration doRegisterDatabaseChangeNotification(String paramString, int paramInt1, Properties paramProperties, int paramInt2, int paramInt3) throws SQLException { SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException(); sQLException.fillInStackTrace(); throw sQLException; } public DatabaseChangeRegistration getDatabaseChangeRegistration(int paramInt) throws SQLException { return new NTFDCNRegistration(this.dbName, paramInt, this.userName, this.versionNumber); } public void unregisterDatabaseChangeNotification(DatabaseChangeRegistration paramDatabaseChangeRegistration) throws SQLException { NTFDCNRegistration nTFDCNRegistration = (NTFDCNRegistration)paramDatabaseChangeRegistration; if (nTFDCNRegistration.getDatabaseName().compareToIgnoreCase(this.dbName) != 0) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 245); sQLException.fillInStackTrace(); throw sQLException; }  doUnregisterDatabaseChangeNotification(nTFDCNRegistration); } void doUnregisterDatabaseChangeNotification(NTFDCNRegistration paramNTFDCNRegistration) throws SQLException { SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException(); sQLException.fillInStackTrace(); throw sQLException; } public void unregisterDatabaseChangeNotification(int paramInt) throws SQLException { String str = null; try { str = InetAddress.getLocalHost().getHostAddress(); } catch (Exception exception) {} unregisterDatabaseChangeNotification(paramInt, str, 47632); } public void unregisterDatabaseChangeNotification(int paramInt1, String paramString, int paramInt2) throws SQLException { String str = "(ADDRESS=(PROTOCOL=tcp)(HOST=" + paramString + ")(PORT=" + paramInt2 + "))?PR=0"; unregisterDatabaseChangeNotification(paramInt1, str); } public void unregisterDatabaseChangeNotification(long paramLong, String paramString) throws SQLException { doUnregisterDatabaseChangeNotification(paramLong, paramString); } void doUnregisterDatabaseChangeNotification(long paramLong, String paramString) throws SQLException { SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException(); sQLException.fillInStackTrace(); throw sQLException; } public void addXSEventListener(XSEventListener paramXSEventListener) throws SQLException { SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException(); sQLException.fillInStackTrace(); throw sQLException; } public void addXSEventListener(XSEventListener paramXSEventListener, Executor paramExecutor) throws SQLException { SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException(); sQLException.fillInStackTrace(); throw sQLException; } public void removeXSEventListener(XSEventListener paramXSEventListener) throws SQLException { SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException(); sQLException.fillInStackTrace(); throw sQLException; } public void removeAllXSEventListener() throws SQLException { SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException(); sQLException.fillInStackTrace(); throw sQLException; } public void setPDBChangeEventListener(PDBChangeEventListener paramPDBChangeEventListener) throws SQLException { SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException(); sQLException.fillInStackTrace(); throw sQLException; } public void setPDBChangeEventListener(PDBChangeEventListener paramPDBChangeEventListener, Executor paramExecutor) throws SQLException { SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException(); sQLException.fillInStackTrace(); throw sQLException; } public void addLogicalTransactionIdEventListener(LogicalTransactionIdEventListener paramLogicalTransactionIdEventListener) throws SQLException { SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException(); sQLException.fillInStackTrace(); throw sQLException; } public void addLogicalTransactionIdEventListener(LogicalTransactionIdEventListener paramLogicalTransactionIdEventListener, Executor paramExecutor) throws SQLException { SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException(); sQLException.fillInStackTrace(); throw sQLException; } public void removeLogicalTransactionIdEventListener(LogicalTransactionIdEventListener paramLogicalTransactionIdEventListener) throws SQLException { SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException(); sQLException.fillInStackTrace(); throw sQLException; } public LogicalTransactionId getLogicalTransactionId() throws SQLException { SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException(); sQLException.fillInStackTrace(); throw sQLException; } public TypeDescriptor[] getAllTypeDescriptorsInCurrentSchema() throws SQLException { TypeDescriptor[] arrayOfTypeDescriptor = null; Statement statement = null; beginNonRequestCalls(); try { statement = createStatement(); ResultSet resultSet = statement.executeQuery("SELECT schema_name, typename, typoid, typecode, version, tds  FROM TABLE(private_jdbc.Get_Type_Shape_Info())"); arrayOfTypeDescriptor = getTypeDescriptorsFromResultSet(resultSet); resultSet.close(); } catch (SQLException sQLException) { if (sQLException.getErrorCode() == 904) { SQLException sQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 165); sQLException1.fillInStackTrace(); throw sQLException1; }  throw sQLException; } finally { if (statement != null) statement.close();  endNonRequestCalls(); }  return arrayOfTypeDescriptor; } public TypeDescriptor[] getTypeDescriptorsFromListInCurrentSchema(String[] paramArrayOfString) throws SQLException { String str = "SELECT schema_name, typename, typoid, typecode, version, tds  FROM TABLE(private_jdbc.Get_Type_Shape_Info(?))"; TypeDescriptor[] arrayOfTypeDescriptor = null; PreparedStatement preparedStatement = null; beginNonRequestCalls(); try { preparedStatement = prepareStatement(str); int i = paramArrayOfString.length; StringBuffer stringBuffer = new StringBuffer(i * 8); for (byte b = 0; b < i; b++) { stringBuffer.append(paramArrayOfString[b]); if (b < i - 1) stringBuffer.append(',');  }  preparedStatement.setString(1, stringBuffer.toString()); ResultSet resultSet = preparedStatement.executeQuery(); arrayOfTypeDescriptor = getTypeDescriptorsFromResultSet(resultSet); resultSet.close(); } catch (SQLException sQLException) { if (sQLException.getErrorCode() == 904) { SQLException sQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 165); sQLException1.fillInStackTrace(); throw sQLException1; }  throw sQLException; } finally { if (preparedStatement != null) preparedStatement.close();  endNonRequestCalls(); }  return arrayOfTypeDescriptor; } public TypeDescriptor[] getTypeDescriptorsFromList(String[][] paramArrayOfString) throws SQLException { TypeDescriptor[] arrayOfTypeDescriptor = null; PreparedStatement preparedStatement = null; int i = paramArrayOfString.length; StringBuffer stringBuffer1 = new StringBuffer(i * 8); StringBuffer stringBuffer2 = new StringBuffer(i * 8); for (byte b = 0; b < i; b++) { stringBuffer1.append(paramArrayOfString[b][0]); stringBuffer2.append(paramArrayOfString[b][1]); if (b < i - 1) { stringBuffer1.append(','); stringBuffer2.append(','); }  }  beginNonRequestCalls(); try { String str = "SELECT schema_name, typename, typoid, typecode, version, tds FROM TABLE(private_jdbc.Get_All_Type_Shape_Info(?,?))"; preparedStatement = prepareStatement(str); preparedStatement.setString(1, stringBuffer1.toString()); preparedStatement.setString(2, stringBuffer2.toString()); ResultSet resultSet = preparedStatement.executeQuery(); arrayOfTypeDescriptor = getTypeDescriptorsFromResultSet(resultSet); resultSet.close(); } catch (SQLException sQLException) { if (sQLException.getErrorCode() == 904) { SQLException sQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 165); sQLException1.fillInStackTrace(); throw sQLException1; }  throw sQLException; } finally { if (preparedStatement != null) preparedStatement.close();  endNonRequestCalls(); }  return arrayOfTypeDescriptor; } TypeDescriptor[] getTypeDescriptorsFromResultSet(ResultSet paramResultSet) throws SQLException { ArrayList<StructDescriptor> arrayList = new ArrayList(); while (paramResultSet.next()) { String str1 = paramResultSet.getString(1); String str2 = paramResultSet.getString(2); byte[] arrayOfByte1 = paramResultSet.getBytes(3); String str3 = paramResultSet.getString(4); int i = paramResultSet.getInt(5); byte[] arrayOfByte2 = paramResultSet.getBytes(6); SQLName sQLName = new SQLName(str1, str2, (OracleConnection)this); if (str3.equals("OBJECT")) { StructDescriptor structDescriptor = StructDescriptor.createDescriptor(sQLName, arrayOfByte1, i, arrayOfByte2, this); putDescriptor(arrayOfByte1, structDescriptor); putDescriptor(structDescriptor.getName(), structDescriptor); arrayList.add(structDescriptor); continue; }  if (str3.equals("COLLECTION")) { ArrayDescriptor arrayDescriptor = ArrayDescriptor.createDescriptor(sQLName, arrayOfByte1, i, arrayOfByte2, this); putDescriptor(arrayOfByte1, arrayDescriptor); putDescriptor(arrayDescriptor.getName(), arrayDescriptor); arrayList.add(arrayDescriptor); }  }  TypeDescriptor[] arrayOfTypeDescriptor = new TypeDescriptor[arrayList.size()]; for (byte b = 0; b < arrayList.size(); b++) { TypeDescriptor typeDescriptor = (TypeDescriptor)arrayList.get(b); arrayOfTypeDescriptor[b] = typeDescriptor; }  return arrayOfTypeDescriptor; } public synchronized boolean isUsable() { return this.isUsable; } public void setUsable(boolean paramBoolean) { this.isUsable = paramBoolean; } void queryFCFProperties(Properties paramProperties) throws SQLException { Statement statement = null; ResultSet resultSet = null; String str = "select sys_context('userenv', 'instance_name'),sys_context('userenv', 'server_host'),sys_context('userenv', 'service_name'),sys_context('userenv', 'db_unique_name') from dual"; try { statement = createStatement(); statement.setFetchSize(1); resultSet = statement.executeQuery(str); while (resultSet.next()) { String str1 = null; str1 = resultSet.getString(1); if (str1 != null) paramProperties.put("INSTANCE_NAME", str1.trim());  str1 = resultSet.getString(2); if (str1 != null) paramProperties.put("SERVER_HOST", str1.trim());  str1 = resultSet.getString(3); if (str1 != null) paramProperties.put("SERVICE_NAME", str1.trim());  str1 = resultSet.getString(4); if (str1 != null) paramProperties.put("DATABASE_NAME", str1.trim());  }  } finally { if (resultSet != null) resultSet.close();  if (statement != null) statement.close();  }  } public void setDefaultTimeZone(TimeZone paramTimeZone) throws SQLException { this.defaultTimeZone = paramTimeZone; } public TimeZone getDefaultTimeZone() throws SQLException { return this.defaultTimeZone; } public int getTimezoneVersionNumber() throws SQLException { return this.timeZoneVersionNumber; } public TIMEZONETAB getTIMEZONETAB() throws SQLException { if (this.timeZoneTab == null) this.timeZoneTab = TIMEZONETAB.getInstance(getTimezoneVersionNumber());  return this.timeZoneTab; } public boolean isDataInLocatorEnabled() throws SQLException { return ((getVersionNumber() >= 10200)) & ((getVersionNumber() < 11000)) & this.enableReadDataInLocator | this.overrideEnableReadDataInLocator; } public boolean isLobStreamPosStandardCompliant() throws SQLException { return this.lobStreamPosStandardCompliant; } public long getCurrentSCN() throws SQLException { return doGetCurrentSCN(); } long doGetCurrentSCN() throws SQLException { SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException(); sQLException.fillInStackTrace(); throw sQLException; } void doSetSnapshotSCN(long paramLong) throws SQLException { SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException(); sQLException.fillInStackTrace(); throw sQLException; } public EnumSet<OracleConnection.TransactionState> getTransactionState() throws SQLException { return doGetTransactionState(); } EnumSet<OracleConnection.TransactionState> doGetTransactionState() throws SQLException { SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException(); sQLException.fillInStackTrace(); throw sQLException; } public boolean isConnectionSocketKeepAlive() throws SocketException, SQLException { SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException(); sQLException.fillInStackTrace(); throw sQLException; } public void setReplayOperations(EnumSet<OracleConnection.ReplayOperation> paramEnumSet) throws SQLException { SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException(); sQLException.fillInStackTrace(); throw sQLException; } public void beginNonRequestCalls() throws SQLException {} public void endNonRequestCalls() throws SQLException {} public void setReplayContext(ReplayContext[] paramArrayOfReplayContext) throws SQLException { SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException(); sQLException.fillInStackTrace(); throw sQLException; } public void setReplayingMode(boolean paramBoolean) throws SQLException { SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException(); sQLException.fillInStackTrace(); throw sQLException; } public void registerEndReplayCallback(OracleConnection.EndReplayCallback paramEndReplayCallback) throws SQLException { SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException(); sQLException.fillInStackTrace(); throw sQLException; } public int getEOC() throws SQLException { SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException(); sQLException.fillInStackTrace(); throw sQLException; } public ReplayContext[] getReplayContext() throws SQLException { SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException(); sQLException.fillInStackTrace(); throw sQLException; } public ReplayContext getLastReplayContext() throws SQLException { SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException(); sQLException.fillInStackTrace(); throw sQLException; } public byte[] getDerivedKeyInternal(byte[] paramArrayOfbyte, int paramInt) throws NoSuchAlgorithmException, InvalidKeySpecException, SQLException { SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException(); sQLException.fillInStackTrace(); throw sQLException; } private static final SQLPermission CALL_ABORT_PERMISSION = new SQLPermission("callAbort"); public void abort(Executor paramExecutor) throws SQLException { SecurityManager securityManager = System.getSecurityManager(); if (securityManager != null) securityManager.checkPermission(CALL_ABORT_PERMISSION);  final PhysicalConnection conn = this; paramExecutor.execute(new Runnable() {
/*       */           public void run() { try { if (conn.lifecycle == 4 || conn.lifecycle == 8) return;  conn.lifecycle = 8; conn.doAbort(); conn.close(); } catch (Exception exception) {  } finally { PhysicalConnection.this.lifecycle = 4; }  }
/*       */         }); } public String getSchema() throws SQLException { return getCurrentSchema(); } private static final SQLPermission CALL_SETNETWORKTIMEOUT_PERMISSION = new SQLPermission("setNetworkTimeout"); private Executor closeExecutor; int varTypeMaxLenCompat; public final void setNetworkTimeout(Executor paramExecutor, int paramInt) throws SQLException { SecurityManager securityManager = System.getSecurityManager(); if (securityManager != null) securityManager.checkPermission(CALL_SETNETWORKTIMEOUT_PERMISSION);  if (paramInt < 0) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 285); sQLException.fillInStackTrace(); throw sQLException; }  if (paramInt > 0 && paramExecutor == null) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 284); sQLException.fillInStackTrace(); throw sQLException; }  this.closeExecutor = (paramInt == 0) ? null : paramExecutor; doSetNetworkTimeout(paramInt); } public int getNetworkTimeout() throws SQLException { SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException(); sQLException.fillInStackTrace(); throw sQLException; } protected void doSetNetworkTimeout(int paramInt) throws SQLException { SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException(); sQLException.fillInStackTrace(); throw sQLException; } void doAsynchronousClose() { if (this.closeExecutor != null) { final PhysicalConnection pc = this; this.closeExecutor.execute(new Runnable() {
/*       */             public void run() { try { pc.close(); } catch (Throwable throwable) {} }
/* 14090 */           }); }  } public void setSchema(String paramString) throws SQLException { String str1 = "\"[^\000\"]{0,28}\""; String str2 = "(\\p{javaLowerCase}|\\p{javaUpperCase})(\\p{javaLowerCase}|\\p{javaUpperCase}|\\d|_|$|#){0,29}"; String str3 = "(" + str1 + ")|(" + str2 + ")"; if (paramString == null) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68); sQLException.fillInStackTrace(); throw sQLException; }  if (!paramString.matches(str3)) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68); sQLException.fillInStackTrace(); throw sQLException; }  String str4 = "alter session set current_schema = " + paramString; Statement statement = null; try { statement = createStatement(); statement.execute(str4); } finally { if (statement != null) statement.close();  }  } void releaseConnectionToPool() throws SQLException { SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException(); sQLException.fillInStackTrace(); throw sQLException; } boolean reusePooledConnection() throws SQLException { SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException(); sQLException.fillInStackTrace(); throw sQLException; } void resetAfterReusePooledConnection() throws SQLException { if (needToPurgeStatementCache()) purgeStatementCache();  } public boolean attachServerConnection() throws SQLException { if (this.lifecycle != 1) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 8); sQLException.fillInStackTrace(); throw sQLException; }  if (!this.drcpEnabled) return true;  return reusePooledConnection(); } public boolean isDRCPEnabled() throws SQLException { return this.drcpEnabled; } public void detachServerConnection(String paramString) throws SQLException { if (this.lifecycle != 1) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 8); sQLException.fillInStackTrace(); throw sQLException; }  if (!this.drcpEnabled) return;  this.drcpTagName = paramString; purgeStatementCache(); closeStatements(false); releaseConnectionToPool(); } public boolean needToPurgeStatementCache() throws SQLException { SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException(); sQLException.fillInStackTrace(); throw sQLException; } public short getExecutingRPCFunctionCode() { return 0; } public String getExecutingRPCSQL() { return ""; } public int getNegotiatedSDU() throws SQLException { SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException(); sQLException.fillInStackTrace(); throw sQLException; } public void setChecksumMode(OracleConnection.ChecksumMode paramChecksumMode) throws SQLException { this.checksumMode = paramChecksumMode; } static final boolean bit(long paramLong1, long paramLong2) { return ((paramLong1 & paramLong2) == paramLong2); }
/*       */ 
/*       */   
/*       */   static final boolean bit(int paramInt1, int paramInt2) {
/* 14094 */     return ((paramInt1 & paramInt2) == paramInt2);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   void onPDBChange() throws SQLException {
/* 14106 */     removeAllDescriptor();
/*       */     
/* 14108 */     if (isStatementCacheInitialized()) {
/* 14109 */       this.statementCache.purgeExplicitCache();
/* 14110 */       this.statementCache.purgeImplicitCache();
/*       */     } 
/*       */   }
/*       */ 
/*       */   
/* 14115 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*       */   public static final String BUILD_DATE = "Thu_Apr_04_15:09:24_PDT_2013";
/*       */   public static final boolean TRACE = false;
/*       */   
/*       */   abstract void initializePassword(String paramString) throws SQLException;
/*       */   
/*       */   abstract void doAbort() throws SQLException;
/*       */   
/*       */   public abstract void getPropertyForPooledConnection(OraclePooledConnection paramOraclePooledConnection) throws SQLException;
/*       */   
/*       */   abstract void logon() throws SQLException;
/*       */   
/*       */   abstract void open(OracleStatement paramOracleStatement) throws SQLException;
/*       */   
/*       */   abstract void cancelOperationOnServer(boolean paramBoolean) throws SQLException;
/*       */   
/*       */   abstract void doSetAutoCommit(boolean paramBoolean) throws SQLException;
/*       */   
/*       */   abstract void doCommit(int paramInt) throws SQLException;
/*       */   
/*       */   abstract void doRollback() throws SQLException;
/*       */   
/*       */   abstract String doGetDatabaseProductVersion() throws SQLException;
/*       */   
/*       */   abstract short doGetVersionNumber() throws SQLException;
/*       */   
/*       */   abstract OracleStatement RefCursorBytesToStatement(byte[] paramArrayOfbyte, OracleStatement paramOracleStatement) throws SQLException;
/*       */   
/*       */   abstract OracleStatement createImplicitResultSetStatement(OracleStatement paramOracleStatement) throws SQLException;
/*       */   
/*       */   public abstract BLOB createTemporaryBlob(Connection paramConnection, boolean paramBoolean, int paramInt) throws SQLException;
/*       */   
/*       */   public abstract CLOB createTemporaryClob(Connection paramConnection, boolean paramBoolean, int paramInt, short paramShort) throws SQLException;
/*       */ }


/* Location:              C:\Users\olatu\OneDrive\Documents\Calypso\syncbase\sync_base.jar!\BOOT-INF\lib\ojdbc-7.jar!\oracle\jdbc\driver\PhysicalConnection.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */