package oracle.jdbc.driver;

import java.io.IOException;
import java.sql.SQLException;

interface T4CAccessor {
  void processIndicator(int paramInt) throws SQLException, IOException;
  
  void unmarshalColumnMetadata() throws SQLException, IOException;
  
  T4CMAREngine getMAREngine();
}


/* Location:              C:\Users\olatu\OneDrive\Documents\Calypso\syncbase\sync_base.jar!\BOOT-INF\lib\ojdbc-7.jar!\oracle\jdbc\driver\T4CAccessor.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */