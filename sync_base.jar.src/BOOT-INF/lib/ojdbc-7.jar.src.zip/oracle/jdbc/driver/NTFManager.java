/*     */ package oracle.jdbc.driver;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.net.BindException;
/*     */ import java.net.InetSocketAddress;
/*     */ import java.net.ServerSocket;
/*     */ import java.nio.channels.ServerSocketChannel;
/*     */ import java.sql.SQLException;
/*     */ import java.util.Enumeration;
/*     */ import java.util.HashMap;
/*     */ import java.util.Hashtable;
/*     */ import oracle.jdbc.internal.OracleConnection;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class NTFManager
/*     */ {
/*  63 */   private Hashtable<Integer, NTFListener> nsListeners = new Hashtable<>();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  68 */   private Hashtable<Integer, NTFRegistration> ntfRegistrations = new Hashtable<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  78 */   private byte[] listOfJdbcRegId = new byte[20];
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  88 */   private HashMap<String, NTFJMSPerDatabaseManager> jmsPerDatabaseManagers = new HashMap<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   synchronized boolean listenOnPortT4C(int[] paramArrayOfint, boolean paramBoolean) throws SQLException {
/* 121 */     int i = paramArrayOfint[0];
/* 122 */     boolean bool = false;
/*     */ 
/*     */ 
/*     */     
/* 126 */     while (this.nsListeners.get(Integer.valueOf(i)) == null) {
/*     */ 
/*     */       
/*     */       try {
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 134 */         ServerSocketChannel serverSocketChannel = ServerSocketChannel.open();
/* 135 */         serverSocketChannel.configureBlocking(false);
/*     */         
/* 137 */         ServerSocket serverSocket = serverSocketChannel.socket();
/*     */         
/* 139 */         InetSocketAddress inetSocketAddress = new InetSocketAddress(i);
/*     */ 
/*     */         
/*     */         try {
/* 143 */           serverSocket.bind(inetSocketAddress);
/*     */           
/* 145 */           bool = true;
/* 146 */           NTFListener nTFListener = new NTFListener(this, serverSocketChannel, i);
/* 147 */           this.nsListeners.put(Integer.valueOf(i), nTFListener);
/* 148 */           nTFListener.start();
/*     */           
/*     */           break;
/* 151 */         } catch (BindException bindException) {
/*     */           
/* 153 */           if (!paramBoolean) {
/*     */             
/* 155 */             SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 250);
/* 156 */             sQLException.fillInStackTrace();
/* 157 */             throw sQLException;
/*     */           } 
/*     */           
/* 160 */           i++;
/*     */         }
/* 162 */         catch (IOException iOException) {
/*     */           
/* 164 */           if (!paramBoolean) {
/*     */             
/* 166 */             SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 250);
/* 167 */             sQLException.fillInStackTrace();
/* 168 */             throw sQLException;
/*     */           } 
/*     */           
/* 171 */           i++;
/*     */         }
/*     */       
/* 174 */       } catch (IOException iOException) {
/*     */ 
/*     */         
/* 177 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException);
/* 178 */         sQLException.fillInStackTrace();
/* 179 */         throw sQLException;
/*     */       } 
/*     */     } 
/*     */     
/* 183 */     paramArrayOfint[0] = i;
/* 184 */     return bool;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   synchronized int getNextJdbcRegId() {
/* 195 */     byte b = 1;
/* 196 */     for (; b < this.listOfJdbcRegId.length; b++) {
/*     */       
/* 198 */       if (this.listOfJdbcRegId[b] == 0)
/*     */         break; 
/*     */     } 
/* 201 */     if (b == this.listOfJdbcRegId.length - 1) {
/*     */       
/* 203 */       byte[] arrayOfByte = new byte[this.listOfJdbcRegId.length * 2];
/* 204 */       System.arraycopy(this.listOfJdbcRegId, 0, arrayOfByte, 0, this.listOfJdbcRegId.length);
/* 205 */       this.listOfJdbcRegId = arrayOfByte;
/*     */     } 
/* 207 */     this.listOfJdbcRegId[b] = 2;
/* 208 */     return b;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   synchronized void addRegistration(NTFRegistration paramNTFRegistration) {
/* 218 */     Integer integer = Integer.valueOf(paramNTFRegistration.getJdbcRegId());
/* 219 */     Hashtable<Integer, NTFRegistration> hashtable = (Hashtable)this.ntfRegistrations.clone();
/* 220 */     hashtable.put(integer, paramNTFRegistration);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 227 */     this.ntfRegistrations = hashtable;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   synchronized boolean removeRegistration(NTFRegistration paramNTFRegistration) {
/* 239 */     Integer integer = Integer.valueOf(paramNTFRegistration.getJdbcRegId());
/* 240 */     Hashtable<Integer, NTFRegistration> hashtable = (Hashtable)this.ntfRegistrations.clone();
/* 241 */     Object object = hashtable.remove(integer);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 248 */     this.ntfRegistrations = hashtable;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 253 */     boolean bool = false;
/*     */     
/* 255 */     if (object != null)
/* 256 */       bool = true; 
/* 257 */     return bool;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   synchronized void freeJdbcRegId(int paramInt) {
/* 265 */     if (this.listOfJdbcRegId != null && this.listOfJdbcRegId.length > paramInt) {
/* 266 */       this.listOfJdbcRegId[paramInt] = 0;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   synchronized void cleanListenersT4C(int paramInt) {
/* 285 */     Enumeration<Integer> enumeration = this.ntfRegistrations.keys();
/* 286 */     boolean bool = false;
/* 287 */     while (!bool && enumeration.hasMoreElements()) {
/*     */       
/* 289 */       Object object = enumeration.nextElement();
/* 290 */       NTFRegistration nTFRegistration = this.ntfRegistrations.get(object);
/* 291 */       if (nTFRegistration.getClientTCPPort() == paramInt)
/* 292 */         bool = true; 
/*     */     } 
/* 294 */     if (!bool) {
/*     */       
/* 296 */       NTFListener nTFListener = this.nsListeners.get(Integer.valueOf(paramInt));
/* 297 */       if (nTFListener != null) {
/*     */         
/* 299 */         nTFListener.closeThisListener();
/* 300 */         nTFListener.interrupt();
/* 301 */         this.nsListeners.remove(Integer.valueOf(paramInt));
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   NTFRegistration getRegistration(int paramInt) {
/* 317 */     Integer integer = Integer.valueOf(paramInt);
/*     */     
/* 319 */     Hashtable<Integer, NTFRegistration> hashtable = this.ntfRegistrations;
/* 320 */     return hashtable.get(integer);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected OracleConnection getConnectionDuringExceptionHandling() {
/* 336 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   synchronized NTFJMSPerDatabaseManager getJMSPerDatabaseManager(String paramString) {
/* 342 */     NTFJMSPerDatabaseManager nTFJMSPerDatabaseManager = this.jmsPerDatabaseManagers.get(paramString);
/* 343 */     if (nTFJMSPerDatabaseManager == null) {
/* 344 */       nTFJMSPerDatabaseManager = new NTFJMSPerDatabaseManager(paramString);
/*     */     }
/* 346 */     this.jmsPerDatabaseManagers.put(paramString, nTFJMSPerDatabaseManager);
/* 347 */     return nTFJMSPerDatabaseManager;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   synchronized void removeJMSUtility(String paramString) {
/* 353 */     this.jmsPerDatabaseManagers.remove(paramString);
/*     */   }
/*     */ 
/*     */   
/* 357 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*     */   public static final String BUILD_DATE = "Thu_Apr_04_15:09:24_PDT_2013";
/*     */   public static final boolean TRACE = false;
/*     */ }


/* Location:              C:\Users\olatu\OneDrive\Documents\Calypso\syncbase\sync_base.jar!\BOOT-INF\lib\ojdbc-7.jar!\oracle\jdbc\driver\NTFManager.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */