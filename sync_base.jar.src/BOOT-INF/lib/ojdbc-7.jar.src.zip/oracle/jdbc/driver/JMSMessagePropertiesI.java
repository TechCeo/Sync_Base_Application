/*     */ package oracle.jdbc.driver;
/*     */ 
/*     */ import oracle.jdbc.internal.JMSMessageProperties;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class JMSMessagePropertiesI
/*     */   implements JMSMessageProperties
/*     */ {
/*  47 */   private String headerProperties = "0";
/*  48 */   private String userProperties = "0";
/*  49 */   private JMSMessageProperties.JMSMessageType jmsMessageType = JMSMessageProperties.JMSMessageType.TEXT_MESSAGE;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getHeaderProperties() {
/*  60 */     return this.headerProperties;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setHeaderProperties(String paramString) {
/*  72 */     this.headerProperties = paramString;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getUserProperties() {
/*  84 */     return this.userProperties;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setUserProperties(String paramString) {
/*  96 */     this.userProperties = paramString;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JMSMessageProperties.JMSMessageType getJMSMessageType() {
/* 108 */     return this.jmsMessageType;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setJMSMessageType(JMSMessageProperties.JMSMessageType paramJMSMessageType) {
/* 120 */     this.jmsMessageType = paramJMSMessageType;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/* 125 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*     */   public static final String BUILD_DATE = "Thu_Apr_04_15:09:24_PDT_2013";
/*     */   public static final boolean TRACE = false;
/*     */ }


/* Location:              C:\Users\olatu\OneDrive\Documents\Calypso\syncbase\sync_base.jar!\BOOT-INF\lib\ojdbc-7.jar!\oracle\jdbc\driver\JMSMessagePropertiesI.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */