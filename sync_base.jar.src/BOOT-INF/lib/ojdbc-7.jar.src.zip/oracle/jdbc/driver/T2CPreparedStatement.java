/*      */ package oracle.jdbc.driver;
/*      */ 
/*      */ import java.io.IOException;
/*      */ import java.nio.ByteBuffer;
/*      */ import java.nio.ByteOrder;
/*      */ import java.nio.CharBuffer;
/*      */ import java.nio.ShortBuffer;
/*      */ import java.sql.Connection;
/*      */ import java.sql.SQLException;
/*      */ import java.util.ArrayDeque;
/*      */ import oracle.jdbc.internal.OracleStatement;
/*      */ import oracle.jdbc.oracore.OracleType;
/*      */ import oracle.jdbc.oracore.OracleTypeADT;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ class T2CPreparedStatement
/*      */   extends OraclePreparedStatement
/*      */ {
/*   45 */   T2CConnection t2cConnection = null;
/*   46 */   int userResultSetType = -1;
/*   47 */   int userResultSetConcur = -1;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*   53 */   static int T2C_EXTEND_BUFFER = -3;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*   69 */   long[] t2cOutput = new long[10]; static final int T2C_OUTPUT_USE_NIO = 5; static final int T2C_OUTPUT_STMT_LOB_PREFETCH_SIZE = 6; static final int T2C_OUTPUT_USE_OCI_DEFAULT_DEFINE_OFFSET = 7; static final boolean T2CDEBUG = false; int extractedCharOffset; int extractedByteOffset; int savedRowPrefetch; static final byte T2C_LOB_PREFETCH_SIZE_THIS_COLUMN_OFFSET = 0; static final byte T2C_LOB_PREFETCH_LOB_LENGTH_OFFSET = 1; static final byte T2C_LOB_PREFETCH_FORM_OFFSET = 2; static final byte T2C_LOB_PREFETCH_CHUNK_OFFSET = 3; static final byte T2C_LOB_PREFETCH_DATA_OFFSET = 4; byte[] lobPrefetchTempBytes; boolean needToRetainRows; byte[] returnParamBytes; char[] returnParamChars; short[] returnParamIndicators; int returnParamRowBytes; int returnParamRowChars; int getPrefetchInternal(boolean paramBoolean) { if (!this.t2cConnection.useOCIDefaultDefines)
/*      */       return super.getPrefetchInternal(paramBoolean);  return paramBoolean ? this.defaultRowPrefetch : this.savedRowPrefetch; }
/*      */   void setPrefetchInternal(int paramInt, boolean paramBoolean1, boolean paramBoolean2) throws SQLException { int i = this.rowPrefetch; super.setPrefetchInternal(paramInt, paramBoolean1, paramBoolean2); if (this.t2cConnection.useOCIDefaultDefines && i != this.rowPrefetch) { this.savedRowPrefetch = this.rowPrefetch; this.rowPrefetch = 1; }  }
/*      */   void prepareForNewResults(boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3) throws SQLException { super.prepareForNewResults(paramBoolean1, paramBoolean2, paramBoolean3); if (this.t2cConnection.useOCIDefaultDefines && this.rowPrefetchChanged) { this.savedRowPrefetch = this.rowPrefetch; this.rowPrefetch = 1; }  }
/*      */   void prepareAccessors() throws SQLException { super.prepareAccessors(); if (this.t2cConnection.useOCIDefaultDefines && this.hasStream)
/*      */       this.savedRowPrefetch = 1;  }
/*      */   String bytes2String(byte[] paramArrayOfbyte, int paramInt1, int paramInt2) throws SQLException { byte[] arrayOfByte = new byte[paramInt2]; System.arraycopy(paramArrayOfbyte, paramInt1, arrayOfByte, 0, paramInt2); return this.connection.conversion.CharBytesToString(arrayOfByte, paramInt2); }
/*      */   void processDescribeData() throws SQLException { this.described = true; this.describedWithNames = true; if (this.numberOfDefinePositions < 1)
/*      */       return;  if (this.accessors == null || this.numberOfDefinePositions > this.accessors.length)
/*      */       this.accessors = new Accessor[this.numberOfDefinePositions];  int i = this.t2cConnection.queryMetaData1Offset; int j = this.t2cConnection.queryMetaData2Offset; short[] arrayOfShort = this.t2cConnection.queryMetaData1; byte[] arrayOfByte = this.t2cConnection.queryMetaData2; for (byte b = 0; b < this.numberOfDefinePositions; b++, i += 14) { short s1 = arrayOfShort[i + 0]; short s2 = arrayOfShort[i + 1]; short s3 = arrayOfShort[i + 11]; boolean bool1 = (arrayOfShort[i + 2] != 0) ? true : false; short s4 = arrayOfShort[i + 3]; short s5 = arrayOfShort[i + 4]; boolean bool2 = false; boolean bool3 = false; boolean bool4 = false; short s6 = arrayOfShort[i + 5]; short s7 = arrayOfShort[i + 6]; String str1 = bytes2String(arrayOfByte, j, s7); short s8 = arrayOfShort[i + 12]; boolean bool5 = (arrayOfShort[i + 13] != 0) ? true : false; String str2 = null; OracleTypeADT oracleTypeADT = null; j += s7; if (s8 > 0) { str2 = bytes2String(arrayOfByte, j, s8); j += s8; oracleTypeADT = new OracleTypeADT(str2, (Connection)this.connection); oracleTypeADT.tdoCState = (arrayOfShort[i + 7] & 0xFFFFL) << 48L | (arrayOfShort[i + 8] & 0xFFFFL) << 32L | (arrayOfShort[i + 9] & 0xFFFFL) << 16L | arrayOfShort[i + 10] & 0xFFFFL; }  Accessor accessor = this.accessors[b]; if (accessor == null || accessor.defineType == 0 || (accessor.describeType != 0 && accessor.describeType != s1)) { accessor = allocateAccessorForDefines(b, s1, s2, bool1, bool2, s4, s5, bool3, bool4, s6, s3, oracleTypeADT, str2); if (this.accessors[b] != null) { accessor.rowLength = (this.accessors[b]).rowLength; accessor.rowOffset = (this.accessors[b]).rowOffset; accessor.rowNull = (this.accessors[b]).rowNull; accessor.rowMetadata = (this.accessors[b]).rowMetadata; }  } else { accessor.initForDescribe(s1, s2, bool1, bool2, s4, s5, bool3, bool4, s6, str2); }  accessor.describeOtype = (OracleType)oracleTypeADT; accessor.columnName = str1; accessor.columnInvisible = bool5; this.accessors[b] = accessor; }  }
/*      */   Accessor allocateAccessorForDefines(int paramInt1, int paramInt2, int paramInt3, boolean paramBoolean, int paramInt4, int paramInt5, int paramInt6, int paramInt7, int paramInt8, short paramShort, int paramInt9, OracleTypeADT paramOracleTypeADT, String paramString) throws SQLException { VarcharAccessor varcharAccessor; CharAccessor charAccessor; NumberAccessor numberAccessor; RawAccessor rawAccessor; BinaryFloatAccessor binaryFloatAccessor; BinaryDoubleAccessor binaryDoubleAccessor; T2CLongAccessor t2CLongAccessor; T2CLongRawAccessor t2CLongRawAccessor; RowidAccessor rowidAccessor; ResultSetAccessor resultSetAccessor; DateAccessor dateAccessor; TimestampAccessor timestampAccessor; TimestamptzAccessor timestamptzAccessor; TimestampltzAccessor timestampltzAccessor; IntervalymAccessor intervalymAccessor; IntervaldsAccessor intervaldsAccessor; ClobAccessor clobAccessor; BlobAccessor blobAccessor; BfileAccessor bfileAccessor; NamedTypeAccessor namedTypeAccessor; switch (paramInt2) { case 1: varcharAccessor = new VarcharAccessor(this, paramInt3, paramBoolean, paramInt4, paramInt5, paramInt6, paramInt7, paramInt8, paramShort); if (paramInt9 > 0)
/*      */           varcharAccessor.setDisplaySize(paramInt9);  return varcharAccessor;
/*      */       case 96: charAccessor = new CharAccessor(this, paramInt3, paramBoolean, paramInt4, paramInt5, paramInt6, paramInt7, paramInt8, paramShort); if (paramInt9 > 0)
/*      */           charAccessor.setDisplaySize(paramInt9);  return charAccessor;
/*      */       case 2: return new NumberAccessor(this, paramInt3, paramBoolean, paramInt4, paramInt5, paramInt6, paramInt7, paramInt8, paramShort);
/*      */       case 23: return new RawAccessor(this, paramInt3, paramBoolean, paramInt4, paramInt5, paramInt6, paramInt7, paramInt8, paramShort);
/*      */       case 100: return new BinaryFloatAccessor(this, paramInt3, paramBoolean, paramInt4, paramInt5, paramInt6, paramInt7, paramInt8, paramShort);
/*      */       case 101: return new BinaryDoubleAccessor(this, paramInt3, paramBoolean, paramInt4, paramInt5, paramInt6, paramInt7, paramInt8, paramShort);
/*      */       case 8: t2CLongAccessor = new T2CLongAccessor(this, paramInt1 + 1, paramInt3, paramBoolean, paramInt4, paramInt5, paramInt6, paramInt7, paramInt8, paramShort); this.rowPrefetch = 1; this.savedRowPrefetch = 1; return t2CLongAccessor;
/*      */       case 24: t2CLongRawAccessor = new T2CLongRawAccessor(this, paramInt1 + 1, paramInt3, paramBoolean, paramInt4, paramInt5, paramInt6, paramInt7, paramInt8, paramShort); this.rowPrefetch = 1; this.savedRowPrefetch = 1; return t2CLongRawAccessor;
/*      */       case 104: return new RowidAccessor(this, paramInt3, paramBoolean, paramInt4, paramInt5, paramInt6, paramInt7, paramInt8, (short)1);
/*      */       case 102: case 116: if (this.sqlKind.isPlsqlOrCall()) { resultSetAccessor = new T2CResultSetAccessor(this, paramInt3, paramBoolean, paramInt4, paramInt5, paramInt6, paramInt7, paramInt8, paramShort); } else { resultSetAccessor = new ResultSetAccessor(this, paramInt3, paramBoolean, paramInt4, paramInt5, paramInt6, paramInt7, paramInt8, paramShort); }  return resultSetAccessor;
/*      */       case 12: return new DateAccessor(this, paramInt3, paramBoolean, paramInt4, paramInt5, paramInt6, paramInt7, paramInt8, paramShort);
/*      */       case 180: return new TimestampAccessor(this, paramInt3, paramBoolean, paramInt4, paramInt5, paramInt6, paramInt7, paramInt8, paramShort);
/*      */       case 181: return new TimestamptzAccessor(this, paramInt3, paramBoolean, paramInt4, paramInt5, paramInt6, paramInt7, paramInt8, paramShort);
/*      */       case 231: return new TimestampltzAccessor(this, paramInt3, paramBoolean, paramInt4, paramInt5, paramInt6, paramInt7, paramInt8, paramShort);
/*      */       case 182: return new IntervalymAccessor(this, paramInt3, paramBoolean, paramInt4, paramInt5, paramInt6, paramInt7, paramInt8, paramShort);
/*      */       case 183: return new IntervaldsAccessor(this, paramInt3, paramBoolean, paramInt4, paramInt5, paramInt6, paramInt7, paramInt8, paramShort);
/*      */       case 112: return new ClobAccessor(this, paramInt3, paramBoolean, paramInt4, paramInt5, paramInt6, paramInt7, paramInt8, paramShort);
/*      */       case 113: return new BlobAccessor(this, paramInt3, paramBoolean, paramInt4, paramInt5, paramInt6, paramInt7, paramInt8, paramShort);
/*      */       case 114: return new BfileAccessor(this, paramInt3, paramBoolean, paramInt4, paramInt5, paramInt6, paramInt7, paramInt8, paramShort);
/*      */       case 109: return new NamedTypeAccessor(this, paramInt3, paramBoolean, paramInt4, paramInt5, paramInt6, paramInt7, paramInt8, paramShort, paramString, (OracleType)paramOracleTypeADT);
/*      */       case 111: return new RefTypeAccessor(this, paramInt3, paramBoolean, paramInt4, paramInt5, paramInt6, paramInt7, paramInt8, paramShort, paramString, (OracleType)paramOracleTypeADT); }  SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 1, "Unknown or unimplemented accessor type: " + paramInt2); sQLException.fillInStackTrace(); throw sQLException; }
/*      */   void executeForDescribe() throws SQLException { boolean bool3; this.t2cOutput[0] = 0L; this.t2cOutput[2] = 0L; this.t2cOutput[7] = (this.t2cConnection.useOCIDefaultDefines ? 1L : 0L); this.lobPrefetchMetaData = null; boolean bool1 = !this.described ? true : false; boolean bool2 = false; int i = this.t2cConnection.useOCIDefaultDefines ? this.savedRowPrefetch : this.rowPrefetch; assert i > 0 : "rowsToFetch < 1 (rowsToFetch=" + i + ", maxRows=" + this.maxRows + ", rowPrefetch=" + this.rowPrefetch + ", savedRowPrefetch=" + this.savedRowPrefetch + ")"; this.validRows = 0; do { bool3 = false; if (this.connection.endToEndAnyChanged) { pushEndToEndValues(); this.connection.endToEndAnyChanged = false; }  byte[] arrayOfByte = this.sqlObject.getSqlBytes(this.processEscapes, this.convertNcharLiterals); int j = 0; try { resetStateBeforeFetch(); j = T2CStatement.t2cParseExecuteDescribe(this, this.c_state, this.numberOfBindPositions, this.numberOfBindRowsAllocated, this.firstRowInBatch, false, this.needToParse, bool1, bool2, arrayOfByte, arrayOfByte.length, T2CStatement.convertSqlKindEnumToByte(this.sqlKind), i, this.batch, this.bindIndicators, this.bindIndicatorOffset, this.bindBytes, this.bindChars, this.bindByteOffset, this.bindCharOffset, this.ibtBindIndicators, this.ibtBindIndicatorOffset, this.ibtBindIndicatorSize, this.ibtBindBytes, this.ibtBindChars, this.ibtBindByteOffset, this.ibtBindCharOffset, this.returnParamMeta, this.t2cConnection.queryMetaData1, this.t2cConnection.queryMetaData2, this.t2cConnection.queryMetaData1Offset, this.t2cConnection.queryMetaData2Offset, this.t2cConnection.queryMetaData1Size, this.t2cConnection.queryMetaData2Size, this.preparedByteBinds, this.preparedCharBinds, this.accessors, this.parameterDatum, this.t2cOutput, this.t2cConnection.plsqlCompilerWarnings); } catch (IOException iOException) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 266); sQLException.fillInStackTrace(); throw sQLException; }  if (this.bindIndicators != null)
/*      */         setLengthForOutAccessors();  this.validRows = (int)this.t2cOutput[1]; if (j == -1 || j == -4) { this.t2cConnection.checkError(j); } else if (j == T2C_EXTEND_BUFFER) { j = this.t2cConnection.queryMetaData1Size * 2; }  if (this.t2cOutput[3] != 0L) { foundPlsqlCompilerWarning(); } else if (this.t2cOutput[2] != 0L) { this.sqlWarning = this.t2cConnection.checkError(1, this.sqlWarning); }  this.connection.endToEndECIDSequenceNumber = (short)(int)this.t2cOutput[4]; this.needToParse = false; bool2 = true; if (this.sqlKind.isSELECT()) { this.numberOfDefinePositions = j; if (this.numberOfDefinePositions > this.t2cConnection.queryMetaData1Size) { bool3 = true; bool2 = true; this.t2cConnection.reallocateQueryMetaData(this.numberOfDefinePositions, this.numberOfDefinePositions * 8); }  } else { this.numberOfDefinePositions = 0; this.validRows = j; }  if (!this.sqlKind.isPlsqlOrCall())
/*      */         continue;  checkForImplicitResultSets(); } while (bool3); this.isComplete = false; processDescribeData(); }
/*      */   void checkForImplicitResultSets() throws SQLException { int i = 0; i = T2CStatement.t2cGetImplicitResultSetCount(this, this.c_state); if (i > 0) { int j = i; this.implicitResultSetStatements = new ArrayDeque<>(j); while (j != 0) { OracleStatement oracleStatement = this.connection.createImplicitResultSetStatement(this); ((T2CStatement)oracleStatement).doDescribe(true); ((T2CStatement)oracleStatement).prepareAccessors(); j--; }  this.implicitResultSetIterator = this.implicitResultSetStatements.iterator(); } else if (i != 0) { this.t2cConnection.checkError(i); }  }
/*      */   void pushEndToEndValues() throws SQLException { T2CConnection t2CConnection = this.t2cConnection; byte[] arrayOfByte1 = null; byte[] arrayOfByte2 = null; byte[] arrayOfByte3 = null; byte[] arrayOfByte4 = null; byte[] arrayOfByte5 = null; if (t2CConnection.endToEndValues != null) { if (t2CConnection.endToEndHasChanged[0]) { String str = t2CConnection.endToEndValues[0]; if (str != null) { arrayOfByte1 = DBConversion.stringToDriverCharBytes(str, t2CConnection.m_clientCharacterSet); } else { arrayOfByte1 = PhysicalConnection.EMPTY_BYTE_ARRAY; }  t2CConnection.endToEndHasChanged[0] = false; }  if (t2CConnection.endToEndHasChanged[1]) { String str = t2CConnection.endToEndValues[1]; if (str != null) { arrayOfByte2 = DBConversion.stringToDriverCharBytes(str, t2CConnection.m_clientCharacterSet); } else { arrayOfByte2 = PhysicalConnection.EMPTY_BYTE_ARRAY; }  t2CConnection.endToEndHasChanged[1] = false; }  if (t2CConnection.endToEndHasChanged[2]) { String str = t2CConnection.endToEndValues[2]; if (str != null) { arrayOfByte3 = DBConversion.stringToDriverCharBytes(str, t2CConnection.m_clientCharacterSet); } else { arrayOfByte3 = PhysicalConnection.EMPTY_BYTE_ARRAY; }  t2CConnection.endToEndHasChanged[2] = false; }  if (t2CConnection.endToEndHasChanged[3]) { String str = t2CConnection.endToEndValues[3]; if (str != null) { arrayOfByte4 = DBConversion.stringToDriverCharBytes(str, t2CConnection.m_clientCharacterSet); } else { arrayOfByte4 = PhysicalConnection.EMPTY_BYTE_ARRAY; }  t2CConnection.endToEndHasChanged[3] = false; }  if (t2CConnection.endToEndHasChanged[4]) { String str = t2CConnection.endToEndValues[4]; if (str != null) { arrayOfByte4 = DBConversion.stringToDriverCharBytes(str, t2CConnection.m_clientCharacterSet); } else { arrayOfByte4 = PhysicalConnection.EMPTY_BYTE_ARRAY; }  t2CConnection.endToEndHasChanged[4] = false; }  T2CStatement.t2cEndToEndUpdate(this.c_state, arrayOfByte1, (arrayOfByte1 == null) ? -1 : arrayOfByte1.length, arrayOfByte2, (arrayOfByte2 == null) ? -1 : arrayOfByte2.length, arrayOfByte3, (arrayOfByte3 == null) ? -1 : arrayOfByte3.length, arrayOfByte4, (arrayOfByte4 == null) ? -1 : arrayOfByte4.length, arrayOfByte5, (arrayOfByte5 == null) ? -1 : arrayOfByte5.length, t2CConnection.endToEndECIDSequenceNumber); }  }
/*      */   void executeForRows(boolean paramBoolean) throws SQLException { if (this.connection.endToEndAnyChanged) { pushEndToEndValues(); this.connection.endToEndAnyChanged = false; }  if (!paramBoolean) { if (this.numberOfDefinePositions > 0) { doDefineExecuteFetch(); } else { executeForDescribe(); }  } else if (this.numberOfDefinePositions > 0) { doDefineFetch(); }  if (this.returnParamMeta != null)
/*      */       fetchDmlReturnParams();  this.needToPrepareDefineBuffer = false; }
/*  109 */   T2CPreparedStatement(T2CConnection paramT2CConnection, String paramString, int paramInt1, int paramInt2, int paramInt3, int paramInt4) throws SQLException { super(paramT2CConnection, paramString, paramInt1, paramInt2, paramInt3, paramInt4);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  134 */     this.savedRowPrefetch = 0;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1658 */     this.needToRetainRows = false;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2237 */     this.updateDataException = null;
/* 2238 */     this.lastProcessedCell = 0;
/*      */ 
/*      */ 
/*      */     
/* 2242 */     this.lastProcessedAccessorIndex = 0;
/* 2243 */     this.accessorsProcessed = 0;
/* 2244 */     this.previousMode = 0; this.userResultSetType = paramInt3; this.userResultSetConcur = paramInt4; this.t2cConnection = paramT2CConnection; if (this.t2cConnection.useOCIDefaultDefines) { this.savedRowPrefetch = this.rowPrefetch; this.rowPrefetch = 1; }  }
/*      */   void setupForDefine() throws SQLException { if (this.numberOfDefinePositions > this.t2cConnection.queryMetaData1Size) { int j = this.numberOfDefinePositions / 100 + 1; this.t2cConnection.reallocateQueryMetaData(this.t2cConnection.queryMetaData1Size * j, this.t2cConnection.queryMetaData2Size * j * 8); }  short[] arrayOfShort = this.t2cConnection.queryMetaData1; int i = this.t2cConnection.queryMetaData1Offset; for (byte b = 0; b < this.numberOfDefinePositions; b++, i += 14) { Accessor accessor = this.accessors[b]; if (accessor == null) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21); sQLException.fillInStackTrace(); throw sQLException; }  arrayOfShort[i + 0] = (short)accessor.defineType; if (!this.described && accessor.charLength > 0 && accessor.formOfUse == 1) { int j = accessor.charLength; int k = j + 1; arrayOfShort[i + 11] = 0; arrayOfShort[i + 1] = (short)k; } else { arrayOfShort[i + 11] = (short)accessor.charLength; arrayOfShort[i + 1] = (short)accessor.byteLength; }  arrayOfShort[i + 5] = accessor.formOfUse; if (accessor.internalOtype != null) { long l = ((OracleTypeADT)accessor.internalOtype).getTdoCState(); arrayOfShort[i + 7] = (short)(int)((l & 0xFFFF000000000000L) >> 48L); arrayOfShort[i + 8] = (short)(int)((l & 0xFFFF00000000L) >> 32L); arrayOfShort[i + 9] = (short)(int)((l & 0xFFFF0000L) >> 16L); arrayOfShort[i + 10] = (short)(int)(l & 0xFFFFL); }  switch (accessor.internalType) { case 112: case 113: if (accessor.lobPrefetchSizeForThisColumn == -1)
/*      */             accessor.lobPrefetchSizeForThisColumn = this.defaultLobPrefetchSize;  arrayOfShort[i + 7] = (short)accessor.lobPrefetchSizeForThisColumn; break; }  }  }
/*      */   protected void configureBindData() throws SQLException { if (this.outBindAccessors == null)
/*      */       return;  AggregateByteArray aggregateByteArray1 = (AggregateByteArray)this.bindData; T2CCharByteArray t2CCharByteArray1 = (T2CCharByteArray)aggregateByteArray1.extension; AggregateByteArray aggregateByteArray2 = (AggregateByteArray)t2CCharByteArray1.extension; T2CCharByteArray t2CCharByteArray2 = (T2CCharByteArray)aggregateByteArray2.extension; if (this.bindBytes != null) { aggregateByteArray1.setBytes(this.bindBytes); } else { aggregateByteArray1.setBytes(PhysicalConnection.EMPTY_BYTE_ARRAY); }  if (this.bindChars != null) { t2CCharByteArray1.setChars(this.bindChars); } else { t2CCharByteArray1.setChars(PhysicalConnection.EMPTY_CHAR_ARRAY); }  if (this.ibtBindBytes != null) { aggregateByteArray2.setBytes(this.ibtBindBytes); } else { aggregateByteArray2.setBytes(PhysicalConnection.EMPTY_BYTE_ARRAY); }  if (this.ibtBindChars != null) { t2CCharByteArray2.setChars(this.ibtBindChars); } else { t2CCharByteArray2.setChars(PhysicalConnection.EMPTY_CHAR_ARRAY); }  t2CCharByteArray1.setDBConversion(this.connection.conversion); t2CCharByteArray2.setDBConversion(this.connection.conversion); byte b1 = (this.bindBytes == null) ? 0 : this.bindBytes.length; byte b2 = (this.bindChars == null) ? 0 : this.bindChars.length; byte b3 = (this.ibtBindBytes == null) ? 0 : this.ibtBindBytes.length; boolean bool = (this.ibtBindChars == null) ? false : this.ibtBindChars.length; Accessor accessor = null; byte b4 = 0; byte b5 = 0; for (; b5 < this.numberOfBindPositions; b5++) { accessor = this.outBindAccessors[b5]; if (accessor != null) { int i = 0; int j = accessor.byteLength; if (accessor.defineType == 998) { PlsqlIndexTableAccessor plsqlIndexTableAccessor = (PlsqlIndexTableAccessor)accessor; i += b1 + b2; i += plsqlIndexTableAccessor.ibtBindInfo.ibtValueIndex; switch (plsqlIndexTableAccessor.ibtBindInfo.element_internal_type) { case 9: i += b3; break; }  accessor.setOffset(0, i); } else { i = accessor.columnDataOffset; if (accessor.charLength > 0) { i += b1; j = accessor.charLength; }  if (accessor.defineType == 15) { b4 = 2; } else if (accessor.externalType == -8) { b4 = (this.sqlKind == OracleStatement.SqlKind.CALL_BLOCK) ? 1 : 2; } else if (accessor.defineType == 6 || accessor.defineType == 9) { b4 = 1; } else { b4 = 0; }  for (byte b = 0; b < this.binders.length; b++) { i += j * b + b4; int k = this.bindIndicators[accessor.lengthIndex] - b4 & 0x7FFF; accessor.setOffset(b, i); }  }  }  }  }
/*      */   void initializePlsqlIndexByTableAccessor(Accessor paramAccessor, int paramInt) { ((T2CPlsqlIndexTableAccessor)paramAccessor).ibtMetaIndex = paramInt - 8; }
/*      */   Object[] getLobPrefetchMetaData() { Object[] arrayOfObject = null; Object object = null; int[] arrayOfInt = null; byte b1 = 0; byte b2 = 0; if (this.accessors != null)
/*      */       for (byte b = 0; b < this.numberOfDefinePositions; b++) { switch ((this.accessors[b]).internalType) { case 8: case 24: b2 = b; break;
/*      */           case 112: case 113:
/*      */             if (arrayOfInt == null)
/*      */               arrayOfInt = new int[this.accessors.length];  if ((this.accessors[b]).lobPrefetchSizeForThisColumn != -1) { b1++; arrayOfInt[b] = (this.accessors[b]).lobPrefetchSizeForThisColumn; break; }  arrayOfInt[b] = -1; break; }  }   if (b1 > 0) { if (arrayOfObject == null)
/*      */         arrayOfObject = new Object[] { null, new long[this.rowPrefetch * b1], new byte[this.accessors.length], new int[this.accessors.length], new Object[this.rowPrefetch * b1] };  for (byte b = 0; b < b2; b++) { switch ((this.accessors[b]).internalType) { case 112:
/*      */           case 113:
/*      */             (this.accessors[b]).lobPrefetchSizeForThisColumn = -1; arrayOfInt[b] = -1; break; }  }  arrayOfObject[0] = arrayOfInt; }  return arrayOfObject; }
/*      */   void processLobPrefetchMetaData(Object[] paramArrayOfObject) { byte b1 = 0; byte b2 = (this.validRows == -2) ? 1 : this.validRows; byte[] arrayOfByte = (byte[])paramArrayOfObject[2]; int[] arrayOfInt1 = (int[])paramArrayOfObject[3]; long[] arrayOfLong = (long[])paramArrayOfObject[1]; Object[] arrayOfObject = (Object[])paramArrayOfObject[4]; int[] arrayOfInt2 = (int[])paramArrayOfObject[0]; if (this.accessors != null)
/*      */       for (byte b = 0; b < this.numberOfDefinePositions; b++) { switch ((this.accessors[b]).internalType) { case 112:
/*      */           case 113:
/*      */             if ((this.accessors[b]).lobPrefetchSizeForThisColumn >= 0) { LobCommonAccessor lobCommonAccessor = (LobCommonAccessor)this.accessors[b]; if (lobCommonAccessor.prefetchedDataLength == null || lobCommonAccessor.prefetchedDataLength.length < this.rowPrefetch) { if (lobCommonAccessor.internalType == 112)
/*      */                   ((ClobAccessor)lobCommonAccessor).prefetchedDataFormOfUse = new int[this.rowPrefetch];  lobCommonAccessor.prefetchedChunkSize = new int[this.rowPrefetch]; lobCommonAccessor.prefetchedDataLength = new int[this.rowPrefetch]; lobCommonAccessor.prefetchedLength = new long[this.rowPrefetch]; lobCommonAccessor.prefetchedDataOffset = new long[this.rowPrefetch]; }  int i = b2 * b1; byte b3 = this.needToRetainRows ? this.storedRowCount : 0; for (byte b4 = 0; b4 < b2; b4++) { lobCommonAccessor.prefetchedChunkSize[b3 + b4] = arrayOfInt1[b]; lobCommonAccessor.prefetchedLength[b3 + b4] = arrayOfLong[i + b4]; if (lobCommonAccessor.internalType == 112)
/* 2263 */                   ((ClobAccessor)lobCommonAccessor).prefetchedDataFormOfUse[b3 + b4] = arrayOfByte[b];  lobCommonAccessor.prefetchedDataLength[b4] = 0; if (arrayOfInt2[b] > 0 && arrayOfLong[i + b4] > 0L) { byte[] arrayOfByte1 = (byte[])arrayOfObject[i + b4]; boolean bool = (arrayOfByte1 == null) ? false : arrayOfByte1.length; if (bool) { lobCommonAccessor.setPrefetchedDataOffset(b3 + b4); lobCommonAccessor.rowData.put(arrayOfByte1, 0, bool); }  lobCommonAccessor.prefetchedDataLength[b3 + b4] = bool; }  }  b1++; }  break; }  }   } public int updateData(int paramInt1, int paramInt2, int paramInt3, int[] paramArrayOfint, byte[] paramArrayOfbyte) { try { int n; Accessor[] arrayOfAccessor; ByteArray byteArray; int i1; byte b; if (this.previousMode != paramInt1) {
/* 2264 */         this.accessorsProcessed = 0;
/*      */       }
/* 2266 */       this.previousMode = paramInt1;
/*      */       
/* 2268 */       int i = 0;
/* 2269 */       int j = 0;
/* 2270 */       int k = 0;
/* 2271 */       int m = 0;
/* 2272 */       boolean bool = false;
/*      */       
/* 2274 */       switch (paramInt1) {
/*      */ 
/*      */         
/*      */         case 16:
/*      */         case 32:
/* 2279 */           n = 0;
/* 2280 */           for (; n < paramInt2; 
/* 2281 */             this.lastProcessedCell++, n++) {
/*      */             
/* 2283 */             j = paramArrayOfint[n * 4 + 0];
/* 2284 */             k = paramArrayOfint[n * 4 + 1];
/* 2285 */             m = paramArrayOfint[n * 4 + 2];
/* 2286 */             bool = (paramArrayOfint[n * 4 + 3] == -1) ? true : false;
/* 2287 */             Accessor accessor = this.accessors[k];
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/* 2293 */             accessor.setOffset((this.needToRetainRows ? this.storedRowCount : 0) + j);
/*      */ 
/*      */ 
/*      */             
/* 2297 */             if (m > 0) {
/*      */ 
/*      */               
/* 2300 */               switch (accessor.defineType) {
/*      */ 
/*      */ 
/*      */                 
/*      */                 case 1:
/*      */                 case 23:
/*      */                 case 96:
/*      */                 case 104:
/* 2308 */                   i += true;
/* 2309 */                   m -= 2;
/*      */                   break;
/*      */                 
/*      */                 case 6:
/* 2313 */                   i++;
/* 2314 */                   m--;
/*      */                   break;
/*      */               } 
/*      */ 
/*      */ 
/*      */ 
/*      */               
/* 2321 */               this.rowData.put(paramArrayOfbyte, i, m);
/*      */               
/* 2323 */               i += m;
/*      */             } 
/* 2325 */             accessor.setLengthAndNull((this.needToRetainRows ? this.storedRowCount : 0) + j, m);
/* 2326 */             this.accessorsProcessed++;
/*      */           } 
/*      */           break;
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         case 64:
/* 2334 */           n = 0;
/* 2335 */           arrayOfAccessor = null;
/* 2336 */           if (this.outBindAccessors != null) {
/* 2337 */             n = ((this.bindBytes == null) ? 0 : this.bindBytes.length) + ((this.bindChars == null) ? 0 : this.bindChars.length) + ((this.ibtBindBytes == null) ? 0 : this.ibtBindBytes.length) + ((this.ibtBindChars == null) ? 0 : this.ibtBindChars.length);
/*      */ 
/*      */ 
/*      */             
/* 2341 */             arrayOfAccessor = this.outBindAccessors;
/*      */           } else {
/*      */             
/* 2344 */             n = ((this.returnParamBytes == null) ? 0 : this.returnParamBytes.length) + ((this.returnParamChars == null) ? 0 : this.returnParamChars.length) + ((this.ibtBindBytes == null) ? 0 : this.ibtBindBytes.length) + ((this.ibtBindChars == null) ? 0 : this.ibtBindChars.length);
/*      */ 
/*      */ 
/*      */             
/* 2348 */             arrayOfAccessor = this.accessors;
/*      */           } 
/* 2350 */           assert arrayOfAccessor != null : "No OUT binds or Return Parameters";
/* 2351 */           byteArray = this.bindData;
/*      */ 
/*      */ 
/*      */           
/* 2355 */           while (byteArray instanceof AggregateByteArray) {
/*      */             
/* 2357 */             byteArray = ((AggregateByteArray)byteArray).extension;
/*      */             
/* 2359 */             if (byteArray == null)
/*      */               break; 
/* 2361 */           }  n = (int)(n + byteArray.getPosition());
/* 2362 */           i1 = this.accessorsProcessed;
/* 2363 */           b = 0;
/* 2364 */           for (; b < paramInt2; 
/* 2365 */             this.lastProcessedCell++, b++) {
/*      */             
/* 2367 */             j = paramArrayOfint[b * 4 + 0];
/* 2368 */             k = paramArrayOfint[b * 4 + 1];
/* 2369 */             m = paramArrayOfint[b * 4 + 2];
/* 2370 */             bool = (paramArrayOfint[b * 4 + 3] == -1) ? true : false;
/* 2371 */             Accessor accessor = arrayOfAccessor[k];
/*      */ 
/*      */ 
/*      */ 
/*      */             
/* 2376 */             accessor.setOffset((this.needToRetainRows ? this.storedRowCount : 0) + j, n);
/* 2377 */             byteArray.put(paramArrayOfbyte, i, m);
/* 2378 */             accessor.setLengthAndNull((this.needToRetainRows ? this.storedRowCount : 0) + j, m);
/*      */             
/* 2380 */             i += m;
/* 2381 */             n += m;
/*      */           } 
/*      */           break;
/*      */       }  }
/* 2385 */     catch (SQLException sQLException)
/*      */     
/* 2387 */     { this.updateDataException = sQLException;
/* 2388 */       return -3; }
/*      */     
/* 2390 */     return 0; }
/*      */   int getRowsToFetch() { int i = -1; if (this.hasStream) { i = 1; if (this.t2cConnection.useOCIDefaultDefines) { this.savedRowPrefetch = 1; } else { this.rowPrefetch = 1; }  } else if (this.t2cConnection.useOCIDefaultDefines) { if (this.maxRows > 0 && this.maxRows == this.storedRowCount) { i = 0; } else { i = this.rowPrefetch; }  } else if (this.maxRows > 0 && this.maxRows < this.rowPrefetch + this.storedRowCount) { if (this.storedRowCount < 1 && this.maxRows < this.rowPrefetch) { i = this.maxRows; } else { i = Math.min(this.rowPrefetch, this.maxRows - this.rowPrefetch + this.storedRowCount); }  } else { i = this.rowPrefetch; }  return i; }
/*      */   void doDefineFetch() throws SQLException { int i = getRowsToFetch(); this.validRows = 0; if (!this.needToPrepareDefineBuffer) throw new Error("doDefineFetch called when needToPrepareDefineBuffer=false " + this.sqlObject.getSql(this.processEscapes, this.convertNcharLiterals));  assert i > 0 : "rowsToFetch < 1 (rowsToFetch=" + i + ", maxRows=" + this.maxRows + ", rowPrefetch=" + this.rowPrefetch + ", savedRowPrefetch=" + this.savedRowPrefetch + ")"; if (i > 0) { setupForDefine(); this.t2cOutput[2] = 0L; this.t2cOutput[5] = (this.connection.useNio ? 1L : 0L); this.t2cOutput[6] = this.defaultLobPrefetchSize; if (this.connection.useNio) { resetNioAttributesBeforeFetch(); allocateNioBuffersIfRequired((this.defineChars == null) ? 0 : this.defineChars.length, (this.defineBytes == null) ? 0 : this.defineBytes.length, (this.defineIndicators == null) ? 0 : this.defineIndicators.length); }  if (this.lobPrefetchMetaData == null) this.lobPrefetchMetaData = getLobPrefetchMetaData();  resetStateBeforeFetch(); this.validRows = T2CStatement.t2cDefineFetch(this, this.c_state, i, this.t2cConnection.queryMetaData1, this.t2cConnection.queryMetaData2, this.t2cConnection.queryMetaData1Offset, this.t2cConnection.queryMetaData2Offset, this.accessors, this.t2cOutput, this.nioBuffers, this.lobPrefetchMetaData); if (this.validRows == -1 || this.validRows == -4) this.t2cConnection.checkError(this.validRows);  if (this.t2cOutput[2] != 0L) this.sqlWarning = this.t2cConnection.checkError(1, this.sqlWarning);  if (this.connection.useNio && (this.validRows > 0 || this.validRows == -2)) extractNioDefineBuffers(0);  if (this.isFetchStreams && this.validRows == -2) copyStreamDataIntoDBA(0);  if (this.lobPrefetchMetaData != null) processLobPrefetchMetaData(this.lobPrefetchMetaData);  }  this.isComplete = (i < 1 || (this.validRows >= 0 && this.validRows < i)); }
/*      */   void copyStreamDataIntoDBA(int paramInt) throws SQLException { assert this.isFetchStreams && this.validRows == -2 : "isFetchStreams: " + this.isFetchStreams + "isScrollable(): " + this.realRsetType.isScrollable() + ", isUpdatable(): " + this.realRsetType.isUpdatable() + ", validRows=" + this.validRows; checkValidRowsStatus(); if (this.accessors != null) for (Accessor accessor : this.accessors) { if (accessor != null) switch (accessor.internalType) { case 8: ((T2CLongAccessor)accessor).copyStreamDataIntoDBA(paramInt); break;case 24: ((T2CLongRawAccessor)accessor).copyStreamDataIntoDBA(paramInt); break; }   }   }
/*      */   void allocateNioBuffersIfRequired(int paramInt1, int paramInt2, int paramInt3) throws SQLException { if (this.nioBuffers == null) this.nioBuffers = new ByteBuffer[4];  if (paramInt2 > 0) if (this.nioBuffers[0] == null || this.nioBuffers[0].capacity() < paramInt2) { this.nioBuffers[0] = ByteBuffer.allocateDirect(paramInt2); } else if (this.nioBuffers[0] != null) { this.nioBuffers[0].rewind(); }   paramInt1 *= 2; if (paramInt1 > 0) if (this.nioBuffers[1] == null || this.nioBuffers[1].capacity() < paramInt1) { this.nioBuffers[1] = ByteBuffer.allocateDirect(paramInt1); } else if (this.nioBuffers[1] != null) { this.nioBuffers[1].rewind(); }   paramInt3 *= 2; if (paramInt3 > 0) if (this.nioBuffers[2] == null || this.nioBuffers[2].capacity() < paramInt3) { this.nioBuffers[2] = ByteBuffer.allocateDirect(paramInt3); } else if (this.nioBuffers[2] != null) { this.nioBuffers[2].rewind(); }   }
/* 2395 */   void doDefineExecuteFetch() throws SQLException { short[] arrayOfShort = null; if (this.needToPrepareDefineBuffer || this.needToParse) { setupForDefine(); arrayOfShort = this.t2cConnection.queryMetaData1; }  this.t2cOutput[0] = 0L; this.t2cOutput[2] = 0L; byte[] arrayOfByte = this.sqlObject.getSqlBytes(this.processEscapes, this.convertNcharLiterals); this.t2cOutput[5] = (this.connection.useNio ? 1L : 0L); this.t2cOutput[6] = this.defaultLobPrefetchSize; this.t2cOutput[7] = (this.t2cConnection.useOCIDefaultDefines ? 1L : 0L); if (this.connection.useNio) { resetNioAttributesBeforeFetch(); allocateNioBuffersIfRequired((this.defineChars == null) ? 0 : this.defineChars.length, (this.defineBytes == null) ? 0 : this.defineBytes.length, (this.defineIndicators == null) ? 0 : this.defineIndicators.length); }  if (this.lobPrefetchMetaData == null) this.lobPrefetchMetaData = getLobPrefetchMetaData();  int i = getRowsToFetch(); assert i > 0 : "rowsToFetch < 1 (rowsToFetch=" + i + ", maxRows=" + this.maxRows + ", rowPrefetch=" + this.rowPrefetch + ", savedRowPrefetch=" + this.savedRowPrefetch + ")"; this.validRows = 0; try { resetStateBeforeFetch(); this.validRows = T2CStatement.t2cDefineExecuteFetch(this, this.c_state, this.numberOfDefinePositions, this.numberOfBindPositions, this.numberOfBindRowsAllocated, this.firstRowInBatch, false, this.needToParse, arrayOfByte, arrayOfByte.length, T2CStatement.convertSqlKindEnumToByte(this.sqlKind), i, this.batch, this.bindIndicators, this.bindIndicatorOffset, this.bindBytes, this.bindChars, this.bindByteOffset, this.bindCharOffset, arrayOfShort, this.t2cConnection.queryMetaData2, this.t2cConnection.queryMetaData1Offset, this.t2cConnection.queryMetaData2Offset, this.preparedByteBinds, this.preparedCharBinds, this.accessors, this.parameterDatum, this.t2cOutput, this.nioBuffers, this.lobPrefetchMetaData); if (this.bindIndicators != null) setLengthForOutAccessors();  } catch (IOException iOException) { this.validRows = 0; SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException); sQLException.fillInStackTrace(); throw sQLException; }  if (this.validRows == -1) this.t2cConnection.checkError(this.validRows);  if (this.t2cOutput[2] != 0L) this.sqlWarning = this.t2cConnection.checkError(1, this.sqlWarning);  this.connection.endToEndECIDSequenceNumber = (short)(int)this.t2cOutput[4]; if (this.connection.useNio && (this.validRows > 0 || this.validRows == -2)) extractNioDefineBuffers(0);  if (this.isFetchStreams && this.validRows == -2) copyStreamDataIntoDBA(0);  if (this.lobPrefetchMetaData != null) processLobPrefetchMetaData(this.lobPrefetchMetaData);  this.isComplete = (i < 1 || (this.validRows >= 0 && this.validRows < i)); this.needToParse = false; } protected void fetch(int paramInt, boolean paramBoolean) throws SQLException { this.needToRetainRows = paramBoolean; int i = getRowsToFetch(); assert i > 0 : "rowsToFetch < 1 (rowsToFetch=" + i + ", maxRows=" + this.maxRows + ", rowPrefetch=" + this.rowPrefetch + ", savedRowPrefetch=" + this.savedRowPrefetch + ")"; this.validRows = 0; if (i > 0 && this.numberOfDefinePositions > 0) if (this.needToPrepareDefineBuffer) { doDefineFetch(); this.needToPrepareDefineBuffer = false; } else { this.t2cOutput[2] = 0L; this.t2cOutput[5] = (this.connection.useNio ? 1L : 0L); this.t2cOutput[6] = this.defaultLobPrefetchSize; if (this.connection.useNio) { resetNioAttributesBeforeFetch(); allocateNioBuffersIfRequired((this.defineChars == null) ? 0 : this.defineChars.length, (this.defineBytes == null) ? 0 : this.defineBytes.length, (this.defineIndicators == null) ? 0 : this.defineIndicators.length); }  if (this.lobPrefetchMetaData == null) this.lobPrefetchMetaData = getLobPrefetchMetaData();  resetStateBeforeFetch(); this.validRows = T2CStatement.t2cFetch(this, this.c_state, this.needToPrepareDefineBuffer, i, this.accessors, this.t2cOutput, this.nioBuffers, this.lobPrefetchMetaData); if (this.validRows == -1 || this.validRows == -4) this.t2cConnection.checkError(this.validRows);  if (this.t2cOutput[2] != 0L) this.sqlWarning = this.t2cConnection.checkError(1, this.sqlWarning);  if (this.lobPrefetchMetaData != null) processLobPrefetchMetaData(this.lobPrefetchMetaData);  if (this.connection.useNio && (this.validRows > 0 || this.validRows == -2)) extractNioDefineBuffers(0);  if (this.isFetchStreams && this.validRows == -2) copyStreamDataIntoDBA(paramInt);  }   this.isComplete = (i < 1 || (this.validRows >= 0 && this.validRows < i)); this.needToRetainRows = false; } void resetNioAttributesBeforeFetch() { this.extractedCharOffset = 0; this.extractedByteOffset = 0; } void extractNioDefineBuffers(int paramInt) throws SQLException { if (this.accessors == null || this.defineIndicators == null || paramInt == this.numberOfDefinePositions) return;  int i = 0; int j = 0; int k = 0; int m = 0; int n = 0; if (!this.hasStream) { i = (this.defineBytes != null) ? this.defineBytes.length : 0; j = (this.defineChars != null) ? this.defineChars.length : 0; k = this.defineIndicators.length; } else { if (this.numberOfDefinePositions > paramInt) { n = (this.accessors[paramInt]).indicatorIndex; m = (this.accessors[paramInt]).lengthIndex; }  for (int i1 = paramInt; i1 < this.numberOfDefinePositions; i1++) { switch ((this.accessors[i1]).internalType) { case 8: case 24: break; }  i += (this.accessors[i1]).byteLength; j += (this.accessors[i1]).charLength; k++; }  }  ByteBuffer byteBuffer = this.nioBuffers[0]; if (byteBuffer != null && this.defineBytes != null) if (i > 0) { byteBuffer.position(this.extractedByteOffset); byteBuffer.get(this.defineBytes, this.extractedByteOffset, i); this.extractedByteOffset += i; }   if (this.nioBuffers[1] != null && this.defineChars != null) { byteBuffer = this.nioBuffers[1].order(ByteOrder.LITTLE_ENDIAN); CharBuffer charBuffer = byteBuffer.asCharBuffer(); if (j > 0) { charBuffer.position(this.extractedCharOffset); charBuffer.get(this.defineChars, this.extractedCharOffset, j); this.extractedCharOffset += j; }  }  if (this.nioBuffers[2] != null) { byteBuffer = this.nioBuffers[2].order(ByteOrder.LITTLE_ENDIAN); ShortBuffer shortBuffer = byteBuffer.asShortBuffer(); if (this.hasStream) { if (k > 0) { shortBuffer.position(n); shortBuffer.get(this.defineIndicators, n, k); shortBuffer.position(m); shortBuffer.get(this.defineIndicators, m, k); }  } else { shortBuffer.get(this.defineIndicators); }  }  } void doClose() throws SQLException { if (this.defineBytes != null) this.defineBytes = null;  if (this.defineChars != null) this.defineChars = null;  if (this.defineIndicators != null) this.defineIndicators = null;  int i = T2CStatement.t2cCloseStatement(this.c_state); this.nioBuffers = null; if (i != 0) this.t2cConnection.checkError(i);  this.t2cOutput = null; } void closeQuery() throws SQLException { this.connection.registerHeartbeat(); this.connection.needLine(); if (this.streamList != null) while (this.nextStream != null) { try { this.nextStream.close(); } catch (IOException iOException) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException); sQLException.fillInStackTrace(); throw sQLException; }  this.nextStream = this.nextStream.nextStream; }   } void closeUsedStreams(int paramInt) throws SQLException { while (this.nextStream != null && this.nextStream.columnIndex < 1 + this.offsetOfFirstUserColumn + paramInt) { try { this.nextStream.close(); } catch (IOException iOException) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException); sQLException.fillInStackTrace(); throw sQLException; }  this.nextStream = this.nextStream.nextStream; }  if (this.nextStream != null) try { this.nextStream.needBytes(); } catch (IOException iOException) { interalCloseOnIOException(iOException); SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException); sQLException.fillInStackTrace(); throw sQLException; }   } void interalCloseOnIOException(IOException paramIOException) throws SQLException { this.closed = true; if (this.currentResultSet != null) this.currentResultSet.closed = true;  doClose(); } void fetchDmlReturnParams() throws SQLException { this.rowsDmlReturned = T2CStatement.t2cGetRowsDmlReturned(this.c_state); if (this.rowsDmlReturned != 0) { allocateDmlReturnStorage(); resetStateBeforeFetch(); int m = T2CStatement.t2cFetchDmlReturnParams(this.c_state, this, this.accessors, this.returnParamBytes, this.returnParamChars, this.returnParamIndicators); if (m == -1 || m == -4) this.t2cConnection.checkError(m);  if (this.t2cOutput[2] != 0L) this.sqlWarning = this.t2cConnection.checkError(1, this.sqlWarning);  if (this.connection.useNio && (m > 0 || m == -2)) extractNioDefineBuffers(0);  }  AggregateByteArray aggregateByteArray = (AggregateByteArray)this.bindData; if (this.returnParamBytes != null) aggregateByteArray.setBytes(this.returnParamBytes);  ((T2CCharByteArray)aggregateByteArray.extension).setChars(this.returnParamChars); ((T2CCharByteArray)aggregateByteArray.extension).setDBConversion(this.connection.conversion); byte b1 = (this.returnParamBytes == null) ? 0 : this.returnParamBytes.length; byte b2 = 0; int i = this.numReturnParams * this.rowsDmlReturned; int j = 0; int k = b1; byte b3 = 0; for (byte b4 = 0; b4 < this.numberOfBindPositions; b4++) { Accessor accessor = this.accessors[b4]; if (accessor != null) { accessor.setCapacity(this.rowsDmlReturned); for (byte b = 0; b < this.rowsDmlReturned; b++) { if (accessor.internalType == 109 || accessor.internalType == 111) { b3++; } else { short s = this.returnParamIndicators[i++]; boolean bool = (this.returnParamIndicators[b2++] == -1) ? true : false; byte b5 = 0; if (accessor.internalType == 104) { b5 = 2; } else if (accessor.defineType == 6 || accessor.defineType == 9 || accessor.defineType == 1) { b5 = 1; }  if (accessor.charLength > 0) { accessor.setOffset(b, (k + b5)); k += accessor.charLength; } else { accessor.setOffset(b, (j + b5)); j += accessor.byteLength; }  if (bool || s == 0) { accessor.setLengthAndNull(b, 0); } else { int m; if (accessor.internalType == 1) m = s / 2;  accessor.setLengthAndNull(b, m); }  }  }  }  }  this.returnParamsFetched = true; } void processDmlReturningBind() throws SQLException { super.processDmlReturningBind(); this.returnParamRowBytes = 0; this.returnParamRowChars = 0; for (byte b = 0; b < this.numberOfBindPositions; b++) { Accessor accessor = this.accessors[b]; if (accessor != null) if (accessor.charLength > 0) { this.returnParamRowChars += accessor.charLength; } else { this.returnParamRowBytes += accessor.byteLength; }   }  this.returnParamMeta[1] = this.returnParamRowBytes; this.returnParamMeta[2] = this.returnParamRowChars; } void allocateDmlReturnStorage() { if (this.rowsDmlReturned == 0) return;  int i = this.returnParamRowBytes * this.rowsDmlReturned; int j = this.returnParamRowChars * this.rowsDmlReturned; int k = 2 * this.numReturnParams * this.rowsDmlReturned; this.returnParamBytes = new byte[i]; this.returnParamChars = new char[j]; this.returnParamIndicators = new short[k]; for (byte b = 0; b < this.numberOfBindPositions; b++) { Accessor accessor = this.accessors[b]; if (accessor != null) accessor.setCapacity(this.rowsDmlReturned);  }  } void cleanupReturnParameterBuffers() { this.returnParamBytes = null; this.returnParamChars = null; this.returnParamIndicators = null; } static int PREAMBLE_PER_POSITION = 5; SQLException updateDataException; int lastProcessedCell; static final int PROCESS_DEFINE_DYNAMIC_COLUMNS = 16; static final int PROCESS_DEFINE_DEFAULT_COLUMNS = 32; static final int PROCESS_ADT_OUT_BINDS = 64; int lastProcessedAccessorIndex; int accessorsProcessed; int previousMode; void initializeIndicatorSubRange() { this.bindIndicatorSubRange = this.numberOfBindPositions * PREAMBLE_PER_POSITION; } int calculateIndicatorSubRangeSize() { return this.numberOfBindPositions * PREAMBLE_PER_POSITION; } short getInoutIndicator(int paramInt) { return this.bindIndicators[paramInt * PREAMBLE_PER_POSITION]; } void resetStateBeforeFetch() { this.lastProcessedCell = 0; this.lastProcessedAccessorIndex = 0; this.accessorsProcessed = 0; this.previousMode = 0; if (this.rowData != null) if (this.needToRetainRows) { this.rowData.setPosition(this.rowData.length()); } else { this.rowData.reset(); }   } final boolean bit(long paramLong1, long paramLong2) { return ((paramLong1 & paramLong2) == paramLong1); }
/*      */ 
/*      */ 
/*      */   
/*      */   public static String toHex(byte[] paramArrayOfbyte, int paramInt) {
/* 2400 */     if (paramArrayOfbyte == null)
/* 2401 */       return "null"; 
/* 2402 */     if (paramInt > paramArrayOfbyte.length)
/* 2403 */       return "byte array not long enough"; 
/* 2404 */     String str = "0:";
/* 2405 */     int i = paramInt;
/* 2406 */     for (byte b = 0; b < i; b++) {
/*      */       
/* 2408 */       if (b != 0 && b % 10 == 0) str = str + "\n" + b + ": "; 
/* 2409 */       str = str + OracleLog.toHex(paramArrayOfbyte[b]) + " ";
/*      */     } 
/* 2411 */     return str;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   Accessor allocateAccessor(int paramInt1, int paramInt2, int paramInt3, int paramInt4, short paramShort, String paramString, boolean paramBoolean) throws SQLException {
/* 2425 */     T2CResultSetAccessor t2CResultSetAccessor = null;
/*      */     
/* 2427 */     switch (paramInt1) {
/*      */ 
/*      */       
/*      */       case 102:
/*      */       case 116:
/* 2432 */         if (paramBoolean && paramString != null) {
/*      */           
/* 2434 */           SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 12, "sqlType=" + paramInt2);
/* 2435 */           sQLException.fillInStackTrace();
/* 2436 */           throw sQLException;
/*      */         } 
/*      */         
/* 2439 */         t2CResultSetAccessor = new T2CResultSetAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean);
/*      */ 
/*      */         
/* 2442 */         return t2CResultSetAccessor;
/*      */ 
/*      */       
/*      */       case 8:
/* 2446 */         if (paramBoolean && paramString != null) {
/*      */           
/* 2448 */           SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 12, "sqlType=" + paramInt2);
/* 2449 */           sQLException.fillInStackTrace();
/* 2450 */           throw sQLException;
/*      */         } 
/*      */         
/* 2453 */         if (paramBoolean) {
/* 2454 */           return new VarcharAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean);
/*      */         }
/*      */         
/* 2457 */         return new T2CLongAccessor(this, paramInt3, paramInt4, paramShort, paramInt2);
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 1:
/* 2463 */         if (paramBoolean) {
/*      */           
/* 2465 */           if (paramString != null) {
/*      */ 
/*      */             
/* 2468 */             SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 12, "sqlType=" + paramInt2);
/* 2469 */             sQLException.fillInStackTrace();
/* 2470 */             throw sQLException;
/*      */           } 
/*      */ 
/*      */ 
/*      */           
/* 2475 */           return new T2CVarcharAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean);
/*      */         } 
/*      */         break;
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 24:
/* 2483 */         if (paramBoolean && paramString != null) {
/*      */           
/* 2485 */           SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 12, "sqlType=" + paramInt2);
/* 2486 */           sQLException.fillInStackTrace();
/* 2487 */           throw sQLException;
/*      */         } 
/*      */         
/* 2490 */         if (paramBoolean) {
/* 2491 */           return new OutRawAccessor(this, paramInt4, paramShort, paramInt2);
/*      */         }
/*      */         
/* 2494 */         return new T2CLongRawAccessor(this, paramInt3, paramInt4, paramShort, paramInt2);
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2501 */     return super.allocateAccessor(paramInt1, paramInt2, paramInt3, paramInt4, paramShort, paramString, paramBoolean);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void prepareBindPreambles(int paramInt1, int paramInt2) {
/* 2514 */     int i = calculateIndicatorSubRangeSize();
/* 2515 */     int j = this.bindIndicatorSubRange - i;
/* 2516 */     OracleTypeADT[] arrayOfOracleTypeADT = (this.parameterOtype == null) ? null : this.parameterOtype[this.firstRowInBatch];
/*      */ 
/*      */ 
/*      */     
/* 2520 */     for (byte b = 0; b < this.numberOfBindPositions; b++) {
/*      */       short s;
/*      */       OracleTypeADT oracleTypeADT;
/* 2523 */       Binder binder = this.lastBinders[b];
/*      */ 
/*      */       
/* 2526 */       if (binder == this.theReturnParamBinder) {
/*      */         
/* 2528 */         oracleTypeADT = (OracleTypeADT)(this.accessors[b]).internalOtype;
/* 2529 */         s = 0;
/*      */       }
/*      */       else {
/*      */         
/* 2533 */         oracleTypeADT = (arrayOfOracleTypeADT == null) ? null : arrayOfOracleTypeADT[b];
/*      */         
/* 2535 */         if (this.outBindAccessors == null) {
/* 2536 */           s = 0;
/*      */         } else {
/*      */           
/* 2539 */           Accessor accessor = this.outBindAccessors[b];
/*      */           
/* 2541 */           if (accessor == null) {
/* 2542 */             s = 0;
/* 2543 */           } else if (binder == this.theOutBinder) {
/*      */             
/* 2545 */             s = 1;
/*      */             
/* 2547 */             if (oracleTypeADT == null) {
/* 2548 */               oracleTypeADT = (OracleTypeADT)accessor.internalOtype;
/*      */             }
/*      */           } else {
/* 2551 */             s = 2;
/*      */           } 
/* 2553 */         }  s = binder.updateInoutIndicatorValue(s);
/*      */       } 
/*      */       
/* 2556 */       this.bindIndicators[j++] = s;
/*      */       
/* 2558 */       if (oracleTypeADT != null) {
/*      */         
/* 2560 */         long l = oracleTypeADT.getTdoCState();
/*      */         
/* 2562 */         this.bindIndicators[j + 0] = (short)(int)(l >> 48L & 0xFFFFL);
/*      */         
/* 2564 */         this.bindIndicators[j + 1] = (short)(int)(l >> 32L & 0xFFFFL);
/*      */         
/* 2566 */         this.bindIndicators[j + 2] = (short)(int)(l >> 16L & 0xFFFFL);
/*      */         
/* 2568 */         this.bindIndicators[j + 3] = (short)(int)(l & 0xFFFFL);
/*      */       } 
/*      */       
/* 2571 */       j += 4;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void releaseBuffers() {
/* 2579 */     super.releaseBuffers();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void setLengthForOutAccessors() throws SQLException {
/* 2588 */     if (this.outBindAccessors == null)
/* 2589 */       return;  Accessor accessor = null;
/*      */     
/* 2591 */     byte b = 0;
/* 2592 */     for (; b < this.numberOfBindPositions; 
/* 2593 */       b++) {
/*      */ 
/*      */       
/* 2596 */       accessor = this.outBindAccessors[b];
/* 2597 */       if (accessor != null)
/*      */       {
/* 2599 */         if (accessor.defineType != 998 && accessor.defineType != 111 && accessor.defineType != 109)
/*      */         {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 2606 */           for (byte b1 = 0; b1 < this.binders.length; b1++) {
/*      */             
/* 2608 */             boolean bool = (accessor.rowSpaceIndicator[accessor.indicatorIndex + b1] == -1) ? true : false;
/* 2609 */             byte b2 = bool ? 0 : (accessor.rowSpaceIndicator[accessor.lengthIndex + b1] & 0xFFFF);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/* 2617 */             if (this.sqlKind != OracleStatement.SqlKind.CALL_BLOCK && accessor.externalType == -8) {
/*      */ 
/*      */ 
/*      */ 
/*      */               
/* 2622 */               accessor.setLengthAndNull(b1, b2);
/* 2623 */             } else if (accessor.defineType == 9 || accessor.defineType == 1) {
/*      */ 
/*      */               
/* 2626 */               accessor.setLengthAndNull(b1, b2 / 2);
/* 2627 */             } else if (accessor.defineType != 109 && accessor.defineType != 111) {
/*      */ 
/*      */               
/* 2630 */               accessor.setLengthAndNull(b1, b2);
/*      */             } 
/*      */           } 
/*      */         }
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void doDescribe(boolean paramBoolean) throws SQLException {
/*      */     boolean bool;
/* 2655 */     if (this.closed) {
/*      */       
/* 2657 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 2658 */       sQLException.fillInStackTrace();
/* 2659 */       throw sQLException;
/*      */     } 
/*      */     
/* 2662 */     if (this.described == true) {
/*      */       return;
/*      */     }
/*      */ 
/*      */     
/* 2667 */     if (!this.isOpen) {
/*      */ 
/*      */ 
/*      */       
/* 2671 */       this.connection.open(this);
/* 2672 */       this.isOpen = true;
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     do {
/* 2680 */       bool = false;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2689 */       boolean bool1 = (this.sqlKind.isSELECT() && this.needToParse && (!this.described || !this.serverCursor)) ? true : false;
/* 2690 */       byte[] arrayOfByte = bool1 ? this.sqlObject.getSqlBytes(this.processEscapes, this.convertNcharLiterals) : PhysicalConnection.EMPTY_BYTE_ARRAY;
/* 2691 */       this.numberOfDefinePositions = T2CStatement.t2cDescribe(this.c_state, this.t2cConnection.queryMetaData1, this.t2cConnection.queryMetaData2, this.t2cConnection.queryMetaData1Offset, this.t2cConnection.queryMetaData2Offset, this.t2cConnection.queryMetaData1Size, this.t2cConnection.queryMetaData2Size, arrayOfByte, arrayOfByte.length, bool1);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2702 */       if (!this.described) {
/* 2703 */         this.described = true;
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2710 */       if (this.numberOfDefinePositions == -1)
/*      */       {
/* 2712 */         this.t2cConnection.checkError(this.numberOfDefinePositions);
/*      */       }
/*      */ 
/*      */       
/* 2716 */       if (this.numberOfDefinePositions != T2C_EXTEND_BUFFER)
/*      */         continue; 
/* 2718 */       bool = true;
/*      */ 
/*      */ 
/*      */       
/* 2722 */       this.t2cConnection.reallocateQueryMetaData(this.t2cConnection.queryMetaData1Size * 2, this.t2cConnection.queryMetaData2Size * 2);
/*      */ 
/*      */     
/*      */     }
/* 2726 */     while (bool);
/*      */     
/* 2728 */     processDescribeData();
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected void configureRowData() {
/* 2734 */     super.configureRowData();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2744 */     DynamicByteArray dynamicByteArray = DynamicByteArray.createDynamicByteArray(this.connection.getBlockSource());
/*      */     
/* 2746 */     T2CCharByteArray t2CCharByteArray1 = new T2CCharByteArray(PhysicalConnection.EMPTY_CHAR_ARRAY, dynamicByteArray);
/*      */     
/* 2748 */     AggregateByteArray aggregateByteArray = new AggregateByteArray(PhysicalConnection.EMPTY_BYTE_ARRAY, t2CCharByteArray1);
/*      */ 
/*      */     
/* 2751 */     T2CCharByteArray t2CCharByteArray2 = new T2CCharByteArray(PhysicalConnection.EMPTY_CHAR_ARRAY, aggregateByteArray);
/*      */ 
/*      */ 
/*      */     
/* 2755 */     this.bindData = new AggregateByteArray(PhysicalConnection.EMPTY_BYTE_ARRAY, t2CCharByteArray2);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 2762 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*      */   public static final String BUILD_DATE = "Thu_Apr_04_15:09:24_PDT_2013";
/*      */   public static final boolean TRACE = false;
/*      */ }


/* Location:              C:\Users\olatu\OneDrive\Documents\Calypso\syncbase\sync_base.jar!\BOOT-INF\lib\ojdbc-7.jar!\oracle\jdbc\driver\T2CPreparedStatement.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */