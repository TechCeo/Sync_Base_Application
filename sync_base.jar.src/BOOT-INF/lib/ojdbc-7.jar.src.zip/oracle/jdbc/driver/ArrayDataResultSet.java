/*      */ package oracle.jdbc.driver;
/*      */ 
/*      */ import java.io.ByteArrayInputStream;
/*      */ import java.io.InputStream;
/*      */ import java.io.Reader;
/*      */ import java.math.BigDecimal;
/*      */ import java.net.URL;
/*      */ import java.sql.Array;
/*      */ import java.sql.Blob;
/*      */ import java.sql.Clob;
/*      */ import java.sql.Connection;
/*      */ import java.sql.Date;
/*      */ import java.sql.NClob;
/*      */ import java.sql.Ref;
/*      */ import java.sql.ResultSet;
/*      */ import java.sql.ResultSetMetaData;
/*      */ import java.sql.RowId;
/*      */ import java.sql.SQLException;
/*      */ import java.sql.SQLXML;
/*      */ import java.sql.Statement;
/*      */ import java.sql.Time;
/*      */ import java.sql.Timestamp;
/*      */ import java.util.Calendar;
/*      */ import java.util.Map;
/*      */ import oracle.jdbc.OracleDataFactory;
/*      */ import oracle.jdbc.OracleResultSet;
/*      */ import oracle.jdbc.internal.OracleConnection;
/*      */ import oracle.sql.ARRAY;
/*      */ import oracle.sql.BFILE;
/*      */ import oracle.sql.BLOB;
/*      */ import oracle.sql.CHAR;
/*      */ import oracle.sql.CLOB;
/*      */ import oracle.sql.CustomDatum;
/*      */ import oracle.sql.CustomDatumFactory;
/*      */ import oracle.sql.DATE;
/*      */ import oracle.sql.Datum;
/*      */ import oracle.sql.INTERVALDS;
/*      */ import oracle.sql.INTERVALYM;
/*      */ import oracle.sql.NUMBER;
/*      */ import oracle.sql.OPAQUE;
/*      */ import oracle.sql.ORAData;
/*      */ import oracle.sql.ORADataFactory;
/*      */ import oracle.sql.RAW;
/*      */ import oracle.sql.REF;
/*      */ import oracle.sql.ROWID;
/*      */ import oracle.sql.STRUCT;
/*      */ import oracle.sql.TIMESTAMP;
/*      */ import oracle.sql.TIMESTAMPLTZ;
/*      */ import oracle.sql.TIMESTAMPTZ;
/*      */ 
/*      */ class ArrayDataResultSet extends OracleResultSet {
/*      */   Datum[] data;
/*      */   
/*      */   ArrayDataResultSet(PhysicalConnection paramPhysicalConnection, Datum[] paramArrayOfDatum, Map paramMap) throws SQLException {
/*   55 */     super(paramPhysicalConnection);
/*      */ 
/*      */     
/*   58 */     this.connection = paramPhysicalConnection;
/*   59 */     this.data = paramArrayOfDatum;
/*   60 */     this.map = paramMap;
/*   61 */     this.currentIndex = 0;
/*   62 */     this.lastIndex = (this.data == null) ? 0 : this.data.length;
/*   63 */     this.fetchSize = OracleConnection.DEFAULT_ROW_PREFETCH;
/*      */   }
/*      */ 
/*      */   
/*      */   Map map;
/*      */   
/*      */   private int currentIndex;
/*      */   
/*      */   private int lastIndex;
/*      */   
/*      */   private Boolean wasNull;
/*      */   
/*      */   private int fetchSize;
/*      */   ARRAY array;
/*      */   
/*      */   ArrayDataResultSet(PhysicalConnection paramPhysicalConnection, Datum[] paramArrayOfDatum, long paramLong, int paramInt, Map paramMap) throws SQLException {
/*   79 */     super(paramPhysicalConnection);
/*      */ 
/*      */     
/*   82 */     this.connection = paramPhysicalConnection;
/*   83 */     this.data = paramArrayOfDatum;
/*   84 */     this.map = paramMap;
/*   85 */     this.currentIndex = (int)paramLong - 1;
/*      */     
/*   87 */     byte b = (this.data == null) ? 0 : this.data.length;
/*      */     
/*   89 */     this.lastIndex = this.currentIndex + Math.min(b - this.currentIndex, paramInt);
/*      */     
/*   91 */     this.fetchSize = OracleConnection.DEFAULT_ROW_PREFETCH;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   ArrayDataResultSet(PhysicalConnection paramPhysicalConnection, ARRAY paramARRAY, long paramLong, int paramInt, Map paramMap) throws SQLException {
/*   98 */     super(paramPhysicalConnection);
/*      */ 
/*      */     
/*  101 */     this.connection = paramPhysicalConnection;
/*  102 */     this.array = paramARRAY;
/*  103 */     this.map = paramMap;
/*  104 */     this.currentIndex = (int)paramLong - 1;
/*      */     
/*  106 */     byte b = (this.array == null) ? 0 : paramARRAY.length();
/*      */     
/*  108 */     this.lastIndex = this.currentIndex + ((paramInt == -1) ? (b - this.currentIndex) : Math.min(b - this.currentIndex, paramInt));
/*      */ 
/*      */     
/*  111 */     this.fetchSize = OracleConnection.DEFAULT_ROW_PREFETCH;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   OracleStatement getOracleStatement() throws SQLException {
/*  125 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   int refreshRows(int paramInt1, int paramInt2) throws SQLException {
/*  139 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 75, "beforeFirst");
/*  140 */     sQLException.fillInStackTrace();
/*  141 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void removeCurrentRowFromCache() throws SQLException {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   int getColumnCount() throws SQLException {
/*  155 */     return 2;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void doneFetchingRows(boolean paramBoolean) throws SQLException {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean next() throws SQLException {
/*  178 */     if (this.closed) {
/*      */       
/*  180 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 10, "next");
/*  181 */       sQLException.fillInStackTrace();
/*  182 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  187 */     this.currentIndex++;
/*      */     
/*  189 */     return (this.currentIndex <= this.lastIndex);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void close() throws SQLException {
/*  195 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  202 */       super.close();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean wasNull() throws SQLException {
/*  209 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  217 */       if (this.wasNull == null) {
/*      */         
/*  219 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 24, (Object)null);
/*  220 */         sQLException.fillInStackTrace();
/*  221 */         throw sQLException;
/*      */       } 
/*      */       
/*  224 */       return this.wasNull.booleanValue();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void beforeFirst() throws SQLException {
/*  241 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 75, "beforeFirst");
/*  242 */     sQLException.fillInStackTrace();
/*  243 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void afterLast() throws SQLException {
/*  256 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 75, "afterLast");
/*  257 */     sQLException.fillInStackTrace();
/*  258 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean first() throws SQLException {
/*  271 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 75, "first");
/*  272 */     sQLException.fillInStackTrace();
/*  273 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean last() throws SQLException {
/*  286 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 75, "last");
/*  287 */     sQLException.fillInStackTrace();
/*  288 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean absolute(int paramInt) throws SQLException {
/*  301 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 75, "absolute");
/*  302 */     sQLException.fillInStackTrace();
/*  303 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean relative(int paramInt) throws SQLException {
/*  316 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 75, "relative");
/*  317 */     sQLException.fillInStackTrace();
/*  318 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean previous() throws SQLException {
/*  331 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 75, "previous");
/*  332 */     sQLException.fillInStackTrace();
/*  333 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getString(int paramInt) throws SQLException {
/*  345 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  353 */       Datum datum = getOracleObject(paramInt);
/*      */       
/*  355 */       if (datum != null) {
/*  356 */         if (datum instanceof TIMESTAMPTZ || datum instanceof TIMESTAMPLTZ) {
/*  357 */           return datum.stringValue((Connection)this.connection);
/*      */         }
/*  359 */         return datum.stringValue();
/*      */       } 
/*      */       
/*  362 */       return null;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public ResultSet getCursor(int paramInt) throws SQLException {
/*  369 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  378 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getCursor");
/*  379 */       sQLException.fillInStackTrace();
/*  380 */       throw sQLException;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Datum getOracleObject(int paramInt) throws SQLException {
/*  396 */     if (this.currentIndex <= 0) {
/*      */       
/*  398 */       SQLException sQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 14, (Object)null);
/*  399 */       sQLException1.fillInStackTrace();
/*  400 */       throw sQLException1;
/*      */     } 
/*      */     
/*  403 */     if (paramInt == 1) {
/*      */       
/*  405 */       this.wasNull = Boolean.FALSE;
/*      */       
/*  407 */       return (Datum)new NUMBER(this.currentIndex);
/*      */     } 
/*  409 */     if (paramInt == 2) {
/*      */       
/*  411 */       if (this.data != null) {
/*      */         
/*  413 */         this.wasNull = (this.data[this.currentIndex - 1] == null) ? Boolean.TRUE : Boolean.FALSE;
/*      */ 
/*      */         
/*  416 */         return this.data[this.currentIndex - 1];
/*      */       } 
/*  418 */       if (this.array != null) {
/*      */ 
/*      */ 
/*      */         
/*  422 */         Datum[] arrayOfDatum = this.array.getOracleArray(this.currentIndex, 1);
/*      */         
/*  424 */         if (arrayOfDatum != null && arrayOfDatum.length >= 1) {
/*      */           
/*  426 */           this.wasNull = (arrayOfDatum[0] == null) ? Boolean.TRUE : Boolean.FALSE;
/*      */           
/*  428 */           return arrayOfDatum[0];
/*      */         } 
/*      */       } 
/*      */ 
/*      */       
/*  433 */       SQLException sQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 1, "Out of sync");
/*  434 */       sQLException1.fillInStackTrace();
/*  435 */       throw sQLException1;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  440 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3, (Object)null);
/*  441 */     sQLException.fillInStackTrace();
/*  442 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ROWID getROWID(int paramInt) throws SQLException {
/*  450 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  458 */       Datum datum = getOracleObject(paramInt);
/*      */       
/*  460 */       if (datum != null) {
/*      */         
/*  462 */         if (datum instanceof ROWID) {
/*  463 */           return (ROWID)datum;
/*      */         }
/*      */         
/*  466 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getROWID");
/*  467 */         sQLException.fillInStackTrace();
/*  468 */         throw sQLException;
/*      */       } 
/*      */ 
/*      */       
/*  472 */       return null;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public NUMBER getNUMBER(int paramInt) throws SQLException {
/*  479 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  487 */       Datum datum = getOracleObject(paramInt);
/*      */       
/*  489 */       if (datum != null) {
/*      */         
/*  491 */         if (datum instanceof NUMBER) {
/*  492 */           return (NUMBER)datum;
/*      */         }
/*      */         
/*  495 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getNUMBER");
/*  496 */         sQLException.fillInStackTrace();
/*  497 */         throw sQLException;
/*      */       } 
/*      */ 
/*      */       
/*  501 */       return null;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public DATE getDATE(int paramInt) throws SQLException {
/*  508 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  516 */       Datum datum = getOracleObject(paramInt);
/*      */       
/*  518 */       if (datum != null) {
/*      */         
/*  520 */         if (datum instanceof DATE) {
/*  521 */           return (DATE)datum;
/*      */         }
/*      */         
/*  524 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getDATE");
/*  525 */         sQLException.fillInStackTrace();
/*  526 */         throw sQLException;
/*      */       } 
/*      */ 
/*      */       
/*  530 */       return null;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public ARRAY getARRAY(int paramInt) throws SQLException {
/*  537 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  545 */       Datum datum = getOracleObject(paramInt);
/*      */       
/*  547 */       if (datum != null) {
/*      */         
/*  549 */         if (datum instanceof ARRAY) {
/*  550 */           return (ARRAY)datum;
/*      */         }
/*      */         
/*  553 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getARRAY");
/*  554 */         sQLException.fillInStackTrace();
/*  555 */         throw sQLException;
/*      */       } 
/*      */ 
/*      */       
/*  559 */       return null;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public STRUCT getSTRUCT(int paramInt) throws SQLException {
/*  566 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  574 */       Datum datum = getOracleObject(paramInt);
/*      */       
/*  576 */       if (datum != null) {
/*      */         
/*  578 */         if (datum instanceof STRUCT) {
/*  579 */           return (STRUCT)datum;
/*      */         }
/*      */         
/*  582 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getSTRUCT");
/*  583 */         sQLException.fillInStackTrace();
/*  584 */         throw sQLException;
/*      */       } 
/*      */ 
/*      */       
/*  588 */       return null;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public OPAQUE getOPAQUE(int paramInt) throws SQLException {
/*  595 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  603 */       Datum datum = getOracleObject(paramInt);
/*      */       
/*  605 */       if (datum != null) {
/*      */         
/*  607 */         if (datum instanceof OPAQUE) {
/*  608 */           return (OPAQUE)datum;
/*      */         }
/*      */         
/*  611 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getOPAQUE");
/*  612 */         sQLException.fillInStackTrace();
/*  613 */         throw sQLException;
/*      */       } 
/*      */ 
/*      */       
/*  617 */       return null;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public REF getREF(int paramInt) throws SQLException {
/*  624 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  632 */       Datum datum = getOracleObject(paramInt);
/*      */       
/*  634 */       if (datum != null) {
/*      */         
/*  636 */         if (datum instanceof REF) {
/*  637 */           return (REF)datum;
/*      */         }
/*      */         
/*  640 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getREF");
/*  641 */         sQLException.fillInStackTrace();
/*  642 */         throw sQLException;
/*      */       } 
/*      */ 
/*      */       
/*  646 */       return null;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public CHAR getCHAR(int paramInt) throws SQLException {
/*  653 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  661 */       Datum datum = getOracleObject(paramInt);
/*      */       
/*  663 */       if (datum != null) {
/*      */         
/*  665 */         if (datum instanceof CHAR) {
/*  666 */           return (CHAR)datum;
/*      */         }
/*      */         
/*  669 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getCHAR");
/*  670 */         sQLException.fillInStackTrace();
/*  671 */         throw sQLException;
/*      */       } 
/*      */ 
/*      */       
/*  675 */       return null;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public RAW getRAW(int paramInt) throws SQLException {
/*  682 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  690 */       Datum datum = getOracleObject(paramInt);
/*      */       
/*  692 */       if (datum != null) {
/*      */         
/*  694 */         if (datum instanceof RAW) {
/*  695 */           return (RAW)datum;
/*      */         }
/*      */         
/*  698 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getRAW");
/*  699 */         sQLException.fillInStackTrace();
/*  700 */         throw sQLException;
/*      */       } 
/*      */ 
/*      */       
/*  704 */       return null;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public BLOB getBLOB(int paramInt) throws SQLException {
/*  711 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  719 */       Datum datum = getOracleObject(paramInt);
/*      */       
/*  721 */       if (datum != null) {
/*      */         
/*  723 */         if (datum instanceof BLOB) {
/*  724 */           return (BLOB)datum;
/*      */         }
/*      */         
/*  727 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getBLOB");
/*  728 */         sQLException.fillInStackTrace();
/*  729 */         throw sQLException;
/*      */       } 
/*      */ 
/*      */       
/*  733 */       return null;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public CLOB getCLOB(int paramInt) throws SQLException {
/*  740 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  748 */       Datum datum = getOracleObject(paramInt);
/*      */       
/*  750 */       if (datum != null) {
/*      */         
/*  752 */         if (datum instanceof CLOB) {
/*  753 */           return (CLOB)datum;
/*      */         }
/*      */         
/*  756 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getCLOB");
/*  757 */         sQLException.fillInStackTrace();
/*  758 */         throw sQLException;
/*      */       } 
/*      */ 
/*      */       
/*  762 */       return null;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public BFILE getBFILE(int paramInt) throws SQLException {
/*  769 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  777 */       Datum datum = getOracleObject(paramInt);
/*      */       
/*  779 */       if (datum != null) {
/*      */         
/*  781 */         if (datum instanceof BFILE) {
/*  782 */           return (BFILE)datum;
/*      */         }
/*      */         
/*  785 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getBFILE");
/*  786 */         sQLException.fillInStackTrace();
/*  787 */         throw sQLException;
/*      */       } 
/*      */ 
/*      */       
/*  791 */       return null;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public INTERVALDS getINTERVALDS(int paramInt) throws SQLException {
/*  798 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  806 */       Datum datum = getOracleObject(paramInt);
/*      */       
/*  808 */       if (datum != null) {
/*      */         
/*  810 */         if (datum instanceof INTERVALDS) {
/*  811 */           return (INTERVALDS)datum;
/*      */         }
/*      */         
/*  814 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4);
/*  815 */         sQLException.fillInStackTrace();
/*  816 */         throw sQLException;
/*      */       } 
/*      */ 
/*      */       
/*  820 */       return null;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public INTERVALYM getINTERVALYM(int paramInt) throws SQLException {
/*  827 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  835 */       Datum datum = getOracleObject(paramInt);
/*      */       
/*  837 */       if (datum != null) {
/*      */         
/*  839 */         if (datum instanceof INTERVALYM) {
/*  840 */           return (INTERVALYM)datum;
/*      */         }
/*      */         
/*  843 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4);
/*  844 */         sQLException.fillInStackTrace();
/*  845 */         throw sQLException;
/*      */       } 
/*      */ 
/*      */       
/*  849 */       return null;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public BFILE getBfile(int paramInt) throws SQLException {
/*  857 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  865 */       return getBFILE(paramInt);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public TIMESTAMP getTIMESTAMP(int paramInt) throws SQLException {
/*  872 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  880 */       Datum datum = getOracleObject(paramInt);
/*      */       
/*  882 */       if (datum != null) {
/*      */         
/*  884 */         if (datum instanceof TIMESTAMP) {
/*  885 */           return (TIMESTAMP)datum;
/*      */         }
/*      */         
/*  888 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getTIMESTAMP");
/*  889 */         sQLException.fillInStackTrace();
/*  890 */         throw sQLException;
/*      */       } 
/*      */ 
/*      */       
/*  894 */       return null;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public TIMESTAMPTZ getTIMESTAMPTZ(int paramInt) throws SQLException {
/*  901 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  909 */       Datum datum = getOracleObject(paramInt);
/*      */       
/*  911 */       if (datum != null) {
/*      */         
/*  913 */         if (datum instanceof TIMESTAMPTZ) {
/*  914 */           return (TIMESTAMPTZ)datum;
/*      */         }
/*      */         
/*  917 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getTIMESTAMPTZ");
/*  918 */         sQLException.fillInStackTrace();
/*  919 */         throw sQLException;
/*      */       } 
/*      */ 
/*      */       
/*  923 */       return null;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public TIMESTAMPLTZ getTIMESTAMPLTZ(int paramInt) throws SQLException {
/*  930 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  938 */       Datum datum = getOracleObject(paramInt);
/*      */       
/*  940 */       if (datum != null) {
/*      */         
/*  942 */         if (datum instanceof TIMESTAMPLTZ) {
/*  943 */           return (TIMESTAMPLTZ)datum;
/*      */         }
/*      */         
/*  946 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getTIMESTAMPLTZ");
/*  947 */         sQLException.fillInStackTrace();
/*  948 */         throw sQLException;
/*      */       } 
/*      */ 
/*      */       
/*  952 */       return null;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean getBoolean(int paramInt) throws SQLException {
/*  959 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  967 */       Datum datum = getOracleObject(paramInt);
/*      */       
/*  969 */       if (datum != null) {
/*  970 */         return datum.booleanValue();
/*      */       }
/*  972 */       return false;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public OracleResultSet.AuthorizationIndicator getAuthorizationIndicator(int paramInt) throws SQLException {
/*  986 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public byte getByte(int paramInt) throws SQLException {
/*  992 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1000 */       Datum datum = getOracleObject(paramInt);
/*      */       
/* 1002 */       if (datum != null) {
/* 1003 */         return datum.byteValue();
/*      */       }
/* 1005 */       return 0;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public short getShort(int paramInt) throws SQLException {
/* 1012 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1020 */       long l = getLong(paramInt);
/*      */       
/* 1022 */       if (l > 65537L || l < -65538L) {
/*      */         
/* 1024 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 26, "getShort");
/* 1025 */         sQLException.fillInStackTrace();
/* 1026 */         throw sQLException;
/*      */       } 
/*      */       
/* 1029 */       return (short)(int)l;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public int getInt(int paramInt) throws SQLException {
/* 1036 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1044 */       Datum datum = getOracleObject(paramInt);
/*      */       
/* 1046 */       if (datum != null)
/*      */       {
/* 1048 */         return datum.intValue();
/*      */       }
/*      */       
/* 1051 */       return 0;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public long getLong(int paramInt) throws SQLException {
/* 1058 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1066 */       Datum datum = getOracleObject(paramInt);
/*      */       
/* 1068 */       if (datum != null)
/*      */       {
/* 1070 */         return datum.longValue();
/*      */       }
/*      */       
/* 1073 */       return 0L;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public float getFloat(int paramInt) throws SQLException {
/* 1080 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1088 */       Datum datum = getOracleObject(paramInt);
/*      */       
/* 1090 */       if (datum != null)
/*      */       {
/* 1092 */         return datum.floatValue();
/*      */       }
/*      */       
/* 1095 */       return 0.0F;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public double getDouble(int paramInt) throws SQLException {
/* 1102 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1110 */       Datum datum = getOracleObject(paramInt);
/*      */       
/* 1112 */       if (datum != null)
/*      */       {
/* 1114 */         return datum.doubleValue();
/*      */       }
/*      */       
/* 1117 */       return 0.0D;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public BigDecimal getBigDecimal(int paramInt1, int paramInt2) throws SQLException {
/* 1125 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1133 */       Datum datum = getOracleObject(paramInt1);
/*      */       
/* 1135 */       if (datum != null)
/*      */       {
/* 1137 */         return datum.bigDecimalValue();
/*      */       }
/*      */       
/* 1140 */       return null;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public byte[] getBytes(int paramInt) throws SQLException {
/* 1147 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1155 */       Datum datum = getOracleObject(paramInt);
/*      */       
/* 1157 */       if (datum != null) {
/*      */         
/* 1159 */         if (datum instanceof RAW) {
/* 1160 */           return ((RAW)datum).shareBytes();
/*      */         }
/*      */         
/* 1163 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getBytes");
/* 1164 */         sQLException.fillInStackTrace();
/* 1165 */         throw sQLException;
/*      */       } 
/*      */ 
/*      */       
/* 1169 */       return null;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public Date getDate(int paramInt) throws SQLException {
/* 1176 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1184 */       Datum datum = getOracleObject(paramInt);
/*      */       
/* 1186 */       if (datum != null)
/*      */       {
/* 1188 */         return datum.dateValue();
/*      */       }
/*      */       
/* 1191 */       return null;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public Time getTime(int paramInt) throws SQLException {
/* 1198 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1206 */       Datum datum = getOracleObject(paramInt);
/*      */       
/* 1208 */       if (datum != null)
/*      */       {
/* 1210 */         return datum.timeValue();
/*      */       }
/*      */       
/* 1213 */       return null;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Timestamp getTimestamp(int paramInt) throws SQLException {
/* 1221 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1229 */       Datum datum = getOracleObject(paramInt);
/*      */       
/* 1231 */       if (datum != null)
/*      */       {
/* 1233 */         return datum.timestampValue();
/*      */       }
/*      */       
/* 1236 */       return null;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public InputStream getAsciiStream(int paramInt) throws SQLException {
/* 1244 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1252 */       Datum datum = getOracleObject(paramInt);
/*      */       
/* 1254 */       if (datum != null)
/*      */       {
/* 1256 */         datum.asciiStreamValue();
/*      */       }
/*      */       
/* 1259 */       return null;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public InputStream getUnicodeStream(int paramInt) throws SQLException {
/* 1267 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1275 */       Datum datum = getOracleObject(paramInt);
/*      */       
/* 1277 */       if (datum != null) {
/*      */         
/* 1279 */         DBConversion dBConversion = this.connection.conversion;
/* 1280 */         byte[] arrayOfByte = datum.shareBytes();
/*      */         
/* 1282 */         if (datum instanceof RAW)
/*      */         {
/* 1284 */           return dBConversion.ConvertStream(new ByteArrayInputStream(arrayOfByte), 3);
/*      */         }
/* 1286 */         if (datum instanceof CHAR)
/*      */         {
/* 1288 */           return dBConversion.ConvertStream(new ByteArrayInputStream(arrayOfByte), 1);
/*      */         }
/*      */ 
/*      */         
/* 1292 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getUnicodeStream");
/* 1293 */         sQLException.fillInStackTrace();
/* 1294 */         throw sQLException;
/*      */       } 
/*      */ 
/*      */       
/* 1298 */       return null;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public InputStream getBinaryStream(int paramInt) throws SQLException {
/* 1306 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1314 */       Datum datum = getOracleObject(paramInt);
/*      */       
/* 1316 */       if (datum != null)
/*      */       {
/* 1318 */         return datum.binaryStreamValue();
/*      */       }
/*      */       
/* 1321 */       return null;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Object getObject(int paramInt, OracleDataFactory paramOracleDataFactory) throws SQLException {
/* 1329 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1336 */       Object object = getObject(paramInt);
/* 1337 */       return paramOracleDataFactory.create(object, 0);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public Object getObject(int paramInt) throws SQLException {
/* 1344 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1353 */       return getObject(paramInt, this.map);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public CustomDatum getCustomDatum(int paramInt, CustomDatumFactory paramCustomDatumFactory) throws SQLException {
/* 1364 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1372 */       Datum datum = getOracleObject(paramInt);
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1377 */       return paramCustomDatumFactory.create(datum, 0);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ORAData getORAData(int paramInt, ORADataFactory paramORADataFactory) throws SQLException {
/* 1385 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1393 */       Datum datum = getOracleObject(paramInt);
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1398 */       return paramORADataFactory.create(datum, 0);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ResultSetMetaData getMetaData() throws SQLException {
/* 1408 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1416 */       if (this.closed) {
/*      */         
/* 1418 */         SQLException sQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 10, "getMetaData");
/* 1419 */         sQLException1.fillInStackTrace();
/* 1420 */         throw sQLException1;
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1426 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 23, "getMetaData");
/* 1427 */       sQLException.fillInStackTrace();
/* 1428 */       throw sQLException;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int findColumn(String paramString) throws SQLException {
/* 1437 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1445 */       if (paramString.equalsIgnoreCase("index"))
/* 1446 */         return 1; 
/* 1447 */       if (paramString.equalsIgnoreCase("value")) {
/* 1448 */         return 2;
/*      */       }
/*      */       
/* 1451 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 6, "get_column_index");
/* 1452 */       sQLException.fillInStackTrace();
/* 1453 */       throw sQLException;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Statement getStatement() throws SQLException {
/* 1473 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Object getObject(int paramInt, Map paramMap) throws SQLException {
/* 1480 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1488 */       Datum datum = getOracleObject(paramInt);
/*      */       
/* 1490 */       if (datum != null) {
/*      */         
/* 1492 */         if (datum instanceof STRUCT) {
/* 1493 */           return ((STRUCT)datum).toJdbc(paramMap);
/*      */         }
/* 1495 */         return datum.toJdbc();
/*      */       } 
/*      */       
/* 1498 */       return null;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public Ref getRef(int paramInt) throws SQLException {
/* 1505 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1513 */       return (Ref)getREF(paramInt);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public Blob getBlob(int paramInt) throws SQLException {
/* 1520 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1528 */       return (Blob)getBLOB(paramInt);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public Clob getClob(int paramInt) throws SQLException {
/* 1535 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1543 */       return (Clob)getCLOB(paramInt);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Array getArray(int paramInt) throws SQLException {
/* 1551 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1559 */       return (Array)getARRAY(paramInt);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Reader getCharacterStream(int paramInt) throws SQLException {
/* 1574 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1582 */       Datum datum = getOracleObject(paramInt);
/*      */       
/* 1584 */       if (datum != null)
/*      */       {
/* 1586 */         return datum.characterStreamValue();
/*      */       }
/*      */       
/* 1589 */       return null;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public BigDecimal getBigDecimal(int paramInt) throws SQLException {
/* 1597 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1605 */       Datum datum = getOracleObject(paramInt);
/*      */       
/* 1607 */       if (datum != null)
/*      */       {
/* 1609 */         return datum.bigDecimalValue();
/*      */       }
/*      */       
/* 1612 */       return null;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Date getDate(int paramInt, Calendar paramCalendar) throws SQLException {
/* 1620 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1628 */       Datum datum = getOracleObject(paramInt);
/*      */       
/* 1630 */       if (datum != null) {
/*      */         
/* 1632 */         DATE dATE = null;
/*      */         
/* 1634 */         if (datum instanceof DATE) {
/* 1635 */           dATE = (DATE)datum;
/*      */         } else {
/* 1637 */           dATE = new DATE(datum.stringValue());
/*      */         } 
/* 1639 */         if (dATE != null) {
/* 1640 */           return dATE.dateValue(paramCalendar);
/*      */         }
/*      */       } 
/* 1643 */       return null;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Time getTime(int paramInt, Calendar paramCalendar) throws SQLException {
/* 1651 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1659 */       Datum datum = getOracleObject(paramInt);
/*      */       
/* 1661 */       if (datum != null) {
/*      */         
/* 1663 */         DATE dATE = null;
/*      */         
/* 1665 */         if (datum instanceof DATE) {
/* 1666 */           dATE = (DATE)datum;
/*      */         } else {
/* 1668 */           dATE = new DATE(datum.stringValue());
/*      */         } 
/* 1670 */         if (dATE != null) {
/* 1671 */           return dATE.timeValue(paramCalendar);
/*      */         }
/*      */       } 
/* 1674 */       return null;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Timestamp getTimestamp(int paramInt, Calendar paramCalendar) throws SQLException {
/* 1682 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1690 */       Datum datum = getOracleObject(paramInt);
/*      */       
/* 1692 */       if (datum != null) {
/*      */         
/* 1694 */         DATE dATE = null;
/*      */         
/* 1696 */         if (datum instanceof DATE) {
/* 1697 */           dATE = (DATE)datum;
/*      */         } else {
/* 1699 */           dATE = new DATE(datum.stringValue());
/*      */         } 
/* 1701 */         if (dATE != null) {
/* 1702 */           return dATE.timestampValue(paramCalendar);
/*      */         }
/*      */       } 
/* 1705 */       return null;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public URL getURL(int paramInt) throws SQLException {
/* 1714 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1756 */       SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException();
/* 1757 */       sQLException.fillInStackTrace();
/* 1758 */       throw sQLException;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getCursorName() throws SQLException {
/* 1766 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1774 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 23, "getCursorName");
/* 1775 */       sQLException.fillInStackTrace();
/* 1776 */       throw sQLException;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public NClob getNClob(int paramInt) throws SQLException {
/* 1791 */     Datum datum = getOracleObject(paramInt);
/*      */     
/* 1793 */     if (datum != null) {
/*      */       
/* 1795 */       if (datum instanceof oracle.sql.NCLOB) {
/* 1796 */         return (NClob)datum;
/*      */       }
/*      */       
/* 1799 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4);
/* 1800 */       sQLException.fillInStackTrace();
/* 1801 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/* 1805 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getNString(int paramInt) throws SQLException {
/* 1817 */     Datum datum = getOracleObject(paramInt);
/*      */     
/* 1819 */     if (datum != null)
/*      */     {
/* 1821 */       return datum.stringValue();
/*      */     }
/*      */     
/* 1824 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Reader getNCharacterStream(int paramInt) throws SQLException {
/* 1837 */     Datum datum = getOracleObject(paramInt);
/*      */     
/* 1839 */     if (datum != null)
/*      */     {
/* 1841 */       return datum.characterStreamValue();
/*      */     }
/*      */     
/* 1844 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public RowId getRowId(int paramInt) throws SQLException {
/* 1856 */     return (RowId)getROWID(paramInt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public SQLXML getSQLXML(int paramInt) throws SQLException {
/* 1869 */     Datum datum = getOracleObject(paramInt);
/*      */     
/* 1871 */     if (datum != null) {
/*      */       
/* 1873 */       if (datum instanceof SQLXML) {
/* 1874 */         return (SQLXML)datum;
/*      */       }
/*      */       
/* 1877 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4);
/* 1878 */       sQLException.fillInStackTrace();
/* 1879 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/* 1883 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <T> T getObject(int paramInt, Class<T> paramClass) throws SQLException {
/* 1893 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1900 */       Object object = getObject(paramInt);
/* 1901 */       if (paramClass.isInstance(object)) return (T)object;
/*      */ 
/*      */       
/* 1904 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4);
/* 1905 */       sQLException.fillInStackTrace();
/* 1906 */       throw sQLException;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isBeforeFirst() throws SQLException {
/* 1928 */     if (this.closed) {
/*      */       
/* 1930 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 10);
/* 1931 */       sQLException.fillInStackTrace();
/* 1932 */       throw sQLException;
/*      */     } 
/* 1934 */     return (this.currentIndex < 1);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isAfterLast() throws SQLException {
/* 1947 */     if (this.closed) {
/*      */       
/* 1949 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 10);
/* 1950 */       sQLException.fillInStackTrace();
/* 1951 */       throw sQLException;
/*      */     } 
/* 1953 */     return (this.currentIndex > this.lastIndex);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isFirst() throws SQLException {
/* 1966 */     if (this.closed) {
/*      */       
/* 1968 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 10);
/* 1969 */       sQLException.fillInStackTrace();
/* 1970 */       throw sQLException;
/*      */     } 
/* 1972 */     return (this.currentIndex == 1);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isLast() throws SQLException {
/* 1985 */     if (this.closed) {
/*      */       
/* 1987 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 10);
/* 1988 */       sQLException.fillInStackTrace();
/* 1989 */       throw sQLException;
/*      */     } 
/* 1991 */     return (this.currentIndex == this.lastIndex);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getRow() throws SQLException {
/* 2004 */     if (this.closed) {
/*      */       
/* 2006 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 10);
/* 2007 */       sQLException.fillInStackTrace();
/* 2008 */       throw sQLException;
/*      */     } 
/* 2010 */     return this.currentIndex;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setFetchSize(int paramInt) throws SQLException {
/* 2027 */     if (paramInt < 0) {
/*      */       
/* 2029 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/* 2030 */       sQLException.fillInStackTrace();
/* 2031 */       throw sQLException;
/*      */     } 
/* 2033 */     if (paramInt == 0) {
/* 2034 */       this.fetchSize = OracleConnection.DEFAULT_ROW_PREFETCH;
/*      */     } else {
/* 2036 */       this.fetchSize = paramInt;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getFetchSize() throws SQLException {
/* 2048 */     return this.fetchSize;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getType() {
/* 2064 */     return 1003;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getConcurrency() {
/* 2080 */     return 1007;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected OracleConnection getConnectionDuringExceptionHandling() {
/* 2095 */     return this.connection;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/* 2100 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*      */   public static final String BUILD_DATE = "Thu_Apr_04_15:09:24_PDT_2013";
/*      */   public static final boolean TRACE = false;
/*      */ }


/* Location:              C:\Users\olatu\OneDrive\Documents\Calypso\syncbase\sync_base.jar!\BOOT-INF\lib\ojdbc-7.jar!\oracle\jdbc\driver\ArrayDataResultSet.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */