/*     */ package oracle.jdbc.driver;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.sql.SQLException;
/*     */ import oracle.jdbc.internal.OracleConnection;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class T4C7Ocommoncall
/*     */   extends T4CTTIfun
/*     */ {
/*     */   T4C7Ocommoncall(T4CConnection paramT4CConnection) {
/*  50 */     super(paramT4CConnection, (byte)3);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void doOLOGOFF() throws SQLException, IOException {
/*  58 */     setFunCode((short)9);
/*  59 */     doRPC();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   void doOROLLBACK() throws SQLException, IOException {
/*  65 */     setFunCode((short)15);
/*  66 */     doRPC();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   void doOCOMMIT() throws SQLException, IOException {
/*  72 */     setFunCode((short)14);
/*  73 */     doRPC();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void marshal() throws IOException {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void processError() throws SQLException {
/*  90 */     if (this.oer.retCode != 2089) {
/*  91 */       this.oer.processError();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected OracleConnection getConnectionDuringExceptionHandling() {
/* 106 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/* 111 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*     */   public static final String BUILD_DATE = "Thu_Apr_04_15:09:24_PDT_2013";
/*     */   public static final boolean TRACE = false;
/*     */ }


/* Location:              C:\Users\olatu\OneDrive\Documents\Calypso\syncbase\sync_base.jar!\BOOT-INF\lib\ojdbc-7.jar!\oracle\jdbc\driver\T4C7Ocommoncall.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */