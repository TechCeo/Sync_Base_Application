/*     */ package oracle.jdbc.driver;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.sql.SQLException;
/*     */ import java.text.DateFormatSymbols;
/*     */ import java.util.TimeZone;
/*     */ import oracle.jdbc.OracleResultSetMetaData;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class T4CTimestampltzAccessor
/*     */   extends TimestampltzAccessor
/*     */ {
/*     */   T4CMAREngine mare;
/*     */   boolean underlyingLongRaw = false;
/*     */   
/*     */   T4CTimestampltzAccessor(OracleStatement paramOracleStatement, int paramInt1, short paramShort, int paramInt2, boolean paramBoolean, T4CMAREngine paramT4CMAREngine) throws SQLException {
/*  42 */     super(paramOracleStatement, paramInt1, paramShort, paramInt2, paramBoolean);
/*     */     
/*  44 */     this.mare = paramT4CMAREngine;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   T4CTimestampltzAccessor(OracleStatement paramOracleStatement, int paramInt1, boolean paramBoolean, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, short paramShort, int paramInt7, int paramInt8, T4CMAREngine paramT4CMAREngine) throws SQLException {
/*  53 */     super(paramOracleStatement, (paramInt1 == -1) ? paramInt8 : paramInt1, paramBoolean, paramInt2, paramInt3, paramInt4, paramInt5, paramInt6, paramShort);
/*     */ 
/*     */     
/*  56 */     this.mare = paramT4CMAREngine;
/*     */ 
/*     */     
/*  59 */     if (paramOracleStatement != null && paramOracleStatement.implicitDefineForLobPrefetchDone) {
/*     */       
/*  61 */       this.definedColumnType = 0;
/*  62 */       this.definedColumnSize = 0;
/*     */     }
/*     */     else {
/*     */       
/*  66 */       this.definedColumnType = paramInt7;
/*  67 */       this.definedColumnSize = paramInt8;
/*     */     } 
/*     */     
/*  70 */     if (paramInt1 == -1)
/*  71 */       this.underlyingLongRaw = true; 
/*     */   }
/*     */   
/*     */   public T4CMAREngine getMAREngine() {
/*  75 */     return this.mare;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void unmarshalColumnMetadata() throws SQLException, IOException {
/*  84 */     if (this.statement.statementType != 2 && !this.statement.sqlKind.isPlsqlOrCall() && this.securityAttribute == OracleResultSetMetaData.SecurityAttribute.ENABLED)
/*     */     {
/*     */       
/*  87 */       setRowMetadata(this.lastRowProcessed, (byte)this.mare.unmarshalUB1());
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void processIndicator(int paramInt) throws IOException, SQLException {
/*  94 */     if ((this.internalType == 1 && this.describeType == 112) || (this.internalType == 23 && this.describeType == 113)) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 101 */       this.mare.unmarshalUB2();
/* 102 */       this.mare.unmarshalUB2();
/*     */     }
/* 104 */     else if (this.statement.connection.versionNumber < 9200) {
/*     */ 
/*     */ 
/*     */       
/* 108 */       this.mare.unmarshalSB2();
/*     */       
/* 110 */       if (!this.statement.sqlKind.isPlsqlOrCall()) {
/* 111 */         this.mare.unmarshalSB2();
/*     */       }
/* 113 */     } else if (this.statement.sqlKind.isPlsqlOrCall() || this.isDMLReturnedParam) {
/* 114 */       this.mare.processIndicator((paramInt <= 0), paramInt);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   int getPreviousRowProcessed() {
/* 120 */     if (this.previousRowProcessed == -1) this.previousRowProcessed = this.statement.rowPrefetchInLastFetch - 1; 
/* 121 */     return this.previousRowProcessed;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean unmarshalOneRow() throws SQLException, IOException {
/* 136 */     boolean bool = false;
/* 137 */     if (!isUseless())
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 143 */       if (isUnexpected()) {
/*     */ 
/*     */         
/* 146 */         long l = this.rowData.getPosition();
/* 147 */         unmarshalColumnMetadata();
/* 148 */         unmarshalBytes();
/* 149 */         this.rowData.setPosition(l);
/* 150 */         setNull(this.lastRowProcessed, true);
/*     */       }
/* 152 */       else if (isNullByDescribe()) {
/*     */ 
/*     */         
/* 155 */         setNull(this.lastRowProcessed, true);
/* 156 */         unmarshalColumnMetadata();
/* 157 */         if (this.statement.connection.versionNumber < 9200) processIndicator(0);
/*     */       
/*     */       } else {
/*     */         
/* 161 */         unmarshalColumnMetadata();
/* 162 */         bool = unmarshalBytes();
/*     */       }  } 
/* 164 */     this.previousRowProcessed = this.lastRowProcessed;
/* 165 */     this.lastRowProcessed++;
/* 166 */     return bool;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean unmarshalBytes() throws SQLException, IOException {
/*     */     int i;
/* 178 */     setOffset(this.lastRowProcessed);
/* 179 */     if (this.statement.maxFieldSize > 0) {
/* 180 */       i = ((DynamicByteArray)this.rowData).unmarshalCLR(this.mare, this.statement.maxFieldSize);
/*     */     } else {
/* 182 */       i = ((DynamicByteArray)this.rowData).unmarshalCLR(this.mare);
/* 183 */     }  processIndicator(i);
/* 184 */     setLength(this.lastRowProcessed, i);
/* 185 */     setNull(this.lastRowProcessed, (i == 0));
/* 186 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void copyRow() throws SQLException, IOException {
/* 195 */     if (this.isNullByDescribe) {
/* 196 */       setNull(this.lastRowProcessed, true);
/*     */     }
/* 198 */     else if (this.lastRowProcessed == 0) {
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 203 */       if (this.previousRowProcessed == -1)
/* 204 */         this.previousRowProcessed = this.statement.rowPrefetchInLastFetch - 1; 
/* 205 */       long l = getOffset(this.previousRowProcessed);
/* 206 */       setNull(this.lastRowProcessed, isNull(this.previousRowProcessed));
/* 207 */       this.rowMetadata[this.lastRowProcessed] = this.rowMetadata[this.previousRowProcessed];
/* 208 */       if (!isNull(this.previousRowProcessed)) {
/* 209 */         setOffset(this.lastRowProcessed);
/* 210 */         ((DynamicByteArray)this.rowData).copyLeft(l, getLength(this.previousRowProcessed));
/* 211 */         setLength(this.lastRowProcessed, getLength(this.previousRowProcessed));
/*     */       }
/*     */     
/*     */     } else {
/*     */       
/* 216 */       setNull(this.lastRowProcessed, isNull(this.previousRowProcessed));
/* 217 */       this.rowMetadata[this.lastRowProcessed] = this.rowMetadata[this.previousRowProcessed];
/* 218 */       setOffset(this.lastRowProcessed, getOffset(this.previousRowProcessed));
/* 219 */       setLength(this.lastRowProcessed, getLength(this.previousRowProcessed));
/*     */     } 
/* 221 */     this.previousRowProcessed = this.lastRowProcessed;
/* 222 */     this.lastRowProcessed++;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   String toText(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, boolean paramBoolean, String paramString) throws SQLException {
/* 247 */     if (this.definedColumnType == 0 || this.definedColumnType == -102)
/*     */     {
/*     */       
/* 250 */       return super.toText(paramInt1, paramInt2, paramInt3, paramInt4, paramInt5, paramInt6, paramInt7, paramBoolean, paramString);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 258 */     String str = (String)this.statement.connection.sessionProperties.get("AUTH_NLS_LXCSTMPFM");
/* 259 */     return nlsFormatToText(paramInt1, paramInt2, paramInt3, paramInt4, paramInt5, paramInt6, paramInt7, paramBoolean, paramString, str);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final String nlsFormatToText(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, boolean paramBoolean, String paramString1, String paramString2) throws SQLException {
/* 286 */     char[] arrayOfChar = (paramString2 + "      ").toCharArray();
/* 287 */     int i = paramString2.length();
/*     */     
/* 289 */     StringBuffer stringBuffer = new StringBuffer(i + 25);
/* 290 */     String[] arrayOfString1 = null;
/* 291 */     String[] arrayOfString2 = null;
/* 292 */     TimeZone timeZone = null;
/*     */ 
/*     */     
/* 295 */     for (byte b = 0; b < i; b++) {
/*     */       
/* 297 */       switch (arrayOfChar[b]) {
/*     */         
/*     */         case 'R':
/*     */         case 'r':
/* 301 */           if (arrayOfChar[b + 1] == 'R' || arrayOfChar[b + 1] == 'r') {
/*     */             
/* 303 */             if ((arrayOfChar[b + 2] == 'R' || arrayOfChar[b + 2] == 'r') && (arrayOfChar[b + 3] == 'R' || arrayOfChar[b + 3] == 'r')) {
/*     */ 
/*     */               
/* 306 */               if (paramInt1 < 1000) {
/* 307 */                 stringBuffer.append("0" + paramInt1);
/* 308 */               } else if (paramInt1 < 100) {
/* 309 */                 stringBuffer.append("00" + paramInt1);
/* 310 */               } else if (paramInt1 < 10) {
/* 311 */                 stringBuffer.append("000" + paramInt1);
/*     */               } else {
/* 313 */                 stringBuffer.append(paramInt1);
/*     */               } 
/* 315 */               b += 3;
/*     */               
/*     */               break;
/*     */             } 
/* 319 */             if (paramInt1 >= 100) {
/* 320 */               paramInt1 %= 100;
/*     */             }
/* 322 */             if (paramInt1 < 10) {
/* 323 */               stringBuffer.append("0" + paramInt1);
/*     */             } else {
/* 325 */               stringBuffer.append(paramInt1);
/*     */             } 
/* 327 */             b++;
/*     */           } 
/*     */           break;
/*     */ 
/*     */         
/*     */         case 'Y':
/*     */         case 'y':
/* 334 */           if (arrayOfChar[b + 1] == 'Y' || arrayOfChar[b + 1] == 'y') {
/*     */             
/* 336 */             if ((arrayOfChar[b + 2] == 'Y' || arrayOfChar[b + 2] == 'y') && (arrayOfChar[b + 3] == 'Y' || arrayOfChar[b + 3] == 'y')) {
/*     */ 
/*     */               
/* 339 */               if (paramInt1 < 1000) {
/* 340 */                 stringBuffer.append("0" + paramInt1);
/* 341 */               } else if (paramInt1 < 100) {
/* 342 */                 stringBuffer.append("00" + paramInt1);
/* 343 */               } else if (paramInt1 < 10) {
/* 344 */                 stringBuffer.append("000" + paramInt1);
/*     */               } else {
/* 346 */                 stringBuffer.append(paramInt1);
/*     */               } 
/* 348 */               b += 3;
/*     */               
/*     */               break;
/*     */             } 
/* 352 */             if (paramInt1 >= 100) {
/* 353 */               paramInt1 %= 100;
/*     */             }
/* 355 */             if (paramInt1 < 10) {
/* 356 */               stringBuffer.append("0" + paramInt1);
/*     */             } else {
/* 358 */               stringBuffer.append(paramInt1);
/*     */             } 
/* 360 */             b++;
/*     */           } 
/*     */           break;
/*     */ 
/*     */         
/*     */         case 'D':
/*     */         case 'd':
/* 367 */           if (arrayOfChar[b + 1] == 'D' || arrayOfChar[b + 1] == 'd') {
/*     */             
/* 369 */             stringBuffer.append(((paramInt3 < 10) ? "0" : "") + paramInt3);
/* 370 */             b++;
/*     */           } 
/*     */           break;
/*     */         
/*     */         case 'M':
/*     */         case 'm':
/* 376 */           if (arrayOfChar[b + 1] == 'M' || arrayOfChar[b + 1] == 'm') {
/*     */             
/* 378 */             stringBuffer.append(((paramInt2 < 10) ? "0" : "") + paramInt2);
/* 379 */             b++; break;
/*     */           } 
/* 381 */           if (arrayOfChar[b + 1] == 'I' || arrayOfChar[b + 1] == 'i') {
/*     */             
/* 383 */             stringBuffer.append(((paramInt5 < 10) ? "0" : "") + paramInt5);
/* 384 */             b++; break;
/*     */           } 
/* 386 */           if ((arrayOfChar[b + 1] == 'O' || arrayOfChar[b + 1] == 'o') && (arrayOfChar[b + 2] == 'N' || arrayOfChar[b + 2] == 'n')) {
/*     */ 
/*     */             
/* 389 */             if ((arrayOfChar[b + 3] == 'T' || arrayOfChar[b + 3] == 't') && (arrayOfChar[b + 4] == 'H' || arrayOfChar[b + 4] == 'h')) {
/*     */ 
/*     */ 
/*     */               
/* 393 */               if (arrayOfString2 == null) {
/* 394 */                 arrayOfString2 = (new DateFormatSymbols()).getMonths();
/*     */               }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */               
/* 401 */               if (arrayOfChar[b] == 'm') {
/*     */ 
/*     */                 
/* 404 */                 stringBuffer.append(arrayOfString2[paramInt2 - 1].toLowerCase());
/*     */               }
/* 406 */               else if (arrayOfChar[b + 1] == 'O') {
/*     */ 
/*     */                 
/* 409 */                 stringBuffer.append(arrayOfString2[paramInt2 - 1].toUpperCase());
/*     */               
/*     */               }
/*     */               else {
/*     */                 
/* 414 */                 stringBuffer.append(arrayOfString2[paramInt2 - 1]);
/*     */               } 
/* 416 */               b += 4;
/*     */               
/*     */               break;
/*     */             } 
/*     */             
/* 421 */             if (arrayOfString1 == null) {
/* 422 */               arrayOfString1 = (new DateFormatSymbols()).getShortMonths();
/*     */             }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */             
/* 429 */             if (arrayOfChar[b] == 'm') {
/*     */ 
/*     */               
/* 432 */               stringBuffer.append(arrayOfString1[paramInt2 - 1].toLowerCase());
/*     */             }
/* 434 */             else if (arrayOfChar[b + 1] == 'O') {
/*     */ 
/*     */               
/* 437 */               stringBuffer.append(arrayOfString1[paramInt2 - 1].toUpperCase());
/*     */             
/*     */             }
/*     */             else {
/*     */               
/* 442 */               stringBuffer.append(arrayOfString1[paramInt2 - 1]);
/*     */             } 
/* 444 */             b += 2;
/*     */           } 
/*     */           break;
/*     */ 
/*     */         
/*     */         case 'H':
/*     */         case 'h':
/* 451 */           if (arrayOfChar[b + 1] == 'H' || arrayOfChar[b + 1] == 'h') {
/*     */             
/* 453 */             if (arrayOfChar[b + 2] == '2' || arrayOfChar[b + 3] == '4') {
/*     */               
/* 455 */               stringBuffer.append(((paramInt4 < 10) ? "0" : "") + paramInt4);
/* 456 */               b += 3;
/*     */               break;
/*     */             } 
/* 459 */             if (paramInt4 > 12)
/* 460 */               paramInt4 -= 12; 
/* 461 */             stringBuffer.append(((paramInt4 < 10) ? "0" : "") + paramInt4);
/* 462 */             b++;
/*     */           } 
/*     */           break;
/*     */ 
/*     */         
/*     */         case 'S':
/*     */         case 's':
/* 469 */           if (arrayOfChar[b + 1] == 'S' || arrayOfChar[b + 1] == 's') {
/*     */             
/* 471 */             stringBuffer.append(((paramInt6 < 10) ? "0" : "") + paramInt6);
/* 472 */             b++;
/* 473 */             if ((arrayOfChar[b + 1] == 'X' || arrayOfChar[b + 1] == 'x') && (arrayOfChar[b + 2] == 'F' || arrayOfChar[b + 2] == 'f') && (arrayOfChar[b + 3] == 'F' || arrayOfChar[b + 3] == 'f')) {
/*     */ 
/*     */ 
/*     */               
/* 477 */               stringBuffer.append(".");
/* 478 */               b++;
/*     */             } 
/*     */           } 
/*     */           break;
/*     */ 
/*     */         
/*     */         case 'F':
/*     */         case 'f':
/* 486 */           if (arrayOfChar[b + 1] == 'F' || arrayOfChar[b + 1] == 'f') {
/*     */             
/* 488 */             if (paramInt7 >= 0) {
/*     */               
/* 490 */               stringBuffer.append(paramInt7);
/*     */             }
/*     */             else {
/*     */               
/* 494 */               stringBuffer.append(0);
/*     */             } 
/* 496 */             b++;
/*     */           } 
/*     */           break;
/*     */         
/*     */         case 'T':
/*     */         case 't':
/* 502 */           if (arrayOfChar[b + 1] == 'Z' || arrayOfChar[b + 1] == 'z') {
/*     */             
/* 504 */             if (arrayOfChar[b + 2] == 'R' || arrayOfChar[b + 2] == 'r') {
/*     */               
/* 506 */               if (paramString1.length() > 3 && paramString1.startsWith("GMT")) {
/*     */                 
/* 508 */                 stringBuffer.append(paramString1.substring(3));
/*     */               
/*     */               }
/*     */               else {
/*     */                 
/* 513 */                 stringBuffer.append(paramString1.toUpperCase());
/*     */               } 
/* 515 */               b += 2; break;
/* 516 */             }  if (arrayOfChar[b + 2] == 'H' || arrayOfChar[b + 2] == 'h') {
/*     */               
/* 518 */               if (timeZone == null)
/* 519 */                 timeZone = TimeZone.getTimeZone(paramString1); 
/* 520 */               long l = (timeZone.getRawOffset() / 3600000);
/* 521 */               stringBuffer.append(l);
/* 522 */               b += 2; break;
/* 523 */             }  if (arrayOfChar[b + 2] == 'M' || arrayOfChar[b + 2] == 'm') {
/*     */               
/* 525 */               if (timeZone == null)
/* 526 */                 timeZone = TimeZone.getTimeZone(paramString1); 
/* 527 */               long l = (Math.abs(timeZone.getRawOffset()) % 3600000 / 60000);
/* 528 */               stringBuffer.append(((l < 10L) ? "0" : "") + l);
/* 529 */               b += 2;
/*     */             } 
/*     */           } 
/*     */           break;
/*     */         
/*     */         case 'A':
/*     */         case 'P':
/*     */         case 'a':
/*     */         case 'p':
/* 538 */           if (arrayOfChar[b + 1] == 'M' || arrayOfChar[b + 1] == 'm') {
/*     */             
/* 540 */             stringBuffer.append(paramBoolean ? "AM" : "PM");
/* 541 */             b++;
/*     */           } 
/*     */           break;
/*     */         
/*     */         default:
/* 546 */           stringBuffer.append(arrayOfChar[b]);
/*     */           break;
/*     */       } 
/*     */ 
/*     */     
/*     */     } 
/* 552 */     return stringBuffer.substring(0, stringBuffer.length());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Object getObject(int paramInt) throws SQLException {
/* 561 */     if (this.definedColumnType == 0) return super.getObject(paramInt); 
/* 562 */     if (isUnexpected()) {
/* 563 */       SQLException sQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
/* 564 */       sQLException1.fillInStackTrace();
/* 565 */       throw sQLException1;
/*     */     } 
/* 567 */     if (isNull(paramInt)) return null;
/*     */     
/* 569 */     switch (this.definedColumnType) {
/*     */       
/*     */       case -15:
/*     */       case -9:
/*     */       case -1:
/*     */       case 1:
/*     */       case 12:
/* 576 */         return getString(paramInt);
/*     */       
/*     */       case 93:
/* 579 */         return getTimestamp(paramInt);
/*     */       
/*     */       case -102:
/* 582 */         return getTIMESTAMPLTZ(paramInt);
/*     */       
/*     */       case 91:
/* 585 */         return getDate(paramInt);
/*     */       
/*     */       case 92:
/* 588 */         return getTime(paramInt);
/*     */       
/*     */       case -4:
/*     */       case -3:
/*     */       case -2:
/* 593 */         return getBytes(paramInt);
/*     */     } 
/*     */ 
/*     */     
/* 597 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4);
/* 598 */     sQLException.fillInStackTrace();
/* 599 */     throw sQLException;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 607 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*     */   public static final String BUILD_DATE = "Thu_Apr_04_15:09:24_PDT_2013";
/*     */   public static final boolean TRACE = false;
/*     */ }


/* Location:              C:\Users\olatu\OneDrive\Documents\Calypso\syncbase\sync_base.jar!\BOOT-INF\lib\ojdbc-7.jar!\oracle\jdbc\driver\T4CTimestampltzAccessor.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */