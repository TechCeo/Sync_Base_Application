/*     */ package oracle.jdbc.driver;
/*     */ 
/*     */ import java.sql.SQLException;
/*     */ import java.util.Map;
/*     */ import oracle.sql.Datum;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class DateAccessor
/*     */   extends DateTimeCommonAccessor
/*     */ {
/*     */   static final int MAXLENGTH = 7;
/*     */   
/*     */   DateAccessor(OracleStatement paramOracleStatement, int paramInt1, short paramShort, int paramInt2, boolean paramBoolean) throws SQLException {
/*  28 */     super(Representation.DATE, paramOracleStatement, 7, paramBoolean);
/*     */     
/*  30 */     init(paramOracleStatement, 12, 12, paramShort, paramBoolean);
/*  31 */     initForDataAccess(paramInt2, paramInt1, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   DateAccessor(OracleStatement paramOracleStatement, int paramInt1, boolean paramBoolean, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, short paramShort) throws SQLException {
/*  39 */     super(Representation.DATE, paramOracleStatement, 7, false);
/*     */     
/*  41 */     init(paramOracleStatement, 12, 12, paramShort, false);
/*  42 */     initForDescribe(12, paramInt1, paramBoolean, paramInt2, paramInt3, paramInt4, paramInt5, paramInt6, paramShort, null);
/*     */     
/*  44 */     initForDataAccess(0, paramInt1, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   String getString(int paramInt) throws SQLException {
/*  52 */     String str = null;
/*  53 */     if (isNull(paramInt)) return null;
/*     */     
/*  55 */     if (this.externalType == 0) {
/*     */ 
/*     */       
/*  58 */       if (this.statement.connection.mapDateToTimestamp)
/*     */       {
/*  60 */         str = getTimestamp(paramInt).toString();
/*     */       }
/*     */       else
/*     */       {
/*  64 */         str = getDate(paramInt).toString();
/*     */       }
/*     */     
/*     */     } else {
/*     */       
/*  69 */       getBytesInternal(paramInt, this.tmpBytes);
/*     */       
/*  71 */       int i = oracleYear(this.tmpBytes);
/*  72 */       int j = 0;
/*  73 */       str = toText(i, this.tmpBytes[2], this.tmpBytes[3], j = this.tmpBytes[4] - 1, this.tmpBytes[5] - 1, this.tmpBytes[6] - 1, -1, (j < 12), (String)null);
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  84 */     return str;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Object getObject(int paramInt) throws SQLException {
/*  92 */     if (isNull(paramInt)) return null;
/*     */     
/*  94 */     if (this.externalType == 0) {
/*     */ 
/*     */       
/*  97 */       if (this.statement.connection.mapDateToTimestamp) {
/*  98 */         return getTimestamp(paramInt);
/*     */       }
/* 100 */       return getDate(paramInt);
/*     */     } 
/*     */ 
/*     */     
/* 104 */     switch (this.externalType) {
/*     */       
/*     */       case 91:
/* 107 */         return getDate(paramInt);
/*     */       case 92:
/* 109 */         return getTime(paramInt);
/*     */       case 93:
/* 111 */         return getTimestamp(paramInt);
/*     */     } 
/*     */     
/* 114 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4);
/*     */     
/* 116 */     sQLException.fillInStackTrace();
/* 117 */     throw sQLException;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Datum getOracleObject(int paramInt) throws SQLException {
/* 129 */     return (Datum)getDATE(paramInt);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Object getObject(int paramInt, Map paramMap) throws SQLException {
/* 137 */     return getObject(paramInt);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/* 142 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*     */   public static final String BUILD_DATE = "Thu_Apr_04_15:09:24_PDT_2013";
/*     */   public static final boolean TRACE = false;
/*     */ }


/* Location:              C:\Users\olatu\OneDrive\Documents\Calypso\syncbase\sync_base.jar!\BOOT-INF\lib\ojdbc-7.jar!\oracle\jdbc\driver\DateAccessor.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */