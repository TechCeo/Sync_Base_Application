/*    */ package oracle.jdbc.driver;
/*    */ 
/*    */ import java.sql.SQLException;
/*    */ import oracle.jdbc.LogicalTransactionId;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class LogicalTransactionId
/*    */   implements LogicalTransactionId
/*    */ {
/*    */   byte[] ltxid;
/*    */   
/*    */   LogicalTransactionId(byte[] paramArrayOfbyte) {
/* 39 */     this.ltxid = paramArrayOfbyte;
/*    */   }
/*    */ 
/*    */   
/*    */   public byte[] getBytes() throws SQLException {
/* 44 */     return this.ltxid;
/*    */   }
/*    */ }


/* Location:              C:\Users\olatu\OneDrive\Documents\Calypso\syncbase\sync_base.jar!\BOOT-INF\lib\ojdbc-7.jar!\oracle\jdbc\driver\LogicalTransactionId.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */