/*    */ package oracle.jdbc.driver;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.sql.SQLException;
/*    */ import oracle.jdbc.internal.KeywordValueLong;
/*    */ import oracle.jdbc.internal.XSKeyval;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class XSKeyvalI
/*    */   extends XSKeyval
/*    */ {
/* 30 */   KeywordValueLongI[] kpxskvlvl = null;
/* 31 */   long kpxskvlflg = 0L;
/*    */ 
/*    */ 
/*    */   
/*    */   private void setKeyval(KeywordValueLongI[] paramArrayOfKeywordValueLongI) throws SQLException {
/* 36 */     this.kpxskvlvl = paramArrayOfKeywordValueLongI;
/*    */   }
/*    */ 
/*    */   
/*    */   public void setKeyval(KeywordValueLong[] paramArrayOfKeywordValueLong) throws SQLException {
/* 41 */     if (paramArrayOfKeywordValueLong != null) {
/*    */       
/* 43 */       this.kpxskvlvl = new KeywordValueLongI[paramArrayOfKeywordValueLong.length];
/* 44 */       for (byte b = 0; b < paramArrayOfKeywordValueLong.length; b++)
/* 45 */         this.kpxskvlvl[b] = (KeywordValueLongI)paramArrayOfKeywordValueLong[b]; 
/*    */     } 
/*    */   }
/*    */   
/*    */   public void setFlag(long paramLong) throws SQLException {
/* 50 */     this.kpxskvlflg = paramLong;
/*    */   }
/*    */ 
/*    */   
/*    */   public KeywordValueLong[] getKeyval() {
/* 55 */     return (KeywordValueLong[])this.kpxskvlvl;
/*    */   }
/*    */   
/*    */   public long getFlag() {
/* 59 */     return this.kpxskvlflg;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   void marshal(T4CMAREngine paramT4CMAREngine) throws IOException {
/* 65 */     if (this.kpxskvlvl != null) {
/*    */       
/* 67 */       paramT4CMAREngine.marshalUB4(this.kpxskvlvl.length);
/* 68 */       for (byte b = 0; b < this.kpxskvlvl.length; b++) {
/* 69 */         this.kpxskvlvl[b].marshal(paramT4CMAREngine);
/*    */       }
/*    */     } else {
/* 72 */       paramT4CMAREngine.marshalUB4(0L);
/*    */     } 
/* 74 */     paramT4CMAREngine.marshalUB4(this.kpxskvlflg);
/*    */   }
/*    */   
/*    */   static XSKeyvalI unmarshal(T4CMAREngine paramT4CMAREngine) throws SQLException, IOException {
/* 78 */     int i = (int)paramT4CMAREngine.unmarshalUB4();
/* 79 */     if (i > 0)
/* 80 */       paramT4CMAREngine.unmarshalUB1(); 
/* 81 */     KeywordValueLongI[] arrayOfKeywordValueLongI = new KeywordValueLongI[i]; int j;
/* 82 */     for (j = 0; j < i; j++)
/*    */     {
/* 84 */       arrayOfKeywordValueLongI[j] = KeywordValueLongI.unmarshal(paramT4CMAREngine);
/*    */     }
/* 86 */     j = (int)paramT4CMAREngine.unmarshalUB4();
/*    */     
/* 88 */     XSKeyvalI xSKeyvalI = new XSKeyvalI();
/* 89 */     xSKeyvalI.setKeyval(arrayOfKeywordValueLongI);
/* 90 */     xSKeyvalI.setFlag(j);
/* 91 */     return xSKeyvalI;
/*    */   }
/*    */ }


/* Location:              C:\Users\olatu\OneDrive\Documents\Calypso\syncbase\sync_base.jar!\BOOT-INF\lib\ojdbc-7.jar!\oracle\jdbc\driver\XSKeyvalI.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */