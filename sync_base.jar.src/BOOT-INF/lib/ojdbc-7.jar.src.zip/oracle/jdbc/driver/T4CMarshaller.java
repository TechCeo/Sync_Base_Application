/*     */ package oracle.jdbc.driver;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.sql.SQLException;
/*     */ import oracle.jdbc.internal.OracleConnection;
/*     */ import oracle.net.ns.BreakNetException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ abstract class T4CMarshaller
/*     */ {
/*  27 */   private static final T4CMarshaller BASIC = new BasicMarshaller();
/*  28 */   private static final T4CMarshaller STREAM = new StreamMarshaller();
/*     */   
/*  30 */   static final T4CMarshaller CHAR = BASIC;
/*  31 */   static final T4CMarshaller LONG_RAW = STREAM;
/*  32 */   static final T4CMarshaller RAW = BASIC;
/*  33 */   static final T4CMarshaller VARCHAR = BASIC;
/*  34 */   static final T4CMarshaller LONG = STREAM;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private T4CMarshaller() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final class BasicMarshaller
/*     */     extends T4CMarshaller
/*     */   {
/*     */     private BasicMarshaller() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     boolean unmarshalOneRow(Accessor param1Accessor) throws SQLException, IOException {
/*  73 */       T4CAccessor t4CAccessor = (T4CAccessor)param1Accessor;
/*     */       
/*  75 */       boolean bool = false;
/*  76 */       if (!param1Accessor.isUseless())
/*     */       {
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*  82 */         if (param1Accessor.isUnexpected()) {
/*     */ 
/*     */           
/*  85 */           long l = param1Accessor.rowData.getPosition();
/*  86 */           t4CAccessor.unmarshalColumnMetadata();
/*  87 */           unmarshalBytes(param1Accessor);
/*  88 */           param1Accessor.rowData.setPosition(l);
/*  89 */           param1Accessor.setNull(param1Accessor.lastRowProcessed, true);
/*     */         }
/*  91 */         else if (param1Accessor.isNullByDescribe()) {
/*     */ 
/*     */           
/*  94 */           param1Accessor.setNull(param1Accessor.lastRowProcessed, true);
/*  95 */           t4CAccessor.unmarshalColumnMetadata();
/*  96 */           if (param1Accessor.statement.connection.versionNumber < 9200) t4CAccessor.processIndicator(0);
/*     */         
/*     */         } else {
/*     */           
/* 100 */           t4CAccessor.unmarshalColumnMetadata();
/* 101 */           bool = unmarshalBytes(param1Accessor);
/*     */         }  } 
/* 103 */       param1Accessor.previousRowProcessed = param1Accessor.lastRowProcessed;
/* 104 */       param1Accessor.lastRowProcessed++;
/* 105 */       return bool;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private boolean unmarshalBytes(Accessor param1Accessor) throws SQLException, IOException {
/*     */       int i;
/* 116 */       T4CAccessor t4CAccessor = (T4CAccessor)param1Accessor;
/* 117 */       T4CMAREngine t4CMAREngine = t4CAccessor.getMAREngine();
/*     */ 
/*     */       
/* 120 */       param1Accessor.setOffset(param1Accessor.lastRowProcessed);
/* 121 */       if (param1Accessor.statement.maxFieldSize > 0) {
/* 122 */         i = ((DynamicByteArray)param1Accessor.rowData).unmarshalCLR(t4CMAREngine, param1Accessor.statement.maxFieldSize);
/*     */       } else {
/* 124 */         i = ((DynamicByteArray)param1Accessor.rowData).unmarshalCLR(t4CMAREngine);
/* 125 */       }  t4CAccessor.processIndicator(i);
/* 126 */       param1Accessor.setLength(param1Accessor.lastRowProcessed, i);
/* 127 */       param1Accessor.setNull(param1Accessor.lastRowProcessed, (i == 0));
/* 128 */       return false;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     int readStreamFromWire(byte[] param1ArrayOfbyte, int param1Int1, int param1Int2, int[] param1ArrayOfint, boolean[] param1ArrayOfboolean1, boolean[] param1ArrayOfboolean2, T4CMAREngine param1T4CMAREngine, T4CTTIoer param1T4CTTIoer) throws SQLException, IOException {
/* 141 */       return -1;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final class StreamMarshaller
/*     */     extends T4CMarshaller
/*     */   {
/*     */     private StreamMarshaller() {}
/*     */ 
/*     */ 
/*     */     
/*     */     boolean unmarshalOneRow(Accessor param1Accessor) throws SQLException, IOException {
/* 156 */       T4CAccessor t4CAccessor = (T4CAccessor)param1Accessor;
/* 157 */       T4CMAREngine t4CMAREngine = t4CAccessor.getMAREngine();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 163 */       if (param1Accessor.isUseless()) {
/* 164 */         param1Accessor.lastRowProcessed++;
/* 165 */         return false;
/*     */       } 
/*     */       
/* 168 */       boolean bool = false;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 174 */       param1Accessor.escapeSequenceArr[0] = t4CMAREngine.unmarshalUB1();
/*     */ 
/*     */       
/* 177 */       if (t4CMAREngine.escapeSequenceNull(param1Accessor.escapeSequenceArr[0])) {
/*     */         
/* 179 */         param1Accessor.setNull(param1Accessor.lastRowProcessed, true);
/* 180 */         t4CMAREngine.processIndicator(false, 0);
/* 181 */         int i = (int)t4CMAREngine.unmarshalUB4();
/*     */         
/* 183 */         param1Accessor.escapeSequenceArr[0] = 0;
/* 184 */         param1Accessor.previousRowProcessed = param1Accessor.lastRowProcessed;
/* 185 */         param1Accessor.lastRowProcessed++;
/*     */       }
/*     */       else {
/*     */         
/* 189 */         param1Accessor.setNull(param1Accessor.lastRowProcessed, false);
/* 190 */         param1Accessor.readHeaderArr[0] = true;
/* 191 */         param1Accessor.readAsNonStreamArr[0] = false;
/*     */ 
/*     */         
/* 194 */         if (param1Accessor.statement.isFetchStreams || param1Accessor.definedColumnType == -2 || param1Accessor.definedColumnType == 12 || param1Accessor.definedColumnType == 1) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 201 */           int i = 0;
/* 202 */           int j = 0;
/* 203 */           byte[] arrayOfByte = param1Accessor.statement.connection.getByteBuffer(32768);
/* 204 */           param1Accessor.setOffset(param1Accessor.lastRowProcessed);
/* 205 */           while (i != -1) {
/* 206 */             i = readStreamFromWire(arrayOfByte, 0, 32768, param1Accessor.escapeSequenceArr, param1Accessor.readHeaderArr, param1Accessor.readAsNonStreamArr, t4CMAREngine, ((T4CConnection)param1Accessor.statement.connection).oer);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */             
/* 214 */             if (i != -1) {
/* 215 */               if (param1Accessor.statement.connection.checksumMode.needToCalculateFetchChecksum()) {
/* 216 */                 long l = CRC64.updateChecksum(param1Accessor.statement.checkSum, arrayOfByte, 0, i);
/*     */ 
/*     */ 
/*     */                 
/* 220 */                 param1Accessor.statement.checkSum = l;
/*     */               } 
/* 222 */               param1Accessor.rowData.put(arrayOfByte, 0, i);
/* 223 */               j += i;
/*     */             } 
/*     */           } 
/* 226 */           param1Accessor.setLength(param1Accessor.lastRowProcessed, j);
/* 227 */           param1Accessor.previousRowProcessed = param1Accessor.lastRowProcessed;
/* 228 */           param1Accessor.lastRowProcessed++;
/* 229 */           param1Accessor.isStream = false;
/* 230 */           param1Accessor.statement.connection.cacheBuffer(arrayOfByte);
/*     */         } else {
/*     */           
/* 233 */           bool = true;
/*     */         } 
/*     */       } 
/*     */       
/* 237 */       return bool;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     int readStreamFromWire(byte[] param1ArrayOfbyte, int param1Int1, int param1Int2, int[] param1ArrayOfint, boolean[] param1ArrayOfboolean1, boolean[] param1ArrayOfboolean2, T4CMAREngine param1T4CMAREngine, T4CTTIoer param1T4CTTIoer) throws SQLException, IOException {
/* 250 */       int i = -1;
/*     */       
/*     */       try {
/* 253 */         if (!param1ArrayOfboolean2[0]) {
/*     */           
/* 255 */           if (param1Int2 > 32768 || param1Int2 < 0) {
/*     */             
/* 257 */             SQLException sQLException = DatabaseError.createSqlException((OracleConnection)null, 433);
/* 258 */             sQLException.fillInStackTrace();
/* 259 */             throw sQLException;
/*     */           } 
/*     */ 
/*     */           
/* 263 */           if (param1ArrayOfboolean1[0])
/*     */           {
/* 265 */             if (param1ArrayOfint[0] == 254) {
/* 266 */               if (param1T4CMAREngine.useCLRBigChunks) {
/*     */                 
/* 268 */                 i = param1T4CMAREngine.unmarshalSB4();
/*     */               }
/*     */               else {
/*     */                 
/* 272 */                 i = param1T4CMAREngine.unmarshalUB1();
/*     */               } 
/*     */             } else {
/*     */               
/* 276 */               if (param1ArrayOfint[0] == 0) {
/*     */                 
/* 278 */                 param1T4CTTIoer.connection.internalClose();
/*     */                 
/* 280 */                 SQLException sQLException = DatabaseError.createSqlException((OracleConnection)null, 401);
/* 281 */                 sQLException.fillInStackTrace();
/* 282 */                 throw sQLException;
/*     */               } 
/*     */ 
/*     */ 
/*     */               
/* 287 */               param1ArrayOfboolean2[0] = true;
/* 288 */               i = param1ArrayOfint[0];
/*     */             } 
/*     */             
/* 291 */             param1ArrayOfboolean1[0] = false;
/* 292 */             param1ArrayOfint[0] = 0;
/*     */           
/*     */           }
/* 295 */           else if (param1T4CMAREngine.useCLRBigChunks)
/*     */           {
/* 297 */             i = param1T4CMAREngine.unmarshalSB4();
/*     */           }
/*     */           else
/*     */           {
/* 301 */             i = param1T4CMAREngine.unmarshalUB1();
/*     */           }
/*     */         
/*     */         }
/*     */         else {
/*     */           
/* 307 */           param1ArrayOfboolean2[0] = false;
/*     */         } 
/*     */ 
/*     */         
/* 311 */         if (i > 0) {
/*     */           
/* 313 */           param1T4CMAREngine.unmarshalNBytes(param1ArrayOfbyte, param1Int1, i);
/*     */         } else {
/*     */           
/* 316 */           i = -1;
/*     */         }
/*     */       
/* 319 */       } catch (BreakNetException breakNetException) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 325 */         i = param1T4CMAREngine.unmarshalSB1();
/* 326 */         if (i == 4) {
/* 327 */           param1T4CTTIoer.init();
/* 328 */           param1T4CTTIoer.processError();
/*     */         } 
/*     */       } 
/*     */ 
/*     */       
/* 333 */       if (i == -1) {
/* 334 */         param1ArrayOfboolean1[0] = true;
/*     */         
/* 336 */         param1T4CMAREngine.unmarshalUB2();
/* 337 */         param1T4CMAREngine.unmarshalUB2();
/*     */       } 
/*     */       
/* 340 */       return i;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 347 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*     */   public static final String BUILD_DATE = "Thu_Apr_04_15:09:24_PDT_2013";
/*     */   public static final boolean TRACE = false;
/*     */   
/*     */   abstract int readStreamFromWire(byte[] paramArrayOfbyte, int paramInt1, int paramInt2, int[] paramArrayOfint, boolean[] paramArrayOfboolean1, boolean[] paramArrayOfboolean2, T4CMAREngine paramT4CMAREngine, T4CTTIoer paramT4CTTIoer) throws SQLException, IOException;
/*     */   
/*     */   abstract boolean unmarshalOneRow(Accessor paramAccessor) throws SQLException, IOException;
/*     */ }


/* Location:              C:\Users\olatu\OneDrive\Documents\Calypso\syncbase\sync_base.jar!\BOOT-INF\lib\ojdbc-7.jar!\oracle\jdbc\driver\T4CMarshaller.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */