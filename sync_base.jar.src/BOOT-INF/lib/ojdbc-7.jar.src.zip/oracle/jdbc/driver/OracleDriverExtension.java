package oracle.jdbc.driver;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.Properties;

abstract class OracleDriverExtension {
  abstract Connection getConnection(String paramString, Properties paramProperties) throws SQLException;
  
  abstract OracleStatement allocateStatement(PhysicalConnection paramPhysicalConnection, int paramInt1, int paramInt2) throws SQLException;
  
  abstract OraclePreparedStatement allocatePreparedStatement(PhysicalConnection paramPhysicalConnection, String paramString, int paramInt1, int paramInt2) throws SQLException;
  
  abstract OracleCallableStatement allocateCallableStatement(PhysicalConnection paramPhysicalConnection, String paramString, int paramInt1, int paramInt2) throws SQLException;
  
  abstract OracleInputStream createInputStream(OracleStatement paramOracleStatement, int paramInt, Accessor paramAccessor) throws SQLException;
}


/* Location:              C:\Users\olatu\OneDrive\Documents\Calypso\syncbase\sync_base.jar!\BOOT-INF\lib\ojdbc-7.jar!\oracle\jdbc\driver\OracleDriverExtension.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */