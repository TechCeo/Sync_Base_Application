/*      */ package oracle.jdbc.driver;
/*      */ 
/*      */ import java.io.ByteArrayInputStream;
/*      */ import java.io.ByteArrayOutputStream;
/*      */ import java.io.IOException;
/*      */ import java.io.InputStream;
/*      */ import java.io.OutputStream;
/*      */ import java.io.Reader;
/*      */ import java.io.Writer;
/*      */ import java.math.BigDecimal;
/*      */ import java.net.MalformedURLException;
/*      */ import java.net.URL;
/*      */ import java.security.AccessController;
/*      */ import java.security.PrivilegedAction;
/*      */ import java.sql.Array;
/*      */ import java.sql.Blob;
/*      */ import java.sql.Clob;
/*      */ import java.sql.Connection;
/*      */ import java.sql.Date;
/*      */ import java.sql.NClob;
/*      */ import java.sql.Ref;
/*      */ import java.sql.ResultSet;
/*      */ import java.sql.ResultSetMetaData;
/*      */ import java.sql.RowId;
/*      */ import java.sql.SQLException;
/*      */ import java.sql.SQLXML;
/*      */ import java.sql.Time;
/*      */ import java.sql.Timestamp;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Calendar;
/*      */ import java.util.Map;
/*      */ import oracle.jdbc.OracleData;
/*      */ import oracle.jdbc.OracleDataFactory;
/*      */ import oracle.jdbc.proxy.ProxyFactory;
/*      */ import oracle.jdbc.proxy._Proxy_;
/*      */ import oracle.sql.ARRAY;
/*      */ import oracle.sql.BFILE;
/*      */ import oracle.sql.BLOB;
/*      */ import oracle.sql.CHAR;
/*      */ import oracle.sql.CLOB;
/*      */ import oracle.sql.CustomDatum;
/*      */ import oracle.sql.CustomDatumFactory;
/*      */ import oracle.sql.DATE;
/*      */ import oracle.sql.Datum;
/*      */ import oracle.sql.INTERVALDS;
/*      */ import oracle.sql.INTERVALYM;
/*      */ import oracle.sql.NCLOB;
/*      */ import oracle.sql.NUMBER;
/*      */ import oracle.sql.OPAQUE;
/*      */ import oracle.sql.ORAData;
/*      */ import oracle.sql.ORADataFactory;
/*      */ import oracle.sql.RAW;
/*      */ import oracle.sql.REF;
/*      */ import oracle.sql.ROWID;
/*      */ import oracle.sql.STRUCT;
/*      */ import oracle.sql.TIMESTAMP;
/*      */ import oracle.sql.TIMESTAMPLTZ;
/*      */ import oracle.sql.TIMESTAMPTZ;
/*      */ 
/*      */ abstract class GeneratedUpdatableResultSet extends OracleResultSet {
/*      */   protected static final int MAX_CHAR_BUFFER_SIZE = 1024;
/*      */   protected static final int MAX_BYTE_BUFFER_SIZE = 1024;
/*      */   protected static final int ASCII_STREAM = 1;
/*      */   protected static final int BINARY_STREAM = 2;
/*      */   protected static final int UNICODE_STREAM = 3;
/*      */   
/*      */   GeneratedUpdatableResultSet(OracleStatement paramOracleStatement, OracleResultSet paramOracleResultSet) throws SQLException {
/*   68 */     super(paramOracleStatement.connection);
/*      */     
/*   70 */     this.resultSet = paramOracleResultSet;
/*      */   }
/*      */ 
/*      */   
/*      */   protected static final int VALUE_NULL = 1;
/*      */   
/*      */   protected static final int VALUE_NOT_NULL = 2;
/*      */   
/*      */   protected static final int VALUE_UNKNOWN = 3;
/*      */   
/*      */   protected static final int VALUE_IN_RSET = 4;
/*      */   
/*      */   OracleResultSet resultSet;
/*      */   
/*      */   boolean isRowDeleted = false;
/*      */ 
/*      */   
/*      */   abstract void ensureOpen() throws SQLException;
/*      */ 
/*      */   
/*      */   abstract void setIsNull(int paramInt);
/*      */ 
/*      */   
/*      */   abstract void setIsNull(boolean paramBoolean);
/*      */ 
/*      */   
/*      */   abstract boolean isOnInsertRow();
/*      */   
/*      */   abstract boolean isUpdatingRow() throws SQLException;
/*      */   
/*      */   abstract boolean isRowBufferUpdatedAt(int paramInt) throws SQLException;
/*      */   
/*      */   abstract Object getRowBufferAt(int paramInt) throws SQLException;
/*      */   
/*      */   abstract Datum getRowBufferDatumAt(int paramInt) throws SQLException;
/*      */   
/*      */   abstract void setRowBufferAt(int paramInt, Datum paramDatum) throws SQLException;
/*      */   
/*      */   abstract void setRowBufferAt(int paramInt, Object paramObject, int[] paramArrayOfint) throws SQLException;
/*      */   
/*      */   abstract ResultSetMetaData getInternalMetadata() throws SQLException;
/*      */   
/*      */   abstract void addToTempLobsToFree(Clob paramClob);
/*      */   
/*      */   abstract void addToTempLobsToFree(Blob paramBlob);
/*      */   
/*      */   abstract void cleanTempLobs();
/*      */   
/*      */   abstract void cleanTempBlobs(ArrayList paramArrayList);
/*      */   
/*      */   abstract void cleanTempClobs(ArrayList paramArrayList);
/*      */   
/*      */   public Datum getOracleObject(int paramInt) throws SQLException {
/*  123 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  131 */       ensureOpen();
/*  132 */       if (this.isRowDeleted) {
/*  133 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 82);
/*  134 */         sQLException.fillInStackTrace();
/*  135 */         throw sQLException;
/*      */       } 
/*  137 */       Datum datum = null;
/*  138 */       setIsNull(3);
/*  139 */       if (isOnInsertRow() || (isUpdatingRow() && isRowBufferUpdatedAt(paramInt))) {
/*      */         
/*  141 */         datum = getRowBufferDatumAt(paramInt);
/*  142 */         setIsNull((datum == null));
/*      */       } else {
/*      */         
/*  145 */         datum = this.resultSet.getOracleObject(paramInt);
/*  146 */         setIsNull(4);
/*      */       } 
/*  148 */       return datum;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getString(int paramInt) throws SQLException {
/*  156 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  163 */       ensureOpen();
/*  164 */       if (this.isRowDeleted) {
/*  165 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 82);
/*  166 */         sQLException.fillInStackTrace();
/*  167 */         throw sQLException;
/*      */       } 
/*  169 */       String str = null;
/*      */       
/*  171 */       setIsNull(3);
/*      */       
/*  173 */       if (isOnInsertRow() || (isUpdatingRow() && isRowBufferUpdatedAt(paramInt))) {
/*      */ 
/*      */         
/*  176 */         Datum datum = getRowBufferDatumAt(paramInt);
/*      */         
/*  178 */         setIsNull((datum == null));
/*      */         
/*  180 */         if (datum != null) {
/*  181 */           str = datum.stringValue((Connection)this.connection);
/*      */         }
/*      */       } else {
/*      */         
/*  185 */         setIsNull(4);
/*      */         
/*  187 */         str = this.resultSet.getString(paramInt);
/*      */       } 
/*      */       
/*  190 */       return str;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean getBoolean(int paramInt) throws SQLException {
/*  197 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  204 */       ensureOpen();
/*  205 */       if (this.isRowDeleted) {
/*  206 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 82);
/*  207 */         sQLException.fillInStackTrace();
/*  208 */         throw sQLException;
/*      */       } 
/*  210 */       boolean bool = false;
/*      */       
/*  212 */       setIsNull(3);
/*      */       
/*  214 */       if (isOnInsertRow() || (isUpdatingRow() && isRowBufferUpdatedAt(paramInt))) {
/*      */ 
/*      */         
/*  217 */         Datum datum = getRowBufferDatumAt(paramInt);
/*      */         
/*  219 */         setIsNull((datum == null));
/*      */         
/*  221 */         if (datum != null) {
/*  222 */           bool = datum.booleanValue();
/*      */         }
/*      */       } else {
/*      */         
/*  226 */         setIsNull(4);
/*      */         
/*  228 */         bool = this.resultSet.getBoolean(paramInt);
/*      */       } 
/*      */       
/*  231 */       return bool;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public byte getByte(int paramInt) throws SQLException {
/*  238 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  245 */       ensureOpen();
/*  246 */       if (this.isRowDeleted) {
/*  247 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 82);
/*  248 */         sQLException.fillInStackTrace();
/*  249 */         throw sQLException;
/*      */       } 
/*  251 */       byte b = 0;
/*      */       
/*  253 */       setIsNull(3);
/*      */       
/*  255 */       if (isOnInsertRow() || (isUpdatingRow() && isRowBufferUpdatedAt(paramInt))) {
/*      */ 
/*      */         
/*  258 */         Datum datum = getRowBufferDatumAt(paramInt);
/*      */         
/*  260 */         setIsNull((datum == null));
/*      */         
/*  262 */         if (datum != null) {
/*  263 */           b = datum.byteValue();
/*      */         }
/*      */       } else {
/*      */         
/*  267 */         setIsNull(4);
/*      */         
/*  269 */         b = this.resultSet.getByte(paramInt);
/*      */       } 
/*      */       
/*  272 */       return b;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public short getShort(int paramInt) throws SQLException {
/*  279 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  286 */       ensureOpen();
/*  287 */       if (this.isRowDeleted) {
/*  288 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 82);
/*  289 */         sQLException.fillInStackTrace();
/*  290 */         throw sQLException;
/*      */       } 
/*  292 */       short s = 0;
/*      */       
/*  294 */       setIsNull(3);
/*      */       
/*  296 */       if (isOnInsertRow() || (isUpdatingRow() && isRowBufferUpdatedAt(paramInt))) {
/*      */ 
/*      */         
/*  299 */         long l = getLong(paramInt);
/*      */         
/*  301 */         if (l > 65537L || l < -65538L) {
/*      */           
/*  303 */           SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 26, "getShort");
/*  304 */           sQLException.fillInStackTrace();
/*  305 */           throw sQLException;
/*      */         } 
/*      */         
/*  308 */         s = (short)(int)l;
/*      */       }
/*      */       else {
/*      */         
/*  312 */         setIsNull(4);
/*      */         
/*  314 */         s = this.resultSet.getShort(paramInt);
/*      */       } 
/*      */       
/*  317 */       return s;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public int getInt(int paramInt) throws SQLException {
/*  324 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  331 */       ensureOpen();
/*  332 */       if (this.isRowDeleted) {
/*  333 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 82);
/*  334 */         sQLException.fillInStackTrace();
/*  335 */         throw sQLException;
/*      */       } 
/*  337 */       int i = 0;
/*      */       
/*  339 */       setIsNull(3);
/*      */       
/*  341 */       if (isOnInsertRow() || (isUpdatingRow() && isRowBufferUpdatedAt(paramInt))) {
/*      */ 
/*      */         
/*  344 */         Datum datum = getRowBufferDatumAt(paramInt);
/*      */         
/*  346 */         setIsNull((datum == null));
/*      */         
/*  348 */         if (datum != null) {
/*  349 */           i = datum.intValue();
/*      */         }
/*      */       } else {
/*      */         
/*  353 */         setIsNull(4);
/*      */         
/*  355 */         i = this.resultSet.getInt(paramInt);
/*      */       } 
/*      */       
/*  358 */       return i;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public long getLong(int paramInt) throws SQLException {
/*  365 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  372 */       ensureOpen();
/*  373 */       if (this.isRowDeleted) {
/*  374 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 82);
/*  375 */         sQLException.fillInStackTrace();
/*  376 */         throw sQLException;
/*      */       } 
/*  378 */       long l = 0L;
/*      */       
/*  380 */       setIsNull(3);
/*      */       
/*  382 */       if (isOnInsertRow() || (isUpdatingRow() && isRowBufferUpdatedAt(paramInt))) {
/*      */ 
/*      */         
/*  385 */         Datum datum = getRowBufferDatumAt(paramInt);
/*      */         
/*  387 */         setIsNull((datum == null));
/*      */         
/*  389 */         if (datum != null) {
/*  390 */           l = datum.longValue();
/*      */         }
/*      */       } else {
/*      */         
/*  394 */         setIsNull(4);
/*      */         
/*  396 */         l = this.resultSet.getLong(paramInt);
/*      */       } 
/*      */       
/*  399 */       return l;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public float getFloat(int paramInt) throws SQLException {
/*  406 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  413 */       ensureOpen();
/*  414 */       if (this.isRowDeleted) {
/*  415 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 82);
/*  416 */         sQLException.fillInStackTrace();
/*  417 */         throw sQLException;
/*      */       } 
/*  419 */       float f = 0.0F;
/*      */       
/*  421 */       setIsNull(3);
/*      */       
/*  423 */       if (isOnInsertRow() || (isUpdatingRow() && isRowBufferUpdatedAt(paramInt))) {
/*      */ 
/*      */         
/*  426 */         Datum datum = getRowBufferDatumAt(paramInt);
/*      */         
/*  428 */         setIsNull((datum == null));
/*      */         
/*  430 */         if (datum != null) {
/*  431 */           f = datum.floatValue();
/*      */         }
/*      */       } else {
/*      */         
/*  435 */         setIsNull(4);
/*      */         
/*  437 */         f = this.resultSet.getFloat(paramInt);
/*      */       } 
/*      */       
/*  440 */       return f;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public double getDouble(int paramInt) throws SQLException {
/*  447 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  454 */       ensureOpen();
/*  455 */       if (this.isRowDeleted) {
/*  456 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 82);
/*  457 */         sQLException.fillInStackTrace();
/*  458 */         throw sQLException;
/*      */       } 
/*  460 */       double d = 0.0D;
/*      */       
/*  462 */       setIsNull(3);
/*      */       
/*  464 */       if (isOnInsertRow() || (isUpdatingRow() && isRowBufferUpdatedAt(paramInt))) {
/*      */ 
/*      */         
/*  467 */         Datum datum = getRowBufferDatumAt(paramInt);
/*      */         
/*  469 */         setIsNull((datum == null));
/*      */         
/*  471 */         if (datum != null) {
/*  472 */           d = datum.doubleValue();
/*      */         }
/*      */       } else {
/*      */         
/*  476 */         setIsNull(4);
/*      */         
/*  478 */         d = this.resultSet.getDouble(paramInt);
/*      */       } 
/*      */       
/*  481 */       return d;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public BigDecimal getBigDecimal(int paramInt1, int paramInt2) throws SQLException {
/*  489 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  496 */       ensureOpen();
/*  497 */       if (this.isRowDeleted) {
/*  498 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 82);
/*  499 */         sQLException.fillInStackTrace();
/*  500 */         throw sQLException;
/*      */       } 
/*  502 */       BigDecimal bigDecimal = null;
/*      */       
/*  504 */       setIsNull(3);
/*      */       
/*  506 */       if (isOnInsertRow() || (isUpdatingRow() && isRowBufferUpdatedAt(paramInt1))) {
/*      */ 
/*      */         
/*  509 */         Datum datum = getRowBufferDatumAt(paramInt1);
/*      */         
/*  511 */         setIsNull((datum == null));
/*      */         
/*  513 */         if (datum != null) {
/*  514 */           bigDecimal = datum.bigDecimalValue();
/*      */         }
/*      */       } else {
/*      */         
/*  518 */         setIsNull(4);
/*      */         
/*  520 */         bigDecimal = this.resultSet.getBigDecimal(paramInt1);
/*      */       } 
/*      */       
/*  523 */       return bigDecimal;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public byte[] getBytes(int paramInt) throws SQLException {
/*  530 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  537 */       ensureOpen();
/*  538 */       if (this.isRowDeleted) {
/*  539 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 82);
/*  540 */         sQLException.fillInStackTrace();
/*  541 */         throw sQLException;
/*      */       } 
/*  543 */       byte[] arrayOfByte = null;
/*      */       
/*  545 */       setIsNull(3);
/*      */       
/*  547 */       if (isOnInsertRow() || (isUpdatingRow() && isRowBufferUpdatedAt(paramInt))) {
/*      */ 
/*      */         
/*  550 */         Datum datum = getRowBufferDatumAt(paramInt);
/*      */         
/*  552 */         setIsNull((datum == null));
/*      */         
/*  554 */         if (datum != null) {
/*  555 */           arrayOfByte = datum.getBytes();
/*      */         }
/*      */       } else {
/*      */         
/*  559 */         setIsNull(4);
/*      */         
/*  561 */         arrayOfByte = this.resultSet.getBytes(paramInt);
/*      */       } 
/*      */       
/*  564 */       return arrayOfByte;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public Date getDate(int paramInt) throws SQLException {
/*  571 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  578 */       ensureOpen();
/*  579 */       if (this.isRowDeleted) {
/*  580 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 82);
/*  581 */         sQLException.fillInStackTrace();
/*  582 */         throw sQLException;
/*      */       } 
/*  584 */       Date date = null;
/*      */       
/*  586 */       setIsNull(3);
/*      */       
/*  588 */       if (isOnInsertRow() || (isUpdatingRow() && isRowBufferUpdatedAt(paramInt))) {
/*      */ 
/*      */         
/*  591 */         Datum datum = getRowBufferDatumAt(paramInt);
/*      */         
/*  593 */         setIsNull((datum == null));
/*      */         
/*  595 */         if (datum != null) {
/*  596 */           date = datum.dateValue();
/*      */         }
/*      */       } else {
/*      */         
/*  600 */         setIsNull(4);
/*      */         
/*  602 */         date = this.resultSet.getDate(paramInt);
/*      */       } 
/*      */       
/*  605 */       return date;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public Time getTime(int paramInt) throws SQLException {
/*  612 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  619 */       ensureOpen();
/*  620 */       if (this.isRowDeleted) {
/*  621 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 82);
/*  622 */         sQLException.fillInStackTrace();
/*  623 */         throw sQLException;
/*      */       } 
/*  625 */       Time time = null;
/*      */       
/*  627 */       setIsNull(3);
/*      */       
/*  629 */       if (isOnInsertRow() || (isUpdatingRow() && isRowBufferUpdatedAt(paramInt))) {
/*      */ 
/*      */         
/*  632 */         Datum datum = getRowBufferDatumAt(paramInt);
/*      */         
/*  634 */         setIsNull((datum == null));
/*      */         
/*  636 */         if (datum != null) {
/*  637 */           time = datum.timeValue();
/*      */         }
/*      */       } else {
/*      */         
/*  641 */         setIsNull(4);
/*      */         
/*  643 */         time = this.resultSet.getTime(paramInt);
/*      */       } 
/*      */       
/*  646 */       return time;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Timestamp getTimestamp(int paramInt) throws SQLException {
/*  654 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  661 */       ensureOpen();
/*  662 */       if (this.isRowDeleted) {
/*  663 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 82);
/*  664 */         sQLException.fillInStackTrace();
/*  665 */         throw sQLException;
/*      */       } 
/*  667 */       Timestamp timestamp = null;
/*      */       
/*  669 */       setIsNull(3);
/*      */       
/*  671 */       if (isOnInsertRow() || (isUpdatingRow() && isRowBufferUpdatedAt(paramInt))) {
/*      */ 
/*      */         
/*  674 */         Datum datum = getRowBufferDatumAt(paramInt);
/*      */         
/*  676 */         setIsNull((datum == null));
/*      */         
/*  678 */         if (datum != null) {
/*  679 */           timestamp = datum.timestampValue();
/*      */         }
/*      */       } else {
/*      */         
/*  683 */         setIsNull(4);
/*      */         
/*  685 */         timestamp = this.resultSet.getTimestamp(paramInt);
/*      */       } 
/*      */       
/*  688 */       return timestamp;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public InputStream getAsciiStream(int paramInt) throws SQLException {
/*  696 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  703 */       ensureOpen();
/*  704 */       if (this.isRowDeleted) {
/*  705 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 82);
/*  706 */         sQLException.fillInStackTrace();
/*  707 */         throw sQLException;
/*      */       } 
/*  709 */       InputStream inputStream = null;
/*      */       
/*  711 */       setIsNull(3);
/*      */       
/*  713 */       if (isOnInsertRow() || (isUpdatingRow() && isRowBufferUpdatedAt(paramInt))) {
/*      */ 
/*      */         
/*  716 */         Object object = getRowBufferAt(paramInt);
/*      */         
/*  718 */         setIsNull((object == null));
/*      */         
/*  720 */         if (object != null)
/*      */         {
/*  722 */           if (object instanceof InputStream)
/*      */           {
/*  724 */             inputStream = (InputStream)object;
/*      */           }
/*      */           else
/*      */           {
/*  728 */             Datum datum = getRowBufferDatumAt(paramInt);
/*      */             
/*  730 */             inputStream = datum.asciiStreamValue();
/*      */           }
/*      */         
/*      */         }
/*      */       } else {
/*      */         
/*  736 */         setIsNull(4);
/*      */         
/*  738 */         inputStream = this.resultSet.getAsciiStream(paramInt);
/*      */       } 
/*      */       
/*  741 */       return inputStream;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public InputStream getUnicodeStream(int paramInt) throws SQLException {
/*  749 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  756 */       ensureOpen();
/*  757 */       if (this.isRowDeleted) {
/*  758 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 82);
/*  759 */         sQLException.fillInStackTrace();
/*  760 */         throw sQLException;
/*      */       } 
/*  762 */       InputStream inputStream = null;
/*      */       
/*  764 */       setIsNull(3);
/*      */       
/*  766 */       if (isOnInsertRow() || (isUpdatingRow() && isRowBufferUpdatedAt(paramInt))) {
/*      */ 
/*      */         
/*  769 */         Object object = getRowBufferAt(paramInt);
/*      */         
/*  771 */         setIsNull((object == null));
/*      */         
/*  773 */         if (object != null)
/*      */         {
/*  775 */           if (object instanceof InputStream) {
/*      */             
/*  777 */             inputStream = (InputStream)object;
/*      */           }
/*      */           else {
/*      */             
/*  781 */             Datum datum = getRowBufferDatumAt(paramInt);
/*  782 */             DBConversion dBConversion = this.connection.conversion;
/*  783 */             byte[] arrayOfByte = datum.shareBytes();
/*      */             
/*  785 */             if (datum instanceof RAW)
/*      */             {
/*  787 */               inputStream = dBConversion.ConvertStream(new ByteArrayInputStream(arrayOfByte), 3);
/*      */             
/*      */             }
/*  790 */             else if (datum instanceof CHAR)
/*      */             {
/*  792 */               inputStream = dBConversion.ConvertStream(new ByteArrayInputStream(arrayOfByte), 1);
/*      */             
/*      */             }
/*      */             else
/*      */             {
/*  797 */               SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getUnicodeStream");
/*  798 */               sQLException.fillInStackTrace();
/*  799 */               throw sQLException;
/*      */             }
/*      */           
/*      */           } 
/*      */         }
/*      */       } else {
/*      */         
/*  806 */         setIsNull(4);
/*      */         
/*  808 */         inputStream = this.resultSet.getUnicodeStream(paramInt);
/*      */       } 
/*      */       
/*  811 */       return inputStream;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public InputStream getBinaryStream(int paramInt) throws SQLException {
/*  819 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  826 */       ensureOpen();
/*  827 */       if (this.isRowDeleted) {
/*  828 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 82);
/*  829 */         sQLException.fillInStackTrace();
/*  830 */         throw sQLException;
/*      */       } 
/*  832 */       InputStream inputStream = null;
/*      */       
/*  834 */       setIsNull(3);
/*      */       
/*  836 */       if (isOnInsertRow() || (isUpdatingRow() && isRowBufferUpdatedAt(paramInt))) {
/*      */ 
/*      */         
/*  839 */         Object object = getRowBufferAt(paramInt);
/*      */         
/*  841 */         setIsNull((object == null));
/*      */         
/*  843 */         if (object != null)
/*      */         {
/*  845 */           if (object instanceof InputStream)
/*      */           {
/*  847 */             inputStream = (InputStream)object;
/*      */           }
/*      */           else
/*      */           {
/*  851 */             Datum datum = getRowBufferDatumAt(paramInt);
/*      */             
/*  853 */             inputStream = datum.binaryStreamValue();
/*      */           }
/*      */         
/*      */         }
/*      */       } else {
/*      */         
/*  859 */         setIsNull(4);
/*      */         
/*  861 */         inputStream = this.resultSet.getBinaryStream(paramInt);
/*      */       } 
/*      */       
/*  864 */       return inputStream;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public Object getObject(int paramInt) throws SQLException {
/*  871 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  878 */       ensureOpen();
/*  879 */       if (this.isRowDeleted) {
/*  880 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 82);
/*  881 */         sQLException.fillInStackTrace();
/*  882 */         throw sQLException;
/*      */       } 
/*  884 */       Object object = null;
/*      */       
/*  886 */       setIsNull(3);
/*      */       
/*  888 */       if (isOnInsertRow() || (isUpdatingRow() && isRowBufferUpdatedAt(paramInt))) {
/*      */ 
/*      */         
/*  891 */         Datum datum = getOracleObject(paramInt);
/*      */         
/*  893 */         setIsNull((datum == null));
/*      */         
/*  895 */         if (datum != null) {
/*  896 */           object = datum.toJdbc();
/*      */         }
/*      */       } else {
/*      */         
/*  900 */         setIsNull(4);
/*      */         
/*  902 */         object = this.resultSet.getObject(paramInt);
/*      */       } 
/*      */       
/*  905 */       return object;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Object getObject(int paramInt, OracleDataFactory paramOracleDataFactory) throws SQLException {
/*  913 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  921 */       ensureOpen();
/*  922 */       if (this.isRowDeleted) {
/*  923 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 82);
/*  924 */         sQLException.fillInStackTrace();
/*  925 */         throw sQLException;
/*      */       } 
/*  927 */       if (paramOracleDataFactory == null) {
/*  928 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/*  929 */         sQLException.fillInStackTrace();
/*  930 */         throw sQLException;
/*      */       } 
/*      */       
/*  933 */       Object object = null;
/*  934 */       setIsNull(3);
/*  935 */       if (isOnInsertRow() || (isUpdatingRow() && isRowBufferUpdatedAt(paramInt))) {
/*      */         
/*  937 */         Object object1 = getObject(paramInt);
/*  938 */         setIsNull((object1 == null));
/*  939 */         object = paramOracleDataFactory.create(object1, 0);
/*      */       } else {
/*      */         
/*  942 */         setIsNull(4);
/*  943 */         object = this.resultSet.getObject(paramInt, paramOracleDataFactory);
/*      */       } 
/*      */       
/*  946 */       return object;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Reader getCharacterStream(int paramInt) throws SQLException {
/*  957 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  964 */       ensureOpen();
/*  965 */       if (this.isRowDeleted) {
/*  966 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 82);
/*  967 */         sQLException.fillInStackTrace();
/*  968 */         throw sQLException;
/*      */       } 
/*  970 */       Reader reader = null;
/*      */       
/*  972 */       setIsNull(3);
/*      */       
/*  974 */       if (isOnInsertRow() || (isUpdatingRow() && isRowBufferUpdatedAt(paramInt))) {
/*      */ 
/*      */         
/*  977 */         Object object = getRowBufferAt(paramInt);
/*      */         
/*  979 */         setIsNull((object == null));
/*      */         
/*  981 */         if (object != null)
/*      */         {
/*  983 */           if (object instanceof Reader)
/*      */           {
/*  985 */             reader = (Reader)object;
/*      */           }
/*      */           else
/*      */           {
/*  989 */             Datum datum = getRowBufferDatumAt(paramInt);
/*      */             
/*  991 */             reader = datum.characterStreamValue();
/*      */           }
/*      */         
/*      */         }
/*      */       } else {
/*      */         
/*  997 */         setIsNull(4);
/*      */         
/*  999 */         reader = this.resultSet.getCharacterStream(paramInt);
/*      */       } 
/*      */       
/* 1002 */       return reader;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public BigDecimal getBigDecimal(int paramInt) throws SQLException {
/* 1011 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1018 */       ensureOpen();
/* 1019 */       if (this.isRowDeleted) {
/* 1020 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 82);
/* 1021 */         sQLException.fillInStackTrace();
/* 1022 */         throw sQLException;
/*      */       } 
/* 1024 */       BigDecimal bigDecimal = null;
/*      */       
/* 1026 */       setIsNull(3);
/*      */       
/* 1028 */       if (isOnInsertRow() || (isUpdatingRow() && isRowBufferUpdatedAt(paramInt))) {
/*      */ 
/*      */         
/* 1031 */         Datum datum = getRowBufferDatumAt(paramInt);
/*      */         
/* 1033 */         setIsNull((datum == null));
/*      */         
/* 1035 */         if (datum != null) {
/* 1036 */           bigDecimal = datum.bigDecimalValue();
/*      */         }
/*      */       } else {
/*      */         
/* 1040 */         setIsNull(4);
/*      */         
/* 1042 */         bigDecimal = this.resultSet.getBigDecimal(paramInt);
/*      */       } 
/*      */       
/* 1045 */       return bigDecimal;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Object getObject(int paramInt, Map paramMap) throws SQLException {
/* 1054 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1061 */       ensureOpen();
/* 1062 */       if (this.isRowDeleted) {
/* 1063 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 82);
/* 1064 */         sQLException.fillInStackTrace();
/* 1065 */         throw sQLException;
/*      */       } 
/* 1067 */       Object object = null;
/*      */       
/* 1069 */       setIsNull(3);
/*      */       
/* 1071 */       if (isOnInsertRow() || (isUpdatingRow() && isRowBufferUpdatedAt(paramInt))) {
/*      */ 
/*      */         
/* 1074 */         Datum datum = getOracleObject(paramInt);
/*      */         
/* 1076 */         setIsNull((datum == null));
/*      */         
/* 1078 */         if (datum != null)
/*      */         {
/* 1080 */           if (datum instanceof STRUCT) {
/* 1081 */             object = ((STRUCT)datum).toJdbc(paramMap);
/*      */           } else {
/* 1083 */             object = datum.toJdbc();
/*      */           } 
/*      */         }
/*      */       } else {
/*      */         
/* 1088 */         setIsNull(4);
/*      */         
/* 1090 */         object = this.resultSet.getObject(paramInt, paramMap);
/*      */       } 
/*      */       
/* 1093 */       return object;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Ref getRef(int paramInt) throws SQLException {
/* 1101 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1108 */       ensureOpen();
/* 1109 */       if (this.isRowDeleted) {
/* 1110 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 82);
/* 1111 */         sQLException.fillInStackTrace();
/* 1112 */         throw sQLException;
/*      */       } 
/* 1114 */       return (Ref)getREF(paramInt);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Blob getBlob(int paramInt) throws SQLException {
/* 1122 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1129 */       ensureOpen();
/* 1130 */       if (this.isRowDeleted) {
/* 1131 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 82);
/* 1132 */         sQLException.fillInStackTrace();
/* 1133 */         throw sQLException;
/*      */       } 
/* 1135 */       return (Blob)getBLOB(paramInt);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Clob getClob(int paramInt) throws SQLException {
/* 1143 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1150 */       ensureOpen();
/* 1151 */       if (this.isRowDeleted) {
/* 1152 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 82);
/* 1153 */         sQLException.fillInStackTrace();
/* 1154 */         throw sQLException;
/*      */       } 
/* 1156 */       return (Clob)getCLOB(paramInt);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Array getArray(int paramInt) throws SQLException {
/* 1165 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1172 */       ensureOpen();
/* 1173 */       if (this.isRowDeleted) {
/* 1174 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 82);
/* 1175 */         sQLException.fillInStackTrace();
/* 1176 */         throw sQLException;
/*      */       } 
/* 1178 */       return (Array)getARRAY(paramInt);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Date getDate(int paramInt, Calendar paramCalendar) throws SQLException {
/* 1187 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1194 */       ensureOpen();
/* 1195 */       if (this.isRowDeleted) {
/* 1196 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 82);
/* 1197 */         sQLException.fillInStackTrace();
/* 1198 */         throw sQLException;
/*      */       } 
/* 1200 */       Date date = null;
/*      */       
/* 1202 */       setIsNull(3);
/*      */       
/* 1204 */       if (isOnInsertRow() || (isUpdatingRow() && isRowBufferUpdatedAt(paramInt))) {
/*      */ 
/*      */         
/* 1207 */         Datum datum = getOracleObject(paramInt);
/*      */         
/* 1209 */         setIsNull((datum == null));
/*      */         
/* 1211 */         if (datum != null)
/*      */         {
/* 1213 */           if (datum instanceof DATE) {
/* 1214 */             date = ((DATE)datum).dateValue(paramCalendar);
/* 1215 */           } else if (datum instanceof TIMESTAMP) {
/*      */             
/* 1217 */             Timestamp timestamp = ((TIMESTAMP)datum).timestampValue(paramCalendar);
/* 1218 */             long l = timestamp.getTime();
/* 1219 */             date = new Date(l);
/*      */           
/*      */           }
/*      */           else {
/*      */ 
/*      */             
/* 1225 */             DATE dATE = new DATE(datum.stringValue((Connection)this.connection));
/*      */             
/* 1227 */             if (dATE != null) {
/* 1228 */               date = dATE.dateValue(paramCalendar);
/*      */             }
/*      */           } 
/*      */         }
/*      */       } else {
/*      */         
/* 1234 */         setIsNull(4);
/*      */         
/* 1236 */         date = this.resultSet.getDate(paramInt, paramCalendar);
/*      */       } 
/*      */       
/* 1239 */       return date;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Time getTime(int paramInt, Calendar paramCalendar) throws SQLException {
/* 1248 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1255 */       ensureOpen();
/* 1256 */       if (this.isRowDeleted) {
/* 1257 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 82);
/* 1258 */         sQLException.fillInStackTrace();
/* 1259 */         throw sQLException;
/*      */       } 
/* 1261 */       Time time = null;
/*      */       
/* 1263 */       setIsNull(3);
/*      */       
/* 1265 */       if (isOnInsertRow() || (isUpdatingRow() && isRowBufferUpdatedAt(paramInt))) {
/*      */ 
/*      */         
/* 1268 */         Datum datum = getOracleObject(paramInt);
/*      */         
/* 1270 */         setIsNull((datum == null));
/*      */         
/* 1272 */         if (datum != null)
/*      */         {
/* 1274 */           if (datum instanceof DATE) {
/* 1275 */             time = ((DATE)datum).timeValue(paramCalendar);
/* 1276 */           } else if (datum instanceof TIMESTAMP) {
/*      */             
/* 1278 */             Timestamp timestamp = ((TIMESTAMP)datum).timestampValue(paramCalendar);
/* 1279 */             long l = timestamp.getTime();
/* 1280 */             time = new Time(l);
/*      */           
/*      */           }
/*      */           else {
/*      */             
/* 1285 */             DATE dATE = new DATE(datum.stringValue((Connection)this.connection));
/*      */             
/* 1287 */             if (dATE != null) {
/* 1288 */               time = dATE.timeValue(paramCalendar);
/*      */             }
/*      */           } 
/*      */         }
/*      */       } else {
/*      */         
/* 1294 */         setIsNull(4);
/*      */         
/* 1296 */         time = this.resultSet.getTime(paramInt, paramCalendar);
/*      */       } 
/*      */       
/* 1299 */       return time;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Timestamp getTimestamp(int paramInt, Calendar paramCalendar) throws SQLException {
/* 1308 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1315 */       ensureOpen();
/* 1316 */       if (this.isRowDeleted) {
/* 1317 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 82);
/* 1318 */         sQLException.fillInStackTrace();
/* 1319 */         throw sQLException;
/*      */       } 
/* 1321 */       Timestamp timestamp = null;
/*      */       
/* 1323 */       setIsNull(3);
/*      */       
/* 1325 */       if (isOnInsertRow() || (isUpdatingRow() && isRowBufferUpdatedAt(paramInt))) {
/*      */ 
/*      */         
/* 1328 */         Datum datum = getOracleObject(paramInt);
/*      */         
/* 1330 */         setIsNull((datum == null));
/*      */         
/* 1332 */         if (datum != null)
/*      */         {
/* 1334 */           if (datum instanceof DATE) {
/* 1335 */             timestamp = ((DATE)datum).timestampValue(paramCalendar);
/* 1336 */           } else if (datum instanceof TIMESTAMP) {
/* 1337 */             timestamp = ((TIMESTAMP)datum).timestampValue(paramCalendar);
/*      */           } else {
/*      */             
/* 1340 */             DATE dATE = new DATE(datum.stringValue((Connection)this.connection));
/*      */             
/* 1342 */             if (dATE != null) {
/* 1343 */               timestamp = dATE.timestampValue(paramCalendar);
/*      */             }
/*      */           } 
/*      */         }
/*      */       } else {
/*      */         
/* 1349 */         setIsNull(4);
/*      */         
/* 1351 */         timestamp = this.resultSet.getTimestamp(paramInt, paramCalendar);
/*      */       } 
/*      */       
/* 1354 */       return timestamp;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public URL getURL(int paramInt) throws SQLException {
/* 1362 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1369 */       ensureOpen();
/* 1370 */       if (this.isRowDeleted) {
/* 1371 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 82);
/* 1372 */         sQLException.fillInStackTrace();
/* 1373 */         throw sQLException;
/*      */       } 
/*      */       
/* 1376 */       URL uRL = null;
/*      */       
/* 1378 */       int i = getInternalMetadata().getColumnType(paramInt);
/* 1379 */       int j = SQLUtil.getInternalType(i);
/*      */ 
/*      */       
/* 1382 */       if (j == 96 || j == 1 || j == 8) {
/*      */ 
/*      */         
/*      */         try {
/*      */           
/* 1387 */           String str = getString(paramInt);
/* 1388 */           if (str == null) { uRL = null; }
/* 1389 */           else { uRL = new URL(str); }
/*      */         
/* 1391 */         } catch (MalformedURLException malformedURLException) {
/*      */ 
/*      */           
/* 1394 */           SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 136);
/* 1395 */           sQLException.fillInStackTrace();
/* 1396 */           throw sQLException;
/*      */         
/*      */         }
/*      */       
/*      */       }
/*      */       else {
/*      */         
/* 1403 */         SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException();
/* 1404 */         sQLException.fillInStackTrace();
/* 1405 */         throw sQLException;
/*      */       } 
/*      */ 
/*      */       
/* 1409 */       return uRL;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ResultSet getCursor(int paramInt) throws SQLException {
/* 1417 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1424 */       ensureOpen();
/* 1425 */       if (this.isRowDeleted) {
/* 1426 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 82);
/* 1427 */         sQLException.fillInStackTrace();
/* 1428 */         throw sQLException;
/*      */       } 
/* 1430 */       ResultSet resultSet = null;
/*      */       
/* 1432 */       setIsNull(3);
/*      */       
/* 1434 */       if (isOnInsertRow() || (isUpdatingRow() && isRowBufferUpdatedAt(paramInt))) {
/*      */ 
/*      */         
/* 1437 */         Datum datum = getOracleObject(paramInt);
/*      */         
/* 1439 */         setIsNull((datum == null));
/*      */         
/* 1441 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getCursor");
/* 1442 */         sQLException.fillInStackTrace();
/* 1443 */         throw sQLException;
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/* 1448 */       setIsNull(4);
/*      */       
/* 1450 */       resultSet = this.resultSet.getCursor(paramInt);
/*      */ 
/*      */       
/* 1453 */       return resultSet;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ROWID getROWID(int paramInt) throws SQLException {
/* 1461 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1468 */       ensureOpen();
/* 1469 */       if (this.isRowDeleted) {
/* 1470 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 82);
/* 1471 */         sQLException.fillInStackTrace();
/* 1472 */         throw sQLException;
/*      */       } 
/* 1474 */       ROWID rOWID = null;
/*      */       
/* 1476 */       setIsNull(3);
/*      */       
/* 1478 */       if (isOnInsertRow() || (isUpdatingRow() && isRowBufferUpdatedAt(paramInt))) {
/*      */ 
/*      */         
/* 1481 */         Datum datum = getRowBufferDatumAt(paramInt);
/*      */         
/* 1483 */         setIsNull((datum == null));
/*      */         
/* 1485 */         if (datum != null && !(datum instanceof ROWID)) {
/*      */           
/* 1487 */           SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getROWID");
/* 1488 */           sQLException.fillInStackTrace();
/* 1489 */           throw sQLException;
/*      */         } 
/*      */         
/* 1492 */         rOWID = (ROWID)datum;
/*      */       }
/*      */       else {
/*      */         
/* 1496 */         setIsNull(4);
/*      */         
/* 1498 */         rOWID = this.resultSet.getROWID(paramInt);
/*      */       } 
/*      */       
/* 1501 */       return rOWID;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public NUMBER getNUMBER(int paramInt) throws SQLException {
/* 1509 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1516 */       ensureOpen();
/* 1517 */       if (this.isRowDeleted) {
/* 1518 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 82);
/* 1519 */         sQLException.fillInStackTrace();
/* 1520 */         throw sQLException;
/*      */       } 
/* 1522 */       NUMBER nUMBER = null;
/*      */       
/* 1524 */       setIsNull(3);
/*      */       
/* 1526 */       if (isOnInsertRow() || (isUpdatingRow() && isRowBufferUpdatedAt(paramInt))) {
/*      */ 
/*      */         
/* 1529 */         Datum datum = getRowBufferDatumAt(paramInt);
/*      */         
/* 1531 */         setIsNull((datum == null));
/*      */         
/* 1533 */         if (datum != null && !(datum instanceof NUMBER)) {
/*      */           
/* 1535 */           SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getNUMBER");
/* 1536 */           sQLException.fillInStackTrace();
/* 1537 */           throw sQLException;
/*      */         } 
/*      */         
/* 1540 */         nUMBER = (NUMBER)datum;
/*      */       }
/*      */       else {
/*      */         
/* 1544 */         setIsNull(4);
/*      */         
/* 1546 */         nUMBER = this.resultSet.getNUMBER(paramInt);
/*      */       } 
/*      */       
/* 1549 */       return nUMBER;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public DATE getDATE(int paramInt) throws SQLException {
/* 1557 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1564 */       ensureOpen();
/* 1565 */       if (this.isRowDeleted) {
/* 1566 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 82);
/* 1567 */         sQLException.fillInStackTrace();
/* 1568 */         throw sQLException;
/*      */       } 
/* 1570 */       DATE dATE = null;
/*      */       
/* 1572 */       setIsNull(3);
/*      */       
/* 1574 */       if (isOnInsertRow() || (isUpdatingRow() && isRowBufferUpdatedAt(paramInt))) {
/*      */ 
/*      */         
/* 1577 */         Datum datum = getRowBufferDatumAt(paramInt);
/*      */         
/* 1579 */         if (datum != null)
/*      */         {
/* 1581 */           if (datum instanceof DATE) { dATE = (DATE)datum; }
/* 1582 */           else if (datum instanceof TIMESTAMP)
/*      */           
/* 1584 */           { Timestamp timestamp = ((TIMESTAMP)datum).timestampValue();
/* 1585 */             dATE = new DATE(timestamp);
/*      */              }
/*      */           
/*      */           else
/*      */           
/* 1590 */           { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getDATE");
/* 1591 */             sQLException.fillInStackTrace();
/* 1592 */             throw sQLException; }
/*      */ 
/*      */         
/*      */         }
/*      */         else
/*      */         {
/* 1598 */           setIsNull((datum == null));
/*      */         }
/*      */       
/*      */       }
/*      */       else {
/*      */         
/* 1604 */         setIsNull(4);
/*      */         
/* 1606 */         dATE = this.resultSet.getDATE(paramInt);
/*      */       } 
/*      */       
/* 1609 */       return dATE;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public TIMESTAMP getTIMESTAMP(int paramInt) throws SQLException {
/* 1617 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1624 */       ensureOpen();
/* 1625 */       if (this.isRowDeleted) {
/* 1626 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 82);
/* 1627 */         sQLException.fillInStackTrace();
/* 1628 */         throw sQLException;
/*      */       } 
/* 1630 */       TIMESTAMP tIMESTAMP = null;
/*      */       
/* 1632 */       setIsNull(3);
/*      */       
/* 1634 */       if (isOnInsertRow() || (isUpdatingRow() && isRowBufferUpdatedAt(paramInt))) {
/*      */ 
/*      */         
/* 1637 */         Datum datum = getRowBufferDatumAt(paramInt);
/*      */         
/* 1639 */         setIsNull((datum == null));
/*      */         
/* 1641 */         if (datum != null && !(datum instanceof TIMESTAMP)) {
/*      */           
/* 1643 */           SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getTIMESTAMP");
/* 1644 */           sQLException.fillInStackTrace();
/* 1645 */           throw sQLException;
/*      */         } 
/*      */         
/* 1648 */         tIMESTAMP = (TIMESTAMP)datum;
/*      */       }
/*      */       else {
/*      */         
/* 1652 */         setIsNull(4);
/*      */         
/* 1654 */         tIMESTAMP = this.resultSet.getTIMESTAMP(paramInt);
/*      */       } 
/*      */       
/* 1657 */       return tIMESTAMP;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public TIMESTAMPTZ getTIMESTAMPTZ(int paramInt) throws SQLException {
/* 1665 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1672 */       ensureOpen();
/* 1673 */       if (this.isRowDeleted) {
/* 1674 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 82);
/* 1675 */         sQLException.fillInStackTrace();
/* 1676 */         throw sQLException;
/*      */       } 
/* 1678 */       TIMESTAMPTZ tIMESTAMPTZ = null;
/*      */       
/* 1680 */       setIsNull(3);
/*      */       
/* 1682 */       if (isOnInsertRow() || (isUpdatingRow() && isRowBufferUpdatedAt(paramInt))) {
/*      */ 
/*      */         
/* 1685 */         Datum datum = getRowBufferDatumAt(paramInt);
/*      */         
/* 1687 */         setIsNull((datum == null));
/*      */         
/* 1689 */         if (datum != null && !(datum instanceof TIMESTAMPTZ)) {
/*      */           
/* 1691 */           SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getTIMESTAMPTZ");
/* 1692 */           sQLException.fillInStackTrace();
/* 1693 */           throw sQLException;
/*      */         } 
/*      */         
/* 1696 */         tIMESTAMPTZ = (TIMESTAMPTZ)datum;
/*      */       }
/*      */       else {
/*      */         
/* 1700 */         setIsNull(4);
/*      */         
/* 1702 */         tIMESTAMPTZ = this.resultSet.getTIMESTAMPTZ(paramInt);
/*      */       } 
/*      */       
/* 1705 */       return tIMESTAMPTZ;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public TIMESTAMPLTZ getTIMESTAMPLTZ(int paramInt) throws SQLException {
/* 1713 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1720 */       ensureOpen();
/* 1721 */       if (this.isRowDeleted) {
/* 1722 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 82);
/* 1723 */         sQLException.fillInStackTrace();
/* 1724 */         throw sQLException;
/*      */       } 
/* 1726 */       TIMESTAMPLTZ tIMESTAMPLTZ = null;
/*      */       
/* 1728 */       setIsNull(3);
/*      */       
/* 1730 */       if (isOnInsertRow() || (isUpdatingRow() && isRowBufferUpdatedAt(paramInt))) {
/*      */ 
/*      */         
/* 1733 */         Datum datum = getRowBufferDatumAt(paramInt);
/*      */         
/* 1735 */         setIsNull((datum == null));
/*      */         
/* 1737 */         if (datum != null && !(datum instanceof TIMESTAMPLTZ)) {
/*      */           
/* 1739 */           SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getTIMESTAMPLTZ");
/* 1740 */           sQLException.fillInStackTrace();
/* 1741 */           throw sQLException;
/*      */         } 
/*      */         
/* 1744 */         tIMESTAMPLTZ = (TIMESTAMPLTZ)datum;
/*      */       }
/*      */       else {
/*      */         
/* 1748 */         setIsNull(4);
/*      */         
/* 1750 */         tIMESTAMPLTZ = this.resultSet.getTIMESTAMPLTZ(paramInt);
/*      */       } 
/*      */       
/* 1753 */       return tIMESTAMPLTZ;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public INTERVALDS getINTERVALDS(int paramInt) throws SQLException {
/* 1761 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1768 */       ensureOpen();
/* 1769 */       if (this.isRowDeleted) {
/* 1770 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 82);
/* 1771 */         sQLException.fillInStackTrace();
/* 1772 */         throw sQLException;
/*      */       } 
/* 1774 */       INTERVALDS iNTERVALDS = null;
/*      */       
/* 1776 */       setIsNull(3);
/*      */       
/* 1778 */       if (isOnInsertRow() || (isUpdatingRow() && isRowBufferUpdatedAt(paramInt))) {
/*      */ 
/*      */         
/* 1781 */         Datum datum = getRowBufferDatumAt(paramInt);
/*      */         
/* 1783 */         setIsNull((datum == null));
/*      */         
/* 1785 */         if (datum != null && !(datum instanceof INTERVALDS)) {
/*      */           
/* 1787 */           SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getINTERVALDS");
/* 1788 */           sQLException.fillInStackTrace();
/* 1789 */           throw sQLException;
/*      */         } 
/*      */         
/* 1792 */         iNTERVALDS = (INTERVALDS)datum;
/*      */       }
/*      */       else {
/*      */         
/* 1796 */         setIsNull(4);
/*      */         
/* 1798 */         iNTERVALDS = this.resultSet.getINTERVALDS(paramInt);
/*      */       } 
/*      */       
/* 1801 */       return iNTERVALDS;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public INTERVALYM getINTERVALYM(int paramInt) throws SQLException {
/* 1809 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1816 */       ensureOpen();
/* 1817 */       if (this.isRowDeleted) {
/* 1818 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 82);
/* 1819 */         sQLException.fillInStackTrace();
/* 1820 */         throw sQLException;
/*      */       } 
/* 1822 */       INTERVALYM iNTERVALYM = null;
/*      */       
/* 1824 */       setIsNull(3);
/*      */       
/* 1826 */       if (isOnInsertRow() || (isUpdatingRow() && isRowBufferUpdatedAt(paramInt))) {
/*      */ 
/*      */         
/* 1829 */         Datum datum = getRowBufferDatumAt(paramInt);
/*      */         
/* 1831 */         setIsNull((datum == null));
/*      */         
/* 1833 */         if (datum != null && !(datum instanceof INTERVALYM)) {
/*      */           
/* 1835 */           SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getINTERVALYM");
/* 1836 */           sQLException.fillInStackTrace();
/* 1837 */           throw sQLException;
/*      */         } 
/*      */         
/* 1840 */         iNTERVALYM = (INTERVALYM)datum;
/*      */       }
/*      */       else {
/*      */         
/* 1844 */         setIsNull(4);
/*      */         
/* 1846 */         iNTERVALYM = this.resultSet.getINTERVALYM(paramInt);
/*      */       } 
/*      */       
/* 1849 */       return iNTERVALYM;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ARRAY getARRAY(int paramInt) throws SQLException {
/* 1857 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1864 */       ensureOpen();
/* 1865 */       if (this.isRowDeleted) {
/* 1866 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 82);
/* 1867 */         sQLException.fillInStackTrace();
/* 1868 */         throw sQLException;
/*      */       } 
/* 1870 */       ARRAY aRRAY = null;
/*      */       
/* 1872 */       setIsNull(3);
/*      */       
/* 1874 */       if (isOnInsertRow() || (isUpdatingRow() && isRowBufferUpdatedAt(paramInt))) {
/*      */ 
/*      */         
/* 1877 */         Datum datum = getRowBufferDatumAt(paramInt);
/*      */         
/* 1879 */         setIsNull((datum == null));
/*      */         
/* 1881 */         if (datum != null && !(datum instanceof ARRAY)) {
/*      */           
/* 1883 */           SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getARRAY");
/* 1884 */           sQLException.fillInStackTrace();
/* 1885 */           throw sQLException;
/*      */         } 
/*      */         
/* 1888 */         aRRAY = (ARRAY)datum;
/*      */       }
/*      */       else {
/*      */         
/* 1892 */         setIsNull(4);
/*      */         
/* 1894 */         aRRAY = this.resultSet.getARRAY(paramInt);
/*      */       } 
/*      */       
/* 1897 */       return aRRAY;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public STRUCT getSTRUCT(int paramInt) throws SQLException {
/* 1905 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1912 */       ensureOpen();
/* 1913 */       if (this.isRowDeleted) {
/* 1914 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 82);
/* 1915 */         sQLException.fillInStackTrace();
/* 1916 */         throw sQLException;
/*      */       } 
/* 1918 */       STRUCT sTRUCT = null;
/*      */       
/* 1920 */       setIsNull(3);
/*      */       
/* 1922 */       if (isOnInsertRow() || (isUpdatingRow() && isRowBufferUpdatedAt(paramInt))) {
/*      */ 
/*      */         
/* 1925 */         Datum datum = getRowBufferDatumAt(paramInt);
/*      */         
/* 1927 */         setIsNull((datum == null));
/*      */         
/* 1929 */         if (datum != null && !(datum instanceof STRUCT)) {
/*      */           
/* 1931 */           SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getSTRUCT");
/* 1932 */           sQLException.fillInStackTrace();
/* 1933 */           throw sQLException;
/*      */         } 
/*      */         
/* 1936 */         sTRUCT = (STRUCT)datum;
/*      */       }
/*      */       else {
/*      */         
/* 1940 */         setIsNull(4);
/*      */         
/* 1942 */         sTRUCT = this.resultSet.getSTRUCT(paramInt);
/*      */       } 
/*      */       
/* 1945 */       return sTRUCT;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public OPAQUE getOPAQUE(int paramInt) throws SQLException {
/* 1953 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1960 */       ensureOpen();
/* 1961 */       if (this.isRowDeleted) {
/* 1962 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 82);
/* 1963 */         sQLException.fillInStackTrace();
/* 1964 */         throw sQLException;
/*      */       } 
/* 1966 */       OPAQUE oPAQUE = null;
/*      */       
/* 1968 */       setIsNull(3);
/*      */       
/* 1970 */       if (isOnInsertRow() || (isUpdatingRow() && isRowBufferUpdatedAt(paramInt))) {
/*      */ 
/*      */         
/* 1973 */         Datum datum = getRowBufferDatumAt(paramInt);
/*      */         
/* 1975 */         setIsNull((datum == null));
/*      */         
/* 1977 */         if (datum != null && !(datum instanceof OPAQUE)) {
/*      */           
/* 1979 */           SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getOPAQUE");
/* 1980 */           sQLException.fillInStackTrace();
/* 1981 */           throw sQLException;
/*      */         } 
/*      */         
/* 1984 */         oPAQUE = (OPAQUE)datum;
/*      */       }
/*      */       else {
/*      */         
/* 1988 */         setIsNull(4);
/*      */         
/* 1990 */         oPAQUE = this.resultSet.getOPAQUE(paramInt);
/*      */       } 
/*      */       
/* 1993 */       return oPAQUE;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public REF getREF(int paramInt) throws SQLException {
/* 2001 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2008 */       ensureOpen();
/* 2009 */       if (this.isRowDeleted) {
/* 2010 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 82);
/* 2011 */         sQLException.fillInStackTrace();
/* 2012 */         throw sQLException;
/*      */       } 
/* 2014 */       REF rEF = null;
/*      */       
/* 2016 */       setIsNull(3);
/*      */       
/* 2018 */       if (isOnInsertRow() || (isUpdatingRow() && isRowBufferUpdatedAt(paramInt))) {
/*      */ 
/*      */         
/* 2021 */         Datum datum = getRowBufferDatumAt(paramInt);
/*      */         
/* 2023 */         setIsNull((datum == null));
/*      */         
/* 2025 */         if (datum != null && !(datum instanceof REF)) {
/*      */           
/* 2027 */           SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getREF");
/* 2028 */           sQLException.fillInStackTrace();
/* 2029 */           throw sQLException;
/*      */         } 
/*      */         
/* 2032 */         rEF = (REF)datum;
/*      */       }
/*      */       else {
/*      */         
/* 2036 */         setIsNull(4);
/*      */         
/* 2038 */         rEF = this.resultSet.getREF(paramInt);
/*      */       } 
/*      */       
/* 2041 */       return rEF;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public CHAR getCHAR(int paramInt) throws SQLException {
/* 2049 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2056 */       ensureOpen();
/* 2057 */       if (this.isRowDeleted) {
/* 2058 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 82);
/* 2059 */         sQLException.fillInStackTrace();
/* 2060 */         throw sQLException;
/*      */       } 
/* 2062 */       CHAR cHAR = null;
/*      */       
/* 2064 */       setIsNull(3);
/*      */       
/* 2066 */       if (isOnInsertRow() || (isUpdatingRow() && isRowBufferUpdatedAt(paramInt))) {
/*      */ 
/*      */         
/* 2069 */         Datum datum = getRowBufferDatumAt(paramInt);
/*      */         
/* 2071 */         setIsNull((datum == null));
/*      */         
/* 2073 */         if (datum != null && !(datum instanceof CHAR)) {
/*      */           
/* 2075 */           SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getCHAR");
/* 2076 */           sQLException.fillInStackTrace();
/* 2077 */           throw sQLException;
/*      */         } 
/*      */         
/* 2080 */         cHAR = (CHAR)datum;
/*      */       }
/*      */       else {
/*      */         
/* 2084 */         setIsNull(4);
/*      */         
/* 2086 */         cHAR = this.resultSet.getCHAR(paramInt);
/*      */       } 
/*      */       
/* 2089 */       return cHAR;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public RAW getRAW(int paramInt) throws SQLException {
/* 2097 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2104 */       ensureOpen();
/* 2105 */       if (this.isRowDeleted) {
/* 2106 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 82);
/* 2107 */         sQLException.fillInStackTrace();
/* 2108 */         throw sQLException;
/*      */       } 
/* 2110 */       RAW rAW = null;
/*      */       
/* 2112 */       setIsNull(3);
/*      */       
/* 2114 */       if (isOnInsertRow() || (isUpdatingRow() && isRowBufferUpdatedAt(paramInt))) {
/*      */ 
/*      */         
/* 2117 */         Datum datum = getRowBufferDatumAt(paramInt);
/*      */         
/* 2119 */         setIsNull((datum == null));
/*      */         
/* 2121 */         if (datum != null && !(datum instanceof RAW)) {
/*      */           
/* 2123 */           SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getRAW");
/* 2124 */           sQLException.fillInStackTrace();
/* 2125 */           throw sQLException;
/*      */         } 
/*      */         
/* 2128 */         rAW = (RAW)datum;
/*      */       }
/*      */       else {
/*      */         
/* 2132 */         setIsNull(4);
/*      */         
/* 2134 */         rAW = this.resultSet.getRAW(paramInt);
/*      */       } 
/*      */       
/* 2137 */       return rAW;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public BLOB getBLOB(int paramInt) throws SQLException {
/* 2145 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2152 */       ensureOpen();
/* 2153 */       if (this.isRowDeleted) {
/* 2154 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 82);
/* 2155 */         sQLException.fillInStackTrace();
/* 2156 */         throw sQLException;
/*      */       } 
/* 2158 */       BLOB bLOB = null;
/*      */       
/* 2160 */       setIsNull(3);
/*      */       
/* 2162 */       if (isOnInsertRow() || (isUpdatingRow() && isRowBufferUpdatedAt(paramInt))) {
/*      */ 
/*      */         
/* 2165 */         Datum datum = getRowBufferDatumAt(paramInt);
/*      */         
/* 2167 */         setIsNull((datum == null));
/*      */         
/* 2169 */         if (datum != null && !(datum instanceof BLOB)) {
/*      */           
/* 2171 */           SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getBLOB");
/* 2172 */           sQLException.fillInStackTrace();
/* 2173 */           throw sQLException;
/*      */         } 
/*      */         
/* 2176 */         bLOB = (BLOB)datum;
/*      */       }
/*      */       else {
/*      */         
/* 2180 */         setIsNull(4);
/*      */         
/* 2182 */         bLOB = this.resultSet.getBLOB(paramInt);
/*      */       } 
/*      */       
/* 2185 */       return bLOB;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public NCLOB getNCLOB(int paramInt) throws SQLException {
/* 2193 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2200 */       ensureOpen();
/* 2201 */       if (this.isRowDeleted) {
/* 2202 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 82);
/* 2203 */         sQLException.fillInStackTrace();
/* 2204 */         throw sQLException;
/*      */       } 
/* 2206 */       NCLOB nCLOB = null;
/*      */       
/* 2208 */       setIsNull(3);
/*      */       
/* 2210 */       if (isOnInsertRow() || (isUpdatingRow() && isRowBufferUpdatedAt(paramInt))) {
/*      */ 
/*      */         
/* 2213 */         Datum datum = getRowBufferDatumAt(paramInt);
/*      */         
/* 2215 */         setIsNull((datum == null));
/*      */         
/* 2217 */         if (datum != null && !(datum instanceof NCLOB)) {
/*      */           
/* 2219 */           SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getCLOB");
/* 2220 */           sQLException.fillInStackTrace();
/* 2221 */           throw sQLException;
/*      */         } 
/*      */         
/* 2224 */         nCLOB = (NCLOB)datum;
/*      */       }
/*      */       else {
/*      */         
/* 2228 */         setIsNull(4);
/*      */         
/* 2230 */         nCLOB = (NCLOB)this.resultSet.getNClob(paramInt);
/*      */       } 
/*      */       
/* 2233 */       return nCLOB;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public CLOB getCLOB(int paramInt) throws SQLException {
/* 2241 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2248 */       ensureOpen();
/* 2249 */       if (this.isRowDeleted) {
/* 2250 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 82);
/* 2251 */         sQLException.fillInStackTrace();
/* 2252 */         throw sQLException;
/*      */       } 
/* 2254 */       CLOB cLOB = null;
/*      */       
/* 2256 */       setIsNull(3);
/*      */       
/* 2258 */       if (isOnInsertRow() || (isUpdatingRow() && isRowBufferUpdatedAt(paramInt))) {
/*      */ 
/*      */         
/* 2261 */         Datum datum = getRowBufferDatumAt(paramInt);
/*      */         
/* 2263 */         setIsNull((datum == null));
/*      */         
/* 2265 */         if (datum != null && !(datum instanceof CLOB)) {
/*      */           
/* 2267 */           SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getCLOB");
/* 2268 */           sQLException.fillInStackTrace();
/* 2269 */           throw sQLException;
/*      */         } 
/*      */         
/* 2272 */         cLOB = (CLOB)datum;
/*      */       }
/*      */       else {
/*      */         
/* 2276 */         setIsNull(4);
/*      */         
/* 2278 */         cLOB = this.resultSet.getCLOB(paramInt);
/*      */       } 
/*      */       
/* 2281 */       return cLOB;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public BFILE getBFILE(int paramInt) throws SQLException {
/* 2289 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2296 */       ensureOpen();
/* 2297 */       if (this.isRowDeleted) {
/* 2298 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 82);
/* 2299 */         sQLException.fillInStackTrace();
/* 2300 */         throw sQLException;
/*      */       } 
/* 2302 */       BFILE bFILE = null;
/*      */       
/* 2304 */       setIsNull(3);
/*      */       
/* 2306 */       if (isOnInsertRow() || (isUpdatingRow() && isRowBufferUpdatedAt(paramInt))) {
/*      */ 
/*      */         
/* 2309 */         Datum datum = getRowBufferDatumAt(paramInt);
/*      */         
/* 2311 */         setIsNull((datum == null));
/*      */         
/* 2313 */         if (datum != null && !(datum instanceof BFILE)) {
/*      */           
/* 2315 */           SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getBFILE");
/* 2316 */           sQLException.fillInStackTrace();
/* 2317 */           throw sQLException;
/*      */         } 
/*      */         
/* 2320 */         bFILE = (BFILE)datum;
/*      */       }
/*      */       else {
/*      */         
/* 2324 */         setIsNull(4);
/*      */         
/* 2326 */         bFILE = this.resultSet.getBFILE(paramInt);
/*      */       } 
/*      */       
/* 2329 */       return bFILE;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public BFILE getBfile(int paramInt) throws SQLException {
/* 2337 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2344 */       ensureOpen();
/* 2345 */       if (this.isRowDeleted) {
/* 2346 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 82);
/* 2347 */         sQLException.fillInStackTrace();
/* 2348 */         throw sQLException;
/*      */       } 
/* 2350 */       return getBFILE(paramInt);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public CustomDatum getCustomDatum(int paramInt, CustomDatumFactory paramCustomDatumFactory) throws SQLException {
/* 2359 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2366 */       ensureOpen();
/* 2367 */       if (this.isRowDeleted) {
/* 2368 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 82);
/* 2369 */         sQLException.fillInStackTrace();
/* 2370 */         throw sQLException;
/*      */       } 
/* 2372 */       if (paramCustomDatumFactory == null) {
/*      */         
/* 2374 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/* 2375 */         sQLException.fillInStackTrace();
/* 2376 */         throw sQLException;
/*      */       } 
/*      */       
/* 2379 */       CustomDatum customDatum = null;
/*      */       
/* 2381 */       setIsNull(3);
/*      */       
/* 2383 */       if (isOnInsertRow() || (isUpdatingRow() && isRowBufferUpdatedAt(paramInt))) {
/*      */ 
/*      */         
/* 2386 */         Datum datum = getRowBufferDatumAt(paramInt);
/*      */         
/* 2388 */         setIsNull((datum == null));
/*      */         
/* 2390 */         customDatum = paramCustomDatumFactory.create(datum, 0);
/*      */       }
/*      */       else {
/*      */         
/* 2394 */         setIsNull(4);
/*      */         
/* 2396 */         customDatum = this.resultSet.getCustomDatum(paramInt, paramCustomDatumFactory);
/*      */       } 
/*      */       
/* 2399 */       return customDatum;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ORAData getORAData(int paramInt, ORADataFactory paramORADataFactory) throws SQLException {
/* 2408 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2415 */       ensureOpen();
/* 2416 */       if (this.isRowDeleted) {
/* 2417 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 82);
/* 2418 */         sQLException.fillInStackTrace();
/* 2419 */         throw sQLException;
/*      */       } 
/* 2421 */       if (paramORADataFactory == null) {
/*      */         
/* 2423 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/* 2424 */         sQLException.fillInStackTrace();
/* 2425 */         throw sQLException;
/*      */       } 
/*      */       
/* 2428 */       ORAData oRAData = null;
/*      */       
/* 2430 */       setIsNull(3);
/*      */       
/* 2432 */       if (isOnInsertRow() || (isUpdatingRow() && isRowBufferUpdatedAt(paramInt))) {
/*      */ 
/*      */         
/* 2435 */         Datum datum = getRowBufferDatumAt(paramInt);
/*      */         
/* 2437 */         setIsNull((datum == null));
/*      */         
/* 2439 */         oRAData = paramORADataFactory.create(datum, 0);
/*      */       }
/*      */       else {
/*      */         
/* 2443 */         setIsNull(4);
/*      */         
/* 2445 */         oRAData = this.resultSet.getORAData(paramInt, paramORADataFactory);
/*      */       } 
/*      */       
/* 2448 */       return oRAData;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public NClob getNClob(int paramInt) throws SQLException {
/* 2461 */     ensureOpen();
/* 2462 */     if (this.isRowDeleted) {
/* 2463 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 82);
/* 2464 */       sQLException.fillInStackTrace();
/* 2465 */       throw sQLException;
/*      */     } 
/* 2467 */     NCLOB nCLOB = getNCLOB(paramInt);
/*      */     
/* 2469 */     if (nCLOB == null) return null;
/*      */     
/* 2471 */     if (!(nCLOB instanceof NClob)) {
/*      */       
/* 2473 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 184);
/* 2474 */       sQLException.fillInStackTrace();
/* 2475 */       throw sQLException;
/*      */     } 
/*      */     
/* 2478 */     return (NClob)nCLOB;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getNString(int paramInt) throws SQLException {
/* 2490 */     ensureOpen();
/* 2491 */     if (this.isRowDeleted) {
/* 2492 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 82);
/* 2493 */       sQLException.fillInStackTrace();
/* 2494 */       throw sQLException;
/*      */     } 
/* 2496 */     return getString(paramInt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Reader getNCharacterStream(int paramInt) throws SQLException {
/* 2508 */     ensureOpen();
/* 2509 */     if (this.isRowDeleted) {
/* 2510 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 82);
/* 2511 */       sQLException.fillInStackTrace();
/* 2512 */       throw sQLException;
/*      */     } 
/* 2514 */     return getCharacterStream(paramInt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public RowId getRowId(int paramInt) throws SQLException {
/* 2526 */     ensureOpen();
/* 2527 */     if (this.isRowDeleted) {
/* 2528 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 82);
/* 2529 */       sQLException.fillInStackTrace();
/* 2530 */       throw sQLException;
/*      */     } 
/* 2532 */     return (RowId)getROWID(paramInt);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public SQLXML getSQLXML(int paramInt) throws SQLException {
/* 2538 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2545 */       ensureOpen();
/* 2546 */       if (this.isRowDeleted) {
/* 2547 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 82);
/* 2548 */         sQLException.fillInStackTrace();
/* 2549 */         throw sQLException;
/*      */       } 
/* 2551 */       SQLXML sQLXML = null;
/*      */       
/* 2553 */       setIsNull(3);
/*      */       
/* 2555 */       if (isOnInsertRow() || (isUpdatingRow() && isRowBufferUpdatedAt(paramInt))) {
/*      */ 
/*      */         
/* 2558 */         Datum datum = getRowBufferDatumAt(paramInt);
/*      */         
/* 2560 */         setIsNull((datum == null));
/*      */         
/* 2562 */         if (datum != null && !(datum instanceof SQLXML)) {
/*      */           
/* 2564 */           SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getSQLXML");
/* 2565 */           sQLException.fillInStackTrace();
/* 2566 */           throw sQLException;
/*      */         } 
/*      */         
/* 2569 */         sQLXML = (SQLXML)datum;
/*      */       }
/*      */       else {
/*      */         
/* 2573 */         setIsNull(4);
/*      */         
/* 2575 */         sQLXML = this.resultSet.getSQLXML(paramInt);
/*      */       } 
/*      */       
/* 2578 */       return sQLXML;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateRowId(int paramInt, RowId paramRowId) throws SQLException {
/* 2596 */     updateROWID(paramInt, (ROWID)paramRowId);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateNCharacterStream(int paramInt, Reader paramReader, long paramLong) throws SQLException {
/* 2610 */     updateCharacterStream(paramInt, paramReader, paramLong);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateNCharacterStream(int paramInt, Reader paramReader) throws SQLException {
/* 2623 */     updateCharacterStream(paramInt, paramReader);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateSQLXML(int paramInt, SQLXML paramSQLXML) throws SQLException {
/* 2634 */     updateOracleObject(paramInt, (Datum)paramSQLXML);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateNString(int paramInt, String paramString) throws SQLException {
/* 2645 */     updateString(paramInt, paramString);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateNClob(int paramInt, NClob paramNClob) throws SQLException {
/* 2656 */     updateClob(paramInt, paramNClob);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateAsciiStream(int paramInt, InputStream paramInputStream, long paramLong) throws SQLException {
/* 2668 */     updateAsciiStream(paramInt, paramInputStream, (int)paramLong);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateAsciiStream(int paramInt, InputStream paramInputStream) throws SQLException {
/* 2680 */     updateAsciiStream(paramInt, paramInputStream, 2147483647);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateBinaryStream(int paramInt, InputStream paramInputStream, long paramLong) throws SQLException {
/* 2692 */     updateBinaryStream(paramInt, paramInputStream, (int)paramLong);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateBinaryStream(int paramInt, InputStream paramInputStream) throws SQLException {
/* 2704 */     updateBinaryStream(paramInt, paramInputStream, 2147483647);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateCharacterStream(int paramInt, Reader paramReader, long paramLong) throws SQLException {
/* 2716 */     updateCharacterStream(paramInt, paramReader, (int)paramLong);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateCharacterStream(int paramInt, Reader paramReader) throws SQLException {
/* 2728 */     updateCharacterStream(paramInt, paramReader, 2147483647);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateBlob(int paramInt, InputStream paramInputStream) throws SQLException {
/* 2740 */     Blob blob = this.connection.createBlob();
/* 2741 */     addToTempLobsToFree(blob);
/* 2742 */     int i = ((BLOB)blob).getBufferSize();
/* 2743 */     OutputStream outputStream = blob.setBinaryStream(1L);
/* 2744 */     byte[] arrayOfByte = new byte[i];
/*      */ 
/*      */     
/*      */     try {
/*      */       while (true) {
/* 2749 */         int j = paramInputStream.read(arrayOfByte);
/* 2750 */         if (j == -1)
/* 2751 */           break;  outputStream.write(arrayOfByte, 0, j);
/*      */       } 
/* 2753 */       outputStream.close();
/* 2754 */       updateBlob(paramInt, blob);
/* 2755 */     } catch (IOException iOException) {
/*      */ 
/*      */       
/* 2758 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException);
/* 2759 */       sQLException.fillInStackTrace();
/* 2760 */       throw sQLException;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateBlob(int paramInt, InputStream paramInputStream, long paramLong) throws SQLException {
/* 2774 */     Blob blob = this.connection.createBlob();
/* 2775 */     addToTempLobsToFree(blob);
/* 2776 */     int i = ((BLOB)blob).getBufferSize();
/* 2777 */     OutputStream outputStream = blob.setBinaryStream(1L);
/* 2778 */     byte[] arrayOfByte = new byte[i];
/* 2779 */     long l = paramLong;
/*      */     
/*      */     try {
/* 2782 */       while (l > 0L) {
/*      */         
/* 2784 */         int j = paramInputStream.read(arrayOfByte, 0, Math.min(i, (int)l));
/* 2785 */         if (j == -1)
/* 2786 */           break;  outputStream.write(arrayOfByte, 0, j);
/*      */         
/* 2788 */         l -= j;
/*      */       } 
/* 2790 */       outputStream.close();
/* 2791 */       updateBlob(paramInt, blob);
/* 2792 */     } catch (IOException iOException) {
/*      */ 
/*      */       
/* 2795 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException);
/* 2796 */       sQLException.fillInStackTrace();
/* 2797 */       throw sQLException;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateClob(int paramInt, Reader paramReader, long paramLong) throws SQLException {
/* 2811 */     updateClob(paramInt, paramReader, paramLong, (short)1);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void updateClob(int paramInt, Reader paramReader, long paramLong, short paramShort) throws SQLException {
/* 2824 */     Clob clob = (paramShort == 1) ? this.connection.createClob() : this.connection.createNClob();
/*      */ 
/*      */     
/* 2827 */     addToTempLobsToFree(clob);
/* 2828 */     int i = ((CLOB)clob).getBufferSize();
/* 2829 */     Writer writer = clob.setCharacterStream(1L);
/* 2830 */     char[] arrayOfChar = new char[i];
/* 2831 */     long l = paramLong;
/*      */     
/*      */     try {
/* 2834 */       while (l > 0L) {
/*      */         
/* 2836 */         int j = paramReader.read(arrayOfChar, 0, Math.min(i, (int)l));
/* 2837 */         if (j == -1)
/* 2838 */           break;  writer.write(arrayOfChar, 0, j);
/*      */         
/* 2840 */         l -= j;
/*      */       } 
/* 2842 */       writer.close();
/* 2843 */       updateClob(paramInt, clob);
/* 2844 */     } catch (IOException iOException) {
/*      */ 
/*      */       
/* 2847 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException);
/* 2848 */       sQLException.fillInStackTrace();
/* 2849 */       throw sQLException;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateClob(int paramInt, Reader paramReader) throws SQLException {
/* 2864 */     Clob clob = this.connection.createClob();
/* 2865 */     addToTempLobsToFree(clob);
/* 2866 */     int i = ((CLOB)clob).getBufferSize();
/* 2867 */     Writer writer = clob.setCharacterStream(1L);
/* 2868 */     char[] arrayOfChar = new char[i];
/*      */ 
/*      */     
/*      */     try {
/*      */       while (true) {
/* 2873 */         int j = paramReader.read(arrayOfChar);
/* 2874 */         if (j == -1)
/* 2875 */           break;  writer.write(arrayOfChar, 0, j);
/*      */       } 
/* 2877 */       writer.close();
/* 2878 */       updateClob(paramInt, clob);
/* 2879 */     } catch (IOException iOException) {
/*      */ 
/*      */       
/* 2882 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException);
/* 2883 */       sQLException.fillInStackTrace();
/* 2884 */       throw sQLException;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void updateClob(int paramInt1, InputStream paramInputStream, int paramInt2) throws SQLException {
/* 2899 */     updateClob(paramInt1, paramInputStream, paramInt2, (short)1);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void updateClob(int paramInt1, InputStream paramInputStream, int paramInt2, short paramShort) throws SQLException {
/* 2914 */     Clob clob = (paramShort == 1) ? this.connection.createClob() : this.connection.createNClob();
/*      */ 
/*      */     
/* 2917 */     addToTempLobsToFree(clob);
/* 2918 */     int i = ((CLOB)clob).getBufferSize();
/* 2919 */     OutputStream outputStream = clob.setAsciiStream(1L);
/* 2920 */     byte[] arrayOfByte = new byte[i];
/* 2921 */     long l = paramInt2;
/*      */     
/*      */     try {
/* 2924 */       while (l > 0L) {
/*      */         
/* 2926 */         int j = paramInputStream.read(arrayOfByte, 0, Math.min(i, (int)l));
/* 2927 */         if (j == -1)
/* 2928 */           break;  outputStream.write(arrayOfByte, 0, j);
/*      */         
/* 2930 */         l -= j;
/*      */       } 
/* 2932 */       outputStream.close();
/* 2933 */       updateClob(paramInt1, clob);
/* 2934 */     } catch (IOException iOException) {
/*      */ 
/*      */       
/* 2937 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException);
/* 2938 */       sQLException.fillInStackTrace();
/* 2939 */       throw sQLException;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void updateNClob(int paramInt1, InputStream paramInputStream, int paramInt2) throws SQLException {
/* 2955 */     NClob nClob = this.connection.createNClob();
/* 2956 */     addToTempLobsToFree(nClob);
/* 2957 */     int i = ((NCLOB)nClob).getBufferSize();
/* 2958 */     OutputStream outputStream = nClob.setAsciiStream(1L);
/* 2959 */     byte[] arrayOfByte = new byte[i];
/* 2960 */     long l = paramInt2;
/*      */     
/*      */     try {
/* 2963 */       while (l > 0L) {
/*      */         
/* 2965 */         int j = paramInputStream.read(arrayOfByte, 0, Math.min(i, (int)l));
/* 2966 */         if (j == -1)
/* 2967 */           break;  outputStream.write(arrayOfByte, 0, j);
/*      */         
/* 2969 */         l -= j;
/*      */       } 
/* 2971 */       outputStream.close();
/* 2972 */       updateNClob(paramInt1, nClob);
/* 2973 */     } catch (IOException iOException) {
/*      */ 
/*      */       
/* 2976 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException);
/* 2977 */       sQLException.fillInStackTrace();
/* 2978 */       throw sQLException;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateNClob(int paramInt, Reader paramReader, long paramLong) throws SQLException {
/* 2993 */     if (paramReader == null) {
/*      */       
/* 2995 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68, "updateNClob");
/* 2996 */       sQLException.fillInStackTrace();
/* 2997 */       throw sQLException;
/*      */     } 
/*      */     
/* 3000 */     NClob nClob = this.connection.createNClob();
/* 3001 */     addToTempLobsToFree(nClob);
/* 3002 */     int i = ((CLOB)nClob).getBufferSize();
/* 3003 */     Writer writer = nClob.setCharacterStream(1L);
/* 3004 */     char[] arrayOfChar = new char[i];
/* 3005 */     long l = paramLong;
/*      */     
/*      */     try {
/* 3008 */       while (l > 0L) {
/*      */         
/* 3010 */         int j = paramReader.read(arrayOfChar, 0, Math.min(i, (int)l));
/* 3011 */         if (j == -1)
/* 3012 */           break;  writer.write(arrayOfChar, 0, j);
/*      */         
/* 3014 */         l -= j;
/*      */       } 
/* 3016 */       writer.close();
/* 3017 */       updateNClob(paramInt, nClob);
/* 3018 */     } catch (IOException iOException) {
/*      */ 
/*      */       
/* 3021 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException);
/* 3022 */       sQLException.fillInStackTrace();
/* 3023 */       throw sQLException;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateNClob(int paramInt, Reader paramReader) throws SQLException {
/* 3038 */     if (paramReader == null) {
/*      */       
/* 3040 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68, "updateNClob");
/* 3041 */       sQLException.fillInStackTrace();
/* 3042 */       throw sQLException;
/*      */     } 
/*      */     
/* 3045 */     NClob nClob = this.connection.createNClob();
/* 3046 */     addToTempLobsToFree(nClob);
/* 3047 */     int i = ((CLOB)nClob).getBufferSize();
/* 3048 */     Writer writer = nClob.setCharacterStream(1L);
/* 3049 */     char[] arrayOfChar = new char[i];
/*      */ 
/*      */     
/*      */     try {
/*      */       while (true) {
/* 3054 */         int j = paramReader.read(arrayOfChar);
/* 3055 */         if (j == -1)
/* 3056 */           break;  writer.write(arrayOfChar, 0, j);
/*      */       } 
/* 3058 */       writer.close();
/* 3059 */       updateNClob(paramInt, nClob);
/* 3060 */     } catch (IOException iOException) {
/*      */ 
/*      */       
/* 3063 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException);
/* 3064 */       sQLException.fillInStackTrace();
/* 3065 */       throw sQLException;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateString(int paramInt, String paramString) throws SQLException {
/* 3074 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 3081 */       if (paramString == null || paramString.length() == 0) {
/* 3082 */         updateNull(paramInt);
/*      */       } else {
/* 3084 */         updateObject(paramInt, paramString);
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateBoolean(int paramInt, boolean paramBoolean) throws SQLException {
/* 3097 */     updateObject(paramInt, Boolean.valueOf(paramBoolean));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateByte(int paramInt, byte paramByte) throws SQLException {
/* 3109 */     updateObject(paramInt, Integer.valueOf(paramByte));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateShort(int paramInt, short paramShort) throws SQLException {
/* 3121 */     updateObject(paramInt, Integer.valueOf(paramShort));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateInt(int paramInt1, int paramInt2) throws SQLException {
/* 3133 */     updateObject(paramInt1, Integer.valueOf(paramInt2));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateLong(int paramInt, long paramLong) throws SQLException {
/* 3145 */     updateObject(paramInt, Long.valueOf(paramLong));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateFloat(int paramInt, float paramFloat) throws SQLException {
/* 3157 */     updateObject(paramInt, Float.valueOf(paramFloat));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateDouble(int paramInt, double paramDouble) throws SQLException {
/* 3169 */     updateObject(paramInt, Double.valueOf(paramDouble));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateBigDecimal(int paramInt, BigDecimal paramBigDecimal) throws SQLException {
/* 3182 */     updateObject(paramInt, paramBigDecimal);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateBytes(int paramInt, byte[] paramArrayOfbyte) throws SQLException {
/* 3194 */     updateObject(paramInt, paramArrayOfbyte);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateDate(int paramInt, Date paramDate) throws SQLException {
/* 3206 */     updateObject(paramInt, paramDate);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateTime(int paramInt, Time paramTime) throws SQLException {
/* 3218 */     updateObject(paramInt, paramTime);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateTimestamp(int paramInt, Timestamp paramTimestamp) throws SQLException {
/* 3231 */     updateObject(paramInt, paramTimestamp);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateAsciiStream(int paramInt1, InputStream paramInputStream, int paramInt2) throws SQLException {
/* 3245 */     ensureOpen();
/* 3246 */     if (this.isRowDeleted) {
/* 3247 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 82);
/* 3248 */       sQLException.fillInStackTrace();
/* 3249 */       throw sQLException;
/*      */     } 
/* 3251 */     OracleResultSetMetaData oracleResultSetMetaData = (OracleResultSetMetaData)getInternalMetadata();
/* 3252 */     int i = oracleResultSetMetaData.getColumnType(paramInt1);
/* 3253 */     if (paramInputStream != null && paramInt2 > 0) {
/*      */       int[] arrayOfInt;
/* 3255 */       switch (i) {
/*      */         
/*      */         case 2005:
/* 3258 */           updateClob(paramInt1, paramInputStream, paramInt2);
/*      */           return;
/*      */         
/*      */         case 2011:
/* 3262 */           updateNClob(paramInt1, paramInputStream, paramInt2);
/*      */           return;
/*      */ 
/*      */         
/*      */         case 2004:
/* 3267 */           updateBlob(paramInt1, paramInputStream, paramInt2);
/*      */           return;
/*      */         
/*      */         case -1:
/* 3271 */           arrayOfInt = new int[] { paramInt2, 1 };
/*      */ 
/*      */ 
/*      */           
/* 3275 */           setRowBufferAt(paramInt1, paramInputStream, arrayOfInt);
/*      */           return;
/*      */       } 
/*      */ 
/*      */       
/*      */       try {
/* 3281 */         int j = 0;
/* 3282 */         int k = paramInt2;
/* 3283 */         byte[] arrayOfByte = new byte[1024];
/* 3284 */         char[] arrayOfChar = new char[1024];
/* 3285 */         StringBuilder stringBuilder = new StringBuilder(1024);
/*      */         
/* 3287 */         while (k > 0) {
/*      */           
/* 3289 */           if (k >= 1024) {
/* 3290 */             j = paramInputStream.read(arrayOfByte);
/*      */           } else {
/* 3292 */             j = paramInputStream.read(arrayOfByte, 0, k);
/*      */           } 
/*      */ 
/*      */           
/* 3296 */           if (j == -1) {
/*      */             break;
/*      */           }
/* 3299 */           DBConversion.asciiBytesToJavaChars(arrayOfByte, j, arrayOfChar);
/*      */           
/* 3301 */           stringBuilder.append(arrayOfChar, 0, j);
/* 3302 */           k -= j;
/*      */         } 
/*      */         
/* 3305 */         paramInputStream.close();
/* 3306 */         if (k == paramInt2) {
/*      */           
/* 3308 */           updateNull(paramInt1);
/*      */           
/*      */           return;
/*      */         } 
/* 3312 */         updateString(paramInt1, stringBuilder.toString());
/*      */       }
/* 3314 */       catch (IOException iOException) {
/*      */ 
/*      */         
/* 3317 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException);
/* 3318 */         sQLException.fillInStackTrace();
/* 3319 */         throw sQLException;
/*      */       
/*      */       }
/*      */     
/*      */     }
/*      */     else {
/*      */       
/* 3326 */       setRowBufferAt(paramInt1, (Datum)null);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateBinaryStream(int paramInt1, InputStream paramInputStream, int paramInt2) throws SQLException {
/* 3340 */     ensureOpen();
/* 3341 */     if (this.isRowDeleted) {
/* 3342 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 82);
/* 3343 */       sQLException.fillInStackTrace();
/* 3344 */       throw sQLException;
/*      */     } 
/* 3346 */     int i = getInternalMetadata().getColumnType(paramInt1);
/* 3347 */     if (paramInputStream != null && paramInt2 > 0) {
/*      */       int[] arrayOfInt;
/* 3349 */       switch (i) {
/*      */         
/*      */         case 2004:
/* 3352 */           updateBlob(paramInt1, paramInputStream, paramInt2);
/*      */           return;
/*      */         
/*      */         case -4:
/* 3356 */           arrayOfInt = new int[] { paramInt2, 2 };
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 3361 */           setRowBufferAt(paramInt1, paramInputStream, arrayOfInt);
/*      */           return;
/*      */       } 
/*      */ 
/*      */       
/*      */       try {
/* 3367 */         int j = 0;
/* 3368 */         int k = paramInt2;
/* 3369 */         byte[] arrayOfByte = new byte[1024];
/* 3370 */         ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream(1024);
/*      */ 
/*      */         
/* 3373 */         while (k > 0) {
/*      */           
/* 3375 */           if (k >= 1024) {
/* 3376 */             j = paramInputStream.read(arrayOfByte);
/*      */           } else {
/* 3378 */             j = paramInputStream.read(arrayOfByte, 0, k);
/*      */           } 
/*      */ 
/*      */           
/* 3382 */           if (j == -1) {
/*      */             break;
/*      */           }
/* 3385 */           byteArrayOutputStream.write(arrayOfByte, 0, j);
/* 3386 */           k -= j;
/*      */         } 
/*      */         
/* 3389 */         paramInputStream.close();
/* 3390 */         if (k == paramInt2) {
/*      */           
/* 3392 */           updateNull(paramInt1);
/*      */           
/*      */           return;
/*      */         } 
/* 3396 */         updateBytes(paramInt1, byteArrayOutputStream.toByteArray());
/*      */       }
/* 3398 */       catch (IOException iOException) {
/*      */ 
/*      */         
/* 3401 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException);
/* 3402 */         sQLException.fillInStackTrace();
/* 3403 */         throw sQLException;
/*      */ 
/*      */       
/*      */       }
/*      */ 
/*      */     
/*      */     }
/*      */     else {
/*      */ 
/*      */       
/* 3413 */       setRowBufferAt(paramInt1, (Datum)null);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateCharacterStream(int paramInt1, Reader paramReader, int paramInt2) throws SQLException {
/* 3421 */     int i = 0, j = paramInt2;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 3429 */     ensureOpen();
/* 3430 */     if (this.isRowDeleted) {
/* 3431 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 82);
/* 3432 */       sQLException.fillInStackTrace();
/* 3433 */       throw sQLException;
/*      */     } 
/* 3435 */     OracleResultSetMetaData oracleResultSetMetaData = (OracleResultSetMetaData)getInternalMetadata();
/* 3436 */     int k = oracleResultSetMetaData.getColumnType(paramInt1);
/* 3437 */     if (paramReader != null && paramInt2 > 0) {
/*      */       int[] arrayOfInt;
/* 3439 */       switch (k) {
/*      */         
/*      */         case 2005:
/* 3442 */           updateClob(paramInt1, paramReader, paramInt2);
/*      */           return;
/*      */         
/*      */         case 2011:
/* 3446 */           updateNClob(paramInt1, paramReader, paramInt2);
/*      */           return;
/*      */         
/*      */         case -1:
/* 3450 */           arrayOfInt = new int[] { paramInt2 };
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 3455 */           setRowBufferAt(paramInt1, paramReader, arrayOfInt);
/*      */           return;
/*      */       } 
/*      */ 
/*      */       
/*      */       try {
/* 3461 */         char[] arrayOfChar = new char[1024];
/* 3462 */         StringBuilder stringBuilder = new StringBuilder(1024);
/*      */         
/* 3464 */         while (j > 0) {
/*      */           
/* 3466 */           if (j >= 1024) {
/* 3467 */             i = paramReader.read(arrayOfChar);
/*      */           } else {
/* 3469 */             i = paramReader.read(arrayOfChar, 0, j);
/*      */           } 
/*      */ 
/*      */           
/* 3473 */           if (i == -1) {
/*      */             break;
/*      */           }
/* 3476 */           stringBuilder.append(arrayOfChar, 0, i);
/* 3477 */           j -= i;
/*      */         } 
/*      */         
/* 3480 */         paramReader.close();
/* 3481 */         if (j == paramInt2) {
/*      */           
/* 3483 */           updateNull(paramInt1);
/*      */           
/*      */           return;
/*      */         } 
/* 3487 */         updateString(paramInt1, stringBuilder.toString());
/*      */       }
/* 3489 */       catch (IOException iOException) {
/*      */ 
/*      */         
/* 3492 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException);
/* 3493 */         sQLException.fillInStackTrace();
/* 3494 */         throw sQLException;
/*      */       
/*      */       }
/*      */ 
/*      */     
/*      */     }
/*      */     else {
/*      */       
/* 3502 */       setRowBufferAt(paramInt1, (Datum)null);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateObject(int paramInt1, Object paramObject, int paramInt2) throws SQLException {
/* 3516 */     updateObject(paramInt1, paramObject);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateObject(int paramInt, Object paramObject) throws SQLException {
/* 3523 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 3530 */       ensureOpen();
/* 3531 */       if (this.isRowDeleted) {
/* 3532 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 82);
/* 3533 */         sQLException.fillInStackTrace();
/* 3534 */         throw sQLException;
/*      */       } 
/* 3536 */       Datum datum = null;
/* 3537 */       if (paramObject != null) {
/*      */         
/* 3539 */         if (paramObject instanceof OracleData) {
/*      */           
/* 3541 */           Object object = ((OracleData)paramObject).toJDBCObject((Connection)this.connection);
/*      */ 
/*      */ 
/*      */           
/* 3545 */           if (object instanceof _Proxy_) {
/*      */             
/* 3547 */             final _Proxy_ proxiedJDBCObject = (_Proxy_)object;
/* 3548 */             object = AccessController.doPrivileged(new PrivilegedAction()
/*      */                 {
/*      */                   
/*      */                   public Object run()
/*      */                   {
/* 3553 */                     return ProxyFactory.extractDelegate(proxiedJDBCObject);
/*      */                   }
/*      */                 });
/*      */           } 
/* 3557 */           paramObject = object;
/*      */         } 
/* 3559 */         if (paramObject instanceof Datum) {
/*      */           
/* 3561 */           datum = (Datum)paramObject;
/*      */         }
/*      */         else {
/*      */           
/* 3565 */           OracleResultSetMetaData oracleResultSetMetaData = (OracleResultSetMetaData)getInternalMetadata();
/* 3566 */           int i = paramInt;
/*      */           
/* 3568 */           int j = oracleResultSetMetaData.getColumnType(i);
/*      */           
/* 3570 */           switch (j) {
/*      */ 
/*      */             
/*      */             case -15:
/*      */             case -9:
/*      */             case -1:
/*      */             case 1:
/*      */             case 12:
/* 3578 */               if (paramObject instanceof byte[]) {
/* 3579 */                 byte[] arrayOfByte = (byte[])paramObject;
/*      */ 
/*      */                 
/* 3582 */                 char[] arrayOfChar = new char[arrayOfByte.length * 3];
/* 3583 */                 int k = DBConversion.RAWBytesToHexChars(arrayOfByte, arrayOfByte.length, arrayOfChar);
/*      */                 
/* 3585 */                 paramObject = new String(arrayOfChar, 0, k);
/*      */               }  break;
/*      */           } 
/* 3588 */           datum = SQLUtil.makeOracleDatum(this.connection, paramObject, oracleResultSetMetaData.getColumnType(i), null, oracleResultSetMetaData.isNCHAR(i));
/*      */         } 
/*      */       } 
/*      */ 
/*      */       
/* 3593 */       setRowBufferAt(paramInt, datum);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateOracleObject(int paramInt, Datum paramDatum) throws SQLException {
/* 3601 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 3608 */       setRowBufferAt(paramInt, paramDatum);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateROWID(int paramInt, ROWID paramROWID) throws SQLException {
/* 3621 */     updateOracleObject(paramInt, (Datum)paramROWID);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateNUMBER(int paramInt, NUMBER paramNUMBER) throws SQLException {
/* 3633 */     updateOracleObject(paramInt, (Datum)paramNUMBER);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateDATE(int paramInt, DATE paramDATE) throws SQLException {
/* 3645 */     updateOracleObject(paramInt, (Datum)paramDATE);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateINTERVALYM(int paramInt, INTERVALYM paramINTERVALYM) throws SQLException {
/* 3658 */     updateOracleObject(paramInt, (Datum)paramINTERVALYM);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateINTERVALDS(int paramInt, INTERVALDS paramINTERVALDS) throws SQLException {
/* 3671 */     updateOracleObject(paramInt, (Datum)paramINTERVALDS);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateTIMESTAMP(int paramInt, TIMESTAMP paramTIMESTAMP) throws SQLException {
/* 3683 */     updateOracleObject(paramInt, (Datum)paramTIMESTAMP);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateTIMESTAMPTZ(int paramInt, TIMESTAMPTZ paramTIMESTAMPTZ) throws SQLException {
/* 3696 */     updateOracleObject(paramInt, (Datum)paramTIMESTAMPTZ);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateTIMESTAMPLTZ(int paramInt, TIMESTAMPLTZ paramTIMESTAMPLTZ) throws SQLException {
/* 3709 */     updateOracleObject(paramInt, (Datum)paramTIMESTAMPLTZ);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateARRAY(int paramInt, ARRAY paramARRAY) throws SQLException {
/* 3721 */     updateOracleObject(paramInt, (Datum)paramARRAY);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateSTRUCT(int paramInt, STRUCT paramSTRUCT) throws SQLException {
/* 3733 */     updateOracleObject(paramInt, (Datum)paramSTRUCT);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateOPAQUE(int paramInt, OPAQUE paramOPAQUE) throws SQLException {
/* 3745 */     updateOracleObject(paramInt, (Datum)paramOPAQUE);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateREF(int paramInt, REF paramREF) throws SQLException {
/* 3757 */     updateOracleObject(paramInt, (Datum)paramREF);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateCHAR(int paramInt, CHAR paramCHAR) throws SQLException {
/* 3769 */     updateOracleObject(paramInt, (Datum)paramCHAR);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateRAW(int paramInt, RAW paramRAW) throws SQLException {
/* 3781 */     updateOracleObject(paramInt, (Datum)paramRAW);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateBLOB(int paramInt, BLOB paramBLOB) throws SQLException {
/* 3793 */     updateOracleObject(paramInt, (Datum)paramBLOB);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateCLOB(int paramInt, CLOB paramCLOB) throws SQLException {
/* 3805 */     updateOracleObject(paramInt, (Datum)paramCLOB);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateBFILE(int paramInt, BFILE paramBFILE) throws SQLException {
/* 3817 */     updateOracleObject(paramInt, (Datum)paramBFILE);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateBfile(int paramInt, BFILE paramBFILE) throws SQLException {
/* 3829 */     updateOracleObject(paramInt, (Datum)paramBFILE);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateCustomDatum(int paramInt, CustomDatum paramCustomDatum) throws SQLException {
/* 3842 */     throw new Error("wanna do datum = ((CustomDatum) x).toDatum(m_comm)");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateORAData(int paramInt, ORAData paramORAData) throws SQLException {
/* 3857 */     Datum datum = paramORAData.toDatum((Connection)this.connection);
/*      */     
/* 3859 */     updateOracleObject(paramInt, datum);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateRef(int paramInt, Ref paramRef) throws SQLException {
/* 3871 */     updateREF(paramInt, (REF)paramRef);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateBlob(int paramInt, Blob paramBlob) throws SQLException {
/* 3883 */     updateBLOB(paramInt, (BLOB)paramBlob);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateClob(int paramInt, Clob paramClob) throws SQLException {
/* 3895 */     updateCLOB(paramInt, (CLOB)paramClob);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateArray(int paramInt, Array paramArray) throws SQLException {
/* 3907 */     updateARRAY(paramInt, (ARRAY)paramArray);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 3914 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*      */   public static final String BUILD_DATE = "Thu_Apr_04_15:09:24_PDT_2013";
/*      */   public static final boolean TRACE = false;
/*      */ }


/* Location:              C:\Users\olatu\OneDrive\Documents\Calypso\syncbase\sync_base.jar!\BOOT-INF\lib\ojdbc-7.jar!\oracle\jdbc\driver\GeneratedUpdatableResultSet.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */