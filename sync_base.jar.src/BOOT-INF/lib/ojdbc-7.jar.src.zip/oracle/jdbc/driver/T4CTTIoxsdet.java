/*     */ package oracle.jdbc.driver;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.sql.SQLException;
/*     */ import oracle.jdbc.internal.XSSecureId;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class T4CTTIoxsdet
/*     */   extends T4CTTIfun
/*     */ {
/*     */   private int opcode;
/*     */   private byte[] sessionId;
/*     */   private XSSecureId secureId;
/*     */   
/*     */   T4CTTIoxsdet(T4CConnection paramT4CConnection) {
/*  52 */     super(paramT4CConnection, (byte)3);
/*  53 */     setFunCode((short)181);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void doOXSDET(int paramInt, byte[] paramArrayOfbyte, XSSecureId paramXSSecureId, boolean paramBoolean) throws IOException, SQLException {
/*  67 */     if (paramBoolean) {
/*  68 */       setTTCCode((byte)3);
/*     */     } else {
/*  70 */       setTTCCode((byte)17);
/*  71 */     }  this.opcode = paramInt;
/*  72 */     this.sessionId = paramArrayOfbyte;
/*  73 */     this.secureId = paramXSSecureId;
/*  74 */     if (paramBoolean) {
/*  75 */       doRPC();
/*     */     } else {
/*  77 */       doPigRPC();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   void marshal() throws IOException {
/*  84 */     this.meg.marshalUB4(this.opcode);
/*  85 */     boolean bool = false;
/*  86 */     if (this.sessionId != null && this.sessionId.length > 0) {
/*  87 */       bool = true;
/*  88 */       this.meg.marshalPTR();
/*  89 */       this.meg.marshalUB4(this.sessionId.length);
/*     */     } else {
/*  91 */       this.meg.marshalNULLPTR();
/*  92 */       this.meg.marshalUB4(0L);
/*     */     } 
/*     */     
/*  95 */     if (this.secureId == null) {
/*  96 */       this.meg.marshalNULLPTR();
/*     */     } else {
/*  98 */       this.meg.marshalPTR();
/*     */     } 
/* 100 */     if (bool) {
/* 101 */       this.meg.marshalB1Array(this.sessionId);
/*     */     }
/* 103 */     if (this.secureId != null) {
/* 104 */       ((XSSecureIdI)this.secureId).marshal(this.meg);
/*     */     }
/*     */   }
/*     */   
/* 108 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*     */   public static final String BUILD_DATE = "Thu_Apr_04_15:09:24_PDT_2013";
/*     */   public static final boolean TRACE = false;
/*     */ }


/* Location:              C:\Users\olatu\OneDrive\Documents\Calypso\syncbase\sync_base.jar!\BOOT-INF\lib\ojdbc-7.jar!\oracle\jdbc\driver\T4CTTIoxsdet.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */