/*      */ package oracle.jdbc.driver;
/*      */ import java.io.InputStream;
/*      */ import java.io.OutputStream;
/*      */ import java.io.Reader;
/*      */ import java.nio.ByteBuffer;
/*      */ import java.sql.CallableStatement;
/*      */ import java.sql.Connection;
/*      */ import java.sql.Date;
/*      */ import java.sql.PreparedStatement;
/*      */ import java.sql.ResultSet;
/*      */ import java.sql.SQLException;
/*      */ import java.sql.SQLWarning;
/*      */ import java.sql.Savepoint;
/*      */ import java.sql.Statement;
/*      */ import java.sql.Time;
/*      */ import java.sql.Timestamp;
/*      */ import java.util.Calendar;
/*      */ import java.util.EnumSet;
/*      */ import java.util.Locale;
/*      */ import java.util.Map;
/*      */ import java.util.Properties;
/*      */ import java.util.StringTokenizer;
/*      */ import java.util.TimeZone;
/*      */ import java.util.concurrent.Executor;
/*      */ import oracle.jdbc.LogicalTransactionIdEventListener;
/*      */ import oracle.jdbc.OracleConnection;
/*      */ import oracle.jdbc.OracleOCIFailover;
/*      */ import oracle.jdbc.OracleSavepoint;
/*      */ import oracle.jdbc.aq.AQDequeueOptions;
/*      */ import oracle.jdbc.aq.AQMessage;
/*      */ import oracle.jdbc.aq.AQNotificationRegistration;
/*      */ import oracle.jdbc.dcn.DatabaseChangeRegistration;
/*      */ import oracle.jdbc.internal.JMSDequeueOptions;
/*      */ import oracle.jdbc.internal.JMSEnqueueOptions;
/*      */ import oracle.jdbc.internal.JMSMessage;
/*      */ import oracle.jdbc.internal.JMSNotificationRegistration;
/*      */ import oracle.jdbc.internal.KeywordValueLong;
/*      */ import oracle.jdbc.internal.OracleBfile;
/*      */ import oracle.jdbc.internal.OracleBlob;
/*      */ import oracle.jdbc.internal.OracleClob;
/*      */ import oracle.jdbc.internal.OracleConnection;
/*      */ import oracle.jdbc.internal.OracleStatement;
/*      */ import oracle.jdbc.internal.PDBChangeEventListener;
/*      */ import oracle.jdbc.internal.ReplayContext;
/*      */ import oracle.jdbc.internal.XSEventListener;
/*      */ import oracle.jdbc.internal.XSKeyval;
/*      */ import oracle.jdbc.internal.XSNamespace;
/*      */ import oracle.jdbc.internal.XSPrincipal;
/*      */ import oracle.jdbc.internal.XSSecureId;
/*      */ import oracle.jdbc.oracore.OracleTypeCLOB;
/*      */ import oracle.jdbc.pool.OracleConnectionCacheCallback;
/*      */ import oracle.jdbc.pool.OraclePooledConnection;
/*      */ import oracle.sql.ARRAY;
/*      */ import oracle.sql.BFILE;
/*      */ import oracle.sql.BLOB;
/*      */ import oracle.sql.CLOB;
/*      */ import oracle.sql.DATE;
/*      */ import oracle.sql.Datum;
/*      */ import oracle.sql.LobPlsqlUtil;
/*      */ import oracle.sql.NCLOB;
/*      */ import oracle.sql.NUMBER;
/*      */ import oracle.sql.TIMESTAMP;
/*      */ import oracle.sql.TIMESTAMPLTZ;
/*      */ import oracle.sql.TIMESTAMPTZ;
/*      */ import oracle.sql.TypeDescriptor;
/*      */ import oracle.sql.converter.CharacterSetMetaData;
/*      */ 
/*      */ public class T2CConnection extends PhysicalConnection implements BfileDBAccess, BlobDBAccess, ClobDBAccess {
/*   69 */   static final long JDBC_OCI_LIBRARY_VERSION = Long.parseLong("12.1.0.1.0".replaceAll("\\.", ""));
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*   75 */   short[] queryMetaData1 = null;
/*   76 */   byte[] queryMetaData2 = null;
/*   77 */   int queryMetaData1Offset = 0;
/*   78 */   int queryMetaData2Offset = 0;
/*      */   private String password;
/*   80 */   int fatalErrorNumber = 0;
/*   81 */   String fatalErrorMessage = null;
/*      */   
/*      */   static final int QMD_dbtype = 0;
/*      */   
/*      */   static final int QMD_dbsize = 1;
/*      */   
/*      */   static final int QMD_nullok = 2;
/*      */   
/*      */   static final int QMD_precision = 3;
/*      */   
/*      */   static final int QMD_scale = 4;
/*      */   
/*      */   static final int QMD_formOfUse = 5;
/*      */   
/*      */   static final int QMD_columnNameLength = 6;
/*      */   
/*      */   static final int QMD_tdo0 = 7;
/*      */   
/*      */   static final int QMD_tdo1 = 8;
/*      */   
/*      */   static final int QMD_tdo2 = 9;
/*      */   
/*      */   static final int QMD_tdo3 = 10;
/*      */   
/*      */   static final int QMD_charLength = 11;
/*      */   
/*      */   static final int QMD_typeNameLength = 12;
/*      */   
/*      */   static final int QMD_columnInvisible = 13;
/*      */   static final int T2C_LOCATOR_MAX_LEN = 16;
/*      */   static final int T2C_LINEARIZED_LOCATOR_MAX_LEN = 4000;
/*      */   static final int T2C_LINEARIZED_BFILE_LOCATOR_MAX_LEN = 530;
/*      */   static final int METADATA1_INDICES_PER_COLUMN = 14;
/*      */   protected static final int SIZEOF_QUERYMETADATA2 = 8;
/*      */   static final String defaultDriverNameAttribute = "jdbcoci";
/*  116 */   int queryMetaData1Size = 100;
/*  117 */   int queryMetaData2Size = 800;
/*      */   
/*      */   long m_nativeState;
/*      */   
/*      */   short m_clientCharacterSet;
/*      */   
/*      */   byte byteAlign;
/*      */   
/*  125 */   static final byte[] EMPTY_BYTES = new byte[0];
/*      */   
/*      */   private static final int EOJ_SUCCESS = 0;
/*      */   
/*      */   private static final int EOJ_ERROR = -1;
/*      */   
/*      */   private static final int EOJ_WARNING = 1;
/*      */   
/*      */   private static final int EOJ_GET_STORAGE_ERROR = -4;
/*      */   private static final int EOJ_ORA3113_SERVER_NORMAL = -6;
/*      */   private static final String OCILIBRARY = "ocijdbc12";
/*  136 */   private int logon_mode = 0;
/*      */   
/*      */   static final int LOGON_MODE_DEFAULT = 0;
/*      */   
/*      */   static final int LOGON_MODE_SYSDBA = 2;
/*      */   
/*      */   static final int LOGON_MODE_SYSOPER = 4;
/*      */   
/*      */   static final int LOGON_MODE_SYSASM = 32768;
/*      */   
/*      */   static final int LOGON_MODE_SYSBKP = 131072;
/*      */   
/*      */   static final int LOGON_MODE_SYSDGD = 262144;
/*      */   
/*      */   static final int LOGON_MODE_SYSKMT = 524288;
/*      */   
/*      */   static final int LOGON_MODE_CONNECTION_POOL = 5;
/*      */   
/*      */   static final int LOGON_MODE_CONNPOOL_CONNECTION = 6;
/*      */   
/*      */   static final int LOGON_MODE_CONNPOOL_PROXY_CONNECTION = 7;
/*      */   
/*      */   static final int LOGON_MODE_CONNPOOL_ALIASED_CONNECTION = 8;
/*      */   
/*      */   static final int T2C_PROXYTYPE_NONE = 0;
/*      */   
/*      */   static final int T2C_PROXYTYPE_USER_NAME = 1;
/*      */   static final int T2C_PROXYTYPE_DISTINGUISHED_NAME = 2;
/*      */   static final int T2C_PROXYTYPE_CERTIFICATE = 3;
/*      */   static final int T2C_CONNECTION_FLAG_DEFAULT_LOB_PREFETCH = 0;
/*      */   static final int T2C_CONNECTION_FLAG_PRELIM_AUTH = 1;
/*      */   static final int T2C_CONNECTION_FLAG_CHARSET = 2;
/*      */   static final int T2C_CONNECTION_FLAG_NCHARSET = 3;
/*      */   static final int T2C_CONNECTION_FLAG_BYTE_ALIGN = 4;
/*      */   static final int T2C_CONNECTION_FLAG_SERVER_TZ_VERSION = 5;
/*      */   static final int T2C_CONNECTION_FLAG_TAF_ENABLED = 6;
/*      */   static final int T2C_CONNECTION_TAG_MATCHED = 7;
/*      */   static final int T2C_CONNECTION_FLAG_MAXLEN_COMPAT = 8;
/*      */   static final int T2C_MAX_SCHEMA_NAME_LENGTH = 258;
/*      */   private static boolean isLibraryLoaded;
/*  176 */   static final Map<String, String> cachedVersionTable = new Hashtable<>();
/*      */   
/*      */   static final int T2C_LOGON_OUT_BUFFER_LENGTH = 256;
/*      */   
/*      */   static final int EOO_LOGIN_OUT_TYPE_DBID = 1;
/*      */   
/*      */   static final int EOO_LOGIN_OUT_INST_START_TIME = 2;
/*      */   
/*      */   String databaseUniqueIdentifier;
/*  185 */   OracleOCIFailover appCallback = null;
/*  186 */   Object appCallbackObject = null;
/*      */   
/*      */   private Properties nativeInfo;
/*      */   ByteBuffer nioBufferForLob;
/*      */   boolean[] tagMatched;
/*      */   static final int OCI_SESSRLS_DROPSESS = 1;
/*      */   static final int OCI_SESSRLS_RETAG = 2;
/*      */   
/*      */   protected T2CConnection(String paramString, Properties paramProperties, OracleDriverExtension paramOracleDriverExtension) throws SQLException {
/*  195 */     super(paramString, paramProperties, paramOracleDriverExtension);
/*      */ 
/*      */     
/*  198 */     initialize();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final void initializePassword(String paramString) throws SQLException {
/*  206 */     this.password = paramString;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void initialize() {
/*  213 */     allocQueryMetaDataBuffers();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void allocQueryMetaDataBuffers() {
/*  245 */     this.queryMetaData1Offset = 0;
/*  246 */     this.queryMetaData1 = new short[this.queryMetaData1Size * 14];
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  251 */     this.queryMetaData2Offset = 0;
/*  252 */     this.queryMetaData2 = new byte[this.queryMetaData2Size];
/*      */     
/*  254 */     this.namedTypeAccessorByteLen = 0;
/*  255 */     this.refTypeAccessorByteLen = 0;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void reallocateQueryMetaData(int paramInt1, int paramInt2) {
/*  262 */     this.queryMetaData1 = null;
/*  263 */     this.queryMetaData2 = null;
/*      */     
/*  265 */     this.queryMetaData1Size = Math.max(paramInt1, this.queryMetaData1Size);
/*  266 */     this.queryMetaData2Size = Math.max(paramInt2, this.queryMetaData2Size);
/*      */     
/*  268 */     allocQueryMetaDataBuffers();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void logon() throws SQLException {
/*  292 */     this.tagMatched = new boolean[] { false };
/*  293 */     if (this.database == null) {
/*      */       
/*  295 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 64);
/*  296 */       sQLException.fillInStackTrace();
/*  297 */       throw sQLException;
/*      */     } 
/*      */     
/*  300 */     if (!isLibraryLoaded) {
/*  301 */       loadNativeLibrary(this.ocidll);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  311 */     byte[] arrayOfByte = new byte[256];
/*  312 */     if (this.ociConnectionPoolIsPooling) {
/*      */       
/*  314 */       processOCIConnectionPooling();
/*      */     }
/*      */     else {
/*      */       
/*  318 */       long l1 = this.ociSvcCtxHandle;
/*  319 */       long l2 = this.ociEnvHandle;
/*  320 */       long l3 = this.ociErrHandle;
/*      */ 
/*      */       
/*  323 */       if (l1 != 0L && l2 != 0L) {
/*      */ 
/*      */         
/*  326 */         if (this.ociDriverCharset != null) {
/*  327 */           this.m_clientCharacterSet = (new Integer(this.ociDriverCharset)).shortValue();
/*      */         
/*      */         }
/*      */         else {
/*      */           
/*  332 */           SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 89);
/*  333 */           sQLException.fillInStackTrace();
/*  334 */           throw sQLException;
/*      */         } 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  340 */         this.conversion = new DBConversion(this.m_clientCharacterSet, this.m_clientCharacterSet, this.m_clientCharacterSet);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  346 */         long[] arrayOfLong1 = { this.defaultLobPrefetchSize, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, (this.enableOCIFAN ? 1L : 0L) };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  359 */         this.sqlWarning = checkError(t2cUseConnection(this.m_nativeState, l2, l1, l3, arrayOfByte, arrayOfLong1), this.sqlWarning);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  366 */         this.conversion = new DBConversion((short)(int)(arrayOfLong1[2] & 0xFFFFL), this.m_clientCharacterSet, (short)(int)(arrayOfLong1[3] & 0xFFFFL));
/*      */ 
/*      */ 
/*      */         
/*  370 */         this.byteAlign = (byte)(int)(arrayOfLong1[4] & 0xFFL);
/*  371 */         this.timeZoneVersionNumber = (int)arrayOfLong1[5];
/*      */ 
/*      */         
/*  374 */         if (arrayOfLong1[6] != 0L) {
/*  375 */           this.useOCIDefaultDefines = true;
/*      */         }
/*  377 */         this.tagMatched[0] = (arrayOfLong1[7] != 0L);
/*      */         
/*  379 */         this.varTypeMaxLenCompat = (int)arrayOfLong1[8];
/*      */ 
/*      */         
/*      */         return;
/*      */       } 
/*      */ 
/*      */       
/*  386 */       if (this.internalLogon == null) {
/*  387 */         this.logon_mode = 0;
/*  388 */       } else if (this.internalLogon.equalsIgnoreCase("SYSDBA")) {
/*  389 */         this.logon_mode = 2;
/*  390 */       } else if (this.internalLogon.equalsIgnoreCase("SYSOPER")) {
/*  391 */         this.logon_mode = 4;
/*  392 */       } else if (this.internalLogon.equalsIgnoreCase("SYSASM")) {
/*  393 */         this.logon_mode = 32768;
/*  394 */       } else if (this.internalLogon.equalsIgnoreCase("SYSBACKUP")) {
/*  395 */         this.logon_mode = 131072;
/*  396 */       } else if (this.internalLogon.equalsIgnoreCase("SYSDG")) {
/*  397 */         this.logon_mode = 262144;
/*  398 */       } else if (this.internalLogon.equalsIgnoreCase("SYSKM")) {
/*  399 */         this.logon_mode = 524288;
/*      */       } 
/*  401 */       byte[] arrayOfByte1 = null;
/*  402 */       byte[] arrayOfByte2 = null;
/*  403 */       byte[] arrayOfByte3 = null;
/*  404 */       byte[] arrayOfByte4 = EMPTY_BYTES;
/*  405 */       byte[] arrayOfByte5 = EMPTY_BYTES;
/*  406 */       String str1 = this.setNewPassword;
/*  407 */       byte[] arrayOfByte6 = EMPTY_BYTES;
/*  408 */       byte[] arrayOfByte7 = EMPTY_BYTES;
/*  409 */       byte[] arrayOfByte8 = EMPTY_BYTES;
/*      */       
/*  411 */       if (this.nlsLangBackdoor) {
/*      */ 
/*      */         
/*  414 */         this.m_clientCharacterSet = getDriverCharSetIdFromNLS_LANG(this.ocidll);
/*      */       
/*      */       }
/*      */       else {
/*      */         
/*  419 */         this.m_clientCharacterSet = getClientCharSetId();
/*      */       } 
/*      */       
/*  422 */       if (str1 != null) {
/*  423 */         arrayOfByte6 = DBConversion.stringToDriverCharBytes(str1, this.m_clientCharacterSet);
/*      */       }
/*  425 */       if (this.editionName != null) {
/*  426 */         arrayOfByte7 = DBConversion.stringToDriverCharBytes(this.editionName, this.m_clientCharacterSet);
/*      */       }
/*  428 */       if (this.driverNameAttribute == null) {
/*  429 */         arrayOfByte8 = DBConversion.stringToDriverCharBytes("jdbcoci", this.m_clientCharacterSet);
/*      */       } else {
/*  431 */         arrayOfByte8 = DBConversion.stringToDriverCharBytes(this.driverNameAttribute, this.m_clientCharacterSet);
/*      */       } 
/*  433 */       arrayOfByte1 = (this.userName == null) ? EMPTY_BYTES : DBConversion.stringToDriverCharBytes(this.userName, this.m_clientCharacterSet);
/*      */ 
/*      */       
/*  436 */       arrayOfByte2 = (this.proxyClientName == null) ? EMPTY_BYTES : DBConversion.stringToDriverCharBytes(this.proxyClientName, this.m_clientCharacterSet);
/*      */ 
/*      */       
/*  439 */       arrayOfByte3 = (this.password == null) ? EMPTY_BYTES : DBConversion.stringToDriverCharBytes(this.password, this.m_clientCharacterSet);
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  444 */       if (this.drcpEnabled) {
/*  445 */         arrayOfByte4 = DBConversion.stringToDriverCharBytes(this.drcpConnectionClass, this.m_clientCharacterSet);
/*      */       }
/*      */       
/*  448 */       if (this.drcpTagName != null) {
/*  449 */         arrayOfByte5 = DBConversion.stringToDriverCharBytes(this.drcpTagName, this.m_clientCharacterSet);
/*      */       }
/*  451 */       byte[] arrayOfByte9 = DBConversion.stringToDriverCharBytes(this.database, this.m_clientCharacterSet);
/*      */       
/*  453 */       String str2 = null;
/*  454 */       byte[] arrayOfByte10 = ((str2 = CharacterSetMetaData.getNLSLanguage(Locale.getDefault(Locale.Category.FORMAT))) != null) ? str2.getBytes() : null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  462 */       byte[] arrayOfByte11 = ((str2 = CharacterSetMetaData.getNLSTerritory(Locale.getDefault(Locale.Category.FORMAT))) != null) ? str2.getBytes() : null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  471 */       if (arrayOfByte10 == null || arrayOfByte11 == null) {
/*      */         
/*  473 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 176);
/*  474 */         sQLException.fillInStackTrace();
/*  475 */         throw sQLException;
/*      */       } 
/*      */       
/*  478 */       TimeZone timeZone = TimeZone.getDefault();
/*  479 */       String str3 = timeZone.getID();
/*      */       
/*  481 */       if (!ZONEIDMAP.isValidRegion(str3) || !this.timezoneAsRegion) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  490 */         int j = timeZone.getOffset(System.currentTimeMillis());
/*  491 */         int k = j / 3600000;
/*  492 */         int m = j / 60000 % 60;
/*      */         
/*  494 */         str3 = ((k < 0) ? ("" + k) : ("+" + k)) + ((m < 10) ? (":0" + m) : (":" + m));
/*      */       } 
/*      */ 
/*      */       
/*  498 */       doSetSessionTimeZone(str3);
/*      */ 
/*      */       
/*  501 */       this.sessionTimeZone = str3;
/*      */ 
/*      */       
/*  504 */       this.conversion = new DBConversion(this.m_clientCharacterSet, this.m_clientCharacterSet, this.m_clientCharacterSet);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  510 */       long[] arrayOfLong = { this.defaultLobPrefetchSize, (this.prelimAuth ? 1L : 0L), 0L, 0L, 0L, 0L, 0L, 0L, 0L, (this.enableOCIFAN ? 1L : 0L) };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  523 */       if (this.m_nativeState == 0L) {
/*      */         
/*  525 */         this.sqlWarning = checkError(t2cCreateState(arrayOfByte1, arrayOfByte1.length, arrayOfByte2, arrayOfByte2.length, arrayOfByte3, arrayOfByte3.length, arrayOfByte6, arrayOfByte6.length, arrayOfByte7, arrayOfByte7.length, arrayOfByte8, arrayOfByte8.length, arrayOfByte9, arrayOfByte9.length, arrayOfByte4, arrayOfByte4.length, arrayOfByte5, arrayOfByte5.length, this.m_clientCharacterSet, this.logon_mode, arrayOfByte10, arrayOfByte11, arrayOfByte, arrayOfLong), this.sqlWarning);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       }
/*      */       else {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  545 */         this.sqlWarning = checkError(t2cLogon(this.m_nativeState, arrayOfByte1, arrayOfByte1.length, arrayOfByte2, arrayOfByte2.length, arrayOfByte3, arrayOfByte3.length, arrayOfByte6, arrayOfByte6.length, arrayOfByte7, arrayOfByte7.length, arrayOfByte8, arrayOfByte8.length, arrayOfByte9, arrayOfByte9.length, arrayOfByte4, arrayOfByte4.length, arrayOfByte5, arrayOfByte5.length, this.logon_mode, arrayOfByte10, arrayOfByte11, arrayOfByte, arrayOfLong), this.sqlWarning);
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  563 */       this.conversion = new DBConversion((short)(int)(arrayOfLong[2] & 0xFFFFL), this.m_clientCharacterSet, (short)(int)(arrayOfLong[3] & 0xFFFFL));
/*      */ 
/*      */ 
/*      */       
/*  567 */       this.byteAlign = (byte)(int)(arrayOfLong[4] & 0xFFL);
/*  568 */       this.timeZoneVersionNumber = (int)arrayOfLong[5];
/*      */ 
/*      */       
/*  571 */       if (arrayOfLong[6] != 0L) {
/*  572 */         this.useOCIDefaultDefines = true;
/*      */       }
/*  574 */       this.tagMatched[0] = (arrayOfLong[7] != 0L);
/*      */       
/*  576 */       this.varTypeMaxLenCompat = (int)arrayOfLong[8];
/*      */       
/*  578 */       int i = 0;
/*  579 */       String str4 = null;
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       while (true) {
/*  585 */         int j = readShort(arrayOfByte, i);
/*      */         
/*  587 */         if (j == 0)
/*  588 */           break;  i += true;
/*      */         
/*  590 */         int k = readShort(arrayOfByte, i);
/*  591 */         i += true;
/*      */         
/*  593 */         switch (j) {
/*      */           case 1:
/*  595 */             this.databaseUniqueIdentifier = new String(arrayOfByte, i, k);
/*      */ 
/*      */             
/*  598 */             i += k;
/*      */           
/*      */           case 2:
/*  601 */             str4 = new String(arrayOfByte, i, k);
/*      */ 
/*      */             
/*  604 */             i += k;
/*      */         } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       } 
/*  612 */       if (this.databaseUniqueIdentifier != null) {
/*      */         
/*  614 */         String str = cachedVersionTable.get(this.databaseUniqueIdentifier + str4);
/*  615 */         if (str == null) {
/*  616 */           cachedVersionTable.put(this.databaseUniqueIdentifier + str4, String.valueOf(getVersionNumber()));
/*      */           
/*  618 */           if (this.drcpEnabled) detachServerConnection((String)null);
/*      */         
/*      */         } else {
/*  621 */           this.versionNumber = Short.parseShort(str);
/*  622 */           t2cSetCachedServerVersion(this.m_nativeState, this.versionNumber);
/*      */         } 
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   int readShort(byte[] paramArrayOfbyte, int paramInt) {
/*  632 */     return (paramArrayOfbyte[paramInt] & 0xFF) << 8 | paramArrayOfbyte[paramInt + 1] & 0xFF;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void logoff() throws SQLException {
/*      */     try {
/*  651 */       if (this.lifecycle == 8 || this.lifecycle == 2)
/*      */       {
/*  653 */         checkError(t2cLogoff(this.m_nativeState));
/*      */       }
/*  655 */     } catch (NullPointerException nullPointerException) {}
/*      */ 
/*      */     
/*  658 */     this.m_nativeState = 0L;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void open(OracleStatement paramOracleStatement) throws SQLException {
/*  676 */     byte[] arrayOfByte = paramOracleStatement.sqlObject.getSql(paramOracleStatement.processEscapes, paramOracleStatement.convertNcharLiterals).getBytes();
/*      */ 
/*      */     
/*  679 */     checkError(t2cCreateStatement(this.m_nativeState, 0L, arrayOfByte, arrayOfByte.length, paramOracleStatement, false, paramOracleStatement.rowPrefetch));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   OracleStatement createImplicitResultSetStatement(OracleStatement paramOracleStatement) throws SQLException {
/*  696 */     T2CStatement t2CStatement = new T2CStatement(this, 1, this.defaultRowPrefetch, -1, -1);
/*  697 */     checkError(t2cGetImplicitResultSetStatement(this.m_nativeState, paramOracleStatement.c_state, t2CStatement));
/*      */     
/*  699 */     t2CStatement.needToParse = false;
/*  700 */     t2CStatement.isOpen = true;
/*  701 */     t2CStatement.processEscapes = false;
/*      */     
/*  703 */     t2CStatement.sqlKind = OracleStatement.SqlKind.SELECT;
/*      */     
/*  705 */     t2CStatement.prepareForNewResults(true, false, true);
/*      */ 
/*      */ 
/*      */     
/*  709 */     paramOracleStatement.addImplicitResultSetStmt(t2CStatement);
/*  710 */     return t2CStatement;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void cancelOperationOnServer(boolean paramBoolean) throws SQLException {
/*  724 */     checkError(t2cCancel(this.m_nativeState));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void doAbort() throws SQLException {
/*  733 */     checkError(t2cAbort(this.m_nativeState));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void doSetAutoCommit(boolean paramBoolean) throws SQLException {
/*  749 */     if (this.autoCommitSpecCompliant && !getAutoCommit() && paramBoolean) {
/*  750 */       commit();
/*      */     }
/*      */     
/*  753 */     checkError(t2cSetAutoCommit(this.m_nativeState, paramBoolean));
/*  754 */     this.autocommit = paramBoolean;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void doCommit(int paramInt) throws SQLException {
/*  770 */     checkError(t2cCommit(this.m_nativeState, paramInt));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void doRollback() throws SQLException {
/*  786 */     checkError(t2cRollback(this.m_nativeState));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   synchronized int doPingDatabase() throws SQLException {
/*  793 */     if (t2cPingDatabase(this.m_nativeState) == 0) {
/*  794 */       return 0;
/*      */     }
/*  796 */     return -1;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected String doGetDatabaseProductVersion() throws SQLException {
/*  803 */     byte[] arrayOfByte = t2cGetProductionVersion(this.m_nativeState);
/*      */     
/*  805 */     return this.conversion.CharBytesToString(arrayOfByte, arrayOfByte.length);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected short doGetVersionNumber() throws SQLException {
/*  812 */     short s = 0;
/*      */ 
/*      */     
/*      */     try {
/*  816 */       String str1 = doGetDatabaseProductVersion();
/*      */       
/*  818 */       StringTokenizer stringTokenizer = new StringTokenizer(str1.trim(), " .", false);
/*  819 */       String str2 = null;
/*  820 */       byte b = 0;
/*  821 */       short s1 = 0;
/*      */       
/*  823 */       while (stringTokenizer.hasMoreTokens())
/*      */       {
/*  825 */         str2 = stringTokenizer.nextToken();
/*      */ 
/*      */         
/*      */         try {
/*  829 */           s1 = Integer.decode(str2).shortValue();
/*  830 */           s = (short)(s * 10 + s1);
/*  831 */           b++;
/*      */ 
/*      */           
/*  834 */           if (b == 4) {
/*      */             break;
/*      */           }
/*  837 */         } catch (NumberFormatException numberFormatException) {}
/*      */       
/*      */       }
/*      */ 
/*      */     
/*      */     }
/*  843 */     catch (NoSuchElementException noSuchElementException) {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  849 */     if (s == -1) {
/*  850 */       s = 0;
/*      */     }
/*      */     
/*  853 */     return s;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ClobDBAccess createClobDBAccess() {
/*  860 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public BlobDBAccess createBlobDBAccess() {
/*  867 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public BfileDBAccess createBfileDBAccess() {
/*  874 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected SQLWarning checkError(int paramInt) throws SQLException {
/*  881 */     return checkError(paramInt, (SQLWarning)null);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected SQLWarning checkError(int paramInt, SQLWarning paramSQLWarning) throws SQLException {
/*      */     T2CError t2CError;
/*      */     SQLException sQLException;
/*      */     int i;
/*      */     String str;
/*  891 */     switch (paramInt) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case -1:
/*      */       case 1:
/*  899 */         t2CError = new T2CError();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  905 */         i = -1;
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  910 */         if (this.lifecycle == 1 || this.lifecycle == 16) {
/*      */           
/*  912 */           i = t2cDescribeError(this.m_nativeState, t2CError, t2CError.m_errorMessage);
/*      */         } else {
/*      */           
/*  915 */           if (this.fatalErrorNumber != 0) {
/*      */ 
/*      */             
/*  918 */             SQLException sQLException2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 269);
/*  919 */             sQLException2.fillInStackTrace();
/*  920 */             throw sQLException2;
/*      */           } 
/*      */ 
/*      */ 
/*      */           
/*  925 */           SQLException sQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 8);
/*  926 */           sQLException1.fillInStackTrace();
/*  927 */           throw sQLException1;
/*      */         } 
/*      */         
/*  930 */         str = null;
/*  931 */         if (i != -1) {
/*      */ 
/*      */ 
/*      */           
/*  935 */           byte b = 0;
/*      */           
/*  937 */           while (b < t2CError.m_errorMessage.length && t2CError.m_errorMessage[b] != 0) {
/*  938 */             b++;
/*      */           }
/*  940 */           if (this.conversion == null) throw new Error("conversion == null"); 
/*  941 */           if (t2CError == null) throw new Error("l_error == null"); 
/*  942 */           str = this.conversion.CharBytesToString(t2CError.m_errorMessage, b, true);
/*      */         } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  949 */         switch (t2CError.m_errorNumber) {
/*      */           
/*      */           case 28:
/*      */           case 600:
/*      */           case 1012:
/*      */           case 1041:
/*  955 */             internalClose();
/*      */             break;
/*      */ 
/*      */           
/*      */           case 902:
/*  960 */             removeAllDescriptor();
/*      */             break;
/*      */           
/*      */           case 3113:
/*      */           case 3114:
/*  965 */             setUsable(false);
/*  966 */             close();
/*      */             break;
/*      */           case -6:
/*  969 */             t2CError.m_errorNumber = 3113;
/*      */             break;
/*      */         } 
/*      */ 
/*      */         
/*  974 */         if (i == -1) {
/*      */           
/*  976 */           SQLException sQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 1, "Fetch error message failed!");
/*  977 */           sQLException1.fillInStackTrace();
/*  978 */           throw sQLException1;
/*      */         } 
/*      */         
/*  981 */         if (paramInt == -1) {
/*      */ 
/*      */           
/*  984 */           SQLException sQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), str, t2CError.m_errorNumber);
/*  985 */           sQLException1.fillInStackTrace();
/*  986 */           throw sQLException1;
/*      */         } 
/*      */ 
/*      */ 
/*      */         
/*  991 */         paramSQLWarning = DatabaseError.addSqlWarning(paramSQLWarning, str, t2CError.m_errorNumber);
/*      */         break;
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case -4:
/*  998 */         sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 254);
/*  999 */         sQLException.fillInStackTrace();
/* 1000 */         throw sQLException;
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1007 */     return paramSQLWarning;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   OracleStatement RefCursorBytesToStatement(byte[] paramArrayOfbyte, OracleStatement paramOracleStatement) throws SQLException {
/* 1015 */     T2CStatement t2CStatement = new T2CStatement(this, 1, this.defaultRowPrefetch, -1, -1);
/*      */     
/* 1017 */     t2CStatement.needToParse = false;
/* 1018 */     t2CStatement.serverCursor = true;
/* 1019 */     t2CStatement.isOpen = true;
/* 1020 */     t2CStatement.processEscapes = false;
/*      */     
/* 1022 */     t2CStatement.prepareForNewResults(true, false, true);
/*      */ 
/*      */     
/* 1025 */     if (this.useOCIDefaultDefines) {
/*      */       
/* 1027 */       t2CStatement.savedRowPrefetch = this.defaultRowPrefetch;
/* 1028 */       t2CStatement.rowPrefetch = 1;
/*      */     } 
/* 1030 */     t2CStatement.sqlObject.initialize("select unknown as ref cursor from whatever");
/*      */     
/* 1032 */     t2CStatement.sqlKind = OracleStatement.SqlKind.SELECT;
/*      */     
/* 1034 */     checkError(t2cCreateStatement(this.m_nativeState, paramOracleStatement.c_state, paramArrayOfbyte, paramArrayOfbyte.length, t2CStatement, true, this.defaultRowPrefetch));
/*      */ 
/*      */ 
/*      */     
/* 1038 */     paramOracleStatement.addChild(t2CStatement);
/* 1039 */     return t2CStatement;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void getForm(OracleTypeADT paramOracleTypeADT, OracleTypeCLOB paramOracleTypeCLOB, int paramInt) throws SQLException {
/* 1048 */     boolean bool = false;
/*      */     
/* 1050 */     if (paramOracleTypeCLOB != null) {
/*      */       
/* 1052 */       String[] arrayOfString1 = new String[1];
/* 1053 */       String[] arrayOfString2 = new String[1];
/*      */       
/* 1055 */       SQLName.parse(paramOracleTypeADT.getFullName(), arrayOfString1, arrayOfString2, true);
/*      */       
/* 1057 */       String str = "\"" + arrayOfString1[0] + "\".\"" + arrayOfString2[0] + "\"";
/*      */ 
/*      */       
/* 1060 */       byte[] arrayOfByte = this.conversion.StringToCharBytes(str);
/*      */       
/* 1062 */       int i = t2cGetFormOfUse(this.m_nativeState, paramOracleTypeCLOB, arrayOfByte, arrayOfByte.length, paramInt);
/*      */ 
/*      */ 
/*      */       
/* 1066 */       if (i < 0) {
/* 1067 */         checkError(i);
/*      */       }
/*      */       
/* 1070 */       paramOracleTypeCLOB.setForm(i);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public long getTdoCState(String paramString1, String paramString2) throws SQLException {
/* 1085 */     String str = "\"" + paramString1 + "\".\"" + paramString2 + "\"";
/* 1086 */     byte[] arrayOfByte = this.conversion.StringToCharBytes(str);
/* 1087 */     int[] arrayOfInt = new int[1];
/* 1088 */     long l = t2cGetTDO(this.m_nativeState, arrayOfByte, arrayOfByte.length, arrayOfInt);
/* 1089 */     if (l == 0L)
/*      */     {
/* 1091 */       checkError(arrayOfInt[0]);
/*      */     }
/* 1093 */     return l;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public long getTdoCState(String paramString) throws SQLException {
/* 1101 */     byte[] arrayOfByte = this.conversion.StringToCharBytes(paramString);
/* 1102 */     int[] arrayOfInt = new int[1];
/* 1103 */     long l = t2cGetTDO(this.m_nativeState, arrayOfByte, arrayOfByte.length, arrayOfInt);
/* 1104 */     if (l == 0L)
/*      */     {
/* 1106 */       checkError(arrayOfInt[0]);
/*      */     }
/* 1108 */     return l;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Properties getDBAccessProperties() throws SQLException {
/* 1124 */     return getOCIHandles();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized Properties getOCIHandles() throws SQLException {
/* 1136 */     if (this.lifecycle != 1) {
/*      */       
/* 1138 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 8);
/* 1139 */       sQLException.fillInStackTrace();
/* 1140 */       throw sQLException;
/*      */     } 
/*      */     
/* 1143 */     if (this.nativeInfo == null) {
/*      */       
/* 1145 */       long[] arrayOfLong = new long[3];
/*      */ 
/*      */       
/* 1148 */       checkError(t2cGetHandles(this.m_nativeState, arrayOfLong));
/*      */ 
/*      */       
/* 1151 */       this.nativeInfo = new Properties();
/*      */       
/* 1153 */       this.nativeInfo.put("OCIEnvHandle", String.valueOf(arrayOfLong[0]));
/* 1154 */       this.nativeInfo.put("OCISvcCtxHandle", String.valueOf(arrayOfLong[1]));
/* 1155 */       this.nativeInfo.put("OCIErrHandle", String.valueOf(arrayOfLong[2]));
/* 1156 */       this.nativeInfo.put("ClientCharSet", String.valueOf(this.m_clientCharacterSet));
/*      */     } 
/*      */     
/* 1159 */     return this.nativeInfo;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Properties getServerSessionInfo() throws SQLException {
/* 1166 */     if (this.lifecycle != 1) {
/*      */       
/* 1168 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 8);
/* 1169 */       sQLException.fillInStackTrace();
/* 1170 */       throw sQLException;
/*      */     } 
/*      */     
/* 1173 */     if (this.sessionProperties == null) {
/* 1174 */       this.sessionProperties = new Properties();
/*      */     }
/*      */ 
/*      */     
/* 1178 */     if (getVersionNumber() < 10200) {
/* 1179 */       queryFCFProperties(this.sessionProperties);
/*      */     } else {
/* 1181 */       checkError(t2cGetServerSessionInfo(this.m_nativeState, this.sessionProperties));
/*      */     } 
/* 1183 */     return this.sessionProperties;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public byte getInstanceProperty(OracleConnection.InstanceProperty paramInstanceProperty) throws SQLException {
/* 1189 */     byte b = 0;
/* 1190 */     if (paramInstanceProperty == OracleConnection.InstanceProperty.ASM_VOLUME_SUPPORTED) {
/*      */       
/* 1192 */       b = t2cGetAsmVolProperty(this.m_nativeState);
/*      */     }
/* 1194 */     else if (paramInstanceProperty == OracleConnection.InstanceProperty.INSTANCE_TYPE) {
/*      */       
/* 1196 */       b = t2cGetInstanceType(this.m_nativeState);
/*      */     } 
/* 1198 */     return b;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Properties getConnectionPoolInfo() throws SQLException {
/* 1213 */     if (this.lifecycle != 1) {
/*      */       
/* 1215 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 8);
/* 1216 */       sQLException.fillInStackTrace();
/* 1217 */       throw sQLException;
/*      */     } 
/* 1219 */     Properties properties = new Properties();
/*      */     
/* 1221 */     checkError(t2cGetConnPoolInfo(this.m_nativeState, properties));
/*      */     
/* 1223 */     return properties;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setConnectionPoolInfo(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6) throws SQLException {
/* 1238 */     checkError(t2cSetConnPoolInfo(this.m_nativeState, paramInt1, paramInt2, paramInt3, paramInt4, paramInt5, paramInt6));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void ociPasswordChange(String paramString1, String paramString2, String paramString3) throws SQLException {
/* 1253 */     if (this.lifecycle != 1) {
/*      */       
/* 1255 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 8);
/* 1256 */       sQLException.fillInStackTrace();
/* 1257 */       throw sQLException;
/*      */     } 
/* 1259 */     byte[] arrayOfByte1 = (paramString1 == null) ? new byte[0] : DBConversion.stringToDriverCharBytes(paramString1, this.m_clientCharacterSet);
/*      */ 
/*      */ 
/*      */     
/* 1263 */     byte[] arrayOfByte2 = (paramString2 == null) ? new byte[0] : DBConversion.stringToDriverCharBytes(paramString2, this.m_clientCharacterSet);
/*      */ 
/*      */     
/* 1266 */     byte[] arrayOfByte3 = (paramString3 == null) ? new byte[0] : DBConversion.stringToDriverCharBytes(paramString3, this.m_clientCharacterSet);
/*      */ 
/*      */     
/* 1269 */     this.sqlWarning = checkError(t2cPasswordChange(this.m_nativeState, arrayOfByte1, arrayOfByte1.length, arrayOfByte2, arrayOfByte2.length, arrayOfByte3, arrayOfByte3.length), this.sqlWarning);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void processOCIConnectionPooling() throws SQLException {
/* 1280 */     if (this.lifecycle != 1) {
/*      */       
/* 1282 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 8);
/* 1283 */       sQLException.fillInStackTrace();
/* 1284 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/* 1288 */     T2CConnection t2CConnection = null;
/*      */     
/* 1290 */     if (this.ociConnectionPoolLogonMode == "connection_pool") {
/*      */       
/* 1292 */       if (this.nlsLangBackdoor) {
/*      */ 
/*      */         
/* 1295 */         this.m_clientCharacterSet = getDriverCharSetIdFromNLS_LANG(this.ocidll);
/*      */       
/*      */       }
/*      */       else {
/*      */         
/* 1300 */         this.m_clientCharacterSet = getClientCharSetId();
/*      */       } 
/*      */     } else {
/*      */       
/* 1304 */       t2CConnection = (T2CConnection)this.ociConnectionPoolObject;
/* 1305 */       this.m_clientCharacterSet = t2CConnection.m_clientCharacterSet;
/*      */     } 
/*      */     
/* 1308 */     byte[] arrayOfByte1 = null;
/*      */     
/* 1310 */     byte[] arrayOfByte2 = (this.password == null) ? new byte[0] : DBConversion.stringToDriverCharBytes(this.password, this.m_clientCharacterSet);
/*      */ 
/*      */     
/* 1313 */     byte[] arrayOfByte3 = (this.editionName == null) ? new byte[0] : DBConversion.stringToDriverCharBytes(this.editionName, this.m_clientCharacterSet);
/*      */ 
/*      */     
/* 1316 */     byte[] arrayOfByte4 = DBConversion.stringToDriverCharBytes((this.driverNameAttribute == null) ? "jdbcoci" : this.driverNameAttribute, this.m_clientCharacterSet);
/*      */ 
/*      */ 
/*      */     
/* 1320 */     byte[] arrayOfByte5 = DBConversion.stringToDriverCharBytes(this.database, this.m_clientCharacterSet);
/*      */     
/* 1322 */     byte[] arrayOfByte6 = CharacterSetMetaData.getNLSLanguage(Locale.getDefault(Locale.Category.FORMAT)).getBytes();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1330 */     byte[] arrayOfByte7 = CharacterSetMetaData.getNLSTerritory(Locale.getDefault(Locale.Category.FORMAT)).getBytes();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1340 */     if (arrayOfByte6 == null || arrayOfByte7 == null) {
/*      */       
/* 1342 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 176);
/* 1343 */       sQLException.fillInStackTrace();
/* 1344 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1350 */     long[] arrayOfLong = { this.defaultLobPrefetchSize, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1363 */     if (this.ociConnectionPoolLogonMode == "connection_pool") {
/*      */       
/* 1365 */       arrayOfByte1 = (this.userName == null) ? new byte[0] : DBConversion.stringToDriverCharBytes(this.userName, this.m_clientCharacterSet);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1371 */       this.conversion = new DBConversion(this.m_clientCharacterSet, this.m_clientCharacterSet, this.m_clientCharacterSet);
/*      */ 
/*      */       
/* 1374 */       this.logon_mode = 5;
/*      */       
/* 1376 */       if (this.lifecycle == 1)
/*      */       {
/* 1378 */         int[] arrayOfInt = new int[6];
/*      */         
/* 1380 */         OracleOCIConnectionPool.readPoolConfig(this.ociConnectionPoolMinLimit, this.ociConnectionPoolMaxLimit, this.ociConnectionPoolIncrement, this.ociConnectionPoolTimeout, this.ociConnectionPoolNoWait, this.ociConnectionPoolTransactionDistributed, arrayOfInt);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1388 */         this.sqlWarning = checkError(t2cCreateConnPool(arrayOfByte1, arrayOfByte1.length, arrayOfByte2, arrayOfByte2.length, arrayOfByte5, arrayOfByte5.length, this.m_clientCharacterSet, this.logon_mode, arrayOfInt[0], arrayOfInt[1], arrayOfInt[2], arrayOfInt[3], arrayOfInt[4], arrayOfInt[5]), this.sqlWarning);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1399 */         this.versionNumber = 10000;
/*      */       
/*      */       }
/*      */       else
/*      */       {
/*      */         
/* 1405 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 0, "Internal Error: ");
/* 1406 */         sQLException.fillInStackTrace();
/* 1407 */         throw sQLException;
/*      */       
/*      */       }
/*      */     
/*      */     }
/* 1412 */     else if (this.ociConnectionPoolLogonMode == "connpool_connection") {
/*      */       
/* 1414 */       this.logon_mode = 6;
/*      */       
/* 1416 */       arrayOfByte1 = (this.userName == null) ? new byte[0] : DBConversion.stringToDriverCharBytes(this.userName, this.m_clientCharacterSet);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1422 */       this.conversion = new DBConversion(this.m_clientCharacterSet, this.m_clientCharacterSet, this.m_clientCharacterSet);
/*      */ 
/*      */       
/* 1425 */       this.sqlWarning = checkError(t2cConnPoolLogon(t2CConnection.m_nativeState, arrayOfByte1, arrayOfByte1.length, arrayOfByte2, arrayOfByte2.length, arrayOfByte3, arrayOfByte3.length, arrayOfByte4, arrayOfByte4.length, arrayOfByte5, arrayOfByte5.length, this.logon_mode, 0, 0, (String[])null, (byte[])null, 0, (byte[])null, 0, (byte[])null, 0, (byte[])null, 0, (byte[])null, 0, arrayOfByte6, arrayOfByte7, arrayOfLong), this.sqlWarning);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     }
/* 1457 */     else if (this.ociConnectionPoolLogonMode == "connpool_alias_connection") {
/*      */       
/* 1459 */       this.logon_mode = 8;
/*      */ 
/*      */       
/* 1462 */       byte[] arrayOfByte = null;
/*      */       
/* 1464 */       arrayOfByte = (byte[])this.ociConnectionPoolConnID;
/*      */ 
/*      */       
/* 1467 */       arrayOfByte1 = (this.userName == null) ? new byte[0] : DBConversion.stringToDriverCharBytes(this.userName, this.m_clientCharacterSet);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1473 */       this.conversion = new DBConversion(this.m_clientCharacterSet, this.m_clientCharacterSet, this.m_clientCharacterSet);
/*      */ 
/*      */       
/* 1476 */       this.sqlWarning = checkError(t2cConnPoolLogon(t2CConnection.m_nativeState, arrayOfByte1, arrayOfByte1.length, arrayOfByte2, arrayOfByte2.length, arrayOfByte3, arrayOfByte3.length, arrayOfByte4, arrayOfByte4.length, arrayOfByte5, arrayOfByte5.length, this.logon_mode, 0, 0, (String[])null, (byte[])null, 0, (byte[])null, 0, (byte[])null, 0, (byte[])null, 0, arrayOfByte, (arrayOfByte == null) ? 0 : arrayOfByte.length, arrayOfByte6, arrayOfByte7, arrayOfLong), this.sqlWarning);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     }
/* 1508 */     else if (this.ociConnectionPoolLogonMode == "connpool_proxy_connection") {
/*      */       
/* 1510 */       this.logon_mode = 7;
/*      */ 
/*      */       
/* 1513 */       String str = this.ociConnectionPoolProxyType;
/*      */ 
/*      */       
/* 1516 */       int i = this.ociConnectionPoolProxyNumRoles.intValue();
/*      */       
/* 1518 */       String[] arrayOfString = null;
/*      */       
/* 1520 */       if (i > 0)
/*      */       {
/* 1522 */         arrayOfString = (String[])this.ociConnectionPoolProxyRoles;
/*      */       }
/*      */ 
/*      */       
/* 1526 */       byte[] arrayOfByte8 = null;
/* 1527 */       byte[] arrayOfByte9 = null;
/* 1528 */       byte[] arrayOfByte10 = null;
/* 1529 */       byte[] arrayOfByte11 = null;
/*      */ 
/*      */       
/* 1532 */       byte b = 0;
/*      */ 
/*      */       
/* 1535 */       if (str == "proxytype_user_name") {
/*      */         
/* 1537 */         b = 1;
/*      */         
/* 1539 */         String str1 = this.ociConnectionPoolProxyUserName;
/*      */         
/* 1541 */         if (str1 != null) {
/* 1542 */           arrayOfByte8 = str1.getBytes();
/*      */         }
/* 1544 */         str1 = this.ociConnectionPoolProxyPassword;
/*      */         
/* 1546 */         if (str1 != null) {
/* 1547 */           arrayOfByte9 = str1.getBytes();
/*      */         }
/* 1549 */       } else if (str == "proxytype_distinguished_name") {
/*      */ 
/*      */         
/* 1552 */         b = 2;
/*      */         
/* 1554 */         String str1 = this.ociConnectionPoolProxyDistinguishedName;
/*      */         
/* 1556 */         if (str1 != null) {
/* 1557 */           arrayOfByte10 = str1.getBytes();
/*      */         }
/* 1559 */       } else if (str == "proxytype_certificate") {
/*      */         
/* 1561 */         b = 3;
/*      */         
/* 1563 */         arrayOfByte11 = (byte[])this.ociConnectionPoolProxyCertificate;
/*      */       
/*      */       }
/*      */       else {
/*      */ 
/*      */         
/* 1569 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 107);
/* 1570 */         sQLException.fillInStackTrace();
/* 1571 */         throw sQLException;
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/* 1576 */       arrayOfByte1 = (this.userName == null) ? new byte[0] : DBConversion.stringToDriverCharBytes(this.userName, this.m_clientCharacterSet);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1582 */       this.conversion = new DBConversion(this.m_clientCharacterSet, this.m_clientCharacterSet, this.m_clientCharacterSet);
/*      */ 
/*      */       
/* 1585 */       this.sqlWarning = checkError(t2cConnPoolLogon(t2CConnection.m_nativeState, arrayOfByte1, arrayOfByte1.length, arrayOfByte2, arrayOfByte2.length, arrayOfByte3, arrayOfByte3.length, arrayOfByte4, arrayOfByte4.length, arrayOfByte5, arrayOfByte5.length, this.logon_mode, b, i, arrayOfString, arrayOfByte8, (arrayOfByte8 == null) ? 0 : arrayOfByte8.length, arrayOfByte9, (arrayOfByte9 == null) ? 0 : arrayOfByte9.length, arrayOfByte10, (arrayOfByte10 == null) ? 0 : arrayOfByte10.length, arrayOfByte11, (arrayOfByte11 == null) ? 0 : arrayOfByte11.length, (byte[])null, 0, arrayOfByte6, arrayOfByte7, arrayOfLong), this.sqlWarning);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     }
/*      */     else {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1611 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 23, "connection-pool-logon");
/* 1612 */       sQLException.fillInStackTrace();
/* 1613 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/* 1617 */     this.conversion = new DBConversion((short)(int)(arrayOfLong[2] & 0xFFFFL), this.m_clientCharacterSet, (short)(int)(arrayOfLong[3] & 0xFFFFL));
/*      */ 
/*      */ 
/*      */     
/* 1621 */     this.byteAlign = (byte)(int)(arrayOfLong[4] & 0xFFL);
/* 1622 */     this.timeZoneVersionNumber = (int)arrayOfLong[5];
/*      */ 
/*      */     
/* 1625 */     if (arrayOfLong[6] != 0L) {
/* 1626 */       this.useOCIDefaultDefines = true;
/*      */     }
/* 1628 */     this.tagMatched[0] = (arrayOfLong[7] != 0L);
/*      */     
/* 1630 */     this.varTypeMaxLenCompat = (int)arrayOfLong[8];
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isDescriptorSharable(OracleConnection paramOracleConnection) throws SQLException {
/* 1647 */     T2CConnection t2CConnection = this;
/* 1648 */     PhysicalConnection physicalConnection = (PhysicalConnection)paramOracleConnection.getPhysicalConnection();
/*      */     
/* 1650 */     return (t2CConnection == physicalConnection);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private long lobLength(byte[] paramArrayOfbyte) throws SQLException {
/* 1727 */     long l = 0L;
/* 1728 */     l = t2cLobGetLength(this.m_nativeState, paramArrayOfbyte, paramArrayOfbyte.length);
/*      */     
/* 1730 */     checkError((int)l);
/*      */     
/* 1732 */     return l;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private int blobRead(byte[] paramArrayOfbyte1, long paramLong, int paramInt, byte[] paramArrayOfbyte2, boolean paramBoolean, ByteBuffer paramByteBuffer) throws SQLException {
/* 1747 */     int i = 0;
/*      */     
/* 1749 */     i = t2cBlobRead(this.m_nativeState, paramArrayOfbyte1, paramArrayOfbyte1.length, paramLong, paramInt, paramArrayOfbyte2, paramArrayOfbyte2.length, paramBoolean, paramByteBuffer);
/*      */ 
/*      */     
/* 1752 */     checkError(i);
/*      */     
/* 1754 */     return i;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private int blobWrite(byte[] paramArrayOfbyte1, long paramLong, byte[] paramArrayOfbyte2, byte[][] paramArrayOfbyte, int paramInt1, int paramInt2) throws SQLException {
/* 1769 */     int i = 0;
/*      */     
/* 1771 */     i = t2cBlobWrite(this.m_nativeState, paramArrayOfbyte1, paramArrayOfbyte1.length, paramLong, paramInt2, paramArrayOfbyte2, paramInt1, paramArrayOfbyte);
/*      */ 
/*      */     
/* 1774 */     checkError(i);
/*      */     
/* 1776 */     return i;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private int clobWrite(byte[] paramArrayOfbyte, long paramLong, char[] paramArrayOfchar, byte[][] paramArrayOfbyte1, boolean paramBoolean, int paramInt1, int paramInt2) throws SQLException {
/* 1792 */     int i = 0;
/*      */     
/* 1794 */     i = t2cClobWrite(this.m_nativeState, paramArrayOfbyte, paramArrayOfbyte.length, paramLong, paramInt2, paramArrayOfchar, paramInt1, paramArrayOfbyte1, paramBoolean);
/*      */ 
/*      */     
/* 1797 */     checkError(i);
/*      */     
/* 1799 */     return i;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private int lobGetChunkSize(byte[] paramArrayOfbyte) throws SQLException {
/* 1807 */     int i = 0;
/* 1808 */     i = t2cLobGetChunkSize(this.m_nativeState, paramArrayOfbyte, paramArrayOfbyte.length);
/*      */     
/* 1810 */     checkError(i);
/*      */     
/* 1812 */     return i;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized long length(BFILE paramBFILE) throws SQLException {
/* 1825 */     byte[] arrayOfByte = null;
/*      */     
/* 1827 */     checkTrue((this.lifecycle == 1), 8);
/* 1828 */     checkTrue((paramBFILE != null && (arrayOfByte = paramBFILE.getLocator()) != null), 54);
/*      */ 
/*      */     
/* 1831 */     return lobLength(arrayOfByte);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized long position(BFILE paramBFILE, byte[] paramArrayOfbyte, long paramLong) throws SQLException {
/* 1849 */     if (paramLong < 1L) {
/*      */ 
/*      */       
/* 1852 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68, "position()");
/* 1853 */       sQLException.fillInStackTrace();
/* 1854 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/* 1858 */     long l = LobPlsqlUtil.hasPattern(paramBFILE, paramArrayOfbyte, paramLong);
/*      */     
/* 1860 */     l = (l == 0L) ? -1L : l;
/*      */     
/* 1862 */     return l;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized long position(BFILE paramBFILE1, BFILE paramBFILE2, long paramLong) throws SQLException {
/* 1880 */     if (paramLong < 1L) {
/*      */ 
/*      */       
/* 1883 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68, "position()");
/* 1884 */       sQLException.fillInStackTrace();
/* 1885 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/* 1889 */     long l = LobPlsqlUtil.isSubLob(paramBFILE1, paramBFILE2, paramLong);
/*      */     
/* 1891 */     l = (l == 0L) ? -1L : l;
/*      */     
/* 1893 */     return l;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized int getBytes(BFILE paramBFILE, long paramLong, int paramInt, byte[] paramArrayOfbyte) throws SQLException {
/* 1909 */     byte[] arrayOfByte = null;
/*      */     
/* 1911 */     checkTrue((this.lifecycle == 1), 8);
/* 1912 */     checkTrue((paramBFILE != null && (arrayOfByte = paramBFILE.getLocator()) != null), 54);
/*      */ 
/*      */     
/* 1915 */     if (paramInt <= 0 || paramArrayOfbyte == null) {
/* 1916 */       return 0;
/*      */     }
/* 1918 */     if (paramInt > paramArrayOfbyte.length) {
/* 1919 */       paramInt = paramArrayOfbyte.length;
/*      */     }
/* 1921 */     if (this.useNio) {
/*      */       
/* 1923 */       int j = paramArrayOfbyte.length;
/* 1924 */       if (this.nioBufferForLob == null || this.nioBufferForLob.capacity() < j) {
/* 1925 */         this.nioBufferForLob = ByteBuffer.allocateDirect(j);
/*      */       } else {
/* 1927 */         this.nioBufferForLob.rewind();
/*      */       } 
/*      */     } 
/* 1930 */     int i = blobRead(arrayOfByte, paramLong, paramInt, paramArrayOfbyte, this.useNio, this.nioBufferForLob);
/* 1931 */     if (this.useNio)
/*      */     {
/* 1933 */       this.nioBufferForLob.get(paramArrayOfbyte);
/*      */     }
/*      */     
/* 1936 */     return i;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized String getName(BFILE paramBFILE) throws SQLException {
/* 1950 */     byte[] arrayOfByte = null;
/* 1951 */     String str = null;
/*      */     
/* 1953 */     checkTrue((this.lifecycle == 1), 8);
/* 1954 */     checkTrue((paramBFILE != null && (arrayOfByte = paramBFILE.getLocator()) != null), 54);
/*      */ 
/*      */     
/* 1957 */     str = t2cBfileGetName(this.m_nativeState, arrayOfByte, arrayOfByte.length);
/*      */     
/* 1959 */     checkError(str.length());
/*      */     
/* 1961 */     return str;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized String getDirAlias(BFILE paramBFILE) throws SQLException {
/* 1975 */     byte[] arrayOfByte = null;
/* 1976 */     String str = null;
/*      */     
/* 1978 */     checkTrue((this.lifecycle == 1), 8);
/* 1979 */     checkTrue((paramBFILE != null && (arrayOfByte = paramBFILE.getLocator()) != null), 54);
/*      */ 
/*      */     
/* 1982 */     str = t2cBfileGetDirAlias(this.m_nativeState, arrayOfByte, arrayOfByte.length);
/*      */     
/* 1984 */     checkError(str.length());
/*      */     
/* 1986 */     return str;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void openFile(BFILE paramBFILE) throws SQLException {
/* 1999 */     byte[] arrayOfByte = null;
/*      */     
/* 2001 */     checkTrue((this.lifecycle == 1), 8);
/* 2002 */     checkTrue((paramBFILE != null && (arrayOfByte = paramBFILE.getLocator()) != null), 54);
/*      */ 
/*      */     
/* 2005 */     byte[][] arrayOfByte1 = new byte[1][];
/*      */     
/* 2007 */     checkError(t2cBfileOpen(this.m_nativeState, arrayOfByte, arrayOfByte.length, arrayOfByte1));
/*      */ 
/*      */     
/* 2010 */     paramBFILE.setLocator(arrayOfByte1[0]);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized boolean isFileOpen(BFILE paramBFILE) throws SQLException {
/* 2027 */     byte[] arrayOfByte = null;
/*      */     
/* 2029 */     checkTrue((this.lifecycle == 1), 8);
/* 2030 */     checkTrue((paramBFILE != null && (arrayOfByte = paramBFILE.getLocator()) != null), 54);
/*      */ 
/*      */     
/* 2033 */     boolean[] arrayOfBoolean = new boolean[1];
/*      */     
/* 2035 */     checkError(t2cBfileIsOpen(this.m_nativeState, arrayOfByte, arrayOfByte.length, arrayOfBoolean));
/*      */     
/* 2037 */     return arrayOfBoolean[0];
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized boolean fileExists(BFILE paramBFILE) throws SQLException {
/* 2053 */     byte[] arrayOfByte = null;
/*      */     
/* 2055 */     checkTrue((this.lifecycle == 1), 8);
/* 2056 */     checkTrue((paramBFILE != null && (arrayOfByte = paramBFILE.getLocator()) != null), 54);
/*      */ 
/*      */     
/* 2059 */     boolean[] arrayOfBoolean = new boolean[1];
/*      */     
/* 2061 */     checkError(t2cBfileExists(this.m_nativeState, arrayOfByte, arrayOfByte.length, arrayOfBoolean));
/*      */     
/* 2063 */     return arrayOfBoolean[0];
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void closeFile(BFILE paramBFILE) throws SQLException {
/* 2076 */     byte[] arrayOfByte = null;
/*      */     
/* 2078 */     checkTrue((this.lifecycle == 1), 8);
/* 2079 */     checkTrue((paramBFILE != null && (arrayOfByte = paramBFILE.getLocator()) != null), 54);
/*      */ 
/*      */     
/* 2082 */     byte[][] arrayOfByte1 = new byte[1][];
/*      */     
/* 2084 */     checkError(t2cBfileClose(this.m_nativeState, arrayOfByte, arrayOfByte.length, arrayOfByte1));
/*      */ 
/*      */     
/* 2087 */     paramBFILE.setLocator(arrayOfByte1[0]);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void open(BFILE paramBFILE, int paramInt) throws SQLException {
/* 2102 */     byte[] arrayOfByte = null;
/*      */     
/* 2104 */     checkTrue((this.lifecycle == 1), 8);
/* 2105 */     checkTrue((paramBFILE != null && (arrayOfByte = paramBFILE.shareBytes()) != null), 54);
/*      */ 
/*      */     
/* 2108 */     byte[][] arrayOfByte1 = new byte[1][];
/*      */     
/* 2110 */     checkError(t2cLobOpen(this.m_nativeState, 114, arrayOfByte, arrayOfByte.length, paramInt, arrayOfByte1));
/*      */ 
/*      */     
/* 2113 */     paramBFILE.setShareBytes(arrayOfByte1[0]);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void close(BFILE paramBFILE) throws SQLException {
/* 2126 */     byte[] arrayOfByte = null;
/*      */     
/* 2128 */     checkTrue((this.lifecycle == 1), 8);
/* 2129 */     checkTrue((paramBFILE != null && (arrayOfByte = paramBFILE.shareBytes()) != null), 54);
/*      */ 
/*      */     
/* 2132 */     byte[][] arrayOfByte1 = new byte[1][];
/*      */     
/* 2134 */     checkError(t2cLobClose(this.m_nativeState, 114, arrayOfByte, arrayOfByte.length, arrayOfByte1));
/*      */ 
/*      */     
/* 2137 */     paramBFILE.setShareBytes(arrayOfByte1[0]);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized boolean isOpen(BFILE paramBFILE) throws SQLException {
/* 2151 */     byte[] arrayOfByte = null;
/*      */     
/* 2153 */     checkTrue((this.lifecycle == 1), 8);
/* 2154 */     checkTrue((paramBFILE != null && (arrayOfByte = paramBFILE.shareBytes()) != null), 54);
/*      */ 
/*      */     
/* 2157 */     boolean[] arrayOfBoolean = new boolean[1];
/*      */     
/* 2159 */     checkError(t2cLobIsOpen(this.m_nativeState, 114, arrayOfByte, arrayOfByte.length, arrayOfBoolean));
/*      */ 
/*      */     
/* 2162 */     return arrayOfBoolean[0];
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public InputStream newInputStream(BFILE paramBFILE, int paramInt, long paramLong) throws SQLException {
/* 2181 */     return newInputStream((OracleBfile)paramBFILE, paramInt, paramLong);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public InputStream newInputStream(OracleBfile paramOracleBfile, int paramInt, long paramLong) throws SQLException {
/* 2201 */     if (paramLong == 0L)
/*      */     {
/* 2203 */       return new OracleBlobInputStream(paramOracleBfile, paramInt);
/*      */     }
/*      */ 
/*      */     
/* 2207 */     return new OracleBlobInputStream(paramOracleBfile, paramInt, paramLong);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public InputStream newConversionInputStream(BFILE paramBFILE, int paramInt) throws SQLException {
/* 2226 */     return newConversionInputStream((OracleBfile)paramBFILE, paramInt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public InputStream newConversionInputStream(OracleBfile paramOracleBfile, int paramInt) throws SQLException {
/* 2245 */     checkTrue((paramOracleBfile != null && paramOracleBfile.shareBytes() != null), 54);
/*      */ 
/*      */     
/* 2248 */     return new OracleConversionInputStream(this.conversion, paramOracleBfile.getBinaryStream(), paramInt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Reader newConversionReader(BFILE paramBFILE, int paramInt) throws SQLException {
/* 2269 */     return newConversionReader((OracleBfile)paramBFILE, paramInt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Reader newConversionReader(OracleBfile paramOracleBfile, int paramInt) throws SQLException {
/* 2288 */     checkTrue((paramOracleBfile != null && paramOracleBfile.shareBytes() != null), 54);
/*      */ 
/*      */     
/* 2291 */     return new OracleConversionReader(this.conversion, paramOracleBfile.getBinaryStream(), paramInt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized long length(BLOB paramBLOB) throws SQLException {
/* 2307 */     byte[] arrayOfByte = null;
/*      */     
/* 2309 */     checkTrue((this.lifecycle == 1), 8);
/* 2310 */     checkTrue((paramBLOB != null && (arrayOfByte = paramBLOB.getLocator()) != null), 54);
/*      */ 
/*      */     
/* 2313 */     return lobLength(arrayOfByte);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized long position(BLOB paramBLOB, byte[] paramArrayOfbyte, long paramLong) throws SQLException {
/* 2332 */     checkTrue((this.lifecycle == 1), 8);
/* 2333 */     checkTrue((paramBLOB != null && paramBLOB.shareBytes() != null), 54);
/*      */ 
/*      */     
/* 2336 */     if (paramLong < 1L) {
/*      */ 
/*      */       
/* 2339 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68, "position()");
/* 2340 */       sQLException.fillInStackTrace();
/* 2341 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/* 2345 */     long l = LobPlsqlUtil.hasPattern(paramBLOB, paramArrayOfbyte, paramLong);
/*      */     
/* 2347 */     l = (l == 0L) ? -1L : l;
/* 2348 */     return l;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized long position(BLOB paramBLOB1, BLOB paramBLOB2, long paramLong) throws SQLException {
/* 2365 */     checkTrue((this.lifecycle == 1), 8);
/* 2366 */     checkTrue((paramBLOB1 != null && paramBLOB1.shareBytes() != null), 54);
/*      */     
/* 2368 */     checkTrue((paramBLOB2 != null && paramBLOB2.shareBytes() != null), 54);
/*      */ 
/*      */     
/* 2371 */     if (paramLong < 1L) {
/*      */ 
/*      */       
/* 2374 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68, "position()");
/* 2375 */       sQLException.fillInStackTrace();
/* 2376 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/* 2380 */     long l = LobPlsqlUtil.isSubLob(paramBLOB1, paramBLOB2, paramLong);
/*      */     
/* 2382 */     l = (l == 0L) ? -1L : l;
/* 2383 */     return l;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized int getBytes(BLOB paramBLOB, long paramLong, int paramInt, byte[] paramArrayOfbyte) throws SQLException {
/* 2400 */     byte[] arrayOfByte = null;
/* 2401 */     int i = 0;
/*      */     
/* 2403 */     checkTrue((this.lifecycle == 1), 8);
/* 2404 */     checkTrue((paramBLOB != null && (arrayOfByte = paramBLOB.getLocator()) != null), 54);
/*      */ 
/*      */     
/* 2407 */     if (paramInt <= 0 || paramArrayOfbyte == null) {
/* 2408 */       return 0;
/*      */     }
/* 2410 */     if (paramInt > paramArrayOfbyte.length) {
/* 2411 */       paramInt = paramArrayOfbyte.length;
/*      */     }
/* 2413 */     long l = -1L;
/*      */     
/* 2415 */     if (paramBLOB.isActivePrefetch()) {
/*      */       
/* 2417 */       byte[] arrayOfByte1 = paramBLOB.getPrefetchedData();
/* 2418 */       l = paramBLOB.length();
/* 2419 */       if (arrayOfByte1 != null && arrayOfByte1.length > 0 && paramLong > 0L && paramLong <= arrayOfByte1.length) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2425 */         int j = Math.min(arrayOfByte1.length - (int)paramLong + 1, paramInt);
/*      */         
/* 2427 */         System.arraycopy(arrayOfByte1, (int)paramLong - 1, paramArrayOfbyte, 0, j);
/*      */         
/* 2429 */         i += j;
/*      */       } 
/*      */     } 
/*      */     
/* 2433 */     if (i < paramInt && (l == -1L || paramLong - 1L + i < l)) {
/*      */ 
/*      */ 
/*      */       
/* 2437 */       byte[] arrayOfByte1 = paramArrayOfbyte;
/* 2438 */       int j = i;
/* 2439 */       int k = ((l > 0L && l < paramInt) ? (int)l : paramInt) - i;
/*      */       
/* 2441 */       if (i > 0)
/*      */       {
/* 2443 */         arrayOfByte1 = new byte[k];
/*      */       }
/*      */       
/* 2446 */       if (this.useNio) {
/*      */         
/* 2448 */         int m = paramArrayOfbyte.length;
/* 2449 */         if (this.nioBufferForLob == null || this.nioBufferForLob.capacity() < m) {
/*      */           
/* 2451 */           this.nioBufferForLob = ByteBuffer.allocateDirect(m);
/*      */         } else {
/* 2453 */           this.nioBufferForLob.rewind();
/*      */         } 
/*      */       } 
/* 2456 */       i += blobRead(arrayOfByte, paramLong + i, k, arrayOfByte1, this.useNio, this.nioBufferForLob);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2462 */       if (this.useNio)
/*      */       {
/* 2464 */         this.nioBufferForLob.get(arrayOfByte1);
/*      */       }
/*      */ 
/*      */ 
/*      */       
/* 2469 */       if (j > 0)
/*      */       {
/* 2471 */         System.arraycopy(arrayOfByte1, 0, paramArrayOfbyte, j, arrayOfByte1.length);
/*      */       }
/*      */     } 
/*      */     
/* 2475 */     return i;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized int putBytes(BLOB paramBLOB, long paramLong, byte[] paramArrayOfbyte, int paramInt1, int paramInt2) throws SQLException {
/* 2497 */     checkTrue((paramLong != 0L || paramInt2 > 0), 68);
/*      */     
/* 2499 */     checkTrue((paramLong >= 0L), 68);
/* 2500 */     if (paramArrayOfbyte == null || paramInt2 <= 0) {
/* 2501 */       return 0;
/*      */     }
/* 2503 */     int i = 0;
/*      */     
/* 2505 */     if (paramArrayOfbyte == null || paramArrayOfbyte.length == 0 || paramInt2 <= 0) {
/* 2506 */       i = 0;
/*      */     } else {
/*      */       
/* 2509 */       byte[] arrayOfByte = null;
/*      */       
/* 2511 */       checkTrue((this.lifecycle == 1), 8);
/* 2512 */       checkTrue((paramBLOB != null && (arrayOfByte = paramBLOB.getLocator()) != null), 54);
/*      */ 
/*      */       
/* 2515 */       byte[][] arrayOfByte1 = new byte[1][];
/*      */       
/* 2517 */       paramBLOB.setActivePrefetch(false);
/* 2518 */       paramBLOB.clearCachedData();
/* 2519 */       i = blobWrite(arrayOfByte, paramLong, paramArrayOfbyte, arrayOfByte1, paramInt1, paramInt2);
/*      */ 
/*      */       
/* 2522 */       paramBLOB.setLocator(arrayOfByte1[0]);
/*      */     } 
/*      */     
/* 2525 */     return i;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized int getChunkSize(BLOB paramBLOB) throws SQLException {
/* 2537 */     byte[] arrayOfByte = null;
/*      */     
/* 2539 */     checkTrue((this.lifecycle == 1), 8);
/* 2540 */     checkTrue((paramBLOB != null && (arrayOfByte = paramBLOB.getLocator()) != null), 54);
/*      */ 
/*      */     
/* 2543 */     return lobGetChunkSize(arrayOfByte);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void trim(BLOB paramBLOB, long paramLong) throws SQLException {
/* 2557 */     byte[] arrayOfByte = null;
/*      */     
/* 2559 */     checkTrue((this.lifecycle == 1), 8);
/* 2560 */     checkTrue((paramBLOB != null && (arrayOfByte = paramBLOB.shareBytes()) != null), 54);
/*      */ 
/*      */     
/* 2563 */     byte[][] arrayOfByte1 = new byte[1][];
/*      */     
/* 2565 */     paramBLOB.setActivePrefetch(false);
/* 2566 */     paramBLOB.clearCachedData();
/* 2567 */     checkError(t2cLobTrim(this.m_nativeState, 113, paramLong, arrayOfByte, arrayOfByte.length, arrayOfByte1));
/*      */ 
/*      */     
/* 2570 */     paramBLOB.setShareBytes(arrayOfByte1[0]);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized BLOB createTemporaryBlob(Connection paramConnection, boolean paramBoolean, int paramInt) throws SQLException {
/* 2589 */     BLOB bLOB = null;
/*      */     
/* 2591 */     checkTrue((this.lifecycle == 1), 8);
/*      */     
/* 2593 */     bLOB = new BLOB((OracleConnection)paramConnection);
/*      */     
/* 2595 */     byte[][] arrayOfByte = new byte[1][];
/*      */     
/* 2597 */     checkError(t2cLobCreateTemporary(this.m_nativeState, 113, paramBoolean, paramInt, (short)0, arrayOfByte));
/*      */ 
/*      */     
/* 2600 */     bLOB.setShareBytes(arrayOfByte[0]);
/*      */     
/* 2602 */     return bLOB;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void freeTemporary(BLOB paramBLOB, boolean paramBoolean) throws SQLException {
/*      */     try {
/* 2618 */       byte[] arrayOfByte = null;
/*      */       
/* 2620 */       checkTrue((this.lifecycle == 1), 8);
/* 2621 */       checkTrue((paramBLOB != null && (arrayOfByte = paramBLOB.shareBytes()) != null), 54);
/*      */ 
/*      */       
/* 2624 */       byte[][] arrayOfByte1 = new byte[1][];
/*      */       
/* 2626 */       checkError(t2cLobFreeTemporary(this.m_nativeState, 113, arrayOfByte, arrayOfByte.length, arrayOfByte1));
/*      */ 
/*      */       
/* 2629 */       paramBLOB.setShareBytes(arrayOfByte1[0]);
/* 2630 */     } catch (SQLException sQLException) {
/*      */       
/* 2632 */       if ((paramBoolean & ((sQLException.getErrorCode() == 64201) ? 1 : 0)) != 0) {
/* 2633 */         LobPlsqlUtil.freeTemporaryLob((Connection)this, (Datum)paramBLOB, 2004);
/*      */       } else {
/* 2635 */         throw sQLException;
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized boolean isTemporary(BLOB paramBLOB) throws SQLException {
/* 2651 */     byte[] arrayOfByte = null;
/*      */     
/* 2653 */     checkTrue((paramBLOB != null && (arrayOfByte = paramBLOB.shareBytes()) != null), 54);
/*      */ 
/*      */     
/* 2656 */     boolean[] arrayOfBoolean = new boolean[1];
/*      */     
/* 2658 */     checkError(t2cLobIsTemporary(this.m_nativeState, 113, arrayOfByte, arrayOfByte.length, arrayOfBoolean));
/*      */ 
/*      */     
/* 2661 */     return arrayOfBoolean[0];
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void open(BLOB paramBLOB, int paramInt) throws SQLException {
/* 2674 */     byte[] arrayOfByte = null;
/*      */     
/* 2676 */     checkTrue((this.lifecycle == 1), 8);
/* 2677 */     checkTrue((paramBLOB != null && (arrayOfByte = paramBLOB.shareBytes()) != null), 54);
/*      */ 
/*      */     
/* 2680 */     byte[][] arrayOfByte1 = new byte[1][];
/*      */     
/* 2682 */     checkError(t2cLobOpen(this.m_nativeState, 113, arrayOfByte, arrayOfByte.length, paramInt, arrayOfByte1));
/*      */ 
/*      */     
/* 2685 */     paramBLOB.setShareBytes(arrayOfByte1[0]);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void close(BLOB paramBLOB) throws SQLException {
/* 2698 */     byte[] arrayOfByte = null;
/*      */     
/* 2700 */     checkTrue((this.lifecycle == 1), 8);
/* 2701 */     checkTrue((paramBLOB != null && (arrayOfByte = paramBLOB.shareBytes()) != null), 54);
/*      */ 
/*      */     
/* 2704 */     byte[][] arrayOfByte1 = new byte[1][];
/*      */     
/* 2706 */     checkError(t2cLobClose(this.m_nativeState, 113, arrayOfByte, arrayOfByte.length, arrayOfByte1));
/*      */ 
/*      */     
/* 2709 */     paramBLOB.setShareBytes(arrayOfByte1[0]);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized boolean isOpen(BLOB paramBLOB) throws SQLException {
/* 2723 */     byte[] arrayOfByte = null;
/*      */     
/* 2725 */     checkTrue((this.lifecycle == 1), 8);
/* 2726 */     checkTrue((paramBLOB != null && (arrayOfByte = paramBLOB.shareBytes()) != null), 54);
/*      */ 
/*      */     
/* 2729 */     boolean[] arrayOfBoolean = new boolean[1];
/*      */     
/* 2731 */     checkError(t2cLobIsOpen(this.m_nativeState, 113, arrayOfByte, arrayOfByte.length, arrayOfBoolean));
/*      */ 
/*      */     
/* 2734 */     return arrayOfBoolean[0];
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public InputStream newInputStream(BLOB paramBLOB, int paramInt, long paramLong) throws SQLException {
/* 2753 */     return newInputStream((OracleBlob)paramBLOB, paramInt, paramLong);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public InputStream newInputStream(OracleBlob paramOracleBlob, int paramInt, long paramLong) throws SQLException {
/* 2772 */     if (paramLong == 0L)
/*      */     {
/* 2774 */       return new OracleBlobInputStream(paramOracleBlob, paramInt);
/*      */     }
/*      */ 
/*      */     
/* 2778 */     return new OracleBlobInputStream(paramOracleBlob, paramInt, paramLong);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public InputStream newInputStream(BLOB paramBLOB, int paramInt, long paramLong1, long paramLong2) throws SQLException {
/* 2798 */     return newInputStream((OracleBlob)paramBLOB, paramInt, paramLong1, paramLong2);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public InputStream newInputStream(OracleBlob paramOracleBlob, int paramInt, long paramLong1, long paramLong2) throws SQLException {
/* 2817 */     return new OracleBlobInputStream(paramOracleBlob, paramInt, paramLong1, paramLong2);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public OutputStream newOutputStream(BLOB paramBLOB, int paramInt, long paramLong, boolean paramBoolean) throws SQLException {
/* 2836 */     return newOutputStream((OracleBlob)paramBLOB, paramInt, paramLong, paramBoolean);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public OutputStream newOutputStream(OracleBlob paramOracleBlob, int paramInt, long paramLong, boolean paramBoolean) throws SQLException {
/* 2855 */     if (paramLong == 0L) {
/*      */       
/* 2857 */       if (paramBoolean & this.lobStreamPosStandardCompliant) {
/*      */ 
/*      */         
/* 2860 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/* 2861 */         sQLException.fillInStackTrace();
/* 2862 */         throw sQLException;
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/* 2867 */       return new OracleBlobOutputStream(paramOracleBlob, paramInt);
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 2872 */     return new OracleBlobOutputStream(paramOracleBlob, paramInt, paramLong);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public InputStream newConversionInputStream(BLOB paramBLOB, int paramInt) throws SQLException {
/* 2891 */     return newConversionInputStream((OracleBlob)paramBLOB, paramInt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public InputStream newConversionInputStream(OracleBlob paramOracleBlob, int paramInt) throws SQLException {
/* 2911 */     checkTrue((paramOracleBlob != null && paramOracleBlob.shareBytes() != null), 54);
/*      */ 
/*      */     
/* 2914 */     return new OracleConversionInputStream(this.conversion, paramOracleBlob.getBinaryStream(), paramInt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Reader newConversionReader(BLOB paramBLOB, int paramInt) throws SQLException {
/* 2934 */     return newConversionReader((OracleBlob)paramBLOB, paramInt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Reader newConversionReader(OracleBlob paramOracleBlob, int paramInt) throws SQLException {
/* 2953 */     checkTrue((paramOracleBlob != null && paramOracleBlob.shareBytes() != null), 54);
/*      */ 
/*      */     
/* 2956 */     return new OracleConversionReader(this.conversion, paramOracleBlob.getBinaryStream(), paramInt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized long length(CLOB paramCLOB) throws SQLException {
/* 2976 */     byte[] arrayOfByte = null;
/*      */     
/* 2978 */     checkTrue((this.lifecycle == 1), 8);
/* 2979 */     checkTrue((paramCLOB != null && (arrayOfByte = paramCLOB.getLocator()) != null), 54);
/*      */ 
/*      */     
/* 2982 */     return lobLength(arrayOfByte);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized long position(CLOB paramCLOB, String paramString, long paramLong) throws SQLException {
/* 3000 */     if (paramString == null) {
/*      */       
/* 3002 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/* 3003 */       sQLException.fillInStackTrace();
/* 3004 */       throw sQLException;
/*      */     } 
/*      */     
/* 3007 */     checkTrue((this.lifecycle == 1), 8);
/* 3008 */     checkTrue((paramCLOB != null && paramCLOB.shareBytes() != null), 54);
/*      */ 
/*      */     
/* 3011 */     if (paramLong < 1L) {
/*      */ 
/*      */       
/* 3014 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68, "position()");
/* 3015 */       sQLException.fillInStackTrace();
/* 3016 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/* 3020 */     char[] arrayOfChar = new char[paramString.length()];
/*      */     
/* 3022 */     paramString.getChars(0, arrayOfChar.length, arrayOfChar, 0);
/*      */     
/* 3024 */     long l = LobPlsqlUtil.hasPattern(paramCLOB, arrayOfChar, paramLong);
/*      */     
/* 3026 */     l = (l == 0L) ? -1L : l;
/* 3027 */     return l;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized long position(CLOB paramCLOB1, CLOB paramCLOB2, long paramLong) throws SQLException {
/* 3044 */     checkTrue((this.lifecycle == 1), 8);
/* 3045 */     checkTrue((paramCLOB1 != null && paramCLOB1.shareBytes() != null), 54);
/*      */     
/* 3047 */     checkTrue((paramCLOB2 != null && paramCLOB2.shareBytes() != null), 54);
/*      */ 
/*      */     
/* 3050 */     if (paramLong < 1L) {
/*      */ 
/*      */       
/* 3053 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68, "position()");
/* 3054 */       sQLException.fillInStackTrace();
/* 3055 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/* 3059 */     long l = LobPlsqlUtil.isSubLob(paramCLOB1, paramCLOB2, paramLong);
/*      */     
/* 3061 */     l = (l == 0L) ? -1L : l;
/* 3062 */     return l;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized int getChars(CLOB paramCLOB, long paramLong, int paramInt, char[] paramArrayOfchar) throws SQLException {
/* 3079 */     byte[] arrayOfByte = null;
/*      */     
/* 3081 */     checkTrue((this.lifecycle == 1), 8);
/* 3082 */     checkTrue((paramCLOB != null && (arrayOfByte = paramCLOB.getLocator()) != null), 54);
/*      */ 
/*      */     
/* 3085 */     if (paramInt <= 0 || paramArrayOfchar == null) {
/* 3086 */       return 0;
/*      */     }
/* 3088 */     if (paramInt > paramArrayOfchar.length) {
/* 3089 */       paramInt = paramArrayOfchar.length;
/*      */     }
/* 3091 */     int i = 0;
/*      */ 
/*      */     
/* 3094 */     long l = -1L;
/*      */ 
/*      */     
/* 3097 */     if (paramCLOB.isActivePrefetch()) {
/*      */       
/* 3099 */       l = paramCLOB.length();
/* 3100 */       char[] arrayOfChar = paramCLOB.getPrefetchedData();
/* 3101 */       long l1 = paramCLOB.getPrefetchedDataSize();
/*      */ 
/*      */       
/* 3104 */       if (arrayOfChar != null && paramLong <= l1) {
/*      */ 
/*      */         
/* 3107 */         int j = Math.min((int)l1 - (int)paramLong + 1, paramInt);
/*      */ 
/*      */         
/* 3110 */         System.arraycopy(arrayOfChar, (int)paramLong - 1, paramArrayOfchar, 0, j);
/*      */         
/* 3112 */         i += j;
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/* 3117 */     if (i < paramInt && (l == -1L || paramLong - 1L + i < l)) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 3122 */       char[] arrayOfChar = paramArrayOfchar;
/* 3123 */       int j = i;
/* 3124 */       int k = ((l > 0L && l < paramInt) ? (int)l : paramInt) - i;
/*      */       
/* 3126 */       if (i > 0)
/*      */       {
/* 3128 */         arrayOfChar = new char[k];
/*      */       }
/*      */       
/* 3131 */       if (this.useNio) {
/*      */ 
/*      */ 
/*      */         
/* 3135 */         int m = paramArrayOfchar.length * 2;
/* 3136 */         if (this.nioBufferForLob == null || this.nioBufferForLob.capacity() < m) {
/* 3137 */           this.nioBufferForLob = ByteBuffer.allocateDirect(m);
/*      */         } else {
/* 3139 */           this.nioBufferForLob.rewind();
/*      */         } 
/*      */       } 
/* 3142 */       i += t2cClobRead(this.m_nativeState, arrayOfByte, arrayOfByte.length, paramLong + i, k, arrayOfChar, arrayOfChar.length, paramCLOB.isNCLOB(), this.useNio, this.nioBufferForLob);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 3154 */       if (this.useNio) {
/*      */         
/* 3156 */         ByteBuffer byteBuffer = this.nioBufferForLob.order(ByteOrder.LITTLE_ENDIAN);
/* 3157 */         CharBuffer charBuffer = byteBuffer.asCharBuffer();
/* 3158 */         charBuffer.get(arrayOfChar);
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/* 3163 */       if (j > 0)
/*      */       {
/* 3165 */         System.arraycopy(arrayOfChar, 0, paramArrayOfchar, j, arrayOfChar.length);
/*      */       }
/*      */       
/* 3168 */       checkError(i);
/*      */     } 
/*      */     
/* 3171 */     return i;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized int putChars(CLOB paramCLOB, long paramLong, char[] paramArrayOfchar, int paramInt1, int paramInt2) throws SQLException {
/* 3192 */     byte[] arrayOfByte = null;
/*      */     
/* 3194 */     checkTrue((this.lifecycle == 1), 8);
/* 3195 */     checkTrue((paramLong >= 0L), 68);
/*      */     
/* 3197 */     checkTrue((paramCLOB != null && (arrayOfByte = paramCLOB.getLocator()) != null), 54);
/*      */ 
/*      */     
/* 3200 */     if (paramArrayOfchar == null) {
/* 3201 */       return 0;
/*      */     }
/* 3203 */     byte[][] arrayOfByte1 = new byte[1][];
/* 3204 */     paramCLOB.setActivePrefetch(false);
/* 3205 */     paramCLOB.clearCachedData();
/* 3206 */     int i = clobWrite(arrayOfByte, paramLong, paramArrayOfchar, arrayOfByte1, paramCLOB.isNCLOB(), paramInt1, paramInt2);
/*      */ 
/*      */     
/* 3209 */     paramCLOB.setLocator(arrayOfByte1[0]);
/*      */     
/* 3211 */     return i;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized int getChunkSize(CLOB paramCLOB) throws SQLException {
/* 3223 */     byte[] arrayOfByte = null;
/*      */     
/* 3225 */     checkTrue((this.lifecycle == 1), 8);
/* 3226 */     checkTrue((paramCLOB != null && (arrayOfByte = paramCLOB.getLocator()) != null), 54);
/*      */ 
/*      */     
/* 3229 */     return lobGetChunkSize(arrayOfByte);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void trim(CLOB paramCLOB, long paramLong) throws SQLException {
/* 3243 */     byte[] arrayOfByte = null;
/*      */     
/* 3245 */     checkTrue((this.lifecycle == 1), 8);
/* 3246 */     checkTrue((paramCLOB != null && (arrayOfByte = paramCLOB.shareBytes()) != null), 54);
/*      */ 
/*      */     
/* 3249 */     byte[][] arrayOfByte1 = new byte[1][];
/*      */     
/* 3251 */     paramCLOB.setActivePrefetch(false);
/* 3252 */     paramCLOB.clearCachedData();
/* 3253 */     checkError(t2cLobTrim(this.m_nativeState, 112, paramLong, arrayOfByte, arrayOfByte.length, arrayOfByte1));
/*      */ 
/*      */     
/* 3256 */     paramCLOB.setShareBytes(arrayOfByte1[0]);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized CLOB createTemporaryClob(Connection paramConnection, boolean paramBoolean, int paramInt, short paramShort) throws SQLException {
/*      */     NCLOB nCLOB;
/* 3276 */     CLOB cLOB = null;
/*      */     
/* 3278 */     checkTrue((this.lifecycle == 1), 8);
/*      */     
/* 3280 */     if (paramShort == 1) {
/* 3281 */       cLOB = new CLOB((OracleConnection)paramConnection);
/*      */     } else {
/*      */       
/* 3284 */       nCLOB = new NCLOB((OracleConnection)paramConnection);
/*      */     } 
/*      */     
/* 3287 */     byte[][] arrayOfByte = new byte[1][];
/*      */     
/* 3289 */     checkError(t2cLobCreateTemporary(this.m_nativeState, 112, paramBoolean, paramInt, paramShort, arrayOfByte));
/*      */ 
/*      */     
/* 3292 */     nCLOB.setShareBytes(arrayOfByte[0]);
/*      */     
/* 3294 */     return (CLOB)nCLOB;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void freeTemporary(CLOB paramCLOB, boolean paramBoolean) throws SQLException {
/*      */     try {
/* 3309 */       byte[] arrayOfByte = null;
/*      */       
/* 3311 */       checkTrue((this.lifecycle == 1), 8);
/* 3312 */       checkTrue((paramCLOB != null && (arrayOfByte = paramCLOB.shareBytes()) != null), 54);
/*      */ 
/*      */       
/* 3315 */       byte[][] arrayOfByte1 = new byte[1][];
/*      */       
/* 3317 */       checkError(t2cLobFreeTemporary(this.m_nativeState, 112, arrayOfByte, arrayOfByte.length, arrayOfByte1));
/*      */ 
/*      */       
/* 3320 */       paramCLOB.setShareBytes(arrayOfByte1[0]);
/* 3321 */     } catch (SQLException sQLException) {
/*      */       
/* 3323 */       if ((paramBoolean & ((sQLException.getErrorCode() == 64201) ? 1 : 0)) != 0) {
/* 3324 */         LobPlsqlUtil.freeTemporaryLob((Connection)this, (Datum)paramCLOB, 2005);
/*      */       } else {
/* 3326 */         throw sQLException;
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized boolean isTemporary(CLOB paramCLOB) throws SQLException {
/* 3343 */     byte[] arrayOfByte = null;
/*      */     
/* 3345 */     checkTrue((paramCLOB != null && (arrayOfByte = paramCLOB.shareBytes()) != null), 54);
/*      */ 
/*      */     
/* 3348 */     boolean[] arrayOfBoolean = new boolean[1];
/*      */     
/* 3350 */     checkError(t2cLobIsTemporary(this.m_nativeState, 112, arrayOfByte, arrayOfByte.length, arrayOfBoolean));
/*      */ 
/*      */     
/* 3353 */     return arrayOfBoolean[0];
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void open(CLOB paramCLOB, int paramInt) throws SQLException {
/* 3366 */     byte[] arrayOfByte = null;
/*      */     
/* 3368 */     checkTrue((this.lifecycle == 1), 8);
/* 3369 */     checkTrue((paramCLOB != null && (arrayOfByte = paramCLOB.shareBytes()) != null), 54);
/*      */ 
/*      */     
/* 3372 */     byte[][] arrayOfByte1 = new byte[1][];
/*      */     
/* 3374 */     checkError(t2cLobOpen(this.m_nativeState, 112, arrayOfByte, arrayOfByte.length, paramInt, arrayOfByte1));
/*      */ 
/*      */     
/* 3377 */     paramCLOB.setShareBytes(arrayOfByte1[0]);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void close(CLOB paramCLOB) throws SQLException {
/* 3390 */     byte[] arrayOfByte = null;
/*      */     
/* 3392 */     checkTrue((this.lifecycle == 1), 8);
/* 3393 */     checkTrue((paramCLOB != null && (arrayOfByte = paramCLOB.shareBytes()) != null), 54);
/*      */ 
/*      */     
/* 3396 */     byte[][] arrayOfByte1 = new byte[1][];
/*      */     
/* 3398 */     checkError(t2cLobClose(this.m_nativeState, 112, arrayOfByte, arrayOfByte.length, arrayOfByte1));
/*      */ 
/*      */     
/* 3401 */     paramCLOB.setShareBytes(arrayOfByte1[0]);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized boolean isOpen(CLOB paramCLOB) throws SQLException {
/* 3415 */     byte[] arrayOfByte = null;
/*      */     
/* 3417 */     checkTrue((this.lifecycle == 1), 8);
/* 3418 */     checkTrue((paramCLOB != null && (arrayOfByte = paramCLOB.shareBytes()) != null), 54);
/*      */ 
/*      */     
/* 3421 */     boolean[] arrayOfBoolean = new boolean[1];
/*      */     
/* 3423 */     checkError(t2cLobIsOpen(this.m_nativeState, 112, arrayOfByte, arrayOfByte.length, arrayOfBoolean));
/*      */ 
/*      */     
/* 3426 */     return arrayOfBoolean[0];
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public InputStream newInputStream(CLOB paramCLOB, int paramInt, long paramLong) throws SQLException {
/* 3445 */     return newInputStream((OracleClob)paramCLOB, paramInt, paramLong);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public InputStream newInputStream(OracleClob paramOracleClob, int paramInt, long paramLong) throws SQLException {
/* 3465 */     if (paramLong == 0L)
/*      */     {
/* 3467 */       return new OracleClobInputStream(paramOracleClob, paramInt);
/*      */     }
/*      */ 
/*      */     
/* 3471 */     return new OracleClobInputStream(paramOracleClob, paramInt, paramLong);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public OutputStream newOutputStream(CLOB paramCLOB, int paramInt, long paramLong, boolean paramBoolean) throws SQLException {
/* 3492 */     return newOutputStream((OracleClob)paramCLOB, paramInt, paramLong, paramBoolean);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public OutputStream newOutputStream(OracleClob paramOracleClob, int paramInt, long paramLong, boolean paramBoolean) throws SQLException {
/* 3512 */     if (paramLong == 0L) {
/*      */       
/* 3514 */       if (paramBoolean & this.lobStreamPosStandardCompliant) {
/*      */ 
/*      */         
/* 3517 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/* 3518 */         sQLException.fillInStackTrace();
/* 3519 */         throw sQLException;
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/* 3524 */       return new OracleClobOutputStream(paramOracleClob, paramInt);
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 3529 */     return new OracleClobOutputStream(paramOracleClob, paramInt, paramLong);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Reader newReader(CLOB paramCLOB, int paramInt, long paramLong) throws SQLException {
/* 3548 */     return newReader((OracleClob)paramCLOB, paramInt, paramLong);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Reader newReader(OracleClob paramOracleClob, int paramInt, long paramLong) throws SQLException {
/* 3566 */     if (paramLong == 0L)
/*      */     {
/* 3568 */       return new OracleClobReader(paramOracleClob, paramInt);
/*      */     }
/*      */ 
/*      */     
/* 3572 */     return new OracleClobReader(paramOracleClob, paramInt, paramLong);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Reader newReader(CLOB paramCLOB, int paramInt, long paramLong1, long paramLong2) throws SQLException {
/* 3592 */     return newReader((OracleClob)paramCLOB, paramInt, paramLong1, paramLong2);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Reader newReader(OracleClob paramOracleClob, int paramInt, long paramLong1, long paramLong2) throws SQLException {
/* 3611 */     return new OracleClobReader(paramOracleClob, paramInt, paramLong1, paramLong2);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Writer newWriter(CLOB paramCLOB, int paramInt, long paramLong, boolean paramBoolean) throws SQLException {
/* 3631 */     return newWriter((OracleClob)paramCLOB, paramInt, paramLong, paramBoolean);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Writer newWriter(OracleClob paramOracleClob, int paramInt, long paramLong, boolean paramBoolean) throws SQLException {
/* 3650 */     if (paramLong == 0L) {
/*      */       
/* 3652 */       if (paramBoolean & this.lobStreamPosStandardCompliant) {
/*      */ 
/*      */         
/* 3655 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/* 3656 */         sQLException.fillInStackTrace();
/* 3657 */         throw sQLException;
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/* 3662 */       return new OracleClobWriter(paramOracleClob, paramInt);
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 3667 */     return new OracleClobWriter(paramOracleClob, paramInt, paramLong);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void registerTAFCallback(OracleOCIFailover paramOracleOCIFailover, Object paramObject) throws SQLException {
/* 3694 */     this.appCallback = paramOracleOCIFailover;
/* 3695 */     this.appCallbackObject = paramObject;
/*      */     
/* 3697 */     checkError(t2cRegisterTAFCallback(this.m_nativeState));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   synchronized int callTAFCallbackMethod(int paramInt1, int paramInt2) {
/* 3707 */     int i = 0;
/*      */ 
/*      */     
/* 3710 */     if (this.appCallback != null) {
/* 3711 */       i = this.appCallback.callbackFn((Connection)this, this.appCallbackObject, paramInt1, paramInt2);
/*      */     }
/* 3713 */     return i;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getHeapAllocSize() throws SQLException {
/* 3727 */     if (this.lifecycle != 1) {
/*      */       
/* 3729 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 8);
/* 3730 */       sQLException.fillInStackTrace();
/* 3731 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 3736 */     int i = t2cGetHeapAllocSize(this.m_nativeState);
/*      */     
/* 3738 */     if (i < 0) {
/*      */       
/* 3740 */       if (i == -999) {
/*      */         
/* 3742 */         SQLException sQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 23);
/* 3743 */         sQLException1.fillInStackTrace();
/* 3744 */         throw sQLException1;
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 3750 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 89);
/* 3751 */       sQLException.fillInStackTrace();
/* 3752 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/* 3756 */     return i;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getOCIEnvHeapAllocSize() throws SQLException {
/* 3769 */     if (this.lifecycle != 1) {
/*      */       
/* 3771 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 8);
/* 3772 */       sQLException.fillInStackTrace();
/* 3773 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 3778 */     int i = t2cGetOciEnvHeapAllocSize(this.m_nativeState);
/*      */     
/* 3780 */     if (i < 0) {
/*      */       
/* 3782 */       if (i == -999) {
/*      */         
/* 3784 */         SQLException sQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 23);
/* 3785 */         sQLException1.fillInStackTrace();
/* 3786 */         throw sQLException1;
/*      */       } 
/*      */       
/* 3789 */       checkError(i);
/*      */ 
/*      */ 
/*      */       
/* 3793 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 89);
/* 3794 */       sQLException.fillInStackTrace();
/* 3795 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/* 3799 */     return i;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final short getClientCharSetId() {
/* 3808 */     return 871;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static short getDriverCharSetIdFromNLS_LANG(String paramString) throws SQLException {
/* 3824 */     if (!isLibraryLoaded) {
/* 3825 */       loadNativeLibrary(paramString);
/*      */     }
/*      */     
/* 3828 */     short s = t2cGetDriverCharSetFromNlsLang();
/*      */ 
/*      */     
/* 3831 */     if (s < 0) {
/*      */       
/* 3833 */       SQLException sQLException = DatabaseError.createSqlException((OracleConnection)null, 8);
/* 3834 */       sQLException.fillInStackTrace();
/* 3835 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/* 3839 */     return s;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void doProxySession(int paramInt, Properties paramProperties) throws SQLException {
/*      */     String str1, str2;
/*      */     Object object;
/* 3852 */     byte[][] arrayOfByte = (byte[][])null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 3858 */     int i = 0;
/*      */     
/* 3860 */     this.savedUser = this.userName;
/* 3861 */     this.userName = null;
/*      */     
/* 3863 */     byte[] arrayOfByte4 = new byte[0], arrayOfByte3 = arrayOfByte4, arrayOfByte2 = arrayOfByte3, arrayOfByte1 = arrayOfByte2;
/*      */     
/* 3865 */     switch (paramInt) {
/*      */       
/*      */       case 1:
/* 3868 */         this.userName = paramProperties.getProperty("PROXY_USER_NAME");
/* 3869 */         str1 = paramProperties.getProperty("PROXY_USER_PASSWORD");
/* 3870 */         if (this.userName != null) {
/* 3871 */           arrayOfByte1 = DBConversion.stringToDriverCharBytes(this.userName, this.m_clientCharacterSet);
/*      */         }
/* 3873 */         if (str1 != null)
/* 3874 */           arrayOfByte2 = DBConversion.stringToDriverCharBytes(str1, this.m_clientCharacterSet); 
/*      */         break;
/*      */       case 2:
/* 3877 */         str2 = paramProperties.getProperty("PROXY_DISTINGUISHED_NAME");
/* 3878 */         if (str2 != null) {
/* 3879 */           arrayOfByte3 = DBConversion.stringToDriverCharBytes(str2, this.m_clientCharacterSet);
/*      */         }
/*      */         break;
/*      */       case 3:
/* 3883 */         object = paramProperties.get("PROXY_CERTIFICATE");
/* 3884 */         arrayOfByte4 = (byte[])object;
/*      */         break;
/*      */     } 
/* 3887 */     String[] arrayOfString = (String[])paramProperties.get("PROXY_ROLES");
/*      */     
/* 3889 */     if (arrayOfString != null) {
/*      */       
/* 3891 */       i = arrayOfString.length;
/* 3892 */       arrayOfByte = new byte[i][];
/* 3893 */       for (byte b = 0; b < i; b++) {
/*      */         
/* 3895 */         if (arrayOfString[b] == null) {
/*      */           
/* 3897 */           SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 150);
/* 3898 */           sQLException.fillInStackTrace();
/* 3899 */           throw sQLException;
/*      */         } 
/*      */         
/* 3902 */         arrayOfByte[b] = DBConversion.stringToDriverCharBytes(arrayOfString[b], this.m_clientCharacterSet);
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/* 3907 */     this.sqlWarning = checkError(t2cDoProxySession(this.m_nativeState, paramInt, arrayOfByte1, arrayOfByte1.length, arrayOfByte2, arrayOfByte2.length, arrayOfByte3, arrayOfByte3.length, arrayOfByte4, arrayOfByte4.length, i, arrayOfByte), this.sqlWarning);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 3921 */     this.isProxy = true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void closeProxySession() throws SQLException {
/* 3928 */     checkError(t2cCloseProxySession(this.m_nativeState));
/* 3929 */     this.userName = this.savedUser;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected void doDescribeTable(AutoKeyInfo paramAutoKeyInfo) throws SQLException {
/*      */     boolean bool;
/*      */     int i;
/* 3937 */     String str = paramAutoKeyInfo.getTableName();
/*      */     
/* 3939 */     byte[] arrayOfByte = DBConversion.stringToDriverCharBytes(str, this.m_clientCharacterSet);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     do {
/* 3947 */       bool = false;
/* 3948 */       i = t2cDescribeTable(this.m_nativeState, arrayOfByte, arrayOfByte.length, this.queryMetaData1, this.queryMetaData2, this.queryMetaData1Offset, this.queryMetaData2Offset, this.queryMetaData1Size, this.queryMetaData2Size);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 3958 */       if (i == -1)
/*      */       {
/* 3960 */         checkError(i);
/*      */       }
/*      */ 
/*      */       
/* 3964 */       if (i != T2CStatement.T2C_EXTEND_BUFFER)
/*      */         continue; 
/* 3966 */       bool = true;
/*      */       
/* 3968 */       reallocateQueryMetaData(this.queryMetaData1Size * 2, this.queryMetaData2Size * 2);
/*      */     
/*      */     }
/* 3971 */     while (bool);
/*      */     
/* 3973 */     processDescribeTableData(i, paramAutoKeyInfo);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void processDescribeTableData(int paramInt, AutoKeyInfo paramAutoKeyInfo) throws SQLException {
/* 3982 */     short[] arrayOfShort = this.queryMetaData1;
/* 3983 */     byte[] arrayOfByte = this.queryMetaData2;
/* 3984 */     int i = this.queryMetaData1Offset;
/* 3985 */     int j = this.queryMetaData2Offset;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 4000 */     paramAutoKeyInfo.allocateSpaceForDescribedData(paramInt);
/*      */     
/* 4002 */     for (byte b = 0; b < paramInt; b++) {
/*      */       
/* 4004 */       short s2 = arrayOfShort[i + 0];
/* 4005 */       short s1 = arrayOfShort[i + 6];
/* 4006 */       String str1 = bytes2String(arrayOfByte, j, s1, this.conversion);
/*      */ 
/*      */       
/* 4009 */       short s3 = arrayOfShort[i + 1];
/* 4010 */       short s4 = arrayOfShort[i + 11];
/* 4011 */       boolean bool1 = (arrayOfShort[i + 2] != 0) ? true : false;
/* 4012 */       short s5 = arrayOfShort[i + 5];
/* 4013 */       short s6 = arrayOfShort[i + 3];
/* 4014 */       short s7 = arrayOfShort[i + 4];
/* 4015 */       short s8 = arrayOfShort[i + 12];
/* 4016 */       boolean bool2 = (arrayOfShort[i + 13] != 0) ? true : false;
/*      */       
/* 4018 */       j += s1;
/* 4019 */       i += 14;
/*      */       
/* 4021 */       String str2 = null;
/* 4022 */       if (s8 > 0) {
/*      */         
/* 4024 */         str2 = bytes2String(arrayOfByte, j, s8, this.conversion);
/*      */         
/* 4026 */         j += s8;
/*      */       } 
/*      */ 
/*      */       
/* 4030 */       paramAutoKeyInfo.fillDescribedData(b, str1, s2, (s4 > 0) ? s4 : s3, bool1, s5, s6, s7, str2);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void doSetApplicationContext(String paramString1, String paramString2, String paramString3) throws SQLException {
/* 4044 */     checkError(t2cSetApplicationContext(this.m_nativeState, paramString1, paramString2, paramString3));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void doClearAllApplicationContext(String paramString) throws SQLException {
/* 4053 */     checkError(t2cClearAllApplicationContext(this.m_nativeState, paramString));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void doStartup(int paramInt) throws SQLException {
/* 4061 */     checkError(t2cStartupDatabase(this.m_nativeState, paramInt));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void doShutdown(int paramInt) throws SQLException {
/* 4069 */     checkError(t2cShutdownDatabase(this.m_nativeState, paramInt));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static final void loadNativeLibrary(String paramString) throws SQLException {
/* 4081 */     if (paramString == null || paramString.equals("ocijdbc12")) {
/*      */       
/* 4083 */       synchronized (T2CConnection.class)
/*      */       {
/* 4085 */         if (!isLibraryLoaded)
/*      */         {
/* 4087 */           AccessController.doPrivileged(new PrivilegedAction()
/*      */               {
/*      */                 public Object run()
/*      */                 {
/* 4091 */                   System.loadLibrary("ocijdbc12");
/* 4092 */                   int i = T2CConnection.getLibraryVersionNumber();
/* 4093 */                   if (i != T2CConnection.JDBC_OCI_LIBRARY_VERSION) {
/* 4094 */                     throw new Error("Incompatible version of libocijdbc[Jdbc:" + T2CConnection.JDBC_OCI_LIBRARY_VERSION + ", Jdbc-OCI:" + i);
/*      */                   }
/*      */                   
/* 4097 */                   return null;
/*      */                 }
/*      */               });
/* 4100 */           isLibraryLoaded = true;
/*      */         }
/*      */       
/*      */       }
/*      */     
/*      */     } else {
/*      */       
/* 4107 */       synchronized (T2CConnection.class) {
/*      */ 
/*      */         
/*      */         try {
/* 4111 */           System.loadLibrary(paramString);
/* 4112 */           isLibraryLoaded = true;
/*      */         }
/* 4114 */         catch (SecurityException securityException) {
/*      */           
/* 4116 */           if (!isLibraryLoaded) {
/*      */             
/* 4118 */             System.loadLibrary(paramString);
/* 4119 */             isLibraryLoaded = true;
/*      */           } 
/*      */         } 
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final void checkTrue(boolean paramBoolean, int paramInt) throws SQLException {
/* 4132 */     if (!paramBoolean) {
/*      */       
/* 4134 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), paramInt);
/* 4135 */       sQLException.fillInStackTrace();
/* 4136 */       throw sQLException;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   boolean useLittleEndianSetCHARBinder() throws SQLException {
/* 4144 */     return t2cPlatformIsLittleEndian(this.m_nativeState);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void getPropertyForPooledConnection(OraclePooledConnection paramOraclePooledConnection) throws SQLException {
/* 4152 */     getPropertyForPooledConnection(paramOraclePooledConnection, this.password);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static final char[] getCharArray(String paramString) {
/* 4159 */     char[] arrayOfChar = null;
/*      */     
/* 4161 */     if (paramString == null) {
/*      */       
/* 4163 */       arrayOfChar = new char[0];
/*      */     }
/*      */     else {
/*      */       
/* 4167 */       arrayOfChar = new char[paramString.length()];
/*      */       
/* 4169 */       paramString.getChars(0, paramString.length(), arrayOfChar, 0);
/*      */     } 
/*      */     
/* 4172 */     return arrayOfChar;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static String bytes2String(byte[] paramArrayOfbyte, int paramInt1, int paramInt2, DBConversion paramDBConversion) throws SQLException {
/* 4182 */     byte[] arrayOfByte = new byte[paramInt2];
/* 4183 */     System.arraycopy(paramArrayOfbyte, paramInt1, arrayOfByte, 0, paramInt2);
/*      */     
/* 4185 */     return paramDBConversion.CharBytesToString(arrayOfByte, paramInt2);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void disableNio() {
/* 4193 */     this.useNio = false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static synchronized void doSetSessionTimeZone(String paramString) throws SQLException {
/* 4201 */     t2cSetSessionTimeZone(paramString);
/*      */   }
/*      */ 
/*      */   
/*      */   public void incrementTempLobReferenceCount(byte[] paramArrayOfbyte) throws SQLException {}
/*      */ 
/*      */   
/*      */   public int decrementTempLobReferenceCount(byte[] paramArrayOfbyte) throws SQLException {
/* 4209 */     return 0;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void releaseConnectionToPool() throws SQLException {
/* 4217 */     if (!this.drcpEnabled || this.drcpState != PhysicalConnection.DrcpState.STATEFUL) {
/*      */       return;
/*      */     }
/* 4220 */     this.drcpState = PhysicalConnection.DrcpState.STATELESS;
/*      */     
/* 4222 */     byte b = 0;
/* 4223 */     byte[] arrayOfByte = EMPTY_BYTES;
/* 4224 */     if (this.drcpTagName != null) {
/*      */       
/* 4226 */       this.tagMatched[0] = false;
/* 4227 */       arrayOfByte = DBConversion.stringToDriverCharBytes(this.drcpTagName, this.m_clientCharacterSet);
/*      */       
/* 4229 */       b = 2;
/*      */     } else {
/*      */       
/* 4232 */       this.tagMatched[0] = true;
/*      */     } 
/*      */ 
/*      */     
/* 4236 */     checkError(t2cCloseDrcpConnection(this.m_nativeState, arrayOfByte, arrayOfByte.length, b), this.sqlWarning);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   boolean reusePooledConnection() throws SQLException {
/* 4245 */     if (this.drcpState != PhysicalConnection.DrcpState.STATEFUL) {
/* 4246 */       this.drcpState = PhysicalConnection.DrcpState.STATEFUL;
/* 4247 */       byte[] arrayOfByte = EMPTY_BYTES;
/*      */       
/* 4249 */       if (this.drcpTagName != null) {
/* 4250 */         arrayOfByte = DBConversion.stringToDriverCharBytes(this.drcpTagName, this.m_clientCharacterSet);
/*      */       }
/*      */       
/* 4253 */       checkError(t2cOpenDrcpConnection(this.m_nativeState, arrayOfByte, arrayOfByte.length, this.tagMatched), this.sqlWarning);
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 4259 */     return this.tagMatched[0];
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean needToPurgeStatementCache() throws SQLException {
/* 4274 */     if (this.lifecycle != 1) {
/*      */       
/* 4276 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 8);
/* 4277 */       sQLException.fillInStackTrace();
/* 4278 */       throw sQLException;
/*      */     } 
/*      */     
/* 4281 */     if (!this.drcpEnabled) return true; 
/* 4282 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getCurrentSchema() throws SQLException {
/* 4296 */     if (this.lifecycle != 1) {
/*      */       
/* 4298 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 8);
/* 4299 */       sQLException.fillInStackTrace();
/* 4300 */       throw sQLException;
/*      */     } 
/*      */     
/* 4303 */     byte[] arrayOfByte = new byte[258];
/*      */     
/*      */     int i;
/* 4306 */     checkError(i = t2cGetSchemaName(this.m_nativeState, arrayOfByte));
/*      */     
/* 4308 */     if (i > 0) {
/* 4309 */       return this.conversion.CharBytesToString(arrayOfByte, i);
/*      */     }
/* 4311 */     return this.userName;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 4499 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*      */   public static final String BUILD_DATE = "Thu_Apr_04_15:09:24_PDT_2013";
/*      */   public static final boolean TRACE = false;
/*      */   
/*      */   native int t2cAbort(long paramLong);
/*      */   
/*      */   native int t2cBlobRead(long paramLong1, byte[] paramArrayOfbyte1, int paramInt1, long paramLong2, int paramInt2, byte[] paramArrayOfbyte2, int paramInt3, boolean paramBoolean, ByteBuffer paramByteBuffer);
/*      */   
/*      */   native int t2cClobRead(long paramLong1, byte[] paramArrayOfbyte, int paramInt1, long paramLong2, int paramInt2, char[] paramArrayOfchar, int paramInt3, boolean paramBoolean1, boolean paramBoolean2, ByteBuffer paramByteBuffer);
/*      */   
/*      */   native int t2cBlobWrite(long paramLong1, byte[] paramArrayOfbyte1, int paramInt1, long paramLong2, int paramInt2, byte[] paramArrayOfbyte2, int paramInt3, byte[][] paramArrayOfbyte);
/*      */   
/*      */   native int t2cClobWrite(long paramLong1, byte[] paramArrayOfbyte, int paramInt1, long paramLong2, int paramInt2, char[] paramArrayOfchar, int paramInt3, byte[][] paramArrayOfbyte1, boolean paramBoolean);
/*      */   
/*      */   native long t2cLobGetLength(long paramLong, byte[] paramArrayOfbyte, int paramInt);
/*      */   
/*      */   native int t2cBfileOpen(long paramLong, byte[] paramArrayOfbyte, int paramInt, byte[][] paramArrayOfbyte1);
/*      */   
/*      */   native int t2cBfileIsOpen(long paramLong, byte[] paramArrayOfbyte, int paramInt, boolean[] paramArrayOfboolean);
/*      */   
/*      */   native int t2cBfileExists(long paramLong, byte[] paramArrayOfbyte, int paramInt, boolean[] paramArrayOfboolean);
/*      */   
/*      */   native String t2cBfileGetName(long paramLong, byte[] paramArrayOfbyte, int paramInt);
/*      */   
/*      */   native String t2cBfileGetDirAlias(long paramLong, byte[] paramArrayOfbyte, int paramInt);
/*      */   
/*      */   native int t2cBfileClose(long paramLong, byte[] paramArrayOfbyte, int paramInt, byte[][] paramArrayOfbyte1);
/*      */   
/*      */   native int t2cLobGetChunkSize(long paramLong, byte[] paramArrayOfbyte, int paramInt);
/*      */   
/*      */   native int t2cLobTrim(long paramLong1, int paramInt1, long paramLong2, byte[] paramArrayOfbyte, int paramInt2, byte[][] paramArrayOfbyte1);
/*      */   
/*      */   native int t2cLobCreateTemporary(long paramLong, int paramInt1, boolean paramBoolean, int paramInt2, short paramShort, byte[][] paramArrayOfbyte);
/*      */   
/*      */   native int t2cLobFreeTemporary(long paramLong, int paramInt1, byte[] paramArrayOfbyte, int paramInt2, byte[][] paramArrayOfbyte1);
/*      */   
/*      */   native int t2cLobIsTemporary(long paramLong, int paramInt1, byte[] paramArrayOfbyte, int paramInt2, boolean[] paramArrayOfboolean);
/*      */   
/*      */   native int t2cLobOpen(long paramLong, int paramInt1, byte[] paramArrayOfbyte, int paramInt2, int paramInt3, byte[][] paramArrayOfbyte1);
/*      */   
/*      */   native int t2cLobIsOpen(long paramLong, int paramInt1, byte[] paramArrayOfbyte, int paramInt2, boolean[] paramArrayOfboolean);
/*      */   
/*      */   native int t2cLobClose(long paramLong, int paramInt1, byte[] paramArrayOfbyte, int paramInt2, byte[][] paramArrayOfbyte1);
/*      */   
/*      */   static native int getLibraryVersionNumber();
/*      */   
/*      */   static native short t2cGetServerSessionInfo(long paramLong, Properties paramProperties);
/*      */   
/*      */   static native short t2cGetDriverCharSetFromNlsLang();
/*      */   
/*      */   native int t2cDescribeError(long paramLong, T2CError paramT2CError, byte[] paramArrayOfbyte);
/*      */   
/*      */   native int t2cCreateState(byte[] paramArrayOfbyte1, int paramInt1, byte[] paramArrayOfbyte2, int paramInt2, byte[] paramArrayOfbyte3, int paramInt3, byte[] paramArrayOfbyte4, int paramInt4, byte[] paramArrayOfbyte5, int paramInt5, byte[] paramArrayOfbyte6, int paramInt6, byte[] paramArrayOfbyte7, int paramInt7, byte[] paramArrayOfbyte8, int paramInt8, byte[] paramArrayOfbyte9, int paramInt9, short paramShort, int paramInt10, byte[] paramArrayOfbyte10, byte[] paramArrayOfbyte11, byte[] paramArrayOfbyte12, long[] paramArrayOflong);
/*      */   
/*      */   native int t2cLogon(long paramLong, byte[] paramArrayOfbyte1, int paramInt1, byte[] paramArrayOfbyte2, int paramInt2, byte[] paramArrayOfbyte3, int paramInt3, byte[] paramArrayOfbyte4, int paramInt4, byte[] paramArrayOfbyte5, int paramInt5, byte[] paramArrayOfbyte6, int paramInt6, byte[] paramArrayOfbyte7, int paramInt7, byte[] paramArrayOfbyte8, int paramInt8, byte[] paramArrayOfbyte9, int paramInt9, int paramInt10, byte[] paramArrayOfbyte10, byte[] paramArrayOfbyte11, byte[] paramArrayOfbyte12, long[] paramArrayOflong);
/*      */   
/*      */   private native int t2cLogoff(long paramLong);
/*      */   
/*      */   private native int t2cCancel(long paramLong);
/*      */   
/*      */   private native byte t2cGetAsmVolProperty(long paramLong);
/*      */   
/*      */   private native byte t2cGetInstanceType(long paramLong);
/*      */   
/*      */   private native int t2cCreateStatement(long paramLong1, long paramLong2, byte[] paramArrayOfbyte, int paramInt1, OracleStatement paramOracleStatement, boolean paramBoolean, int paramInt2);
/*      */   
/*      */   private native int t2cSetAutoCommit(long paramLong, boolean paramBoolean);
/*      */   
/*      */   private native int t2cCommit(long paramLong, int paramInt);
/*      */   
/*      */   private native int t2cRollback(long paramLong);
/*      */   
/*      */   private native int t2cPingDatabase(long paramLong);
/*      */   
/*      */   private native byte[] t2cGetProductionVersion(long paramLong);
/*      */   
/*      */   private native int t2cGetVersionNumber(long paramLong);
/*      */   
/*      */   private native int t2cGetDefaultStreamChunkSize(long paramLong);
/*      */   
/*      */   native int t2cGetFormOfUse(long paramLong, OracleTypeCLOB paramOracleTypeCLOB, byte[] paramArrayOfbyte, int paramInt1, int paramInt2);
/*      */   
/*      */   native long t2cGetTDO(long paramLong, byte[] paramArrayOfbyte, int paramInt, int[] paramArrayOfint);
/*      */   
/*      */   native int t2cCreateConnPool(byte[] paramArrayOfbyte1, int paramInt1, byte[] paramArrayOfbyte2, int paramInt2, byte[] paramArrayOfbyte3, int paramInt3, short paramShort, int paramInt4, int paramInt5, int paramInt6, int paramInt7, int paramInt8, int paramInt9, int paramInt10);
/*      */   
/*      */   native int t2cConnPoolLogon(long paramLong, byte[] paramArrayOfbyte1, int paramInt1, byte[] paramArrayOfbyte2, int paramInt2, byte[] paramArrayOfbyte3, int paramInt3, byte[] paramArrayOfbyte4, int paramInt4, byte[] paramArrayOfbyte5, int paramInt5, int paramInt6, int paramInt7, int paramInt8, String[] paramArrayOfString, byte[] paramArrayOfbyte6, int paramInt9, byte[] paramArrayOfbyte7, int paramInt10, byte[] paramArrayOfbyte8, int paramInt11, byte[] paramArrayOfbyte9, int paramInt12, byte[] paramArrayOfbyte10, int paramInt13, byte[] paramArrayOfbyte11, byte[] paramArrayOfbyte12, long[] paramArrayOflong);
/*      */   
/*      */   native int t2cGetConnPoolInfo(long paramLong, Properties paramProperties);
/*      */   
/*      */   native int t2cSetConnPoolInfo(long paramLong, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6);
/*      */   
/*      */   native int t2cPasswordChange(long paramLong, byte[] paramArrayOfbyte1, int paramInt1, byte[] paramArrayOfbyte2, int paramInt2, byte[] paramArrayOfbyte3, int paramInt3);
/*      */   
/*      */   protected native byte[] t2cGetConnectionId(long paramLong);
/*      */   
/*      */   native int t2cGetHandles(long paramLong, long[] paramArrayOflong);
/*      */   
/*      */   native int t2cUseConnection(long paramLong1, long paramLong2, long paramLong3, long paramLong4, byte[] paramArrayOfbyte, long[] paramArrayOflong);
/*      */   
/*      */   native boolean t2cPlatformIsLittleEndian(long paramLong);
/*      */   
/*      */   native int t2cRegisterTAFCallback(long paramLong);
/*      */   
/*      */   native int t2cGetHeapAllocSize(long paramLong);
/*      */   
/*      */   native int t2cGetOciEnvHeapAllocSize(long paramLong);
/*      */   
/*      */   native int t2cDoProxySession(long paramLong, int paramInt1, byte[] paramArrayOfbyte1, int paramInt2, byte[] paramArrayOfbyte2, int paramInt3, byte[] paramArrayOfbyte3, int paramInt4, byte[] paramArrayOfbyte4, int paramInt5, int paramInt6, byte[][] paramArrayOfbyte);
/*      */   
/*      */   native int t2cCloseProxySession(long paramLong);
/*      */   
/*      */   static native int t2cDescribeTable(long paramLong, byte[] paramArrayOfbyte1, int paramInt1, short[] paramArrayOfshort, byte[] paramArrayOfbyte2, int paramInt2, int paramInt3, int paramInt4, int paramInt5);
/*      */   
/*      */   native int t2cSetApplicationContext(long paramLong, String paramString1, String paramString2, String paramString3);
/*      */   
/*      */   native int t2cClearAllApplicationContext(long paramLong, String paramString);
/*      */   
/*      */   native int t2cStartupDatabase(long paramLong, int paramInt);
/*      */   
/*      */   native int t2cShutdownDatabase(long paramLong, int paramInt);
/*      */   
/*      */   static native void t2cSetSessionTimeZone(String paramString);
/*      */   
/*      */   native int t2cCloseDrcpConnection(long paramLong, byte[] paramArrayOfbyte, int paramInt1, int paramInt2);
/*      */   
/*      */   native int t2cOpenDrcpConnection(long paramLong, byte[] paramArrayOfbyte, int paramInt, boolean[] paramArrayOfboolean);
/*      */   
/*      */   native int t2cSetCachedServerVersion(long paramLong, short paramShort);
/*      */   
/*      */   native int t2cGetImplicitResultSetStatement(long paramLong1, long paramLong2, OracleStatement paramOracleStatement);
/*      */   
/*      */   native int t2cGetSchemaName(long paramLong, byte[] paramArrayOfbyte);
/*      */ }


/* Location:              C:\Users\olatu\OneDrive\Documents\Calypso\syncbase\sync_base.jar!\BOOT-INF\lib\ojdbc-7.jar!\oracle\jdbc\driver\T2CConnection.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */