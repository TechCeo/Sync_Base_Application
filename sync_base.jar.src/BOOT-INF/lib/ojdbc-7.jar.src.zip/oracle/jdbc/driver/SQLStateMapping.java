/*     */ package oracle.jdbc.driver;
/*     */ 
/*     */ import java.io.BufferedReader;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.InputStreamReader;
/*     */ import java.io.Reader;
/*     */ import java.sql.SQLClientInfoException;
/*     */ import java.sql.SQLDataException;
/*     */ import java.sql.SQLException;
/*     */ import java.sql.SQLFeatureNotSupportedException;
/*     */ import java.sql.SQLIntegrityConstraintViolationException;
/*     */ import java.sql.SQLInvalidAuthorizationSpecException;
/*     */ import java.sql.SQLNonTransientConnectionException;
/*     */ import java.sql.SQLNonTransientException;
/*     */ import java.sql.SQLRecoverableException;
/*     */ import java.sql.SQLSyntaxErrorException;
/*     */ import java.sql.SQLTimeoutException;
/*     */ import java.sql.SQLTransactionRollbackException;
/*     */ import java.sql.SQLTransientConnectionException;
/*     */ import java.sql.SQLTransientException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ class SQLStateMapping
/*     */ {
/*     */   public static final int SQLEXCEPTION = 0;
/*     */   public static final int SQLNONTRANSIENTEXCEPTION = 1;
/*     */   public static final int SQLTRANSIENTEXCEPTION = 2;
/*     */   public static final int SQLDATAEXCEPTION = 3;
/*     */   public static final int SQLFEATURENOTSUPPORTEDEXCEPTION = 4;
/*     */   public static final int SQLINTEGRITYCONSTRAINTVIOLATIONEXCEPTION = 5;
/*     */   public static final int SQLINVALIDAUTHORIZATIONSPECEXCEPTION = 6;
/*     */   public static final int SQLNONTRANSIENTCONNECTIONEXCEPTION = 7;
/*     */   public static final int SQLSYNTAXERROREXCEPTION = 8;
/*     */   public static final int SQLTIMEOUTEXCEPTION = 9;
/*     */   public static final int SQLTRANSACTIONROLLBACKEXCEPTION = 10;
/*     */   public static final int SQLTRANSIENTCONNECTIONEXCEPTION = 11;
/*     */   public static final int SQLCLIENTINFOEXCEPTION = 12;
/*     */   public static final int SQLRECOVERABLEEXCEPTION = 13;
/*     */   int low;
/*     */   int high;
/*     */   public String sqlState;
/*     */   public int exception;
/*     */   static final String mappingResource = "errorMap.xml";
/*     */   static SQLStateMapping[] all;
/*     */   private static final int NUMEBER_OF_MAPPINGS_IN_ERRORMAP_XML = 128;
/*     */   
/*     */   public SQLStateMapping(int paramInt1, int paramInt2, String paramString, int paramInt3) {
/*  52 */     this.low = paramInt1;
/*  53 */     this.sqlState = paramString;
/*  54 */     this.exception = paramInt3;
/*  55 */     this.high = paramInt2;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isIncluded(int paramInt) {
/*  61 */     return (this.low <= paramInt && paramInt <= this.high);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public SQLException newSQLException(String paramString, int paramInt) {
/*  67 */     switch (this.exception) {
/*     */       case 0:
/*  69 */         return new SQLException(paramString, this.sqlState, paramInt);
/*     */       case 1:
/*  71 */         return new SQLNonTransientException(paramString, this.sqlState, paramInt);
/*     */       case 2:
/*  73 */         return new SQLTransientException(paramString, this.sqlState, paramInt);
/*     */       case 3:
/*  75 */         return new SQLDataException(paramString, this.sqlState, paramInt);
/*     */       case 4:
/*  77 */         return new SQLFeatureNotSupportedException(paramString, this.sqlState, paramInt);
/*     */       case 5:
/*  79 */         return new SQLIntegrityConstraintViolationException(paramString, this.sqlState, paramInt);
/*     */       case 6:
/*  81 */         return new SQLInvalidAuthorizationSpecException(paramString, this.sqlState, paramInt);
/*     */       case 7:
/*  83 */         return new SQLNonTransientConnectionException(paramString, this.sqlState, paramInt);
/*     */       case 8:
/*  85 */         return new SQLSyntaxErrorException(paramString, this.sqlState, paramInt);
/*     */       case 9:
/*  87 */         return new SQLTimeoutException(paramString, this.sqlState, paramInt);
/*     */       case 10:
/*  89 */         return new SQLTransactionRollbackException(paramString, this.sqlState, paramInt);
/*     */       case 11:
/*  91 */         return new SQLTransientConnectionException(paramString, this.sqlState, paramInt);
/*     */       case 12:
/*  93 */         return new SQLClientInfoException(paramString, this.sqlState, paramInt, null);
/*     */       case 13:
/*  95 */         return new SQLRecoverableException(paramString, this.sqlState, paramInt);
/*  96 */     }  return new SQLException(paramString, this.sqlState, paramInt);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   boolean lessThan(SQLStateMapping paramSQLStateMapping) {
/* 102 */     if (this.low < paramSQLStateMapping.low) {
/* 103 */       return (this.high < paramSQLStateMapping.high);
/*     */     }
/*     */     
/* 106 */     return (this.high <= paramSQLStateMapping.high);
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 111 */     return super.toString() + "(" + this.low + ", " + this.high + ", " + this.sqlState + ", " + this.exception + ")";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void main(String[] paramArrayOfString) throws IOException {
/* 118 */     SQLStateMapping[] arrayOfSQLStateMapping = doGetMappings();
/* 119 */     System.out.println("a\t" + arrayOfSQLStateMapping);
/* 120 */     for (byte b = 0; b < arrayOfSQLStateMapping.length; b++) {
/* 121 */       System.out.println("low:\t" + (arrayOfSQLStateMapping[b]).low + "\thigh:\t" + (arrayOfSQLStateMapping[b]).high + "\tsqlState:\t" + (arrayOfSQLStateMapping[b]).sqlState + "\tsqlException:\t" + (arrayOfSQLStateMapping[b]).exception);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static SQLStateMapping[] getMappings() {
/* 131 */     if (all == null) {
/*     */       try {
/* 133 */         all = doGetMappings();
/*     */       }
/* 135 */       catch (Throwable throwable) {
/*     */         
/* 137 */         all = new SQLStateMapping[0];
/*     */       } 
/*     */     }
/* 140 */     return all;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static SQLStateMapping[] doGetMappings() throws IOException {
/* 148 */     InputStream inputStream = SQLStateMapping.class.getResourceAsStream("errorMap.xml");
/* 149 */     ArrayList arrayList = new ArrayList(128);
/* 150 */     load(inputStream, arrayList);
/* 151 */     return (SQLStateMapping[])arrayList.toArray((Object[])new SQLStateMapping[0]);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static void load(InputStream paramInputStream, List paramList) throws IOException {
/* 173 */     BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(paramInputStream));
/* 174 */     Tokenizer tokenizer = new Tokenizer(bufferedReader);
/* 175 */     int i = -1;
/* 176 */     int j = -1;
/* 177 */     String str1 = null;
/* 178 */     int k = -1;
/* 179 */     String str2 = null;
/* 180 */     byte b = 0;
/*     */     String str3;
/* 182 */     while ((str3 = tokenizer.next()) != null) {
/* 183 */       switch (b) {
/*     */         case false:
/* 185 */           if (str3.equals("<")) b = 1; 
/*     */           continue;
/*     */         case true:
/* 188 */           if (str3.equals("!")) { b = 2; continue; }
/* 189 */            if (str3.equals("oraErrorSqlStateSqlExceptionMapping")) { b = 6; continue; }
/* 190 */            throw new IOException("Unexpected token \"" + str3 + "\" at line " + tokenizer.lineno + " of errorMap.xml. Expected \"oraErrorSqlStateSqlExceptionMapping\".");
/*     */ 
/*     */         
/*     */         case true:
/* 194 */           if (str3.equals("-")) { b = 3; continue; }
/* 195 */            throw new IOException("Unexpected token \"" + str3 + "\" at line " + tokenizer.lineno + " of errorMap.xml. Expected \"-\".");
/*     */ 
/*     */         
/*     */         case true:
/* 199 */           if (str3.equals("-")) b = 4; 
/*     */           continue;
/*     */         case true:
/* 202 */           if (str3.equals("-")) { b = 5; continue; }
/* 203 */            b = 3;
/*     */           continue;
/*     */         case true:
/* 206 */           if (str3.equals(">")) { b = 0; continue; }
/* 207 */            throw new IOException("Unexpected token \"" + str3 + "\" at line " + tokenizer.lineno + " of errorMap.xml. Expected \">\".");
/*     */ 
/*     */         
/*     */         case true:
/* 211 */           if (str3.equals(">")) { b = 7; continue; }
/* 212 */            throw new IOException("Unexpected token \"" + str3 + "\" at line " + tokenizer.lineno + " of errorMap.xml. Expected \">\".");
/*     */ 
/*     */         
/*     */         case true:
/* 216 */           if (str3.equals("<")) { b = 8; continue; }
/* 217 */            throw new IOException("Unexpected token \"" + str3 + "\" at line " + tokenizer.lineno + " of errorMap.xml. Expected \"<\".");
/*     */ 
/*     */         
/*     */         case true:
/* 221 */           if (str3.equals("!")) { b = 9; continue; }
/* 222 */            if (str3.equals("error")) { b = 14; continue; }
/* 223 */            if (str3.equals("/")) { b = 16; continue; }
/* 224 */            throw new IOException("Unexpected token \"" + str3 + "\" at line " + tokenizer.lineno + " of errorMap.xml. Expected one of \"!--\", \"error\", \"/\".");
/*     */ 
/*     */         
/*     */         case true:
/* 228 */           if (str3.equals("-")) { b = 10; continue; }
/* 229 */            throw new IOException("Unexpected token \"" + str3 + "\" at line " + tokenizer.lineno + " of errorMap.xml. Expected \"-\".");
/*     */ 
/*     */         
/*     */         case true:
/* 233 */           if (str3.equals("-")) { b = 11; continue; }
/* 234 */            throw new IOException("Unexpected token \"" + str3 + "\" at line " + tokenizer.lineno + " of errorMap.xml. Expected \"-\".");
/*     */ 
/*     */         
/*     */         case true:
/* 238 */           if (str3.equals("-")) b = 12; 
/*     */           continue;
/*     */         case true:
/* 241 */           if (str3.equals("-")) { b = 13; continue; }
/* 242 */            b = 11;
/*     */           continue;
/*     */         case true:
/* 245 */           if (str3.equals(">")) { b = 7; continue; }
/* 246 */            throw new IOException("Unexpected token \"" + str3 + "\" at line " + tokenizer.lineno + " of errorMap.xml. Expected \">\".");
/*     */ 
/*     */         
/*     */         case true:
/* 250 */           if (str3.equals("/")) { b = 15; continue; }
/* 251 */            if (str3.equals("oraErrorFrom")) { b = 19; continue; }
/* 252 */            if (str3.equals("oraErrorTo")) { b = 21; continue; }
/* 253 */            if (str3.equals("sqlState")) { b = 23; continue; }
/* 254 */            if (str3.equals("sqlException")) { b = 25; continue; }
/* 255 */            if (str3.equals("comment")) { b = 27; continue; }
/* 256 */            throw new IOException("Unexpected token \"" + str3 + "\" at line " + tokenizer.lineno + " of errorMap.xml. Expected one of " + "\"oraErrorFrom\", \"oraErrorTo\", \"sqlState\", " + "\"sqlException\", \"comment\", \"/\".");
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         case true:
/* 262 */           if (str3.equals(">")) {
/*     */             try {
/* 264 */               createOne(paramList, i, j, str1, k, str2);
/*     */             }
/* 266 */             catch (IOException iOException) {
/* 267 */               throw new IOException("Invalid error element at line " + tokenizer.lineno + " of errorMap.xml. " + iOException.getMessage());
/*     */             } 
/*     */             
/* 270 */             i = -1;
/* 271 */             j = -1;
/* 272 */             str1 = null;
/* 273 */             k = -1;
/* 274 */             str2 = null;
/* 275 */             b = 7; continue;
/*     */           } 
/* 277 */           throw new IOException("Unexpected token \"" + str3 + "\" at line " + tokenizer.lineno + " of errorMap.xml. Expected \">\".");
/*     */ 
/*     */         
/*     */         case true:
/* 281 */           if (str3.equals("oraErrorSqlStateSqlExceptionMapping")) { b = 17; continue; }
/* 282 */            throw new IOException("Unexpected token \"" + str3 + "\" at line " + tokenizer.lineno + " of errorMap.xml. Expected \"oraErrorSqlStateSqlExceptionMapping\".");
/*     */ 
/*     */         
/*     */         case true:
/* 286 */           if (str3.equals(">")) { b = 18; continue; }
/* 287 */            throw new IOException("Unexpected token \"" + str3 + "\" at line " + tokenizer.lineno + " of errorMap.xml. Expected \">\".");
/*     */         
/*     */         case true:
/*     */           continue;
/*     */         
/*     */         case true:
/* 293 */           if (str3.equals("=")) { b = 20; continue; }
/* 294 */            throw new IOException("Unexpected token \"" + str3 + "\" at line " + tokenizer.lineno + " of errorMap.xml. Expected \"=\".");
/*     */ 
/*     */         
/*     */         case true:
/*     */           try {
/* 299 */             i = Integer.parseInt(str3);
/*     */           }
/* 301 */           catch (NumberFormatException numberFormatException) {
/* 302 */             throw new IOException("Unexpected value \"" + str3 + "\" at line " + tokenizer.lineno + " of errorMap.xml. Expected an integer.");
/*     */           } 
/*     */           
/* 305 */           b = 14;
/*     */           continue;
/*     */         case true:
/* 308 */           if (str3.equals("=")) { b = 22; continue; }
/* 309 */            throw new IOException("Unexpected token \"" + str3 + "\" at line " + tokenizer.lineno + " of errorMap.xml. Expected \"=\".");
/*     */ 
/*     */         
/*     */         case true:
/*     */           try {
/* 314 */             j = Integer.parseInt(str3);
/*     */           }
/* 316 */           catch (NumberFormatException numberFormatException) {
/* 317 */             throw new IOException("Unexpected value \"" + str3 + "\" at line " + tokenizer.lineno + " of errorMap.xml. Expected an integer.");
/*     */           } 
/*     */           
/* 320 */           b = 14;
/*     */           continue;
/*     */         case true:
/* 323 */           if (str3.equals("=")) { b = 24; continue; }
/* 324 */            throw new IOException("Unexpected token \"" + str3 + "\" at line " + tokenizer.lineno + " of errorMap.xml. Expected \"=\".");
/*     */ 
/*     */         
/*     */         case true:
/* 328 */           str1 = str3;
/* 329 */           b = 14;
/*     */           continue;
/*     */         case true:
/* 332 */           if (str3.equals("=")) { b = 26; continue; }
/* 333 */            throw new IOException("Unexpected token \"" + str3 + "\" at line " + tokenizer.lineno + " of errorMap.xml. Expected \"=\".");
/*     */ 
/*     */         
/*     */         case true:
/*     */           try {
/* 338 */             k = valueOf(str3);
/*     */           }
/* 340 */           catch (Exception exception) {
/* 341 */             throw new IOException("Unexpected token \"" + str3 + "\" at line " + tokenizer.lineno + " of errorMap.xml. Expected SQLException" + " subclass name.");
/*     */           } 
/*     */ 
/*     */           
/* 345 */           b = 14;
/*     */           continue;
/*     */         case true:
/* 348 */           if (str3.equals("=")) { b = 28; continue; }
/* 349 */            throw new IOException("Unexpected token \"" + str3 + "\" at line " + tokenizer.lineno + " of errorMap.xml. Expected \"=\".");
/*     */ 
/*     */         
/*     */         case true:
/* 353 */           str2 = str3;
/* 354 */           b = 14;
/*     */           continue;
/*     */       } 
/* 357 */       throw new IOException("Unknown parser state " + b + " at line " + tokenizer.lineno + " of errorMap.xml.");
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final class Tokenizer
/*     */   {
/* 375 */     int lineno = 1;
/*     */     Reader r;
/*     */     int c;
/*     */     
/*     */     Tokenizer(Reader param1Reader) throws IOException {
/* 380 */       this.r = param1Reader;
/* 381 */       this.c = param1Reader.read();
/*     */     }
/*     */     
/*     */     String next() throws IOException {
/* 385 */       StringBuffer stringBuffer = new StringBuffer(16);
/* 386 */       boolean bool = true;
/*     */       
/* 388 */       while (this.c != -1) {
/* 389 */         if (this.c == 10) this.lineno++; 
/* 390 */         if (this.c <= 32 && bool) {
/* 391 */           this.c = this.r.read();
/*     */           continue;
/*     */         } 
/* 394 */         if (this.c <= 32 && !bool) {
/* 395 */           this.c = this.r.read();
/*     */           break;
/*     */         } 
/* 398 */         if (this.c == 34) {
/* 399 */           for (; (this.c = this.r.read()) != 34; stringBuffer.append((char)this.c));
/* 400 */           this.c = this.r.read();
/*     */           break;
/*     */         } 
/* 403 */         if ((48 <= this.c && this.c <= 57) || (65 <= this.c && this.c <= 90) || (97 <= this.c && this.c <= 122) || this.c == 95) {
/*     */           
/*     */           do
/*     */           {
/*     */             
/* 408 */             stringBuffer.append((char)this.c);
/*     */ 
/*     */           
/*     */           }
/* 412 */           while ((48 <= (this.c = this.r.read()) && this.c <= 57) || (65 <= this.c && this.c <= 90) || (97 <= this.c && this.c <= 122) || this.c == 95);
/*     */           break;
/*     */         } 
/* 415 */         stringBuffer.append((char)this.c);
/* 416 */         this.c = this.r.read();
/*     */         break;
/*     */       } 
/* 419 */       if (stringBuffer.length() > 0) return stringBuffer.toString(); 
/* 420 */       return null;
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private static void createOne(List paramList, int paramInt1, int paramInt2, String paramString1, int paramInt3, String paramString2) throws IOException {
/* 426 */     if (paramInt1 == -1) throw new IOException("oraErrorFrom is a required attribute"); 
/* 427 */     if (paramInt2 == -1) paramInt2 = paramInt1; 
/* 428 */     if (paramString1 == null || paramString1.length() == 0) throw new IOException("sqlState is a required attribute"); 
/* 429 */     if (paramInt3 == -1) throw new IOException("sqlException is a required attribute"); 
/* 430 */     if (paramString2 == null || paramString2.length() < 8) throw new IOException("a lengthy comment in required"); 
/* 431 */     SQLStateMapping sQLStateMapping = new SQLStateMapping(paramInt1, paramInt2, paramString1, paramInt3);
/* 432 */     add(paramList, sQLStateMapping);
/*     */   }
/*     */   
/*     */   static void add(List<SQLStateMapping> paramList, SQLStateMapping paramSQLStateMapping) {
/* 436 */     int i = paramList.size();
/* 437 */     for (; i > 0 && 
/* 438 */       !((SQLStateMapping)paramList.get(i - 1)).lessThan(paramSQLStateMapping); i--);
/*     */ 
/*     */ 
/*     */     
/* 442 */     paramList.add(i, paramSQLStateMapping);
/*     */   }
/*     */ 
/*     */   
/*     */   static int valueOf(String paramString) throws Exception {
/* 447 */     if (paramString.equalsIgnoreCase("SQLEXCEPTION")) return 0; 
/* 448 */     if (paramString.equalsIgnoreCase("SQLNONTRANSIENTEXCEPTION")) return 1; 
/* 449 */     if (paramString.equalsIgnoreCase("SQLTRANSIENTEXCEPTION")) return 2; 
/* 450 */     if (paramString.equalsIgnoreCase("SQLDATAEXCEPTION")) return 3; 
/* 451 */     if (paramString.equalsIgnoreCase("SQLFEATURENOTSUPPORTEDEXCEPTION")) return 4; 
/* 452 */     if (paramString.equalsIgnoreCase("SQLINTEGRITYCONSTRAINTVIOLATIONEXCEPTION")) return 5; 
/* 453 */     if (paramString.equalsIgnoreCase("SQLINVALIDAUTHORIZATIONSPECEXCEPTION")) return 6; 
/* 454 */     if (paramString.equalsIgnoreCase("SQLNONTRANSIENTCONNECTIONEXCEPTION")) return 7; 
/* 455 */     if (paramString.equalsIgnoreCase("SQLSYNTAXERROREXCEPTION")) return 8; 
/* 456 */     if (paramString.equalsIgnoreCase("SQLTIMEOUTEXCEPTION")) return 9; 
/* 457 */     if (paramString.equalsIgnoreCase("SQLTRANSACTIONROLLBACKEXCEPTION")) return 10; 
/* 458 */     if (paramString.equalsIgnoreCase("SQLTRANSIENTCONNECTIONEXCEPTION")) return 11; 
/* 459 */     if (paramString.equalsIgnoreCase("SQLCLIENTINFOEXCEPTION")) return 12; 
/* 460 */     if (paramString.equalsIgnoreCase("SQLRECOVERABLEEXCEPTION")) return 13; 
/* 461 */     throw new Exception("unexpected exception name: " + paramString);
/*     */   }
/*     */ 
/*     */   
/* 465 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*     */   public static final String BUILD_DATE = "Thu_Apr_04_15:09:24_PDT_2013";
/*     */   public static final boolean TRACE = false;
/*     */ }


/* Location:              C:\Users\olatu\OneDrive\Documents\Calypso\syncbase\sync_base.jar!\BOOT-INF\lib\ojdbc-7.jar!\oracle\jdbc\driver\SQLStateMapping.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */