/*     */ package oracle.jdbc.driver;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.sql.SQLException;
/*     */ import oracle.jdbc.internal.XSSecureId;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class XSSecureIdI
/*     */   extends XSSecureId
/*     */ {
/*  33 */   byte[] kpxssidpmac = null;
/*  34 */   byte[] kpxssidpmtid = null;
/*  35 */   long kpxssidpnonce = 0L;
/*     */ 
/*     */   
/*     */   public void setMac(byte[] paramArrayOfbyte) throws SQLException {
/*  39 */     this.kpxssidpmac = paramArrayOfbyte;
/*     */   }
/*     */   
/*     */   public void setMidtierId(byte[] paramArrayOfbyte) throws SQLException {
/*  43 */     this.kpxssidpmtid = paramArrayOfbyte;
/*     */   }
/*     */   
/*     */   public void setNonce(long paramLong) throws SQLException {
/*  47 */     this.kpxssidpnonce = paramLong;
/*     */   }
/*     */ 
/*     */   
/*     */   public byte[] getMac() {
/*  52 */     return this.kpxssidpmac;
/*     */   }
/*     */ 
/*     */   
/*     */   public byte[] getMidtierId() {
/*  57 */     return this.kpxssidpmtid;
/*     */   }
/*     */ 
/*     */   
/*     */   public long getNonce() {
/*  62 */     return this.kpxssidpnonce;
/*     */   }
/*     */ 
/*     */   
/*     */   void marshal(T4CMAREngine paramT4CMAREngine) throws IOException {
/*  67 */     if (this.kpxssidpmac != null) {
/*     */       
/*  69 */       paramT4CMAREngine.marshalUB4(this.kpxssidpmac.length);
/*  70 */       paramT4CMAREngine.marshalCLR(this.kpxssidpmac, this.kpxssidpmac.length);
/*     */     } else {
/*     */       
/*  73 */       paramT4CMAREngine.marshalUB4(0L);
/*     */     } 
/*  75 */     if (this.kpxssidpmtid != null) {
/*     */       
/*  77 */       paramT4CMAREngine.marshalUB4(this.kpxssidpmtid.length);
/*  78 */       paramT4CMAREngine.marshalCLR(this.kpxssidpmtid, this.kpxssidpmtid.length);
/*     */     } else {
/*     */       
/*  81 */       paramT4CMAREngine.marshalUB4(0L);
/*     */     } 
/*  83 */     paramT4CMAREngine.marshalUB4(this.kpxssidpnonce);
/*     */   }
/*     */   
/*     */   static XSSecureIdI unmarshal(T4CMAREngine paramT4CMAREngine) throws SQLException, IOException {
/*  87 */     byte[] arrayOfByte1 = null;
/*  88 */     byte[] arrayOfByte2 = null;
/*  89 */     long l = 0L;
/*     */     
/*  91 */     int i = (int)paramT4CMAREngine.unmarshalUB4();
/*  92 */     if (i > 0) {
/*  93 */       arrayOfByte1 = paramT4CMAREngine.unmarshalNBytes(i);
/*     */     }
/*  95 */     int j = (int)paramT4CMAREngine.unmarshalUB4();
/*  96 */     if (j > 0) {
/*  97 */       arrayOfByte2 = paramT4CMAREngine.unmarshalNBytes(j);
/*     */     }
/*  99 */     l = paramT4CMAREngine.unmarshalUB4();
/*     */     
/* 101 */     XSSecureIdI xSSecureIdI = new XSSecureIdI();
/* 102 */     xSSecureIdI.setMac(arrayOfByte1);
/* 103 */     xSSecureIdI.setMidtierId(arrayOfByte2);
/* 104 */     xSSecureIdI.setNonce(l);
/* 105 */     return xSSecureIdI;
/*     */   }
/*     */ }


/* Location:              C:\Users\olatu\OneDrive\Documents\Calypso\syncbase\sync_base.jar!\BOOT-INF\lib\ojdbc-7.jar!\oracle\jdbc\driver\XSSecureIdI.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */