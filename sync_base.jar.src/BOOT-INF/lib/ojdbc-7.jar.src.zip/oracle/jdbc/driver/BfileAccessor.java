/*     */ package oracle.jdbc.driver;
/*     */ 
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.Reader;
/*     */ import java.sql.SQLException;
/*     */ import java.util.Map;
/*     */ import oracle.jdbc.OracleConnection;
/*     */ import oracle.sql.BFILE;
/*     */ import oracle.sql.Datum;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class BfileAccessor
/*     */   extends LobCommonAccessor
/*     */ {
/*     */   static final int MAXLENGTH = 530;
/*     */   
/*     */   BfileAccessor(OracleStatement paramOracleStatement, int paramInt1, short paramShort, int paramInt2, boolean paramBoolean) throws SQLException {
/*  29 */     super(Representation.BFILE, paramOracleStatement, 530, paramBoolean);
/*     */     
/*  31 */     init(paramOracleStatement, 114, 114, paramShort, paramBoolean);
/*  32 */     initForDataAccess(paramInt2, paramInt1, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   BfileAccessor(OracleStatement paramOracleStatement, int paramInt1, boolean paramBoolean, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, short paramShort) throws SQLException {
/*  40 */     super(Representation.BFILE, paramOracleStatement, 530, false);
/*     */     
/*  42 */     init(paramOracleStatement, 114, 114, paramShort, false);
/*  43 */     initForDescribe(114, paramInt1, paramBoolean, paramInt2, paramInt3, paramInt4, paramInt5, paramInt6, paramShort, null);
/*     */     
/*  45 */     initForDataAccess(0, paramInt1, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Object getObject(int paramInt) throws SQLException {
/*  65 */     return getBFILE(paramInt);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Object getObject(int paramInt, Map paramMap) throws SQLException {
/*  82 */     return getBFILE(paramInt);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Datum getOracleObject(int paramInt) throws SQLException {
/* 104 */     return (Datum)getBFILE(paramInt);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   BFILE getBFILE(int paramInt) throws SQLException {
/* 122 */     if (isNull(paramInt)) return null;
/*     */     
/* 124 */     BFILE bFILE = new BFILE((OracleConnection)this.statement.connection, getBytesInternal(paramInt));
/* 125 */     if (isPrefetched()) bFILE.setLength(getPrefetchedLength(paramInt)); 
/* 126 */     return bFILE;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   InputStream getAsciiStream(int paramInt) throws SQLException {
/* 144 */     BFILE bFILE = getBFILE(paramInt);
/*     */     
/* 146 */     if (bFILE == null) {
/* 147 */       return null;
/*     */     }
/* 149 */     return bFILE.asciiStreamValue();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Reader getCharacterStream(int paramInt) throws SQLException {
/* 165 */     BFILE bFILE = getBFILE(paramInt);
/*     */     
/* 167 */     if (bFILE == null) {
/* 168 */       return null;
/*     */     }
/* 170 */     return bFILE.characterStreamValue();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   InputStream getBinaryStream(int paramInt) throws SQLException {
/* 186 */     BFILE bFILE = getBFILE(paramInt);
/*     */     
/* 188 */     if (bFILE == null) {
/* 189 */       return null;
/*     */     }
/* 191 */     return bFILE.getBinaryStream();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   byte[] getBytes(int paramInt) throws SQLException {
/* 208 */     BFILE bFILE = getBFILE(paramInt);
/*     */     
/* 210 */     if (bFILE == null) {
/* 211 */       return null;
/*     */     }
/* 213 */     InputStream inputStream = bFILE.getBinaryStream();
/* 214 */     char c = 'က';
/* 215 */     int i = 0;
/* 216 */     ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream(c);
/* 217 */     byte[] arrayOfByte = new byte[c];
/*     */ 
/*     */     
/*     */     try {
/* 221 */       while ((i = inputStream.read(arrayOfByte)) != -1)
/*     */       {
/* 223 */         byteArrayOutputStream.write(arrayOfByte, 0, i);
/*     */       }
/*     */     }
/* 226 */     catch (IOException iOException) {
/*     */ 
/*     */       
/* 229 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException);
/* 230 */       sQLException.fillInStackTrace();
/* 231 */       throw sQLException;
/*     */     
/*     */     }
/* 234 */     catch (IndexOutOfBoundsException indexOutOfBoundsException) {
/*     */ 
/*     */       
/* 237 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 151);
/* 238 */       sQLException.fillInStackTrace();
/* 239 */       throw sQLException;
/*     */     } 
/*     */ 
/*     */     
/* 243 */     return byteArrayOutputStream.toByteArray();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/* 248 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*     */   public static final String BUILD_DATE = "Thu_Apr_04_15:09:24_PDT_2013";
/*     */   public static final boolean TRACE = false;
/*     */ }


/* Location:              C:\Users\olatu\OneDrive\Documents\Calypso\syncbase\sync_base.jar!\BOOT-INF\lib\ojdbc-7.jar!\oracle\jdbc\driver\BfileAccessor.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */