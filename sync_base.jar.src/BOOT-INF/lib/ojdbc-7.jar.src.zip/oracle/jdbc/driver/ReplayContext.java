/*    */ package oracle.jdbc.driver;
/*    */ 
/*    */ import oracle.jdbc.internal.ReplayContext;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class ReplayContext
/*    */   implements ReplayContext
/*    */ {
/*    */   long flags_kpdxcAppContCtl;
/*    */   short queue_kpdxcAppContCtl;
/*    */   byte[] replayctx_kpdxcAppContCtl;
/*    */   long errcode_kpdxcAppContCtl;
/*    */   
/*    */   ReplayContext(long paramLong1, short paramShort, byte[] paramArrayOfbyte, long paramLong2) {
/* 44 */     this.flags_kpdxcAppContCtl = paramLong1;
/* 45 */     this.queue_kpdxcAppContCtl = paramShort;
/* 46 */     this.errcode_kpdxcAppContCtl = paramLong2;
/* 47 */     this.replayctx_kpdxcAppContCtl = paramArrayOfbyte;
/*    */   }
/*    */   
/*    */   public byte[] getContext() {
/* 51 */     return this.replayctx_kpdxcAppContCtl;
/*    */   }
/*    */   
/*    */   public short getQueue() {
/* 55 */     return this.queue_kpdxcAppContCtl;
/*    */   }
/*    */   
/*    */   public long getDirectives() {
/* 59 */     return this.flags_kpdxcAppContCtl;
/*    */   }
/*    */   
/*    */   public long getErrorCode() {
/* 63 */     return this.errcode_kpdxcAppContCtl;
/*    */   }
/*    */   
/*    */   private String getDirectivesAsString() {
/* 67 */     String str = "[0";
/* 68 */     if ((this.flags_kpdxcAppContCtl & 0x1L) == 1L)
/* 69 */       str = str + "|DIRECTIVE_ENQUEUE_CALL"; 
/* 70 */     if ((this.flags_kpdxcAppContCtl & 0x2L) == 2L)
/* 71 */       str = str + "|DIRECTIVE_REQ_SCOPE_CRSR"; 
/* 72 */     if ((this.flags_kpdxcAppContCtl & 0x4L) == 4L)
/* 73 */       str = str + "|DIRECTIVE_REPLAY_ENABLED"; 
/* 74 */     if ((this.flags_kpdxcAppContCtl & 0x8L) == 8L)
/* 75 */       str = str + "|DIRECTIVE_EMPTY_QUEUE"; 
/* 76 */     return str + "]";
/*    */   }
/*    */   
/*    */   public String toString() {
/* 80 */     return "ReplayContext[Directives=" + getDirectivesAsString() + ",Queue=" + this.queue_kpdxcAppContCtl + ",ErrorCode=" + this.errcode_kpdxcAppContCtl + ",Context=" + this.replayctx_kpdxcAppContCtl + "]";
/*    */   }
/*    */ }


/* Location:              C:\Users\olatu\OneDrive\Documents\Calypso\syncbase\sync_base.jar!\BOOT-INF\lib\ojdbc-7.jar!\oracle\jdbc\driver\ReplayContext.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */