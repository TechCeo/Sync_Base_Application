/*     */ package oracle.jdbc.driver;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ import java.sql.SQLException;
/*     */ import oracle.jdbc.internal.OracleBlob;
/*     */ import oracle.jdbc.internal.OracleConnection;
/*     */ import oracle.sql.BLOB;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class OracleBlobOutputStream
/*     */   extends OutputStream
/*     */ {
/*     */   long lobOffset;
/*     */   OracleBlob blob;
/*     */   byte[] buf;
/*     */   int count;
/*     */   int bufSize;
/*     */   boolean isClosed;
/*     */   
/*     */   public OracleBlobOutputStream(BLOB paramBLOB, int paramInt) throws SQLException {
/*  45 */     this((OracleBlob)paramBLOB, paramInt);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public OracleBlobOutputStream(OracleBlob paramOracleBlob, int paramInt) throws SQLException {
/*  58 */     this(paramOracleBlob, paramInt, 1L);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public OracleBlobOutputStream(BLOB paramBLOB, int paramInt, long paramLong) throws SQLException {
/*  72 */     this((OracleBlob)paramBLOB, paramInt, paramLong);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public OracleBlobOutputStream(OracleBlob paramOracleBlob, int paramInt, long paramLong) throws SQLException {
/*  89 */     if (paramOracleBlob == null || paramInt <= 0 || paramLong < 1L)
/*     */     {
/*  91 */       throw new IllegalArgumentException("Illegal Arguments");
/*     */     }
/*     */     
/*  94 */     this.blob = paramOracleBlob;
/*  95 */     this.lobOffset = paramLong;
/*     */     
/*  97 */     PhysicalConnection physicalConnection = (PhysicalConnection)paramOracleBlob.getInternalConnection();
/*  98 */     synchronized (physicalConnection) {
/*  99 */       this.buf = physicalConnection.getByteBuffer(paramInt);
/*     */     } 
/* 101 */     this.count = 0;
/* 102 */     this.bufSize = paramInt;
/*     */     
/* 104 */     this.isClosed = false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void write(int paramInt) throws IOException {
/* 123 */     ensureOpen();
/*     */     
/* 125 */     if (this.count >= this.bufSize) {
/* 126 */       flushBuffer();
/*     */     }
/* 128 */     this.buf[this.count++] = (byte)paramInt;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void write(byte[] paramArrayOfbyte, int paramInt1, int paramInt2) throws IOException {
/* 150 */     ensureOpen();
/*     */     
/* 152 */     int i = paramInt1;
/* 153 */     int j = Math.min(paramInt2, paramArrayOfbyte.length - paramInt1);
/*     */     
/* 155 */     if (j >= 2 * this.bufSize) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 162 */       if (this.count > 0) flushBuffer();
/*     */       
/*     */       try {
/* 165 */         this.lobOffset += this.blob.setBytes(this.lobOffset, paramArrayOfbyte, paramInt1, j);
/*     */       }
/* 167 */       catch (SQLException sQLException) {
/*     */ 
/*     */         
/* 170 */         IOException iOException = DatabaseError.createIOException(sQLException);
/* 171 */         iOException.fillInStackTrace();
/* 172 */         throw iOException;
/*     */       }
/*     */     
/*     */     }
/*     */     else {
/*     */       
/* 178 */       int k = i + j;
/*     */       
/* 180 */       while (i < k) {
/*     */         
/* 182 */         int m = Math.min(this.bufSize - this.count, k - i);
/*     */         
/* 184 */         System.arraycopy(paramArrayOfbyte, i, this.buf, this.count, m);
/*     */         
/* 186 */         i += m;
/* 187 */         this.count += m;
/*     */         
/* 189 */         if (this.count >= this.bufSize) {
/* 190 */           flushBuffer();
/*     */         }
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void flush() throws IOException {
/* 211 */     ensureOpen();
/*     */     
/* 213 */     flushBuffer();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void close() throws IOException {
/* 232 */     if (this.isClosed) {
/*     */       return;
/*     */     }
/*     */     
/*     */     try {
/* 237 */       this.isClosed = true;
/* 238 */       flushBuffer();
/*     */     } finally {
/*     */ 
/*     */       
/*     */       try {
/* 243 */         PhysicalConnection physicalConnection = (PhysicalConnection)this.blob.getInternalConnection();
/* 244 */         synchronized (physicalConnection) {
/*     */           
/* 246 */           if (this.buf != null) {
/*     */             
/* 248 */             physicalConnection.cacheBuffer(this.buf);
/* 249 */             this.buf = null;
/*     */           } 
/*     */         } 
/* 252 */       } catch (SQLException sQLException) {
/*     */ 
/*     */         
/* 255 */         IOException iOException = DatabaseError.createIOException(sQLException);
/* 256 */         iOException.fillInStackTrace();
/* 257 */         throw iOException;
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void flushBuffer() throws IOException {
/*     */     try {
/* 275 */       if (this.count > 0)
/*     */       {
/* 277 */         this.lobOffset += this.blob.setBytes(this.lobOffset, this.buf, 0, this.count);
/* 278 */         this.count = 0;
/*     */       }
/*     */     
/* 281 */     } catch (SQLException sQLException) {
/*     */ 
/*     */       
/* 284 */       IOException iOException = DatabaseError.createIOException(sQLException);
/* 285 */       iOException.fillInStackTrace();
/* 286 */       throw iOException;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void ensureOpen() throws IOException {
/*     */     try {
/* 303 */       if (this.isClosed)
/*     */       {
/* 305 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 57, (Object)null);
/* 306 */         sQLException.fillInStackTrace();
/* 307 */         throw sQLException;
/*     */       }
/*     */     
/* 310 */     } catch (SQLException sQLException) {
/*     */ 
/*     */       
/* 313 */       IOException iOException = DatabaseError.createIOException(sQLException);
/* 314 */       iOException.fillInStackTrace();
/* 315 */       throw iOException;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected OracleConnection getConnectionDuringExceptionHandling() {
/*     */     try {
/* 335 */       return this.blob.getInternalConnection();
/*     */     }
/* 337 */     catch (Exception exception) {
/*     */       
/* 339 */       return null;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 346 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*     */   public static final String BUILD_DATE = "Thu_Apr_04_15:09:24_PDT_2013";
/*     */   public static final boolean TRACE = false;
/*     */ }


/* Location:              C:\Users\olatu\OneDrive\Documents\Calypso\syncbase\sync_base.jar!\BOOT-INF\lib\ojdbc-7.jar!\oracle\jdbc\driver\OracleBlobOutputStream.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */