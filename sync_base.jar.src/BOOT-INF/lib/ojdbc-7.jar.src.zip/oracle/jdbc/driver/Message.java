package oracle.jdbc.driver;

public interface Message {
  String msg(String paramString, Object paramObject);
}


/* Location:              C:\Users\olatu\OneDrive\Documents\Calypso\syncbase\sync_base.jar!\BOOT-INF\lib\ojdbc-7.jar!\oracle\jdbc\driver\Message.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */