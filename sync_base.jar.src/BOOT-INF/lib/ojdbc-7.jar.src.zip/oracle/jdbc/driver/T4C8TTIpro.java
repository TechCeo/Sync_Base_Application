/*     */ package oracle.jdbc.driver;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.StringWriter;
/*     */ import java.sql.SQLException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class T4C8TTIpro
/*     */   extends T4CTTIMsg
/*     */ {
/*     */   short svrCharSet;
/*     */   short svrCharSetElem;
/*     */   byte svrFlags;
/*     */   byte[] proSvrStr;
/*     */   short proSvrVer;
/*  65 */   short oVersion = -1;
/*     */ 
/*     */   
/*     */   boolean svrInfoAvailable = false;
/*     */   
/*  70 */   byte[] proCliVerTTC8 = new byte[] { 6, 5, 4, 3, 2, 1, 0 };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  76 */   byte[] proCliStrTTC8 = new byte[] { 74, 97, 118, 97, 95, 84, 84, 67, 45, 56, 46, 50, 46, 48, 0 };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  83 */   short NCHAR_CHARSET = 0;
/*     */   
/*  85 */   byte[] runtimeCapabilities = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   T4C8TTIpro(T4CConnection paramT4CConnection) throws SQLException, IOException {
/*  96 */     super(paramT4CConnection, (byte)1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   byte[] receive() throws SQLException, IOException {
/*     */     SQLException sQLException;
/* 127 */     if (this.meg.unmarshalUB1() != 1) {
/*     */       
/* 129 */       SQLException sQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 401);
/* 130 */       sQLException1.fillInStackTrace();
/* 131 */       throw sQLException1;
/*     */     } 
/*     */     
/* 134 */     this.proSvrVer = this.meg.unmarshalUB1();
/* 135 */     this.meg.proSvrVer = this.proSvrVer;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 140 */     switch (this.proSvrVer) {
/*     */ 
/*     */       
/*     */       case 4:
/* 144 */         this.oVersion = 7230;
/*     */         break;
/*     */ 
/*     */ 
/*     */       
/*     */       case 5:
/* 150 */         this.oVersion = 8030;
/*     */         break;
/*     */ 
/*     */       
/*     */       case 6:
/* 155 */         this.oVersion = 8100;
/*     */         break;
/*     */ 
/*     */ 
/*     */       
/*     */       default:
/* 161 */         sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 444);
/* 162 */         sQLException.fillInStackTrace();
/* 163 */         throw sQLException;
/*     */     } 
/*     */ 
/*     */     
/* 167 */     this.meg.unmarshalUB1();
/*     */     
/* 169 */     this.proSvrStr = this.meg.unmarshalTEXT(50);
/* 170 */     this.oVersion = getOracleVersion();
/*     */ 
/*     */     
/* 173 */     this.svrCharSet = (short)this.meg.unmarshalUB2();
/* 174 */     this.svrFlags = (byte)this.meg.unmarshalUB1();
/*     */ 
/*     */     
/* 177 */     if ((this.svrCharSetElem = (short)this.meg.unmarshalUB2()) > 0)
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 183 */       this.meg.unmarshalNBytes(this.svrCharSetElem * 5);
/*     */     }
/*     */     
/* 186 */     this.svrInfoAvailable = true;
/*     */ 
/*     */     
/* 189 */     if (this.proSvrVer < 5) {
/* 190 */       return null;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 196 */     byte b = this.meg.types.getRep((byte)1);
/* 197 */     this.meg.types.setRep((byte)1, (byte)0);
/* 198 */     int i = this.meg.unmarshalUB2();
/*     */     
/* 200 */     this.meg.types.setRep((byte)1, b);
/*     */     
/* 202 */     byte[] arrayOfByte1 = this.meg.unmarshalNBytes(i);
/*     */ 
/*     */     
/* 205 */     int j = 6 + (arrayOfByte1[5] & 0xFF) + (arrayOfByte1[6] & 0xFF);
/*     */     
/* 207 */     this.NCHAR_CHARSET = (short)((arrayOfByte1[j + 3] & 0xFF) << 8);
/* 208 */     this.NCHAR_CHARSET = (short)(this.NCHAR_CHARSET | (short)(arrayOfByte1[j + 4] & 0xFF));
/*     */     
/* 210 */     if (this.proSvrVer < 6) {
/* 211 */       return null;
/*     */     }
/*     */ 
/*     */     
/* 215 */     short s = this.meg.unmarshalUB1();
/* 216 */     byte[] arrayOfByte2 = new byte[s]; byte b1;
/* 217 */     for (b1 = 0; b1 < s; b1++) {
/* 218 */       arrayOfByte2[b1] = (byte)this.meg.unmarshalUB1();
/*     */     }
/*     */     
/* 221 */     s = this.meg.unmarshalUB1();
/* 222 */     if (s > 0) {
/*     */       
/* 224 */       this.runtimeCapabilities = new byte[s];
/* 225 */       for (b1 = 0; b1 < s; b1++) {
/* 226 */         this.runtimeCapabilities[b1] = (byte)this.meg.unmarshalUB1();
/*     */       }
/*     */     } 
/* 229 */     return arrayOfByte2;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   short getOracleVersion() {
/* 241 */     return this.oVersion;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   byte[] getServerRuntimeCapabilities() {
/* 248 */     return this.runtimeCapabilities;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   short getCharacterSet() {
/* 260 */     return this.svrCharSet;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   short getncharCHARSET() {
/* 267 */     return this.NCHAR_CHARSET;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   byte getFlags() {
/* 279 */     return this.svrFlags;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void marshal() throws SQLException, IOException {
/* 286 */     marshalTTCcode();
/*     */     
/* 288 */     this.meg.marshalB1Array(this.proCliVerTTC8);
/* 289 */     this.meg.marshalB1Array(this.proCliStrTTC8);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void printServerInfo() {
/* 303 */     if (this.svrInfoAvailable) {
/*     */       
/* 305 */       byte b = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 310 */       StringWriter stringWriter = new StringWriter();
/*     */       
/* 312 */       stringWriter.write("Protocol string  =");
/*     */       
/* 314 */       while (b < this.proSvrStr.length) {
/* 315 */         stringWriter.write((char)this.proSvrStr[b++]);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 332 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*     */   public static final String BUILD_DATE = "Thu_Apr_04_15:09:24_PDT_2013";
/*     */   public static final boolean TRACE = false;
/*     */ }


/* Location:              C:\Users\olatu\OneDrive\Documents\Calypso\syncbase\sync_base.jar!\BOOT-INF\lib\ojdbc-7.jar!\oracle\jdbc\driver\T4C8TTIpro.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */