/*    */ package oracle.jdbc.driver;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.sql.SQLException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class T4CTTIosesstate
/*    */   extends T4CTTIfun
/*    */ {
/*    */   private long flags_kpdssSessionStateOps;
/*    */   
/*    */   T4CTTIosesstate(T4CConnection paramT4CConnection) {
/* 56 */     super(paramT4CConnection, (byte)17);
/*    */     
/* 58 */     setFunCode((short)176);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   void doOSESSSTATE(long paramLong) throws IOException, SQLException {
/* 66 */     this.flags_kpdssSessionStateOps = paramLong;
/* 67 */     doPigRPC();
/*    */   }
/*    */ 
/*    */   
/*    */   void marshal() throws IOException {
/* 72 */     this.meg.marshalSB8(this.flags_kpdssSessionStateOps);
/*    */   }
/*    */ }


/* Location:              C:\Users\olatu\OneDrive\Documents\Calypso\syncbase\sync_base.jar!\BOOT-INF\lib\ojdbc-7.jar!\oracle\jdbc\driver\T4CTTIosesstate.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */