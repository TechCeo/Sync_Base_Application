/*     */ package oracle.jdbc.driver;
/*     */ 
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.Reader;
/*     */ import java.sql.SQLException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class T2CLongRawAccessor
/*     */   extends LongRawAccessor
/*     */ {
/*     */   T2CLongRawAccessor(OracleStatement paramOracleStatement, int paramInt1, int paramInt2, short paramShort, int paramInt3) throws SQLException {
/*  39 */     super(paramOracleStatement, paramInt1, paramInt2, paramShort, paramInt3);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   T2CLongRawAccessor(OracleStatement paramOracleStatement, int paramInt1, int paramInt2, boolean paramBoolean, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, short paramShort) throws SQLException {
/*  47 */     super(paramOracleStatement, paramInt1, paramInt2, paramBoolean, paramInt3, paramInt4, paramInt5, paramInt6, paramInt7, paramShort);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   byte[] getBytesInternal(int paramInt) throws SQLException {
/*  56 */     if (this.statement.isFetchStreams) {
/*  57 */       assert !isNull(paramInt);
/*  58 */       int i = getLength(paramInt);
/*  59 */       long l = getOffset(paramInt);
/*  60 */       return this.rowData.get(l, i);
/*     */     } 
/*     */     
/*  63 */     return super.getBytesInternal(paramInt);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   InputStream getAsciiStream(int paramInt) throws SQLException {
/*  72 */     if (this.statement.isFetchStreams) {
/*  73 */       if (isNull(paramInt)) return null; 
/*  74 */       ByteArrayInputStream byteArrayInputStream = new ByteArrayInputStream(this.rowData.get(getOffset(paramInt), getLength(paramInt)));
/*     */ 
/*     */ 
/*     */       
/*  78 */       try { return this.statement.connection.conversion.ConvertStream(byteArrayInputStream, 2); }
/*     */       finally { 
/*  80 */         try { if (byteArrayInputStream != null) byteArrayInputStream.close();  } catch (IOException iOException) {} }
/*     */     
/*     */     } 
/*  83 */     return super.getAsciiStream(paramInt);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   InputStream getUnicodeStream(int paramInt) throws SQLException {
/*  93 */     if (this.statement.isFetchStreams) {
/*  94 */       if (isNull(paramInt)) return null; 
/*  95 */       ByteArrayInputStream byteArrayInputStream = new ByteArrayInputStream(this.rowData.get(getOffset(paramInt), getLength(paramInt)));
/*     */ 
/*     */ 
/*     */       
/*  99 */       try { return this.statement.connection.conversion.ConvertStream(byteArrayInputStream, 3); }
/*     */       finally { 
/* 101 */         try { if (byteArrayInputStream != null) byteArrayInputStream.close();  } catch (IOException iOException) {} }
/*     */     
/*     */     } 
/* 104 */     return super.getUnicodeStream(paramInt);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Reader getCharacterStream(int paramInt) throws SQLException {
/* 114 */     if (this.statement.isFetchStreams) {
/* 115 */       if (isNull(paramInt)) return null; 
/* 116 */       ByteArrayInputStream byteArrayInputStream = new ByteArrayInputStream(this.rowData.get(getOffset(paramInt), getLength(paramInt)));
/*     */ 
/*     */ 
/*     */       
/* 120 */       try { return this.statement.connection.conversion.ConvertCharacterStream(byteArrayInputStream, 8, this.formOfUse); }
/*     */       finally { 
/* 122 */         try { if (byteArrayInputStream != null) byteArrayInputStream.close();  } catch (IOException iOException) {} }
/*     */     
/*     */     } 
/* 125 */     return super.getCharacterStream(paramInt);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   InputStream getBinaryStream(int paramInt) throws SQLException {
/* 135 */     if (this.statement.isFetchStreams) {
/* 136 */       if (isNull(paramInt)) return null; 
/* 137 */       return new ByteArrayInputStream(this.rowData.get(getOffset(paramInt), getLength(paramInt)));
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 149 */     return super.getBinaryStream(paramInt);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void copyStreamDataIntoDBA(int paramInt) throws SQLException {
/* 156 */     if (this.stream.closed) {
/*     */       
/* 158 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 27);
/* 159 */       sQLException.fillInStackTrace();
/* 160 */       throw sQLException;
/*     */     } 
/*     */ 
/*     */     
/* 164 */     ByteArrayOutputStream byteArrayOutputStream = null;
/* 165 */     byte[] arrayOfByte = null;
/*     */     try {
/* 167 */       byteArrayOutputStream = new ByteArrayOutputStream(1024);
/* 168 */       byte[] arrayOfByte1 = this.statement.connection.getByteBuffer(32768);
/*     */       
/*     */       try {
/*     */         int i;
/* 172 */         for (; (i = this.stream.read(arrayOfByte1, 0, 32768)) != -1; byteArrayOutputStream.write(arrayOfByte1, 0, i));
/* 173 */         this.statement.connection.cacheBuffer(arrayOfByte1);
/*     */       }
/* 175 */       catch (IOException iOException) {
/*     */         
/* 177 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException);
/* 178 */         sQLException.fillInStackTrace();
/* 179 */         throw sQLException;
/*     */       } 
/*     */       
/* 182 */       arrayOfByte = byteArrayOutputStream.toByteArray();
/*     */     } finally {
/*     */       
/* 185 */       try { if (byteArrayOutputStream != null) byteArrayOutputStream.close();  } catch (IOException iOException) {}
/*     */     } 
/* 187 */     if (arrayOfByte == null || arrayOfByte.length == 0) {
/* 188 */       setLengthAndNull(paramInt, 0);
/*     */     } else {
/*     */       
/* 191 */       setOffset(paramInt);
/* 192 */       setLengthAndNull(paramInt, arrayOfByte.length);
/* 193 */       this.rowData.put(arrayOfByte);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   Accessor copyForDefine(OracleStatement paramOracleStatement) {
/* 200 */     LongRawAccessor longRawAccessor = (LongRawAccessor)super.copyForDefine(paramOracleStatement);
/*     */     try {
/* 202 */       longRawAccessor.stream = paramOracleStatement.connection.driverExtension.createInputStream(paramOracleStatement, this.columnPosition, longRawAccessor);
/*     */     
/*     */     }
/* 205 */     catch (SQLException sQLException) {}
/* 206 */     return longRawAccessor;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/* 211 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*     */   public static final String BUILD_DATE = "Thu_Apr_04_15:09:24_PDT_2013";
/*     */   public static final boolean TRACE = false;
/*     */ }


/* Location:              C:\Users\olatu\OneDrive\Documents\Calypso\syncbase\sync_base.jar!\BOOT-INF\lib\ojdbc-7.jar!\oracle\jdbc\driver\T2CLongRawAccessor.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */