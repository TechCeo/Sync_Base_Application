/*     */ package oracle.jdbc.driver;
/*     */ 
/*     */ import java.io.PrintWriter;
/*     */ import java.sql.SQLException;
/*     */ import java.util.ArrayList;
/*     */ import oracle.jdbc.internal.OracleConnection;
/*     */ import oracle.jdbc.internal.OracleStatement;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class OracleParameterMetaDataParser
/*     */ {
/*     */   static final int UNINITIALIZED = -1;
/*  39 */   static final String[] EMPTY_LIST = new String[0];
/*     */   
/*     */   String parameterSql;
/*     */   
/*  43 */   OracleStatement.SqlKind sqlKind = OracleStatement.SqlKind.UNINITIALIZED;
/*  44 */   int parameterCount = -1;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean needToParseSql;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final int cMax = 127;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void initialize(String paramString, OracleStatement.SqlKind paramSqlKind, int paramInt) throws SQLException {
/*  74 */     if (paramString == null || paramString.length() == 0) {
/*     */       
/*  76 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 104);
/*  77 */       sQLException.fillInStackTrace();
/*  78 */       throw sQLException;
/*     */     } 
/*     */     
/*  81 */     this.sqlKind = paramSqlKind;
/*  82 */     this.parameterSql = paramString;
/*  83 */     this.parameterCount = paramInt;
/*     */     
/*  85 */     this.needToParseSql = true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  91 */   private static final int[][] TRANSITION = OracleParameterMetaDataParserStates.TRANSITION;
/*     */ 
/*     */   
/*  94 */   private static final int[][] ACTION = OracleParameterMetaDataParserStates.ACTION;
/*     */   
/*     */   private static final int NO_ACTION = 0;
/*     */   
/*     */   private static final int WHERE_ACTION = 2;
/*     */   
/*     */   private static final int PARAMETER_ACTION = 3;
/*     */   
/*     */   private static final int END_PARAMETER_ACTION = 4;
/*     */   
/*     */   private static final int COUNT_BIND_ACTION = 5;
/*     */   
/*     */   private static final int START_NCHAR_LITERAL_ACTION = 6;
/*     */   
/*     */   private static final int END_NCHAR_LITERAL_ACTION = 7;
/*     */   
/*     */   private static final int SAVE_DELIMITER_ACTION = 8;
/*     */   
/*     */   private static final int LOOK_FOR_DELIMITER_ACTION = 9;
/*     */   
/*     */   private static final int RECORD_TABLE_NAME_ACTION = 10;
/*     */   
/*     */   private static final int END_RECORD_TABLE_NAME_ACTION = 11;
/*     */   private static final int DONE_RECORD_TABLE_NAME_ACTION = 12;
/*     */   private static final int START_RECORD_COLUMN_NAME_ACTION = 13;
/*     */   private static final int RECORD_COLUMN_NAME_ACTION = 14;
/*     */   private static final int END_RECORD_COLUMN_NAME_ACTION = 15;
/*     */   private static final int DONE_RECORD_COLUMN_NAME_ACTION = 16;
/*     */   private static final int NO_PARAMETER_METADATA_ACTION = 17;
/*     */   private static final int BEGIN_COMMENT_ACTION = 18;
/*     */   private static final int END_COMMENT_ACTION = 19;
/*     */   private static final int RESET_RECORDING_ACTION = 20;
/*     */   private static final int INITIAL_STATE = 0;
/*     */   private static final int RESTART_STATE = 22;
/*     */   private static final boolean DEBUG_CBI = false;
/*     */   ArrayList<String> tableName;
/*     */   ArrayList<String> columnName;
/*     */   byte[] bindStatusForInsert;
/*     */   char[] currentParameter;
/*     */   
/*     */   protected OracleParameterMetaDataParser() {
/* 135 */     this.tableName = new ArrayList<>();
/* 136 */     this.columnName = new ArrayList<>();
/* 137 */     this.bindStatusForInsert = null;
/* 138 */     this.currentParameter = null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   void computeBasicInfo(String paramString) throws SQLException {
/* 144 */     byte b = 0;
/*     */     
/* 146 */     boolean bool1 = false;
/*     */     
/* 148 */     byte b1 = 0;
/*     */     
/* 150 */     int i = 0;
/* 151 */     int j = paramString.length();
/* 152 */     int k = j + 1;
/*     */     
/* 154 */     char[] arrayOfChar = new char[128];
/* 155 */     byte b2 = 0;
/* 156 */     byte b3 = 0;
/* 157 */     this.columnName.clear();
/* 158 */     this.tableName.clear();
/* 159 */     boolean bool2 = false;
/* 160 */     boolean bool3 = false;
/* 161 */     boolean bool4 = false;
/* 162 */     byte b4 = 0;
/* 163 */     byte b5 = 0;
/* 164 */     boolean bool5 = true;
/* 165 */     int m = -1;
/*     */     
/* 167 */     this.bindStatusForInsert = null;
/*     */ 
/*     */ 
/*     */     
/* 171 */     for (byte b6 = 0; b6 < k; b6++) {
/*     */       
/* 173 */       byte b7 = (b6 < j) ? paramString.charAt(b6) : 32;
/* 174 */       byte b8 = b7;
/*     */       
/* 176 */       if (b7 > 127)
/*     */       {
/*     */         
/* 179 */         if (Character.isLetterOrDigit(b7)) {
/* 180 */           b8 = 88;
/*     */         } else {
/* 182 */           b8 = 32;
/*     */         } 
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 199 */       switch (ACTION[i][b8]) {
/*     */ 
/*     */         
/*     */         case 18:
/* 203 */           m = i;
/* 204 */           i = (b8 == 47) ? 18 : 20;
/*     */ 
/*     */         
/*     */         case 19:
/* 208 */           i = m;
/* 209 */           m = -1;
/*     */           break;
/*     */         
/*     */         case 20:
/* 213 */           b3 = 0;
/* 214 */           b2 = 0;
/* 215 */           m = 68;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         case 0:
/* 362 */           i = TRANSITION[i][b8]; break;case 2: b2 -= true;case 3: if (b3) { String str = new String(arrayOfChar, 0, b3); if (str.trim().length() > 0) this.columnName.add(str);  }  b3 = 0; if (!b1) b4 = b6;  b1++; bool2 = true;case 5: if (bool2) { if (this.bindStatusForInsert == null) { int n = Math.max(50, b >> 1); this.bindStatusForInsert = new byte[n]; } else if (b >= this.bindStatusForInsert.length) { byte[] arrayOfByte = new byte[this.bindStatusForInsert.length << 1]; System.arraycopy(this.bindStatusForInsert, 0, arrayOfByte, 0, this.bindStatusForInsert.length); this.bindStatusForInsert = arrayOfByte; }  this.bindStatusForInsert[b] = 1; }  b5 = b6; b++; bool2 = false;case 4: bool2 = false; b1 = 0;case 10: arrayOfChar[b2++] = b8;case 11: if (b2 > 0) { String str = (new String(arrayOfChar, 0, b2)).trim(); if (str.length() > 0) this.tableName.add(str);  }  b2 = 0;case 12: if (b2 > 0) { String str = (new String(arrayOfChar, 0, b2)).trim(); if (str.length() > 0) this.tableName.add(str);  b2 = 0; } case 13: if (b2 > 0) { String str = (new String(arrayOfChar, 0, b2)).trim(); if (str.length() > 0) this.tableName.add(str);  b2 = 0; }  if (this.tableName.isEmpty()) { bool5 = false; } else if (this.sqlKind != OracleStatement.SqlKind.INSERT) { b3 = 0; arrayOfChar[b3++] = b8; } case 14: arrayOfChar[b3++] = b8;case 15: if (bool5) { if (b3 > 0) { String str = new String(arrayOfChar, 0, b3); if (str.trim().length() > 0) this.columnName.add(str);  }  b3 = 0; } case 16: if (bool5) { if (b3 > 0) { String str = new String(arrayOfChar, 0, b3); if (str.trim().length() > 0) this.columnName.add(str);  }  b3 = 0; } case 17: bool5 = false;default: i = TRANSITION[i][b8]; break;
/*     */       } 
/*     */     } 
/* 365 */     if (bool5) {
/*     */       
/* 367 */       if (this.sqlKind == OracleStatement.SqlKind.INSERT && b5 < b4) {
/*     */ 
/*     */         
/* 370 */         if (this.bindStatusForInsert == null) {
/*     */           
/* 372 */           this.bindStatusForInsert = new byte[50];
/* 373 */         } else if (b >= this.bindStatusForInsert.length) {
/*     */           
/* 375 */           byte[] arrayOfByte = new byte[this.bindStatusForInsert.length << 1];
/* 376 */           System.arraycopy(this.bindStatusForInsert, 0, arrayOfByte, 0, this.bindStatusForInsert.length);
/*     */ 
/*     */           
/* 379 */           this.bindStatusForInsert = arrayOfByte;
/*     */         } 
/* 381 */         this.bindStatusForInsert[b++] = 1;
/*     */       } 
/*     */     } else {
/* 384 */       if (!this.tableName.isEmpty()) this.tableName.clear(); 
/* 385 */       if (!this.columnName.isEmpty()) this.columnName.clear(); 
/* 386 */       this.bindStatusForInsert = null;
/* 387 */       b = -1;
/*     */     } 
/*     */ 
/*     */     
/* 391 */     this.needToParseSql = false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   String[] getColumnNames() {
/* 415 */     String[] arrayOfString = new String[this.columnName.size()];
/* 416 */     return this.columnName.<String>toArray(arrayOfString);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   String[] getTableNames() {
/* 423 */     String[] arrayOfString = new String[this.tableName.size()];
/* 424 */     return this.tableName.<String>toArray(arrayOfString);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getParameterMetaDataSql() throws SQLException {
/* 432 */     if (this.needToParseSql) computeBasicInfo(this.parameterSql);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 437 */     if (this.sqlKind.isPlsqlOrCall() || this.parameterCount == 0) {
/* 438 */       return null;
/*     */     }
/* 440 */     String[] arrayOfString1 = getTableNames();
/* 441 */     if (arrayOfString1 == null || arrayOfString1.length == 0) {
/* 442 */       return null;
/*     */     }
/* 444 */     String[] arrayOfString2 = getColumnNames();
/* 445 */     StringBuilder stringBuilder = new StringBuilder(100);
/* 446 */     stringBuilder.append("SELECT ");
/*     */     
/* 448 */     if (arrayOfString2.length == 0) {
/*     */       
/* 450 */       if (this.sqlKind == OracleStatement.SqlKind.INSERT) {
/*     */         
/* 452 */         stringBuilder.append("* ");
/*     */       } else {
/*     */         
/* 455 */         return null;
/*     */       }
/*     */     
/*     */     } else {
/*     */       
/* 460 */       boolean bool = (this.bindStatusForInsert != null) ? true : false;
/* 461 */       byte b1 = 0;
/* 462 */       for (byte b2 = 0; b2 < arrayOfString2.length; b2++) {
/*     */         
/* 464 */         if (!bool || this.bindStatusForInsert[b2] == 1) {
/*     */ 
/*     */           
/* 467 */           if (b1++ != 0)
/* 468 */             stringBuilder.append(", "); 
/* 469 */           stringBuilder.append(arrayOfString2[b2]);
/*     */         } 
/*     */       } 
/* 472 */     }  stringBuilder.append(" FROM ");
/* 473 */     for (byte b = 0; b < arrayOfString1.length; b++) {
/*     */       
/* 475 */       if (b != 0)
/* 476 */         stringBuilder.append(", "); 
/* 477 */       stringBuilder.append(arrayOfString1[b]);
/*     */     } 
/* 479 */     return stringBuilder.substring(0, stringBuilder.length());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean needBindStatusForParameterMetaData() throws SQLException {
/* 487 */     return (this.columnName.size() > 0 && this.parameterCount > 0 && this.bindStatusForInsert != null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   byte[] getBindStatusForInsert() {
/* 496 */     return this.bindStatusForInsert;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void main(String[] paramArrayOfString) {
/* 504 */     String[] arrayOfString = null;
/* 505 */     if (paramArrayOfString.length < 1) {
/* 506 */       System.err.println("ERROR: incorrect usage. OracleParameterMetaDataParser <-test| sql >"); return;
/*     */     } 
/* 508 */     if ("-test".equals(paramArrayOfString[0])) {
/*     */       
/* 510 */       arrayOfString = new String[] { "insert into JAVA_KEYWORDS (\"ABSTRACT\",\"ASSERT\",\"BOOLEAN\",\"BREAK\",\"BYTE\",\"CASE\",\"CATCH\",\"CHAR\",\"CLASS\",\"CONST \",\"CONTINUE\",\"DEFAULT\",\"DO\",\"DOUBLE\",\"ELSE\",\"ENUM \",\"EXTENDS\",\"FINAL\",\"FINALLY\",\"FLOAT\",\"FOR\",\"GOTO \",\"IF\",\"IMPLEMENTS\",\"IMPORT\",\"INSTANCEOF\",\"INT\",\"INTERFACE\",\"LONG\",\"NATIVE\",\"NEW\",\"PACKAGE\",\"PRIVATE\",\"PROTECTED\",\"PUBLIC\",\"RETU RN\",\"SHORT\",\"STATIC\",\"STRICTFP \",\"SUPER\",\"SWITCH\",\"SYNCHRONIZED\",\"THIS\",\"THROW\",\"THROWS\",\"TRANS IENT\",\"TRY\",\"VOID\",\"VOLATILE\",\"WHILE\", \"ID\") values (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?  ,?,?,?,?,?,?,?,?,?,?,?,?)", "INSERT INTO emp(empno,ename,sal) VALUES(:B1, :b2, :b3)", "INSERT INTO T1 VALUES(:BIND1, :bind2)", "begin INSERT INTO T1 VALUES(:BIND1, :bind2); end;", "UPDATE T1 SET  C1 = :B1 and c2 = :b2 and c3 = 'abc'", "UPDATE T1 SET C1 = :B1 and  c2 = :b2 and c3 = 'abc'", "UPDATE T1 SET    C1 = :B1 and    c2 = :b2 and    c3 = 'abc' and c4 = :b4", "SELECT ename from emp where empno = :a1 and sal = :a2", "DELETE FROM EMP WHERE EMPNO>:x", "DELETE FROM EMP WHERE EMPNO   >   :1", "DELETE FROM EMP WHERE EMPNO\n>\n:2", "DELETE FROM EMP WHERE EMPNO\n<>\n:3", "DELETE FROM EMP WHERE EMPNO\n<>\n'abc'", "SELECT ename, d.deptno from emp e, dept d where empno = ?  and sal = ? and e.deptno = d.deptno", "SELECT ename, d.deptno from emp e, dept d where empno = :a1 and sal = :a2 and e.deptno = d.deptno", "SELECT ename, deptno   from    emp   , dept    where    empno =    :a1 and   sal = :a2", "SELECT * FROM TKPJST58_TAB WHERE C1 = :2", "SELECT * FROM TKPJST58_TAB WHERE C1 is null and c2 = :1 and c3 = :4", "SELECT * FROM TKPJST58_TAB WHERE C1 is NULL  AND C2 = :1   AND C3 = :2   AND C4 = :3   AND C5 = :4   AND C6 = :5   AND C7 = :6   AND C8 = :7   AND C9 = :8   AND C10 = :9   AND C11 = :10   AND C12 = :11   AND C13 = :12   AND C14 = :13   AND C15 = :14   AND C16 is not null  AND C17 <> :15", "SELECT * FROM TKPJST58_TAB WHERE C1 = ?  AND C2 = ?  AND C3 = ?  AND C4 = ?  AND C5 = ?  AND C6 = ?  AND C7 = ?  AND C8 = ?  AND C9 = ?  AND C10 = ?  AND C11 = ?  AND C12 = ?  AND C13 = ?  AND C14 = ?  AND C15 = ?  AND C16 = ?  AND C17 = ?", "INSERT INTO TKPJST58_TAB(c1, c2, c3, c4, c5, c9, c14, c10) values (?,?,?,?,?,?,?,?)", "INSERT INTO TKPJST58_TAB values (12,'abc',?,?,?,?,?,?)", "INSERT INTO TKPJST58_TAB values (12,'abc',:1,:2,:3,:4,:5)", "INSERT INTO TKPJST58_TAB(c1,c2,c3,c4,c5,c6,c7) values (12,'abc',:1,:2,:3,:4,:5)", "INSERT INTO TKPJST58_TAB(c1,c2,c3,c4,c5,c6,c7) values (12,'abc',:1,:2,55,:4,:5)", "insert into rawtab values ('010203040506', '0708090a0b0c0d')", "begin insert into asciitab values (200,'21-sep-71',?,?,?); end;", "select col from dummy_tab where rowid=?", "SELECT * FROM test2 WHERE key >= ? ORDER BY key", "SELECT * FROM test2 WHERE key>=? ORDER BY key", "INSERT INTO tkpjb2354325_tab VALUES (111, {ts '1999-12-31 12:59:59'})", "SELECT user FROM dual WHERE  ? < { fn LOCATE('TEST123TEST', 1) }", "INSERT INTO tkpjb2354325_tab VALUES (111, {ts '1999-12-31 12:59:59'}, :3)", "delete from tkpjdg02_view where id >? returning id, name into ?, ?", "SELECT * FROM TABLE( CAST(? AS TYPE_VARCHAR_NT) )", "insert into (select t.col1 as column1, t.col2 as column2 from tkpjsc37 t  where t.col1 in (?,?,?,?)) values ( ?, ?)", "delete from tkpjdg02_view where id >? returning_id = ?", "insert into tkpjir93_tab values (?,q'!name LIKE '%DBMS_%%'!')", "insert into tkpjir93_tab values (?,q'{SELECT * FROM employees WHERE last_name = 'Smith';}'", "insert into xml_test values ('adf', '<?xml version=\"1.0\" encoding=\"UTF-8\"?><a></a>')", "SELECT * FROM test2 WHERE key>=? and ORDER_id=?  order BY key", "insert into emp(empno, ename, sal) values (?, N'abc', ?)", "UPDATE tkpjb5752856_tab SET c2=N'????C Mother''s Maiden Name????'", "INSERT INTO TKPJST58_TAB(c1, c2, c3, c4, c5, c9, c14, c10) values (12,'abc',?,?,?,?,?,?)", "UPDATE /*abc*/T1 SET/*xyz*/ C1 = :B1 /*nyl*/and/*bac*/ c2 = :b2 and c3 = 'abc'", "SELECT * FROM TKPJST58_TAB WHERE C1 is/*abc*/ null and c2 = :1 and c3 = :4", "SELECT * FROM TKPJST58_TAB WHERE C1 is/*abc*/not--xyz\n null and c2 = :1 and c3 = :4", "UPDATE TKPJST58_TAB/*comment1*/set/*comment2*/ C1 = ?  WHERE  C4 = /*abc*/? ", "UPDATE TKPJST58_TAB set C1 = ?  and c2 = ? WHERE  C4 = /*abc*/? and c5 = ?" };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     }
/*     */     else {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 573 */       arrayOfString = paramArrayOfString;
/*     */     } 
/*     */     
/* 576 */     for (String str : arrayOfString) {
/*     */       try {
/* 578 */         OracleSql oracleSql = new OracleSql(null);
/* 579 */         oracleSql.initialize(str);
/* 580 */         String str1 = oracleSql.getSql(true, true);
/*     */         
/* 582 */         System.err.println("SQL:" + str1);
/* 583 */         System.err.println("  SqlKind:" + oracleSql.sqlKind + ", Parameter Count=" + oracleSql.parameterCount);
/* 584 */         if (!oracleSql.sqlKind.isPlsqlOrCall() && oracleSql.parameterCount > 0) {
/*     */           
/* 586 */           OracleParameterMetaDataParser oracleParameterMetaDataParser = new OracleParameterMetaDataParser();
/*     */           
/* 588 */           oracleParameterMetaDataParser.initialize(str1, oracleSql.sqlKind, oracleSql.parameterCount);
/* 589 */           System.err.println("  Parameter SQL: " + oracleParameterMetaDataParser.getParameterMetaDataSql());
/*     */         }
/*     */         else {
/*     */           
/* 593 */           System.err.println("  Cannot get Parameter MetaData");
/*     */         } 
/* 595 */         System.err.println("\n");
/*     */       
/*     */       }
/* 598 */       catch (Exception exception) {
/* 599 */         System.out.println(exception);
/* 600 */         exception.printStackTrace();
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   private static final void dumpTransitionMatrix(String paramString) {
/*     */     try {
/* 607 */       PrintWriter printWriter = new PrintWriter(paramString);
/* 608 */       printWriter.print(",");
/* 609 */       for (byte b1 = 0; b1 < ''; ) { printWriter.print("'" + ((b1 < 32) ? ("0x" + Integer.toHexString(b1)) : Character.toString((char)b1)) + ((b1 < 127) ? "'," : "'")); b1++; }
/* 610 */        printWriter.println();
/* 611 */       int[][] arrayOfInt = OracleParameterMetaDataParserStates.TRANSITION;
/* 612 */       String[] arrayOfString = OracleParameterMetaDataParserStates.PARSER_STATE_NAME;
/* 613 */       for (byte b2 = 0; b2 < TRANSITION.length; b2++) {
/* 614 */         printWriter.print(arrayOfString[b2] + ",");
/* 615 */         for (byte b = 0; b < (arrayOfInt[b2]).length; ) { printWriter.print(arrayOfString[arrayOfInt[b2][b]] + ((b < 127) ? "," : "")); b++; }
/* 616 */          printWriter.println();
/*     */       } 
/* 618 */       printWriter.close();
/*     */     }
/* 620 */     catch (Throwable throwable) {
/* 621 */       System.err.println(throwable);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected OracleConnection getConnectionDuringExceptionHandling() {
/* 638 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/* 643 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*     */   public static final String BUILD_DATE = "Thu_Apr_04_15:09:24_PDT_2013";
/*     */   public static final boolean TRACE = false;
/*     */ }


/* Location:              C:\Users\olatu\OneDrive\Documents\Calypso\syncbase\sync_base.jar!\BOOT-INF\lib\ojdbc-7.jar!\oracle\jdbc\driver\OracleParameterMetaDataParser.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */