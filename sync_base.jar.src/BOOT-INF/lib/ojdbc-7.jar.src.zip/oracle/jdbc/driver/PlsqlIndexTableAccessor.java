/*     */ package oracle.jdbc.driver;
/*     */ 
/*     */ import java.math.BigDecimal;
/*     */ import java.sql.SQLException;
/*     */ import oracle.sql.CHAR;
/*     */ import oracle.sql.CharacterSet;
/*     */ import oracle.sql.Datum;
/*     */ import oracle.sql.NUMBER;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class PlsqlIndexTableAccessor
/*     */   extends Accessor
/*     */ {
/*     */   static final int MAXLENGTH = -1;
/*     */   PlsqlIbtBindInfo ibtBindInfo;
/*     */   
/*     */   PlsqlIndexTableAccessor(OracleStatement paramOracleStatement, PlsqlIbtBindInfo paramPlsqlIbtBindInfo, short paramShort) throws SQLException {
/*  30 */     super(Representation.PLSQL_INDEX_TABLE, paramOracleStatement, -1, true);
/*     */     
/*  32 */     init(paramOracleStatement, 998, 998, paramShort, true);
/*  33 */     this.ibtBindInfo = paramPlsqlIbtBindInfo;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void initForDataAccess(int paramInt1, int paramInt2, String paramString) throws SQLException {
/*  41 */     unimpl("initForDataAccess");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   PlsqlIbtBindInfo plsqlIndexTableBindInfo() throws SQLException {
/*  48 */     return this.ibtBindInfo;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Object[] getPlsqlIndexTable(int paramInt) throws SQLException {
/*     */     String[] arrayOfString;
/*     */     BigDecimal[] arrayOfBigDecimal;
/*     */     byte b;
/*     */     SQLException sQLException;
/*  66 */     this.rowData.setPosition(getOffset(paramInt));
/*  67 */     int i = this.rowData.getInt();
/*     */     
/*  69 */     switch (this.ibtBindInfo.element_internal_type) {
/*     */       
/*     */       case 9:
/*  72 */         arrayOfString = new String[i];
/*  73 */         for (b = 0; b < i; b++) {
/*  74 */           int j = this.rowData.getShort();
/*  75 */           if (j == 0) { arrayOfString[b] = null; }
/*  76 */           else { arrayOfString[b] = this.rowData.getString(j, this.statement.connection.conversion.getCharacterSet((short)1)); }
/*     */         
/*     */         } 
/*     */         break;
/*     */       
/*     */       case 6:
/*  82 */         arrayOfBigDecimal = new BigDecimal[i];
/*  83 */         for (b = 0; b < i; b++) {
/*  84 */           int j = this.rowData.getShort();
/*  85 */           if (j == 0) { arrayOfBigDecimal[b] = null; }
/*  86 */           else { arrayOfBigDecimal[b] = NUMBER.toBigDecimal(this.rowData.getBytes(j)); }
/*     */         
/*     */         } 
/*     */         break;
/*     */       
/*     */       default:
/*  92 */         sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 97);
/*  93 */         sQLException.fillInStackTrace();
/*  94 */         throw sQLException;
/*     */     } 
/*     */ 
/*     */     
/*  98 */     assert this.rowData.getPosition() == getOffset(paramInt) + getLength(paramInt) : "rowData.position(): " + this.rowData.getPosition() + " getOffset(" + paramInt + "): " + getOffset(paramInt) + " getLength(" + paramInt + "): " + getLength(paramInt);
/*     */     
/* 100 */     return (Object[])arrayOfBigDecimal;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Datum[] getOraclePlsqlIndexTable(int paramInt) throws SQLException {
/*     */     NUMBER[] arrayOfNUMBER;
/*     */     CharacterSet characterSet;
/*     */     byte b;
/*     */     SQLException sQLException;
/* 118 */     this.rowData.setPosition(getOffset(paramInt));
/* 119 */     CHAR[] arrayOfCHAR = null;
/* 120 */     int i = this.rowData.getInt();
/* 121 */     switch (this.ibtBindInfo.element_internal_type) {
/*     */       
/*     */       case 9:
/* 124 */         arrayOfCHAR = new CHAR[i];
/* 125 */         characterSet = this.statement.connection.conversion.getDriverCharSetObj();
/* 126 */         for (b = 0; b < i; b++) {
/* 127 */           int j = this.rowData.getShort();
/* 128 */           if (j == 0) { arrayOfCHAR[b] = null; }
/* 129 */           else { arrayOfCHAR[b] = new CHAR(this.rowData.getBytes(j), characterSet); }
/*     */         
/*     */         } 
/*     */         break;
/*     */       case 6:
/* 134 */         arrayOfNUMBER = new NUMBER[i];
/* 135 */         for (b = 0; b < i; b++) {
/* 136 */           int j = this.rowData.getShort();
/* 137 */           if (j == 0) { arrayOfNUMBER[b] = null; }
/* 138 */           else { arrayOfNUMBER[b] = new NUMBER(this.rowData.getBytes(j)); }
/*     */         
/*     */         } 
/*     */         break;
/*     */       
/*     */       default:
/* 144 */         sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 97);
/* 145 */         sQLException.fillInStackTrace();
/* 146 */         throw sQLException;
/*     */     } 
/*     */ 
/*     */     
/* 150 */     assert this.rowData.getPosition() == getOffset(paramInt) + getLength(paramInt) : "rowData.position(): " + this.rowData.getPosition() + " getOffset(" + paramInt + "): " + getOffset(paramInt) + " getLength(" + paramInt + "): " + getLength(paramInt);
/*     */     
/* 152 */     return (Datum[])arrayOfNUMBER;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 158 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*     */   public static final String BUILD_DATE = "Thu_Apr_04_15:09:24_PDT_2013";
/*     */   public static final boolean TRACE = false;
/*     */ }


/* Location:              C:\Users\olatu\OneDrive\Documents\Calypso\syncbase\sync_base.jar!\BOOT-INF\lib\ojdbc-7.jar!\oracle\jdbc\driver\PlsqlIndexTableAccessor.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */