/*     */ package oracle.jdbc.driver;
/*     */ 
/*     */ import java.sql.SQLException;
/*     */ import java.sql.Timestamp;
/*     */ import oracle.jdbc.aq.AQAgent;
/*     */ import oracle.jdbc.aq.AQMessageProperties;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class AQMessagePropertiesI
/*     */   implements AQMessageProperties
/*     */ {
/*  68 */   private int attrAttempts = -1;
/*  69 */   private String attrCorrelation = null;
/*  70 */   private int attrDelay = 0;
/*  71 */   private Timestamp attrEnqTime = null;
/*  72 */   private String attrExceptionQueue = null;
/*  73 */   private int attrExpiration = -1;
/*  74 */   private AQMessageProperties.MessageState attrMsgState = null;
/*  75 */   private int attrPriority = 0;
/*  76 */   private AQAgentI[] attrRecipientList = null;
/*  77 */   private AQAgentI attrSenderId = null;
/*  78 */   private String attrTransactionGroup = null;
/*  79 */   private byte[] attrPreviousQueueMsgId = null;
/*  80 */   private AQMessageProperties.DeliveryMode deliveryMode = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getDequeueAttemptsCount() {
/*  93 */     return this.attrAttempts;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setCorrelation(String paramString) throws SQLException {
/* 106 */     this.attrCorrelation = paramString;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getCorrelation() {
/* 118 */     return this.attrCorrelation;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDelay(int paramInt) throws SQLException {
/* 130 */     this.attrDelay = paramInt;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getDelay() {
/* 142 */     return this.attrDelay;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Timestamp getEnqueueTime() {
/* 154 */     return this.attrEnqTime;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setExceptionQueue(String paramString) throws SQLException {
/* 167 */     this.attrExceptionQueue = paramString;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getExceptionQueue() {
/* 179 */     return this.attrExceptionQueue;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setExpiration(int paramInt) throws SQLException {
/* 192 */     this.attrExpiration = paramInt;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getExpiration() {
/* 204 */     return this.attrExpiration;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AQMessageProperties.MessageState getState() {
/* 216 */     return this.attrMsgState;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setPriority(int paramInt) throws SQLException {
/* 228 */     this.attrPriority = paramInt;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getPriority() {
/* 240 */     return this.attrPriority;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setRecipientList(AQAgent[] paramArrayOfAQAgent) throws SQLException {
/* 253 */     if (paramArrayOfAQAgent == null) {
/*     */       
/* 255 */       this.attrRecipientList = null;
/*     */     }
/*     */     else {
/*     */       
/* 259 */       this.attrRecipientList = new AQAgentI[paramArrayOfAQAgent.length];
/* 260 */       for (byte b = 0; b < paramArrayOfAQAgent.length; b++) {
/* 261 */         this.attrRecipientList[b] = (AQAgentI)paramArrayOfAQAgent[b];
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AQAgent[] getRecipientList() {
/* 274 */     return (AQAgent[])this.attrRecipientList;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSender(AQAgent paramAQAgent) throws SQLException {
/* 286 */     this.attrSenderId = (AQAgentI)paramAQAgent;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AQAgent getSender() {
/* 298 */     return this.attrSenderId;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getTransactionGroup() {
/* 310 */     return this.attrTransactionGroup;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void setTransactionGroup(String paramString) {
/* 317 */     this.attrTransactionGroup = paramString;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void setPreviousQueueMessageId(byte[] paramArrayOfbyte) {
/* 324 */     this.attrPreviousQueueMsgId = paramArrayOfbyte;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] getPreviousQueueMessageId() {
/* 336 */     return this.attrPreviousQueueMsgId;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AQMessageProperties.DeliveryMode getDeliveryMode() {
/* 348 */     return this.deliveryMode;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void setDeliveryMode(AQMessageProperties.DeliveryMode paramDeliveryMode) {
/* 355 */     this.deliveryMode = paramDeliveryMode;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 398 */     StringBuffer stringBuffer = new StringBuffer();
/* 399 */     stringBuffer.append("Correlation             : " + getCorrelation() + "\n");
/* 400 */     Timestamp timestamp = getEnqueueTime();
/* 401 */     if (timestamp != null)
/* 402 */       stringBuffer.append("Enqueue time            : " + timestamp + "\n"); 
/* 403 */     stringBuffer.append("Exception Queue         : " + getExceptionQueue() + "\n");
/* 404 */     stringBuffer.append("Sender                  : (" + getSender() + ")\n");
/* 405 */     int i = getDequeueAttemptsCount();
/* 406 */     if (i != -1)
/* 407 */       stringBuffer.append("Attempts                : " + i + "\n"); 
/* 408 */     stringBuffer.append("Delay                   : " + getDelay() + "\n");
/* 409 */     stringBuffer.append("Expiration              : " + getExpiration() + "\n");
/* 410 */     AQMessageProperties.MessageState messageState = getState();
/*     */     
/* 412 */     if (messageState != null)
/* 413 */       stringBuffer.append("State                   : " + messageState + "\n"); 
/* 414 */     stringBuffer.append("Priority                : " + getPriority() + "\n");
/* 415 */     AQMessageProperties.DeliveryMode deliveryMode = getDeliveryMode();
/*     */     
/* 417 */     if (deliveryMode != null)
/* 418 */       stringBuffer.append("Delivery Mode           : " + deliveryMode + "\n"); 
/* 419 */     stringBuffer.append("Recipient List          : {");
/* 420 */     AQAgent[] arrayOfAQAgent = getRecipientList();
/* 421 */     if (arrayOfAQAgent != null)
/*     */     {
/* 423 */       for (byte b = 0; b < arrayOfAQAgent.length; b++) {
/*     */         
/* 425 */         stringBuffer.append(arrayOfAQAgent[b]);
/* 426 */         if (b != arrayOfAQAgent.length - 1)
/* 427 */           stringBuffer.append("; "); 
/*     */       } 
/*     */     }
/* 430 */     stringBuffer.append("}");
/*     */     
/* 432 */     return stringBuffer.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void setAttempts(int paramInt) throws SQLException {
/* 439 */     this.attrAttempts = paramInt;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void setEnqueueTime(Timestamp paramTimestamp) throws SQLException {
/* 448 */     this.attrEnqTime = paramTimestamp;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void setMessageState(AQMessageProperties.MessageState paramMessageState) throws SQLException {
/* 456 */     this.attrMsgState = paramMessageState;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/* 461 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*     */   public static final String BUILD_DATE = "Thu_Apr_04_15:09:24_PDT_2013";
/*     */   public static final boolean TRACE = false;
/*     */ }


/* Location:              C:\Users\olatu\OneDrive\Documents\Calypso\syncbase\sync_base.jar!\BOOT-INF\lib\ojdbc-7.jar!\oracle\jdbc\driver\AQMessagePropertiesI.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */