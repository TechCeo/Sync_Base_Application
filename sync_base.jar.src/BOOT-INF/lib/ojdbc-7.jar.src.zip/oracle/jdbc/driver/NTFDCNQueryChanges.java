/*     */ package oracle.jdbc.driver;
/*     */ 
/*     */ import java.nio.ByteBuffer;
/*     */ import oracle.jdbc.dcn.QueryChangeDescription;
/*     */ import oracle.jdbc.dcn.TableChangeDescription;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class NTFDCNQueryChanges
/*     */   implements QueryChangeDescription
/*     */ {
/*     */   private final long queryId;
/*     */   private final QueryChangeDescription.QueryChangeEventType queryopflags;
/*     */   private final int numberOfTables;
/*     */   private final NTFDCNTableChanges[] tcdesc;
/*     */   
/*     */   NTFDCNQueryChanges(ByteBuffer paramByteBuffer, int paramInt) {
/*  50 */     long l1 = (paramByteBuffer.getInt() & 0xFFFFFFFF);
/*  51 */     long l2 = (paramByteBuffer.getInt() & 0xFFFFFFFF);
/*  52 */     this.queryId = l1 | l2 << 32L;
/*  53 */     this.queryopflags = QueryChangeDescription.QueryChangeEventType.getQueryChangeEventType(paramByteBuffer.getInt());
/*  54 */     this.numberOfTables = paramByteBuffer.getShort();
/*  55 */     this.tcdesc = new NTFDCNTableChanges[this.numberOfTables];
/*  56 */     for (byte b = 0; b < this.tcdesc.length; b++) {
/*  57 */       this.tcdesc[b] = new NTFDCNTableChanges(paramByteBuffer, paramInt);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public long getQueryId() {
/*  64 */     return this.queryId;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public QueryChangeDescription.QueryChangeEventType getQueryChangeEventType() {
/*  71 */     return this.queryopflags;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TableChangeDescription[] getTableChangeDescription() {
/*  78 */     return (TableChangeDescription[])this.tcdesc;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/*  90 */     StringBuffer stringBuffer = new StringBuffer();
/*  91 */     stringBuffer.append("  query ID=" + this.queryId + ", query change event type=" + this.queryopflags + "\n");
/*  92 */     TableChangeDescription[] arrayOfTableChangeDescription = getTableChangeDescription();
/*  93 */     if (arrayOfTableChangeDescription != null) {
/*     */       
/*  95 */       stringBuffer.append("  Table Change Description (length=" + arrayOfTableChangeDescription.length + "):");
/*  96 */       for (byte b = 0; b < arrayOfTableChangeDescription.length; b++)
/*  97 */         stringBuffer.append(arrayOfTableChangeDescription[b].toString()); 
/*     */     } 
/*  99 */     return stringBuffer.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/* 104 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*     */   public static final String BUILD_DATE = "Thu_Apr_04_15:09:24_PDT_2013";
/*     */   public static final boolean TRACE = false;
/*     */ }


/* Location:              C:\Users\olatu\OneDrive\Documents\Calypso\syncbase\sync_base.jar!\BOOT-INF\lib\ojdbc-7.jar!\oracle\jdbc\driver\NTFDCNQueryChanges.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */