/*    */ package oracle.jdbc.driver;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.sql.SQLException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class T4CTTIkpdnrgnc
/*    */ {
/*    */   byte[] kpdnrgnclsc;
/*    */   T4CMAREngine mar;
/*    */   
/*    */   T4CTTIkpdnrgnc(T4CConnection paramT4CConnection) {
/* 37 */     this.mar = paramT4CConnection.mare;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   void receive() throws SQLException, IOException {
/* 44 */     int i = this.mar.unmarshalSWORD();
/* 45 */     if (i > 0) {
/* 46 */       this.kpdnrgnclsc = new byte[i];
/* 47 */       int[] arrayOfInt = new int[1];
/*    */       
/* 49 */       this.mar.unmarshalCLR(this.kpdnrgnclsc, 0, arrayOfInt, i);
/*    */     } else {
/*    */       
/* 52 */       this.kpdnrgnclsc = null;
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public byte[] getKpdnrgnclsc() {
/* 63 */     return this.kpdnrgnclsc;
/*    */   }
/*    */ 
/*    */   
/* 67 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*    */   public static final String BUILD_DATE = "Thu_Apr_04_15:09:24_PDT_2013";
/*    */   public static final boolean TRACE = false;
/*    */ }


/* Location:              C:\Users\olatu\OneDrive\Documents\Calypso\syncbase\sync_base.jar!\BOOT-INF\lib\ojdbc-7.jar!\oracle\jdbc\driver\T4CTTIkpdnrgnc.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */