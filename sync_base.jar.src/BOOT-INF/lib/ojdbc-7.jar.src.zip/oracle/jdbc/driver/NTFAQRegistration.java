/*     */ package oracle.jdbc.driver;
/*     */ 
/*     */ import java.sql.SQLException;
/*     */ import java.util.EventListener;
/*     */ import java.util.Properties;
/*     */ import java.util.concurrent.Executor;
/*     */ import oracle.jdbc.aq.AQNotificationListener;
/*     */ import oracle.jdbc.aq.AQNotificationRegistration;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class NTFAQRegistration
/*     */   extends NTFRegistration
/*     */   implements AQNotificationRegistration
/*     */ {
/*     */   private final String name;
/*     */   
/*     */   NTFAQRegistration(int paramInt1, boolean paramBoolean, String paramString1, String paramString2, String paramString3, int paramInt2, Properties paramProperties, String paramString4, short paramShort) {
/*  58 */     super(paramInt1, 1, paramBoolean, paramString1, paramString3, paramInt2, paramProperties, paramString2, paramShort);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  68 */     this.name = paramString4;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addListener(AQNotificationListener paramAQNotificationListener, Executor paramExecutor) throws SQLException {
/*  83 */     NTFEventListener nTFEventListener = new NTFEventListener(paramAQNotificationListener);
/*  84 */     nTFEventListener.setExecutor(paramExecutor);
/*  85 */     addListener(nTFEventListener);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addListener(AQNotificationListener paramAQNotificationListener) throws SQLException {
/*  99 */     NTFEventListener nTFEventListener = new NTFEventListener(paramAQNotificationListener);
/* 100 */     addListener(nTFEventListener);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void removeListener(AQNotificationListener paramAQNotificationListener) throws SQLException {
/* 113 */     removeListener((EventListener)paramAQNotificationListener);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getQueueName() {
/* 125 */     return this.name;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/* 130 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*     */   public static final String BUILD_DATE = "Thu_Apr_04_15:09:24_PDT_2013";
/*     */   public static final boolean TRACE = false;
/*     */ }


/* Location:              C:\Users\olatu\OneDrive\Documents\Calypso\syncbase\sync_base.jar!\BOOT-INF\lib\ojdbc-7.jar!\oracle\jdbc\driver\NTFAQRegistration.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */