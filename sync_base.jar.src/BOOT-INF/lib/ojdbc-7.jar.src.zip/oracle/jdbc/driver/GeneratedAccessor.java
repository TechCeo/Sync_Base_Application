/*      */ package oracle.jdbc.driver;
/*      */ 
/*      */ import java.io.InputStream;
/*      */ import java.io.Reader;
/*      */ import java.math.BigDecimal;
/*      */ import java.math.BigInteger;
/*      */ import java.net.URL;
/*      */ import java.sql.Array;
/*      */ import java.sql.Blob;
/*      */ import java.sql.Clob;
/*      */ import java.sql.Date;
/*      */ import java.sql.NClob;
/*      */ import java.sql.Ref;
/*      */ import java.sql.ResultSet;
/*      */ import java.sql.RowId;
/*      */ import java.sql.SQLException;
/*      */ import java.sql.SQLXML;
/*      */ import java.sql.Struct;
/*      */ import java.sql.Time;
/*      */ import java.sql.Timestamp;
/*      */ import java.util.Calendar;
/*      */ import java.util.Date;
/*      */ import java.util.Map;
/*      */ import oracle.jdbc.OracleArray;
/*      */ import oracle.jdbc.OracleBfile;
/*      */ import oracle.jdbc.OracleBlob;
/*      */ import oracle.jdbc.OracleClob;
/*      */ import oracle.jdbc.OracleData;
/*      */ import oracle.jdbc.OracleDataFactory;
/*      */ import oracle.jdbc.OracleOpaque;
/*      */ import oracle.jdbc.OracleRef;
/*      */ import oracle.jdbc.internal.OracleConnection;
/*      */ import oracle.sql.ARRAY;
/*      */ import oracle.sql.BFILE;
/*      */ import oracle.sql.BINARY_DOUBLE;
/*      */ import oracle.sql.BINARY_FLOAT;
/*      */ import oracle.sql.BLOB;
/*      */ import oracle.sql.CHAR;
/*      */ import oracle.sql.CLOB;
/*      */ import oracle.sql.CustomDatum;
/*      */ import oracle.sql.CustomDatumFactory;
/*      */ import oracle.sql.DATE;
/*      */ import oracle.sql.Datum;
/*      */ import oracle.sql.INTERVALDS;
/*      */ import oracle.sql.INTERVALYM;
/*      */ import oracle.sql.NUMBER;
/*      */ import oracle.sql.OPAQUE;
/*      */ import oracle.sql.ORAData;
/*      */ import oracle.sql.ORADataFactory;
/*      */ import oracle.sql.RAW;
/*      */ import oracle.sql.REF;
/*      */ import oracle.sql.ROWID;
/*      */ import oracle.sql.STRUCT;
/*      */ import oracle.sql.TIMESTAMP;
/*      */ import oracle.sql.TIMESTAMPLTZ;
/*      */ import oracle.sql.TIMESTAMPTZ;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ abstract class GeneratedAccessor
/*      */ {
/*      */   OracleStatement statement;
/*      */   
/*      */   abstract boolean isNull(int paramInt) throws SQLException;
/*      */   
/*      */   Array getArray(int paramInt) throws SQLException {
/*  121 */     if (isNull(paramInt)) return null;
/*      */     
/*  123 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getArray not implemented for class " + getClass().getName());
/*  124 */     sQLException.fillInStackTrace();
/*  125 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   BigDecimal getBigDecimal(int paramInt) throws SQLException {
/*  145 */     if (isNull(paramInt)) return null;
/*      */     
/*  147 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getBigDecimal not implemented for class " + getClass().getName());
/*  148 */     sQLException.fillInStackTrace();
/*  149 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   BigDecimal getBigDecimal(int paramInt1, int paramInt2) throws SQLException {
/*  169 */     if (isNull(paramInt1)) return null;
/*      */     
/*  171 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getBigDecimal not implemented for class " + getClass().getName());
/*  172 */     sQLException.fillInStackTrace();
/*  173 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   Blob getBlob(int paramInt) throws SQLException {
/*  193 */     if (isNull(paramInt)) return null;
/*      */     
/*  195 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getBlob not implemented for class " + getClass().getName());
/*  196 */     sQLException.fillInStackTrace();
/*  197 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   boolean getBoolean(int paramInt) throws SQLException {
/*  217 */     if (isNull(paramInt)) return false;
/*      */     
/*  219 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getBoolean not implemented for class " + getClass().getName());
/*  220 */     sQLException.fillInStackTrace();
/*  221 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   byte getByte(int paramInt) throws SQLException {
/*  241 */     if (isNull(paramInt)) return 0;
/*      */     
/*  243 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getByte not implemented for class " + getClass().getName());
/*  244 */     sQLException.fillInStackTrace();
/*  245 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   byte[] getBytes(int paramInt) throws SQLException {
/*  265 */     if (isNull(paramInt)) return null;
/*      */     
/*  267 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getBytes not implemented for class " + getClass().getName());
/*  268 */     sQLException.fillInStackTrace();
/*  269 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   Clob getClob(int paramInt) throws SQLException {
/*  289 */     if (isNull(paramInt)) return null;
/*      */     
/*  291 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getClob not implemented for class " + getClass().getName());
/*  292 */     sQLException.fillInStackTrace();
/*  293 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   Date getDate(int paramInt) throws SQLException {
/*  313 */     if (isNull(paramInt)) return null;
/*      */     
/*  315 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getDate not implemented for class " + getClass().getName());
/*  316 */     sQLException.fillInStackTrace();
/*  317 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   Date getDate(int paramInt, Calendar paramCalendar) throws SQLException {
/*  337 */     if (isNull(paramInt)) return null;
/*      */     
/*  339 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getDate not implemented for class " + getClass().getName());
/*  340 */     sQLException.fillInStackTrace();
/*  341 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   double getDouble(int paramInt) throws SQLException {
/*  361 */     if (isNull(paramInt)) return 0.0D;
/*      */     
/*  363 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getDouble not implemented for class " + getClass().getName());
/*  364 */     sQLException.fillInStackTrace();
/*  365 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   float getFloat(int paramInt) throws SQLException {
/*  385 */     if (isNull(paramInt)) return 0.0F;
/*      */     
/*  387 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getFloat not implemented for class " + getClass().getName());
/*  388 */     sQLException.fillInStackTrace();
/*  389 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   int getInt(int paramInt) throws SQLException {
/*  409 */     if (isNull(paramInt)) return 0;
/*      */     
/*  411 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getInt not implemented for class " + getClass().getName());
/*  412 */     sQLException.fillInStackTrace();
/*  413 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   long getLong(int paramInt) throws SQLException {
/*  433 */     if (isNull(paramInt)) return 0L;
/*      */     
/*  435 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getLong not implemented for class " + getClass().getName());
/*  436 */     sQLException.fillInStackTrace();
/*  437 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   NClob getNClob(int paramInt) throws SQLException {
/*  457 */     if (isNull(paramInt)) return null;
/*      */     
/*  459 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getNClob not implemented for class " + getClass().getName());
/*  460 */     sQLException.fillInStackTrace();
/*  461 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   String getNString(int paramInt) throws SQLException {
/*  481 */     if (isNull(paramInt)) return null;
/*      */     
/*  483 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getNString not implemented for class " + getClass().getName());
/*  484 */     sQLException.fillInStackTrace();
/*  485 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   Object getObject(int paramInt) throws SQLException {
/*  505 */     if (isNull(paramInt)) return null;
/*      */     
/*  507 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getObject not implemented for class " + getClass().getName());
/*  508 */     sQLException.fillInStackTrace();
/*  509 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   Object getObject(int paramInt, Map paramMap) throws SQLException {
/*  529 */     if (isNull(paramInt)) return null;
/*      */     
/*  531 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getObject not implemented for class " + getClass().getName());
/*  532 */     sQLException.fillInStackTrace();
/*  533 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   Ref getRef(int paramInt) throws SQLException {
/*  553 */     if (isNull(paramInt)) return null;
/*      */     
/*  555 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getRef not implemented for class " + getClass().getName());
/*  556 */     sQLException.fillInStackTrace();
/*  557 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   RowId getRowId(int paramInt) throws SQLException {
/*  577 */     if (isNull(paramInt)) return null;
/*      */     
/*  579 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getRowId not implemented for class " + getClass().getName());
/*  580 */     sQLException.fillInStackTrace();
/*  581 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   short getShort(int paramInt) throws SQLException {
/*  601 */     if (isNull(paramInt)) return 0;
/*      */     
/*  603 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getShort not implemented for class " + getClass().getName());
/*  604 */     sQLException.fillInStackTrace();
/*  605 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   SQLXML getSQLXML(int paramInt) throws SQLException {
/*  625 */     if (isNull(paramInt)) return null;
/*      */     
/*  627 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getSQLXML not implemented for class " + getClass().getName());
/*  628 */     sQLException.fillInStackTrace();
/*  629 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   String getString(int paramInt) throws SQLException {
/*  649 */     if (isNull(paramInt)) return null;
/*      */     
/*  651 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getString not implemented for class " + getClass().getName());
/*  652 */     sQLException.fillInStackTrace();
/*  653 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   Struct getStruct(int paramInt) throws SQLException {
/*  673 */     if (isNull(paramInt)) return null;
/*      */     
/*  675 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getStruct not implemented for class " + getClass().getName());
/*  676 */     sQLException.fillInStackTrace();
/*  677 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   Time getTime(int paramInt) throws SQLException {
/*  697 */     if (isNull(paramInt)) return null;
/*      */     
/*  699 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getTime not implemented for class " + getClass().getName());
/*  700 */     sQLException.fillInStackTrace();
/*  701 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   Time getTime(int paramInt, Calendar paramCalendar) throws SQLException {
/*  721 */     if (isNull(paramInt)) return null;
/*      */     
/*  723 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getTime not implemented for class " + getClass().getName());
/*  724 */     sQLException.fillInStackTrace();
/*  725 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   Timestamp getTimestamp(int paramInt) throws SQLException {
/*  745 */     if (isNull(paramInt)) return null;
/*      */     
/*  747 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getTimestamp not implemented for class " + getClass().getName());
/*  748 */     sQLException.fillInStackTrace();
/*  749 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   Timestamp getTimestamp(int paramInt, Calendar paramCalendar) throws SQLException {
/*  769 */     if (isNull(paramInt)) return null;
/*      */     
/*  771 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getTimestamp not implemented for class " + getClass().getName());
/*  772 */     sQLException.fillInStackTrace();
/*  773 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   URL getURL(int paramInt) throws SQLException {
/*  793 */     if (isNull(paramInt)) return null;
/*      */     
/*  795 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getURL not implemented for class " + getClass().getName());
/*  796 */     sQLException.fillInStackTrace();
/*  797 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   BigInteger getBigInteger(int paramInt) throws SQLException {
/*  817 */     if (isNull(paramInt)) return null;
/*      */     
/*  819 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getBigInteger not implemented for class " + getClass().getName());
/*  820 */     sQLException.fillInStackTrace();
/*  821 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   Date getJavaUtilDate(int paramInt) throws SQLException {
/*  841 */     if (isNull(paramInt)) return null;
/*      */     
/*  843 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getJavaUtilDate not implemented for class " + getClass().getName());
/*  844 */     sQLException.fillInStackTrace();
/*  845 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   Calendar getCalendar(int paramInt) throws SQLException {
/*  865 */     if (isNull(paramInt)) return null;
/*      */     
/*  867 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getCalendar not implemented for class " + getClass().getName());
/*  868 */     sQLException.fillInStackTrace();
/*  869 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   ARRAY getARRAY(int paramInt) throws SQLException {
/*  889 */     if (isNull(paramInt)) return null;
/*      */     
/*  891 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getARRAY not implemented for class " + getClass().getName());
/*  892 */     sQLException.fillInStackTrace();
/*  893 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   BFILE getBFILE(int paramInt) throws SQLException {
/*  913 */     if (isNull(paramInt)) return null;
/*      */     
/*  915 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getBFILE not implemented for class " + getClass().getName());
/*  916 */     sQLException.fillInStackTrace();
/*  917 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   BFILE getBfile(int paramInt) throws SQLException {
/*  937 */     if (isNull(paramInt)) return null;
/*      */     
/*  939 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getBfile not implemented for class " + getClass().getName());
/*  940 */     sQLException.fillInStackTrace();
/*  941 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   BINARY_FLOAT getBINARY_FLOAT(int paramInt) throws SQLException {
/*  961 */     if (isNull(paramInt)) return null;
/*      */     
/*  963 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getBINARY_FLOAT not implemented for class " + getClass().getName());
/*  964 */     sQLException.fillInStackTrace();
/*  965 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   BINARY_DOUBLE getBINARY_DOUBLE(int paramInt) throws SQLException {
/*  985 */     if (isNull(paramInt)) return null;
/*      */     
/*  987 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getBINARY_DOUBLE not implemented for class " + getClass().getName());
/*  988 */     sQLException.fillInStackTrace();
/*  989 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   BLOB getBLOB(int paramInt) throws SQLException {
/* 1009 */     if (isNull(paramInt)) return null;
/*      */     
/* 1011 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getBLOB not implemented for class " + getClass().getName());
/* 1012 */     sQLException.fillInStackTrace();
/* 1013 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   CHAR getCHAR(int paramInt) throws SQLException {
/* 1033 */     if (isNull(paramInt)) return null;
/*      */     
/* 1035 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getCHAR not implemented for class " + getClass().getName());
/* 1036 */     sQLException.fillInStackTrace();
/* 1037 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   CLOB getCLOB(int paramInt) throws SQLException {
/* 1057 */     if (isNull(paramInt)) return null;
/*      */     
/* 1059 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getCLOB not implemented for class " + getClass().getName());
/* 1060 */     sQLException.fillInStackTrace();
/* 1061 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   ResultSet getCursor(int paramInt) throws SQLException {
/* 1081 */     if (isNull(paramInt)) return null;
/*      */     
/* 1083 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getCursor not implemented for class " + getClass().getName());
/* 1084 */     sQLException.fillInStackTrace();
/* 1085 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   DATE getDATE(int paramInt) throws SQLException {
/* 1105 */     if (isNull(paramInt)) return null;
/*      */     
/* 1107 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getDATE not implemented for class " + getClass().getName());
/* 1108 */     sQLException.fillInStackTrace();
/* 1109 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   INTERVALDS getINTERVALDS(int paramInt) throws SQLException {
/* 1129 */     if (isNull(paramInt)) return null;
/*      */     
/* 1131 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getINTERVALDS not implemented for class " + getClass().getName());
/* 1132 */     sQLException.fillInStackTrace();
/* 1133 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   INTERVALYM getINTERVALYM(int paramInt) throws SQLException {
/* 1153 */     if (isNull(paramInt)) return null;
/*      */     
/* 1155 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getINTERVALYM not implemented for class " + getClass().getName());
/* 1156 */     sQLException.fillInStackTrace();
/* 1157 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   NUMBER getNUMBER(int paramInt) throws SQLException {
/* 1177 */     if (isNull(paramInt)) return null;
/*      */     
/* 1179 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getNUMBER not implemented for class " + getClass().getName());
/* 1180 */     sQLException.fillInStackTrace();
/* 1181 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   OPAQUE getOPAQUE(int paramInt) throws SQLException {
/* 1201 */     if (isNull(paramInt)) return null;
/*      */     
/* 1203 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getOPAQUE not implemented for class " + getClass().getName());
/* 1204 */     sQLException.fillInStackTrace();
/* 1205 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   Datum getOracleObject(int paramInt) throws SQLException {
/* 1225 */     if (isNull(paramInt)) return null;
/*      */     
/* 1227 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getOracleObject not implemented for class " + getClass().getName());
/* 1228 */     sQLException.fillInStackTrace();
/* 1229 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   ORAData getORAData(int paramInt, ORADataFactory paramORADataFactory) throws SQLException {
/* 1249 */     if (isNull(paramInt)) return null;
/*      */     
/* 1251 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getORAData not implemented for class " + getClass().getName());
/* 1252 */     sQLException.fillInStackTrace();
/* 1253 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   ORAData getORAData(int paramInt) throws SQLException {
/* 1273 */     if (isNull(paramInt)) return null;
/*      */     
/* 1275 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getORAData not implemented for class " + getClass().getName());
/* 1276 */     sQLException.fillInStackTrace();
/* 1277 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   OracleData getOracleData(int paramInt) throws SQLException {
/* 1297 */     if (isNull(paramInt)) return null;
/*      */     
/* 1299 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getOracleData not implemented for class " + getClass().getName());
/* 1300 */     sQLException.fillInStackTrace();
/* 1301 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   Object getObject(int paramInt, OracleDataFactory paramOracleDataFactory) throws SQLException {
/* 1321 */     if (isNull(paramInt)) return null;
/*      */     
/* 1323 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getObject not implemented for class " + getClass().getName());
/* 1324 */     sQLException.fillInStackTrace();
/* 1325 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   RAW getRAW(int paramInt) throws SQLException {
/* 1345 */     if (isNull(paramInt)) return null;
/*      */     
/* 1347 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getRAW not implemented for class " + getClass().getName());
/* 1348 */     sQLException.fillInStackTrace();
/* 1349 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   REF getREF(int paramInt) throws SQLException {
/* 1369 */     if (isNull(paramInt)) return null;
/*      */     
/* 1371 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getREF not implemented for class " + getClass().getName());
/* 1372 */     sQLException.fillInStackTrace();
/* 1373 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   ROWID getROWID(int paramInt) throws SQLException {
/* 1393 */     if (isNull(paramInt)) return null;
/*      */     
/* 1395 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getROWID not implemented for class " + getClass().getName());
/* 1396 */     sQLException.fillInStackTrace();
/* 1397 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   STRUCT getSTRUCT(int paramInt) throws SQLException {
/* 1417 */     if (isNull(paramInt)) return null;
/*      */     
/* 1419 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getSTRUCT not implemented for class " + getClass().getName());
/* 1420 */     sQLException.fillInStackTrace();
/* 1421 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   TIMESTAMPLTZ getTIMESTAMPLTZ(int paramInt) throws SQLException {
/* 1441 */     if (isNull(paramInt)) return null;
/*      */     
/* 1443 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getTIMESTAMPLTZ not implemented for class " + getClass().getName());
/* 1444 */     sQLException.fillInStackTrace();
/* 1445 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   TIMESTAMPTZ getTIMESTAMPTZ(int paramInt) throws SQLException {
/* 1465 */     if (isNull(paramInt)) return null;
/*      */     
/* 1467 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getTIMESTAMPTZ not implemented for class " + getClass().getName());
/* 1468 */     sQLException.fillInStackTrace();
/* 1469 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   TIMESTAMP getTIMESTAMP(int paramInt) throws SQLException {
/* 1489 */     if (isNull(paramInt)) return null;
/*      */     
/* 1491 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getTIMESTAMP not implemented for class " + getClass().getName());
/* 1492 */     sQLException.fillInStackTrace();
/* 1493 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   CustomDatum getCustomDatum(int paramInt, CustomDatumFactory paramCustomDatumFactory) throws SQLException {
/* 1513 */     if (isNull(paramInt)) return null;
/*      */     
/* 1515 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getCustomDatum not implemented for class " + getClass().getName());
/* 1516 */     sQLException.fillInStackTrace();
/* 1517 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   OracleArray getOracleArray(int paramInt) throws SQLException {
/* 1537 */     if (isNull(paramInt)) return null;
/*      */     
/* 1539 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getOracleArray not implemented for class " + getClass().getName());
/* 1540 */     sQLException.fillInStackTrace();
/* 1541 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   OracleBlob getOracleBlob(int paramInt) throws SQLException {
/* 1561 */     if (isNull(paramInt)) return null;
/*      */     
/* 1563 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getOracleBlob not implemented for class " + getClass().getName());
/* 1564 */     sQLException.fillInStackTrace();
/* 1565 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   OracleClob getOracleClob(int paramInt) throws SQLException {
/* 1585 */     if (isNull(paramInt)) return null;
/*      */     
/* 1587 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getOracleClob not implemented for class " + getClass().getName());
/* 1588 */     sQLException.fillInStackTrace();
/* 1589 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   OracleBfile getOracleBfile(int paramInt) throws SQLException {
/* 1609 */     if (isNull(paramInt)) return null;
/*      */     
/* 1611 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getOracleBfile not implemented for class " + getClass().getName());
/* 1612 */     sQLException.fillInStackTrace();
/* 1613 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   OracleRef getOracleRef(int paramInt) throws SQLException {
/* 1633 */     if (isNull(paramInt)) return null;
/*      */     
/* 1635 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getOracleRef not implemented for class " + getClass().getName());
/* 1636 */     sQLException.fillInStackTrace();
/* 1637 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   OracleOpaque getOracleOpaque(int paramInt) throws SQLException {
/* 1657 */     if (isNull(paramInt)) return null;
/*      */     
/* 1659 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getOracleOpaque not implemented for class " + getClass().getName());
/* 1660 */     sQLException.fillInStackTrace();
/* 1661 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   InputStream getAsciiStream(int paramInt) throws SQLException {
/* 1681 */     if (isNull(paramInt)) return null;
/*      */     
/* 1683 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getAsciiStream not implemented for class " + getClass().getName());
/* 1684 */     sQLException.fillInStackTrace();
/* 1685 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   InputStream getBinaryStream(int paramInt) throws SQLException {
/* 1705 */     if (isNull(paramInt)) return null;
/*      */     
/* 1707 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getBinaryStream not implemented for class " + getClass().getName());
/* 1708 */     sQLException.fillInStackTrace();
/* 1709 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   Reader getCharacterStream(int paramInt) throws SQLException {
/* 1729 */     if (isNull(paramInt)) return null;
/*      */     
/* 1731 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getCharacterStream not implemented for class " + getClass().getName());
/* 1732 */     sQLException.fillInStackTrace();
/* 1733 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   Reader getNCharacterStream(int paramInt) throws SQLException {
/* 1753 */     if (isNull(paramInt)) return null;
/*      */     
/* 1755 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getNCharacterStream not implemented for class " + getClass().getName());
/* 1756 */     sQLException.fillInStackTrace();
/* 1757 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   InputStream getUnicodeStream(int paramInt) throws SQLException {
/* 1777 */     if (isNull(paramInt)) return null;
/*      */     
/* 1779 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getUnicodeStream not implemented for class " + getClass().getName());
/* 1780 */     sQLException.fillInStackTrace();
/* 1781 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected OracleConnection getConnectionDuringExceptionHandling() {
/* 1802 */     return this.statement.getConnectionDuringExceptionHandling();
/*      */   }
/*      */ 
/*      */ 
/*      */   
/* 1807 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*      */   public static final String BUILD_DATE = "Thu_Apr_04_15:09:24_PDT_2013";
/*      */   public static final boolean TRACE = false;
/*      */ }


/* Location:              C:\Users\olatu\OneDrive\Documents\Calypso\syncbase\sync_base.jar!\BOOT-INF\lib\ojdbc-7.jar!\oracle\jdbc\driver\GeneratedAccessor.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */