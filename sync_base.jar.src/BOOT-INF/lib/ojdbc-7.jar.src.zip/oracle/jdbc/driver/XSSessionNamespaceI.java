/*     */ package oracle.jdbc.driver;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.sql.SQLException;
/*     */ import oracle.jdbc.internal.XSPrincipal;
/*     */ import oracle.jdbc.internal.XSSessionNamespace;
/*     */ import oracle.sql.TIMESTAMPTZ;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class XSSessionNamespaceI
/*     */   extends XSSessionNamespace
/*     */ {
/*  75 */   XSPrincipalI kpxssessnsuser = null;
/*  76 */   String kpxssessnstenant = null;
/*  77 */   byte[] kpxssessnstenantBytes = null;
/*  78 */   byte[] kpxssessnssid = null;
/*  79 */   byte[] kpxssessnscookie = null;
/*  80 */   long kpxssessnsproxy = 0L;
/*  81 */   long kpxssessnsaclids = 0L;
/*  82 */   long kpxssessnscreator = 0L;
/*  83 */   long kpxssessnsupdater = 0L;
/*  84 */   byte[] kpxssessnscrets = null;
/*  85 */   byte[] kpxssessnsaccts = null;
/*  86 */   byte[] kpxssessnsautts = null;
/*  87 */   int kpxssessnstimeout = 0;
/*     */ 
/*     */ 
/*     */   
/*     */   public XSPrincipal getPrincipal() {
/*  92 */     return this.kpxssessnsuser;
/*     */   }
/*     */   
/*     */   public String getTenant() {
/*  96 */     return this.kpxssessnstenant;
/*     */   }
/*     */   
/*     */   public byte[] getSessionId() {
/* 100 */     return this.kpxssessnssid;
/*     */   }
/*     */   
/*     */   public byte[] getCookie() {
/* 104 */     return this.kpxssessnscookie;
/*     */   }
/*     */   
/*     */   public long getProxyId() {
/* 108 */     return this.kpxssessnsproxy;
/*     */   }
/*     */   
/*     */   public long getACLId() {
/* 112 */     return this.kpxssessnsaclids;
/*     */   }
/*     */   
/*     */   public long getCreatedBy() {
/* 116 */     return this.kpxssessnscreator;
/*     */   }
/*     */   
/*     */   public long getUpdatedBy() {
/* 120 */     return this.kpxssessnsupdater;
/*     */   }
/*     */   
/*     */   public TIMESTAMPTZ getCreateTimestamp() {
/* 124 */     return new TIMESTAMPTZ(this.kpxssessnscrets);
/*     */   }
/*     */   
/*     */   public TIMESTAMPTZ getAccessTimestamp() {
/* 128 */     return new TIMESTAMPTZ(this.kpxssessnsaccts);
/*     */   }
/*     */   
/*     */   public TIMESTAMPTZ getAuthTimestamp() {
/* 132 */     return new TIMESTAMPTZ(this.kpxssessnsautts);
/*     */   }
/*     */   
/*     */   public int getTimeout() {
/* 136 */     return this.kpxssessnstimeout;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void setPrincipal(XSPrincipal paramXSPrincipal) throws SQLException {
/* 142 */     this.kpxssessnsuser = (XSPrincipalI)paramXSPrincipal;
/*     */   }
/*     */   
/*     */   private void setTenant(String paramString) throws SQLException {
/* 146 */     this.kpxssessnstenant = paramString;
/*     */   }
/*     */   
/*     */   private void setSessionId(byte[] paramArrayOfbyte) throws SQLException {
/* 150 */     this.kpxssessnssid = paramArrayOfbyte;
/*     */   }
/*     */   
/*     */   private void setCookie(byte[] paramArrayOfbyte) throws SQLException {
/* 154 */     this.kpxssessnscookie = paramArrayOfbyte;
/*     */   }
/*     */   
/*     */   private void setProxyId(long paramLong) throws SQLException {
/* 158 */     this.kpxssessnsproxy = paramLong;
/*     */   }
/*     */   
/*     */   private void setACLId(long paramLong) throws SQLException {
/* 162 */     this.kpxssessnsaclids = paramLong;
/*     */   }
/*     */   
/*     */   private void setCreatedBy(long paramLong) throws SQLException {
/* 166 */     this.kpxssessnscreator = paramLong;
/*     */   }
/*     */   
/*     */   private void setUpdatedBy(long paramLong) throws SQLException {
/* 170 */     this.kpxssessnsupdater = paramLong;
/*     */   }
/*     */   
/*     */   private void setCreateTimestamp(byte[] paramArrayOfbyte) throws SQLException {
/* 174 */     this.kpxssessnscrets = paramArrayOfbyte;
/*     */   }
/*     */   
/*     */   private void setAccessTimestamp(byte[] paramArrayOfbyte) throws SQLException {
/* 178 */     this.kpxssessnsaccts = paramArrayOfbyte;
/*     */   }
/*     */   
/*     */   private void setAuthTimestamp(byte[] paramArrayOfbyte) throws SQLException {
/* 182 */     this.kpxssessnsautts = paramArrayOfbyte;
/*     */   }
/*     */   
/*     */   private void setTimeout(int paramInt) throws SQLException {
/* 186 */     this.kpxssessnstimeout = paramInt;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   static XSSessionNamespaceI unmarshal(T4CMAREngine paramT4CMAREngine) throws SQLException, IOException {
/* 192 */     XSPrincipalI xSPrincipalI = XSPrincipalI.unmarshal(paramT4CMAREngine);
/*     */     
/* 194 */     int[] arrayOfInt = new int[1];
/* 195 */     String str = null;
/* 196 */     int i = (int)paramT4CMAREngine.unmarshalUB4();
/* 197 */     if (i > 0) {
/*     */       
/* 199 */       byte[] arrayOfByte = new byte[i];
/* 200 */       paramT4CMAREngine.unmarshalCLR(arrayOfByte, 0, arrayOfInt);
/* 201 */       str = paramT4CMAREngine.conv.CharBytesToString(arrayOfByte, arrayOfInt[0]);
/*     */     } 
/*     */     
/* 204 */     byte[] arrayOfByte1 = null;
/* 205 */     int j = (int)paramT4CMAREngine.unmarshalUB4();
/* 206 */     if (j > 0) {
/*     */       
/* 208 */       paramT4CMAREngine.unmarshalUB1();
/* 209 */       arrayOfByte1 = paramT4CMAREngine.unmarshalNBytes(j);
/*     */     } 
/*     */     
/* 212 */     byte[] arrayOfByte2 = null;
/* 213 */     int k = (int)paramT4CMAREngine.unmarshalUB4();
/* 214 */     if (k > 0) {
/*     */       
/* 216 */       paramT4CMAREngine.unmarshalUB1();
/* 217 */       arrayOfByte2 = paramT4CMAREngine.unmarshalNBytes(k);
/*     */     } 
/*     */     
/* 220 */     long l1 = paramT4CMAREngine.unmarshalSB8();
/*     */     
/* 222 */     long l2 = paramT4CMAREngine.unmarshalSB8();
/*     */     
/* 224 */     long l3 = paramT4CMAREngine.unmarshalSB8();
/* 225 */     long l4 = paramT4CMAREngine.unmarshalSB8();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 239 */     byte[] arrayOfByte3 = null;
/* 240 */     if (paramT4CMAREngine.unmarshalUB1() == 1) {
/*     */       
/* 242 */       int n = (int)paramT4CMAREngine.unmarshalUB4();
/* 243 */       arrayOfByte3 = paramT4CMAREngine.unmarshalNBytes(n);
/*     */     } 
/*     */     
/* 246 */     byte[] arrayOfByte4 = null;
/* 247 */     if (paramT4CMAREngine.unmarshalUB1() == 1) {
/*     */       
/* 249 */       int n = (int)paramT4CMAREngine.unmarshalUB4();
/* 250 */       arrayOfByte4 = paramT4CMAREngine.unmarshalNBytes(n);
/*     */     } 
/* 252 */     byte[] arrayOfByte5 = null;
/* 253 */     if (paramT4CMAREngine.unmarshalUB1() == 1) {
/*     */       
/* 255 */       int n = (int)paramT4CMAREngine.unmarshalUB4();
/* 256 */       arrayOfByte5 = paramT4CMAREngine.unmarshalNBytes(n);
/*     */     } 
/*     */     
/* 259 */     int m = (int)paramT4CMAREngine.unmarshalUB4();
/* 260 */     XSSessionNamespaceI xSSessionNamespaceI = new XSSessionNamespaceI();
/* 261 */     xSSessionNamespaceI.setPrincipal(xSPrincipalI);
/* 262 */     xSSessionNamespaceI.setTenant(str);
/* 263 */     xSSessionNamespaceI.setSessionId(arrayOfByte1);
/* 264 */     xSSessionNamespaceI.setCookie(arrayOfByte2);
/* 265 */     xSSessionNamespaceI.setProxyId(l1);
/* 266 */     xSSessionNamespaceI.setACLId(l2);
/* 267 */     xSSessionNamespaceI.setCreatedBy(l3);
/* 268 */     xSSessionNamespaceI.setUpdatedBy(l4);
/* 269 */     xSSessionNamespaceI.setCreateTimestamp(arrayOfByte3);
/* 270 */     xSSessionNamespaceI.setAccessTimestamp(arrayOfByte4);
/* 271 */     xSSessionNamespaceI.setAuthTimestamp(arrayOfByte5);
/* 272 */     xSSessionNamespaceI.setTimeout(m);
/* 273 */     return xSSessionNamespaceI;
/*     */   }
/*     */ 
/*     */   
/* 277 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*     */   public static final String BUILD_DATE = "Thu_Apr_04_15:09:24_PDT_2013";
/*     */   public static final boolean TRACE = false;
/*     */ }


/* Location:              C:\Users\olatu\OneDrive\Documents\Calypso\syncbase\sync_base.jar!\BOOT-INF\lib\ojdbc-7.jar!\oracle\jdbc\driver\XSSessionNamespaceI.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */