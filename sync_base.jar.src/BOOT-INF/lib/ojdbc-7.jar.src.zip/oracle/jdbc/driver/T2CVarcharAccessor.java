/*    */ package oracle.jdbc.driver;
/*    */ 
/*    */ import java.sql.SQLException;
/*    */ import oracle.sql.CharacterSet;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class T2CVarcharAccessor
/*    */   extends VarcharAccessor
/*    */ {
/*    */   T2CVarcharAccessor(OracleStatement paramOracleStatement, int paramInt1, short paramShort, int paramInt2, boolean paramBoolean) throws SQLException {
/* 33 */     super(paramOracleStatement, paramInt1, paramShort, paramInt2, paramBoolean);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   byte[] getBytesInternal(int paramInt) throws SQLException {
/* 40 */     if (this.formOfUse == 2) {
/*    */       
/* 42 */       assert !isNull(paramInt);
/* 43 */       CharacterSet characterSet = this.statement.connection.conversion.getCharacterSet(this.formOfUse);
/* 44 */       String str = this.rowData.getString(getOffset(paramInt), getLength(paramInt), characterSet);
/* 45 */       return DBConversion.stringToDriverCharBytes(str, (short)characterSet.getOracleId());
/*    */     } 
/*    */ 
/*    */ 
/*    */     
/* 50 */     return super.getBytesInternal(paramInt);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 56 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*    */   public static final String BUILD_DATE = "Thu_Apr_04_15:09:24_PDT_2013";
/*    */   public static final boolean TRACE = false;
/*    */ }


/* Location:              C:\Users\olatu\OneDrive\Documents\Calypso\syncbase\sync_base.jar!\BOOT-INF\lib\ojdbc-7.jar!\oracle\jdbc\driver\T2CVarcharAccessor.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */