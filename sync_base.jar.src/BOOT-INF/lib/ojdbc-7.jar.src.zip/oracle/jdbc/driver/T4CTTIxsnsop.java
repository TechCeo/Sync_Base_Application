/*     */ package oracle.jdbc.driver;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.sql.SQLException;
/*     */ import oracle.jdbc.internal.OracleConnection;
/*     */ import oracle.jdbc.internal.XSNamespace;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class T4CTTIxsnsop
/*     */   extends T4CTTIfun
/*     */ {
/*     */   private OracleConnection.XSOperationCode operationCode;
/*     */   private byte[] sessionId;
/*     */   private XSNamespace[] namespaces;
/*     */   private XSNamespace[] outNamespaces;
/*     */   
/*     */   T4CTTIxsnsop(T4CConnection paramT4CConnection) {
/*  64 */     super(paramT4CConnection, (byte)3);
/*     */     
/*  66 */     setFunCode((short)172);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void doOXSNS(OracleConnection.XSOperationCode paramXSOperationCode, byte[] paramArrayOfbyte, XSNamespace[] paramArrayOfXSNamespace, boolean paramBoolean) throws IOException, SQLException {
/*  84 */     if (paramBoolean) {
/*  85 */       setTTCCode((byte)3);
/*     */     } else {
/*  87 */       setTTCCode((byte)17);
/*  88 */     }  this.operationCode = paramXSOperationCode;
/*  89 */     this.sessionId = paramArrayOfbyte;
/*  90 */     this.namespaces = paramArrayOfXSNamespace;
/*     */     
/*  92 */     if (this.namespaces != null)
/*  93 */       for (byte b = 0; b < this.namespaces.length; b++) {
/*  94 */         ((XSNamespaceI)this.namespaces[b]).doCharConversion(this.meg.conv);
/*     */       } 
/*  96 */     if (paramBoolean) {
/*  97 */       doRPC();
/*     */     } else {
/*  99 */       doPigRPC();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void marshal() throws IOException {
/* 107 */     this.meg.marshalUB4(this.operationCode.getCode());
/* 108 */     boolean bool1 = false;
/* 109 */     if (this.sessionId != null && this.sessionId.length > 0) {
/*     */       
/* 111 */       bool1 = true;
/* 112 */       this.meg.marshalPTR();
/* 113 */       this.meg.marshalUB4(this.sessionId.length);
/*     */     }
/*     */     else {
/*     */       
/* 117 */       this.meg.marshalNULLPTR();
/* 118 */       this.meg.marshalUB4(0L);
/*     */     } 
/*     */     
/* 121 */     boolean bool2 = false;
/* 122 */     this.meg.marshalPTR();
/* 123 */     if (this.namespaces != null && this.namespaces.length > 0) {
/*     */       
/* 125 */       bool2 = true;
/* 126 */       this.meg.marshalUB4(this.namespaces.length);
/*     */     }
/*     */     else {
/*     */       
/* 130 */       this.meg.marshalUB4(0L);
/*     */     } 
/* 132 */     this.meg.marshalPTR();
/*     */     
/* 134 */     if (bool1)
/* 135 */       this.meg.marshalB1Array(this.sessionId); 
/* 136 */     if (bool2) {
/* 137 */       for (byte b = 0; b < this.namespaces.length; b++) {
/* 138 */         ((XSNamespaceI)this.namespaces[b]).marshal(this.meg);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void readRPA() throws SQLException, IOException {
/* 147 */     this.outNamespaces = null;
/* 148 */     int i = (int)this.meg.unmarshalUB4();
/* 149 */     if (i > 0) {
/*     */       
/* 151 */       this.outNamespaces = new XSNamespace[i];
/* 152 */       for (byte b = 0; b < i; b++) {
/* 153 */         this.outNamespaces[b] = XSNamespaceI.unmarshal(this.meg);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   XSNamespace[] getNamespaces() throws SQLException {
/* 161 */     return this.outNamespaces;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected OracleConnection getConnectionDuringExceptionHandling() {
/* 176 */     return this.connection;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/* 181 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*     */   public static final String BUILD_DATE = "Thu_Apr_04_15:09:24_PDT_2013";
/*     */   public static final boolean TRACE = false;
/*     */ }


/* Location:              C:\Users\olatu\OneDrive\Documents\Calypso\syncbase\sync_base.jar!\BOOT-INF\lib\ojdbc-7.jar!\oracle\jdbc\driver\T4CTTIxsnsop.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */