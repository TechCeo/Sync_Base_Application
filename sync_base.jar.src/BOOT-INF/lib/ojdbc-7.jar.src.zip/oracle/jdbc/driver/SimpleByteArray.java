/*     */ package oracle.jdbc.driver;
/*     */ 
/*     */ import java.sql.SQLException;
/*     */ import oracle.sql.CharacterSet;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class SimpleByteArray
/*     */   extends ByteArray
/*     */ {
/*     */   protected byte[] bytes;
/*     */   
/*     */   protected SimpleByteArray(byte[] paramArrayOfbyte) {
/*  25 */     setBytes(paramArrayOfbyte);
/*     */   }
/*     */ 
/*     */   
/*     */   void setBytes(byte[] paramArrayOfbyte) {
/*  30 */     this.bytes = paramArrayOfbyte;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   long length() {
/*  39 */     return this.bytes.length;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void put(long paramLong, byte paramByte) {
/*  53 */     assert paramLong >= 0L && paramLong < this.bytes.length : "index = " + paramLong + " length = " + this.bytes.length;
/*  54 */     this.bytes[(int)paramLong] = paramByte;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   byte get(long paramLong) {
/*  69 */     assert paramLong >= 0L && paramLong < this.bytes.length : "index = " + paramLong + " length = " + this.bytes.length;
/*  70 */     return this.bytes[(int)paramLong];
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void put(long paramLong, byte[] paramArrayOfbyte, int paramInt1, int paramInt2) {
/*  89 */     assert paramLong >= 0L && paramLong + paramInt2 < this.bytes.length : "offset = " + paramLong + " length = " + paramInt2 + " bytes.length = " + this.bytes.length;
/*     */     
/*  91 */     assert paramInt1 >= 0 && paramInt1 + paramInt2 < paramArrayOfbyte.length : "srcOffset = " + paramInt1 + " length = " + paramInt2 + " src.length = " + paramArrayOfbyte.length;
/*  92 */     System.arraycopy(paramArrayOfbyte, paramInt1, this.bytes, (int)paramLong, paramInt2);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void get(long paramLong, byte[] paramArrayOfbyte, int paramInt1, int paramInt2) {
/* 114 */     assert paramLong >= 0L && paramLong + paramInt2 <= this.bytes.length && paramInt1 >= 0 && paramInt1 + paramInt2 <= paramArrayOfbyte.length : " offset: " + paramLong + " bytes.length: " + this.bytes.length + " destOffset: " + paramInt1 + " length: " + paramInt2;
/* 115 */     System.arraycopy(this.bytes, (int)paramLong, paramArrayOfbyte, paramInt1, paramInt2);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   char[] getChars(long paramLong, int paramInt1, DBConversion paramDBConversion, int paramInt2, int[] paramArrayOfint) throws SQLException {
/* 142 */     assert paramLong >= 0L && paramInt1 >= 0 && this.bytes.length >= paramLong + paramInt1 : "bytes.length: " + this.bytes.length + " offset: " + paramLong + " lengthInBytes: " + paramInt1;
/* 143 */     assert paramDBConversion != null : "conversion is null";
/*     */     
/* 145 */     assert paramArrayOfint != null && paramArrayOfint.length >= 1 : "out_lengthInChars: " + paramArrayOfint;
/* 146 */     boolean bool = (paramInt2 == 2) ? true : false;
/* 147 */     char[] arrayOfChar = new char[paramInt1 * paramDBConversion.cMaxCharSize];
/* 148 */     int[] arrayOfInt = new int[1];
/* 149 */     arrayOfInt[0] = paramInt1;
/* 150 */     int i = paramDBConversion.CHARBytesToJavaChars(this.bytes, (int)paramLong, arrayOfChar, 0, arrayOfInt, arrayOfChar.length, bool);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 157 */     paramArrayOfint[0] = i;
/* 158 */     return arrayOfChar;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   char[] getChars(long paramLong, int paramInt, CharacterSet paramCharacterSet, int[] paramArrayOfint) throws SQLException {
/* 183 */     assert paramLong >= 0L && paramInt >= 0 : "offset: " + paramLong + " lengthInBytes: " + paramInt;
/*     */     
/* 185 */     assert this.bytes.length >= paramLong + paramInt : "bytes.length: " + this.bytes.length + " offset: " + paramLong + " lengthInBytes: " + paramInt;
/*     */     
/* 187 */     assert paramArrayOfint != null && paramArrayOfint.length > 0 : "out_lengthInChars: " + paramArrayOfint;
/* 188 */     String str = paramCharacterSet.toString(this.bytes, (int)paramLong, paramInt);
/* 189 */     char[] arrayOfChar = str.toCharArray();
/* 190 */     paramArrayOfint[0] = arrayOfChar.length;
/* 191 */     return arrayOfChar;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   long updateChecksum(long paramLong1, int paramInt, CRC64 paramCRC64, long paramLong2) {
/* 206 */     return CRC64.updateChecksum(paramLong2, this.bytes, (int)paramLong1, paramInt);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   byte[] getBlockBasic(long paramLong, int[] paramArrayOfint) {
/* 215 */     paramArrayOfint[0] = (int)paramLong;
/* 216 */     return (paramLong < this.bytes.length) ? this.bytes : null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void free() {}
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 227 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*     */   public static final String BUILD_DATE = "Thu_Apr_04_15:09:24_PDT_2013";
/*     */   public static final boolean TRACE = false;
/*     */ }


/* Location:              C:\Users\olatu\OneDrive\Documents\Calypso\syncbase\sync_base.jar!\BOOT-INF\lib\ojdbc-7.jar!\oracle\jdbc\driver\SimpleByteArray.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */