/*    */ package oracle.jdbc.driver;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.sql.SQLException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class T4CTTIoses
/*    */   extends T4CTTIfun
/*    */ {
/*    */   static final int OSESSWS = 1;
/*    */   static final int OSESDET = 3;
/*    */   private int sididx;
/*    */   private int sidser;
/*    */   private int sidopc;
/*    */   
/*    */   T4CTTIoses(T4CConnection paramT4CConnection) {
/* 44 */     super(paramT4CConnection, (byte)17);
/*    */     
/* 46 */     setFunCode((short)107);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   void doO80SES(int paramInt1, int paramInt2, int paramInt3) throws IOException, SQLException {
/* 57 */     this.sididx = paramInt1;
/* 58 */     this.sidser = paramInt2;
/* 59 */     this.sidopc = paramInt3;
/*    */     
/* 61 */     if (this.sidopc != 1 && this.sidopc != 3)
/* 62 */       throw new SQLException("Wrong operation : can only do switch or detach"); 
/* 63 */     doPigRPC();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   void marshal() throws IOException {
/* 70 */     this.meg.marshalUB4(this.sididx);
/* 71 */     this.meg.marshalUB4(this.sidser);
/* 72 */     this.meg.marshalUB4(this.sidopc);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/* 77 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*    */   public static final String BUILD_DATE = "Thu_Apr_04_15:09:24_PDT_2013";
/*    */   public static final boolean TRACE = false;
/*    */ }


/* Location:              C:\Users\olatu\OneDrive\Documents\Calypso\syncbase\sync_base.jar!\BOOT-INF\lib\ojdbc-7.jar!\oracle\jdbc\driver\T4CTTIoses.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */