/*     */ package oracle.jdbc.driver;
/*     */ 
/*     */ import java.sql.Connection;
/*     */ import java.sql.SQLException;
/*     */ import java.sql.SQLXML;
/*     */ import java.sql.Struct;
/*     */ import java.util.Map;
/*     */ import oracle.jdbc.OracleConnection;
/*     */ import oracle.jdbc.OracleData;
/*     */ import oracle.jdbc.oracore.OracleType;
/*     */ import oracle.jdbc.oracore.OracleTypeADT;
/*     */ import oracle.sql.ARRAY;
/*     */ import oracle.sql.ArrayDescriptor;
/*     */ import oracle.sql.Datum;
/*     */ import oracle.sql.JAVA_STRUCT;
/*     */ import oracle.sql.OPAQUE;
/*     */ import oracle.sql.ORAData;
/*     */ import oracle.sql.OpaqueDescriptor;
/*     */ import oracle.sql.STRUCT;
/*     */ import oracle.sql.StructDescriptor;
/*     */ import oracle.sql.TypeDescriptor;
/*     */ import oracle.xdb.XMLType;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class NamedTypeAccessor
/*     */   extends TypeAccessor
/*     */ {
/*     */   static final int MAXLENGTH = -1;
/*     */   
/*     */   NamedTypeAccessor(OracleStatement paramOracleStatement, String paramString, short paramShort, int paramInt, boolean paramBoolean) throws SQLException {
/*  33 */     super(Representation.NAMED_TYPE, paramOracleStatement, -1, paramBoolean);
/*     */     
/*  35 */     init(paramOracleStatement, 109, 109, paramShort, paramBoolean);
/*  36 */     initForDataAccess(paramInt, 0, paramString);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   NamedTypeAccessor(OracleStatement paramOracleStatement, int paramInt1, boolean paramBoolean, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, short paramShort, String paramString) throws SQLException {
/*  45 */     super(Representation.NAMED_TYPE, paramOracleStatement, -1, false);
/*     */     
/*  47 */     init(paramOracleStatement, 109, 109, paramShort, false);
/*  48 */     initForDescribe(109, paramInt1, paramBoolean, paramInt2, paramInt3, paramInt4, paramInt5, paramInt6, paramShort, paramString);
/*     */     
/*  50 */     initForDataAccess(0, paramInt1, paramString);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   NamedTypeAccessor(OracleStatement paramOracleStatement, int paramInt1, boolean paramBoolean, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, short paramShort, String paramString, OracleType paramOracleType) throws SQLException {
/*  59 */     super(Representation.NAMED_TYPE, paramOracleStatement, -1, false);
/*     */     
/*  61 */     init(paramOracleStatement, 109, 109, paramShort, false);
/*     */     
/*  63 */     this.describeOtype = paramOracleType;
/*     */     
/*  65 */     initForDescribe(109, paramInt1, paramBoolean, paramInt2, paramInt3, paramInt4, paramInt5, paramInt6, paramShort, paramString);
/*     */ 
/*     */     
/*  68 */     this.internalOtype = paramOracleType;
/*     */     
/*  70 */     initForDataAccess(0, paramInt1, paramString);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   OracleType otypeFromName(String paramString) throws SQLException {
/*  77 */     if (!this.outBind) {
/*  78 */       return (OracleType)TypeDescriptor.getTypeDescriptor(paramString, (OracleConnection)this.statement.connection).getPickler();
/*     */     }
/*  80 */     if (this.externalType == 2003) {
/*  81 */       return (OracleType)ArrayDescriptor.createDescriptor(paramString, (Connection)this.statement.connection).getOracleTypeCOLLECTION();
/*     */     }
/*  83 */     if (this.externalType == 2007 || this.externalType == 2009)
/*     */     {
/*     */       
/*  86 */       return (OracleType)OpaqueDescriptor.createDescriptor(paramString, (Connection)this.statement.connection).getPickler();
/*     */     }
/*     */     
/*  89 */     return (OracleType)StructDescriptor.createDescriptor(paramString, (Connection)this.statement.connection).getOracleTypeADT();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void initForDataAccess(int paramInt1, int paramInt2, String paramString) throws SQLException {
/*  98 */     super.initForDataAccess(paramInt1, paramInt2, paramString);
/*     */     
/* 100 */     this.byteLength = this.statement.connection.namedTypeAccessorByteLen;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Object getObject(int paramInt) throws SQLException {
/* 110 */     return getObject(paramInt, this.statement.connection.getTypeMap());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static class XMLFactory
/*     */   {
/*     */     static Datum createXML(OPAQUE param1OPAQUE) throws SQLException {
/* 118 */       return (Datum)XMLType.createXML(param1OPAQUE);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Object getObject(int paramInt, Map paramMap) throws SQLException {
/*     */     Datum datum;
/* 130 */     if (isNull(paramInt)) return null;
/*     */ 
/*     */ 
/*     */     
/* 134 */     if (this.externalType == 0) {
/*     */       
/* 136 */       Datum datum1 = getOracleObject(paramInt);
/*     */       
/* 138 */       if (datum1 == null) return null; 
/* 139 */       if (datum1 instanceof STRUCT)
/* 140 */         return ((STRUCT)datum1).toJdbc(paramMap); 
/* 141 */       if (datum1 instanceof OPAQUE) {
/* 142 */         return ((OPAQUE)datum1).toJdbc(paramMap);
/*     */       }
/*     */       
/* 145 */       if (datum1 instanceof ARRAY) {
/* 146 */         return ((ARRAY)datum1).toJdbc(paramMap);
/*     */       }
/*     */       
/* 149 */       return datum1.toJdbc();
/*     */     } 
/*     */     
/* 152 */     switch (this.externalType) {
/*     */ 
/*     */ 
/*     */       
/*     */       case 2008:
/* 157 */         paramMap = null;
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       case 2000:
/*     */       case 2002:
/*     */       case 2003:
/*     */       case 2007:
/* 166 */         datum = getOracleObject(paramInt);
/*     */         
/* 168 */         if (datum == null) {
/* 169 */           return null;
/*     */         }
/*     */         
/* 172 */         if (datum instanceof STRUCT) {
/* 173 */           return ((STRUCT)datum).toJdbc(paramMap);
/*     */         }
/*     */         
/* 176 */         if (datum instanceof ARRAY) {
/* 177 */           return ((ARRAY)datum).toJdbc(paramMap);
/*     */         }
/*     */ 
/*     */         
/* 181 */         return datum.toJdbc();
/*     */ 
/*     */       
/*     */       case 2009:
/* 185 */         datum = getOracleObject(paramInt);
/* 186 */         if (datum == null) {
/* 187 */           return null;
/*     */         }
/*     */         
/*     */         try {
/* 191 */           return datum;
/*     */         }
/* 193 */         catch (ClassCastException classCastException) {
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 198 */           SQLException sQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4);
/* 199 */           sQLException1.fillInStackTrace();
/* 200 */           throw sQLException1;
/*     */         } 
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 206 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4);
/* 207 */     sQLException.fillInStackTrace();
/* 208 */     throw sQLException;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Datum getOracleObject(int paramInt) throws SQLException {
/* 227 */     if (isNull(paramInt)) return null;
/*     */ 
/*     */ 
/*     */     
/* 231 */     byte[] arrayOfByte = pickledBytes(paramInt);
/*     */     
/* 233 */     if (arrayOfByte == null || arrayOfByte.length == 0) return null;
/*     */     
/* 235 */     PhysicalConnection physicalConnection = this.statement.connection;
/* 236 */     OracleTypeADT oracleTypeADT = (OracleTypeADT)this.internalOtype;
/* 237 */     TypeDescriptor typeDescriptor = TypeDescriptor.getTypeDescriptor(oracleTypeADT.getFullName(), (OracleConnection)physicalConnection, arrayOfByte, 0L);
/*     */ 
/*     */     
/* 240 */     switch (typeDescriptor.getTypeCode()) {
/*     */       
/*     */       case 2003:
/* 243 */         return (Datum)new ARRAY((ArrayDescriptor)typeDescriptor, arrayOfByte, (Connection)physicalConnection);
/*     */       
/*     */       case 2002:
/* 246 */         return (Datum)new STRUCT((StructDescriptor)typeDescriptor, arrayOfByte, (Connection)physicalConnection);
/*     */       
/*     */       case 2009:
/* 249 */         return XMLFactory.createXML(new OPAQUE((OpaqueDescriptor)typeDescriptor, arrayOfByte, (Connection)physicalConnection));
/*     */ 
/*     */       
/*     */       case 2007:
/* 253 */         return (Datum)new OPAQUE((OpaqueDescriptor)typeDescriptor, arrayOfByte, (Connection)physicalConnection);
/*     */       
/*     */       case 2008:
/* 256 */         return (Datum)new JAVA_STRUCT((StructDescriptor)typeDescriptor, arrayOfByte, (Connection)physicalConnection);
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 261 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 1);
/* 262 */     sQLException.fillInStackTrace();
/* 263 */     throw sQLException;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   OracleData getOracleData(int paramInt) throws SQLException {
/* 277 */     return (OracleData)getObject(paramInt);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   ORAData getORAData(int paramInt) throws SQLException {
/* 284 */     return (ORAData)getObject(paramInt);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   ARRAY getARRAY(int paramInt) throws SQLException {
/* 292 */     return (ARRAY)getOracleObject(paramInt);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   STRUCT getSTRUCT(int paramInt) throws SQLException {
/* 302 */     return (STRUCT)getOracleObject(paramInt);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Struct getStruct(int paramInt) throws SQLException {
/* 312 */     return (Struct)getOracleObject(paramInt);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   OPAQUE getOPAQUE(int paramInt) throws SQLException {
/* 322 */     return (OPAQUE)getOracleObject(paramInt);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   SQLXML getSQLXML(int paramInt) throws SQLException {
/*     */     try {
/* 333 */       OPAQUE oPAQUE = (OPAQUE)getOracleObject(paramInt);
/* 334 */       if (oPAQUE == null) return null; 
/* 335 */       return (SQLXML)oPAQUE;
/*     */     }
/* 337 */     catch (ClassCastException classCastException) {
/*     */       
/* 339 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4);
/* 340 */       sQLException.fillInStackTrace();
/* 341 */       throw sQLException;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   String getString(int paramInt) throws SQLException {
/* 354 */     Datum datum = getOracleObject(paramInt);
/* 355 */     if (datum instanceof XMLType) {
/* 356 */       return ((XMLType)datum).getString();
/*     */     }
/* 358 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 365 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*     */   public static final String BUILD_DATE = "Thu_Apr_04_15:09:24_PDT_2013";
/*     */   public static final boolean TRACE = false;
/*     */ }


/* Location:              C:\Users\olatu\OneDrive\Documents\Calypso\syncbase\sync_base.jar!\BOOT-INF\lib\ojdbc-7.jar!\oracle\jdbc\driver\NamedTypeAccessor.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */