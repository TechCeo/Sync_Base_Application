/*      */ package oracle.jdbc.driver;
/*      */ 
/*      */ import java.io.IOException;
/*      */ import java.io.InputStream;
/*      */ import java.sql.SQLException;
/*      */ import java.util.ArrayDeque;
/*      */ import java.util.Properties;
/*      */ import java.util.Vector;
/*      */ import oracle.jdbc.internal.KeywordValue;
/*      */ import oracle.jdbc.internal.OracleConnection;
/*      */ import oracle.jdbc.internal.OracleStatement;
/*      */ import oracle.jdbc.oracore.OracleTypeADT;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ final class T4C8Oall
/*      */   extends T4CTTIfun
/*      */ {
/*  122 */   Vector<IOException> nonFatalIOExceptions = null;
/*      */   
/*  124 */   static final byte[] EMPTY_BYTES = new byte[0];
/*      */ 
/*      */   
/*      */   static final int UOPF_PRS = 1;
/*      */ 
/*      */   
/*      */   static final int UOPF_BND = 8;
/*      */ 
/*      */   
/*      */   static final int UOPF_EXE = 32;
/*      */ 
/*      */   
/*      */   static final int UOPF_FEX = 512;
/*      */ 
/*      */   
/*      */   static final int UOPF_FCH = 64;
/*      */ 
/*      */   
/*      */   static final int UOPF_CAN = 128;
/*      */ 
/*      */   
/*      */   static final int UOPF_COM = 256;
/*      */ 
/*      */   
/*      */   static final int UOPF_DSY = 8192;
/*      */   
/*      */   static final int UOPF_SIO = 1024;
/*      */   
/*      */   static final int UOPF_NPL = 32768;
/*      */   
/*      */   static final int UOPF_DFN = 16;
/*      */   
/*      */   static final int UOPF_NCF = 262144;
/*      */   
/*      */   static final int EXE_COMMIT_ON_SUCCESS = 1;
/*      */   
/*      */   static final int EXE_LEAVE_CUR_MAPPED = 2;
/*      */   
/*      */   static final int EXE_BATCH_DML_ERRORS = 4;
/*      */   
/*      */   static final int EXE_SCROL_READ_ONLY = 8;
/*      */   
/*      */   static final int AL8EX_GET_PIDMLRC = 16384;
/*      */   
/*      */   static final int AL8KW_MAXLANG = 63;
/*      */   
/*      */   static final int AL8KW_TIMEZONE = 163;
/*      */   
/*      */   static final int AL8KW_ERR_OVLAP = 164;
/*      */   
/*      */   static final int AL8KW_SESSION_ID = 165;
/*      */   
/*      */   static final int AL8KW_SERIAL_NUM = 166;
/*      */   
/*      */   static final int AL8KW_TAG_FOUND = 167;
/*      */   
/*      */   static final int AL8KW_SCHEMA_NAME = 168;
/*      */   
/*      */   static final int AL8KW_SCHEMA_ID = 169;
/*      */   
/*      */   static final int AL8KW_ENABLED_ROLES = 170;
/*      */   
/*      */   static final int AL8KW_AUX_SESSSTATE = 171;
/*      */   
/*      */   static final int AL8KW_OPENCURSORS = 175;
/*      */   
/*      */   static final int AL8KW_PDBUID = 176;
/*      */   
/*      */   static final int AL8KW_DBID = 177;
/*      */   
/*      */   static final int AL8KW_GUDBID = 178;
/*      */   
/*      */   static final int AL8KW_DBNAME = 179;
/*      */   
/*  198 */   static final String[] NLS_KEYS = new String[] { "AUTH_NLS_LXCCURRENCY", "AUTH_NLS_LXCISOCURR", "AUTH_NLS_LXCNUMERICS", null, null, null, null, "AUTH_NLS_LXCDATEFM", "AUTH_NLS_LXCDATELANG", "AUTH_NLS_LXCTERRITORY", "SESSION_NLS_LXCCHARSET", "AUTH_NLS_LXCSORT", "AUTH_NLS_LXCCALENDAR", null, null, null, "AUTH_NLS_LXLAN", null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, "AUTH_NLS_LXCSORT", null, "AUTH_NLS_LXCUNIONCUR", null, null, null, null, "AUTH_NLS_LXCTIMEFM", "AUTH_NLS_LXCSTMPFM", "AUTH_NLS_LXCTTZNFM", "AUTH_NLS_LXCSTZNFM", "SESSION_NLS_LXCNLSLENSEM", "SESSION_NLS_LXCNCHAREXCP", "SESSION_NLS_LXCNCHARIMP" };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static final int LDIREGIDFLAG = 120;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static final int LDIREGIDSET = 181;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static final int LDIMAXTIMEFIELD = 60;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static final int AL8EX_IMPL_RESULTS_CLIENT = 32768;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   int rowsProcessed;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   int numberOfDefinePositions;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   long options;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   int cursor;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  287 */   byte[] sqlStmt = new byte[0];
/*  288 */   final long[] al8i4 = new long[13];
/*      */ 
/*      */   
/*      */   boolean plsql = false;
/*      */ 
/*      */   
/*      */   Accessor[] definesAccessors;
/*      */ 
/*      */   
/*      */   int definesLength;
/*      */ 
/*      */   
/*      */   Accessor[] outBindAccessors;
/*      */   
/*      */   int numberOfBindPositions;
/*      */   
/*      */   InputStream[][] parameterStream;
/*      */   
/*      */   byte[][][] parameterDatum;
/*      */   
/*      */   OracleTypeADT[][] parameterOtype;
/*      */   
/*      */   short[] bindIndicators;
/*      */   
/*      */   byte[] bindBytes;
/*      */   
/*      */   char[] bindChars;
/*      */   
/*      */   int bindIndicatorSubRange;
/*      */   
/*      */   byte[] tmpBindsByteArray;
/*      */   
/*      */   DBConversion conversion;
/*      */   
/*      */   byte[] ibtBindBytes;
/*      */   
/*      */   char[] ibtBindChars;
/*      */   
/*      */   short[] ibtBindIndicators;
/*      */   
/*      */   boolean sendBindsDefinition = false;
/*      */   
/*      */   OracleStatement oracleStatement;
/*      */   
/*      */   short dbCharSet;
/*      */   
/*      */   short NCharSet;
/*      */   
/*      */   T4CTTIrxd rxd;
/*      */   
/*      */   T4C8TTIrxh rxh;
/*      */   
/*      */   T4CTTIdcb dcb;
/*      */   
/*      */   T4CTTIimplres implres;
/*      */   
/*      */   OracleStatement.SqlKind typeOfStatement;
/*      */   
/*  346 */   int defCols = 0;
/*      */ 
/*      */   
/*      */   int rowsToFetch;
/*      */   
/*      */   boolean aFetchWasDone = false;
/*      */   
/*      */   T4CTTIoac[] oacdefBindsSent;
/*      */   
/*      */   T4CTTIoac[] oacdefDefines;
/*      */   
/*      */   int[] definedColumnSize;
/*      */   
/*      */   int[] definedColumnType;
/*      */   
/*      */   int[] definedColumnFormOfUse;
/*      */   
/*  363 */   NTFDCNRegistration registration = null;
/*      */   
/*      */   static final int AL8TXCUR = 1;
/*      */   
/*      */   static final int AL8TXDON = 2;
/*      */   
/*      */   static final int AL8TXRON = 4;
/*      */   
/*      */   T4C8Oall(T4CConnection paramT4CConnection) {
/*  372 */     super(paramT4CConnection, (byte)3);
/*      */     
/*  374 */     setFunCode((short)94);
/*  375 */     this.rxh = new T4C8TTIrxh(paramT4CConnection);
/*  376 */     this.rxd = new T4CTTIrxd(paramT4CConnection);
/*  377 */     this.dcb = new T4CTTIdcb(paramT4CConnection);
/*  378 */     this.implres = new T4CTTIimplres(paramT4CConnection);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void doOALL(boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3, boolean paramBoolean4, boolean paramBoolean5, OracleStatement.SqlKind paramSqlKind, int paramInt1, byte[] paramArrayOfbyte1, int paramInt2, Accessor[] paramArrayOfAccessor1, int paramInt3, Accessor[] paramArrayOfAccessor2, int paramInt4, byte[] paramArrayOfbyte2, char[] paramArrayOfchar1, short[] paramArrayOfshort1, int paramInt5, DBConversion paramDBConversion, byte[] paramArrayOfbyte3, InputStream[][] paramArrayOfInputStream, byte[][][] paramArrayOfbyte, OracleTypeADT[][] paramArrayOfOracleTypeADT, OracleStatement paramOracleStatement, byte[] paramArrayOfbyte4, char[] paramArrayOfchar2, short[] paramArrayOfshort2, T4CTTIoac[] paramArrayOfT4CTTIoac, int[] paramArrayOfint1, int[] paramArrayOfint2, int[] paramArrayOfint3, NTFDCNRegistration paramNTFDCNRegistration) throws SQLException, IOException {
/*  403 */     this.typeOfStatement = paramSqlKind;
/*  404 */     this.cursor = paramInt1;
/*  405 */     this.sqlStmt = paramBoolean1 ? paramArrayOfbyte1 : EMPTY_BYTES;
/*  406 */     this.rowsToFetch = paramInt2;
/*  407 */     this.outBindAccessors = paramArrayOfAccessor1;
/*  408 */     this.numberOfBindPositions = paramInt3;
/*  409 */     this.definesAccessors = paramArrayOfAccessor2;
/*  410 */     this.definesLength = paramInt4;
/*  411 */     this.bindBytes = paramArrayOfbyte2;
/*  412 */     this.bindChars = paramArrayOfchar1;
/*  413 */     this.bindIndicators = paramArrayOfshort1;
/*  414 */     this.bindIndicatorSubRange = paramInt5;
/*  415 */     this.conversion = paramDBConversion;
/*  416 */     this.tmpBindsByteArray = paramArrayOfbyte3;
/*  417 */     this.parameterStream = paramArrayOfInputStream;
/*  418 */     this.parameterDatum = paramArrayOfbyte;
/*  419 */     this.parameterOtype = paramArrayOfOracleTypeADT;
/*  420 */     this.oracleStatement = paramOracleStatement;
/*  421 */     this.ibtBindBytes = paramArrayOfbyte4;
/*  422 */     this.ibtBindChars = paramArrayOfchar2;
/*  423 */     this.ibtBindIndicators = paramArrayOfshort2;
/*  424 */     this.oacdefBindsSent = paramArrayOfT4CTTIoac;
/*  425 */     this.definedColumnType = paramArrayOfint1;
/*  426 */     this.definedColumnSize = paramArrayOfint2;
/*  427 */     this.definedColumnFormOfUse = paramArrayOfint3;
/*  428 */     this.registration = paramNTFDCNRegistration;
/*      */ 
/*      */     
/*  431 */     this.dbCharSet = paramDBConversion.getServerCharSetId();
/*  432 */     this.NCharSet = paramDBConversion.getNCharSetId();
/*      */ 
/*      */     
/*  435 */     int i = 0;
/*  436 */     if (this.bindIndicators != null) {
/*  437 */       i = ((this.bindIndicators[this.bindIndicatorSubRange + 3] & 0xFFFF) << 16) + (this.bindIndicators[this.bindIndicatorSubRange + 4] & 0xFFFF);
/*      */     }
/*      */ 
/*      */     
/*  441 */     if (paramArrayOfbyte1 == null) {
/*      */ 
/*      */       
/*  444 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 431);
/*  445 */       sQLException.fillInStackTrace();
/*  446 */       throw sQLException;
/*      */     } 
/*      */     
/*  449 */     if (!this.typeOfStatement.isDML() && i > 1) {
/*      */ 
/*      */ 
/*      */       
/*  453 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 433);
/*  454 */       sQLException.fillInStackTrace();
/*  455 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  460 */     this.rowsProcessed = 0;
/*  461 */     this.options = 0L;
/*  462 */     this.plsql = this.typeOfStatement.isPlsqlOrCall();
/*  463 */     this.sendBindsDefinition = false;
/*      */ 
/*      */     
/*  466 */     if (this.receiveState != 0)
/*      */     {
/*      */ 
/*      */ 
/*      */       
/*  471 */       this.receiveState = 0;
/*      */     }
/*      */     
/*  474 */     this.rxh.init();
/*  475 */     this.rxd.init();
/*  476 */     this.oer.init();
/*      */ 
/*      */     
/*  479 */     if (paramBoolean5) {
/*  480 */       initDefinesDefinition();
/*      */     }
/*  482 */     if (this.numberOfBindPositions > 0 && this.bindIndicators != null) {
/*      */       
/*  484 */       if (this.oacdefBindsSent == null)
/*  485 */         this.oacdefBindsSent = new T4CTTIoac[this.numberOfBindPositions]; 
/*  486 */       this.sendBindsDefinition = initBindsDefinition(this.oacdefBindsSent);
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  496 */     this.options = setOptions(paramBoolean1, paramBoolean2, paramBoolean3, paramBoolean5);
/*      */     
/*  498 */     if ((this.options & 0x1L) > 0L) {
/*  499 */       this.al8i4[0] = 1L;
/*      */     } else {
/*  501 */       this.al8i4[0] = 0L;
/*      */     } 
/*      */     
/*  504 */     if (this.plsql || this.typeOfStatement.isOTHER()) {
/*  505 */       this.al8i4[1] = 1L;
/*  506 */     } else if (paramBoolean4) {
/*      */       
/*  508 */       if (paramBoolean3 && this.oracleStatement.isFetchStreams) {
/*  509 */         this.al8i4[1] = this.rowsToFetch;
/*      */       } else {
/*  511 */         this.al8i4[1] = 0L;
/*      */       } 
/*  513 */     } else if (this.typeOfStatement.isDML()) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  519 */       this.al8i4[1] = (i == 0) ? this.oracleStatement.batch : i;
/*      */     }
/*  521 */     else if (paramBoolean3 && !paramBoolean4) {
/*      */       
/*  523 */       this.al8i4[1] = this.rowsToFetch;
/*      */     } else {
/*  525 */       this.al8i4[1] = 0L;
/*      */     } 
/*      */     
/*  528 */     if (this.typeOfStatement.isSELECT()) {
/*  529 */       this.al8i4[7] = 1L;
/*      */     } else {
/*  531 */       this.al8i4[7] = 0L;
/*      */     } 
/*  533 */     long l = this.oracleStatement.inScn;
/*  534 */     int j = (int)l;
/*  535 */     int k = (int)(l >> 32L);
/*  536 */     this.al8i4[5] = j;
/*  537 */     this.al8i4[6] = k;
/*      */ 
/*      */     
/*  540 */     if (this.typeOfStatement.isDML()) {
/*  541 */       this.al8i4[9] = this.al8i4[9] | 0x4000L;
/*      */     } else {
/*  543 */       this.al8i4[9] = this.al8i4[9] & 0xFFFFFFFFFFFFBFFFL;
/*      */     } 
/*  545 */     this.rowsProcessed = 0;
/*  546 */     this.aFetchWasDone = false;
/*      */ 
/*      */     
/*  549 */     this.rxd.setNumberOfColumns(this.definesLength);
/*      */     
/*  551 */     if ((this.options & 0x40L) != 0L && (this.options & 0x20L) == 0L && (this.options & 0x1L) == 0L && (this.options & 0x8L) == 0L && (this.options & 0x10L) == 0L && !this.oracleStatement.needToSendOalToFetch) {
/*      */ 
/*      */       
/*  554 */       setFunCode((short)5);
/*      */     } else {
/*  556 */       setFunCode((short)94);
/*  557 */     }  if ((this.options & 0x20L) != 0L) {
/*  558 */       this.al8i4[9] = this.al8i4[9] | 0x8000L;
/*      */     } else {
/*  560 */       this.al8i4[9] = this.al8i4[9] & 0xFFFFFFFFFFFF7FFFL;
/*      */     } 
/*  562 */     if (getFunCode() == 94) {
/*  563 */       ((T4CConnection)this.oracleStatement.connection).setExecutingRPCSQL(this.oracleStatement.sqlObject.actualSql);
/*      */     }
/*  565 */     this.nonFatalIOExceptions = null;
/*  566 */     doRPC();
/*      */ 
/*      */ 
/*      */     
/*  570 */     if ((this.options & 0x20L) != 0L) {
/*  571 */       this.oracleStatement.inScn = 0L;
/*      */     }
/*      */     
/*  574 */     this.ibtBindIndicators = null;
/*  575 */     this.ibtBindChars = null;
/*  576 */     this.ibtBindBytes = null;
/*  577 */     this.tmpBindsByteArray = null;
/*  578 */     this.outBindAccessors = null;
/*  579 */     this.bindBytes = null;
/*  580 */     this.bindChars = null;
/*  581 */     this.bindIndicators = null;
/*  582 */     this.oracleStatement = null;
/*  583 */     this.parameterStream = (InputStream[][])null;
/*      */     
/*  585 */     if (this.nonFatalIOExceptions != null) {
/*      */       
/*  587 */       IOException iOException = this.nonFatalIOExceptions.get(0);
/*      */       
/*      */       try {
/*  590 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 266);
/*  591 */         sQLException.fillInStackTrace();
/*  592 */         throw sQLException;
/*      */       
/*      */       }
/*  595 */       catch (SQLException sQLException) {
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  600 */         sQLException.initCause(iOException);
/*  601 */         throw sQLException;
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void readBVC() throws IOException, SQLException {
/*  615 */     int i = this.meg.unmarshalUB2();
/*      */ 
/*      */     
/*  618 */     this.rxd.unmarshalBVC(i);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void readIOV() throws IOException, SQLException {
/*  626 */     T4CTTIiov t4CTTIiov = new T4CTTIiov(this.connection, this.rxh, this.rxd);
/*      */     
/*  628 */     t4CTTIiov.init();
/*  629 */     t4CTTIiov.unmarshalV10();
/*      */ 
/*      */     
/*  632 */     if (!this.oracleStatement.isDmlReturning && !t4CTTIiov.isIOVectorEmpty()) {
/*      */ 
/*      */       
/*  635 */       byte[] arrayOfByte = t4CTTIiov.getIOVector();
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  640 */       this.outBindAccessors = t4CTTIiov.processRXD(this.outBindAccessors, this.numberOfBindPositions, this.bindBytes, this.bindChars, this.bindIndicators, this.bindIndicatorSubRange, this.conversion, this.tmpBindsByteArray, arrayOfByte, this.parameterStream, this.parameterDatum, this.parameterOtype, this.oracleStatement, null, null, null);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void readRXH() throws IOException, SQLException {
/*  656 */     this.rxh.init();
/*  657 */     this.rxh.unmarshalV10(this.rxd);
/*      */     
/*  659 */     if (this.rxh.uacBufLength > 0) {
/*      */ 
/*      */       
/*  662 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 405);
/*  663 */       sQLException.fillInStackTrace();
/*  664 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/*  668 */     if ((this.rxh.rxhflg & 0x8) == 8) {
/*      */ 
/*      */ 
/*      */       
/*  672 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 449);
/*  673 */       sQLException.fillInStackTrace();
/*  674 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/*  678 */     if ((this.rxh.rxhflg & 0x10) == 16)
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  684 */       for (byte b = 0; b < this.definesAccessors.length; b++) {
/*      */         
/*  686 */         if ((this.definesAccessors[b]).udskpos >= 0 && (this.definesAccessors[b]).udskpos != b) {
/*      */ 
/*      */           
/*  689 */           SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 450);
/*  690 */           sQLException.fillInStackTrace();
/*  691 */           throw sQLException;
/*      */         } 
/*      */       } 
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void processSLG() throws IOException, SQLException {
/*  764 */     readRXH();
/*      */ 
/*      */     
/*  767 */     int[] arrayOfInt = new int[this.numberOfBindPositions];
/*  768 */     for (byte b = 0; b < this.numberOfBindPositions; b++) {
/*  769 */       arrayOfInt[b] = (this.oacdefBindsSent[b]).oacmxl;
/*      */     }
/*      */     
/*  772 */     this.nonFatalIOExceptions = marshalBinds(arrayOfInt, true);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   boolean readRXD() throws IOException, SQLException {
/*  785 */     this.aFetchWasDone = true;
/*      */ 
/*      */     
/*  788 */     if (this.oracleStatement.isDmlReturning && this.numberOfBindPositions > 0) {
/*      */       
/*  790 */       boolean bool = false;
/*  791 */       for (byte b = 0; b < this.oracleStatement.numberOfBindPositions; b++) {
/*      */         
/*  793 */         Accessor accessor = this.oracleStatement.accessors[b];
/*  794 */         if (accessor != null) {
/*      */           
/*  796 */           int i = (int)this.meg.unmarshalUB4();
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  801 */           this.oracleStatement.increaseCapacity(i);
/*  802 */           this.oracleStatement.rowsDmlReturned = i;
/*      */           
/*  804 */           for (byte b1 = 0; b1 < i; b1++)
/*      */           {
/*      */ 
/*      */ 
/*      */             
/*  809 */             accessor.unmarshalOneRow(); } 
/*      */         } 
/*      */       } 
/*  812 */       this.oracleStatement.returnParamsFetched = true;
/*      */     
/*      */     }
/*  815 */     else if (this.iovProcessed || (this.outBindAccessors != null && this.definesAccessors == null)) {
/*      */ 
/*      */ 
/*      */       
/*  819 */       if (this.rxd.unmarshal(this.outBindAccessors, this.numberOfBindPositions))
/*      */       {
/*  821 */         return true;
/*      */       
/*      */       }
/*      */     }
/*  825 */     else if (this.rxd.unmarshal(this.definesAccessors, this.definesLength)) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  831 */       return true;
/*      */     } 
/*      */     
/*  834 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void readRPA() throws IOException, SQLException {
/*  860 */     int i = this.meg.unmarshalUB2();
/*  861 */     int[] arrayOfInt = new int[i];
/*      */     int j;
/*  863 */     for (j = 0; j < i; j++) {
/*  864 */       arrayOfInt[j] = (int)this.meg.unmarshalUB4();
/*      */     }
/*  866 */     j = arrayOfInt[0];
/*  867 */     int k = arrayOfInt[1];
/*  868 */     long l = j & 0xFFFFFFFFL | (k & 0xFFFFFFFFL) << 32L;
/*      */ 
/*      */     
/*  871 */     if (l != 0L) {
/*  872 */       this.oracleStatement.connection.outScn = l;
/*      */     }
/*      */ 
/*      */     
/*  876 */     this.cursor = arrayOfInt[2];
/*      */ 
/*      */     
/*  879 */     int m = this.meg.unmarshalUB2();
/*      */     
/*  881 */     byte[] arrayOfByte = null;
/*  882 */     if (m > 0) {
/*  883 */       arrayOfByte = this.meg.unmarshalNBytes(m);
/*      */     }
/*      */     
/*  886 */     int n = this.meg.unmarshalUB2();
/*      */     
/*  888 */     KeywordValue[] arrayOfKeywordValue = new KeywordValue[n]; int i1;
/*  889 */     for (i1 = 0; i1 < n; i1++) {
/*  890 */       arrayOfKeywordValue[i1] = KeywordValueI.unmarshal(this.meg);
/*      */     }
/*  892 */     this.connection.updateSessionProperties(arrayOfKeywordValue);
/*      */ 
/*      */     
/*  895 */     this.oracleStatement.dcnQueryId = -1L;
/*  896 */     this.oracleStatement.dcnTableName = null;
/*  897 */     if (this.connection.getTTCVersion() >= 4) {
/*      */       
/*  899 */       i1 = (int)this.meg.unmarshalUB4();
/*  900 */       byte[] arrayOfByte1 = this.meg.unmarshalNBytes(i1);
/*  901 */       if (i1 > 0 && this.registration != null) {
/*      */         
/*  903 */         boolean bool = false;
/*  904 */         Properties properties = this.registration.getRegistrationOptions();
/*  905 */         if (properties != null) {
/*      */           
/*  907 */           String str1 = properties.getProperty("DCN_QUERY_CHANGE_NOTIFICATION");
/*  908 */           if (str1 != null && str1.compareToIgnoreCase("true") == 0)
/*  909 */             bool = true; 
/*      */         } 
/*  911 */         int i2 = i1;
/*  912 */         if (bool) {
/*  913 */           i2 = i1 - 8;
/*      */         }
/*  915 */         String str = new String(arrayOfByte1, 0, i2);
/*  916 */         char[] arrayOfChar = { Character.MIN_VALUE };
/*  917 */         String[] arrayOfString = str.split(new String(arrayOfChar));
/*  918 */         this.registration.addTablesName(arrayOfString, arrayOfString.length);
/*      */         
/*  920 */         this.oracleStatement.dcnTableName = arrayOfString;
/*      */         
/*  922 */         if (bool) {
/*      */ 
/*      */           
/*  925 */           int i3 = arrayOfByte1[i1 - 1] & 0xFF | (arrayOfByte1[i1 - 2] & 0xFF) << 8 | (arrayOfByte1[i1 - 3] & 0xFF) << 16 | (arrayOfByte1[i1 - 4] & 0xFF) << 24;
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  930 */           int i4 = arrayOfByte1[i1 - 5] & 0xFF | (arrayOfByte1[i1 - 6] & 0xFF) << 8 | (arrayOfByte1[i1 - 7] & 0xFF) << 16 | (arrayOfByte1[i1 - 8] & 0xFF) << 24;
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  935 */           long l1 = i4 & 0xFFFFFFFFL | (i3 & 0xFFFFFFFFL) << 32L;
/*  936 */           this.oracleStatement.dcnQueryId = l1;
/*      */         } 
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/*  942 */     if (this.connection.getTTCVersion() >= 7 && this.typeOfStatement.isDML()) {
/*      */       
/*  944 */       i1 = (int)this.meg.unmarshalUB4();
/*  945 */       int[] arrayOfInt1 = new int[i1];
/*  946 */       for (byte b = 0; b < i1; b++)
/*      */       {
/*  948 */         arrayOfInt1[b] = (int)this.meg.unmarshalSB8();
/*      */       }
/*  950 */       this.oracleStatement.batchRowsUpdatedArray = arrayOfInt1;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void readDCB() throws IOException, SQLException {
/*  962 */     this.dcb.init(this.oracleStatement, 0);
/*      */     
/*  964 */     this.definesAccessors = this.dcb.receive(this.definesAccessors);
/*  965 */     this.numberOfDefinePositions = this.dcb.numuds;
/*  966 */     this.definesLength = this.numberOfDefinePositions;
/*      */     
/*  968 */     this.rxd.setNumberOfColumns(this.numberOfDefinePositions);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void readIMPLRES() throws IOException, SQLException {
/*  976 */     this.implres.init(this.oracleStatement);
/*      */     
/*  978 */     int i = (int)this.meg.unmarshalUB4();
/*  979 */     this.oracleStatement.implicitResultSetStatements = new ArrayDeque<>(i);
/*  980 */     while (i != 0) {
/*      */ 
/*      */       
/*  983 */       this.implres.readImplicitResultSet();
/*  984 */       i--;
/*      */     } 
/*  986 */     this.oracleStatement.implicitResultSetIterator = this.oracleStatement.implicitResultSetStatements.iterator();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void processError() throws SQLException {
/*  997 */     this.cursor = this.oer.currCursorID;
/*      */ 
/*      */ 
/*      */     
/* 1001 */     this.rowsProcessed = this.oer.getCurRowNumber();
/*      */ 
/*      */     
/* 1004 */     this.oracleStatement.isComplete |= (this.oer.retCode == 1403) ? 1 : 0;
/* 1005 */     if (this.typeOfStatement.isSELECT() && this.oer.retCode == 1403)
/*      */     {
/* 1007 */       this.aFetchWasDone = true;
/*      */     }
/*      */     
/* 1010 */     if (!this.typeOfStatement.isSELECT() || (this.typeOfStatement.isSELECT() && this.oer.retCode != 1403)) {
/*      */       
/* 1012 */       if (this.oracleStatement.connection.checksumMode.needToCalculateFetchChecksum() && this.oer.retCode != 0) {
/*      */         
/* 1014 */         long l = this.oer.updateChecksum(this.oracleStatement.checkSum);
/* 1015 */         this.oracleStatement.checkSum = l;
/*      */       } 
/* 1017 */       this.oer.processError(this.oracleStatement);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   int getCursorId() {
/* 1030 */     return this.cursor;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void continueReadRow(int paramInt, OracleStatement paramOracleStatement) throws SQLException, IOException {
/*      */     try {
/* 1047 */       this.oracleStatement = paramOracleStatement;
/*      */ 
/*      */ 
/*      */       
/* 1051 */       this.receiveState = 2;
/*      */       
/* 1053 */       if (this.rxd.unmarshal(this.definesAccessors, paramInt, this.definesLength)) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1059 */         this.receiveState = 3;
/*      */ 
/*      */         
/*      */         return;
/*      */       } 
/*      */       
/* 1065 */       resumeReceive();
/*      */     }
/*      */     finally {
/*      */       
/* 1069 */       this.oracleStatement = null;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   int getNumRows() {
/* 1082 */     int i = 0;
/*      */     
/* 1084 */     if (this.typeOfStatement == null) {
/* 1085 */       return i;
/*      */     }
/* 1087 */     if (this.receiveState == 3) {
/* 1088 */       i = -2;
/*      */     } else {
/*      */       
/* 1091 */       switch (this.typeOfStatement) {
/*      */         case DELETE:
/*      */         case INSERT:
/*      */         case MERGE:
/*      */         case UPDATE:
/*      */         case ALTER_SESSION:
/*      */         case OTHER:
/*      */         case PLSQL_BLOCK:
/*      */         case CALL_BLOCK:
/* 1100 */           i = this.rowsProcessed;
/*      */           break;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         case SELECT_FOR_UPDATE:
/*      */         case SELECT:
/* 1110 */           assert this.definesAccessors == null || this.definesAccessors[0] != null : "definesAccessors is not null but definesAccessors[0] is null";
/* 1111 */           i = (this.definesAccessors != null && this.definesLength > 0 && this.definesAccessors[0] != null) ? (this.definesAccessors[0]).lastRowProcessed : 0;
/*      */           break;
/*      */       } 
/*      */ 
/*      */     
/*      */     } 
/* 1117 */     return i;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void marshal() throws IOException {
/* 1129 */     if (getFunCode() == 5) {
/*      */       
/* 1131 */       this.meg.marshalSWORD(this.cursor);
/* 1132 */       this.meg.marshalSWORD((int)this.al8i4[1]);
/*      */     }
/*      */     else {
/*      */       
/* 1136 */       if (this.oracleStatement.needToSendOalToFetch) {
/* 1137 */         this.oracleStatement.needToSendOalToFetch = false;
/*      */       }
/* 1139 */       marshalPisdef();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1145 */       this.meg.marshalCHR(this.sqlStmt);
/*      */ 
/*      */       
/* 1148 */       this.meg.marshalUB4Array(this.al8i4);
/*      */ 
/*      */       
/* 1151 */       int[] arrayOfInt = new int[this.numberOfBindPositions];
/*      */       byte b;
/* 1153 */       for (b = 0; b < this.numberOfBindPositions; b++)
/*      */       {
/* 1155 */         arrayOfInt[b] = (this.oacdefBindsSent[b]).oacmxl;
/*      */       }
/*      */ 
/*      */       
/* 1159 */       if ((this.options & 0x8L) != 0L && this.numberOfBindPositions > 0 && this.bindIndicators != null && this.sendBindsDefinition)
/*      */       {
/* 1161 */         marshalBindsTypes(this.oacdefBindsSent);
/*      */       }
/*      */ 
/*      */       
/* 1165 */       if (this.connection.getTTCVersion() >= 2 && (this.options & 0x10L) != 0L)
/*      */       {
/* 1167 */         for (b = 0; b < this.defCols; b++) {
/* 1168 */           this.oacdefDefines[b].marshal();
/*      */         }
/*      */       }
/*      */ 
/*      */ 
/*      */       
/* 1174 */       if ((this.options & 0x20L) != 0L && this.numberOfBindPositions > 0 && this.bindIndicators != null)
/*      */       {
/* 1176 */         this.nonFatalIOExceptions = marshalBinds(arrayOfInt, false);
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void marshalPisdef() throws IOException {
/* 1196 */     this.meg.marshalUB4(this.options);
/*      */ 
/*      */     
/* 1199 */     this.meg.marshalSWORD(this.cursor);
/*      */ 
/*      */ 
/*      */     
/* 1203 */     if (this.sqlStmt.length == 0) {
/* 1204 */       this.meg.marshalNULLPTR();
/*      */     } else {
/* 1206 */       this.meg.marshalPTR();
/*      */     } 
/*      */     
/* 1209 */     this.meg.marshalSWORD(this.sqlStmt.length);
/*      */ 
/*      */ 
/*      */     
/* 1213 */     if (this.al8i4.length == 0) {
/* 1214 */       this.meg.marshalNULLPTR();
/*      */     } else {
/* 1216 */       this.meg.marshalPTR();
/*      */     } 
/*      */     
/* 1219 */     this.meg.marshalSWORD(this.al8i4.length);
/*      */ 
/*      */ 
/*      */     
/* 1223 */     this.meg.marshalNULLPTR();
/*      */ 
/*      */     
/* 1226 */     this.meg.marshalNULLPTR();
/*      */ 
/*      */     
/* 1229 */     if ((this.options & 0x40L) == 0L && (this.options & 0x20L) != 0L && (this.options & 0x1L) != 0L && this.typeOfStatement.isSELECT()) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1235 */       this.meg.marshalUB4(Long.MAX_VALUE);
/* 1236 */       this.meg.marshalUB4(this.rowsToFetch);
/*      */     
/*      */     }
/*      */     else {
/*      */       
/* 1241 */       this.meg.marshalUB4(0L);
/*      */       
/* 1243 */       this.meg.marshalUB4(0L);
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 1248 */     if (!this.typeOfStatement.isPlsqlOrCall()) {
/* 1249 */       this.meg.marshalUB4(2147483647L);
/*      */     } else {
/* 1251 */       this.meg.marshalUB4(32760L);
/*      */     } 
/*      */     
/* 1254 */     if ((this.options & 0x8L) != 0L && this.numberOfBindPositions > 0 && this.sendBindsDefinition) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1259 */       this.meg.marshalPTR();
/*      */ 
/*      */       
/* 1262 */       this.meg.marshalSWORD(this.numberOfBindPositions);
/*      */     
/*      */     }
/*      */     else {
/*      */ 
/*      */       
/* 1268 */       this.meg.marshalNULLPTR();
/*      */ 
/*      */       
/* 1271 */       this.meg.marshalSWORD(0);
/*      */     } 
/*      */ 
/*      */     
/* 1275 */     this.meg.marshalNULLPTR();
/*      */ 
/*      */     
/* 1278 */     this.meg.marshalNULLPTR();
/*      */ 
/*      */     
/* 1281 */     this.meg.marshalNULLPTR();
/*      */ 
/*      */     
/* 1284 */     this.meg.marshalNULLPTR();
/*      */ 
/*      */     
/* 1287 */     this.meg.marshalNULLPTR();
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1292 */     if (this.connection.getTTCVersion() >= 2)
/*      */     {
/* 1294 */       if (this.defCols > 0 && (this.options & 0x10L) != 0L) {
/*      */ 
/*      */ 
/*      */         
/* 1298 */         this.meg.marshalPTR();
/*      */ 
/*      */         
/* 1301 */         this.meg.marshalSWORD(this.defCols);
/*      */       
/*      */       }
/*      */       else {
/*      */ 
/*      */         
/* 1307 */         this.meg.marshalNULLPTR();
/*      */ 
/*      */         
/* 1310 */         this.meg.marshalSWORD(0);
/*      */       } 
/*      */     }
/*      */     
/* 1314 */     if (this.connection.getTTCVersion() >= 4) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1323 */       int i = 0;
/* 1324 */       int j = 0;
/* 1325 */       if (this.registration != null) {
/*      */         
/* 1327 */         long l = this.registration.getRegId();
/* 1328 */         i = (int)(l & 0xFFFFFFFFFFFFFFFFL);
/* 1329 */         j = (int)((l & 0xFFFFFFFF00000000L) >> 32L);
/*      */       } 
/*      */ 
/*      */       
/* 1333 */       this.meg.marshalUB4(i);
/*      */       
/* 1335 */       this.meg.marshalNULLPTR();
/* 1336 */       this.meg.marshalPTR();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1357 */       if (this.connection.getTTCVersion() >= 5) {
/*      */         
/* 1359 */         this.meg.marshalNULLPTR();
/* 1360 */         this.meg.marshalUB4(0L);
/* 1361 */         this.meg.marshalNULLPTR();
/* 1362 */         this.meg.marshalUB4(0L);
/*      */         
/* 1364 */         this.meg.marshalUB4(j);
/*      */         
/* 1366 */         if (this.connection.getTTCVersion() >= 7)
/*      */         {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 1374 */           if (this.typeOfStatement.isDML()) {
/*      */             
/* 1376 */             this.meg.marshalPTR();
/* 1377 */             this.meg.marshalUB4(this.oracleStatement.currentRank);
/* 1378 */             this.meg.marshalPTR();
/*      */           }
/*      */           else {
/*      */             
/* 1382 */             this.meg.marshalNULLPTR();
/* 1383 */             this.meg.marshalUB4(0L);
/* 1384 */             this.meg.marshalNULLPTR();
/*      */           } 
/*      */         }
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   boolean initBindsDefinition(T4CTTIoac[] paramArrayOfT4CTTIoac) throws SQLException, IOException {
/* 1402 */     boolean bool = false;
/*      */     
/* 1404 */     if (paramArrayOfT4CTTIoac.length != this.numberOfBindPositions) {
/*      */       
/* 1406 */       bool = true;
/* 1407 */       paramArrayOfT4CTTIoac = new T4CTTIoac[this.numberOfBindPositions];
/*      */     } 
/*      */ 
/*      */     
/* 1411 */     short[] arrayOfShort = this.bindIndicators;
/*      */ 
/*      */     
/* 1414 */     int i = 0;
/*      */ 
/*      */     
/* 1417 */     byte b1 = 0;
/*      */ 
/*      */     
/* 1420 */     for (byte b2 = 0; b2 < this.numberOfBindPositions; b2++) {
/*      */       SQLException sQLException; int arrayOfInt[], m;
/* 1422 */       T4CTTIoac t4CTTIoac = new T4CTTIoac(this.connection);
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1427 */       int j = this.bindIndicatorSubRange + 5 + 10 * b2;
/*      */ 
/*      */ 
/*      */       
/* 1431 */       short s = arrayOfShort[j + 9];
/*      */ 
/*      */       
/* 1434 */       int k = arrayOfShort[j + 0] & 0xFFFF;
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1439 */       switch (k) {
/*      */ 
/*      */         
/*      */         case 8:
/*      */         case 24:
/* 1444 */           if (this.plsql) {
/* 1445 */             i = 32760;
/*      */           } else {
/* 1447 */             i = Integer.MAX_VALUE;
/*      */           } 
/* 1449 */           t4CTTIoac.init((short)k, i);
/* 1450 */           t4CTTIoac.setFormOfUse(s);
/* 1451 */           t4CTTIoac.setCharset((s == 2) ? this.NCharSet : this.dbCharSet);
/*      */           break;
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         case 998:
/* 1458 */           if (this.outBindAccessors != null && this.outBindAccessors[b2] != null) {
/*      */             
/* 1460 */             PlsqlIbtBindInfo plsqlIbtBindInfo = this.outBindAccessors[b2].plsqlIndexTableBindInfo();
/*      */             
/* 1462 */             t4CTTIoac.init((short)plsqlIbtBindInfo.element_internal_type, plsqlIbtBindInfo.elemMaxLen);
/*      */             
/* 1464 */             t4CTTIoac.setMal(plsqlIbtBindInfo.maxLen);
/* 1465 */             t4CTTIoac.addFlg((short)64);
/* 1466 */             b1++; break;
/*      */           } 
/* 1468 */           if (this.ibtBindIndicators[6 + b1 * 8] != 0) {
/*      */             
/* 1470 */             short s1 = this.ibtBindIndicators[6 + b1 * 8];
/* 1471 */             int n = (this.ibtBindIndicators[6 + b1 * 8 + 2] & 0xFFFF) << 16 | this.ibtBindIndicators[6 + b1 * 8 + 3] & 0xFFFF;
/*      */ 
/*      */ 
/*      */             
/* 1475 */             i = this.ibtBindIndicators[6 + b1 * 8 + 1] * this.conversion.sMaxCharSize;
/*      */             
/* 1477 */             t4CTTIoac.init((short)s1, i);
/* 1478 */             t4CTTIoac.setMal(n);
/* 1479 */             t4CTTIoac.addFlg((short)64);
/* 1480 */             b1++;
/*      */             
/*      */             break;
/*      */           } 
/* 1484 */           sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), "INTERNAL ERROR: Binding PLSQL index-by table but no type defined", -1);
/* 1485 */           sQLException.fillInStackTrace();
/* 1486 */           throw sQLException;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         case 109:
/*      */         case 111:
/* 1494 */           if (this.outBindAccessors != null && this.outBindAccessors[b2] != null) {
/*      */             
/* 1496 */             if ((this.outBindAccessors[b2]).internalOtype != null) {
/*      */               
/* 1498 */               t4CTTIoac.init((short)k, (k == 109) ? 11 : 4000);
/*      */               
/* 1500 */               t4CTTIoac.setADT((OracleTypeADT)((TypeAccessor)this.outBindAccessors[b2]).internalOtype);
/*      */             } 
/*      */             break;
/*      */           } 
/* 1504 */           if (this.parameterOtype != null && this.parameterOtype[this.oracleStatement.firstRowInBatch] != null) {
/*      */ 
/*      */             
/* 1507 */             t4CTTIoac.init((short)k, (k == 109) ? 11 : 4000);
/* 1508 */             t4CTTIoac.setADT(this.parameterOtype[this.oracleStatement.firstRowInBatch][b2]);
/*      */ 
/*      */             
/*      */             break;
/*      */           } 
/*      */           
/* 1514 */           sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), "INTERNAL ERROR: Binding NAMED_TYPE but no type defined", -1);
/* 1515 */           sQLException.fillInStackTrace();
/* 1516 */           throw sQLException;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         case 994:
/* 1524 */           arrayOfInt = this.oracleStatement.returnParamMeta;
/* 1525 */           k = arrayOfInt[3 + b2 * 4 + 0];
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 1530 */           i = arrayOfInt[3 + b2 * 4 + 2];
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 1535 */           s = (short)arrayOfInt[3 + b2 * 4 + 3];
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 1540 */           if (k == 109 || k == 111) {
/*      */             
/* 1542 */             TypeAccessor typeAccessor = (TypeAccessor)this.oracleStatement.accessors[b2];
/*      */ 
/*      */             
/* 1545 */             t4CTTIoac.init((short)k, (k == 109) ? 11 : 4000);
/*      */             
/* 1547 */             t4CTTIoac.setADT((OracleTypeADT)typeAccessor.internalOtype);
/*      */             
/*      */             break;
/*      */           } 
/* 1551 */           t4CTTIoac.init((short)k, i);
/* 1552 */           t4CTTIoac.setFormOfUse(s);
/* 1553 */           t4CTTIoac.setCharset((s == 2) ? this.NCharSet : this.dbCharSet);
/*      */           break;
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         case 180:
/* 1560 */           i = arrayOfShort[j + 1] & 0xFFFF;
/*      */ 
/*      */ 
/*      */           
/* 1564 */           t4CTTIoac.init((short)k, i);
/* 1565 */           t4CTTIoac.addFlg2(134217728);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 1573 */           t4CTTIoac.setTimestampFractionalSecondsPrecision((short)9);
/*      */           
/* 1575 */           m = ((this.bindIndicators[this.bindIndicatorSubRange + 3] & 0xFFFF) << 16) + (this.bindIndicators[this.bindIndicatorSubRange + 4] & 0xFFFF);
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 1580 */           if (m == 1) {
/*      */             
/* 1582 */             int n = ((arrayOfShort[j + 7] & 0xFFFF) << 16) + (arrayOfShort[j + 8] & 0xFFFF);
/*      */ 
/*      */             
/* 1585 */             short s1 = arrayOfShort[n];
/*      */             
/* 1587 */             if (s1 == 7)
/*      */             {
/* 1589 */               t4CTTIoac.setTimestampFractionalSecondsPrecision((short)0);
/*      */             }
/*      */           } 
/*      */           break;
/*      */ 
/*      */         
/*      */         case 182:
/*      */         case 183:
/* 1597 */           i = arrayOfShort[j + 1] & 0xFFFF;
/*      */ 
/*      */ 
/*      */           
/* 1601 */           t4CTTIoac.init((short)k, i);
/* 1602 */           t4CTTIoac.setFormOfUse(s);
/* 1603 */           t4CTTIoac.setCharset((s == 2) ? this.NCharSet : this.dbCharSet);
/*      */           
/* 1605 */           t4CTTIoac.setPrecision((short)9);
/*      */           break;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         default:
/* 1614 */           i = arrayOfShort[j + 1] & 0xFFFF;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 1621 */           if (i == 0) {
/*      */             
/* 1623 */             i = arrayOfShort[j + 2] & 0xFFFF;
/*      */ 
/*      */ 
/*      */             
/* 1627 */             if (k == 996) {
/* 1628 */               i *= 2;
/*      */             }
/* 1630 */             else if (i > 1) {
/* 1631 */               i--;
/*      */             } 
/*      */             
/* 1634 */             if (s == 2) {
/* 1635 */               i *= this.conversion.maxNCharSize;
/*      */             }
/*      */ 
/*      */             
/* 1639 */             if (this.typeOfStatement == OracleStatement.SqlKind.PLSQL_BLOCK || (this.connection.versionNumber >= 10200 && this.typeOfStatement == OracleStatement.SqlKind.CALL_BLOCK)) {
/*      */ 
/*      */ 
/*      */               
/* 1643 */               if (i == 0) {
/* 1644 */                 i = this.connection.maxVcsBytesPlsql;
/*      */               } else {
/* 1646 */                 i *= this.conversion.sMaxCharSize;
/*      */               } 
/* 1648 */             } else if (this.typeOfStatement == OracleStatement.SqlKind.CALL_BLOCK) {
/*      */ 
/*      */ 
/*      */ 
/*      */               
/* 1653 */               if (i < 4001) {
/* 1654 */                 i = 4001;
/*      */               
/*      */               }
/*      */             
/*      */             }
/* 1659 */             else if (s != 2) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */               
/* 1670 */               m = this.connection.maxVarcharLength;
/* 1671 */               if (((T4CConnection)this.oracleStatement.connection).retainV9BindBehavior && i <= m) {
/*      */ 
/*      */                 
/* 1674 */                 i = Math.min(i * this.conversion.sMaxCharSize, m);
/*      */               }
/*      */               else {
/*      */                 
/* 1678 */                 i *= this.conversion.sMaxCharSize;
/*      */               } 
/*      */             } 
/*      */ 
/*      */ 
/*      */             
/* 1684 */             if (i == 0) {
/* 1685 */               i = 32;
/*      */             }
/*      */           } 
/* 1688 */           t4CTTIoac.init((short)k, i);
/* 1689 */           t4CTTIoac.setFormOfUse(s);
/* 1690 */           t4CTTIoac.setCharset((s == 2) ? this.NCharSet : this.dbCharSet);
/*      */           break;
/*      */       } 
/*      */ 
/*      */       
/* 1695 */       if (paramArrayOfT4CTTIoac[b2] == null || !t4CTTIoac.isOldSufficient(paramArrayOfT4CTTIoac[b2])) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1702 */         paramArrayOfT4CTTIoac[b2] = t4CTTIoac;
/* 1703 */         bool = true;
/*      */       } 
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 1709 */     if (bool) {
/* 1710 */       this.oracleStatement.nbPostPonedColumns[0] = 0;
/*      */     }
/* 1712 */     return bool;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void initDefinesDefinition() throws SQLException, IOException {
/* 1726 */     this.defCols = 0;
/*      */     int i;
/* 1728 */     for (i = 0; i < this.definedColumnType.length; i++) {
/*      */       
/* 1730 */       if (this.definedColumnType[i] == 0)
/*      */         break; 
/* 1732 */       this.defCols++;
/*      */     } 
/* 1734 */     this.oacdefDefines = new T4CTTIoac[this.defCols];
/* 1735 */     i = 0;
/* 1736 */     int j = 0;
/* 1737 */     int k = 0;
/* 1738 */     short s = 0;
/* 1739 */     for (byte b = 0; b < this.oacdefDefines.length; b++) {
/*      */       
/* 1741 */       this.oacdefDefines[b] = new T4CTTIoac(this.connection);
/* 1742 */       s = (short)this.oracleStatement.getInternalType(this.definedColumnType[b]);
/* 1743 */       j = Integer.MAX_VALUE;
/* 1744 */       i = 0;
/* 1745 */       k = 0;
/* 1746 */       byte b1 = 1;
/* 1747 */       if (this.definedColumnFormOfUse != null && this.definedColumnFormOfUse.length > b && this.definedColumnFormOfUse[b] == 2)
/*      */       {
/*      */ 
/*      */         
/* 1751 */         b1 = 2;
/*      */       }
/* 1753 */       if (s == 8) {
/* 1754 */         s = 1;
/* 1755 */       } else if (s == 24) {
/* 1756 */         s = 23;
/* 1757 */       } else if (s == 1 || s == 96) {
/*      */ 
/*      */         
/* 1760 */         s = 1;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1766 */         j = this.connection.maxVarcharLength * this.conversion.sMaxCharSize;
/* 1767 */         if (this.definedColumnSize != null && this.definedColumnSize.length > b && this.definedColumnSize[b] > 0)
/*      */         {
/*      */ 
/*      */           
/* 1771 */           j = this.definedColumnSize[b] * this.conversion.sMaxCharSize;
/*      */         }
/* 1773 */       } else if (this.connection.useLobPrefetch && (s == 113 || s == 112 || s == 114)) {
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1778 */         j = 0;
/* 1779 */         i = 33554432;
/* 1780 */         if (this.definedColumnSize != null && this.definedColumnSize.length > b && this.definedColumnSize[b] > 0)
/*      */         {
/*      */ 
/*      */           
/* 1784 */           k = this.definedColumnSize[b];
/*      */         }
/* 1786 */       } else if (s == 23) {
/* 1787 */         j = this.connection.maxRawLength;
/*      */       } 
/* 1789 */       this.oacdefDefines[b].init(s, j);
/* 1790 */       this.oacdefDefines[b].addFlg2(i);
/* 1791 */       this.oacdefDefines[b].setMxlc(k);
/* 1792 */       this.oacdefDefines[b].setFormOfUse(b1);
/* 1793 */       this.oacdefDefines[b].setCharset((b1 == 2) ? this.NCharSet : this.dbCharSet);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void marshalBindsTypes(T4CTTIoac[] paramArrayOfT4CTTIoac) throws IOException {
/* 1803 */     if (paramArrayOfT4CTTIoac == null) {
/*      */       return;
/*      */     }
/* 1806 */     for (byte b = 0; b < paramArrayOfT4CTTIoac.length; b++)
/*      */     {
/* 1808 */       paramArrayOfT4CTTIoac[b].marshal();
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   Vector<IOException> marshalBinds(int[] paramArrayOfint, boolean paramBoolean) throws IOException {
/*      */     byte b;
/*      */     boolean bool;
/* 1825 */     Vector<IOException> vector = null;
/* 1826 */     int i = ((this.bindIndicators[this.bindIndicatorSubRange + 3] & 0xFFFF) << 16) + (this.bindIndicators[this.bindIndicatorSubRange + 4] & 0xFFFF);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1834 */     if (paramBoolean) {
/*      */       
/* 1836 */       b = this.rxh.iterNum;
/* 1837 */       bool = true;
/*      */     }
/*      */     else {
/*      */       
/* 1841 */       b = 0;
/* 1842 */       bool = false;
/*      */     } 
/*      */ 
/*      */     
/* 1846 */     for (; b < i; b++) {
/*      */       
/* 1848 */       int j = this.oracleStatement.firstRowInBatch + b;
/* 1849 */       InputStream[] arrayOfInputStream = null;
/* 1850 */       if (this.parameterStream != null)
/* 1851 */         arrayOfInputStream = this.parameterStream[j]; 
/* 1852 */       byte[][] arrayOfByte = (byte[][])null;
/* 1853 */       if (this.parameterDatum != null)
/* 1854 */         arrayOfByte = this.parameterDatum[j]; 
/* 1855 */       OracleTypeADT[] arrayOfOracleTypeADT = null;
/* 1856 */       if (this.parameterOtype != null) {
/* 1857 */         arrayOfOracleTypeADT = this.parameterOtype[j];
/*      */       }
/*      */       
/* 1860 */       Vector<IOException> vector1 = this.rxd.marshal(this.bindBytes, this.bindChars, this.bindIndicators, this.bindIndicatorSubRange, this.tmpBindsByteArray, this.conversion, arrayOfInputStream, arrayOfByte, arrayOfOracleTypeADT, this.ibtBindBytes, this.ibtBindChars, this.ibtBindIndicators, null, b, paramArrayOfint, this.plsql, this.oracleStatement.returnParamMeta, this.oracleStatement.nbPostPonedColumns, this.oracleStatement.indexOfPostPonedColumn, bool);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1870 */       bool = false;
/*      */       
/* 1872 */       if (vector1 != null) {
/*      */         
/* 1874 */         if (vector == null)
/* 1875 */           vector = new Vector(); 
/* 1876 */         vector.addAll(vector1);
/*      */       } 
/*      */     } 
/* 1879 */     return vector;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   long setOptions(boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3, boolean paramBoolean4) throws SQLException {
/* 1888 */     long l = 0L;
/*      */ 
/*      */     
/* 1891 */     if (paramBoolean1 && !paramBoolean2 && !paramBoolean3) {
/* 1892 */       l |= 0x1L;
/* 1893 */     } else if (paramBoolean1 && paramBoolean2 && !paramBoolean3) {
/* 1894 */       l = 32801L;
/* 1895 */     } else if (paramBoolean2 && paramBoolean3) {
/*      */       SQLException sQLException;
/* 1897 */       if (paramBoolean1) {
/* 1898 */         l |= 0x1L;
/*      */       }
/*      */ 
/*      */ 
/*      */       
/* 1903 */       switch (this.typeOfStatement) {
/*      */ 
/*      */         
/*      */         case SELECT_FOR_UPDATE:
/*      */         case SELECT:
/* 1908 */           l |= 0x8060L;
/*      */           break;
/*      */ 
/*      */ 
/*      */         
/*      */         case PLSQL_BLOCK:
/*      */         case CALL_BLOCK:
/* 1915 */           if (this.numberOfBindPositions > 0) {
/*      */ 
/*      */             
/* 1918 */             l |= 0x420L | (this.oracleStatement.connection.autocommit ? 256L : 0L);
/*      */ 
/*      */             
/* 1921 */             if (this.sendBindsDefinition)
/* 1922 */               l |= 0x8L; 
/*      */             break;
/*      */           } 
/* 1925 */           l |= 0x20L | (this.oracleStatement.connection.autocommit ? 256L : 0L);
/*      */           break;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         case DELETE:
/*      */         case INSERT:
/*      */         case MERGE:
/*      */         case UPDATE:
/*      */         case ALTER_SESSION:
/*      */         case OTHER:
/* 1940 */           if (this.oracleStatement.isDmlReturning) {
/* 1941 */             l |= 0x420L | (this.oracleStatement.connection.autocommit ? 256L : 0L);
/*      */             break;
/*      */           } 
/* 1944 */           l |= 0x8020L | (this.oracleStatement.connection.autocommit ? 256L : 0L);
/*      */           break;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         default:
/* 1952 */           sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 432);
/* 1953 */           sQLException.fillInStackTrace();
/* 1954 */           throw sQLException;
/*      */       } 
/*      */ 
/*      */     
/* 1958 */     } else if (!paramBoolean1 && !paramBoolean2 && paramBoolean3) {
/* 1959 */       l = 32832L;
/*      */     }
/*      */     else {
/*      */       
/* 1963 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 432);
/* 1964 */       sQLException.fillInStackTrace();
/* 1965 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 1970 */     if (!this.typeOfStatement.isPlsqlOrCall()) {
/*      */ 
/*      */ 
/*      */       
/* 1974 */       if (paramBoolean1 || paramBoolean2 || !paramBoolean3)
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1981 */         if (this.numberOfBindPositions > 0 && this.sendBindsDefinition) {
/* 1982 */           l |= 0x8L;
/*      */         }
/*      */       }
/* 1985 */       if (this.connection.versionNumber >= 9000 && paramBoolean4)
/*      */       {
/* 1987 */         l |= 0x10L;
/*      */       }
/*      */     } 
/*      */     
/* 1991 */     l &= 0xFFFFFFFFFFFFFFFFL;
/*      */ 
/*      */     
/* 1994 */     return l;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected OracleConnection getConnectionDuringExceptionHandling() {
/* 2009 */     return this.connection;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/* 2014 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*      */   public static final String BUILD_DATE = "Thu_Apr_04_15:09:24_PDT_2013";
/*      */   public static final boolean TRACE = false;
/*      */ }


/* Location:              C:\Users\olatu\OneDrive\Documents\Calypso\syncbase\sync_base.jar!\BOOT-INF\lib\ojdbc-7.jar!\oracle\jdbc\driver\T4C8Oall.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */