/*     */ package oracle.jdbc.driver;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.sql.SQLException;
/*     */ import oracle.jdbc.internal.OracleConnection;
/*     */ import oracle.jdbc.internal.XSSecureId;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class T4CTTIoxsdes
/*     */   extends T4CTTIfun
/*     */ {
/*     */   private byte[] kpxsdesopsid;
/*     */   private XSSecureId kpxsdesopsidp;
/*     */   private byte[] kpxsdesopcookie;
/*     */   
/*     */   T4CTTIoxsdes(T4CConnection paramT4CConnection) {
/*  36 */     super(paramT4CConnection, (byte)3);
/*  37 */     setFunCode((short)182);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void doOXSDES(byte[] paramArrayOfbyte1, XSSecureId paramXSSecureId, byte[] paramArrayOfbyte2) throws IOException, SQLException {
/*  48 */     this.kpxsdesopsid = paramArrayOfbyte1;
/*  49 */     this.kpxsdesopsidp = paramXSSecureId;
/*  50 */     this.kpxsdesopcookie = paramArrayOfbyte2;
/*     */     
/*  52 */     doRPC();
/*     */   }
/*     */ 
/*     */   
/*     */   void marshal() throws IOException {
/*  57 */     boolean bool1 = false;
/*  58 */     if (this.kpxsdesopsid != null && this.kpxsdesopsid.length > 0) {
/*     */       
/*  60 */       bool1 = true;
/*  61 */       this.meg.marshalPTR();
/*  62 */       this.meg.marshalUB4(this.kpxsdesopsid.length);
/*     */     }
/*     */     else {
/*     */       
/*  66 */       this.meg.marshalNULLPTR();
/*  67 */       this.meg.marshalUB4(0L);
/*     */     } 
/*  69 */     boolean bool2 = false;
/*  70 */     if (this.kpxsdesopsidp != null) {
/*     */       
/*  72 */       bool2 = true;
/*  73 */       this.meg.marshalPTR();
/*     */     }
/*     */     else {
/*     */       
/*  77 */       this.meg.marshalNULLPTR();
/*     */     } 
/*     */     
/*  80 */     boolean bool3 = false;
/*  81 */     if (this.kpxsdesopcookie != null && this.kpxsdesopcookie.length > 0) {
/*     */       
/*  83 */       bool3 = true;
/*  84 */       this.meg.marshalPTR();
/*  85 */       this.meg.marshalUB4(this.kpxsdesopcookie.length);
/*     */     }
/*     */     else {
/*     */       
/*  89 */       this.meg.marshalNULLPTR();
/*  90 */       this.meg.marshalUB4(0L);
/*     */     } 
/*     */ 
/*     */     
/*  94 */     if (bool1)
/*  95 */       this.meg.marshalB1Array(this.kpxsdesopsid); 
/*  96 */     if (bool2)
/*  97 */       ((XSSecureIdI)this.kpxsdesopsidp).marshal(this.meg); 
/*  98 */     if (bool3) {
/*  99 */       this.meg.marshalB1Array(this.kpxsdesopcookie);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected OracleConnection getConnectionDuringExceptionHandling() {
/* 113 */     return this.connection;
/*     */   }
/*     */ }


/* Location:              C:\Users\olatu\OneDrive\Documents\Calypso\syncbase\sync_base.jar!\BOOT-INF\lib\ojdbc-7.jar!\oracle\jdbc\driver\T4CTTIoxsdes.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */