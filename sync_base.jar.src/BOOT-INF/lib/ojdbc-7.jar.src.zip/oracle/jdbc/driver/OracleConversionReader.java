/*     */ package oracle.jdbc.driver;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.Reader;
/*     */ import java.sql.SQLException;
/*     */ import oracle.jdbc.internal.OracleConnection;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class OracleConversionReader
/*     */   extends Reader
/*     */ {
/*     */   static final int CHUNK_SIZE = 32768;
/*     */   DBConversion dbConversion;
/*     */   int conversion;
/*     */   InputStream istream;
/*     */   char[] buf;
/*     */   byte[] byteBuf;
/*     */   int pos;
/*     */   int count;
/*     */   int numUnconvertedBytes;
/*     */   boolean isClosed;
/*     */   boolean endOfStream;
/*     */   private short csform;
/*     */   int[] nbytes;
/*     */   
/*     */   public OracleConversionReader(DBConversion paramDBConversion, InputStream paramInputStream, int paramInt) throws SQLException {
/*  57 */     if (paramDBConversion == null || paramInputStream == null || (paramInt != 8 && paramInt != 9)) {
/*     */ 
/*     */ 
/*     */       
/*  61 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/*  62 */       sQLException.fillInStackTrace();
/*  63 */       throw sQLException;
/*     */     } 
/*     */     
/*  66 */     this.dbConversion = paramDBConversion;
/*  67 */     this.conversion = paramInt;
/*  68 */     this.istream = paramInputStream;
/*  69 */     this.pos = this.count = 0;
/*  70 */     this.numUnconvertedBytes = 0;
/*     */     
/*  72 */     this.isClosed = false;
/*  73 */     this.nbytes = new int[1];
/*     */     
/*  75 */     if (paramInt == 8) {
/*     */       
/*  77 */       this.byteBuf = new byte[16384];
/*  78 */       this.buf = new char[32768];
/*     */     }
/*  80 */     else if (paramInt == 9) {
/*     */       
/*  82 */       this.byteBuf = new byte[32768];
/*  83 */       this.buf = new char[32768];
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setFormOfUse(short paramShort) {
/*  92 */     this.csform = paramShort;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int read(char[] paramArrayOfchar, int paramInt1, int paramInt2) throws IOException {
/* 119 */     ensureOpen();
/*     */     
/* 121 */     if (!needChars()) {
/* 122 */       return -1;
/*     */     }
/* 124 */     int i = paramInt1;
/* 125 */     int j = i + Math.min(paramInt2, paramArrayOfchar.length - paramInt1);
/*     */     
/* 127 */     i += writeChars(paramArrayOfchar, i, j - i);
/*     */     
/* 129 */     while (i < j && needChars())
/*     */     {
/* 131 */       i += writeChars(paramArrayOfchar, i, j - i);
/*     */     }
/*     */     
/* 134 */     return i - paramInt1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean needChars() throws IOException {
/* 148 */     ensureOpen();
/*     */     
/* 150 */     if (this.pos >= this.count) {
/*     */ 
/*     */ 
/*     */       
/* 154 */       if (!this.endOfStream) {
/*     */         
/*     */         try {
/*     */           
/* 158 */           int i = this.istream.read(this.byteBuf, this.numUnconvertedBytes, this.byteBuf.length - this.numUnconvertedBytes);
/*     */ 
/*     */           
/* 161 */           if (i == -1) {
/*     */             
/* 163 */             this.endOfStream = true;
/*     */             
/* 165 */             this.istream.close();
/*     */             
/* 167 */             if (this.numUnconvertedBytes != 0) {
/*     */               
/* 169 */               SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 55);
/* 170 */               sQLException.fillInStackTrace();
/* 171 */               throw sQLException;
/*     */             } 
/*     */           } 
/*     */           
/* 175 */           i += this.numUnconvertedBytes;
/*     */           
/* 177 */           if (i > 0) {
/*     */             byte b; SQLException sQLException;
/* 179 */             switch (this.conversion) {
/*     */ 
/*     */ 
/*     */               
/*     */               case 8:
/* 184 */                 this.count = DBConversion.RAWBytesToHexChars(this.byteBuf, i, this.buf);
/*     */                 break;
/*     */ 
/*     */ 
/*     */ 
/*     */               
/*     */               case 9:
/* 191 */                 this.nbytes[0] = i;
/*     */                 
/* 193 */                 if (this.csform == 2) {
/* 194 */                   this.count = this.dbConversion.NCHARBytesToJavaChars(this.byteBuf, 0, this.buf, 0, this.nbytes, this.buf.length);
/*     */                 
/*     */                 }
/*     */                 else {
/*     */                   
/* 199 */                   this.count = this.dbConversion.CHARBytesToJavaChars(this.byteBuf, 0, this.buf, 0, this.nbytes, this.buf.length);
/*     */                 } 
/*     */ 
/*     */ 
/*     */                 
/* 204 */                 this.numUnconvertedBytes = this.nbytes[0];
/*     */                 
/* 206 */                 for (b = 0; b < this.numUnconvertedBytes; b++) {
/* 207 */                   this.byteBuf[b] = this.byteBuf[i - this.numUnconvertedBytes + b];
/*     */                 }
/*     */                 break;
/*     */ 
/*     */ 
/*     */               
/*     */               default:
/* 214 */                 sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 23);
/* 215 */                 sQLException.fillInStackTrace();
/* 216 */                 throw sQLException;
/*     */             } 
/*     */ 
/*     */             
/* 220 */             if (this.count > 0)
/*     */             {
/* 222 */               this.pos = 0;
/*     */               
/* 224 */               return true;
/*     */             }
/*     */           
/*     */           } 
/* 228 */         } catch (SQLException sQLException) {
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 233 */           IOException iOException = DatabaseError.createIOException(sQLException);
/* 234 */           iOException.fillInStackTrace();
/* 235 */           throw iOException;
/*     */         } 
/*     */       }
/*     */ 
/*     */       
/* 240 */       return false;
/*     */     } 
/*     */     
/* 243 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected int writeChars(char[] paramArrayOfchar, int paramInt1, int paramInt2) {
/* 258 */     int i = Math.min(paramInt2, this.count - this.pos);
/*     */     
/* 260 */     System.arraycopy(this.buf, this.pos, paramArrayOfchar, paramInt1, i);
/*     */     
/* 262 */     this.pos += i;
/*     */     
/* 264 */     return i;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean ready() throws IOException {
/* 286 */     ensureOpen();
/*     */     
/* 288 */     return (this.pos < this.count);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void close() throws IOException {
/* 308 */     if (!this.isClosed) {
/*     */       
/* 310 */       this.isClosed = true;
/*     */       
/* 312 */       this.istream.close();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void ensureOpen() throws IOException {
/*     */     try {
/* 328 */       if (this.isClosed)
/*     */       {
/* 330 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 57, (Object)null);
/* 331 */         sQLException.fillInStackTrace();
/* 332 */         throw sQLException;
/*     */       }
/*     */     
/* 335 */     } catch (SQLException sQLException) {
/*     */ 
/*     */       
/* 338 */       IOException iOException = DatabaseError.createIOException(sQLException);
/* 339 */       iOException.fillInStackTrace();
/* 340 */       throw iOException;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected OracleConnection getConnectionDuringExceptionHandling() {
/* 357 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/* 362 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*     */   public static final String BUILD_DATE = "Thu_Apr_04_15:09:24_PDT_2013";
/*     */   public static final boolean TRACE = false;
/*     */ }


/* Location:              C:\Users\olatu\OneDrive\Documents\Calypso\syncbase\sync_base.jar!\BOOT-INF\lib\ojdbc-7.jar!\oracle\jdbc\driver\OracleConversionReader.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */