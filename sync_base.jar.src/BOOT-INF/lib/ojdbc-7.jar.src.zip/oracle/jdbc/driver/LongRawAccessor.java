/*     */ package oracle.jdbc.driver;
/*     */ 
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.Reader;
/*     */ import java.sql.SQLException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class LongRawAccessor
/*     */   extends RawCommonAccessor
/*     */ {
/*     */   static final int MAXLENGTH = 2147483647;
/*     */   OracleInputStream stream;
/*  30 */   int columnPosition = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   LongRawAccessor(OracleStatement paramOracleStatement, int paramInt1, int paramInt2, short paramShort, int paramInt3) throws SQLException {
/*  36 */     super(paramOracleStatement, 2147483647, false);
/*     */     
/*  38 */     init(paramOracleStatement, 24, 24, paramShort, false);
/*     */     
/*  40 */     this.columnPosition = paramInt1;
/*     */     
/*  42 */     initForDataAccess(paramInt3, paramInt2, (String)null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   LongRawAccessor(OracleStatement paramOracleStatement, int paramInt1, int paramInt2, boolean paramBoolean, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, short paramShort) throws SQLException {
/*  50 */     super(paramOracleStatement, 2147483647, false);
/*     */     
/*  52 */     init(paramOracleStatement, 24, 24, paramShort, false);
/*     */     
/*  54 */     this.columnPosition = paramInt1;
/*     */     
/*  56 */     initForDescribe(24, paramInt2, paramBoolean, paramInt3, paramInt4, paramInt5, paramInt6, paramInt7, paramShort, null);
/*     */ 
/*     */     
/*  59 */     int i = paramOracleStatement.maxFieldSize;
/*     */     
/*  61 */     if (i > 0 && (paramInt2 == 0 || i < paramInt2)) {
/*  62 */       paramInt2 = i;
/*     */     }
/*  64 */     initForDataAccess(0, paramInt2, (String)null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void initForDataAccess(int paramInt1, int paramInt2, String paramString) throws SQLException {
/*  72 */     if (paramInt1 != 0) {
/*  73 */       this.externalType = paramInt1;
/*     */     }
/*  75 */     this.isStream = true;
/*  76 */     this.isColumnNumberAware = true;
/*     */     
/*  78 */     this.byteLength = 0;
/*     */ 
/*     */     
/*  81 */     this.stream = this.statement.connection.driverExtension.createInputStream(this.statement, this.columnPosition, this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   OracleInputStream initForNewRow() throws SQLException {
/*  96 */     this.stream = this.statement.connection.driverExtension.createInputStream(this.statement, this.columnPosition, this);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 101 */     return this.stream;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void updateColumnNumber(int paramInt) {
/* 113 */     this.columnPosition = ++paramInt;
/*     */     
/* 115 */     if (this.stream != null) {
/* 116 */       this.stream.columnIndex = paramInt;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   byte[] getBytesInternal(int paramInt) throws SQLException {
/* 128 */     if (isNull(paramInt)) return null; 
/* 129 */     if (this.statement.isFetchStreams) return super.getBytesInternal(paramInt); 
/* 130 */     if (this.stream == null) return null; 
/* 131 */     if (!this.isStream) return super.getBytesInternal(paramInt); 
/* 132 */     if (this.stream.closed) {
/* 133 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 27);
/* 134 */       sQLException.fillInStackTrace();
/* 135 */       throw sQLException;
/*     */     } 
/*     */     
/* 138 */     ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream(1024);
/* 139 */     byte[] arrayOfByte = new byte[1024];
/*     */     try {
/*     */       int i;
/* 142 */       for (; (i = this.stream.read(arrayOfByte)) != -1; byteArrayOutputStream.write(arrayOfByte, 0, i));
/*     */     }
/* 144 */     catch (IOException iOException) {
/*     */       
/* 146 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException);
/* 147 */       sQLException.fillInStackTrace();
/* 148 */       throw sQLException;
/*     */     } 
/*     */     
/* 151 */     return byteArrayOutputStream.toByteArray();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected InputStream convertBytesToStream(int paramInt1, int paramInt2) throws SQLException {
/* 159 */     ByteArrayInputStream byteArrayInputStream = new ByteArrayInputStream(getBytesInternal(paramInt1));
/*     */     try {
/* 161 */       InputStream inputStream = this.statement.connection.conversion.ConvertStream(byteArrayInputStream, paramInt2);
/* 162 */       return inputStream;
/*     */     } finally {
/*     */       
/*     */       try {
/* 166 */         if (byteArrayInputStream != null) byteArrayInputStream.close();
/*     */       
/* 168 */       } catch (IOException iOException) {}
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   InputStream getAsciiStream(int paramInt) throws SQLException {
/* 184 */     PhysicalConnection physicalConnection = this.statement.connection;
/* 185 */     if (isNull(paramInt)) return null; 
/* 186 */     if (this.statement.isFetchStreams) return convertBytesToStream(paramInt, 2); 
/* 187 */     if (this.stream.closed) {
/* 188 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 27);
/* 189 */       sQLException.fillInStackTrace();
/* 190 */       throw sQLException;
/*     */     } 
/* 192 */     return physicalConnection.conversion.ConvertStream(this.stream, 2);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   InputStream getUnicodeStream(int paramInt) throws SQLException {
/* 208 */     PhysicalConnection physicalConnection = this.statement.connection;
/* 209 */     if (isNull(paramInt)) return null; 
/* 210 */     if (this.statement.isFetchStreams) return convertBytesToStream(paramInt, 3); 
/* 211 */     if (this.stream.closed) {
/* 212 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 27);
/* 213 */       sQLException.fillInStackTrace();
/* 214 */       throw sQLException;
/*     */     } 
/* 216 */     return physicalConnection.conversion.ConvertStream(this.stream, 3);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Reader getCharacterStream(int paramInt) throws SQLException {
/* 232 */     if (isNull(paramInt)) return null; 
/* 233 */     if (this.statement.isFetchStreams) {
/* 234 */       ByteArrayInputStream byteArrayInputStream = new ByteArrayInputStream(getBytesInternal(paramInt));
/*     */       try {
/* 236 */         PhysicalConnection physicalConnection1 = this.statement.connection;
/* 237 */         Reader reader = this.statement.connection.conversion.ConvertCharacterStream(byteArrayInputStream, 8, this.formOfUse);
/* 238 */         return reader;
/*     */       } finally {
/*     */         
/*     */         try {
/* 242 */           if (byteArrayInputStream != null) byteArrayInputStream.close();
/*     */         
/* 244 */         } catch (IOException iOException) {}
/*     */       } 
/*     */     } 
/* 247 */     if (this.stream.closed) {
/* 248 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 27);
/* 249 */       sQLException.fillInStackTrace();
/* 250 */       throw sQLException;
/*     */     } 
/*     */     
/* 253 */     PhysicalConnection physicalConnection = this.statement.connection;
/* 254 */     return physicalConnection.conversion.ConvertCharacterStream(this.stream, 8, this.formOfUse);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   InputStream getBinaryStream(int paramInt) throws SQLException {
/* 273 */     PhysicalConnection physicalConnection = this.statement.connection;
/* 274 */     if (isNull(paramInt)) return null; 
/* 275 */     if (this.statement.isFetchStreams) return convertBytesToStream(paramInt, 6); 
/* 276 */     if (this.stream.closed) {
/* 277 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 27);
/* 278 */       sQLException.fillInStackTrace();
/* 279 */       throw sQLException;
/*     */     } 
/* 281 */     return physicalConnection.conversion.ConvertStream(this.stream, 6);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 290 */     return "LongRawAccessor@" + Integer.toHexString(hashCode()) + "{columnPosition = " + this.columnPosition + "}";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 297 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*     */   public static final String BUILD_DATE = "Thu_Apr_04_15:09:24_PDT_2013";
/*     */   public static final boolean TRACE = false;
/*     */ }


/* Location:              C:\Users\olatu\OneDrive\Documents\Calypso\syncbase\sync_base.jar!\BOOT-INF\lib\ojdbc-7.jar!\oracle\jdbc\driver\LongRawAccessor.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */