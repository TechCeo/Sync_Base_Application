/*    */ package oracle.jdbc.driver;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class Namespace
/*    */ {
/*    */   static final int ATTRIBUTE_MAX_LENGTH = 30;
/*    */   static final int VALUE_MAX_LENGTH = 4000;
/*    */   String name;
/*    */   boolean clear;
/*    */   String[] keys;
/*    */   String[] values;
/*    */   int nbPairs;
/*    */   
/*    */   Namespace(String paramString) {
/* 46 */     if (paramString == null) {
/* 47 */       throw new NullPointerException();
/*    */     }
/* 49 */     this.name = paramString;
/* 50 */     this.clear = false;
/* 51 */     this.nbPairs = 0;
/* 52 */     this.keys = new String[5];
/* 53 */     this.values = new String[5];
/*    */   }
/*    */ 
/*    */   
/*    */   void clear() {
/* 58 */     this.clear = true;
/*    */     
/* 60 */     for (byte b = 0; b < this.nbPairs; b++) {
/*    */       
/* 62 */       this.keys[b] = null;
/* 63 */       this.values[b] = null;
/*    */     } 
/* 65 */     this.nbPairs = 0;
/*    */   }
/*    */ 
/*    */   
/*    */   void setAttribute(String paramString1, String paramString2) {
/* 70 */     if (paramString1 == null || paramString2 == null || paramString1.equals("")) {
/* 71 */       throw new NullPointerException();
/*    */     }
/* 73 */     if (this.nbPairs == this.keys.length) {
/*    */       
/* 75 */       String[] arrayOfString1 = new String[this.keys.length * 2];
/* 76 */       String[] arrayOfString2 = new String[this.keys.length * 2];
/* 77 */       System.arraycopy(this.keys, 0, arrayOfString1, 0, this.keys.length);
/* 78 */       System.arraycopy(this.values, 0, arrayOfString2, 0, this.values.length);
/* 79 */       this.keys = arrayOfString1;
/* 80 */       this.values = arrayOfString2;
/*    */     } 
/* 82 */     this.keys[this.nbPairs] = paramString1;
/* 83 */     this.values[this.nbPairs] = paramString2;
/* 84 */     this.nbPairs++;
/*    */   }
/*    */ }


/* Location:              C:\Users\olatu\OneDrive\Documents\Calypso\syncbase\sync_base.jar!\BOOT-INF\lib\ojdbc-7.jar!\oracle\jdbc\driver\Namespace.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */