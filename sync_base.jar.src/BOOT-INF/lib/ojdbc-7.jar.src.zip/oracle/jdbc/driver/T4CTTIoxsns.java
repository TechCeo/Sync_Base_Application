/*     */ package oracle.jdbc.driver;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.sql.SQLException;
/*     */ import oracle.jdbc.internal.OracleConnection;
/*     */ import oracle.jdbc.internal.XSNamespace;
/*     */ import oracle.jdbc.internal.XSSecureId;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class T4CTTIoxsns
/*     */   extends T4CTTIfun
/*     */ {
/*     */   private OracleConnection.XSOperationCode operationCode;
/*     */   private byte[] sessionId;
/*     */   private XSNamespace[] namespaces;
/*     */   private XSSecureId secureId;
/*     */   private XSNamespace[] outNamespaces;
/*     */   
/*     */   T4CTTIoxsns(T4CConnection paramT4CConnection) {
/*  83 */     super(paramT4CConnection, (byte)3);
/*  84 */     setFunCode((short)178);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void doOXSNS(OracleConnection.XSOperationCode paramXSOperationCode, byte[] paramArrayOfbyte, XSNamespace[] paramArrayOfXSNamespace, XSSecureId paramXSSecureId, boolean paramBoolean) throws IOException, SQLException {
/* 103 */     if (paramBoolean) {
/* 104 */       setTTCCode((byte)3);
/*     */     } else {
/* 106 */       setTTCCode((byte)17);
/* 107 */     }  this.operationCode = paramXSOperationCode;
/* 108 */     this.sessionId = paramArrayOfbyte;
/* 109 */     this.namespaces = paramArrayOfXSNamespace;
/* 110 */     this.secureId = paramXSSecureId;
/*     */     
/* 112 */     if (this.namespaces != null)
/* 113 */       for (byte b = 0; b < this.namespaces.length; b++) {
/* 114 */         ((XSNamespaceI)this.namespaces[b]).doCharConversion(this.meg.conv);
/*     */       } 
/* 116 */     if (paramBoolean) {
/* 117 */       doRPC();
/*     */     } else {
/* 119 */       doPigRPC();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void marshal() throws IOException {
/* 127 */     this.meg.marshalUB4(this.operationCode.getCode());
/* 128 */     boolean bool1 = false;
/* 129 */     if (this.sessionId != null && this.sessionId.length > 0) {
/* 130 */       bool1 = true;
/* 131 */       this.meg.marshalPTR();
/* 132 */       this.meg.marshalUB4(this.sessionId.length);
/*     */     } else {
/* 134 */       this.meg.marshalNULLPTR();
/* 135 */       this.meg.marshalUB4(0L);
/*     */     } 
/*     */     
/* 138 */     boolean bool2 = false;
/* 139 */     this.meg.marshalPTR();
/* 140 */     if (this.namespaces != null && this.namespaces.length > 0) {
/* 141 */       bool2 = true;
/* 142 */       this.meg.marshalUB4(this.namespaces.length);
/*     */     } else {
/* 144 */       this.meg.marshalUB4(0L);
/*     */     } 
/* 146 */     this.meg.marshalPTR();
/*     */     
/* 148 */     if (this.secureId == null) {
/* 149 */       this.meg.marshalNULLPTR();
/*     */     } else {
/* 151 */       this.meg.marshalPTR();
/*     */     } 
/* 153 */     if (bool1)
/* 154 */       this.meg.marshalB1Array(this.sessionId); 
/* 155 */     if (bool2)
/* 156 */       for (byte b = 0; b < this.namespaces.length; b++)
/* 157 */         ((XSNamespaceI)this.namespaces[b]).marshal(this.meg);  
/* 158 */     if (this.secureId != null) {
/* 159 */       ((XSSecureIdI)this.secureId).marshal(this.meg);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void readRPA() throws SQLException, IOException {
/* 167 */     this.outNamespaces = null;
/* 168 */     int i = (int)this.meg.unmarshalUB4();
/* 169 */     if (i > 0) {
/* 170 */       this.outNamespaces = new XSNamespace[i];
/* 171 */       for (byte b = 0; b < i; b++) {
/* 172 */         this.outNamespaces[b] = XSNamespaceI.unmarshal(this.meg);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   XSNamespace[] getNamespaces() throws SQLException {
/* 180 */     return this.outNamespaces;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/* 185 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*     */   public static final String BUILD_DATE = "Thu_Apr_04_15:09:24_PDT_2013";
/*     */   public static final boolean TRACE = false;
/*     */ }


/* Location:              C:\Users\olatu\OneDrive\Documents\Calypso\syncbase\sync_base.jar!\BOOT-INF\lib\ojdbc-7.jar!\oracle\jdbc\driver\T4CTTIoxsns.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */