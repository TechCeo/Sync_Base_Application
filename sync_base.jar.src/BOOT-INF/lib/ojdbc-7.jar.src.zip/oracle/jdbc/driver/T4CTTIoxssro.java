/*     */ package oracle.jdbc.driver;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.sql.SQLException;
/*     */ import oracle.jdbc.internal.KeywordValueLong;
/*     */ import oracle.jdbc.internal.OracleConnection;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class T4CTTIoxssro
/*     */   extends T4CTTIfun
/*     */ {
/*     */   private int functionId;
/*     */   private byte[] sessionId;
/*     */   private KeywordValueLong[] inKV;
/*     */   private int inFlags;
/*     */   private KeywordValueLong[] outKV;
/*     */   private int outFlags;
/*     */   
/*     */   T4CTTIoxssro(T4CConnection paramT4CConnection) {
/*  61 */     super(paramT4CConnection, (byte)3);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  67 */     this.sessionId = null;
/*  68 */     this.inKV = null;
/*     */ 
/*     */     
/*  71 */     this.outKV = null;
/*  72 */     this.outFlags = -1;
/*     */     setFunCode((short)156);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void doOXSSRO(int paramInt1, byte[] paramArrayOfbyte, KeywordValueLong[] paramArrayOfKeywordValueLong, int paramInt2) throws IOException, SQLException {
/*  81 */     this.functionId = paramInt1;
/*  82 */     this.sessionId = paramArrayOfbyte;
/*  83 */     this.inKV = paramArrayOfKeywordValueLong;
/*  84 */     this.inFlags = paramInt2;
/*  85 */     this.outKV = null;
/*  86 */     this.outFlags = -1;
/*     */     
/*  88 */     if (this.inKV != null)
/*  89 */       for (byte b = 0; b < this.inKV.length; b++)
/*  90 */         ((KeywordValueLongI)this.inKV[b]).doCharConversion(this.meg.conv);  
/*  91 */     doRPC();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   void marshal() throws IOException {
/*  97 */     this.meg.marshalUB4(this.functionId);
/*  98 */     boolean bool1 = false;
/*  99 */     if (this.sessionId != null && this.sessionId.length > 0) {
/*     */       
/* 101 */       bool1 = true;
/* 102 */       this.meg.marshalPTR();
/* 103 */       this.meg.marshalUB4(this.sessionId.length);
/*     */     }
/*     */     else {
/*     */       
/* 107 */       this.meg.marshalNULLPTR();
/* 108 */       this.meg.marshalUB4(0L);
/*     */     } 
/* 110 */     boolean bool2 = false;
/* 111 */     if (this.inKV != null && this.inKV.length > 0) {
/*     */       
/* 113 */       bool2 = true;
/* 114 */       this.meg.marshalPTR();
/* 115 */       this.meg.marshalUB4(this.inKV.length);
/*     */     }
/*     */     else {
/*     */       
/* 119 */       this.meg.marshalNULLPTR();
/* 120 */       this.meg.marshalUB4(0L);
/*     */     } 
/* 122 */     this.meg.marshalUB4(this.inFlags);
/* 123 */     this.meg.marshalPTR();
/* 124 */     this.meg.marshalPTR();
/* 125 */     this.meg.marshalPTR();
/*     */     
/* 127 */     if (bool1)
/* 128 */       this.meg.marshalB1Array(this.sessionId); 
/* 129 */     if (bool2) {
/* 130 */       for (byte b = 0; b < this.inKV.length; b++) {
/* 131 */         ((KeywordValueLongI)this.inKV[b]).marshal(this.meg);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   KeywordValueLong[] getOutKV() {
/* 139 */     return this.outKV;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   int getOutFlags() {
/* 145 */     return this.outFlags;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   void readRPA() throws SQLException, IOException {
/* 151 */     int i = (int)this.meg.unmarshalUB4();
/* 152 */     this.outKV = new KeywordValueLong[i];
/* 153 */     for (byte b = 0; b < i; b++)
/* 154 */       this.outKV[b] = KeywordValueLongI.unmarshal(this.meg); 
/* 155 */     this.outFlags = (int)this.meg.unmarshalUB4();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected OracleConnection getConnectionDuringExceptionHandling() {
/* 170 */     return this.connection;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/* 175 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*     */   public static final String BUILD_DATE = "Thu_Apr_04_15:09:24_PDT_2013";
/*     */   public static final boolean TRACE = false;
/*     */ }


/* Location:              C:\Users\olatu\OneDrive\Documents\Calypso\syncbase\sync_base.jar!\BOOT-INF\lib\ojdbc-7.jar!\oracle\jdbc\driver\T4CTTIoxssro.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */