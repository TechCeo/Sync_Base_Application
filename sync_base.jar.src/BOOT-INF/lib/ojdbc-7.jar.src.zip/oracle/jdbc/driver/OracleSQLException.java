/*     */ package oracle.jdbc.driver;
/*     */ 
/*     */ import java.sql.SQLException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class OracleSQLException
/*     */   extends SQLException
/*     */ {
/*     */   private Object[] m_parameters;
/*     */   
/*     */   public OracleSQLException() {
/*  31 */     this(null, null, 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public OracleSQLException(String paramString) {
/*  38 */     this(paramString, null, 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public OracleSQLException(String paramString1, String paramString2) {
/*  45 */     this(paramString1, paramString2, 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public OracleSQLException(String paramString1, String paramString2, int paramInt) {
/*  52 */     this(paramString1, paramString2, paramInt, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public OracleSQLException(String paramString1, String paramString2, int paramInt, Object[] paramArrayOfObject) {
/*  60 */     super(paramString1, paramString2, paramInt);
/*     */     
/*  62 */     this.m_parameters = paramArrayOfObject;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object[] getParameters() {
/*  80 */     if (this.m_parameters == null)
/*  81 */       this.m_parameters = new Object[0]; 
/*  82 */     return this.m_parameters;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getNumParameters() {
/*  97 */     if (this.m_parameters == null)
/*  98 */       this.m_parameters = new Object[0]; 
/*  99 */     return this.m_parameters.length;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setParameters(Object[] paramArrayOfObject) {
/* 114 */     this.m_parameters = paramArrayOfObject;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/* 119 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*     */   public static final String BUILD_DATE = "Thu_Apr_04_15:09:24_PDT_2013";
/*     */   public static final boolean TRACE = false;
/*     */ }


/* Location:              C:\Users\olatu\OneDrive\Documents\Calypso\syncbase\sync_base.jar!\BOOT-INF\lib\ojdbc-7.jar!\oracle\jdbc\driver\OracleSQLException.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */