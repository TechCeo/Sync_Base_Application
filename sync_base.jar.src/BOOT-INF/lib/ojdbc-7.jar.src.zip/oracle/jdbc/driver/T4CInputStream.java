/*    */ package oracle.jdbc.driver;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.sql.SQLException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class T4CInputStream
/*    */   extends OracleInputStream
/*    */ {
/*    */   T4CInputStream(OracleStatement paramOracleStatement, int paramInt, Accessor paramAccessor) {
/* 25 */     super(paramOracleStatement, paramInt, paramAccessor);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean isNull() throws IOException {
/* 33 */     if (!this.statement.isFetchStreams) {
/* 34 */       return super.isNull();
/*    */     }
/* 36 */     boolean bool = false;
/*    */ 
/*    */     
/*    */     try {
/* 40 */       int i = this.statement.currentResultSet.getRow();
/*    */       
/* 42 */       if (i < 0) {
/* 43 */         i = 0;
/*    */       }
/* 45 */       if (i >= this.statement.validRows) {
/* 46 */         return true;
/*    */       }
/* 48 */       bool = this.statement.isNull(i, this.columnIndex);
/*    */     }
/* 50 */     catch (SQLException sQLException) {
/*    */ 
/*    */       
/* 53 */       IOException iOException = DatabaseError.createIOException(sQLException);
/* 54 */       iOException.fillInStackTrace();
/* 55 */       throw iOException;
/*    */     } 
/*    */ 
/*    */     
/* 59 */     return bool;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public int getBytes(int paramInt) throws IOException {
/* 66 */     synchronized (this.statement.connection) {
/* 67 */       int i = -1;
/*    */ 
/*    */       
/*    */       try {
/* 71 */         if (this.statement.connection.lifecycle == 1 || this.statement.connection.lifecycle == 2)
/*    */         {
/* 73 */           i = this.accessor.readStream(this.resizableBuffer, this.initialBufferSize);
/*    */         }
/* 75 */       } catch (SQLException sQLException) {
/*    */         
/* 77 */         throw new IOException(sQLException.getMessage());
/*    */       
/*    */       }
/* 80 */       catch (IOException iOException) {
/*    */ 
/*    */         
/*    */         try {
/* 84 */           ((T4CConnection)this.statement.connection).handleIOException(iOException);
/*    */         }
/* 86 */         catch (SQLException sQLException) {}
/*    */         
/* 88 */         throw iOException;
/*    */       } 
/*    */       
/* 91 */       return i;
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/* 96 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*    */   public static final String BUILD_DATE = "Thu_Apr_04_15:09:24_PDT_2013";
/*    */   public static final boolean TRACE = false;
/*    */ }


/* Location:              C:\Users\olatu\OneDrive\Documents\Calypso\syncbase\sync_base.jar!\BOOT-INF\lib\ojdbc-7.jar!\oracle\jdbc\driver\T4CInputStream.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */