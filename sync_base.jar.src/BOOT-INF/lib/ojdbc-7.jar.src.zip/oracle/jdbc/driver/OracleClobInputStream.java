/*     */ package oracle.jdbc.driver;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.sql.SQLException;
/*     */ import oracle.jdbc.internal.OracleClob;
/*     */ import oracle.jdbc.internal.OracleConnection;
/*     */ import oracle.sql.CharacterSet;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class OracleClobInputStream
/*     */   extends OracleBufferedStream
/*     */ {
/*     */   protected long lobOffset;
/*     */   protected OracleClob clob;
/*     */   protected long markedByte;
/*     */   protected boolean endOfStream;
/*     */   protected char[] charBuf;
/*     */   protected boolean asciiStrictConversion;
/*     */   
/*     */   public OracleClobInputStream(OracleClob paramOracleClob, int paramInt) throws SQLException {
/*  38 */     this(paramOracleClob, paramInt, 1L);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public OracleClobInputStream(OracleClob paramOracleClob, int paramInt, long paramLong) throws SQLException {
/*  52 */     super(paramInt);
/*     */ 
/*     */     
/*  55 */     if (paramOracleClob == null || paramInt <= 0 || paramLong < 1L)
/*     */     {
/*  57 */       throw new IllegalArgumentException();
/*     */     }
/*     */     
/*  60 */     this.lobOffset = paramLong;
/*  61 */     this.clob = paramOracleClob;
/*  62 */     this.markedByte = -1L;
/*  63 */     this.endOfStream = false;
/*  64 */     this.asciiStrictConversion = ((PhysicalConnection)paramOracleClob.getInternalConnection()).isStrictAsciiConversion;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean needBytes(int paramInt) throws IOException {
/*  82 */     ensureOpen();
/*     */     
/*  84 */     if (this.pos >= this.count) {
/*     */       
/*  86 */       if (!this.endOfStream) {
/*     */         
/*     */         try {
/*     */           
/*  90 */           if (paramInt > this.currentBufferSize || paramInt == 0) {
/*     */             
/*  92 */             this.currentBufferSize = Math.max(paramInt, this.initialBufferSize);
/*  93 */             PhysicalConnection physicalConnection = (PhysicalConnection)this.clob.getInternalConnection();
/*     */             
/*  95 */             synchronized (physicalConnection) {
/*  96 */               this.resizableBuffer = physicalConnection.getByteBuffer(this.currentBufferSize);
/*  97 */               this.charBuf = physicalConnection.getCharBuffer(this.currentBufferSize);
/*     */             } 
/*     */           } 
/* 100 */           this.count = this.clob.getChars(this.lobOffset, this.currentBufferSize, this.charBuf);
/*     */ 
/*     */           
/* 103 */           CharacterSet.convertJavaCharsToASCIIBytes(this.charBuf, 0, this.resizableBuffer, 0, this.count, this.asciiStrictConversion);
/*     */           
/* 105 */           if (this.count < this.currentBufferSize) {
/* 106 */             this.endOfStream = true;
/*     */           }
/* 108 */           if (this.count > 0)
/*     */           {
/* 110 */             this.pos = 0;
/* 111 */             this.lobOffset += this.count;
/*     */             
/* 113 */             return true;
/*     */           }
/*     */         
/* 116 */         } catch (SQLException sQLException) {
/*     */ 
/*     */           
/* 119 */           IOException iOException = DatabaseError.createIOException(sQLException);
/* 120 */           iOException.fillInStackTrace();
/* 121 */           throw iOException;
/*     */         } 
/*     */       }
/*     */ 
/*     */       
/* 126 */       return false;
/*     */     } 
/*     */     
/* 129 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void ensureOpen() throws IOException {
/*     */     try {
/* 144 */       if (this.closed)
/*     */       {
/* 146 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 57, (Object)null);
/* 147 */         sQLException.fillInStackTrace();
/* 148 */         throw sQLException;
/*     */       }
/*     */     
/* 151 */     } catch (SQLException sQLException) {
/*     */ 
/*     */       
/* 154 */       IOException iOException = DatabaseError.createIOException(sQLException);
/* 155 */       iOException.fillInStackTrace();
/* 156 */       throw iOException;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean markSupported() {
/* 177 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void mark(int paramInt) {
/* 200 */     if (paramInt < 0) {
/* 201 */       throw new IllegalArgumentException(DatabaseError.findMessage(196, null));
/*     */     }
/* 203 */     this.markedByte = this.lobOffset - this.count + this.pos;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void markInternal(int paramInt) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void reset() throws IOException {
/* 224 */     ensureOpen();
/*     */     
/* 226 */     if (this.markedByte < 0L) {
/* 227 */       throw new IOException(DatabaseError.findMessage(195, null));
/*     */     }
/* 229 */     this.lobOffset = this.markedByte;
/* 230 */     this.pos = this.count;
/* 231 */     this.endOfStream = false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public long skip(long paramLong) throws IOException {
/* 255 */     ensureOpen();
/*     */     
/* 257 */     long l = 0L;
/*     */     
/* 259 */     if ((this.count - this.pos) >= paramLong) {
/*     */       
/* 261 */       this.pos = (int)(this.pos + paramLong);
/* 262 */       l += paramLong;
/*     */     }
/*     */     else {
/*     */       
/* 266 */       l += (this.count - this.pos);
/* 267 */       this.pos = this.count;
/*     */ 
/*     */       
/*     */       try {
/* 271 */         long l1 = 0L;
/*     */         
/* 273 */         l1 = this.clob.length() - this.lobOffset + 1L;
/*     */         
/* 275 */         if (l1 >= paramLong - l)
/*     */         {
/* 277 */           this.lobOffset += paramLong - l;
/* 278 */           l += paramLong - l;
/*     */         }
/*     */         else
/*     */         {
/* 282 */           this.lobOffset += l1;
/* 283 */           l += l1;
/*     */         }
/*     */       
/* 286 */       } catch (SQLException sQLException) {
/*     */ 
/*     */         
/* 289 */         IOException iOException = DatabaseError.createIOException(sQLException);
/* 290 */         iOException.fillInStackTrace();
/* 291 */         throw iOException;
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 296 */     return l;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void close() throws IOException {
/* 304 */     if (this.closed) {
/*     */       return;
/*     */     }
/*     */     try {
/* 308 */       super.close();
/*     */     } finally {
/*     */ 
/*     */       
/*     */       try {
/* 313 */         PhysicalConnection physicalConnection = (PhysicalConnection)this.clob.getInternalConnection();
/*     */         
/* 315 */         synchronized (physicalConnection) {
/*     */           
/* 317 */           if (this.charBuf != null) {
/*     */             
/* 319 */             physicalConnection.cacheBuffer(this.charBuf);
/* 320 */             this.charBuf = null;
/*     */           } 
/* 322 */           if (this.resizableBuffer != null) {
/*     */             
/* 324 */             physicalConnection.cacheBuffer(this.resizableBuffer);
/* 325 */             this.resizableBuffer = null;
/*     */           } 
/* 327 */           this.currentBufferSize = 0;
/*     */         } 
/* 329 */       } catch (SQLException sQLException) {
/*     */ 
/*     */         
/* 332 */         IOException iOException = DatabaseError.createIOException(sQLException);
/* 333 */         iOException.fillInStackTrace();
/* 334 */         throw iOException;
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected OracleConnection getConnectionDuringExceptionHandling() {
/*     */     try {
/* 357 */       return this.clob.getInternalConnection();
/*     */     }
/* 359 */     catch (Exception exception) {
/*     */       
/* 361 */       return null;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 368 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*     */   public static final String BUILD_DATE = "Thu_Apr_04_15:09:24_PDT_2013";
/*     */   public static final boolean TRACE = false;
/*     */ }


/* Location:              C:\Users\olatu\OneDrive\Documents\Calypso\syncbase\sync_base.jar!\BOOT-INF\lib\ojdbc-7.jar!\oracle\jdbc\driver\OracleClobInputStream.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */