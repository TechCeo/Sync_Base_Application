/*     */ package oracle.jdbc.connector;
/*     */ 
/*     */ import java.io.PrintWriter;
/*     */ import java.sql.Connection;
/*     */ import java.sql.SQLException;
/*     */ import java.util.Enumeration;
/*     */ import java.util.Hashtable;
/*     */ import javax.resource.ResourceException;
/*     */ import javax.resource.spi.ConnectionEvent;
/*     */ import javax.resource.spi.ConnectionEventListener;
/*     */ import javax.resource.spi.ConnectionRequestInfo;
/*     */ import javax.resource.spi.EISSystemException;
/*     */ import javax.resource.spi.IllegalStateException;
/*     */ import javax.resource.spi.LocalTransaction;
/*     */ import javax.resource.spi.ManagedConnection;
/*     */ import javax.resource.spi.ManagedConnectionMetaData;
/*     */ import javax.resource.spi.security.PasswordCredential;
/*     */ import javax.security.auth.Subject;
/*     */ import javax.sql.XAConnection;
/*     */ import javax.transaction.xa.XAResource;
/*     */ import oracle.jdbc.internal.OracleConnection;
/*     */ import oracle.jdbc.xa.OracleXAConnection;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class OracleManagedConnection
/*     */   implements ManagedConnection
/*     */ {
/*  39 */   private OracleXAConnection xaConnection = null;
/*  40 */   private Hashtable connectionListeners = null;
/*  41 */   private Connection connection = null;
/*  42 */   private PrintWriter logWriter = null;
/*  43 */   private PasswordCredential passwordCredential = null;
/*  44 */   private OracleLocalTransaction localTxn = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   OracleManagedConnection(XAConnection paramXAConnection) {
/*  51 */     this.xaConnection = (OracleXAConnection)paramXAConnection;
/*  52 */     this.connectionListeners = new Hashtable<>(10);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object getConnection(Subject paramSubject, ConnectionRequestInfo paramConnectionRequestInfo) throws ResourceException {
/*     */     try {
/*  90 */       if (this.connection != null) {
/*  91 */         this.connection.close();
/*     */       }
/*  93 */       this.connection = this.xaConnection.getConnection();
/*     */       
/*  95 */       return this.connection;
/*     */     }
/*  97 */     catch (SQLException sQLException) {
/*     */       
/*  99 */       EISSystemException eISSystemException = new EISSystemException("SQLException: " + sQLException.getMessage());
/*     */ 
/*     */       
/* 102 */       eISSystemException.setLinkedException(sQLException);
/*     */       
/* 104 */       throw eISSystemException;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void destroy() throws ResourceException {
/*     */     try {
/* 127 */       if (this.xaConnection != null) {
/*     */ 
/*     */ 
/*     */         
/* 131 */         Connection connection = this.xaConnection.getPhysicalHandle();
/*     */ 
/*     */ 
/*     */         
/* 135 */         if ((this.localTxn != null && this.localTxn.isBeginCalled) || ((OracleConnection)connection).getTxnMode() == 1)
/*     */         {
/*     */ 
/*     */           
/* 139 */           throw new IllegalStateException("Could not close connection while transaction is active");
/*     */         }
/*     */       } 
/*     */       
/* 143 */       if (this.connection != null) {
/* 144 */         this.connection.close();
/*     */       }
/* 146 */       if (this.xaConnection != null) {
/* 147 */         this.xaConnection.close();
/*     */       }
/*     */     }
/* 150 */     catch (SQLException sQLException) {
/*     */       
/* 152 */       EISSystemException eISSystemException = new EISSystemException("SQLException: " + sQLException.getMessage());
/*     */ 
/*     */       
/* 155 */       eISSystemException.setLinkedException(sQLException);
/*     */       
/* 157 */       throw eISSystemException;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void cleanup() throws ResourceException {
/*     */     try {
/* 187 */       if (this.connection != null)
/*     */       {
/*     */ 
/*     */ 
/*     */         
/* 192 */         if ((this.localTxn != null && this.localTxn.isBeginCalled) || ((OracleConnection)this.connection).getTxnMode() == 1)
/*     */         {
/*     */ 
/*     */           
/* 196 */           throw new IllegalStateException("Could not close connection while transaction is active");
/*     */         }
/*     */         
/* 199 */         this.connection.close();
/*     */       }
/*     */     
/*     */     }
/* 203 */     catch (SQLException sQLException) {
/*     */       
/* 205 */       EISSystemException eISSystemException = new EISSystemException("SQLException: " + sQLException.getMessage());
/*     */ 
/*     */       
/* 208 */       eISSystemException.setLinkedException(sQLException);
/*     */       
/* 210 */       throw eISSystemException;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void associateConnection(Object paramObject) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addConnectionEventListener(ConnectionEventListener paramConnectionEventListener) {
/* 257 */     this.connectionListeners.put(paramConnectionEventListener, paramConnectionEventListener);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void removeConnectionEventListener(ConnectionEventListener paramConnectionEventListener) {
/* 283 */     this.connectionListeners.remove(paramConnectionEventListener);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public XAResource getXAResource() throws ResourceException {
/* 309 */     return this.xaConnection.getXAResource();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LocalTransaction getLocalTransaction() throws ResourceException {
/* 331 */     if (this.localTxn == null)
/*     */     {
/* 333 */       this.localTxn = new OracleLocalTransaction(this);
/*     */     }
/*     */     
/* 336 */     return this.localTxn;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ManagedConnectionMetaData getMetaData() throws ResourceException {
/* 357 */     return new OracleManagedConnectionMetaData(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setLogWriter(PrintWriter paramPrintWriter) throws ResourceException {
/* 379 */     this.logWriter = paramPrintWriter;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PrintWriter getLogWriter() throws ResourceException {
/* 400 */     return this.logWriter;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Connection getPhysicalConnection() throws ResourceException {
/*     */     try {
/* 411 */       return this.xaConnection.getPhysicalHandle();
/*     */     
/*     */     }
/* 414 */     catch (Exception exception) {
/*     */       
/* 416 */       EISSystemException eISSystemException = new EISSystemException("Exception: " + exception.getMessage());
/*     */ 
/*     */       
/* 419 */       eISSystemException.setLinkedException(exception);
/*     */       
/* 421 */       throw eISSystemException;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void setPasswordCredential(PasswordCredential paramPasswordCredential) {
/* 432 */     this.passwordCredential = paramPasswordCredential;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   PasswordCredential getPasswordCredential() {
/* 441 */     return this.passwordCredential;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void eventOccurred(int paramInt) throws ResourceException {
/* 450 */     Enumeration<ConnectionEventListener> enumeration = this.connectionListeners.keys();
/*     */     
/* 452 */     while (enumeration.hasMoreElements()) {
/*     */ 
/*     */ 
/*     */       
/* 456 */       ConnectionEventListener connectionEventListener = enumeration.nextElement();
/*     */ 
/*     */ 
/*     */       
/* 460 */       ConnectionEvent connectionEvent = new ConnectionEvent(this, paramInt);
/*     */       
/* 462 */       switch (paramInt) {
/*     */ 
/*     */ 
/*     */         
/*     */         case 1:
/* 467 */           connectionEventListener.connectionClosed(connectionEvent);
/*     */           continue;
/*     */ 
/*     */ 
/*     */         
/*     */         case 2:
/* 473 */           connectionEventListener.localTransactionStarted(connectionEvent);
/*     */           continue;
/*     */ 
/*     */         
/*     */         case 3:
/* 478 */           connectionEventListener.localTransactionCommitted(connectionEvent);
/*     */           continue;
/*     */ 
/*     */         
/*     */         case 4:
/* 483 */           connectionEventListener.localTransactionRolledback(connectionEvent);
/*     */           continue;
/*     */ 
/*     */ 
/*     */         
/*     */         case 5:
/* 489 */           connectionEventListener.connectionErrorOccurred(connectionEvent);
/*     */           continue;
/*     */       } 
/*     */ 
/*     */       
/* 494 */       throw new IllegalArgumentException("Illegal eventType in eventOccurred(): " + paramInt);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 503 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*     */   public static final String BUILD_DATE = "Thu_Apr_04_15:09:24_PDT_2013";
/*     */   public static final boolean TRACE = false;
/*     */ }


/* Location:              C:\Users\olatu\OneDrive\Documents\Calypso\syncbase\sync_base.jar!\BOOT-INF\lib\ojdbc-7.jar!\oracle\jdbc\connector\OracleManagedConnection.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */