/*     */ package oracle.jdbc.connector;
/*     */ 
/*     */ import java.sql.SQLException;
/*     */ import javax.resource.ResourceException;
/*     */ import javax.resource.spi.EISSystemException;
/*     */ import javax.resource.spi.ManagedConnectionMetaData;
/*     */ import oracle.jdbc.OracleConnection;
/*     */ import oracle.jdbc.OracleDatabaseMetaData;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class OracleManagedConnectionMetaData
/*     */   implements ManagedConnectionMetaData
/*     */ {
/*  28 */   private OracleManagedConnection managedConnection = null;
/*  29 */   private OracleDatabaseMetaData databaseMetaData = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   OracleManagedConnectionMetaData(OracleManagedConnection paramOracleManagedConnection) throws ResourceException {
/*     */     try {
/*  40 */       this.managedConnection = paramOracleManagedConnection;
/*     */       
/*  42 */       OracleConnection oracleConnection = (OracleConnection)paramOracleManagedConnection.getPhysicalConnection();
/*     */       
/*  44 */       this.databaseMetaData = (OracleDatabaseMetaData)oracleConnection.getMetaData();
/*     */     }
/*  46 */     catch (Exception exception) {
/*     */       
/*  48 */       EISSystemException eISSystemException = new EISSystemException("Exception: " + exception.getMessage());
/*     */ 
/*     */       
/*  51 */       eISSystemException.setLinkedException(exception);
/*     */       
/*  53 */       throw eISSystemException;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getEISProductName() throws ResourceException {
/*     */     try {
/*  79 */       return this.databaseMetaData.getDatabaseProductName();
/*     */     }
/*  81 */     catch (SQLException sQLException) {
/*     */ 
/*     */ 
/*     */       
/*  85 */       EISSystemException eISSystemException = new EISSystemException("SQLException: " + sQLException.getMessage());
/*     */ 
/*     */       
/*  88 */       eISSystemException.setLinkedException(sQLException);
/*     */       
/*  90 */       throw eISSystemException;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getEISProductVersion() throws ResourceException {
/*     */     try {
/* 116 */       return this.databaseMetaData.getDatabaseProductVersion();
/*     */     
/*     */     }
/* 119 */     catch (Exception exception) {
/*     */       
/* 121 */       EISSystemException eISSystemException = new EISSystemException("Exception: " + exception.getMessage());
/*     */ 
/*     */       
/* 124 */       eISSystemException.setLinkedException(exception);
/*     */       
/* 126 */       throw eISSystemException;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getMaxConnections() throws ResourceException {
/*     */     try {
/* 154 */       return this.databaseMetaData.getMaxConnections();
/*     */     }
/* 156 */     catch (SQLException sQLException) {
/*     */ 
/*     */ 
/*     */       
/* 160 */       EISSystemException eISSystemException = new EISSystemException("SQLException: " + sQLException.getMessage());
/*     */ 
/*     */       
/* 163 */       eISSystemException.setLinkedException(sQLException);
/*     */       
/* 165 */       throw eISSystemException;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getUserName() throws ResourceException {
/*     */     try {
/* 193 */       return this.databaseMetaData.getUserName();
/*     */     }
/* 195 */     catch (SQLException sQLException) {
/*     */ 
/*     */ 
/*     */       
/* 199 */       EISSystemException eISSystemException = new EISSystemException("SQLException: " + sQLException.getMessage());
/*     */ 
/*     */       
/* 202 */       eISSystemException.setLinkedException(sQLException);
/*     */       
/* 204 */       throw eISSystemException;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 213 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*     */   public static final String BUILD_DATE = "Thu_Apr_04_15:09:24_PDT_2013";
/*     */   public static final boolean TRACE = false;
/*     */ }


/* Location:              C:\Users\olatu\OneDrive\Documents\Calypso\syncbase\sync_base.jar!\BOOT-INF\lib\ojdbc-7.jar!\oracle\jdbc\connector\OracleManagedConnectionMetaData.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */