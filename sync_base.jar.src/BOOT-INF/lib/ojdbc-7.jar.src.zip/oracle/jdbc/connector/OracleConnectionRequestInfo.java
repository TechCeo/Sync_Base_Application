/*     */ package oracle.jdbc.connector;
/*     */ 
/*     */ import javax.resource.spi.ConnectionRequestInfo;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class OracleConnectionRequestInfo
/*     */   implements ConnectionRequestInfo
/*     */ {
/*  21 */   private String user = null;
/*  22 */   private String password = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public OracleConnectionRequestInfo(String paramString1, String paramString2) {
/*  36 */     this.user = paramString1;
/*  37 */     this.password = paramString2;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getUser() {
/*  51 */     return this.user;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setUser(String paramString) {
/*  64 */     this.user = paramString;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getPassword() {
/*  78 */     return this.password;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setPassword(String paramString) {
/*  91 */     this.password = paramString;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object paramObject) {
/* 126 */     if (!(paramObject instanceof OracleConnectionRequestInfo)) {
/* 127 */       return false;
/*     */     }
/* 129 */     OracleConnectionRequestInfo oracleConnectionRequestInfo = (OracleConnectionRequestInfo)paramObject;
/*     */ 
/*     */     
/* 132 */     return (this.user.equalsIgnoreCase(oracleConnectionRequestInfo.getUser()) && this.password.equals(oracleConnectionRequestInfo.getPassword()));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/* 137 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*     */   public static final String BUILD_DATE = "Thu_Apr_04_15:09:24_PDT_2013";
/*     */   public static final boolean TRACE = false;
/*     */ }


/* Location:              C:\Users\olatu\OneDrive\Documents\Calypso\syncbase\sync_base.jar!\BOOT-INF\lib\ojdbc-7.jar!\oracle\jdbc\connector\OracleConnectionRequestInfo.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */