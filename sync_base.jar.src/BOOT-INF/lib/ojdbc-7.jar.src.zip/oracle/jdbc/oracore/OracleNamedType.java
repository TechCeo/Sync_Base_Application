/*     */ package oracle.jdbc.oracore;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.ObjectInputStream;
/*     */ import java.io.ObjectOutputStream;
/*     */ import java.io.PrintWriter;
/*     */ import java.io.Serializable;
/*     */ import java.sql.PreparedStatement;
/*     */ import java.sql.ResultSet;
/*     */ import java.sql.SQLException;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import oracle.jdbc.OracleConnection;
/*     */ import oracle.jdbc.driver.DatabaseError;
/*     */ import oracle.jdbc.internal.OracleConnection;
/*     */ import oracle.sql.Datum;
/*     */ import oracle.sql.SQLName;
/*     */ import oracle.sql.TypeDescriptor;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class OracleNamedType
/*     */   extends OracleType
/*     */   implements Serializable
/*     */ {
/*     */   transient OracleConnection connection;
/*  34 */   SQLName sqlName = null;
/*  35 */   transient OracleTypeADT parent = null;
/*     */   transient int idx;
/*  37 */   transient TypeDescriptor descriptor = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   String typeNameByUser;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getFullName() throws SQLException {
/*  70 */     return getFullName(false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getFullName(boolean paramBoolean) throws SQLException {
/*  78 */     String str = null;
/*     */     
/*  80 */     if (paramBoolean || this.sqlName == null)
/*     */     {
/*     */       
/*  83 */       if (this.parent != null && (str = this.parent.getAttributeType(this.idx)) != null) {
/*     */ 
/*     */         
/*  86 */         this.sqlName = new SQLName(str, (OracleConnection)this.connection);
/*     */       }
/*     */       else {
/*     */         
/*  90 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 1, "Unable to resolve name");
/*  91 */         sQLException.fillInStackTrace();
/*  92 */         throw sQLException;
/*     */       } 
/*     */     }
/*  95 */     return this.sqlName.getName();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getSchemaName() throws SQLException {
/* 102 */     if (this.sqlName == null) getFullName(); 
/* 103 */     return this.sqlName.getSchema();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getSimpleName() throws SQLException {
/* 110 */     if (this.sqlName == null) getFullName(); 
/* 111 */     return this.sqlName.getSimpleName();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean hasName() throws SQLException {
/* 118 */     return (this.sqlName != null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public OracleTypeADT getParent() throws SQLException {
/* 125 */     return this.parent;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setParent(OracleTypeADT paramOracleTypeADT) throws SQLException {
/* 132 */     this.parent = paramOracleTypeADT;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getOrder() throws SQLException {
/* 139 */     return this.idx;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setOrder(int paramInt) throws SQLException {
/* 146 */     this.idx = paramInt;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public OracleConnection getConnection() throws SQLException {
/* 160 */     return this.connection;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setConnection(OracleConnection paramOracleConnection) throws SQLException {
/* 175 */     setConnectionInternal(paramOracleConnection);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setConnectionInternal(OracleConnection paramOracleConnection) {
/* 182 */     this.connection = paramOracleConnection;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Datum unlinearize(byte[] paramArrayOfbyte, long paramLong, Datum paramDatum, int paramInt, Map paramMap) throws SQLException {
/* 201 */     SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException();
/* 202 */     sQLException.fillInStackTrace();
/* 203 */     throw sQLException;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Datum unlinearize(byte[] paramArrayOfbyte, long paramLong1, Datum paramDatum, long paramLong2, int paramInt1, int paramInt2, Map paramMap) throws SQLException {
/* 223 */     SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException();
/* 224 */     sQLException.fillInStackTrace();
/* 225 */     throw sQLException;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] linearize(Datum paramDatum) throws SQLException {
/* 238 */     SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException();
/* 239 */     sQLException.fillInStackTrace();
/* 240 */     throw sQLException;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TypeDescriptor getDescriptor() throws SQLException {
/* 248 */     return this.descriptor;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDescriptor(TypeDescriptor paramTypeDescriptor) throws SQLException {
/* 255 */     this.descriptor = paramTypeDescriptor;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getTypeVersion() {
/* 262 */     return 1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void writeObject(ObjectOutputStream paramObjectOutputStream) throws IOException {
/*     */     try {
/* 276 */       paramObjectOutputStream.writeUTF(getFullName());
/*     */     }
/* 278 */     catch (SQLException sQLException) {
/*     */ 
/*     */       
/* 281 */       IOException iOException = DatabaseError.createIOException(sQLException);
/* 282 */       iOException.fillInStackTrace();
/* 283 */       throw iOException;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void readObject(ObjectInputStream paramObjectInputStream) throws IOException, ClassNotFoundException {
/* 293 */     String str = paramObjectInputStream.readUTF(); 
/* 294 */     try { this.sqlName = new SQLName(str, null); } catch (SQLException sQLException) {}
/* 295 */     this.parent = null;
/* 296 */     this.idx = -1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void fixupConnection(OracleConnection paramOracleConnection) throws SQLException {
/* 304 */     if (this.connection == null) setConnection(paramOracleConnection);
/*     */   
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void printXML(PrintWriter paramPrintWriter, int paramInt) throws SQLException {
/* 316 */     printXML(paramPrintWriter, paramInt, false);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void printXML(PrintWriter paramPrintWriter, int paramInt, boolean paramBoolean) throws SQLException {
/* 322 */     for (byte b = 0; b < paramInt; ) { paramPrintWriter.print("  "); b++; }
/* 323 */      paramPrintWriter.println("<OracleNamedType/>");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void initNamesRecursively() throws SQLException {
/* 330 */     Map map = createTypesTreeMap();
/* 331 */     if (map.size() > 0) {
/* 332 */       initChildNamesRecursively(map);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setNames(String paramString1, String paramString2) throws SQLException {
/* 339 */     this.sqlName = new SQLName(paramString1, paramString2, (OracleConnection)this.connection);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSqlName(SQLName paramSQLName) {
/* 346 */     this.sqlName = paramSQLName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Map createTypesTreeMap() throws SQLException {
/* 360 */     Map map = null;
/* 361 */     String str = this.connection.getDefaultSchemaNameForNamedTypes();
/* 362 */     if (this.sqlName.getSchema().equals(str)) {
/* 363 */       map = getNodeMapFromUserTypes();
/*     */     }
/* 365 */     if (map == null)
/* 366 */       map = getNodeMapFromAllTypes(); 
/* 367 */     return map;
/*     */   }
/*     */ 
/*     */   
/* 371 */   static String getUserTypeTreeSql = "select level depth, parent_type, child_type, ATTR_NO, child_type_owner from  (select TYPE_NAME parent_type, ELEM_TYPE_NAME child_type, 0 ATTR_NO,       ELEM_TYPE_OWNER child_type_owner     from USER_COLL_TYPES  union   select TYPE_NAME parent_type, ATTR_TYPE_NAME child_type, ATTR_NO,       ATTR_TYPE_OWNER child_type_owner     from USER_TYPE_ATTRS  ) start with parent_type  = ?  connect by prior  child_type = parent_type";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   String sqlHint;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected OracleNamedType() {
/* 386 */     this.sqlHint = null; } public OracleNamedType(String paramString, OracleConnection paramOracleConnection) throws SQLException { this.sqlHint = null; setConnectionInternal(paramOracleConnection); this.typeNameByUser = paramString; this.sqlName = new SQLName(paramString, (OracleConnection)paramOracleConnection); } protected OracleNamedType(OracleTypeADT paramOracleTypeADT, int paramInt, OracleConnection paramOracleConnection) { this.sqlHint = null;
/*     */     setConnectionInternal(paramOracleConnection);
/*     */     this.parent = paramOracleTypeADT;
/*     */     this.idx = paramInt; } String getSqlHint() throws SQLException {
/* 390 */     if (this.sqlHint == null)
/*     */     {
/* 392 */       if (this.connection.getVersionNumber() >= 11000) {
/* 393 */         this.sqlHint = "";
/*     */       } else {
/* 395 */         this.sqlHint = "/*+RULE*/";
/*     */       }  } 
/* 397 */     return this.sqlHint;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Map getNodeMapFromUserTypes() throws SQLException {
/* 405 */     HashMap<Object, Object> hashMap = new HashMap<>();
/* 406 */     PreparedStatement preparedStatement = null;
/* 407 */     ResultSet resultSet = null;
/* 408 */     this.connection.beginNonRequestCalls();
/*     */     
/*     */     try {
/* 411 */       preparedStatement = this.connection.prepareStatement(getSqlHint() + getUserTypeTreeSql);
/* 412 */       preparedStatement.setString(1, this.sqlName.getSimpleName());
/* 413 */       resultSet = preparedStatement.executeQuery();
/*     */       
/* 415 */       while (resultSet.next()) {
/*     */         
/* 417 */         int i = resultSet.getInt(1);
/* 418 */         String str1 = resultSet.getString(2);
/* 419 */         String str2 = resultSet.getString(3);
/* 420 */         int j = resultSet.getInt(4);
/* 421 */         String str3 = resultSet.getString(5);
/* 422 */         if (str3 != null && !str3.equals(this.sqlName.getSchema())) {
/*     */           
/* 424 */           hashMap = null;
/*     */           break;
/*     */         } 
/* 427 */         if (str1.length() > 0) {
/*     */           
/* 429 */           SQLName sQLName = new SQLName(this.sqlName.getSchema(), str1, (OracleConnection)this.connection);
/* 430 */           TypeTreeElement typeTreeElement = null;
/* 431 */           if (hashMap.containsKey(sQLName)) {
/* 432 */             typeTreeElement = (TypeTreeElement)hashMap.get(sQLName);
/*     */           } else {
/*     */             
/* 435 */             typeTreeElement = new TypeTreeElement(this.sqlName.getSchema(), str1);
/* 436 */             hashMap.put(sQLName, typeTreeElement);
/*     */           } 
/* 438 */           typeTreeElement.putChild(this.sqlName.getSchema(), str2, j);
/*     */         } 
/*     */       } 
/*     */     } finally {
/*     */       
/* 443 */       if (resultSet != null) resultSet.close(); 
/* 444 */       if (preparedStatement != null) preparedStatement.close();
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 449 */       this.connection.endNonRequestCalls();
/*     */     } 
/* 451 */     return hashMap;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/* 456 */   static String getAllTypeTreeSql = "select parent_type, parent_type_owner, child_type, ATTR_NO, child_type_owner from ( select TYPE_NAME parent_type,  OWNER parent_type_owner,     ELEM_TYPE_NAME child_type, 0 ATTR_NO,     ELEM_TYPE_OWNER child_type_owner   from ALL_COLL_TYPES union   select TYPE_NAME parent_type, OWNER parent_type_owner,     ATTR_TYPE_NAME child_type, ATTR_NO,     ATTR_TYPE_OWNER child_type_owner   from ALL_TYPE_ATTRS ) start with parent_type  = ?  and parent_type_owner = ? connect by prior child_type = parent_type   and ( child_type_owner = parent_type_owner or child_type_owner is null )";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Map getNodeMapFromAllTypes() throws SQLException {
/* 474 */     HashMap<Object, Object> hashMap = new HashMap<>();
/* 475 */     PreparedStatement preparedStatement = null;
/* 476 */     ResultSet resultSet = null;
/* 477 */     this.connection.beginNonRequestCalls();
/*     */     
/*     */     try {
/* 480 */       preparedStatement = this.connection.prepareStatement(getSqlHint() + getAllTypeTreeSql);
/* 481 */       preparedStatement.setString(1, this.sqlName.getSimpleName());
/* 482 */       preparedStatement.setString(2, this.sqlName.getSchema());
/* 483 */       resultSet = preparedStatement.executeQuery();
/*     */       
/* 485 */       while (resultSet.next()) {
/*     */         
/* 487 */         String str1 = resultSet.getString(1);
/* 488 */         String str2 = resultSet.getString(2);
/* 489 */         String str3 = resultSet.getString(3);
/* 490 */         int i = resultSet.getInt(4);
/* 491 */         String str4 = resultSet.getString(5);
/* 492 */         if (str4 == null) str4 = "SYS"; 
/* 493 */         if (str1.length() > 0) {
/*     */           
/* 495 */           SQLName sQLName = new SQLName(str2, str1, (OracleConnection)this.connection);
/* 496 */           TypeTreeElement typeTreeElement = null;
/* 497 */           if (hashMap.containsKey(sQLName)) {
/* 498 */             typeTreeElement = (TypeTreeElement)hashMap.get(sQLName);
/*     */           } else {
/*     */             
/* 501 */             typeTreeElement = new TypeTreeElement(str2, str1);
/* 502 */             hashMap.put(sQLName, typeTreeElement);
/*     */           } 
/* 504 */           typeTreeElement.putChild(str4, str3, i);
/*     */         } 
/*     */       } 
/*     */     } finally {
/*     */       
/* 509 */       if (resultSet != null) resultSet.close(); 
/* 510 */       if (preparedStatement != null) preparedStatement.close();
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 515 */       this.connection.endNonRequestCalls();
/*     */     } 
/* 517 */     return hashMap;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected OracleConnection getConnectionDuringExceptionHandling() {
/* 532 */     return this.connection;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 581 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*     */   public static final String BUILD_DATE = "Thu_Apr_04_15:09:24_PDT_2013";
/*     */   public static final boolean TRACE = false;
/*     */ }


/* Location:              C:\Users\olatu\OneDrive\Documents\Calypso\syncbase\sync_base.jar!\BOOT-INF\lib\ojdbc-7.jar!\oracle\jdbc\oracore\OracleNamedType.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */