/*     */ package oracle.jdbc.aq;
/*     */ 
/*     */ import java.sql.SQLException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AQEnqueueOptions
/*     */ {
/*     */   private byte[] attrRelativeMessageId;
/*     */   private SequenceDeviationOption attrSequenceDeviation;
/*     */   private VisibilityOption attrVisibility;
/*     */   private DeliveryMode attrDeliveryMode;
/*     */   private boolean retrieveMsgId;
/*     */   private String transformation;
/*     */   
/*     */   public enum VisibilityOption
/*     */   {
/*  48 */     ON_COMMIT(2),
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  53 */     IMMEDIATE(1);
/*     */     private final int mode;
/*     */     
/*     */     VisibilityOption(int param1Int1) {
/*  57 */       this.mode = param1Int1;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final int getCode() {
/*  64 */       return this.mode;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public enum SequenceDeviationOption
/*     */   {
/*  73 */     BOTTOM(0),
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  78 */     BEFORE(2),
/*     */ 
/*     */ 
/*     */     
/*  82 */     TOP(3);
/*     */     private final int mode;
/*     */     
/*     */     SequenceDeviationOption(int param1Int1) {
/*  86 */       this.mode = param1Int1;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final int getCode() {
/*  93 */       return this.mode;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public enum DeliveryMode
/*     */   {
/* 103 */     PERSISTENT(AQDequeueOptions.DeliveryFilter.PERSISTENT.getCode()),
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 108 */     BUFFERED(AQDequeueOptions.DeliveryFilter.BUFFERED.getCode());
/*     */     private final int mode;
/*     */     
/*     */     DeliveryMode(int param1Int1) {
/* 112 */       this.mode = param1Int1;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final int getCode() {
/* 119 */       return this.mode;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AQEnqueueOptions() {
/* 147 */     this.attrRelativeMessageId = null;
/* 148 */     this.attrSequenceDeviation = SequenceDeviationOption.BOTTOM;
/* 149 */     this.attrVisibility = VisibilityOption.ON_COMMIT;
/* 150 */     this.attrDeliveryMode = DeliveryMode.PERSISTENT;
/*     */ 
/*     */ 
/*     */     
/* 154 */     this.retrieveMsgId = false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setRelativeMessageId(byte[] paramArrayOfbyte) throws SQLException {
/* 177 */     this.attrRelativeMessageId = paramArrayOfbyte;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] getRelativeMessageId() {
/* 194 */     return this.attrRelativeMessageId;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSequenceDeviation(SequenceDeviationOption paramSequenceDeviationOption) throws SQLException {
/* 219 */     this.attrSequenceDeviation = paramSequenceDeviationOption;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SequenceDeviationOption getSequenceDeviation() {
/* 236 */     return this.attrSequenceDeviation;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setVisibility(VisibilityOption paramVisibilityOption) throws SQLException {
/* 257 */     this.attrVisibility = paramVisibilityOption;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public VisibilityOption getVisibility() {
/* 274 */     return this.attrVisibility;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDeliveryMode(DeliveryMode paramDeliveryMode) throws SQLException {
/* 297 */     this.attrDeliveryMode = paramDeliveryMode;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DeliveryMode getDeliveryMode() {
/* 314 */     return this.attrDeliveryMode;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setRetrieveMessageId(boolean paramBoolean) {
/* 334 */     this.retrieveMsgId = paramBoolean;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean getRetrieveMessageId() {
/* 351 */     return this.retrieveMsgId;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setTransformation(String paramString) {
/* 377 */     this.transformation = paramString;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getTransformation() {
/* 394 */     return this.transformation;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/* 399 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*     */   public static final String BUILD_DATE = "Thu_Apr_04_15:09:24_PDT_2013";
/*     */   public static final boolean TRACE = false;
/*     */ }


/* Location:              C:\Users\olatu\OneDrive\Documents\Calypso\syncbase\sync_base.jar!\BOOT-INF\lib\ojdbc-7.jar!\oracle\jdbc\aq\AQEnqueueOptions.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */