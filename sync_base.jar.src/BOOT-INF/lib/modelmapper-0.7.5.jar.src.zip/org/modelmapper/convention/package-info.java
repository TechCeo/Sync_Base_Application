/**
 * Conventions
 */
package org.modelmapper.convention;