/**
 * ModelMapper internals. The contents of this package are not part of the public API and are subject to change.
 */
package org.modelmapper.internal;