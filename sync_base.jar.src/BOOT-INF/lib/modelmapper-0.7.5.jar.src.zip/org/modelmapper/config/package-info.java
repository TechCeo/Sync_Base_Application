/**
 * Configuration types
 */
package org.modelmapper.config;

