package antlr.collections;

import java.util.NoSuchElementException;

public interface Stack {
  int height();
  
  Object pop() throws NoSuchElementException;
  
  void push(Object paramObject);
  
  Object top() throws NoSuchElementException;
}


/* Location:              C:\Users\olatu\OneDrive\Documents\Calypso\syncbase\sync_base.jar!\BOOT-INF\lib\antlr-2.7.7.jar!\antlr\collections\Stack.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */