/*    */ package antlr.collections.impl;
/*    */ 
/*    */ import java.util.Enumeration;
/*    */ import java.util.Hashtable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class IndexedVector
/*    */ {
/*    */   protected Vector elements;
/*    */   protected Hashtable index;
/*    */   
/*    */   public IndexedVector() {
/* 29 */     this.elements = new Vector(10);
/* 30 */     this.index = new Hashtable(10);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public IndexedVector(int paramInt) {
/* 38 */     this.elements = new Vector(paramInt);
/* 39 */     this.index = new Hashtable(paramInt);
/*    */   }
/*    */   
/*    */   public synchronized void appendElement(Object paramObject1, Object paramObject2) {
/* 43 */     this.elements.appendElement(paramObject2);
/* 44 */     this.index.put(paramObject1, paramObject2);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Object elementAt(int paramInt) {
/* 54 */     return this.elements.elementAt(paramInt);
/*    */   }
/*    */   
/*    */   public Enumeration elements() {
/* 58 */     return this.elements.elements();
/*    */   }
/*    */   
/*    */   public Object getElement(Object paramObject) {
/* 62 */     return this.index.get(paramObject);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public synchronized boolean removeElement(Object paramObject) {
/* 68 */     Object object = this.index.get(paramObject);
/* 69 */     if (object == null) {
/* 70 */       return false;
/*    */     }
/* 72 */     this.index.remove(paramObject);
/* 73 */     this.elements.removeElement(object);
/* 74 */     return false;
/*    */   }
/*    */   
/*    */   public int size() {
/* 78 */     return this.elements.size();
/*    */   }
/*    */ }


/* Location:              C:\Users\olatu\OneDrive\Documents\Calypso\syncbase\sync_base.jar!\BOOT-INF\lib\antlr-2.7.7.jar!\antlr\collections\impl\IndexedVector.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */