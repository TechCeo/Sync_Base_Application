/*    */ package antlr.ASdebug;
/*    */ 
/*    */ import antlr.Token;
/*    */ import antlr.TokenStream;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class ASDebugStream
/*    */ {
/*    */   public static String getEntireText(TokenStream paramTokenStream) {
/* 15 */     if (paramTokenStream instanceof IASDebugStream) {
/*    */       
/* 17 */       IASDebugStream iASDebugStream = (IASDebugStream)paramTokenStream;
/* 18 */       return iASDebugStream.getEntireText();
/*    */     } 
/* 20 */     return null;
/*    */   }
/*    */ 
/*    */   
/*    */   public static TokenOffsetInfo getOffsetInfo(TokenStream paramTokenStream, Token paramToken) {
/* 25 */     if (paramTokenStream instanceof IASDebugStream) {
/*    */       
/* 27 */       IASDebugStream iASDebugStream = (IASDebugStream)paramTokenStream;
/* 28 */       return iASDebugStream.getOffsetInfo(paramToken);
/*    */     } 
/* 30 */     return null;
/*    */   }
/*    */ }


/* Location:              C:\Users\olatu\OneDrive\Documents\Calypso\syncbase\sync_base.jar!\BOOT-INF\lib\antlr-2.7.7.jar!\antlr\ASdebug\ASDebugStream.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */