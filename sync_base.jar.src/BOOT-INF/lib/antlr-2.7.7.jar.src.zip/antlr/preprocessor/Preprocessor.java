/*     */ package antlr.preprocessor;
/*     */ 
/*     */ import antlr.LLkParser;
/*     */ import antlr.NoViableAltException;
/*     */ import antlr.ParserSharedInputState;
/*     */ import antlr.RecognitionException;
/*     */ import antlr.SemanticException;
/*     */ import antlr.Token;
/*     */ import antlr.TokenBuffer;
/*     */ import antlr.TokenStream;
/*     */ import antlr.TokenStreamException;
/*     */ import antlr.Tool;
/*     */ import antlr.collections.impl.BitSet;
/*     */ import antlr.collections.impl.IndexedVector;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Preprocessor
/*     */   extends LLkParser
/*     */   implements PreprocessorTokenTypes
/*     */ {
/*     */   private Tool antlrTool;
/*     */   
/*     */   public void setTool(Tool paramTool) {
/*  37 */     if (this.antlrTool == null) {
/*  38 */       this.antlrTool = paramTool;
/*     */     } else {
/*     */       
/*  41 */       throw new IllegalStateException("antlr.Tool already registered");
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   protected Tool getTool() {
/*  47 */     return this.antlrTool;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void reportError(String paramString) {
/*  55 */     if (getTool() != null) {
/*  56 */       getTool().error(paramString, getFilename(), -1, -1);
/*     */     } else {
/*     */       
/*  59 */       super.reportError(paramString);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void reportError(RecognitionException paramRecognitionException) {
/*  68 */     if (getTool() != null) {
/*  69 */       getTool().error(paramRecognitionException.getErrorMessage(), paramRecognitionException.getFilename(), paramRecognitionException.getLine(), paramRecognitionException.getColumn());
/*     */     } else {
/*     */       
/*  72 */       super.reportError(paramRecognitionException);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void reportWarning(String paramString) {
/*  81 */     if (getTool() != null) {
/*  82 */       getTool().warning(paramString, getFilename(), -1, -1);
/*     */     } else {
/*     */       
/*  85 */       super.reportWarning(paramString);
/*     */     } 
/*     */   }
/*     */   
/*     */   protected Preprocessor(TokenBuffer paramTokenBuffer, int paramInt) {
/*  90 */     super(paramTokenBuffer, paramInt);
/*  91 */     this.tokenNames = _tokenNames;
/*     */   }
/*     */   
/*     */   public Preprocessor(TokenBuffer paramTokenBuffer) {
/*  95 */     this(paramTokenBuffer, 1);
/*     */   }
/*     */   
/*     */   protected Preprocessor(TokenStream paramTokenStream, int paramInt) {
/*  99 */     super(paramTokenStream, paramInt);
/* 100 */     this.tokenNames = _tokenNames;
/*     */   }
/*     */   
/*     */   public Preprocessor(TokenStream paramTokenStream) {
/* 104 */     this(paramTokenStream, 1);
/*     */   }
/*     */   
/*     */   public Preprocessor(ParserSharedInputState paramParserSharedInputState) {
/* 108 */     super(paramParserSharedInputState, 1);
/* 109 */     this.tokenNames = _tokenNames;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void grammarFile(Hierarchy paramHierarchy, String paramString) throws RecognitionException, TokenStreamException {
/* 116 */     Token token = null;
/*     */ 
/*     */     
/* 119 */     IndexedVector indexedVector = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/* 126 */       while (LA(1) == 5) {
/* 127 */         token = LT(1);
/* 128 */         match(5);
/* 129 */         paramHierarchy.getFile(paramString).addHeaderAction(token.getText());
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 138 */       switch (LA(1)) {
/*     */         
/*     */         case 13:
/* 141 */           indexedVector = optionSpec((Grammar)null);
/*     */           break;
/*     */ 
/*     */         
/*     */         case 1:
/*     */         case 7:
/*     */         case 8:
/*     */           break;
/*     */ 
/*     */         
/*     */         default:
/* 152 */           throw new NoViableAltException(LT(1), getFilename());
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 159 */       while (LA(1) == 7 || LA(1) == 8) {
/* 160 */         Grammar grammar = class_def(paramString, paramHierarchy);
/*     */         
/* 162 */         if (grammar != null && indexedVector != null) {
/* 163 */           paramHierarchy.getFile(paramString).setOptions(indexedVector);
/*     */         }
/* 165 */         if (grammar != null) {
/* 166 */           grammar.setFileName(paramString);
/* 167 */           paramHierarchy.addGrammar(grammar);
/*     */         } 
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 177 */       match(1);
/*     */     }
/* 179 */     catch (RecognitionException recognitionException) {
/* 180 */       reportError(recognitionException);
/* 181 */       consume();
/* 182 */       consumeUntil(_tokenSet_0);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final IndexedVector optionSpec(Grammar paramGrammar) throws RecognitionException, TokenStreamException {
/* 191 */     Token token1 = null;
/* 192 */     Token token2 = null;
/*     */     
/* 194 */     IndexedVector indexedVector = new IndexedVector();
/*     */ 
/*     */     
/*     */     try {
/* 198 */       match(13);
/*     */ 
/*     */ 
/*     */       
/* 202 */       while (LA(1) == 9) {
/* 203 */         token1 = LT(1);
/* 204 */         match(9);
/* 205 */         token2 = LT(1);
/* 206 */         match(14);
/*     */         
/* 208 */         Option option = new Option(token1.getText(), token2.getText(), paramGrammar);
/* 209 */         indexedVector.appendElement(option.getName(), option);
/* 210 */         if (paramGrammar != null && token1.getText().equals("importVocab")) {
/* 211 */           paramGrammar.specifiedVocabulary = true;
/* 212 */           paramGrammar.importVocab = token2.getText(); continue;
/*     */         } 
/* 214 */         if (paramGrammar != null && token1.getText().equals("exportVocab")) {
/*     */ 
/*     */           
/* 217 */           paramGrammar.exportVocab = token2.getText().substring(0, token2.getText().length() - 1);
/* 218 */           paramGrammar.exportVocab = paramGrammar.exportVocab.trim();
/*     */         } 
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 228 */       match(15);
/*     */     }
/* 230 */     catch (RecognitionException recognitionException) {
/* 231 */       reportError(recognitionException);
/* 232 */       consume();
/* 233 */       consumeUntil(_tokenSet_1);
/*     */     } 
/* 235 */     return indexedVector;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final Grammar class_def(String paramString, Hierarchy paramHierarchy) throws RecognitionException, TokenStreamException {
/* 243 */     Token token1 = null;
/* 244 */     Token token2 = null;
/* 245 */     Token token3 = null;
/* 246 */     Token token4 = null;
/* 247 */     Token token5 = null;
/*     */     
/* 249 */     Grammar grammar = null;
/* 250 */     IndexedVector indexedVector1 = new IndexedVector(100);
/* 251 */     IndexedVector indexedVector2 = null;
/* 252 */     String str = null;
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/* 257 */       switch (LA(1)) {
/*     */         
/*     */         case 7:
/* 260 */           token1 = LT(1);
/* 261 */           match(7);
/*     */           break;
/*     */ 
/*     */         
/*     */         case 8:
/*     */           break;
/*     */ 
/*     */         
/*     */         default:
/* 270 */           throw new NoViableAltException(LT(1), getFilename());
/*     */       } 
/*     */ 
/*     */       
/* 274 */       match(8);
/* 275 */       token2 = LT(1);
/* 276 */       match(9);
/* 277 */       match(10);
/* 278 */       token3 = LT(1);
/* 279 */       match(9);
/*     */       
/* 281 */       switch (LA(1)) {
/*     */         
/*     */         case 6:
/* 284 */           str = superClass();
/*     */           break;
/*     */ 
/*     */         
/*     */         case 11:
/*     */           break;
/*     */ 
/*     */         
/*     */         default:
/* 293 */           throw new NoViableAltException(LT(1), getFilename());
/*     */       } 
/*     */ 
/*     */       
/* 297 */       match(11);
/*     */       
/* 299 */       grammar = paramHierarchy.getGrammar(token2.getText());
/* 300 */       if (grammar != null) {
/*     */         
/* 302 */         grammar = null;
/* 303 */         throw new SemanticException("redefinition of grammar " + token2.getText(), paramString, token2.getLine(), token2.getColumn());
/*     */       } 
/*     */       
/* 306 */       grammar = new Grammar(paramHierarchy.getTool(), token2.getText(), token3.getText(), indexedVector1);
/* 307 */       grammar.superClass = str;
/* 308 */       if (token1 != null) {
/* 309 */         grammar.setPreambleAction(token1.getText());
/*     */       }
/*     */ 
/*     */ 
/*     */       
/* 314 */       switch (LA(1)) {
/*     */         
/*     */         case 13:
/* 317 */           indexedVector2 = optionSpec(grammar);
/*     */           break;
/*     */ 
/*     */         
/*     */         case 7:
/*     */         case 9:
/*     */         case 12:
/*     */         case 16:
/*     */         case 17:
/*     */         case 18:
/*     */           break;
/*     */ 
/*     */         
/*     */         default:
/* 331 */           throw new NoViableAltException(LT(1), getFilename());
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 336 */       if (grammar != null) {
/* 337 */         grammar.setOptions(indexedVector2);
/*     */       }
/*     */ 
/*     */       
/* 341 */       switch (LA(1)) {
/*     */         
/*     */         case 12:
/* 344 */           token4 = LT(1);
/* 345 */           match(12);
/* 346 */           grammar.setTokenSection(token4.getText());
/*     */           break;
/*     */ 
/*     */         
/*     */         case 7:
/*     */         case 9:
/*     */         case 16:
/*     */         case 17:
/*     */         case 18:
/*     */           break;
/*     */ 
/*     */         
/*     */         default:
/* 359 */           throw new NoViableAltException(LT(1), getFilename());
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 364 */       switch (LA(1)) {
/*     */         
/*     */         case 7:
/* 367 */           token5 = LT(1);
/* 368 */           match(7);
/* 369 */           grammar.setMemberAction(token5.getText());
/*     */           break;
/*     */ 
/*     */         
/*     */         case 9:
/*     */         case 16:
/*     */         case 17:
/*     */         case 18:
/*     */           break;
/*     */ 
/*     */         
/*     */         default:
/* 381 */           throw new NoViableAltException(LT(1), getFilename());
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 386 */       byte b = 0;
/*     */       
/*     */       while (true) {
/* 389 */         if (_tokenSet_2.member(LA(1))) {
/* 390 */           rule(grammar);
/*     */         } else {
/*     */           
/* 393 */           if (b >= 1) break;  throw new NoViableAltException(LT(1), getFilename());
/*     */         } 
/*     */         
/* 396 */         b++;
/*     */       }
/*     */     
/*     */     }
/* 400 */     catch (RecognitionException recognitionException) {
/* 401 */       reportError(recognitionException);
/* 402 */       consume();
/* 403 */       consumeUntil(_tokenSet_3);
/*     */     } 
/* 405 */     return grammar;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public final String superClass() throws RecognitionException, TokenStreamException {
/* 411 */     String str = LT(1).getText();
/*     */     
/*     */     try {
/* 414 */       match(6);
/*     */     }
/* 416 */     catch (RecognitionException recognitionException) {
/* 417 */       reportError(recognitionException);
/* 418 */       consume();
/* 419 */       consumeUntil(_tokenSet_4);
/*     */     } 
/* 421 */     return str;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void rule(Grammar paramGrammar) throws RecognitionException, TokenStreamException {
/* 428 */     Token token1 = null;
/* 429 */     Token token2 = null;
/* 430 */     Token token3 = null;
/* 431 */     Token token4 = null;
/* 432 */     Token token5 = null;
/*     */     
/* 434 */     IndexedVector indexedVector = null;
/* 435 */     String str1 = null;
/* 436 */     boolean bool = false;
/* 437 */     String str2 = null, str3 = "";
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/* 442 */       switch (LA(1)) {
/*     */         
/*     */         case 16:
/* 445 */           match(16);
/* 446 */           str1 = "protected";
/*     */           break;
/*     */ 
/*     */         
/*     */         case 17:
/* 451 */           match(17);
/* 452 */           str1 = "private";
/*     */           break;
/*     */ 
/*     */         
/*     */         case 18:
/* 457 */           match(18);
/* 458 */           str1 = "public";
/*     */           break;
/*     */ 
/*     */         
/*     */         case 9:
/*     */           break;
/*     */ 
/*     */         
/*     */         default:
/* 467 */           throw new NoViableAltException(LT(1), getFilename());
/*     */       } 
/*     */ 
/*     */       
/* 471 */       token1 = LT(1);
/* 472 */       match(9);
/*     */       
/* 474 */       switch (LA(1)) {
/*     */         
/*     */         case 19:
/* 477 */           match(19);
/* 478 */           bool = true;
/*     */           break;
/*     */ 
/*     */         
/*     */         case 7:
/*     */         case 13:
/*     */         case 20:
/*     */         case 21:
/*     */         case 22:
/*     */         case 23:
/*     */           break;
/*     */ 
/*     */         
/*     */         default:
/* 492 */           throw new NoViableAltException(LT(1), getFilename());
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 497 */       switch (LA(1)) {
/*     */         
/*     */         case 20:
/* 500 */           token2 = LT(1);
/* 501 */           match(20);
/*     */           break;
/*     */ 
/*     */         
/*     */         case 7:
/*     */         case 13:
/*     */         case 21:
/*     */         case 22:
/*     */         case 23:
/*     */           break;
/*     */ 
/*     */         
/*     */         default:
/* 514 */           throw new NoViableAltException(LT(1), getFilename());
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 519 */       switch (LA(1)) {
/*     */         
/*     */         case 21:
/* 522 */           match(21);
/* 523 */           token3 = LT(1);
/* 524 */           match(20);
/*     */           break;
/*     */ 
/*     */         
/*     */         case 7:
/*     */         case 13:
/*     */         case 22:
/*     */         case 23:
/*     */           break;
/*     */ 
/*     */         
/*     */         default:
/* 536 */           throw new NoViableAltException(LT(1), getFilename());
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 541 */       switch (LA(1)) {
/*     */         
/*     */         case 23:
/* 544 */           str3 = throwsSpec();
/*     */           break;
/*     */ 
/*     */         
/*     */         case 7:
/*     */         case 13:
/*     */         case 22:
/*     */           break;
/*     */ 
/*     */         
/*     */         default:
/* 555 */           throw new NoViableAltException(LT(1), getFilename());
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 560 */       switch (LA(1)) {
/*     */         
/*     */         case 13:
/* 563 */           indexedVector = optionSpec((Grammar)null);
/*     */           break;
/*     */ 
/*     */         
/*     */         case 7:
/*     */         case 22:
/*     */           break;
/*     */ 
/*     */         
/*     */         default:
/* 573 */           throw new NoViableAltException(LT(1), getFilename());
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 578 */       switch (LA(1)) {
/*     */         
/*     */         case 7:
/* 581 */           token4 = LT(1);
/* 582 */           match(7);
/*     */           break;
/*     */ 
/*     */         
/*     */         case 22:
/*     */           break;
/*     */ 
/*     */         
/*     */         default:
/* 591 */           throw new NoViableAltException(LT(1), getFilename());
/*     */       } 
/*     */ 
/*     */       
/* 595 */       token5 = LT(1);
/* 596 */       match(22);
/* 597 */       str2 = exceptionGroup();
/*     */       
/* 599 */       String str = token5.getText() + str2;
/* 600 */       Rule rule = new Rule(token1.getText(), str, indexedVector, paramGrammar);
/* 601 */       rule.setThrowsSpec(str3);
/* 602 */       if (token2 != null) {
/* 603 */         rule.setArgs(token2.getText());
/*     */       }
/* 605 */       if (token3 != null) {
/* 606 */         rule.setReturnValue(token3.getText());
/*     */       }
/* 608 */       if (token4 != null) {
/* 609 */         rule.setInitAction(token4.getText());
/*     */       }
/* 611 */       if (bool) {
/* 612 */         rule.setBang();
/*     */       }
/* 614 */       rule.setVisibility(str1);
/* 615 */       if (paramGrammar != null) {
/* 616 */         paramGrammar.addRule(rule);
/*     */       
/*     */       }
/*     */     }
/* 620 */     catch (RecognitionException recognitionException) {
/* 621 */       reportError(recognitionException);
/* 622 */       consume();
/* 623 */       consumeUntil(_tokenSet_5);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public final String throwsSpec() throws RecognitionException, TokenStreamException {
/* 630 */     Token token1 = null;
/* 631 */     Token token2 = null;
/* 632 */     String str = "throws ";
/*     */     
/*     */     try {
/* 635 */       match(23);
/* 636 */       token1 = LT(1);
/* 637 */       match(9);
/* 638 */       str = str + token1.getText();
/*     */ 
/*     */ 
/*     */       
/* 642 */       while (LA(1) == 24) {
/* 643 */         match(24);
/* 644 */         token2 = LT(1);
/* 645 */         match(9);
/* 646 */         str = str + "," + token2.getText();
/*     */ 
/*     */ 
/*     */       
/*     */       }
/*     */ 
/*     */ 
/*     */     
/*     */     }
/* 655 */     catch (RecognitionException recognitionException) {
/* 656 */       reportError(recognitionException);
/* 657 */       consume();
/* 658 */       consumeUntil(_tokenSet_6);
/*     */     } 
/* 660 */     return str;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public final String exceptionGroup() throws RecognitionException, TokenStreamException {
/* 666 */     String str2 = null, str1 = "";
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/* 672 */       while (LA(1) == 25) {
/* 673 */         str2 = exceptionSpec();
/* 674 */         str1 = str1 + str2;
/*     */ 
/*     */ 
/*     */       
/*     */       }
/*     */ 
/*     */ 
/*     */     
/*     */     }
/* 683 */     catch (RecognitionException recognitionException) {
/* 684 */       reportError(recognitionException);
/* 685 */       consume();
/* 686 */       consumeUntil(_tokenSet_5);
/*     */     } 
/* 688 */     return str1;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public final String exceptionSpec() throws RecognitionException, TokenStreamException {
/* 694 */     Token token = null;
/* 695 */     String str2 = null;
/* 696 */     String str1 = System.getProperty("line.separator") + "exception ";
/*     */ 
/*     */     
/*     */     try {
/* 700 */       match(25);
/*     */       
/* 702 */       switch (LA(1)) {
/*     */         
/*     */         case 20:
/* 705 */           token = LT(1);
/* 706 */           match(20);
/* 707 */           str1 = str1 + token.getText();
/*     */           break;
/*     */ 
/*     */         
/*     */         case 1:
/*     */         case 7:
/*     */         case 8:
/*     */         case 9:
/*     */         case 16:
/*     */         case 17:
/*     */         case 18:
/*     */         case 25:
/*     */         case 26:
/*     */           break;
/*     */ 
/*     */         
/*     */         default:
/* 724 */           throw new NoViableAltException(LT(1), getFilename());
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 731 */       while (LA(1) == 26) {
/* 732 */         str2 = exceptionHandler();
/* 733 */         str1 = str1 + str2;
/*     */ 
/*     */ 
/*     */       
/*     */       }
/*     */ 
/*     */ 
/*     */     
/*     */     }
/* 742 */     catch (RecognitionException recognitionException) {
/* 743 */       reportError(recognitionException);
/* 744 */       consume();
/* 745 */       consumeUntil(_tokenSet_7);
/*     */     } 
/* 747 */     return str1;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public final String exceptionHandler() throws RecognitionException, TokenStreamException {
/* 753 */     Token token1 = null;
/* 754 */     Token token2 = null;
/* 755 */     String str = null;
/*     */     
/*     */     try {
/* 758 */       match(26);
/* 759 */       token1 = LT(1);
/* 760 */       match(20);
/* 761 */       token2 = LT(1);
/* 762 */       match(7);
/* 763 */       str = System.getProperty("line.separator") + "catch " + token1.getText() + " " + token2.getText();
/*     */     
/*     */     }
/* 766 */     catch (RecognitionException recognitionException) {
/* 767 */       reportError(recognitionException);
/* 768 */       consume();
/* 769 */       consumeUntil(_tokenSet_8);
/*     */     } 
/* 771 */     return str;
/*     */   }
/*     */ 
/*     */   
/* 775 */   public static final String[] _tokenNames = new String[] { "<0>", "EOF", "<2>", "NULL_TREE_LOOKAHEAD", "\"tokens\"", "HEADER_ACTION", "SUBRULE_BLOCK", "ACTION", "\"class\"", "ID", "\"extends\"", "SEMI", "TOKENS_SPEC", "OPTIONS_START", "ASSIGN_RHS", "RCURLY", "\"protected\"", "\"private\"", "\"public\"", "BANG", "ARG_ACTION", "\"returns\"", "RULE_BLOCK", "\"throws\"", "COMMA", "\"exception\"", "\"catch\"", "ALT", "ELEMENT", "LPAREN", "RPAREN", "ID_OR_KEYWORD", "CURLY_BLOCK_SCARF", "WS", "NEWLINE", "COMMENT", "SL_COMMENT", "ML_COMMENT", "CHAR_LITERAL", "STRING_LITERAL", "ESC", "DIGIT", "XDIGIT" };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final long[] mk_tokenSet_0() {
/* 822 */     return new long[] { 2L, 0L };
/*     */   }
/*     */   
/* 825 */   public static final BitSet _tokenSet_0 = new BitSet(mk_tokenSet_0());
/*     */   private static final long[] mk_tokenSet_1() {
/* 827 */     return new long[] { 4658050L, 0L };
/*     */   }
/*     */   
/* 830 */   public static final BitSet _tokenSet_1 = new BitSet(mk_tokenSet_1());
/*     */   private static final long[] mk_tokenSet_2() {
/* 832 */     return new long[] { 459264L, 0L };
/*     */   }
/*     */   
/* 835 */   public static final BitSet _tokenSet_2 = new BitSet(mk_tokenSet_2());
/*     */   private static final long[] mk_tokenSet_3() {
/* 837 */     return new long[] { 386L, 0L };
/*     */   }
/*     */   
/* 840 */   public static final BitSet _tokenSet_3 = new BitSet(mk_tokenSet_3());
/*     */   private static final long[] mk_tokenSet_4() {
/* 842 */     return new long[] { 2048L, 0L };
/*     */   }
/*     */   
/* 845 */   public static final BitSet _tokenSet_4 = new BitSet(mk_tokenSet_4());
/*     */   private static final long[] mk_tokenSet_5() {
/* 847 */     return new long[] { 459650L, 0L };
/*     */   }
/*     */   
/* 850 */   public static final BitSet _tokenSet_5 = new BitSet(mk_tokenSet_5());
/*     */   private static final long[] mk_tokenSet_6() {
/* 852 */     return new long[] { 4202624L, 0L };
/*     */   }
/*     */   
/* 855 */   public static final BitSet _tokenSet_6 = new BitSet(mk_tokenSet_6());
/*     */   private static final long[] mk_tokenSet_7() {
/* 857 */     return new long[] { 34014082L, 0L };
/*     */   }
/*     */   
/* 860 */   public static final BitSet _tokenSet_7 = new BitSet(mk_tokenSet_7());
/*     */   private static final long[] mk_tokenSet_8() {
/* 862 */     return new long[] { 101122946L, 0L };
/*     */   }
/*     */   
/* 865 */   public static final BitSet _tokenSet_8 = new BitSet(mk_tokenSet_8());
/*     */ }


/* Location:              C:\Users\olatu\OneDrive\Documents\Calypso\syncbase\sync_base.jar!\BOOT-INF\lib\antlr-2.7.7.jar!\antlr\preprocessor\Preprocessor.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */