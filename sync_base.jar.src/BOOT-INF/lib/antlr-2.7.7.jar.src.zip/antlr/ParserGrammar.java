/*     */ package antlr;
/*     */ 
/*     */ import java.io.IOException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class ParserGrammar
/*     */   extends Grammar
/*     */ {
/*     */   ParserGrammar(String paramString1, Tool paramTool, String paramString2) {
/*  23 */     super(paramString1, paramTool, paramString2);
/*     */   }
/*     */ 
/*     */   
/*     */   public void generate() throws IOException {
/*  28 */     this.generator.gen(this);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected String getSuperClass() {
/*  34 */     if (this.debuggingOutput)
/*  35 */       return "debug.LLkDebuggingParser"; 
/*  36 */     return "LLkParser";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void processArguments(String[] paramArrayOfString) {
/*  45 */     for (byte b = 0; b < paramArrayOfString.length; b++) {
/*  46 */       if (paramArrayOfString[b].equals("-trace")) {
/*  47 */         this.traceRules = true;
/*  48 */         this.antlrTool.setArgOK(b);
/*     */       }
/*  50 */       else if (paramArrayOfString[b].equals("-traceParser")) {
/*  51 */         this.traceRules = true;
/*  52 */         this.antlrTool.setArgOK(b);
/*     */       }
/*  54 */       else if (paramArrayOfString[b].equals("-debug")) {
/*  55 */         this.debuggingOutput = true;
/*  56 */         this.antlrTool.setArgOK(b);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean setOption(String paramString, Token paramToken) {
/*  64 */     String str = paramToken.getText();
/*  65 */     if (paramString.equals("buildAST")) {
/*  66 */       if (str.equals("true")) {
/*  67 */         this.buildAST = true;
/*     */       }
/*  69 */       else if (str.equals("false")) {
/*  70 */         this.buildAST = false;
/*     */       } else {
/*     */         
/*  73 */         this.antlrTool.error("buildAST option must be true or false", getFilename(), paramToken.getLine(), paramToken.getColumn());
/*     */       } 
/*  75 */       return true;
/*     */     } 
/*  77 */     if (paramString.equals("interactive")) {
/*  78 */       if (str.equals("true")) {
/*  79 */         this.interactive = true;
/*     */       }
/*  81 */       else if (str.equals("false")) {
/*  82 */         this.interactive = false;
/*     */       } else {
/*     */         
/*  85 */         this.antlrTool.error("interactive option must be true or false", getFilename(), paramToken.getLine(), paramToken.getColumn());
/*     */       } 
/*  87 */       return true;
/*     */     } 
/*  89 */     if (paramString.equals("ASTLabelType")) {
/*  90 */       super.setOption(paramString, paramToken);
/*  91 */       return true;
/*     */     } 
/*  93 */     if (paramString.equals("className")) {
/*  94 */       super.setOption(paramString, paramToken);
/*  95 */       return true;
/*     */     } 
/*  97 */     if (super.setOption(paramString, paramToken)) {
/*  98 */       return true;
/*     */     }
/* 100 */     this.antlrTool.error("Invalid option: " + paramString, getFilename(), paramToken.getLine(), paramToken.getColumn());
/* 101 */     return false;
/*     */   }
/*     */ }


/* Location:              C:\Users\olatu\OneDrive\Documents\Calypso\syncbase\sync_base.jar!\BOOT-INF\lib\antlr-2.7.7.jar!\antlr\ParserGrammar.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */