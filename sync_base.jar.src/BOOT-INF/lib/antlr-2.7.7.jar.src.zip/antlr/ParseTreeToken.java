/*    */ package antlr;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ParseTreeToken
/*    */   extends ParseTree
/*    */ {
/*    */   protected Token token;
/*    */   
/*    */   public ParseTreeToken(Token paramToken) {
/* 15 */     this.token = paramToken;
/*    */   }
/*    */   
/*    */   protected int getLeftmostDerivation(StringBuffer paramStringBuffer, int paramInt) {
/* 19 */     paramStringBuffer.append(' ');
/* 20 */     paramStringBuffer.append(toString());
/* 21 */     return paramInt;
/*    */   }
/*    */   
/*    */   public String toString() {
/* 25 */     if (this.token != null) {
/* 26 */       return this.token.getText();
/*    */     }
/* 28 */     return "<missing token>";
/*    */   }
/*    */ }


/* Location:              C:\Users\olatu\OneDrive\Documents\Calypso\syncbase\sync_base.jar!\BOOT-INF\lib\antlr-2.7.7.jar!\antlr\ParseTreeToken.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */