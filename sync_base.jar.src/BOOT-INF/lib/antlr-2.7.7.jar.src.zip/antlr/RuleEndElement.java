/*    */ package antlr;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class RuleEndElement
/*    */   extends BlockEndElement
/*    */ {
/*    */   protected Lookahead[] cache;
/*    */   protected boolean noFOLLOW;
/*    */   
/*    */   public RuleEndElement(Grammar paramGrammar) {
/* 21 */     super(paramGrammar);
/* 22 */     this.cache = new Lookahead[paramGrammar.maxk + 1];
/*    */   }
/*    */   
/*    */   public Lookahead look(int paramInt) {
/* 26 */     return this.grammar.theLLkAnalyzer.look(paramInt, this);
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 31 */     return "";
/*    */   }
/*    */ }


/* Location:              C:\Users\olatu\OneDrive\Documents\Calypso\syncbase\sync_base.jar!\BOOT-INF\lib\antlr-2.7.7.jar!\antlr\RuleEndElement.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */