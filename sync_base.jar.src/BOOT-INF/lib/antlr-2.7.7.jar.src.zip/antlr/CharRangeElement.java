/*    */ package antlr;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class CharRangeElement
/*    */   extends AlternativeElement
/*    */ {
/*    */   String label;
/* 12 */   protected char begin = Character.MIN_VALUE;
/* 13 */   protected char end = Character.MIN_VALUE;
/*    */   
/*    */   protected String beginText;
/*    */   protected String endText;
/*    */   
/*    */   public CharRangeElement(LexerGrammar paramLexerGrammar, Token paramToken1, Token paramToken2, int paramInt) {
/* 19 */     super(paramLexerGrammar);
/* 20 */     this.begin = (char)ANTLRLexer.tokenTypeForCharLiteral(paramToken1.getText());
/* 21 */     this.beginText = paramToken1.getText();
/* 22 */     this.end = (char)ANTLRLexer.tokenTypeForCharLiteral(paramToken2.getText());
/* 23 */     this.endText = paramToken2.getText();
/* 24 */     this.line = paramToken1.getLine();
/*    */     
/* 26 */     for (char c = this.begin; c <= this.end; c++) {
/* 27 */       paramLexerGrammar.charVocabulary.add(c);
/*    */     }
/* 29 */     this.autoGenType = paramInt;
/*    */   }
/*    */   
/*    */   public void generate() {
/* 33 */     this.grammar.generator.gen(this);
/*    */   }
/*    */   
/*    */   public String getLabel() {
/* 37 */     return this.label;
/*    */   }
/*    */   
/*    */   public Lookahead look(int paramInt) {
/* 41 */     return this.grammar.theLLkAnalyzer.look(paramInt, this);
/*    */   }
/*    */   
/*    */   public void setLabel(String paramString) {
/* 45 */     this.label = paramString;
/*    */   }
/*    */   
/*    */   public String toString() {
/* 49 */     if (this.label != null) {
/* 50 */       return " " + this.label + ":" + this.beginText + ".." + this.endText;
/*    */     }
/* 52 */     return " " + this.beginText + ".." + this.endText;
/*    */   }
/*    */ }


/* Location:              C:\Users\olatu\OneDrive\Documents\Calypso\syncbase\sync_base.jar!\BOOT-INF\lib\antlr-2.7.7.jar!\antlr\CharRangeElement.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */