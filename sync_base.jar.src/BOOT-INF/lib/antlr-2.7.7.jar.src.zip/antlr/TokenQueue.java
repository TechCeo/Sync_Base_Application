/*    */ package antlr;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class TokenQueue
/*    */ {
/*    */   private Token[] buffer;
/*    */   private int sizeLessOne;
/*    */   private int offset;
/*    */   protected int nbrEntries;
/*    */   
/*    */   public TokenQueue(int paramInt) {
/* 24 */     if (paramInt < 0) {
/* 25 */       init(16);
/*    */       
/*    */       return;
/*    */     } 
/* 29 */     if (paramInt >= 1073741823) {
/* 30 */       init(2147483647); return;
/*    */     } 
/*    */     int i;
/* 33 */     for (i = 2; i < paramInt; i *= 2);
/*    */ 
/*    */     
/* 36 */     init(i);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public final void append(Token paramToken) {
/* 43 */     if (this.nbrEntries == this.buffer.length) {
/* 44 */       expand();
/*    */     }
/* 46 */     this.buffer[this.offset + this.nbrEntries & this.sizeLessOne] = paramToken;
/* 47 */     this.nbrEntries++;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public final Token elementAt(int paramInt) {
/* 54 */     return this.buffer[this.offset + paramInt & this.sizeLessOne];
/*    */   }
/*    */ 
/*    */   
/*    */   private final void expand() {
/* 59 */     Token[] arrayOfToken = new Token[this.buffer.length * 2];
/*    */ 
/*    */ 
/*    */     
/* 63 */     for (byte b = 0; b < this.buffer.length; b++) {
/* 64 */       arrayOfToken[b] = elementAt(b);
/*    */     }
/*    */     
/* 67 */     this.buffer = arrayOfToken;
/* 68 */     this.sizeLessOne = this.buffer.length - 1;
/* 69 */     this.offset = 0;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   private final void init(int paramInt) {
/* 77 */     this.buffer = new Token[paramInt];
/*    */     
/* 79 */     this.sizeLessOne = paramInt - 1;
/* 80 */     this.offset = 0;
/* 81 */     this.nbrEntries = 0;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public final void reset() {
/* 87 */     this.offset = 0;
/* 88 */     this.nbrEntries = 0;
/*    */   }
/*    */ 
/*    */   
/*    */   public final void removeFirst() {
/* 93 */     this.offset = this.offset + 1 & this.sizeLessOne;
/* 94 */     this.nbrEntries--;
/*    */   }
/*    */ }


/* Location:              C:\Users\olatu\OneDrive\Documents\Calypso\syncbase\sync_base.jar!\BOOT-INF\lib\antlr-2.7.7.jar!\antlr\TokenQueue.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */