/*     */ package antlr;
/*     */ 
/*     */ import antlr.collections.impl.BitSet;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TokenStreamHiddenTokenFilter
/*     */   extends TokenStreamBasicFilter
/*     */   implements TokenStream
/*     */ {
/*     */   protected BitSet hideMask;
/*     */   protected CommonHiddenStreamToken nextMonitoredToken;
/*     */   protected CommonHiddenStreamToken lastHiddenToken;
/*  30 */   protected CommonHiddenStreamToken firstHidden = null;
/*     */   
/*     */   public TokenStreamHiddenTokenFilter(TokenStream paramTokenStream) {
/*  33 */     super(paramTokenStream);
/*  34 */     this.hideMask = new BitSet();
/*     */   }
/*     */   
/*     */   protected void consume() throws TokenStreamException {
/*  38 */     this.nextMonitoredToken = (CommonHiddenStreamToken)this.input.nextToken();
/*     */   }
/*     */   
/*     */   private void consumeFirst() throws TokenStreamException {
/*  42 */     consume();
/*     */ 
/*     */ 
/*     */     
/*  46 */     CommonHiddenStreamToken commonHiddenStreamToken = null;
/*     */     
/*  48 */     while (this.hideMask.member(LA(1).getType()) || this.discardMask.member(LA(1).getType())) {
/*  49 */       if (this.hideMask.member(LA(1).getType())) {
/*  50 */         if (commonHiddenStreamToken == null) {
/*  51 */           commonHiddenStreamToken = LA(1);
/*     */         } else {
/*     */           
/*  54 */           commonHiddenStreamToken.setHiddenAfter(LA(1));
/*  55 */           LA(1).setHiddenBefore(commonHiddenStreamToken);
/*  56 */           commonHiddenStreamToken = LA(1);
/*     */         } 
/*  58 */         this.lastHiddenToken = commonHiddenStreamToken;
/*  59 */         if (this.firstHidden == null) {
/*  60 */           this.firstHidden = commonHiddenStreamToken;
/*     */         }
/*     */       } 
/*  63 */       consume();
/*     */     } 
/*     */   }
/*     */   
/*     */   public BitSet getDiscardMask() {
/*  68 */     return this.discardMask;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CommonHiddenStreamToken getHiddenAfter(CommonHiddenStreamToken paramCommonHiddenStreamToken) {
/*  75 */     return paramCommonHiddenStreamToken.getHiddenAfter();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CommonHiddenStreamToken getHiddenBefore(CommonHiddenStreamToken paramCommonHiddenStreamToken) {
/*  82 */     return paramCommonHiddenStreamToken.getHiddenBefore();
/*     */   }
/*     */   
/*     */   public BitSet getHideMask() {
/*  86 */     return this.hideMask;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CommonHiddenStreamToken getInitialHiddenToken() {
/*  93 */     return this.firstHidden;
/*     */   }
/*     */   
/*     */   public void hide(int paramInt) {
/*  97 */     this.hideMask.add(paramInt);
/*     */   }
/*     */   
/*     */   public void hide(BitSet paramBitSet) {
/* 101 */     this.hideMask = paramBitSet;
/*     */   }
/*     */   
/*     */   protected CommonHiddenStreamToken LA(int paramInt) {
/* 105 */     return this.nextMonitoredToken;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Token nextToken() throws TokenStreamException {
/* 121 */     if (LA(1) == null) {
/* 122 */       consumeFirst();
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 127 */     CommonHiddenStreamToken commonHiddenStreamToken1 = LA(1);
/*     */     
/* 129 */     commonHiddenStreamToken1.setHiddenBefore(this.lastHiddenToken);
/* 130 */     this.lastHiddenToken = null;
/*     */ 
/*     */ 
/*     */     
/* 134 */     consume();
/* 135 */     CommonHiddenStreamToken commonHiddenStreamToken2 = commonHiddenStreamToken1;
/*     */     
/* 137 */     while (this.hideMask.member(LA(1).getType()) || this.discardMask.member(LA(1).getType())) {
/* 138 */       if (this.hideMask.member(LA(1).getType())) {
/*     */ 
/*     */         
/* 141 */         commonHiddenStreamToken2.setHiddenAfter(LA(1));
/*     */         
/* 143 */         if (commonHiddenStreamToken2 != commonHiddenStreamToken1) {
/* 144 */           LA(1).setHiddenBefore(commonHiddenStreamToken2);
/*     */         }
/* 146 */         commonHiddenStreamToken2 = this.lastHiddenToken = LA(1);
/*     */       } 
/* 148 */       consume();
/*     */     } 
/* 150 */     return commonHiddenStreamToken1;
/*     */   }
/*     */ }


/* Location:              C:\Users\olatu\OneDrive\Documents\Calypso\syncbase\sync_base.jar!\BOOT-INF\lib\antlr-2.7.7.jar!\antlr\TokenStreamHiddenTokenFilter.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */