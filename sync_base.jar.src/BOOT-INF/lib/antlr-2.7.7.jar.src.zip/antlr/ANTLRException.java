/*    */ package antlr;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ANTLRException
/*    */   extends Exception
/*    */ {
/*    */   public ANTLRException() {}
/*    */   
/*    */   public ANTLRException(String paramString) {
/* 17 */     super(paramString);
/*    */   }
/*    */   
/*    */   public ANTLRException(String paramString, Throwable paramThrowable) {
/* 21 */     super(paramString, paramThrowable);
/*    */   }
/*    */   
/*    */   public ANTLRException(Throwable paramThrowable) {
/* 25 */     super(paramThrowable);
/*    */   }
/*    */ }


/* Location:              C:\Users\olatu\OneDrive\Documents\Calypso\syncbase\sync_base.jar!\BOOT-INF\lib\antlr-2.7.7.jar!\antlr\ANTLRException.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */