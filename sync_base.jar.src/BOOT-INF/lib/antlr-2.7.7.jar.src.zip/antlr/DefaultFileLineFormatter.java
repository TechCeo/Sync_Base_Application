/*    */ package antlr;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DefaultFileLineFormatter
/*    */   extends FileLineFormatter
/*    */ {
/*    */   public String getFormatString(String paramString, int paramInt1, int paramInt2) {
/* 12 */     StringBuffer stringBuffer = new StringBuffer();
/*    */     
/* 14 */     if (paramString != null) {
/* 15 */       stringBuffer.append(paramString + ":");
/*    */     }
/* 17 */     if (paramInt1 != -1) {
/* 18 */       if (paramString == null) {
/* 19 */         stringBuffer.append("line ");
/*    */       }
/* 21 */       stringBuffer.append(paramInt1);
/*    */       
/* 23 */       if (paramInt2 != -1) {
/* 24 */         stringBuffer.append(":" + paramInt2);
/*    */       }
/* 26 */       stringBuffer.append(":");
/*    */     } 
/*    */     
/* 29 */     stringBuffer.append(" ");
/*    */     
/* 31 */     return stringBuffer.toString();
/*    */   }
/*    */ }


/* Location:              C:\Users\olatu\OneDrive\Documents\Calypso\syncbase\sync_base.jar!\BOOT-INF\lib\antlr-2.7.7.jar!\antlr\DefaultFileLineFormatter.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */