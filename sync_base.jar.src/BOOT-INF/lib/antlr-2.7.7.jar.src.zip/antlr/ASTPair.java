/*    */ package antlr;
/*    */ 
/*    */ import antlr.collections.AST;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ASTPair
/*    */ {
/*    */   public AST root;
/*    */   public AST child;
/*    */   
/*    */   public final void advanceChildToEnd() {
/* 23 */     if (this.child != null) {
/* 24 */       while (this.child.getNextSibling() != null) {
/* 25 */         this.child = this.child.getNextSibling();
/*    */       }
/*    */     }
/*    */   }
/*    */ 
/*    */   
/*    */   public ASTPair copy() {
/* 32 */     ASTPair aSTPair = new ASTPair();
/* 33 */     aSTPair.root = this.root;
/* 34 */     aSTPair.child = this.child;
/* 35 */     return aSTPair;
/*    */   }
/*    */   
/*    */   public String toString() {
/* 39 */     String str1 = (this.root == null) ? "null" : this.root.getText();
/* 40 */     String str2 = (this.child == null) ? "null" : this.child.getText();
/* 41 */     return "[" + str1 + "," + str2 + "]";
/*    */   }
/*    */ }


/* Location:              C:\Users\olatu\OneDrive\Documents\Calypso\syncbase\sync_base.jar!\BOOT-INF\lib\antlr-2.7.7.jar!\antlr\ASTPair.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */