/*      */ package antlr;
/*      */ 
/*      */ import antlr.collections.impl.BitSet;
/*      */ import java.io.InputStream;
/*      */ import java.io.Reader;
/*      */ import java.util.Hashtable;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class ANTLRLexer
/*      */   extends CharScanner
/*      */   implements ANTLRTokenTypes, TokenStream
/*      */ {
/*      */   public static int escapeCharValue(String paramString) {
/*   35 */     if (paramString.charAt(1) != '\\') return 0; 
/*   36 */     switch (paramString.charAt(2)) { case 'b':
/*   37 */         return 8;
/*   38 */       case 'r': return 13;
/*   39 */       case 't': return 9;
/*   40 */       case 'n': return 10;
/*   41 */       case 'f': return 12;
/*   42 */       case '"': return 34;
/*   43 */       case '\'': return 39;
/*   44 */       case '\\': return 92;
/*      */ 
/*      */       
/*      */       case 'u':
/*   48 */         if (paramString.length() != 8) {
/*   49 */           return 0;
/*      */         }
/*      */         
/*   52 */         return Character.digit(paramString.charAt(3), 16) * 16 * 16 * 16 + Character.digit(paramString.charAt(4), 16) * 16 * 16 + Character.digit(paramString.charAt(5), 16) * 16 + Character.digit(paramString.charAt(6), 16);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case '0':
/*      */       case '1':
/*      */       case '2':
/*      */       case '3':
/*   63 */         if (paramString.length() > 5 && Character.isDigit(paramString.charAt(4))) {
/*   64 */           return (paramString.charAt(2) - 48) * 8 * 8 + (paramString.charAt(3) - 48) * 8 + paramString.charAt(4) - 48;
/*      */         }
/*   66 */         if (paramString.length() > 4 && Character.isDigit(paramString.charAt(3))) {
/*   67 */           return (paramString.charAt(2) - 48) * 8 + paramString.charAt(3) - 48;
/*      */         }
/*   69 */         return paramString.charAt(2) - 48;
/*      */       
/*      */       case '4':
/*      */       case '5':
/*      */       case '6':
/*      */       case '7':
/*   75 */         if (paramString.length() > 4 && Character.isDigit(paramString.charAt(3))) {
/*   76 */           return (paramString.charAt(2) - 48) * 8 + paramString.charAt(3) - 48;
/*      */         }
/*   78 */         return paramString.charAt(2) - 48; }
/*      */ 
/*      */     
/*   81 */     return 0;
/*      */   }
/*      */ 
/*      */   
/*      */   public static int tokenTypeForCharLiteral(String paramString) {
/*   86 */     if (paramString.length() > 3) {
/*   87 */       return escapeCharValue(paramString);
/*      */     }
/*      */     
/*   90 */     return paramString.charAt(1);
/*      */   }
/*      */   
/*      */   public ANTLRLexer(InputStream paramInputStream) {
/*   94 */     this(new ByteBuffer(paramInputStream));
/*      */   }
/*      */   public ANTLRLexer(Reader paramReader) {
/*   97 */     this(new CharBuffer(paramReader));
/*      */   }
/*      */   public ANTLRLexer(InputBuffer paramInputBuffer) {
/*  100 */     this(new LexerSharedInputState(paramInputBuffer));
/*      */   }
/*      */   public ANTLRLexer(LexerSharedInputState paramLexerSharedInputState) {
/*  103 */     super(paramLexerSharedInputState);
/*  104 */     this.caseSensitiveLiterals = true;
/*  105 */     setCaseSensitive(true);
/*  106 */     this.literals = new Hashtable();
/*  107 */     this.literals.put(new ANTLRHashString("public", this), new Integer(31));
/*  108 */     this.literals.put(new ANTLRHashString("class", this), new Integer(10));
/*  109 */     this.literals.put(new ANTLRHashString("header", this), new Integer(5));
/*  110 */     this.literals.put(new ANTLRHashString("throws", this), new Integer(37));
/*  111 */     this.literals.put(new ANTLRHashString("lexclass", this), new Integer(9));
/*  112 */     this.literals.put(new ANTLRHashString("catch", this), new Integer(40));
/*  113 */     this.literals.put(new ANTLRHashString("private", this), new Integer(32));
/*  114 */     this.literals.put(new ANTLRHashString("options", this), new Integer(51));
/*  115 */     this.literals.put(new ANTLRHashString("extends", this), new Integer(11));
/*  116 */     this.literals.put(new ANTLRHashString("protected", this), new Integer(30));
/*  117 */     this.literals.put(new ANTLRHashString("TreeParser", this), new Integer(13));
/*  118 */     this.literals.put(new ANTLRHashString("Parser", this), new Integer(29));
/*  119 */     this.literals.put(new ANTLRHashString("Lexer", this), new Integer(12));
/*  120 */     this.literals.put(new ANTLRHashString("returns", this), new Integer(35));
/*  121 */     this.literals.put(new ANTLRHashString("charVocabulary", this), new Integer(18));
/*  122 */     this.literals.put(new ANTLRHashString("tokens", this), new Integer(4));
/*  123 */     this.literals.put(new ANTLRHashString("exception", this), new Integer(39));
/*      */   }
/*      */   
/*      */   public Token nextToken() throws TokenStreamException {
/*  127 */     Token token = null;
/*      */     
/*      */     while (true) {
/*  130 */       Object object = null;
/*  131 */       int i = 0;
/*  132 */       resetText();
/*      */       
/*      */       try {
/*  135 */         switch (LA(1)) { case '\t': case '\n':
/*      */           case '\r':
/*      */           case ' ':
/*  138 */             mWS(true);
/*  139 */             token = this._returnToken;
/*      */             break;
/*      */ 
/*      */           
/*      */           case '/':
/*  144 */             mCOMMENT(true);
/*  145 */             token = this._returnToken;
/*      */             break;
/*      */ 
/*      */           
/*      */           case '<':
/*  150 */             mOPEN_ELEMENT_OPTION(true);
/*  151 */             token = this._returnToken;
/*      */             break;
/*      */ 
/*      */           
/*      */           case '>':
/*  156 */             mCLOSE_ELEMENT_OPTION(true);
/*  157 */             token = this._returnToken;
/*      */             break;
/*      */ 
/*      */           
/*      */           case ',':
/*  162 */             mCOMMA(true);
/*  163 */             token = this._returnToken;
/*      */             break;
/*      */ 
/*      */           
/*      */           case '?':
/*  168 */             mQUESTION(true);
/*  169 */             token = this._returnToken;
/*      */             break;
/*      */ 
/*      */           
/*      */           case '#':
/*  174 */             mTREE_BEGIN(true);
/*  175 */             token = this._returnToken;
/*      */             break;
/*      */ 
/*      */           
/*      */           case '(':
/*  180 */             mLPAREN(true);
/*  181 */             token = this._returnToken;
/*      */             break;
/*      */ 
/*      */           
/*      */           case ')':
/*  186 */             mRPAREN(true);
/*  187 */             token = this._returnToken;
/*      */             break;
/*      */ 
/*      */           
/*      */           case ':':
/*  192 */             mCOLON(true);
/*  193 */             token = this._returnToken;
/*      */             break;
/*      */ 
/*      */           
/*      */           case '*':
/*  198 */             mSTAR(true);
/*  199 */             token = this._returnToken;
/*      */             break;
/*      */ 
/*      */           
/*      */           case '+':
/*  204 */             mPLUS(true);
/*  205 */             token = this._returnToken;
/*      */             break;
/*      */ 
/*      */           
/*      */           case ';':
/*  210 */             mSEMI(true);
/*  211 */             token = this._returnToken;
/*      */             break;
/*      */ 
/*      */           
/*      */           case '^':
/*  216 */             mCARET(true);
/*  217 */             token = this._returnToken;
/*      */             break;
/*      */ 
/*      */           
/*      */           case '!':
/*  222 */             mBANG(true);
/*  223 */             token = this._returnToken;
/*      */             break;
/*      */ 
/*      */           
/*      */           case '|':
/*  228 */             mOR(true);
/*  229 */             token = this._returnToken;
/*      */             break;
/*      */ 
/*      */           
/*      */           case '~':
/*  234 */             mNOT_OP(true);
/*  235 */             token = this._returnToken;
/*      */             break;
/*      */ 
/*      */           
/*      */           case '}':
/*  240 */             mRCURLY(true);
/*  241 */             token = this._returnToken;
/*      */             break;
/*      */ 
/*      */           
/*      */           case '\'':
/*  246 */             mCHAR_LITERAL(true);
/*  247 */             token = this._returnToken;
/*      */             break;
/*      */ 
/*      */           
/*      */           case '"':
/*  252 */             mSTRING_LITERAL(true);
/*  253 */             token = this._returnToken; break;
/*      */           case '0': case '1': case '2': case '3': case '4':
/*      */           case '5':
/*      */           case '6':
/*      */           case '7':
/*      */           case '8':
/*      */           case '9':
/*  260 */             mINT(true);
/*  261 */             token = this._returnToken;
/*      */             break;
/*      */ 
/*      */           
/*      */           case '[':
/*  266 */             mARG_ACTION(true);
/*  267 */             token = this._returnToken;
/*      */             break;
/*      */ 
/*      */           
/*      */           case '{':
/*  272 */             mACTION(true);
/*  273 */             token = this._returnToken; break;
/*      */           case 'A': case 'B': case 'C': case 'D': case 'E': case 'F': case 'G': case 'H': case 'I': case 'J': case 'K': case 'L': case 'M': case 'N': case 'O': case 'P': case 'Q':
/*      */           case 'R':
/*      */           case 'S':
/*      */           case 'T':
/*      */           case 'U':
/*      */           case 'V':
/*      */           case 'W':
/*      */           case 'X':
/*      */           case 'Y':
/*      */           case 'Z':
/*  284 */             mTOKEN_REF(true);
/*  285 */             token = this._returnToken; break;
/*      */           case 'a': case 'b': case 'c': case 'd': case 'e': case 'f': case 'g': case 'h': case 'i': case 'j': case 'k': case 'l': case 'm': case 'n': case 'o': case 'p': case 'q':
/*      */           case 'r':
/*      */           case 's':
/*      */           case 't':
/*      */           case 'u':
/*      */           case 'v':
/*      */           case 'w':
/*      */           case 'x':
/*      */           case 'y':
/*      */           case 'z':
/*  296 */             mRULE_REF(true);
/*  297 */             token = this._returnToken;
/*      */             break;
/*      */           
/*      */           default:
/*  301 */             if (LA(1) == '=' && LA(2) == '>') {
/*  302 */               mIMPLIES(true);
/*  303 */               token = this._returnToken; break;
/*      */             } 
/*  305 */             if (LA(1) == '.' && LA(2) == '.') {
/*  306 */               mRANGE(true);
/*  307 */               token = this._returnToken; break;
/*      */             } 
/*  309 */             if (LA(1) == '=') {
/*  310 */               mASSIGN(true);
/*  311 */               token = this._returnToken; break;
/*      */             } 
/*  313 */             if (LA(1) == '.') {
/*  314 */               mWILDCARD(true);
/*  315 */               token = this._returnToken;
/*      */               break;
/*      */             } 
/*  318 */             if (LA(1) == Character.MAX_VALUE) { uponEOF(); this._returnToken = makeToken(1); break; }
/*  319 */              throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn()); }
/*      */ 
/*      */         
/*  322 */         if (this._returnToken == null)
/*  323 */           continue;  i = this._returnToken.getType();
/*  324 */         this._returnToken.setType(i);
/*  325 */         return this._returnToken;
/*      */       }
/*  327 */       catch (RecognitionException recognitionException) {
/*  328 */         throw new TokenStreamRecognitionException(recognitionException);
/*      */       
/*      */       }
/*  331 */       catch (CharStreamException charStreamException) {
/*  332 */         if (charStreamException instanceof CharStreamIOException) {
/*  333 */           throw new TokenStreamIOException(((CharStreamIOException)charStreamException).io);
/*      */         }
/*      */         
/*  336 */         throw new TokenStreamException(charStreamException.getMessage());
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public final void mWS(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/*  343 */     Token token = null; int i = this.text.length();
/*  344 */     byte b = 52;
/*      */ 
/*      */ 
/*      */     
/*  348 */     switch (LA(1)) {
/*      */       
/*      */       case ' ':
/*  351 */         match(' ');
/*      */         break;
/*      */ 
/*      */       
/*      */       case '\t':
/*  356 */         match('\t');
/*      */         break;
/*      */ 
/*      */       
/*      */       case '\n':
/*  361 */         match('\n');
/*  362 */         newline();
/*      */         break;
/*      */       
/*      */       default:
/*  366 */         if (LA(1) == '\r' && LA(2) == '\n') {
/*  367 */           match('\r');
/*  368 */           match('\n');
/*  369 */           newline(); break;
/*      */         } 
/*  371 */         if (LA(1) == '\r') {
/*  372 */           match('\r');
/*  373 */           newline();
/*      */           break;
/*      */         } 
/*  376 */         throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn());
/*      */     } 
/*      */ 
/*      */     
/*  380 */     b = -1;
/*  381 */     if (paramBoolean && token == null && b != -1) {
/*  382 */       token = makeToken(b);
/*  383 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/*  385 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   public final void mCOMMENT(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/*  389 */     Token token1 = null; int j = this.text.length();
/*  390 */     int i = 53;
/*      */     
/*  392 */     Token token2 = null;
/*      */ 
/*      */     
/*  395 */     if (LA(1) == '/' && LA(2) == '/') {
/*  396 */       mSL_COMMENT(false);
/*      */     }
/*  398 */     else if (LA(1) == '/' && LA(2) == '*') {
/*  399 */       mML_COMMENT(true);
/*  400 */       token2 = this._returnToken;
/*  401 */       i = token2.getType();
/*      */     } else {
/*      */       
/*  404 */       throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn());
/*      */     } 
/*      */ 
/*      */     
/*  408 */     if (i != 8) i = -1; 
/*  409 */     if (paramBoolean && token1 == null && i != -1) {
/*  410 */       token1 = makeToken(i);
/*  411 */       token1.setText(new String(this.text.getBuffer(), j, this.text.length() - j));
/*      */     } 
/*  413 */     this._returnToken = token1;
/*      */   }
/*      */   
/*      */   protected final void mSL_COMMENT(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/*  417 */     Token token = null; int i = this.text.length();
/*  418 */     byte b = 54;
/*      */ 
/*      */     
/*  421 */     match("//");
/*      */ 
/*      */ 
/*      */     
/*  425 */     while (_tokenSet_0.member(LA(1)))
/*      */     {
/*  427 */       match(_tokenSet_0);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  437 */     if (LA(1) == '\r' && LA(2) == '\n') {
/*  438 */       match('\r');
/*  439 */       match('\n');
/*      */     }
/*  441 */     else if (LA(1) == '\r') {
/*  442 */       match('\r');
/*      */     }
/*  444 */     else if (LA(1) == '\n') {
/*  445 */       match('\n');
/*      */     } else {
/*      */       
/*  448 */       throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn());
/*      */     } 
/*      */ 
/*      */     
/*  452 */     newline();
/*  453 */     if (paramBoolean && token == null && b != -1) {
/*  454 */       token = makeToken(b);
/*  455 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/*  457 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   protected final void mML_COMMENT(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/*  461 */     Token token = null; int i = this.text.length();
/*  462 */     byte b = 55;
/*      */ 
/*      */     
/*  465 */     match("/*");
/*      */     
/*  467 */     if (LA(1) == '*' && LA(2) >= '\003' && LA(2) <= 'ÿ' && LA(2) != '/') {
/*  468 */       match('*');
/*  469 */       b = 8;
/*      */     }
/*  471 */     else if (LA(1) < '\003' || LA(1) > 'ÿ' || LA(2) < '\003' || LA(2) > 'ÿ') {
/*      */ 
/*      */       
/*  474 */       throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn());
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  482 */     while (LA(1) != '*' || LA(2) != '/') {
/*  483 */       if (LA(1) == '\r' && LA(2) == '\n') {
/*  484 */         match('\r');
/*  485 */         match('\n');
/*  486 */         newline(); continue;
/*      */       } 
/*  488 */       if (LA(1) == '\r' && LA(2) >= '\003' && LA(2) <= 'ÿ') {
/*  489 */         match('\r');
/*  490 */         newline(); continue;
/*      */       } 
/*  492 */       if (_tokenSet_0.member(LA(1)) && LA(2) >= '\003' && LA(2) <= 'ÿ') {
/*      */         
/*  494 */         match(_tokenSet_0);
/*      */         continue;
/*      */       } 
/*  497 */       if (LA(1) == '\n') {
/*  498 */         match('\n');
/*  499 */         newline();
/*      */         
/*      */         continue;
/*      */       } 
/*      */       
/*      */       break;
/*      */     } 
/*      */     
/*  507 */     match("*/");
/*  508 */     if (paramBoolean && token == null && b != -1) {
/*  509 */       token = makeToken(b);
/*  510 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/*  512 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   public final void mOPEN_ELEMENT_OPTION(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/*  516 */     Token token = null; int i = this.text.length();
/*  517 */     byte b = 25;
/*      */ 
/*      */     
/*  520 */     match('<');
/*  521 */     if (paramBoolean && token == null && b != -1) {
/*  522 */       token = makeToken(b);
/*  523 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/*  525 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   public final void mCLOSE_ELEMENT_OPTION(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/*  529 */     Token token = null; int i = this.text.length();
/*  530 */     byte b = 26;
/*      */ 
/*      */     
/*  533 */     match('>');
/*  534 */     if (paramBoolean && token == null && b != -1) {
/*  535 */       token = makeToken(b);
/*  536 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/*  538 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   public final void mCOMMA(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/*  542 */     Token token = null; int i = this.text.length();
/*  543 */     byte b = 38;
/*      */ 
/*      */     
/*  546 */     match(',');
/*  547 */     if (paramBoolean && token == null && b != -1) {
/*  548 */       token = makeToken(b);
/*  549 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/*  551 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   public final void mQUESTION(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/*  555 */     Token token = null; int i = this.text.length();
/*  556 */     byte b = 45;
/*      */ 
/*      */     
/*  559 */     match('?');
/*  560 */     if (paramBoolean && token == null && b != -1) {
/*  561 */       token = makeToken(b);
/*  562 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/*  564 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   public final void mTREE_BEGIN(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/*  568 */     Token token = null; int i = this.text.length();
/*  569 */     byte b = 44;
/*      */ 
/*      */     
/*  572 */     match("#(");
/*  573 */     if (paramBoolean && token == null && b != -1) {
/*  574 */       token = makeToken(b);
/*  575 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/*  577 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   public final void mLPAREN(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/*  581 */     Token token = null; int i = this.text.length();
/*  582 */     byte b = 27;
/*      */ 
/*      */     
/*  585 */     match('(');
/*  586 */     if (paramBoolean && token == null && b != -1) {
/*  587 */       token = makeToken(b);
/*  588 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/*  590 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   public final void mRPAREN(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/*  594 */     Token token = null; int i = this.text.length();
/*  595 */     byte b = 28;
/*      */ 
/*      */     
/*  598 */     match(')');
/*  599 */     if (paramBoolean && token == null && b != -1) {
/*  600 */       token = makeToken(b);
/*  601 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/*  603 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   public final void mCOLON(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/*  607 */     Token token = null; int i = this.text.length();
/*  608 */     byte b = 36;
/*      */ 
/*      */     
/*  611 */     match(':');
/*  612 */     if (paramBoolean && token == null && b != -1) {
/*  613 */       token = makeToken(b);
/*  614 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/*  616 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   public final void mSTAR(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/*  620 */     Token token = null; int i = this.text.length();
/*  621 */     byte b = 46;
/*      */ 
/*      */     
/*  624 */     match('*');
/*  625 */     if (paramBoolean && token == null && b != -1) {
/*  626 */       token = makeToken(b);
/*  627 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/*  629 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   public final void mPLUS(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/*  633 */     Token token = null; int i = this.text.length();
/*  634 */     byte b = 47;
/*      */ 
/*      */     
/*  637 */     match('+');
/*  638 */     if (paramBoolean && token == null && b != -1) {
/*  639 */       token = makeToken(b);
/*  640 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/*  642 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   public final void mASSIGN(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/*  646 */     Token token = null; int i = this.text.length();
/*  647 */     byte b = 15;
/*      */ 
/*      */     
/*  650 */     match('=');
/*  651 */     if (paramBoolean && token == null && b != -1) {
/*  652 */       token = makeToken(b);
/*  653 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/*  655 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   public final void mIMPLIES(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/*  659 */     Token token = null; int i = this.text.length();
/*  660 */     byte b = 48;
/*      */ 
/*      */     
/*  663 */     match("=>");
/*  664 */     if (paramBoolean && token == null && b != -1) {
/*  665 */       token = makeToken(b);
/*  666 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/*  668 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   public final void mSEMI(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/*  672 */     Token token = null; int i = this.text.length();
/*  673 */     byte b = 16;
/*      */ 
/*      */     
/*  676 */     match(';');
/*  677 */     if (paramBoolean && token == null && b != -1) {
/*  678 */       token = makeToken(b);
/*  679 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/*  681 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   public final void mCARET(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/*  685 */     Token token = null; int i = this.text.length();
/*  686 */     byte b = 49;
/*      */ 
/*      */     
/*  689 */     match('^');
/*  690 */     if (paramBoolean && token == null && b != -1) {
/*  691 */       token = makeToken(b);
/*  692 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/*  694 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   public final void mBANG(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/*  698 */     Token token = null; int i = this.text.length();
/*  699 */     byte b = 33;
/*      */ 
/*      */     
/*  702 */     match('!');
/*  703 */     if (paramBoolean && token == null && b != -1) {
/*  704 */       token = makeToken(b);
/*  705 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/*  707 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   public final void mOR(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/*  711 */     Token token = null; int i = this.text.length();
/*  712 */     byte b = 21;
/*      */ 
/*      */     
/*  715 */     match('|');
/*  716 */     if (paramBoolean && token == null && b != -1) {
/*  717 */       token = makeToken(b);
/*  718 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/*  720 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   public final void mWILDCARD(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/*  724 */     Token token = null; int i = this.text.length();
/*  725 */     byte b = 50;
/*      */ 
/*      */     
/*  728 */     match('.');
/*  729 */     if (paramBoolean && token == null && b != -1) {
/*  730 */       token = makeToken(b);
/*  731 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/*  733 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   public final void mRANGE(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/*  737 */     Token token = null; int i = this.text.length();
/*  738 */     byte b = 22;
/*      */ 
/*      */     
/*  741 */     match("..");
/*  742 */     if (paramBoolean && token == null && b != -1) {
/*  743 */       token = makeToken(b);
/*  744 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/*  746 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   public final void mNOT_OP(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/*  750 */     Token token = null; int i = this.text.length();
/*  751 */     byte b = 42;
/*      */ 
/*      */     
/*  754 */     match('~');
/*  755 */     if (paramBoolean && token == null && b != -1) {
/*  756 */       token = makeToken(b);
/*  757 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/*  759 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   public final void mRCURLY(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/*  763 */     Token token = null; int i = this.text.length();
/*  764 */     byte b = 17;
/*      */ 
/*      */     
/*  767 */     match('}');
/*  768 */     if (paramBoolean && token == null && b != -1) {
/*  769 */       token = makeToken(b);
/*  770 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/*  772 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   public final void mCHAR_LITERAL(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/*  776 */     Token token = null; int i = this.text.length();
/*  777 */     byte b = 19;
/*      */ 
/*      */     
/*  780 */     match('\'');
/*      */     
/*  782 */     if (LA(1) == '\\') {
/*  783 */       mESC(false);
/*      */     }
/*  785 */     else if (_tokenSet_1.member(LA(1))) {
/*  786 */       matchNot('\'');
/*      */     } else {
/*      */       
/*  789 */       throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn());
/*      */     } 
/*      */ 
/*      */     
/*  793 */     match('\'');
/*  794 */     if (paramBoolean && token == null && b != -1) {
/*  795 */       token = makeToken(b);
/*  796 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/*  798 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   protected final void mESC(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/*  802 */     Token token = null; int i = this.text.length();
/*  803 */     byte b = 56;
/*      */ 
/*      */     
/*  806 */     match('\\');
/*      */     
/*  808 */     switch (LA(1)) {
/*      */       
/*      */       case 'n':
/*  811 */         match('n');
/*      */         break;
/*      */ 
/*      */       
/*      */       case 'r':
/*  816 */         match('r');
/*      */         break;
/*      */ 
/*      */       
/*      */       case 't':
/*  821 */         match('t');
/*      */         break;
/*      */ 
/*      */       
/*      */       case 'b':
/*  826 */         match('b');
/*      */         break;
/*      */ 
/*      */       
/*      */       case 'f':
/*  831 */         match('f');
/*      */         break;
/*      */ 
/*      */       
/*      */       case 'w':
/*  836 */         match('w');
/*      */         break;
/*      */ 
/*      */       
/*      */       case 'a':
/*  841 */         match('a');
/*      */         break;
/*      */ 
/*      */       
/*      */       case '"':
/*  846 */         match('"');
/*      */         break;
/*      */ 
/*      */       
/*      */       case '\'':
/*  851 */         match('\'');
/*      */         break;
/*      */ 
/*      */       
/*      */       case '\\':
/*  856 */         match('\\');
/*      */         break;
/*      */       case '0':
/*      */       case '1':
/*      */       case '2':
/*      */       case '3':
/*  862 */         matchRange('0', '3');
/*      */ 
/*      */         
/*  865 */         if (LA(1) >= '0' && LA(1) <= '7' && LA(2) >= '\003' && LA(2) <= 'ÿ') {
/*  866 */           matchRange('0', '7');
/*      */           
/*  868 */           if (LA(1) >= '0' && LA(1) <= '7' && LA(2) >= '\003' && LA(2) <= 'ÿ') {
/*  869 */             matchRange('0', '7'); break;
/*      */           } 
/*  871 */           if (LA(1) >= '\003' && LA(1) <= 'ÿ') {
/*      */             break;
/*      */           }
/*  874 */           throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn());
/*      */         } 
/*      */ 
/*      */ 
/*      */         
/*  879 */         if (LA(1) >= '\003' && LA(1) <= 'ÿ') {
/*      */           break;
/*      */         }
/*  882 */         throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn());
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case '4':
/*      */       case '5':
/*      */       case '6':
/*      */       case '7':
/*  891 */         matchRange('4', '7');
/*      */ 
/*      */         
/*  894 */         if (LA(1) >= '0' && LA(1) <= '7' && LA(2) >= '\003' && LA(2) <= 'ÿ') {
/*  895 */           matchRange('0', '7'); break;
/*      */         } 
/*  897 */         if (LA(1) >= '\003' && LA(1) <= 'ÿ') {
/*      */           break;
/*      */         }
/*  900 */         throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn());
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 'u':
/*  908 */         match('u');
/*  909 */         mXDIGIT(false);
/*  910 */         mXDIGIT(false);
/*  911 */         mXDIGIT(false);
/*  912 */         mXDIGIT(false);
/*      */         break;
/*      */ 
/*      */       
/*      */       default:
/*  917 */         throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn());
/*      */     } 
/*      */ 
/*      */     
/*  921 */     if (paramBoolean && token == null && b != -1) {
/*  922 */       token = makeToken(b);
/*  923 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/*  925 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   public final void mSTRING_LITERAL(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/*  929 */     Token token = null; int i = this.text.length();
/*  930 */     byte b = 6;
/*      */ 
/*      */     
/*  933 */     match('"');
/*      */ 
/*      */     
/*      */     while (true) {
/*  937 */       while (LA(1) == '\\') {
/*  938 */         mESC(false);
/*      */       }
/*  940 */       if (_tokenSet_2.member(LA(1))) {
/*  941 */         matchNot('"');
/*      */         
/*      */         continue;
/*      */       } 
/*      */       
/*      */       break;
/*      */     } 
/*      */     
/*  949 */     match('"');
/*  950 */     if (paramBoolean && token == null && b != -1) {
/*  951 */       token = makeToken(b);
/*  952 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/*  954 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   protected final void mXDIGIT(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/*  958 */     Token token = null; int i = this.text.length();
/*  959 */     byte b = 58;
/*      */ 
/*      */     
/*  962 */     switch (LA(1)) { case '0': case '1': case '2': case '3': case '4': case '5':
/*      */       case '6':
/*      */       case '7':
/*      */       case '8':
/*      */       case '9':
/*  967 */         matchRange('0', '9'); break;
/*      */       case 'a': case 'b':
/*      */       case 'c':
/*      */       case 'd':
/*      */       case 'e':
/*      */       case 'f':
/*  973 */         matchRange('a', 'f'); break;
/*      */       case 'A': case 'B':
/*      */       case 'C':
/*      */       case 'D':
/*      */       case 'E':
/*      */       case 'F':
/*  979 */         matchRange('A', 'F');
/*      */         break;
/*      */ 
/*      */       
/*      */       default:
/*  984 */         throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn()); }
/*      */ 
/*      */     
/*  987 */     if (paramBoolean && token == null && b != -1) {
/*  988 */       token = makeToken(b);
/*  989 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/*  991 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   protected final void mDIGIT(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/*  995 */     Token token = null; int i = this.text.length();
/*  996 */     byte b = 57;
/*      */ 
/*      */     
/*  999 */     matchRange('0', '9');
/* 1000 */     if (paramBoolean && token == null && b != -1) {
/* 1001 */       token = makeToken(b);
/* 1002 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/* 1004 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   public final void mINT(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/* 1008 */     Token token = null; int i = this.text.length();
/* 1009 */     byte b1 = 20;
/*      */ 
/*      */ 
/*      */     
/* 1013 */     byte b2 = 0;
/*      */     
/*      */     while (true) {
/* 1016 */       if (LA(1) >= '0' && LA(1) <= '9') {
/* 1017 */         matchRange('0', '9');
/*      */       } else {
/*      */         
/* 1020 */         if (b2 >= 1) break;  throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn());
/*      */       } 
/*      */       
/* 1023 */       b2++;
/*      */     } 
/*      */     
/* 1026 */     if (paramBoolean && token == null && b1 != -1) {
/* 1027 */       token = makeToken(b1);
/* 1028 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/* 1030 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   public final void mARG_ACTION(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/* 1034 */     Token token = null; int i = this.text.length();
/* 1035 */     byte b = 34;
/*      */ 
/*      */     
/* 1038 */     mNESTED_ARG_ACTION(false);
/* 1039 */     setText(StringUtils.stripFrontBack(getText(), "[", "]"));
/* 1040 */     if (paramBoolean && token == null && b != -1) {
/* 1041 */       token = makeToken(b);
/* 1042 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/* 1044 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   protected final void mNESTED_ARG_ACTION(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/* 1048 */     Token token = null; int i = this.text.length();
/* 1049 */     byte b = 59;
/*      */ 
/*      */     
/* 1052 */     match('[');
/*      */ 
/*      */     
/*      */     while (true) {
/* 1056 */       switch (LA(1)) {
/*      */         
/*      */         case '[':
/* 1059 */           mNESTED_ARG_ACTION(false);
/*      */           continue;
/*      */ 
/*      */         
/*      */         case '\n':
/* 1064 */           match('\n');
/* 1065 */           newline();
/*      */           continue;
/*      */ 
/*      */         
/*      */         case '\'':
/* 1070 */           mCHAR_LITERAL(false);
/*      */           continue;
/*      */ 
/*      */         
/*      */         case '"':
/* 1075 */           mSTRING_LITERAL(false);
/*      */           continue;
/*      */       } 
/*      */       
/* 1079 */       if (LA(1) == '\r' && LA(2) == '\n') {
/* 1080 */         match('\r');
/* 1081 */         match('\n');
/* 1082 */         newline(); continue;
/*      */       } 
/* 1084 */       if (LA(1) == '\r' && LA(2) >= '\003' && LA(2) <= 'ÿ') {
/* 1085 */         match('\r');
/* 1086 */         newline(); continue;
/*      */       } 
/* 1088 */       if (_tokenSet_3.member(LA(1))) {
/* 1089 */         matchNot(']');
/*      */         
/*      */         continue;
/*      */       } 
/*      */       
/*      */       break;
/*      */     } 
/*      */     
/* 1097 */     match(']');
/* 1098 */     if (paramBoolean && token == null && b != -1) {
/* 1099 */       token = makeToken(b);
/* 1100 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/* 1102 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   public final void mACTION(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/* 1106 */     Token token = null; int i = this.text.length();
/* 1107 */     byte b = 7;
/*      */     
/* 1109 */     int j = getLine(), k = getColumn();
/*      */     
/* 1111 */     mNESTED_ACTION(false);
/*      */     
/* 1113 */     if (LA(1) == '?') {
/* 1114 */       match('?');
/* 1115 */       b = 43;
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1122 */     if (b == 7) {
/* 1123 */       setText(StringUtils.stripFrontBack(getText(), "{", "}"));
/*      */     } else {
/*      */       
/* 1126 */       setText(StringUtils.stripFrontBack(getText(), "{", "}?"));
/*      */     } 
/* 1128 */     CommonToken commonToken = new CommonToken(b, new String(this.text.getBuffer(), i, this.text.length() - i));
/* 1129 */     commonToken.setLine(j);
/* 1130 */     commonToken.setColumn(k);
/* 1131 */     token = commonToken;
/*      */     
/* 1133 */     if (paramBoolean && token == null && b != -1) {
/* 1134 */       token = makeToken(b);
/* 1135 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/* 1137 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   protected final void mNESTED_ACTION(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/* 1141 */     Token token = null; int i = this.text.length();
/* 1142 */     byte b = 60;
/*      */ 
/*      */     
/* 1145 */     match('{');
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1150 */     while (LA(1) != '}') {
/* 1151 */       if ((LA(1) == '\n' || LA(1) == '\r') && LA(2) >= '\003' && LA(2) <= 'ÿ') {
/*      */         
/* 1153 */         if (LA(1) == '\r' && LA(2) == '\n') {
/* 1154 */           match('\r');
/* 1155 */           match('\n');
/* 1156 */           newline(); continue;
/*      */         } 
/* 1158 */         if (LA(1) == '\r' && LA(2) >= '\003' && LA(2) <= 'ÿ') {
/* 1159 */           match('\r');
/* 1160 */           newline(); continue;
/*      */         } 
/* 1162 */         if (LA(1) == '\n') {
/* 1163 */           match('\n');
/* 1164 */           newline();
/*      */           continue;
/*      */         } 
/* 1167 */         throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn());
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/* 1172 */       if (LA(1) == '{' && LA(2) >= '\003' && LA(2) <= 'ÿ') {
/* 1173 */         mNESTED_ACTION(false); continue;
/*      */       } 
/* 1175 */       if (LA(1) == '\'' && _tokenSet_4.member(LA(2))) {
/* 1176 */         mCHAR_LITERAL(false); continue;
/*      */       } 
/* 1178 */       if (LA(1) == '/' && (LA(2) == '*' || LA(2) == '/')) {
/* 1179 */         mCOMMENT(false); continue;
/*      */       } 
/* 1181 */       if (LA(1) == '"' && LA(2) >= '\003' && LA(2) <= 'ÿ') {
/* 1182 */         mSTRING_LITERAL(false); continue;
/*      */       } 
/* 1184 */       if (LA(1) >= '\003' && LA(1) <= 'ÿ' && LA(2) >= '\003' && LA(2) <= 'ÿ') {
/* 1185 */         matchNot('￿');
/*      */         
/*      */         continue;
/*      */       } 
/*      */       
/*      */       break;
/*      */     } 
/*      */     
/* 1193 */     match('}');
/* 1194 */     if (paramBoolean && token == null && b != -1) {
/* 1195 */       token = makeToken(b);
/* 1196 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/* 1198 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   public final void mTOKEN_REF(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/* 1202 */     Token token = null; int j = this.text.length();
/* 1203 */     int i = 24;
/*      */ 
/*      */     
/* 1206 */     matchRange('A', 'Z');
/*      */ 
/*      */     
/*      */     while (true) {
/* 1210 */       switch (LA(1)) { case 'a': case 'b': case 'c': case 'd': case 'e': case 'f': case 'g': case 'h': case 'i': case 'j': case 'k': case 'l': case 'm': case 'n': case 'o': case 'p': case 'q': case 'r':
/*      */         case 's':
/*      */         case 't':
/*      */         case 'u':
/*      */         case 'v':
/*      */         case 'w':
/*      */         case 'x':
/*      */         case 'y':
/*      */         case 'z':
/* 1219 */           matchRange('a', 'z'); continue;
/*      */         case 'A': case 'B': case 'C': case 'D': case 'E': case 'F': case 'G': case 'H': case 'I': case 'J': case 'K': case 'L': case 'M': case 'N': case 'O': case 'P': case 'Q':
/*      */         case 'R':
/*      */         case 'S':
/*      */         case 'T':
/*      */         case 'U':
/*      */         case 'V':
/*      */         case 'W':
/*      */         case 'X':
/*      */         case 'Y':
/*      */         case 'Z':
/* 1230 */           matchRange('A', 'Z');
/*      */           continue;
/*      */ 
/*      */         
/*      */         case '_':
/* 1235 */           match('_'); continue;
/*      */         case '0': case '1': case '2': case '3': case '4':
/*      */         case '5':
/*      */         case '6':
/*      */         case '7':
/*      */         case '8':
/*      */         case '9':
/* 1242 */           matchRange('0', '9');
/*      */           continue; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       break;
/*      */     } 
/* 1252 */     i = testLiteralsTable(i);
/* 1253 */     if (paramBoolean && token == null && i != -1) {
/* 1254 */       token = makeToken(i);
/* 1255 */       token.setText(new String(this.text.getBuffer(), j, this.text.length() - j));
/*      */     } 
/* 1257 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   public final void mRULE_REF(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/* 1261 */     Token token = null; int j = this.text.length();
/* 1262 */     int i = 41;
/*      */ 
/*      */     
/* 1265 */     int k = 0;
/*      */ 
/*      */     
/* 1268 */     k = mINTERNAL_RULE_REF(false);
/* 1269 */     i = k;
/*      */     
/* 1271 */     if (k == 51) {
/* 1272 */       mWS_LOOP(false);
/*      */       
/* 1274 */       if (LA(1) == '{') {
/* 1275 */         match('{');
/* 1276 */         i = 14;
/*      */ 
/*      */       
/*      */       }
/*      */ 
/*      */     
/*      */     }
/* 1283 */     else if (k == 4) {
/* 1284 */       mWS_LOOP(false);
/*      */       
/* 1286 */       if (LA(1) == '{') {
/* 1287 */         match('{');
/* 1288 */         i = 23;
/*      */       } 
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1299 */     if (paramBoolean && token == null && i != -1) {
/* 1300 */       token = makeToken(i);
/* 1301 */       token.setText(new String(this.text.getBuffer(), j, this.text.length() - j));
/*      */     } 
/* 1303 */     this._returnToken = token;
/*      */   }
/*      */ 
/*      */   
/*      */   protected final int mINTERNAL_RULE_REF(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/* 1308 */     Token token = null; int j = this.text.length();
/* 1309 */     byte b = 62;
/*      */ 
/*      */     
/* 1312 */     int i = 41;
/*      */ 
/*      */     
/* 1315 */     matchRange('a', 'z');
/*      */ 
/*      */     
/*      */     while (true) {
/* 1319 */       switch (LA(1)) { case 'a': case 'b': case 'c': case 'd': case 'e': case 'f': case 'g': case 'h': case 'i': case 'j': case 'k': case 'l': case 'm': case 'n': case 'o': case 'p': case 'q': case 'r':
/*      */         case 's':
/*      */         case 't':
/*      */         case 'u':
/*      */         case 'v':
/*      */         case 'w':
/*      */         case 'x':
/*      */         case 'y':
/*      */         case 'z':
/* 1328 */           matchRange('a', 'z'); continue;
/*      */         case 'A': case 'B': case 'C': case 'D': case 'E': case 'F': case 'G': case 'H': case 'I': case 'J': case 'K': case 'L': case 'M': case 'N': case 'O': case 'P': case 'Q':
/*      */         case 'R':
/*      */         case 'S':
/*      */         case 'T':
/*      */         case 'U':
/*      */         case 'V':
/*      */         case 'W':
/*      */         case 'X':
/*      */         case 'Y':
/*      */         case 'Z':
/* 1339 */           matchRange('A', 'Z');
/*      */           continue;
/*      */ 
/*      */         
/*      */         case '_':
/* 1344 */           match('_'); continue;
/*      */         case '0': case '1': case '2': case '3': case '4':
/*      */         case '5':
/*      */         case '6':
/*      */         case '7':
/*      */         case '8':
/*      */         case '9':
/* 1351 */           matchRange('0', '9');
/*      */           continue; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       break;
/*      */     } 
/* 1361 */     i = testLiteralsTable(i);
/* 1362 */     if (paramBoolean && token == null && b != -1) {
/* 1363 */       token = makeToken(b);
/* 1364 */       token.setText(new String(this.text.getBuffer(), j, this.text.length() - j));
/*      */     } 
/* 1366 */     this._returnToken = token;
/* 1367 */     return i;
/*      */   }
/*      */   
/*      */   protected final void mWS_LOOP(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/* 1371 */     Token token = null; int i = this.text.length();
/* 1372 */     byte b = 61;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     while (true) {
/* 1378 */       switch (LA(1)) { case '\t': case '\n':
/*      */         case '\r':
/*      */         case ' ':
/* 1381 */           mWS(false);
/*      */           continue;
/*      */ 
/*      */         
/*      */         case '/':
/* 1386 */           mCOMMENT(false);
/*      */           continue; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       break;
/*      */     } 
/* 1396 */     if (paramBoolean && token == null && b != -1) {
/* 1397 */       token = makeToken(b);
/* 1398 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/* 1400 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   protected final void mWS_OPT(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/* 1404 */     Token token = null; int i = this.text.length();
/* 1405 */     byte b = 63;
/*      */ 
/*      */ 
/*      */     
/* 1409 */     if (_tokenSet_5.member(LA(1))) {
/* 1410 */       mWS(false);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1416 */     if (paramBoolean && token == null && b != -1) {
/* 1417 */       token = makeToken(b);
/* 1418 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/* 1420 */     this._returnToken = token;
/*      */   }
/*      */ 
/*      */   
/*      */   private static final long[] mk_tokenSet_0() {
/* 1425 */     long[] arrayOfLong = new long[8];
/* 1426 */     arrayOfLong[0] = -9224L;
/* 1427 */     for (byte b = 1; b <= 3; ) { arrayOfLong[b] = -1L; b++; }
/* 1428 */      return arrayOfLong;
/*      */   }
/* 1430 */   public static final BitSet _tokenSet_0 = new BitSet(mk_tokenSet_0());
/*      */   private static final long[] mk_tokenSet_1() {
/* 1432 */     long[] arrayOfLong = new long[8];
/* 1433 */     arrayOfLong[0] = -549755813896L;
/* 1434 */     arrayOfLong[1] = -268435457L;
/* 1435 */     for (byte b = 2; b <= 3; ) { arrayOfLong[b] = -1L; b++; }
/* 1436 */      return arrayOfLong;
/*      */   }
/* 1438 */   public static final BitSet _tokenSet_1 = new BitSet(mk_tokenSet_1());
/*      */   private static final long[] mk_tokenSet_2() {
/* 1440 */     long[] arrayOfLong = new long[8];
/* 1441 */     arrayOfLong[0] = -17179869192L;
/* 1442 */     arrayOfLong[1] = -268435457L;
/* 1443 */     for (byte b = 2; b <= 3; ) { arrayOfLong[b] = -1L; b++; }
/* 1444 */      return arrayOfLong;
/*      */   }
/* 1446 */   public static final BitSet _tokenSet_2 = new BitSet(mk_tokenSet_2());
/*      */   private static final long[] mk_tokenSet_3() {
/* 1448 */     long[] arrayOfLong = new long[8];
/* 1449 */     arrayOfLong[0] = -566935692296L;
/* 1450 */     arrayOfLong[1] = -671088641L;
/* 1451 */     for (byte b = 2; b <= 3; ) { arrayOfLong[b] = -1L; b++; }
/* 1452 */      return arrayOfLong;
/*      */   }
/* 1454 */   public static final BitSet _tokenSet_3 = new BitSet(mk_tokenSet_3());
/*      */   private static final long[] mk_tokenSet_4() {
/* 1456 */     long[] arrayOfLong = new long[8];
/* 1457 */     arrayOfLong[0] = -549755813896L;
/* 1458 */     for (byte b = 1; b <= 3; ) { arrayOfLong[b] = -1L; b++; }
/* 1459 */      return arrayOfLong;
/*      */   }
/* 1461 */   public static final BitSet _tokenSet_4 = new BitSet(mk_tokenSet_4());
/*      */   private static final long[] mk_tokenSet_5() {
/* 1463 */     return new long[] { 4294977024L, 0L, 0L, 0L, 0L };
/*      */   }
/*      */   
/* 1466 */   public static final BitSet _tokenSet_5 = new BitSet(mk_tokenSet_5());
/*      */ }


/* Location:              C:\Users\olatu\OneDrive\Documents\Calypso\syncbase\sync_base.jar!\BOOT-INF\lib\antlr-2.7.7.jar!\antlr\ANTLRLexer.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */