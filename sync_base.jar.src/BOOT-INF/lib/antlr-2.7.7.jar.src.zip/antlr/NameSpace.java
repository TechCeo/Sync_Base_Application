/*    */ package antlr;
/*    */ 
/*    */ import java.io.PrintWriter;
/*    */ import java.util.Enumeration;
/*    */ import java.util.StringTokenizer;
/*    */ import java.util.Vector;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class NameSpace
/*    */ {
/* 22 */   private Vector names = new Vector();
/*    */   private String _name;
/*    */   
/*    */   public NameSpace(String paramString) {
/* 26 */     this._name = new String(paramString);
/* 27 */     parse(paramString);
/*    */   }
/*    */ 
/*    */   
/*    */   public String getName() {
/* 32 */     return this._name;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected void parse(String paramString) {
/* 42 */     StringTokenizer stringTokenizer = new StringTokenizer(paramString, "::");
/* 43 */     while (stringTokenizer.hasMoreTokens()) {
/* 44 */       this.names.addElement(stringTokenizer.nextToken());
/*    */     }
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   void emitDeclarations(PrintWriter paramPrintWriter) {
/* 51 */     for (Enumeration enumeration = this.names.elements(); enumeration.hasMoreElements(); ) {
/* 52 */       String str = enumeration.nextElement();
/* 53 */       paramPrintWriter.println("ANTLR_BEGIN_NAMESPACE(" + str + ")");
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   void emitClosures(PrintWriter paramPrintWriter) {
/* 61 */     for (byte b = 0; b < this.names.size(); b++)
/* 62 */       paramPrintWriter.println("ANTLR_END_NAMESPACE"); 
/*    */   }
/*    */ }


/* Location:              C:\Users\olatu\OneDrive\Documents\Calypso\syncbase\sync_base.jar!\BOOT-INF\lib\antlr-2.7.7.jar!\antlr\NameSpace.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */