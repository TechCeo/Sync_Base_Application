/*      */ package antlr;
/*      */ 
/*      */ import antlr.actions.csharp.ActionLexer;
/*      */ import antlr.collections.impl.BitSet;
/*      */ import antlr.collections.impl.Vector;
/*      */ import java.io.IOException;
/*      */ import java.util.Enumeration;
/*      */ import java.util.Hashtable;
/*      */ import java.util.StringTokenizer;
/*      */ import java.util.Vector;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class CSharpCodeGenerator
/*      */   extends CodeGenerator
/*      */ {
/*   67 */   protected int syntacticPredLevel = 0;
/*      */   
/*      */   protected boolean genAST = false;
/*      */   
/*      */   protected boolean saveText = false;
/*      */   
/*      */   boolean usingCustomAST = false;
/*      */   
/*      */   String labeledElementType;
/*      */   
/*      */   String labeledElementASTType;
/*      */   
/*      */   String labeledElementInit;
/*      */   
/*      */   String commonExtraArgs;
/*      */   
/*      */   String commonExtraParams;
/*      */   
/*      */   String commonLocalVars;
/*      */   
/*      */   String lt1Value;
/*      */   
/*      */   String exceptionThrown;
/*      */   
/*      */   String throwNoViable;
/*      */   
/*      */   RuleBlock currentRule;
/*      */   
/*      */   String currentASTResult;
/*   96 */   Hashtable treeVariableMap = new Hashtable();
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  101 */   Hashtable declaredASTVariables = new Hashtable();
/*      */ 
/*      */   
/*  104 */   int astVarNumber = 1;
/*      */ 
/*      */   
/*  107 */   protected static final String NONUNIQUE = new String();
/*      */ 
/*      */   
/*      */   public static final int caseSizeThreshold = 127;
/*      */   
/*      */   private Vector semPreds;
/*      */   
/*      */   private Vector astTypes;
/*      */   
/*  116 */   private static CSharpNameSpace nameSpace = null;
/*      */ 
/*      */ 
/*      */   
/*      */   int saveIndexCreateLevel;
/*      */ 
/*      */ 
/*      */   
/*      */   int blockNestingLevel;
/*      */ 
/*      */ 
/*      */   
/*      */   public CSharpCodeGenerator() {
/*  129 */     this.charFormatter = new CSharpCharFormatter();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected int addSemPred(String paramString) {
/*  138 */     this.semPreds.appendElement(paramString);
/*  139 */     return this.semPreds.size() - 1;
/*      */   }
/*      */ 
/*      */   
/*      */   public void exitIfError() {
/*  144 */     if (this.antlrTool.hasError())
/*      */     {
/*  146 */       this.antlrTool.fatalError("Exiting due to errors.");
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void gen() {
/*      */     try {
/*  155 */       Enumeration enumeration = this.behavior.grammars.elements();
/*  156 */       while (enumeration.hasMoreElements()) {
/*  157 */         Grammar grammar = enumeration.nextElement();
/*      */         
/*  159 */         grammar.setGrammarAnalyzer(this.analyzer);
/*  160 */         grammar.setCodeGenerator(this);
/*  161 */         this.analyzer.setGrammar(grammar);
/*      */         
/*  163 */         setupGrammarParameters(grammar);
/*  164 */         grammar.generate();
/*  165 */         exitIfError();
/*      */       } 
/*      */ 
/*      */       
/*  169 */       Enumeration enumeration1 = this.behavior.tokenManagers.elements();
/*  170 */       while (enumeration1.hasMoreElements()) {
/*  171 */         TokenManager tokenManager = enumeration1.nextElement();
/*  172 */         if (!tokenManager.isReadOnly()) {
/*      */ 
/*      */ 
/*      */           
/*  176 */           genTokenTypes(tokenManager);
/*      */           
/*  178 */           genTokenInterchange(tokenManager);
/*      */         } 
/*  180 */         exitIfError();
/*      */       }
/*      */     
/*  183 */     } catch (IOException iOException) {
/*  184 */       this.antlrTool.reportException(iOException, null);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void gen(ActionElement paramActionElement) {
/*  192 */     if (this.DEBUG_CODE_GENERATOR) System.out.println("genAction(" + paramActionElement + ")"); 
/*  193 */     if (paramActionElement.isSemPred) {
/*  194 */       genSemPred(paramActionElement.actionText, paramActionElement.line);
/*      */     } else {
/*      */       
/*  197 */       if (this.grammar.hasSyntacticPredicate) {
/*  198 */         println("if (0==inputState.guessing)");
/*  199 */         println("{");
/*  200 */         this.tabs++;
/*      */       } 
/*      */       
/*  203 */       ActionTransInfo actionTransInfo = new ActionTransInfo();
/*  204 */       String str = processActionForSpecialSymbols(paramActionElement.actionText, paramActionElement.getLine(), this.currentRule, actionTransInfo);
/*      */ 
/*      */ 
/*      */       
/*  208 */       if (actionTransInfo.refRuleRoot != null)
/*      */       {
/*      */ 
/*      */ 
/*      */         
/*  213 */         println(actionTransInfo.refRuleRoot + " = (" + this.labeledElementASTType + ")currentAST.root;");
/*      */       }
/*      */ 
/*      */       
/*  217 */       printAction(str);
/*      */       
/*  219 */       if (actionTransInfo.assignToRoot) {
/*      */         
/*  221 */         println("currentAST.root = " + actionTransInfo.refRuleRoot + ";");
/*      */         
/*  223 */         println("if ( (null != " + actionTransInfo.refRuleRoot + ") && (null != " + actionTransInfo.refRuleRoot + ".getFirstChild()) )");
/*  224 */         this.tabs++;
/*  225 */         println("currentAST.child = " + actionTransInfo.refRuleRoot + ".getFirstChild();");
/*  226 */         this.tabs--;
/*  227 */         println("else");
/*  228 */         this.tabs++;
/*  229 */         println("currentAST.child = " + actionTransInfo.refRuleRoot + ";");
/*  230 */         this.tabs--;
/*  231 */         println("currentAST.advanceChildToEnd();");
/*      */       } 
/*      */       
/*  234 */       if (this.grammar.hasSyntacticPredicate) {
/*  235 */         this.tabs--;
/*  236 */         println("}");
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void gen(AlternativeBlock paramAlternativeBlock) {
/*  245 */     if (this.DEBUG_CODE_GENERATOR) System.out.println("gen(" + paramAlternativeBlock + ")"); 
/*  246 */     println("{");
/*  247 */     this.tabs++;
/*      */     
/*  249 */     genBlockPreamble(paramAlternativeBlock);
/*  250 */     genBlockInitAction(paramAlternativeBlock);
/*      */ 
/*      */     
/*  253 */     String str = this.currentASTResult;
/*  254 */     if (paramAlternativeBlock.getLabel() != null) {
/*  255 */       this.currentASTResult = paramAlternativeBlock.getLabel();
/*      */     }
/*      */     
/*  258 */     boolean bool = this.grammar.theLLkAnalyzer.deterministic(paramAlternativeBlock);
/*      */     
/*  260 */     CSharpBlockFinishingInfo cSharpBlockFinishingInfo = genCommonBlock(paramAlternativeBlock, true);
/*  261 */     genBlockFinish(cSharpBlockFinishingInfo, this.throwNoViable);
/*      */     
/*  263 */     this.tabs--;
/*  264 */     println("}");
/*      */ 
/*      */     
/*  267 */     this.currentASTResult = str;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void gen(BlockEndElement paramBlockEndElement) {
/*  275 */     if (this.DEBUG_CODE_GENERATOR) System.out.println("genRuleEnd(" + paramBlockEndElement + ")");
/*      */   
/*      */   }
/*      */ 
/*      */   
/*      */   public void gen(CharLiteralElement paramCharLiteralElement) {
/*  281 */     if (this.DEBUG_CODE_GENERATOR) System.out.println("genChar(" + paramCharLiteralElement + ")");
/*      */     
/*  283 */     if (paramCharLiteralElement.getLabel() != null) {
/*  284 */       println(paramCharLiteralElement.getLabel() + " = " + this.lt1Value + ";");
/*      */     }
/*      */     
/*  287 */     boolean bool = this.saveText;
/*  288 */     this.saveText = (this.saveText && paramCharLiteralElement.getAutoGenType() == 1);
/*  289 */     genMatch(paramCharLiteralElement);
/*  290 */     this.saveText = bool;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void gen(CharRangeElement paramCharRangeElement) {
/*  296 */     if (paramCharRangeElement.getLabel() != null && this.syntacticPredLevel == 0) {
/*  297 */       println(paramCharRangeElement.getLabel() + " = " + this.lt1Value + ";");
/*      */     }
/*  299 */     boolean bool = (this.grammar instanceof LexerGrammar && (!this.saveText || paramCharRangeElement.getAutoGenType() == 3)) ? true : false;
/*      */     
/*  301 */     if (bool) {
/*  302 */       println("_saveIndex = text.Length;");
/*      */     }
/*  304 */     println("matchRange(" + OctalToUnicode(paramCharRangeElement.beginText) + "," + OctalToUnicode(paramCharRangeElement.endText) + ");");
/*      */     
/*  306 */     if (bool) {
/*  307 */       println("text.Length = _saveIndex;");
/*      */     }
/*      */   }
/*      */   
/*      */   public void gen(LexerGrammar paramLexerGrammar) throws IOException {
/*  312 */     if (paramLexerGrammar.debuggingOutput) {
/*  313 */       this.semPreds = new Vector();
/*      */     }
/*  315 */     setGrammar(paramLexerGrammar);
/*  316 */     if (!(this.grammar instanceof LexerGrammar)) {
/*  317 */       this.antlrTool.panic("Internal error generating lexer");
/*      */     }
/*  319 */     genBody(paramLexerGrammar);
/*      */   }
/*      */ 
/*      */   
/*      */   public void gen(OneOrMoreBlock paramOneOrMoreBlock) {
/*      */     String str1, str2;
/*  325 */     if (this.DEBUG_CODE_GENERATOR) System.out.println("gen+(" + paramOneOrMoreBlock + ")");
/*      */ 
/*      */     
/*  328 */     println("{ // ( ... )+");
/*  329 */     this.tabs++;
/*  330 */     this.blockNestingLevel++;
/*  331 */     genBlockPreamble(paramOneOrMoreBlock);
/*  332 */     if (paramOneOrMoreBlock.getLabel() != null) {
/*  333 */       str2 = "_cnt_" + paramOneOrMoreBlock.getLabel();
/*      */     } else {
/*      */       
/*  336 */       str2 = "_cnt" + paramOneOrMoreBlock.ID;
/*      */     } 
/*  338 */     println("int " + str2 + "=0;");
/*  339 */     if (paramOneOrMoreBlock.getLabel() != null) {
/*  340 */       str1 = paramOneOrMoreBlock.getLabel();
/*      */     } else {
/*      */       
/*  343 */       str1 = "_loop" + paramOneOrMoreBlock.ID;
/*      */     } 
/*      */     
/*  346 */     println("for (;;)");
/*  347 */     println("{");
/*  348 */     this.tabs++;
/*  349 */     this.blockNestingLevel++;
/*      */ 
/*      */     
/*  352 */     genBlockInitAction(paramOneOrMoreBlock);
/*      */ 
/*      */     
/*  355 */     String str3 = this.currentASTResult;
/*  356 */     if (paramOneOrMoreBlock.getLabel() != null) {
/*  357 */       this.currentASTResult = paramOneOrMoreBlock.getLabel();
/*      */     }
/*      */     
/*  360 */     boolean bool = this.grammar.theLLkAnalyzer.deterministic(paramOneOrMoreBlock);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  372 */     boolean bool1 = false;
/*  373 */     int i = this.grammar.maxk;
/*      */     
/*  375 */     if (!paramOneOrMoreBlock.greedy && paramOneOrMoreBlock.exitLookaheadDepth <= this.grammar.maxk && paramOneOrMoreBlock.exitCache[paramOneOrMoreBlock.exitLookaheadDepth].containsEpsilon()) {
/*      */ 
/*      */ 
/*      */       
/*  379 */       bool1 = true;
/*  380 */       i = paramOneOrMoreBlock.exitLookaheadDepth;
/*      */     }
/*  382 */     else if (!paramOneOrMoreBlock.greedy && paramOneOrMoreBlock.exitLookaheadDepth == Integer.MAX_VALUE) {
/*      */ 
/*      */       
/*  385 */       bool1 = true;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  390 */     if (bool1) {
/*  391 */       if (this.DEBUG_CODE_GENERATOR) {
/*  392 */         System.out.println("nongreedy (...)+ loop; exit depth is " + paramOneOrMoreBlock.exitLookaheadDepth);
/*      */       }
/*      */       
/*  395 */       String str = getLookaheadTestExpression(paramOneOrMoreBlock.exitCache, i);
/*      */ 
/*      */       
/*  398 */       println("// nongreedy exit test");
/*  399 */       println("if ((" + str2 + " >= 1) && " + str + ") goto " + str1 + "_breakloop;");
/*      */     } 
/*      */     
/*  402 */     CSharpBlockFinishingInfo cSharpBlockFinishingInfo = genCommonBlock(paramOneOrMoreBlock, false);
/*  403 */     genBlockFinish(cSharpBlockFinishingInfo, "if (" + str2 + " >= 1) { goto " + str1 + "_breakloop; } else { " + this.throwNoViable + "; }");
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  408 */     println(str2 + "++;");
/*  409 */     this.tabs--;
/*  410 */     if (this.blockNestingLevel-- == this.saveIndexCreateLevel)
/*  411 */       this.saveIndexCreateLevel = 0; 
/*  412 */     println("}");
/*  413 */     _print(str1 + "_breakloop:");
/*  414 */     println(";");
/*  415 */     this.tabs--;
/*  416 */     if (this.blockNestingLevel-- == this.saveIndexCreateLevel)
/*  417 */       this.saveIndexCreateLevel = 0; 
/*  418 */     println("}    // ( ... )+");
/*      */ 
/*      */     
/*  421 */     this.currentASTResult = str3;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void gen(ParserGrammar paramParserGrammar) throws IOException {
/*  428 */     if (paramParserGrammar.debuggingOutput) {
/*  429 */       this.semPreds = new Vector();
/*      */     }
/*  431 */     setGrammar(paramParserGrammar);
/*  432 */     if (!(this.grammar instanceof ParserGrammar)) {
/*  433 */       this.antlrTool.panic("Internal error generating parser");
/*      */     }
/*  435 */     genBody(paramParserGrammar);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void gen(RuleRefElement paramRuleRefElement) {
/*  442 */     if (this.DEBUG_CODE_GENERATOR) System.out.println("genRR(" + paramRuleRefElement + ")"); 
/*  443 */     RuleSymbol ruleSymbol = (RuleSymbol)this.grammar.getSymbol(paramRuleRefElement.targetRule);
/*  444 */     if (ruleSymbol == null || !ruleSymbol.isDefined()) {
/*      */ 
/*      */       
/*  447 */       this.antlrTool.error("Rule '" + paramRuleRefElement.targetRule + "' is not defined", this.grammar.getFilename(), paramRuleRefElement.getLine(), paramRuleRefElement.getColumn());
/*      */       return;
/*      */     } 
/*  450 */     if (!(ruleSymbol instanceof RuleSymbol)) {
/*      */ 
/*      */       
/*  453 */       this.antlrTool.error("'" + paramRuleRefElement.targetRule + "' does not name a grammar rule", this.grammar.getFilename(), paramRuleRefElement.getLine(), paramRuleRefElement.getColumn());
/*      */       
/*      */       return;
/*      */     } 
/*  457 */     genErrorTryForElement(paramRuleRefElement);
/*      */ 
/*      */ 
/*      */     
/*  461 */     if (this.grammar instanceof TreeWalkerGrammar && paramRuleRefElement.getLabel() != null && this.syntacticPredLevel == 0)
/*      */     {
/*      */ 
/*      */       
/*  465 */       println(paramRuleRefElement.getLabel() + " = _t==ASTNULL ? null : " + this.lt1Value + ";");
/*      */     }
/*      */ 
/*      */     
/*  469 */     if (this.grammar instanceof LexerGrammar && (!this.saveText || paramRuleRefElement.getAutoGenType() == 3)) {
/*      */       
/*  471 */       declareSaveIndexVariableIfNeeded();
/*  472 */       println("_saveIndex = text.Length;");
/*      */     } 
/*      */ 
/*      */     
/*  476 */     printTabs();
/*  477 */     if (paramRuleRefElement.idAssign != null) {
/*      */ 
/*      */       
/*  480 */       if (ruleSymbol.block.returnAction == null)
/*      */       {
/*  482 */         this.antlrTool.warning("Rule '" + paramRuleRefElement.targetRule + "' has no return type", this.grammar.getFilename(), paramRuleRefElement.getLine(), paramRuleRefElement.getColumn());
/*      */       }
/*  484 */       _print(paramRuleRefElement.idAssign + "=");
/*      */     
/*      */     }
/*  487 */     else if (!(this.grammar instanceof LexerGrammar) && this.syntacticPredLevel == 0 && ruleSymbol.block.returnAction != null) {
/*      */       
/*  489 */       this.antlrTool.warning("Rule '" + paramRuleRefElement.targetRule + "' returns a value", this.grammar.getFilename(), paramRuleRefElement.getLine(), paramRuleRefElement.getColumn());
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  494 */     GenRuleInvocation(paramRuleRefElement);
/*      */ 
/*      */     
/*  497 */     if (this.grammar instanceof LexerGrammar && (!this.saveText || paramRuleRefElement.getAutoGenType() == 3)) {
/*  498 */       declareSaveIndexVariableIfNeeded();
/*  499 */       println("text.Length = _saveIndex;");
/*      */     } 
/*      */ 
/*      */     
/*  503 */     if (this.syntacticPredLevel == 0) {
/*      */       
/*  505 */       boolean bool = (this.grammar.hasSyntacticPredicate && ((this.grammar.buildAST && paramRuleRefElement.getLabel() != null) || (this.genAST && paramRuleRefElement.getAutoGenType() == 1))) ? true : false;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  512 */       if (bool) {
/*  513 */         println("if (0 == inputState.guessing)");
/*  514 */         println("{");
/*  515 */         this.tabs++;
/*      */       } 
/*      */       
/*  518 */       if (this.grammar.buildAST && paramRuleRefElement.getLabel() != null)
/*      */       {
/*      */         
/*  521 */         println(paramRuleRefElement.getLabel() + "_AST = (" + this.labeledElementASTType + ")returnAST;");
/*      */       }
/*  523 */       if (this.genAST)
/*      */       {
/*  525 */         switch (paramRuleRefElement.getAutoGenType()) {
/*      */           
/*      */           case 1:
/*  528 */             if (this.usingCustomAST) {
/*  529 */               println("astFactory.addASTChild(ref currentAST, (AST)returnAST);"); break;
/*      */             } 
/*  531 */             println("astFactory.addASTChild(ref currentAST, returnAST);");
/*      */             break;
/*      */           case 2:
/*  534 */             this.antlrTool.error("Internal: encountered ^ after rule reference");
/*      */             break;
/*      */         } 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       }
/*  542 */       if (this.grammar instanceof LexerGrammar && paramRuleRefElement.getLabel() != null)
/*      */       {
/*  544 */         println(paramRuleRefElement.getLabel() + " = returnToken_;");
/*      */       }
/*      */       
/*  547 */       if (bool) {
/*      */         
/*  549 */         this.tabs--;
/*  550 */         println("}");
/*      */       } 
/*      */     } 
/*  553 */     genErrorCatchForElement(paramRuleRefElement);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void gen(StringLiteralElement paramStringLiteralElement) {
/*  559 */     if (this.DEBUG_CODE_GENERATOR) System.out.println("genString(" + paramStringLiteralElement + ")");
/*      */ 
/*      */     
/*  562 */     if (paramStringLiteralElement.getLabel() != null && this.syntacticPredLevel == 0) {
/*  563 */       println(paramStringLiteralElement.getLabel() + " = " + this.lt1Value + ";");
/*      */     }
/*      */ 
/*      */     
/*  567 */     genElementAST(paramStringLiteralElement);
/*      */ 
/*      */     
/*  570 */     boolean bool = this.saveText;
/*  571 */     this.saveText = (this.saveText && paramStringLiteralElement.getAutoGenType() == 1);
/*      */ 
/*      */     
/*  574 */     genMatch(paramStringLiteralElement);
/*      */     
/*  576 */     this.saveText = bool;
/*      */ 
/*      */     
/*  579 */     if (this.grammar instanceof TreeWalkerGrammar) {
/*  580 */       println("_t = _t.getNextSibling();");
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void gen(TokenRangeElement paramTokenRangeElement) {
/*  588 */     genErrorTryForElement(paramTokenRangeElement);
/*  589 */     if (paramTokenRangeElement.getLabel() != null && this.syntacticPredLevel == 0) {
/*  590 */       println(paramTokenRangeElement.getLabel() + " = " + this.lt1Value + ";");
/*      */     }
/*      */ 
/*      */     
/*  594 */     genElementAST(paramTokenRangeElement);
/*      */ 
/*      */     
/*  597 */     println("matchRange(" + OctalToUnicode(paramTokenRangeElement.beginText) + "," + OctalToUnicode(paramTokenRangeElement.endText) + ");");
/*  598 */     genErrorCatchForElement(paramTokenRangeElement);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void gen(TokenRefElement paramTokenRefElement) {
/*  605 */     if (this.DEBUG_CODE_GENERATOR) System.out.println("genTokenRef(" + paramTokenRefElement + ")"); 
/*  606 */     if (this.grammar instanceof LexerGrammar) {
/*  607 */       this.antlrTool.panic("Token reference found in lexer");
/*      */     }
/*  609 */     genErrorTryForElement(paramTokenRefElement);
/*      */     
/*  611 */     if (paramTokenRefElement.getLabel() != null && this.syntacticPredLevel == 0) {
/*  612 */       println(paramTokenRefElement.getLabel() + " = " + this.lt1Value + ";");
/*      */     }
/*      */ 
/*      */     
/*  616 */     genElementAST(paramTokenRefElement);
/*      */     
/*  618 */     genMatch(paramTokenRefElement);
/*  619 */     genErrorCatchForElement(paramTokenRefElement);
/*      */ 
/*      */     
/*  622 */     if (this.grammar instanceof TreeWalkerGrammar) {
/*  623 */       println("_t = _t.getNextSibling();");
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   public void gen(TreeElement paramTreeElement) {
/*  629 */     println("AST __t" + paramTreeElement.ID + " = _t;");
/*      */ 
/*      */     
/*  632 */     if (paramTreeElement.root.getLabel() != null) {
/*  633 */       println(paramTreeElement.root.getLabel() + " = (ASTNULL == _t) ? null : (" + this.labeledElementASTType + ")_t;");
/*      */     }
/*      */ 
/*      */     
/*  637 */     if (paramTreeElement.root.getAutoGenType() == 3) {
/*  638 */       this.antlrTool.error("Suffixing a root node with '!' is not implemented", this.grammar.getFilename(), paramTreeElement.getLine(), paramTreeElement.getColumn());
/*      */       
/*  640 */       paramTreeElement.root.setAutoGenType(1);
/*      */     } 
/*  642 */     if (paramTreeElement.root.getAutoGenType() == 2) {
/*  643 */       this.antlrTool.warning("Suffixing a root node with '^' is redundant; already a root", this.grammar.getFilename(), paramTreeElement.getLine(), paramTreeElement.getColumn());
/*      */       
/*  645 */       paramTreeElement.root.setAutoGenType(1);
/*      */     } 
/*      */ 
/*      */     
/*  649 */     genElementAST(paramTreeElement.root);
/*  650 */     if (this.grammar.buildAST) {
/*      */       
/*  652 */       println("ASTPair __currentAST" + paramTreeElement.ID + " = currentAST.copy();");
/*      */       
/*  654 */       println("currentAST.root = currentAST.child;");
/*  655 */       println("currentAST.child = null;");
/*      */     } 
/*      */ 
/*      */     
/*  659 */     if (paramTreeElement.root instanceof WildcardElement) {
/*  660 */       println("if (null == _t) throw new MismatchedTokenException();");
/*      */     } else {
/*      */       
/*  663 */       genMatch(paramTreeElement.root);
/*      */     } 
/*      */     
/*  666 */     println("_t = _t.getFirstChild();");
/*      */ 
/*      */     
/*  669 */     for (byte b = 0; b < paramTreeElement.getAlternatives().size(); b++) {
/*  670 */       Alternative alternative = paramTreeElement.getAlternativeAt(b);
/*  671 */       AlternativeElement alternativeElement = alternative.head;
/*  672 */       while (alternativeElement != null) {
/*  673 */         alternativeElement.generate();
/*  674 */         alternativeElement = alternativeElement.next;
/*      */       } 
/*      */     } 
/*      */     
/*  678 */     if (this.grammar.buildAST)
/*      */     {
/*      */       
/*  681 */       println("currentAST = __currentAST" + paramTreeElement.ID + ";");
/*      */     }
/*      */     
/*  684 */     println("_t = __t" + paramTreeElement.ID + ";");
/*      */     
/*  686 */     println("_t = _t.getNextSibling();");
/*      */   }
/*      */ 
/*      */   
/*      */   public void gen(TreeWalkerGrammar paramTreeWalkerGrammar) throws IOException {
/*  691 */     setGrammar(paramTreeWalkerGrammar);
/*  692 */     if (!(this.grammar instanceof TreeWalkerGrammar)) {
/*  693 */       this.antlrTool.panic("Internal error generating tree-walker");
/*      */     }
/*  695 */     genBody(paramTreeWalkerGrammar);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void gen(WildcardElement paramWildcardElement) {
/*  703 */     if (paramWildcardElement.getLabel() != null && this.syntacticPredLevel == 0) {
/*  704 */       println(paramWildcardElement.getLabel() + " = " + this.lt1Value + ";");
/*      */     }
/*      */ 
/*      */     
/*  708 */     genElementAST(paramWildcardElement);
/*      */     
/*  710 */     if (this.grammar instanceof TreeWalkerGrammar) {
/*  711 */       println("if (null == _t) throw new MismatchedTokenException();");
/*      */     }
/*  713 */     else if (this.grammar instanceof LexerGrammar) {
/*  714 */       if (this.grammar instanceof LexerGrammar && (!this.saveText || paramWildcardElement.getAutoGenType() == 3)) {
/*      */         
/*  716 */         declareSaveIndexVariableIfNeeded();
/*  717 */         println("_saveIndex = text.Length;");
/*      */       } 
/*  719 */       println("matchNot(EOF/*_CHAR*/);");
/*  720 */       if (this.grammar instanceof LexerGrammar && (!this.saveText || paramWildcardElement.getAutoGenType() == 3)) {
/*      */         
/*  722 */         declareSaveIndexVariableIfNeeded();
/*  723 */         println("text.Length = _saveIndex;");
/*      */       } 
/*      */     } else {
/*      */       
/*  727 */       println("matchNot(" + getValueString(1) + ");");
/*      */     } 
/*      */ 
/*      */     
/*  731 */     if (this.grammar instanceof TreeWalkerGrammar) {
/*  732 */       println("_t = _t.getNextSibling();");
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void gen(ZeroOrMoreBlock paramZeroOrMoreBlock) {
/*      */     String str1;
/*  740 */     if (this.DEBUG_CODE_GENERATOR) System.out.println("gen*(" + paramZeroOrMoreBlock + ")"); 
/*  741 */     println("{    // ( ... )*");
/*  742 */     this.tabs++;
/*  743 */     this.blockNestingLevel++;
/*  744 */     genBlockPreamble(paramZeroOrMoreBlock);
/*      */     
/*  746 */     if (paramZeroOrMoreBlock.getLabel() != null) {
/*  747 */       str1 = paramZeroOrMoreBlock.getLabel();
/*      */     } else {
/*      */       
/*  750 */       str1 = "_loop" + paramZeroOrMoreBlock.ID;
/*      */     } 
/*  752 */     println("for (;;)");
/*  753 */     println("{");
/*  754 */     this.tabs++;
/*  755 */     this.blockNestingLevel++;
/*      */ 
/*      */     
/*  758 */     genBlockInitAction(paramZeroOrMoreBlock);
/*      */ 
/*      */     
/*  761 */     String str2 = this.currentASTResult;
/*  762 */     if (paramZeroOrMoreBlock.getLabel() != null) {
/*  763 */       this.currentASTResult = paramZeroOrMoreBlock.getLabel();
/*      */     }
/*      */     
/*  766 */     boolean bool = this.grammar.theLLkAnalyzer.deterministic(paramZeroOrMoreBlock);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  778 */     boolean bool1 = false;
/*  779 */     int i = this.grammar.maxk;
/*      */     
/*  781 */     if (!paramZeroOrMoreBlock.greedy && paramZeroOrMoreBlock.exitLookaheadDepth <= this.grammar.maxk && paramZeroOrMoreBlock.exitCache[paramZeroOrMoreBlock.exitLookaheadDepth].containsEpsilon()) {
/*      */ 
/*      */ 
/*      */       
/*  785 */       bool1 = true;
/*  786 */       i = paramZeroOrMoreBlock.exitLookaheadDepth;
/*      */     }
/*  788 */     else if (!paramZeroOrMoreBlock.greedy && paramZeroOrMoreBlock.exitLookaheadDepth == Integer.MAX_VALUE) {
/*      */ 
/*      */       
/*  791 */       bool1 = true;
/*      */     } 
/*  793 */     if (bool1) {
/*  794 */       if (this.DEBUG_CODE_GENERATOR) {
/*  795 */         System.out.println("nongreedy (...)* loop; exit depth is " + paramZeroOrMoreBlock.exitLookaheadDepth);
/*      */       }
/*      */       
/*  798 */       String str = getLookaheadTestExpression(paramZeroOrMoreBlock.exitCache, i);
/*      */ 
/*      */       
/*  801 */       println("// nongreedy exit test");
/*  802 */       println("if (" + str + ") goto " + str1 + "_breakloop;");
/*      */     } 
/*      */     
/*  805 */     CSharpBlockFinishingInfo cSharpBlockFinishingInfo = genCommonBlock(paramZeroOrMoreBlock, false);
/*  806 */     genBlockFinish(cSharpBlockFinishingInfo, "goto " + str1 + "_breakloop;");
/*      */     
/*  808 */     this.tabs--;
/*  809 */     if (this.blockNestingLevel-- == this.saveIndexCreateLevel)
/*  810 */       this.saveIndexCreateLevel = 0; 
/*  811 */     println("}");
/*  812 */     _print(str1 + "_breakloop:");
/*  813 */     println(";");
/*  814 */     this.tabs--;
/*  815 */     if (this.blockNestingLevel-- == this.saveIndexCreateLevel)
/*  816 */       this.saveIndexCreateLevel = 0; 
/*  817 */     println("}    // ( ... )*");
/*      */ 
/*      */     
/*  820 */     this.currentASTResult = str2;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void genAlt(Alternative paramAlternative, AlternativeBlock paramAlternativeBlock) {
/*  830 */     boolean bool1 = this.genAST;
/*  831 */     this.genAST = (this.genAST && paramAlternative.getAutoGen());
/*      */     
/*  833 */     boolean bool2 = this.saveText;
/*  834 */     this.saveText = (this.saveText && paramAlternative.getAutoGen());
/*      */ 
/*      */     
/*  837 */     Hashtable hashtable = this.treeVariableMap;
/*  838 */     this.treeVariableMap = new Hashtable();
/*      */ 
/*      */     
/*  841 */     if (paramAlternative.exceptionSpec != null) {
/*  842 */       println("try        // for error handling");
/*  843 */       println("{");
/*  844 */       this.tabs++;
/*      */     } 
/*      */     
/*  847 */     AlternativeElement alternativeElement = paramAlternative.head;
/*  848 */     while (!(alternativeElement instanceof BlockEndElement)) {
/*  849 */       alternativeElement.generate();
/*  850 */       alternativeElement = alternativeElement.next;
/*      */     } 
/*      */     
/*  853 */     if (this.genAST)
/*      */     {
/*  855 */       if (paramAlternativeBlock instanceof RuleBlock) {
/*      */ 
/*      */         
/*  858 */         RuleBlock ruleBlock = (RuleBlock)paramAlternativeBlock;
/*  859 */         if (this.usingCustomAST)
/*      */         {
/*  861 */           println(ruleBlock.getRuleName() + "_AST = (" + this.labeledElementASTType + ")currentAST.root;");
/*      */         }
/*      */         else
/*      */         {
/*  865 */           println(ruleBlock.getRuleName() + "_AST = currentAST.root;");
/*      */         }
/*      */       
/*  868 */       } else if (paramAlternativeBlock.getLabel() != null) {
/*      */ 
/*      */         
/*  871 */         this.antlrTool.warning("Labeled subrules not yet supported", this.grammar.getFilename(), paramAlternativeBlock.getLine(), paramAlternativeBlock.getColumn());
/*      */       } 
/*      */     }
/*      */     
/*  875 */     if (paramAlternative.exceptionSpec != null) {
/*      */ 
/*      */       
/*  878 */       this.tabs--;
/*  879 */       println("}");
/*  880 */       genErrorHandler(paramAlternative.exceptionSpec);
/*      */     } 
/*      */     
/*  883 */     this.genAST = bool1;
/*  884 */     this.saveText = bool2;
/*      */     
/*  886 */     this.treeVariableMap = hashtable;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void genBitsets(Vector paramVector, int paramInt) {
/*  900 */     println("");
/*  901 */     for (byte b = 0; b < paramVector.size(); b++) {
/*      */       
/*  903 */       BitSet bitSet = (BitSet)paramVector.elementAt(b);
/*      */       
/*  905 */       bitSet.growToInclude(paramInt);
/*  906 */       genBitSet(bitSet, b);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void genBitSet(BitSet paramBitSet, int paramInt) {
/*  922 */     println("private static long[] mk_" + getBitsetName(paramInt) + "()");
/*  923 */     println("{");
/*  924 */     this.tabs++;
/*  925 */     int i = paramBitSet.lengthInLongWords();
/*  926 */     if (i < 8) {
/*  927 */       println("long[] data = { " + paramBitSet.toStringOfWords() + "};");
/*      */     }
/*      */     else {
/*      */       
/*  931 */       println("long[] data = new long[" + i + "];");
/*  932 */       long[] arrayOfLong = paramBitSet.toPackedArray(); int j;
/*  933 */       for (j = 0; j < arrayOfLong.length; ) {
/*  934 */         if (j + 1 == arrayOfLong.length || arrayOfLong[j] != arrayOfLong[j + 1]) {
/*      */           
/*  936 */           println("data[" + j + "]=" + arrayOfLong[j] + "L;");
/*  937 */           j++;
/*      */           
/*      */           continue;
/*      */         } 
/*      */         
/*      */         int k;
/*  943 */         for (k = j + 1; k < arrayOfLong.length && arrayOfLong[k] == arrayOfLong[j]; k++);
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  948 */         println("for (int i = " + j + "; i<=" + (k - 1) + "; i++) { data[i]=" + arrayOfLong[j] + "L; }");
/*      */         
/*  950 */         j = k;
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/*  955 */     println("return data;");
/*  956 */     this.tabs--;
/*  957 */     println("}");
/*      */     
/*  959 */     println("public static readonly BitSet " + getBitsetName(paramInt) + " = new BitSet(" + "mk_" + getBitsetName(paramInt) + "()" + ");");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected String getBitsetName(int paramInt) {
/*  969 */     return "tokenSet_" + paramInt + "_";
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void genBlockFinish(CSharpBlockFinishingInfo paramCSharpBlockFinishingInfo, String paramString) {
/*  981 */     if (paramCSharpBlockFinishingInfo.needAnErrorClause && (paramCSharpBlockFinishingInfo.generatedAnIf || paramCSharpBlockFinishingInfo.generatedSwitch)) {
/*      */ 
/*      */       
/*  984 */       if (paramCSharpBlockFinishingInfo.generatedAnIf) {
/*  985 */         println("else");
/*  986 */         println("{");
/*      */       } else {
/*      */         
/*  989 */         println("{");
/*      */       } 
/*  991 */       this.tabs++;
/*  992 */       println(paramString);
/*  993 */       this.tabs--;
/*  994 */       println("}");
/*      */     } 
/*      */     
/*  997 */     if (paramCSharpBlockFinishingInfo.postscript != null) {
/*  998 */       if (paramCSharpBlockFinishingInfo.needAnErrorClause && paramCSharpBlockFinishingInfo.generatedSwitch && !paramCSharpBlockFinishingInfo.generatedAnIf && paramString != null) {
/*      */ 
/*      */ 
/*      */         
/* 1002 */         if (paramString.indexOf("throw") == 0 || paramString.indexOf("goto") == 0) {
/*      */           
/* 1004 */           int i = paramCSharpBlockFinishingInfo.postscript.indexOf("break;") + 6;
/* 1005 */           String str = paramCSharpBlockFinishingInfo.postscript.substring(i);
/* 1006 */           println(str);
/*      */         } else {
/*      */           
/* 1009 */           println(paramCSharpBlockFinishingInfo.postscript);
/*      */         } 
/*      */       } else {
/*      */         
/* 1013 */         println(paramCSharpBlockFinishingInfo.postscript);
/*      */       } 
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void genBlockInitAction(AlternativeBlock paramAlternativeBlock) {
/* 1025 */     if (paramAlternativeBlock.initAction != null) {
/* 1026 */       printAction(processActionForSpecialSymbols(paramAlternativeBlock.initAction, paramAlternativeBlock.getLine(), this.currentRule, (ActionTransInfo)null));
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void genBlockPreamble(AlternativeBlock paramAlternativeBlock) {
/* 1037 */     if (paramAlternativeBlock instanceof RuleBlock) {
/* 1038 */       RuleBlock ruleBlock = (RuleBlock)paramAlternativeBlock;
/* 1039 */       if (ruleBlock.labeledElements != null) {
/* 1040 */         for (byte b = 0; b < ruleBlock.labeledElements.size(); b++) {
/*      */           
/* 1042 */           AlternativeElement alternativeElement = (AlternativeElement)ruleBlock.labeledElements.elementAt(b);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 1049 */           if (alternativeElement instanceof RuleRefElement || (alternativeElement instanceof AlternativeBlock && !(alternativeElement instanceof RuleBlock) && !(alternativeElement instanceof SynPredBlock))) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/* 1056 */             if (!(alternativeElement instanceof RuleRefElement) && ((AlternativeBlock)alternativeElement).not && this.analyzer.subruleCanBeInverted((AlternativeBlock)alternativeElement, this.grammar instanceof LexerGrammar)) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */               
/* 1064 */               println(this.labeledElementType + " " + alternativeElement.getLabel() + " = " + this.labeledElementInit + ";");
/* 1065 */               if (this.grammar.buildAST) {
/* 1066 */                 genASTDeclaration(alternativeElement);
/*      */               }
/*      */             } else {
/*      */               
/* 1070 */               if (this.grammar.buildAST)
/*      */               {
/*      */ 
/*      */                 
/* 1074 */                 genASTDeclaration(alternativeElement);
/*      */               }
/* 1076 */               if (this.grammar instanceof LexerGrammar) {
/* 1077 */                 println("IToken " + alternativeElement.getLabel() + " = null;");
/*      */               }
/* 1079 */               if (this.grammar instanceof TreeWalkerGrammar)
/*      */               {
/*      */                 
/* 1082 */                 println(this.labeledElementType + " " + alternativeElement.getLabel() + " = " + this.labeledElementInit + ";");
/*      */               }
/*      */             }
/*      */           
/*      */           }
/*      */           else {
/*      */             
/* 1089 */             println(this.labeledElementType + " " + alternativeElement.getLabel() + " = " + this.labeledElementInit + ";");
/*      */             
/* 1091 */             if (this.grammar.buildAST)
/*      */             {
/* 1093 */               if (alternativeElement instanceof GrammarAtom && ((GrammarAtom)alternativeElement).getASTNodeType() != null) {
/*      */                 
/* 1095 */                 GrammarAtom grammarAtom = (GrammarAtom)alternativeElement;
/* 1096 */                 genASTDeclaration(alternativeElement, grammarAtom.getASTNodeType());
/*      */               } else {
/*      */                 
/* 1099 */                 genASTDeclaration(alternativeElement);
/*      */               } 
/*      */             }
/*      */           } 
/*      */         } 
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void genBody(LexerGrammar paramLexerGrammar) throws IOException {
/* 1112 */     setupOutput(this.grammar.getClassName());
/*      */     
/* 1114 */     this.genAST = false;
/* 1115 */     this.saveText = true;
/*      */     
/* 1117 */     this.tabs = 0;
/*      */ 
/*      */     
/* 1120 */     genHeader();
/*      */     
/* 1122 */     println(this.behavior.getHeaderAction(""));
/*      */ 
/*      */     
/* 1125 */     if (nameSpace != null)
/* 1126 */       nameSpace.emitDeclarations(this.currentOutput); 
/* 1127 */     this.tabs++;
/*      */ 
/*      */     
/* 1130 */     println("// Generate header specific to lexer CSharp file");
/* 1131 */     println("using System;");
/* 1132 */     println("using Stream                          = System.IO.Stream;");
/* 1133 */     println("using TextReader                      = System.IO.TextReader;");
/* 1134 */     println("using Hashtable                       = System.Collections.Hashtable;");
/* 1135 */     println("using Comparer                        = System.Collections.Comparer;");
/* 1136 */     if (!paramLexerGrammar.caseSensitiveLiterals) {
/*      */       
/* 1138 */       println("using CaseInsensitiveHashCodeProvider = System.Collections.CaseInsensitiveHashCodeProvider;");
/* 1139 */       println("using CaseInsensitiveComparer         = System.Collections.CaseInsensitiveComparer;");
/*      */     } 
/* 1141 */     println("");
/* 1142 */     println("using TokenStreamException            = antlr.TokenStreamException;");
/* 1143 */     println("using TokenStreamIOException          = antlr.TokenStreamIOException;");
/* 1144 */     println("using TokenStreamRecognitionException = antlr.TokenStreamRecognitionException;");
/* 1145 */     println("using CharStreamException             = antlr.CharStreamException;");
/* 1146 */     println("using CharStreamIOException           = antlr.CharStreamIOException;");
/* 1147 */     println("using ANTLRException                  = antlr.ANTLRException;");
/* 1148 */     println("using CharScanner                     = antlr.CharScanner;");
/* 1149 */     println("using InputBuffer                     = antlr.InputBuffer;");
/* 1150 */     println("using ByteBuffer                      = antlr.ByteBuffer;");
/* 1151 */     println("using CharBuffer                      = antlr.CharBuffer;");
/* 1152 */     println("using Token                           = antlr.Token;");
/* 1153 */     println("using IToken                          = antlr.IToken;");
/* 1154 */     println("using CommonToken                     = antlr.CommonToken;");
/* 1155 */     println("using SemanticException               = antlr.SemanticException;");
/* 1156 */     println("using RecognitionException            = antlr.RecognitionException;");
/* 1157 */     println("using NoViableAltForCharException     = antlr.NoViableAltForCharException;");
/* 1158 */     println("using MismatchedCharException         = antlr.MismatchedCharException;");
/* 1159 */     println("using TokenStream                     = antlr.TokenStream;");
/* 1160 */     println("using LexerSharedInputState           = antlr.LexerSharedInputState;");
/* 1161 */     println("using BitSet                          = antlr.collections.impl.BitSet;");
/*      */ 
/*      */     
/* 1164 */     println(this.grammar.preambleAction.getText());
/*      */ 
/*      */     
/* 1167 */     String str = null;
/* 1168 */     if (this.grammar.superClass != null) {
/* 1169 */       str = this.grammar.superClass;
/*      */     } else {
/*      */       
/* 1172 */       str = "antlr." + this.grammar.getSuperClass();
/*      */     } 
/*      */ 
/*      */     
/* 1176 */     if (this.grammar.comment != null)
/*      */     {
/* 1178 */       _println(this.grammar.comment);
/*      */     }
/*      */     
/* 1181 */     Token token1 = (Token)this.grammar.options.get("classHeaderPrefix");
/* 1182 */     if (token1 == null) {
/* 1183 */       print("public ");
/*      */     } else {
/*      */       
/* 1186 */       String str1 = StringUtils.stripFrontBack(token1.getText(), "\"", "\"");
/* 1187 */       if (str1 == null) {
/* 1188 */         print("public ");
/*      */       } else {
/*      */         
/* 1191 */         print(str1 + " ");
/*      */       } 
/*      */     } 
/*      */     
/* 1195 */     print("class " + this.grammar.getClassName() + " : " + str);
/* 1196 */     println(", TokenStream");
/* 1197 */     Token token2 = (Token)this.grammar.options.get("classHeaderSuffix");
/* 1198 */     if (token2 != null) {
/*      */       
/* 1200 */       String str1 = StringUtils.stripFrontBack(token2.getText(), "\"", "\"");
/* 1201 */       if (str1 != null)
/*      */       {
/* 1203 */         print(", " + str1);
/*      */       }
/*      */     } 
/* 1206 */     println(" {");
/* 1207 */     this.tabs++;
/*      */ 
/*      */     
/* 1210 */     genTokenDefinitions(this.grammar.tokenManager);
/*      */ 
/*      */     
/* 1213 */     print(processActionForSpecialSymbols(this.grammar.classMemberAction.getText(), this.grammar.classMemberAction.getLine(), this.currentRule, (ActionTransInfo)null));
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1221 */     println("public " + this.grammar.getClassName() + "(Stream ins) : this(new ByteBuffer(ins))");
/* 1222 */     println("{");
/* 1223 */     println("}");
/* 1224 */     println("");
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1230 */     println("public " + this.grammar.getClassName() + "(TextReader r) : this(new CharBuffer(r))");
/* 1231 */     println("{");
/* 1232 */     println("}");
/* 1233 */     println("");
/*      */     
/* 1235 */     print("public " + this.grammar.getClassName() + "(InputBuffer ib)");
/*      */     
/* 1237 */     if (this.grammar.debuggingOutput) {
/* 1238 */       println(" : this(new LexerSharedInputState(new antlr.debug.DebuggingInputBuffer(ib)))");
/*      */     } else {
/* 1240 */       println(" : this(new LexerSharedInputState(ib))");
/* 1241 */     }  println("{");
/* 1242 */     println("}");
/* 1243 */     println("");
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1248 */     println("public " + this.grammar.getClassName() + "(LexerSharedInputState state) : base(state)");
/* 1249 */     println("{");
/* 1250 */     this.tabs++;
/* 1251 */     println("initialize();");
/* 1252 */     this.tabs--;
/* 1253 */     println("}");
/*      */ 
/*      */     
/* 1256 */     println("private void initialize()");
/* 1257 */     println("{");
/* 1258 */     this.tabs++;
/*      */ 
/*      */ 
/*      */     
/* 1262 */     if (this.grammar.debuggingOutput) {
/* 1263 */       println("ruleNames  = _ruleNames;");
/* 1264 */       println("semPredNames = _semPredNames;");
/* 1265 */       println("setupDebugging();");
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1271 */     println("caseSensitiveLiterals = " + paramLexerGrammar.caseSensitiveLiterals + ";");
/* 1272 */     println("setCaseSensitive(" + paramLexerGrammar.caseSensitive + ");");
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1277 */     if (paramLexerGrammar.caseSensitiveLiterals) {
/* 1278 */       println("literals = new Hashtable(100, (float) 0.4, null, Comparer.Default);");
/*      */     } else {
/* 1280 */       println("literals = new Hashtable(100, (float) 0.4, CaseInsensitiveHashCodeProvider.Default, CaseInsensitiveComparer.Default);");
/* 1281 */     }  Enumeration enumeration = this.grammar.tokenManager.getTokenSymbolKeys();
/* 1282 */     while (enumeration.hasMoreElements()) {
/* 1283 */       String str1 = enumeration.nextElement();
/* 1284 */       if (str1.charAt(0) != '"') {
/*      */         continue;
/*      */       }
/* 1287 */       TokenSymbol tokenSymbol = this.grammar.tokenManager.getTokenSymbol(str1);
/* 1288 */       if (tokenSymbol instanceof StringLiteralSymbol) {
/* 1289 */         StringLiteralSymbol stringLiteralSymbol = (StringLiteralSymbol)tokenSymbol;
/* 1290 */         println("literals.Add(" + stringLiteralSymbol.getId() + ", " + stringLiteralSymbol.getTokenType() + ");");
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/* 1295 */     this.tabs--;
/* 1296 */     println("}");
/*      */ 
/*      */     
/* 1299 */     if (this.grammar.debuggingOutput) {
/* 1300 */       println("private static readonly string[] _ruleNames = new string[] {");
/*      */       
/* 1302 */       Enumeration enumeration2 = this.grammar.rules.elements();
/* 1303 */       boolean bool = false;
/* 1304 */       while (enumeration2.hasMoreElements()) {
/* 1305 */         GrammarSymbol grammarSymbol = enumeration2.nextElement();
/* 1306 */         if (grammarSymbol instanceof RuleSymbol)
/* 1307 */           println("  \"" + ((RuleSymbol)grammarSymbol).getId() + "\","); 
/*      */       } 
/* 1309 */       println("};");
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1315 */     genNextToken();
/*      */ 
/*      */     
/* 1318 */     Enumeration enumeration1 = this.grammar.rules.elements();
/* 1319 */     byte b = 0;
/* 1320 */     while (enumeration1.hasMoreElements()) {
/* 1321 */       RuleSymbol ruleSymbol = enumeration1.nextElement();
/*      */       
/* 1323 */       if (!ruleSymbol.getId().equals("mnextToken")) {
/* 1324 */         genRule(ruleSymbol, false, b++, this.grammar.tokenManager);
/*      */       }
/* 1326 */       exitIfError();
/*      */     } 
/*      */ 
/*      */     
/* 1330 */     if (this.grammar.debuggingOutput) {
/* 1331 */       genSemPredMap();
/*      */     }
/*      */     
/* 1334 */     genBitsets(this.bitsetsUsed, ((LexerGrammar)this.grammar).charVocabulary.size());
/*      */     
/* 1336 */     println("");
/* 1337 */     this.tabs--;
/* 1338 */     println("}");
/*      */     
/* 1340 */     this.tabs--;
/*      */     
/* 1342 */     if (nameSpace != null) {
/* 1343 */       nameSpace.emitClosures(this.currentOutput);
/*      */     }
/*      */     
/* 1346 */     this.currentOutput.close();
/* 1347 */     this.currentOutput = null;
/*      */   }
/*      */   
/*      */   public void genInitFactory(Grammar paramGrammar) {
/* 1351 */     if (paramGrammar.buildAST) {
/*      */ 
/*      */ 
/*      */       
/* 1355 */       println("static public void initializeASTFactory( ASTFactory factory )");
/* 1356 */       println("{");
/* 1357 */       this.tabs++;
/*      */       
/* 1359 */       println("factory.setMaxNodeType(" + paramGrammar.tokenManager.maxTokenType() + ");");
/*      */ 
/*      */ 
/*      */       
/* 1363 */       Vector vector = paramGrammar.tokenManager.getVocabulary();
/* 1364 */       for (byte b = 0; b < vector.size(); b++) {
/* 1365 */         String str = (String)vector.elementAt(b);
/* 1366 */         if (str != null) {
/* 1367 */           TokenSymbol tokenSymbol = paramGrammar.tokenManager.getTokenSymbol(str);
/* 1368 */           if (tokenSymbol != null && tokenSymbol.getASTNodeType() != null) {
/* 1369 */             println("factory.setTokenTypeASTNodeType(" + str + ", \"" + tokenSymbol.getASTNodeType() + "\");");
/*      */           }
/*      */         } 
/*      */       } 
/*      */       
/* 1374 */       this.tabs--;
/* 1375 */       println("}");
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void genBody(ParserGrammar paramParserGrammar) throws IOException {
/* 1383 */     setupOutput(this.grammar.getClassName());
/*      */     
/* 1385 */     this.genAST = this.grammar.buildAST;
/*      */     
/* 1387 */     this.tabs = 0;
/*      */ 
/*      */     
/* 1390 */     genHeader();
/*      */     
/* 1392 */     println(this.behavior.getHeaderAction(""));
/*      */ 
/*      */     
/* 1395 */     if (nameSpace != null)
/* 1396 */       nameSpace.emitDeclarations(this.currentOutput); 
/* 1397 */     this.tabs++;
/*      */ 
/*      */     
/* 1400 */     println("// Generate the header common to all output files.");
/* 1401 */     println("using System;");
/* 1402 */     println("");
/* 1403 */     println("using TokenBuffer              = antlr.TokenBuffer;");
/* 1404 */     println("using TokenStreamException     = antlr.TokenStreamException;");
/* 1405 */     println("using TokenStreamIOException   = antlr.TokenStreamIOException;");
/* 1406 */     println("using ANTLRException           = antlr.ANTLRException;");
/*      */     
/* 1408 */     String str1 = this.grammar.getSuperClass();
/* 1409 */     String[] arrayOfString = split(str1, ".");
/* 1410 */     println("using " + arrayOfString[arrayOfString.length - 1] + " = antlr." + str1 + ";");
/*      */     
/* 1412 */     println("using Token                    = antlr.Token;");
/* 1413 */     println("using IToken                   = antlr.IToken;");
/* 1414 */     println("using TokenStream              = antlr.TokenStream;");
/* 1415 */     println("using RecognitionException     = antlr.RecognitionException;");
/* 1416 */     println("using NoViableAltException     = antlr.NoViableAltException;");
/* 1417 */     println("using MismatchedTokenException = antlr.MismatchedTokenException;");
/* 1418 */     println("using SemanticException        = antlr.SemanticException;");
/* 1419 */     println("using ParserSharedInputState   = antlr.ParserSharedInputState;");
/* 1420 */     println("using BitSet                   = antlr.collections.impl.BitSet;");
/* 1421 */     if (this.genAST) {
/* 1422 */       println("using AST                      = antlr.collections.AST;");
/* 1423 */       println("using ASTPair                  = antlr.ASTPair;");
/* 1424 */       println("using ASTFactory               = antlr.ASTFactory;");
/* 1425 */       println("using ASTArray                 = antlr.collections.impl.ASTArray;");
/*      */     } 
/*      */ 
/*      */     
/* 1429 */     println(this.grammar.preambleAction.getText());
/*      */ 
/*      */     
/* 1432 */     String str2 = null;
/* 1433 */     if (this.grammar.superClass != null) {
/* 1434 */       str2 = this.grammar.superClass;
/*      */     } else {
/* 1436 */       str2 = "antlr." + this.grammar.getSuperClass();
/*      */     } 
/*      */     
/* 1439 */     if (this.grammar.comment != null) {
/* 1440 */       _println(this.grammar.comment);
/*      */     }
/*      */     
/* 1443 */     Token token1 = (Token)this.grammar.options.get("classHeaderPrefix");
/* 1444 */     if (token1 == null) {
/* 1445 */       print("public ");
/*      */     } else {
/*      */       
/* 1448 */       String str = StringUtils.stripFrontBack(token1.getText(), "\"", "\"");
/* 1449 */       if (str == null) {
/* 1450 */         print("public ");
/*      */       } else {
/*      */         
/* 1453 */         print(str + " ");
/*      */       } 
/*      */     } 
/*      */     
/* 1457 */     println("class " + this.grammar.getClassName() + " : " + str2);
/*      */     
/* 1459 */     Token token2 = (Token)this.grammar.options.get("classHeaderSuffix");
/* 1460 */     if (token2 != null) {
/* 1461 */       String str = StringUtils.stripFrontBack(token2.getText(), "\"", "\"");
/* 1462 */       if (str != null)
/* 1463 */         print("              , " + str); 
/*      */     } 
/* 1465 */     println("{");
/* 1466 */     this.tabs++;
/*      */ 
/*      */     
/* 1469 */     genTokenDefinitions(this.grammar.tokenManager);
/*      */ 
/*      */ 
/*      */     
/* 1473 */     if (this.grammar.debuggingOutput) {
/* 1474 */       println("private static readonly string[] _ruleNames = new string[] {");
/* 1475 */       this.tabs++;
/*      */       
/* 1477 */       Enumeration enumeration1 = this.grammar.rules.elements();
/* 1478 */       boolean bool = false;
/* 1479 */       while (enumeration1.hasMoreElements()) {
/* 1480 */         GrammarSymbol grammarSymbol = enumeration1.nextElement();
/* 1481 */         if (grammarSymbol instanceof RuleSymbol)
/* 1482 */           println("  \"" + ((RuleSymbol)grammarSymbol).getId() + "\","); 
/*      */       } 
/* 1484 */       this.tabs--;
/* 1485 */       println("};");
/*      */     } 
/*      */ 
/*      */     
/* 1489 */     print(processActionForSpecialSymbols(this.grammar.classMemberAction.getText(), this.grammar.classMemberAction.getLine(), this.currentRule, (ActionTransInfo)null));
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1494 */     println("");
/* 1495 */     println("protected void initialize()");
/* 1496 */     println("{");
/* 1497 */     this.tabs++;
/* 1498 */     println("tokenNames = tokenNames_;");
/*      */     
/* 1500 */     if (this.grammar.buildAST) {
/* 1501 */       println("initializeFactory();");
/*      */     }
/*      */ 
/*      */     
/* 1505 */     if (this.grammar.debuggingOutput) {
/* 1506 */       println("ruleNames  = _ruleNames;");
/* 1507 */       println("semPredNames = _semPredNames;");
/* 1508 */       println("setupDebugging(tokenBuf);");
/*      */     } 
/* 1510 */     this.tabs--;
/* 1511 */     println("}");
/* 1512 */     println("");
/*      */     
/* 1514 */     println("");
/* 1515 */     println("protected " + this.grammar.getClassName() + "(TokenBuffer tokenBuf, int k) : base(tokenBuf, k)");
/* 1516 */     println("{");
/* 1517 */     this.tabs++;
/* 1518 */     println("initialize();");
/* 1519 */     this.tabs--;
/* 1520 */     println("}");
/* 1521 */     println("");
/*      */     
/* 1523 */     println("public " + this.grammar.getClassName() + "(TokenBuffer tokenBuf) : this(tokenBuf," + this.grammar.maxk + ")");
/* 1524 */     println("{");
/* 1525 */     println("}");
/* 1526 */     println("");
/*      */ 
/*      */     
/* 1529 */     println("protected " + this.grammar.getClassName() + "(TokenStream lexer, int k) : base(lexer,k)");
/* 1530 */     println("{");
/* 1531 */     this.tabs++;
/* 1532 */     println("initialize();");
/* 1533 */     this.tabs--;
/* 1534 */     println("}");
/* 1535 */     println("");
/*      */     
/* 1537 */     println("public " + this.grammar.getClassName() + "(TokenStream lexer) : this(lexer," + this.grammar.maxk + ")");
/* 1538 */     println("{");
/* 1539 */     println("}");
/* 1540 */     println("");
/*      */     
/* 1542 */     println("public " + this.grammar.getClassName() + "(ParserSharedInputState state) : base(state," + this.grammar.maxk + ")");
/* 1543 */     println("{");
/* 1544 */     this.tabs++;
/* 1545 */     println("initialize();");
/* 1546 */     this.tabs--;
/* 1547 */     println("}");
/* 1548 */     println("");
/*      */     
/* 1550 */     this.astTypes = new Vector(100);
/*      */ 
/*      */     
/* 1553 */     Enumeration enumeration = this.grammar.rules.elements();
/* 1554 */     byte b = 0;
/* 1555 */     while (enumeration.hasMoreElements()) {
/* 1556 */       GrammarSymbol grammarSymbol = enumeration.nextElement();
/* 1557 */       if (grammarSymbol instanceof RuleSymbol) {
/* 1558 */         RuleSymbol ruleSymbol = (RuleSymbol)grammarSymbol;
/* 1559 */         genRule(ruleSymbol, (ruleSymbol.references.size() == 0), b++, this.grammar.tokenManager);
/*      */       } 
/* 1561 */       exitIfError();
/*      */     } 
/* 1563 */     if (this.usingCustomAST) {
/*      */ 
/*      */ 
/*      */       
/* 1567 */       println("public new " + this.labeledElementASTType + " getAST()");
/* 1568 */       println("{");
/* 1569 */       this.tabs++;
/* 1570 */       println("return (" + this.labeledElementASTType + ") returnAST;");
/* 1571 */       this.tabs--;
/* 1572 */       println("}");
/* 1573 */       println("");
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 1578 */     println("private void initializeFactory()");
/* 1579 */     println("{");
/* 1580 */     this.tabs++;
/* 1581 */     if (this.grammar.buildAST) {
/* 1582 */       println("if (astFactory == null)");
/* 1583 */       println("{");
/* 1584 */       this.tabs++;
/* 1585 */       if (this.usingCustomAST) {
/*      */         
/* 1587 */         println("astFactory = new ASTFactory(\"" + this.labeledElementASTType + "\");");
/*      */       } else {
/*      */         
/* 1590 */         println("astFactory = new ASTFactory();");
/* 1591 */       }  this.tabs--;
/* 1592 */       println("}");
/* 1593 */       println("initializeASTFactory( astFactory );");
/*      */     } 
/* 1595 */     this.tabs--;
/* 1596 */     println("}");
/* 1597 */     genInitFactory(paramParserGrammar);
/*      */ 
/*      */     
/* 1600 */     genTokenStrings();
/*      */ 
/*      */     
/* 1603 */     genBitsets(this.bitsetsUsed, this.grammar.tokenManager.maxTokenType());
/*      */ 
/*      */     
/* 1606 */     if (this.grammar.debuggingOutput) {
/* 1607 */       genSemPredMap();
/*      */     }
/*      */     
/* 1610 */     println("");
/* 1611 */     this.tabs--;
/* 1612 */     println("}");
/*      */     
/* 1614 */     this.tabs--;
/*      */     
/* 1616 */     if (nameSpace != null) {
/* 1617 */       nameSpace.emitClosures(this.currentOutput);
/*      */     }
/*      */     
/* 1620 */     this.currentOutput.close();
/* 1621 */     this.currentOutput = null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void genBody(TreeWalkerGrammar paramTreeWalkerGrammar) throws IOException {
/* 1628 */     setupOutput(this.grammar.getClassName());
/*      */     
/* 1630 */     this.genAST = this.grammar.buildAST;
/* 1631 */     this.tabs = 0;
/*      */ 
/*      */     
/* 1634 */     genHeader();
/*      */     
/* 1636 */     println(this.behavior.getHeaderAction(""));
/*      */ 
/*      */     
/* 1639 */     if (nameSpace != null)
/* 1640 */       nameSpace.emitDeclarations(this.currentOutput); 
/* 1641 */     this.tabs++;
/*      */ 
/*      */     
/* 1644 */     println("// Generate header specific to the tree-parser CSharp file");
/* 1645 */     println("using System;");
/* 1646 */     println("");
/* 1647 */     println("using " + this.grammar.getSuperClass() + " = antlr." + this.grammar.getSuperClass() + ";");
/* 1648 */     println("using Token                    = antlr.Token;");
/* 1649 */     println("using IToken                   = antlr.IToken;");
/* 1650 */     println("using AST                      = antlr.collections.AST;");
/* 1651 */     println("using RecognitionException     = antlr.RecognitionException;");
/* 1652 */     println("using ANTLRException           = antlr.ANTLRException;");
/* 1653 */     println("using NoViableAltException     = antlr.NoViableAltException;");
/* 1654 */     println("using MismatchedTokenException = antlr.MismatchedTokenException;");
/* 1655 */     println("using SemanticException        = antlr.SemanticException;");
/* 1656 */     println("using BitSet                   = antlr.collections.impl.BitSet;");
/* 1657 */     println("using ASTPair                  = antlr.ASTPair;");
/* 1658 */     println("using ASTFactory               = antlr.ASTFactory;");
/* 1659 */     println("using ASTArray                 = antlr.collections.impl.ASTArray;");
/*      */ 
/*      */     
/* 1662 */     println(this.grammar.preambleAction.getText());
/*      */ 
/*      */     
/* 1665 */     String str1 = null;
/* 1666 */     if (this.grammar.superClass != null) {
/* 1667 */       str1 = this.grammar.superClass;
/*      */     } else {
/*      */       
/* 1670 */       str1 = "antlr." + this.grammar.getSuperClass();
/*      */     } 
/* 1672 */     println("");
/*      */ 
/*      */     
/* 1675 */     if (this.grammar.comment != null) {
/* 1676 */       _println(this.grammar.comment);
/*      */     }
/*      */     
/* 1679 */     Token token1 = (Token)this.grammar.options.get("classHeaderPrefix");
/* 1680 */     if (token1 == null) {
/* 1681 */       print("public ");
/*      */     } else {
/*      */       
/* 1684 */       String str = StringUtils.stripFrontBack(token1.getText(), "\"", "\"");
/* 1685 */       if (str == null) {
/* 1686 */         print("public ");
/*      */       } else {
/*      */         
/* 1689 */         print(str + " ");
/*      */       } 
/*      */     } 
/*      */     
/* 1693 */     println("class " + this.grammar.getClassName() + " : " + str1);
/* 1694 */     Token token2 = (Token)this.grammar.options.get("classHeaderSuffix");
/* 1695 */     if (token2 != null) {
/* 1696 */       String str = StringUtils.stripFrontBack(token2.getText(), "\"", "\"");
/* 1697 */       if (str != null) {
/* 1698 */         print("              , " + str);
/*      */       }
/*      */     } 
/* 1701 */     println("{");
/* 1702 */     this.tabs++;
/*      */ 
/*      */     
/* 1705 */     genTokenDefinitions(this.grammar.tokenManager);
/*      */ 
/*      */     
/* 1708 */     print(processActionForSpecialSymbols(this.grammar.classMemberAction.getText(), this.grammar.classMemberAction.getLine(), this.currentRule, (ActionTransInfo)null));
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1713 */     println("public " + this.grammar.getClassName() + "()");
/* 1714 */     println("{");
/* 1715 */     this.tabs++;
/* 1716 */     println("tokenNames = tokenNames_;");
/* 1717 */     this.tabs--;
/* 1718 */     println("}");
/* 1719 */     println("");
/*      */     
/* 1721 */     this.astTypes = new Vector();
/*      */     
/* 1723 */     Enumeration enumeration = this.grammar.rules.elements();
/* 1724 */     byte b = 0;
/* 1725 */     String str2 = "";
/* 1726 */     while (enumeration.hasMoreElements()) {
/* 1727 */       GrammarSymbol grammarSymbol = enumeration.nextElement();
/* 1728 */       if (grammarSymbol instanceof RuleSymbol) {
/* 1729 */         RuleSymbol ruleSymbol = (RuleSymbol)grammarSymbol;
/* 1730 */         genRule(ruleSymbol, (ruleSymbol.references.size() == 0), b++, this.grammar.tokenManager);
/*      */       } 
/* 1732 */       exitIfError();
/*      */     } 
/*      */     
/* 1735 */     if (this.usingCustomAST) {
/*      */ 
/*      */ 
/*      */       
/* 1739 */       println("public new " + this.labeledElementASTType + " getAST()");
/* 1740 */       println("{");
/* 1741 */       this.tabs++;
/* 1742 */       println("return (" + this.labeledElementASTType + ") returnAST;");
/* 1743 */       this.tabs--;
/* 1744 */       println("}");
/* 1745 */       println("");
/*      */     } 
/*      */ 
/*      */     
/* 1749 */     genInitFactory(this.grammar);
/*      */ 
/*      */     
/* 1752 */     genTokenStrings();
/*      */ 
/*      */     
/* 1755 */     genBitsets(this.bitsetsUsed, this.grammar.tokenManager.maxTokenType());
/*      */ 
/*      */     
/* 1758 */     this.tabs--;
/* 1759 */     println("}");
/* 1760 */     println("");
/*      */     
/* 1762 */     this.tabs--;
/*      */     
/* 1764 */     if (nameSpace != null) {
/* 1765 */       nameSpace.emitClosures(this.currentOutput);
/*      */     }
/*      */     
/* 1768 */     this.currentOutput.close();
/* 1769 */     this.currentOutput = null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void genCases(BitSet paramBitSet) {
/* 1776 */     if (this.DEBUG_CODE_GENERATOR) System.out.println("genCases(" + paramBitSet + ")");
/*      */ 
/*      */     
/* 1779 */     int[] arrayOfInt = paramBitSet.toArray();
/*      */     
/* 1781 */     byte b1 = (this.grammar instanceof LexerGrammar) ? 4 : 1;
/* 1782 */     byte b2 = 1;
/* 1783 */     boolean bool = true;
/* 1784 */     for (byte b3 = 0; b3 < arrayOfInt.length; b3++) {
/* 1785 */       if (b2 == 1) {
/* 1786 */         print("");
/*      */       } else {
/* 1788 */         _print("  ");
/*      */       } 
/* 1790 */       _print("case " + getValueString(arrayOfInt[b3]) + ":");
/* 1791 */       if (b2 == b1) {
/* 1792 */         _println("");
/* 1793 */         bool = true;
/* 1794 */         b2 = 1;
/*      */       } else {
/*      */         
/* 1797 */         b2++;
/* 1798 */         bool = false;
/*      */       } 
/*      */     } 
/* 1801 */     if (!bool) {
/* 1802 */       _println("");
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public CSharpBlockFinishingInfo genCommonBlock(AlternativeBlock paramAlternativeBlock, boolean paramBoolean) {
/*      */     // Byte code:
/*      */     //   0: iconst_0
/*      */     //   1: istore_3
/*      */     //   2: iconst_0
/*      */     //   3: istore #4
/*      */     //   5: iconst_0
/*      */     //   6: istore #5
/*      */     //   8: new antlr/CSharpBlockFinishingInfo
/*      */     //   11: dup
/*      */     //   12: invokespecial <init> : ()V
/*      */     //   15: astore #6
/*      */     //   17: aload_0
/*      */     //   18: getfield DEBUG_CODE_GENERATOR : Z
/*      */     //   21: ifeq -> 55
/*      */     //   24: getstatic java/lang/System.out : Ljava/io/PrintStream;
/*      */     //   27: new java/lang/StringBuffer
/*      */     //   30: dup
/*      */     //   31: invokespecial <init> : ()V
/*      */     //   34: ldc_w 'genCommonBlock('
/*      */     //   37: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuffer;
/*      */     //   40: aload_1
/*      */     //   41: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuffer;
/*      */     //   44: ldc ')'
/*      */     //   46: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuffer;
/*      */     //   49: invokevirtual toString : ()Ljava/lang/String;
/*      */     //   52: invokevirtual println : (Ljava/lang/String;)V
/*      */     //   55: aload_0
/*      */     //   56: getfield genAST : Z
/*      */     //   59: istore #7
/*      */     //   61: aload_0
/*      */     //   62: aload_0
/*      */     //   63: getfield genAST : Z
/*      */     //   66: ifeq -> 80
/*      */     //   69: aload_1
/*      */     //   70: invokevirtual getAutoGen : ()Z
/*      */     //   73: ifeq -> 80
/*      */     //   76: iconst_1
/*      */     //   77: goto -> 81
/*      */     //   80: iconst_0
/*      */     //   81: putfield genAST : Z
/*      */     //   84: aload_0
/*      */     //   85: getfield saveText : Z
/*      */     //   88: istore #8
/*      */     //   90: aload_0
/*      */     //   91: aload_0
/*      */     //   92: getfield saveText : Z
/*      */     //   95: ifeq -> 109
/*      */     //   98: aload_1
/*      */     //   99: invokevirtual getAutoGen : ()Z
/*      */     //   102: ifeq -> 109
/*      */     //   105: iconst_1
/*      */     //   106: goto -> 110
/*      */     //   109: iconst_0
/*      */     //   110: putfield saveText : Z
/*      */     //   113: aload_1
/*      */     //   114: getfield not : Z
/*      */     //   117: ifeq -> 326
/*      */     //   120: aload_0
/*      */     //   121: getfield analyzer : Lantlr/LLkGrammarAnalyzer;
/*      */     //   124: aload_1
/*      */     //   125: aload_0
/*      */     //   126: getfield grammar : Lantlr/Grammar;
/*      */     //   129: instanceof antlr/LexerGrammar
/*      */     //   132: invokeinterface subruleCanBeInverted : (Lantlr/AlternativeBlock;Z)Z
/*      */     //   137: ifeq -> 326
/*      */     //   140: aload_0
/*      */     //   141: getfield DEBUG_CODE_GENERATOR : Z
/*      */     //   144: ifeq -> 156
/*      */     //   147: getstatic java/lang/System.out : Ljava/io/PrintStream;
/*      */     //   150: ldc_w 'special case: ~(subrule)'
/*      */     //   153: invokevirtual println : (Ljava/lang/String;)V
/*      */     //   156: aload_0
/*      */     //   157: getfield analyzer : Lantlr/LLkGrammarAnalyzer;
/*      */     //   160: iconst_1
/*      */     //   161: aload_1
/*      */     //   162: invokeinterface look : (ILantlr/AlternativeBlock;)Lantlr/Lookahead;
/*      */     //   167: astore #9
/*      */     //   169: aload_1
/*      */     //   170: invokevirtual getLabel : ()Ljava/lang/String;
/*      */     //   173: ifnull -> 221
/*      */     //   176: aload_0
/*      */     //   177: getfield syntacticPredLevel : I
/*      */     //   180: ifne -> 221
/*      */     //   183: aload_0
/*      */     //   184: new java/lang/StringBuffer
/*      */     //   187: dup
/*      */     //   188: invokespecial <init> : ()V
/*      */     //   191: aload_1
/*      */     //   192: invokevirtual getLabel : ()Ljava/lang/String;
/*      */     //   195: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuffer;
/*      */     //   198: ldc ' = '
/*      */     //   200: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuffer;
/*      */     //   203: aload_0
/*      */     //   204: getfield lt1Value : Ljava/lang/String;
/*      */     //   207: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuffer;
/*      */     //   210: ldc ';'
/*      */     //   212: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuffer;
/*      */     //   215: invokevirtual toString : ()Ljava/lang/String;
/*      */     //   218: invokevirtual println : (Ljava/lang/String;)V
/*      */     //   221: aload_0
/*      */     //   222: aload_1
/*      */     //   223: invokespecial genElementAST : (Lantlr/AlternativeElement;)V
/*      */     //   226: ldc_w ''
/*      */     //   229: astore #10
/*      */     //   231: aload_0
/*      */     //   232: getfield grammar : Lantlr/Grammar;
/*      */     //   235: instanceof antlr/TreeWalkerGrammar
/*      */     //   238: ifeq -> 261
/*      */     //   241: aload_0
/*      */     //   242: getfield usingCustomAST : Z
/*      */     //   245: ifeq -> 256
/*      */     //   248: ldc_w '(AST)_t,'
/*      */     //   251: astore #10
/*      */     //   253: goto -> 261
/*      */     //   256: ldc_w '_t,'
/*      */     //   259: astore #10
/*      */     //   261: aload_0
/*      */     //   262: new java/lang/StringBuffer
/*      */     //   265: dup
/*      */     //   266: invokespecial <init> : ()V
/*      */     //   269: ldc_w 'match('
/*      */     //   272: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuffer;
/*      */     //   275: aload #10
/*      */     //   277: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuffer;
/*      */     //   280: aload_0
/*      */     //   281: aload_0
/*      */     //   282: aload #9
/*      */     //   284: getfield fset : Lantlr/collections/impl/BitSet;
/*      */     //   287: invokevirtual markBitsetForGen : (Lantlr/collections/impl/BitSet;)I
/*      */     //   290: invokevirtual getBitsetName : (I)Ljava/lang/String;
/*      */     //   293: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuffer;
/*      */     //   296: ldc ');'
/*      */     //   298: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuffer;
/*      */     //   301: invokevirtual toString : ()Ljava/lang/String;
/*      */     //   304: invokevirtual println : (Ljava/lang/String;)V
/*      */     //   307: aload_0
/*      */     //   308: getfield grammar : Lantlr/Grammar;
/*      */     //   311: instanceof antlr/TreeWalkerGrammar
/*      */     //   314: ifeq -> 323
/*      */     //   317: aload_0
/*      */     //   318: ldc '_t = _t.getNextSibling();'
/*      */     //   320: invokevirtual println : (Ljava/lang/String;)V
/*      */     //   323: aload #6
/*      */     //   325: areturn
/*      */     //   326: aload_1
/*      */     //   327: invokevirtual getAlternatives : ()Lantlr/collections/impl/Vector;
/*      */     //   330: invokevirtual size : ()I
/*      */     //   333: iconst_1
/*      */     //   334: if_icmpne -> 426
/*      */     //   337: aload_1
/*      */     //   338: iconst_0
/*      */     //   339: invokevirtual getAlternativeAt : (I)Lantlr/Alternative;
/*      */     //   342: astore #9
/*      */     //   344: aload #9
/*      */     //   346: getfield synPred : Lantlr/SynPredBlock;
/*      */     //   349: ifnull -> 391
/*      */     //   352: aload_0
/*      */     //   353: getfield antlrTool : Lantlr/Tool;
/*      */     //   356: ldc_w 'Syntactic predicate superfluous for single alternative'
/*      */     //   359: aload_0
/*      */     //   360: getfield grammar : Lantlr/Grammar;
/*      */     //   363: invokevirtual getFilename : ()Ljava/lang/String;
/*      */     //   366: aload_1
/*      */     //   367: iconst_0
/*      */     //   368: invokevirtual getAlternativeAt : (I)Lantlr/Alternative;
/*      */     //   371: getfield synPred : Lantlr/SynPredBlock;
/*      */     //   374: invokevirtual getLine : ()I
/*      */     //   377: aload_1
/*      */     //   378: iconst_0
/*      */     //   379: invokevirtual getAlternativeAt : (I)Lantlr/Alternative;
/*      */     //   382: getfield synPred : Lantlr/SynPredBlock;
/*      */     //   385: invokevirtual getColumn : ()I
/*      */     //   388: invokevirtual warning : (Ljava/lang/String;Ljava/lang/String;II)V
/*      */     //   391: iload_2
/*      */     //   392: ifeq -> 426
/*      */     //   395: aload #9
/*      */     //   397: getfield semPred : Ljava/lang/String;
/*      */     //   400: ifnull -> 416
/*      */     //   403: aload_0
/*      */     //   404: aload #9
/*      */     //   406: getfield semPred : Ljava/lang/String;
/*      */     //   409: aload_1
/*      */     //   410: getfield line : I
/*      */     //   413: invokevirtual genSemPred : (Ljava/lang/String;I)V
/*      */     //   416: aload_0
/*      */     //   417: aload #9
/*      */     //   419: aload_1
/*      */     //   420: invokevirtual genAlt : (Lantlr/Alternative;Lantlr/AlternativeBlock;)V
/*      */     //   423: aload #6
/*      */     //   425: areturn
/*      */     //   426: iconst_0
/*      */     //   427: istore #9
/*      */     //   429: iconst_0
/*      */     //   430: istore #10
/*      */     //   432: iload #10
/*      */     //   434: aload_1
/*      */     //   435: invokevirtual getAlternatives : ()Lantlr/collections/impl/Vector;
/*      */     //   438: invokevirtual size : ()I
/*      */     //   441: if_icmpge -> 469
/*      */     //   444: aload_1
/*      */     //   445: iload #10
/*      */     //   447: invokevirtual getAlternativeAt : (I)Lantlr/Alternative;
/*      */     //   450: astore #11
/*      */     //   452: aload #11
/*      */     //   454: invokestatic suitableForCaseExpression : (Lantlr/Alternative;)Z
/*      */     //   457: ifeq -> 463
/*      */     //   460: iinc #9, 1
/*      */     //   463: iinc #10, 1
/*      */     //   466: goto -> 432
/*      */     //   469: iload #9
/*      */     //   471: aload_0
/*      */     //   472: getfield makeSwitchThreshold : I
/*      */     //   475: if_icmplt -> 788
/*      */     //   478: aload_0
/*      */     //   479: iconst_1
/*      */     //   480: invokespecial lookaheadString : (I)Ljava/lang/String;
/*      */     //   483: astore #10
/*      */     //   485: iconst_1
/*      */     //   486: istore #4
/*      */     //   488: aload_0
/*      */     //   489: getfield grammar : Lantlr/Grammar;
/*      */     //   492: instanceof antlr/TreeWalkerGrammar
/*      */     //   495: ifeq -> 532
/*      */     //   498: aload_0
/*      */     //   499: ldc_w 'if (null == _t)'
/*      */     //   502: invokevirtual println : (Ljava/lang/String;)V
/*      */     //   505: aload_0
/*      */     //   506: dup
/*      */     //   507: getfield tabs : I
/*      */     //   510: iconst_1
/*      */     //   511: iadd
/*      */     //   512: putfield tabs : I
/*      */     //   515: aload_0
/*      */     //   516: ldc_w '_t = ASTNULL;'
/*      */     //   519: invokevirtual println : (Ljava/lang/String;)V
/*      */     //   522: aload_0
/*      */     //   523: dup
/*      */     //   524: getfield tabs : I
/*      */     //   527: iconst_1
/*      */     //   528: isub
/*      */     //   529: putfield tabs : I
/*      */     //   532: aload_0
/*      */     //   533: new java/lang/StringBuffer
/*      */     //   536: dup
/*      */     //   537: invokespecial <init> : ()V
/*      */     //   540: ldc_w 'switch ( '
/*      */     //   543: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuffer;
/*      */     //   546: aload #10
/*      */     //   548: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuffer;
/*      */     //   551: ldc_w ' )'
/*      */     //   554: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuffer;
/*      */     //   557: invokevirtual toString : ()Ljava/lang/String;
/*      */     //   560: invokevirtual println : (Ljava/lang/String;)V
/*      */     //   563: aload_0
/*      */     //   564: ldc '{'
/*      */     //   566: invokevirtual println : (Ljava/lang/String;)V
/*      */     //   569: aload_0
/*      */     //   570: dup
/*      */     //   571: getfield blockNestingLevel : I
/*      */     //   574: iconst_1
/*      */     //   575: iadd
/*      */     //   576: putfield blockNestingLevel : I
/*      */     //   579: iconst_0
/*      */     //   580: istore #11
/*      */     //   582: iload #11
/*      */     //   584: aload_1
/*      */     //   585: getfield alternatives : Lantlr/collections/impl/Vector;
/*      */     //   588: invokevirtual size : ()I
/*      */     //   591: if_icmpge -> 771
/*      */     //   594: aload_1
/*      */     //   595: iload #11
/*      */     //   597: invokevirtual getAlternativeAt : (I)Lantlr/Alternative;
/*      */     //   600: astore #12
/*      */     //   602: aload #12
/*      */     //   604: invokestatic suitableForCaseExpression : (Lantlr/Alternative;)Z
/*      */     //   607: ifne -> 613
/*      */     //   610: goto -> 765
/*      */     //   613: aload #12
/*      */     //   615: getfield cache : [Lantlr/Lookahead;
/*      */     //   618: iconst_1
/*      */     //   619: aaload
/*      */     //   620: astore #13
/*      */     //   622: aload #13
/*      */     //   624: getfield fset : Lantlr/collections/impl/BitSet;
/*      */     //   627: invokevirtual degree : ()I
/*      */     //   630: ifne -> 677
/*      */     //   633: aload #13
/*      */     //   635: invokevirtual containsEpsilon : ()Z
/*      */     //   638: ifne -> 677
/*      */     //   641: aload_0
/*      */     //   642: getfield antlrTool : Lantlr/Tool;
/*      */     //   645: ldc_w 'Alternate omitted due to empty prediction set'
/*      */     //   648: aload_0
/*      */     //   649: getfield grammar : Lantlr/Grammar;
/*      */     //   652: invokevirtual getFilename : ()Ljava/lang/String;
/*      */     //   655: aload #12
/*      */     //   657: getfield head : Lantlr/AlternativeElement;
/*      */     //   660: invokevirtual getLine : ()I
/*      */     //   663: aload #12
/*      */     //   665: getfield head : Lantlr/AlternativeElement;
/*      */     //   668: invokevirtual getColumn : ()I
/*      */     //   671: invokevirtual warning : (Ljava/lang/String;Ljava/lang/String;II)V
/*      */     //   674: goto -> 765
/*      */     //   677: aload_0
/*      */     //   678: aload #13
/*      */     //   680: getfield fset : Lantlr/collections/impl/BitSet;
/*      */     //   683: invokevirtual genCases : (Lantlr/collections/impl/BitSet;)V
/*      */     //   686: aload_0
/*      */     //   687: ldc '{'
/*      */     //   689: invokevirtual println : (Ljava/lang/String;)V
/*      */     //   692: aload_0
/*      */     //   693: dup
/*      */     //   694: getfield tabs : I
/*      */     //   697: iconst_1
/*      */     //   698: iadd
/*      */     //   699: putfield tabs : I
/*      */     //   702: aload_0
/*      */     //   703: dup
/*      */     //   704: getfield blockNestingLevel : I
/*      */     //   707: iconst_1
/*      */     //   708: iadd
/*      */     //   709: putfield blockNestingLevel : I
/*      */     //   712: aload_0
/*      */     //   713: aload #12
/*      */     //   715: aload_1
/*      */     //   716: invokevirtual genAlt : (Lantlr/Alternative;Lantlr/AlternativeBlock;)V
/*      */     //   719: aload_0
/*      */     //   720: ldc_w 'break;'
/*      */     //   723: invokevirtual println : (Ljava/lang/String;)V
/*      */     //   726: aload_0
/*      */     //   727: dup
/*      */     //   728: getfield blockNestingLevel : I
/*      */     //   731: dup_x1
/*      */     //   732: iconst_1
/*      */     //   733: isub
/*      */     //   734: putfield blockNestingLevel : I
/*      */     //   737: aload_0
/*      */     //   738: getfield saveIndexCreateLevel : I
/*      */     //   741: if_icmpne -> 749
/*      */     //   744: aload_0
/*      */     //   745: iconst_0
/*      */     //   746: putfield saveIndexCreateLevel : I
/*      */     //   749: aload_0
/*      */     //   750: dup
/*      */     //   751: getfield tabs : I
/*      */     //   754: iconst_1
/*      */     //   755: isub
/*      */     //   756: putfield tabs : I
/*      */     //   759: aload_0
/*      */     //   760: ldc '}'
/*      */     //   762: invokevirtual println : (Ljava/lang/String;)V
/*      */     //   765: iinc #11, 1
/*      */     //   768: goto -> 582
/*      */     //   771: aload_0
/*      */     //   772: ldc_w 'default:'
/*      */     //   775: invokevirtual println : (Ljava/lang/String;)V
/*      */     //   778: aload_0
/*      */     //   779: dup
/*      */     //   780: getfield tabs : I
/*      */     //   783: iconst_1
/*      */     //   784: iadd
/*      */     //   785: putfield tabs : I
/*      */     //   788: aload_0
/*      */     //   789: getfield grammar : Lantlr/Grammar;
/*      */     //   792: instanceof antlr/LexerGrammar
/*      */     //   795: ifeq -> 808
/*      */     //   798: aload_0
/*      */     //   799: getfield grammar : Lantlr/Grammar;
/*      */     //   802: getfield maxk : I
/*      */     //   805: goto -> 809
/*      */     //   808: iconst_0
/*      */     //   809: istore #10
/*      */     //   811: iload #10
/*      */     //   813: istore #11
/*      */     //   815: iload #11
/*      */     //   817: iflt -> 1703
/*      */     //   820: aload_0
/*      */     //   821: getfield DEBUG_CODE_GENERATOR : Z
/*      */     //   824: ifeq -> 854
/*      */     //   827: getstatic java/lang/System.out : Ljava/io/PrintStream;
/*      */     //   830: new java/lang/StringBuffer
/*      */     //   833: dup
/*      */     //   834: invokespecial <init> : ()V
/*      */     //   837: ldc_w 'checking depth '
/*      */     //   840: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuffer;
/*      */     //   843: iload #11
/*      */     //   845: invokevirtual append : (I)Ljava/lang/StringBuffer;
/*      */     //   848: invokevirtual toString : ()Ljava/lang/String;
/*      */     //   851: invokevirtual println : (Ljava/lang/String;)V
/*      */     //   854: iconst_0
/*      */     //   855: istore #12
/*      */     //   857: iload #12
/*      */     //   859: aload_1
/*      */     //   860: getfield alternatives : Lantlr/collections/impl/Vector;
/*      */     //   863: invokevirtual size : ()I
/*      */     //   866: if_icmpge -> 1697
/*      */     //   869: aload_1
/*      */     //   870: iload #12
/*      */     //   872: invokevirtual getAlternativeAt : (I)Lantlr/Alternative;
/*      */     //   875: astore #13
/*      */     //   877: aload_0
/*      */     //   878: getfield DEBUG_CODE_GENERATOR : Z
/*      */     //   881: ifeq -> 911
/*      */     //   884: getstatic java/lang/System.out : Ljava/io/PrintStream;
/*      */     //   887: new java/lang/StringBuffer
/*      */     //   890: dup
/*      */     //   891: invokespecial <init> : ()V
/*      */     //   894: ldc_w 'genAlt: '
/*      */     //   897: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuffer;
/*      */     //   900: iload #12
/*      */     //   902: invokevirtual append : (I)Ljava/lang/StringBuffer;
/*      */     //   905: invokevirtual toString : ()Ljava/lang/String;
/*      */     //   908: invokevirtual println : (Ljava/lang/String;)V
/*      */     //   911: iload #4
/*      */     //   913: ifeq -> 943
/*      */     //   916: aload #13
/*      */     //   918: invokestatic suitableForCaseExpression : (Lantlr/Alternative;)Z
/*      */     //   921: ifeq -> 943
/*      */     //   924: aload_0
/*      */     //   925: getfield DEBUG_CODE_GENERATOR : Z
/*      */     //   928: ifeq -> 1691
/*      */     //   931: getstatic java/lang/System.out : Ljava/io/PrintStream;
/*      */     //   934: ldc_w 'ignoring alt because it was in the switch'
/*      */     //   937: invokevirtual println : (Ljava/lang/String;)V
/*      */     //   940: goto -> 1691
/*      */     //   943: iconst_0
/*      */     //   944: istore #15
/*      */     //   946: aload_0
/*      */     //   947: getfield grammar : Lantlr/Grammar;
/*      */     //   950: instanceof antlr/LexerGrammar
/*      */     //   953: ifeq -> 1083
/*      */     //   956: aload #13
/*      */     //   958: getfield lookaheadDepth : I
/*      */     //   961: istore #16
/*      */     //   963: iload #16
/*      */     //   965: ldc 2147483647
/*      */     //   967: if_icmpne -> 979
/*      */     //   970: aload_0
/*      */     //   971: getfield grammar : Lantlr/Grammar;
/*      */     //   974: getfield maxk : I
/*      */     //   977: istore #16
/*      */     //   979: iload #16
/*      */     //   981: iconst_1
/*      */     //   982: if_icmplt -> 1005
/*      */     //   985: aload #13
/*      */     //   987: getfield cache : [Lantlr/Lookahead;
/*      */     //   990: iload #16
/*      */     //   992: aaload
/*      */     //   993: invokevirtual containsEpsilon : ()Z
/*      */     //   996: ifeq -> 1005
/*      */     //   999: iinc #16, -1
/*      */     //   1002: goto -> 979
/*      */     //   1005: iload #16
/*      */     //   1007: iload #11
/*      */     //   1009: if_icmpeq -> 1060
/*      */     //   1012: aload_0
/*      */     //   1013: getfield DEBUG_CODE_GENERATOR : Z
/*      */     //   1016: ifeq -> 1691
/*      */     //   1019: getstatic java/lang/System.out : Ljava/io/PrintStream;
/*      */     //   1022: new java/lang/StringBuffer
/*      */     //   1025: dup
/*      */     //   1026: invokespecial <init> : ()V
/*      */     //   1029: ldc_w 'ignoring alt because effectiveDepth!=altDepth;'
/*      */     //   1032: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuffer;
/*      */     //   1035: iload #16
/*      */     //   1037: invokevirtual append : (I)Ljava/lang/StringBuffer;
/*      */     //   1040: ldc_w '!='
/*      */     //   1043: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuffer;
/*      */     //   1046: iload #11
/*      */     //   1048: invokevirtual append : (I)Ljava/lang/StringBuffer;
/*      */     //   1051: invokevirtual toString : ()Ljava/lang/String;
/*      */     //   1054: invokevirtual println : (Ljava/lang/String;)V
/*      */     //   1057: goto -> 1691
/*      */     //   1060: aload_0
/*      */     //   1061: aload #13
/*      */     //   1063: iload #16
/*      */     //   1065: invokevirtual lookaheadIsEmpty : (Lantlr/Alternative;I)Z
/*      */     //   1068: istore #15
/*      */     //   1070: aload_0
/*      */     //   1071: aload #13
/*      */     //   1073: iload #16
/*      */     //   1075: invokevirtual getLookaheadTestExpression : (Lantlr/Alternative;I)Ljava/lang/String;
/*      */     //   1078: astore #14
/*      */     //   1080: goto -> 1113
/*      */     //   1083: aload_0
/*      */     //   1084: aload #13
/*      */     //   1086: aload_0
/*      */     //   1087: getfield grammar : Lantlr/Grammar;
/*      */     //   1090: getfield maxk : I
/*      */     //   1093: invokevirtual lookaheadIsEmpty : (Lantlr/Alternative;I)Z
/*      */     //   1096: istore #15
/*      */     //   1098: aload_0
/*      */     //   1099: aload #13
/*      */     //   1101: aload_0
/*      */     //   1102: getfield grammar : Lantlr/Grammar;
/*      */     //   1105: getfield maxk : I
/*      */     //   1108: invokevirtual getLookaheadTestExpression : (Lantlr/Alternative;I)Ljava/lang/String;
/*      */     //   1111: astore #14
/*      */     //   1113: aload #13
/*      */     //   1115: getfield cache : [Lantlr/Lookahead;
/*      */     //   1118: iconst_1
/*      */     //   1119: aaload
/*      */     //   1120: getfield fset : Lantlr/collections/impl/BitSet;
/*      */     //   1123: invokevirtual degree : ()I
/*      */     //   1126: bipush #127
/*      */     //   1128: if_icmple -> 1211
/*      */     //   1131: aload #13
/*      */     //   1133: invokestatic suitableForCaseExpression : (Lantlr/Alternative;)Z
/*      */     //   1136: ifeq -> 1211
/*      */     //   1139: iload_3
/*      */     //   1140: ifne -> 1177
/*      */     //   1143: aload_0
/*      */     //   1144: new java/lang/StringBuffer
/*      */     //   1147: dup
/*      */     //   1148: invokespecial <init> : ()V
/*      */     //   1151: ldc_w 'if '
/*      */     //   1154: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuffer;
/*      */     //   1157: aload #14
/*      */     //   1159: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuffer;
/*      */     //   1162: invokevirtual toString : ()Ljava/lang/String;
/*      */     //   1165: invokevirtual println : (Ljava/lang/String;)V
/*      */     //   1168: aload_0
/*      */     //   1169: ldc '{'
/*      */     //   1171: invokevirtual println : (Ljava/lang/String;)V
/*      */     //   1174: goto -> 1622
/*      */     //   1177: aload_0
/*      */     //   1178: new java/lang/StringBuffer
/*      */     //   1181: dup
/*      */     //   1182: invokespecial <init> : ()V
/*      */     //   1185: ldc_w 'else if '
/*      */     //   1188: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuffer;
/*      */     //   1191: aload #14
/*      */     //   1193: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuffer;
/*      */     //   1196: invokevirtual toString : ()Ljava/lang/String;
/*      */     //   1199: invokevirtual println : (Ljava/lang/String;)V
/*      */     //   1202: aload_0
/*      */     //   1203: ldc '{'
/*      */     //   1205: invokevirtual println : (Ljava/lang/String;)V
/*      */     //   1208: goto -> 1622
/*      */     //   1211: iload #15
/*      */     //   1213: ifeq -> 1261
/*      */     //   1216: aload #13
/*      */     //   1218: getfield semPred : Ljava/lang/String;
/*      */     //   1221: ifnonnull -> 1261
/*      */     //   1224: aload #13
/*      */     //   1226: getfield synPred : Lantlr/SynPredBlock;
/*      */     //   1229: ifnonnull -> 1261
/*      */     //   1232: iload_3
/*      */     //   1233: ifne -> 1245
/*      */     //   1236: aload_0
/*      */     //   1237: ldc '{'
/*      */     //   1239: invokevirtual println : (Ljava/lang/String;)V
/*      */     //   1242: goto -> 1252
/*      */     //   1245: aload_0
/*      */     //   1246: ldc_w 'else {'
/*      */     //   1249: invokevirtual println : (Ljava/lang/String;)V
/*      */     //   1252: aload #6
/*      */     //   1254: iconst_0
/*      */     //   1255: putfield needAnErrorClause : Z
/*      */     //   1258: goto -> 1622
/*      */     //   1261: aload #13
/*      */     //   1263: getfield semPred : Ljava/lang/String;
/*      */     //   1266: ifnull -> 1435
/*      */     //   1269: new antlr/ActionTransInfo
/*      */     //   1272: dup
/*      */     //   1273: invokespecial <init> : ()V
/*      */     //   1276: astore #16
/*      */     //   1278: aload_0
/*      */     //   1279: aload #13
/*      */     //   1281: getfield semPred : Ljava/lang/String;
/*      */     //   1284: aload_1
/*      */     //   1285: getfield line : I
/*      */     //   1288: aload_0
/*      */     //   1289: getfield currentRule : Lantlr/RuleBlock;
/*      */     //   1292: aload #16
/*      */     //   1294: invokevirtual processActionForSpecialSymbols : (Ljava/lang/String;ILantlr/RuleBlock;Lantlr/ActionTransInfo;)Ljava/lang/String;
/*      */     //   1297: astore #17
/*      */     //   1299: aload_0
/*      */     //   1300: getfield grammar : Lantlr/Grammar;
/*      */     //   1303: instanceof antlr/ParserGrammar
/*      */     //   1306: ifne -> 1319
/*      */     //   1309: aload_0
/*      */     //   1310: getfield grammar : Lantlr/Grammar;
/*      */     //   1313: instanceof antlr/LexerGrammar
/*      */     //   1316: ifeq -> 1395
/*      */     //   1319: aload_0
/*      */     //   1320: getfield grammar : Lantlr/Grammar;
/*      */     //   1323: getfield debuggingOutput : Z
/*      */     //   1326: ifeq -> 1395
/*      */     //   1329: new java/lang/StringBuffer
/*      */     //   1332: dup
/*      */     //   1333: invokespecial <init> : ()V
/*      */     //   1336: ldc_w '('
/*      */     //   1339: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuffer;
/*      */     //   1342: aload #14
/*      */     //   1344: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuffer;
/*      */     //   1347: ldc_w '&& fireSemanticPredicateEvaluated(antlr.debug.SemanticPredicateEventArgs.PREDICTING,'
/*      */     //   1350: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuffer;
/*      */     //   1353: aload_0
/*      */     //   1354: aload_0
/*      */     //   1355: getfield charFormatter : Lantlr/CharFormatter;
/*      */     //   1358: aload #17
/*      */     //   1360: invokeinterface escapeString : (Ljava/lang/String;)Ljava/lang/String;
/*      */     //   1365: invokevirtual addSemPred : (Ljava/lang/String;)I
/*      */     //   1368: invokevirtual append : (I)Ljava/lang/StringBuffer;
/*      */     //   1371: ldc ','
/*      */     //   1373: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuffer;
/*      */     //   1376: aload #17
/*      */     //   1378: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuffer;
/*      */     //   1381: ldc_w '))'
/*      */     //   1384: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuffer;
/*      */     //   1387: invokevirtual toString : ()Ljava/lang/String;
/*      */     //   1390: astore #14
/*      */     //   1392: goto -> 1435
/*      */     //   1395: new java/lang/StringBuffer
/*      */     //   1398: dup
/*      */     //   1399: invokespecial <init> : ()V
/*      */     //   1402: ldc_w '('
/*      */     //   1405: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuffer;
/*      */     //   1408: aload #14
/*      */     //   1410: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuffer;
/*      */     //   1413: ldc_w '&&('
/*      */     //   1416: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuffer;
/*      */     //   1419: aload #17
/*      */     //   1421: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuffer;
/*      */     //   1424: ldc_w '))'
/*      */     //   1427: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuffer;
/*      */     //   1430: invokevirtual toString : ()Ljava/lang/String;
/*      */     //   1433: astore #14
/*      */     //   1435: iload_3
/*      */     //   1436: ifle -> 1525
/*      */     //   1439: aload #13
/*      */     //   1441: getfield synPred : Lantlr/SynPredBlock;
/*      */     //   1444: ifnull -> 1491
/*      */     //   1447: aload_0
/*      */     //   1448: ldc_w 'else {'
/*      */     //   1451: invokevirtual println : (Ljava/lang/String;)V
/*      */     //   1454: aload_0
/*      */     //   1455: dup
/*      */     //   1456: getfield tabs : I
/*      */     //   1459: iconst_1
/*      */     //   1460: iadd
/*      */     //   1461: putfield tabs : I
/*      */     //   1464: aload_0
/*      */     //   1465: dup
/*      */     //   1466: getfield blockNestingLevel : I
/*      */     //   1469: iconst_1
/*      */     //   1470: iadd
/*      */     //   1471: putfield blockNestingLevel : I
/*      */     //   1474: aload_0
/*      */     //   1475: aload #13
/*      */     //   1477: getfield synPred : Lantlr/SynPredBlock;
/*      */     //   1480: aload #14
/*      */     //   1482: invokevirtual genSynPred : (Lantlr/SynPredBlock;Ljava/lang/String;)V
/*      */     //   1485: iinc #5, 1
/*      */     //   1488: goto -> 1622
/*      */     //   1491: aload_0
/*      */     //   1492: new java/lang/StringBuffer
/*      */     //   1495: dup
/*      */     //   1496: invokespecial <init> : ()V
/*      */     //   1499: ldc_w 'else if '
/*      */     //   1502: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuffer;
/*      */     //   1505: aload #14
/*      */     //   1507: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuffer;
/*      */     //   1510: ldc_w ' {'
/*      */     //   1513: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuffer;
/*      */     //   1516: invokevirtual toString : ()Ljava/lang/String;
/*      */     //   1519: invokevirtual println : (Ljava/lang/String;)V
/*      */     //   1522: goto -> 1622
/*      */     //   1525: aload #13
/*      */     //   1527: getfield synPred : Lantlr/SynPredBlock;
/*      */     //   1530: ifnull -> 1547
/*      */     //   1533: aload_0
/*      */     //   1534: aload #13
/*      */     //   1536: getfield synPred : Lantlr/SynPredBlock;
/*      */     //   1539: aload #14
/*      */     //   1541: invokevirtual genSynPred : (Lantlr/SynPredBlock;Ljava/lang/String;)V
/*      */     //   1544: goto -> 1622
/*      */     //   1547: aload_0
/*      */     //   1548: getfield grammar : Lantlr/Grammar;
/*      */     //   1551: instanceof antlr/TreeWalkerGrammar
/*      */     //   1554: ifeq -> 1591
/*      */     //   1557: aload_0
/*      */     //   1558: ldc_w 'if (_t == null)'
/*      */     //   1561: invokevirtual println : (Ljava/lang/String;)V
/*      */     //   1564: aload_0
/*      */     //   1565: dup
/*      */     //   1566: getfield tabs : I
/*      */     //   1569: iconst_1
/*      */     //   1570: iadd
/*      */     //   1571: putfield tabs : I
/*      */     //   1574: aload_0
/*      */     //   1575: ldc_w '_t = ASTNULL;'
/*      */     //   1578: invokevirtual println : (Ljava/lang/String;)V
/*      */     //   1581: aload_0
/*      */     //   1582: dup
/*      */     //   1583: getfield tabs : I
/*      */     //   1586: iconst_1
/*      */     //   1587: isub
/*      */     //   1588: putfield tabs : I
/*      */     //   1591: aload_0
/*      */     //   1592: new java/lang/StringBuffer
/*      */     //   1595: dup
/*      */     //   1596: invokespecial <init> : ()V
/*      */     //   1599: ldc_w 'if '
/*      */     //   1602: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuffer;
/*      */     //   1605: aload #14
/*      */     //   1607: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuffer;
/*      */     //   1610: invokevirtual toString : ()Ljava/lang/String;
/*      */     //   1613: invokevirtual println : (Ljava/lang/String;)V
/*      */     //   1616: aload_0
/*      */     //   1617: ldc '{'
/*      */     //   1619: invokevirtual println : (Ljava/lang/String;)V
/*      */     //   1622: aload_0
/*      */     //   1623: dup
/*      */     //   1624: getfield blockNestingLevel : I
/*      */     //   1627: iconst_1
/*      */     //   1628: iadd
/*      */     //   1629: putfield blockNestingLevel : I
/*      */     //   1632: iinc #3, 1
/*      */     //   1635: aload_0
/*      */     //   1636: dup
/*      */     //   1637: getfield tabs : I
/*      */     //   1640: iconst_1
/*      */     //   1641: iadd
/*      */     //   1642: putfield tabs : I
/*      */     //   1645: aload_0
/*      */     //   1646: aload #13
/*      */     //   1648: aload_1
/*      */     //   1649: invokevirtual genAlt : (Lantlr/Alternative;Lantlr/AlternativeBlock;)V
/*      */     //   1652: aload_0
/*      */     //   1653: dup
/*      */     //   1654: getfield tabs : I
/*      */     //   1657: iconst_1
/*      */     //   1658: isub
/*      */     //   1659: putfield tabs : I
/*      */     //   1662: aload_0
/*      */     //   1663: dup
/*      */     //   1664: getfield blockNestingLevel : I
/*      */     //   1667: dup_x1
/*      */     //   1668: iconst_1
/*      */     //   1669: isub
/*      */     //   1670: putfield blockNestingLevel : I
/*      */     //   1673: aload_0
/*      */     //   1674: getfield saveIndexCreateLevel : I
/*      */     //   1677: if_icmpne -> 1685
/*      */     //   1680: aload_0
/*      */     //   1681: iconst_0
/*      */     //   1682: putfield saveIndexCreateLevel : I
/*      */     //   1685: aload_0
/*      */     //   1686: ldc '}'
/*      */     //   1688: invokevirtual println : (Ljava/lang/String;)V
/*      */     //   1691: iinc #12, 1
/*      */     //   1694: goto -> 857
/*      */     //   1697: iinc #11, -1
/*      */     //   1700: goto -> 815
/*      */     //   1703: ldc_w ''
/*      */     //   1706: astore #11
/*      */     //   1708: iconst_1
/*      */     //   1709: istore #12
/*      */     //   1711: iload #12
/*      */     //   1713: iload #5
/*      */     //   1715: if_icmpgt -> 1769
/*      */     //   1718: new java/lang/StringBuffer
/*      */     //   1721: dup
/*      */     //   1722: invokespecial <init> : ()V
/*      */     //   1725: aload #11
/*      */     //   1727: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuffer;
/*      */     //   1730: ldc '}'
/*      */     //   1732: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuffer;
/*      */     //   1735: invokevirtual toString : ()Ljava/lang/String;
/*      */     //   1738: astore #11
/*      */     //   1740: aload_0
/*      */     //   1741: dup
/*      */     //   1742: getfield blockNestingLevel : I
/*      */     //   1745: dup_x1
/*      */     //   1746: iconst_1
/*      */     //   1747: isub
/*      */     //   1748: putfield blockNestingLevel : I
/*      */     //   1751: aload_0
/*      */     //   1752: getfield saveIndexCreateLevel : I
/*      */     //   1755: if_icmpne -> 1763
/*      */     //   1758: aload_0
/*      */     //   1759: iconst_0
/*      */     //   1760: putfield saveIndexCreateLevel : I
/*      */     //   1763: iinc #12, 1
/*      */     //   1766: goto -> 1711
/*      */     //   1769: aload_0
/*      */     //   1770: iload #7
/*      */     //   1772: putfield genAST : Z
/*      */     //   1775: aload_0
/*      */     //   1776: iload #8
/*      */     //   1778: putfield saveText : Z
/*      */     //   1781: iload #4
/*      */     //   1783: ifeq -> 1868
/*      */     //   1786: aload_0
/*      */     //   1787: dup
/*      */     //   1788: getfield tabs : I
/*      */     //   1791: iconst_1
/*      */     //   1792: isub
/*      */     //   1793: putfield tabs : I
/*      */     //   1796: aload #6
/*      */     //   1798: new java/lang/StringBuffer
/*      */     //   1801: dup
/*      */     //   1802: invokespecial <init> : ()V
/*      */     //   1805: aload #11
/*      */     //   1807: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuffer;
/*      */     //   1810: ldc_w 'break; }'
/*      */     //   1813: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuffer;
/*      */     //   1816: invokevirtual toString : ()Ljava/lang/String;
/*      */     //   1819: putfield postscript : Ljava/lang/String;
/*      */     //   1822: aload_0
/*      */     //   1823: dup
/*      */     //   1824: getfield blockNestingLevel : I
/*      */     //   1827: dup_x1
/*      */     //   1828: iconst_1
/*      */     //   1829: isub
/*      */     //   1830: putfield blockNestingLevel : I
/*      */     //   1833: aload_0
/*      */     //   1834: getfield saveIndexCreateLevel : I
/*      */     //   1837: if_icmpne -> 1845
/*      */     //   1840: aload_0
/*      */     //   1841: iconst_0
/*      */     //   1842: putfield saveIndexCreateLevel : I
/*      */     //   1845: aload #6
/*      */     //   1847: iconst_1
/*      */     //   1848: putfield generatedSwitch : Z
/*      */     //   1851: aload #6
/*      */     //   1853: iload_3
/*      */     //   1854: ifle -> 1861
/*      */     //   1857: iconst_1
/*      */     //   1858: goto -> 1862
/*      */     //   1861: iconst_0
/*      */     //   1862: putfield generatedAnIf : Z
/*      */     //   1865: goto -> 1895
/*      */     //   1868: aload #6
/*      */     //   1870: aload #11
/*      */     //   1872: putfield postscript : Ljava/lang/String;
/*      */     //   1875: aload #6
/*      */     //   1877: iconst_0
/*      */     //   1878: putfield generatedSwitch : Z
/*      */     //   1881: aload #6
/*      */     //   1883: iload_3
/*      */     //   1884: ifle -> 1891
/*      */     //   1887: iconst_1
/*      */     //   1888: goto -> 1892
/*      */     //   1891: iconst_0
/*      */     //   1892: putfield generatedAnIf : Z
/*      */     //   1895: aload #6
/*      */     //   1897: areturn
/*      */     // Line number table:
/*      */     //   Java source line number -> byte code offset
/*      */     //   #1820	-> 0
/*      */     //   #1821	-> 2
/*      */     //   #1822	-> 5
/*      */     //   #1823	-> 8
/*      */     //   #1824	-> 17
/*      */     //   #1827	-> 55
/*      */     //   #1828	-> 61
/*      */     //   #1830	-> 84
/*      */     //   #1831	-> 90
/*      */     //   #1834	-> 113
/*      */     //   #1837	-> 140
/*      */     //   #1838	-> 156
/*      */     //   #1840	-> 169
/*      */     //   #1841	-> 183
/*      */     //   #1845	-> 221
/*      */     //   #1847	-> 226
/*      */     //   #1848	-> 231
/*      */     //   #1849	-> 241
/*      */     //   #1850	-> 248
/*      */     //   #1852	-> 256
/*      */     //   #1856	-> 261
/*      */     //   #1859	-> 307
/*      */     //   #1861	-> 317
/*      */     //   #1863	-> 323
/*      */     //   #1867	-> 326
/*      */     //   #1869	-> 337
/*      */     //   #1871	-> 344
/*      */     //   #1873	-> 352
/*      */     //   #1880	-> 391
/*      */     //   #1882	-> 395
/*      */     //   #1885	-> 403
/*      */     //   #1887	-> 416
/*      */     //   #1888	-> 423
/*      */     //   #1901	-> 426
/*      */     //   #1902	-> 429
/*      */     //   #1904	-> 444
/*      */     //   #1905	-> 452
/*      */     //   #1906	-> 460
/*      */     //   #1902	-> 463
/*      */     //   #1911	-> 469
/*      */     //   #1914	-> 478
/*      */     //   #1915	-> 485
/*      */     //   #1917	-> 488
/*      */     //   #1919	-> 498
/*      */     //   #1920	-> 505
/*      */     //   #1921	-> 515
/*      */     //   #1922	-> 522
/*      */     //   #1924	-> 532
/*      */     //   #1925	-> 563
/*      */     //   #1928	-> 569
/*      */     //   #1930	-> 579
/*      */     //   #1932	-> 594
/*      */     //   #1935	-> 602
/*      */     //   #1937	-> 610
/*      */     //   #1939	-> 613
/*      */     //   #1940	-> 622
/*      */     //   #1942	-> 641
/*      */     //   #1948	-> 677
/*      */     //   #1949	-> 686
/*      */     //   #1950	-> 692
/*      */     //   #1951	-> 702
/*      */     //   #1952	-> 712
/*      */     //   #1953	-> 719
/*      */     //   #1954	-> 726
/*      */     //   #1955	-> 744
/*      */     //   #1956	-> 749
/*      */     //   #1957	-> 759
/*      */     //   #1930	-> 765
/*      */     //   #1960	-> 771
/*      */     //   #1961	-> 778
/*      */     //   #1977	-> 788
/*      */     //   #1978	-> 811
/*      */     //   #1979	-> 820
/*      */     //   #1980	-> 854
/*      */     //   #1981	-> 869
/*      */     //   #1982	-> 877
/*      */     //   #1987	-> 911
/*      */     //   #1989	-> 924
/*      */     //   #1994	-> 943
/*      */     //   #1996	-> 946
/*      */     //   #2000	-> 956
/*      */     //   #2001	-> 963
/*      */     //   #2004	-> 970
/*      */     //   #2006	-> 979
/*      */     //   #2009	-> 999
/*      */     //   #2013	-> 1005
/*      */     //   #2015	-> 1012
/*      */     //   #2016	-> 1019
/*      */     //   #2019	-> 1060
/*      */     //   #2020	-> 1070
/*      */     //   #2024	-> 1083
/*      */     //   #2025	-> 1098
/*      */     //   #2030	-> 1113
/*      */     //   #2033	-> 1139
/*      */     //   #2035	-> 1143
/*      */     //   #2036	-> 1168
/*      */     //   #2039	-> 1177
/*      */     //   #2040	-> 1202
/*      */     //   #2043	-> 1211
/*      */     //   #2051	-> 1232
/*      */     //   #2052	-> 1236
/*      */     //   #2055	-> 1245
/*      */     //   #2057	-> 1252
/*      */     //   #2063	-> 1261
/*      */     //   #2067	-> 1269
/*      */     //   #2068	-> 1278
/*      */     //   #2075	-> 1299
/*      */     //   #2077	-> 1329
/*      */     //   #2081	-> 1395
/*      */     //   #2086	-> 1435
/*      */     //   #2087	-> 1439
/*      */     //   #2088	-> 1447
/*      */     //   #2089	-> 1454
/*      */     //   #2090	-> 1464
/*      */     //   #2091	-> 1474
/*      */     //   #2092	-> 1485
/*      */     //   #2095	-> 1491
/*      */     //   #2099	-> 1525
/*      */     //   #2100	-> 1533
/*      */     //   #2105	-> 1547
/*      */     //   #2106	-> 1557
/*      */     //   #2107	-> 1564
/*      */     //   #2108	-> 1574
/*      */     //   #2109	-> 1581
/*      */     //   #2111	-> 1591
/*      */     //   #2112	-> 1616
/*      */     //   #2117	-> 1622
/*      */     //   #2119	-> 1632
/*      */     //   #2120	-> 1635
/*      */     //   #2121	-> 1645
/*      */     //   #2122	-> 1652
/*      */     //   #2124	-> 1662
/*      */     //   #2125	-> 1680
/*      */     //   #2126	-> 1685
/*      */     //   #1980	-> 1691
/*      */     //   #1978	-> 1697
/*      */     //   #2130	-> 1703
/*      */     //   #2131	-> 1708
/*      */     //   #2132	-> 1718
/*      */     //   #2133	-> 1740
/*      */     //   #2134	-> 1758
/*      */     //   #2131	-> 1763
/*      */     //   #2138	-> 1769
/*      */     //   #2141	-> 1775
/*      */     //   #2144	-> 1781
/*      */     //   #2145	-> 1786
/*      */     //   #2146	-> 1796
/*      */     //   #2147	-> 1822
/*      */     //   #2148	-> 1840
/*      */     //   #2149	-> 1845
/*      */     //   #2150	-> 1851
/*      */     //   #2155	-> 1868
/*      */     //   #2156	-> 1875
/*      */     //   #2157	-> 1881
/*      */     //   #2160	-> 1895
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static boolean suitableForCaseExpression(Alternative paramAlternative) {
/* 2164 */     return (paramAlternative.lookaheadDepth == 1 && paramAlternative.semPred == null && !paramAlternative.cache[1].containsEpsilon() && (paramAlternative.cache[1]).fset.degree() <= 127);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void genElementAST(AlternativeElement paramAlternativeElement) {
/* 2174 */     if (this.grammar instanceof TreeWalkerGrammar && !this.grammar.buildAST) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2180 */       if (paramAlternativeElement.getLabel() == null) {
/*      */         
/* 2182 */         String str1 = this.lt1Value;
/*      */         
/* 2184 */         String str2 = "tmp" + this.astVarNumber + "_AST";
/* 2185 */         this.astVarNumber++;
/*      */         
/* 2187 */         mapTreeVariable(paramAlternativeElement, str2);
/*      */         
/* 2189 */         println(this.labeledElementASTType + " " + str2 + "_in = " + str1 + ";");
/*      */       } 
/*      */       
/*      */       return;
/*      */     } 
/* 2194 */     if (this.grammar.buildAST && this.syntacticPredLevel == 0) {
/*      */       String str1, str2;
/* 2196 */       boolean bool1 = (this.genAST && (paramAlternativeElement.getLabel() != null || paramAlternativeElement.getAutoGenType() != 3)) ? true : false;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2204 */       if (paramAlternativeElement.getAutoGenType() != 3 && paramAlternativeElement instanceof TokenRefElement)
/*      */       {
/* 2206 */         bool1 = true;
/*      */       }
/* 2208 */       boolean bool2 = (this.grammar.hasSyntacticPredicate && bool1) ? true : false;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2214 */       if (paramAlternativeElement.getLabel() != null) {
/*      */ 
/*      */         
/* 2217 */         str1 = paramAlternativeElement.getLabel();
/* 2218 */         str2 = paramAlternativeElement.getLabel();
/*      */       
/*      */       }
/*      */       else {
/*      */         
/* 2223 */         str1 = this.lt1Value;
/*      */         
/* 2225 */         str2 = "tmp" + this.astVarNumber;
/* 2226 */         this.astVarNumber++;
/*      */       } 
/*      */ 
/*      */       
/* 2230 */       if (bool1)
/*      */       {
/*      */         
/* 2233 */         if (paramAlternativeElement instanceof GrammarAtom) {
/*      */           
/* 2235 */           GrammarAtom grammarAtom = (GrammarAtom)paramAlternativeElement;
/* 2236 */           if (grammarAtom.getASTNodeType() != null)
/*      */           {
/* 2238 */             genASTDeclaration(paramAlternativeElement, str2, grammarAtom.getASTNodeType());
/*      */           
/*      */           }
/*      */           else
/*      */           {
/* 2243 */             genASTDeclaration(paramAlternativeElement, str2, this.labeledElementASTType);
/*      */           }
/*      */         
/*      */         }
/*      */         else {
/*      */           
/* 2249 */           genASTDeclaration(paramAlternativeElement, str2, this.labeledElementASTType);
/*      */         } 
/*      */       }
/*      */ 
/*      */ 
/*      */       
/* 2255 */       String str3 = str2 + "_AST";
/*      */ 
/*      */       
/* 2258 */       mapTreeVariable(paramAlternativeElement, str3);
/* 2259 */       if (this.grammar instanceof TreeWalkerGrammar)
/*      */       {
/*      */         
/* 2262 */         println(this.labeledElementASTType + " " + str3 + "_in = null;");
/*      */       }
/*      */ 
/*      */ 
/*      */       
/* 2267 */       if (bool2);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2275 */       if (paramAlternativeElement.getLabel() != null)
/*      */       {
/* 2277 */         if (paramAlternativeElement instanceof GrammarAtom) {
/*      */           
/* 2279 */           println(str3 + " = " + getASTCreateString((GrammarAtom)paramAlternativeElement, str1) + ";");
/*      */         }
/*      */         else {
/*      */           
/* 2283 */           println(str3 + " = " + getASTCreateString(str1) + ";");
/*      */         } 
/*      */       }
/*      */ 
/*      */       
/* 2288 */       if (paramAlternativeElement.getLabel() == null && bool1) {
/*      */         
/* 2290 */         str1 = this.lt1Value;
/* 2291 */         if (paramAlternativeElement instanceof GrammarAtom) {
/*      */           
/* 2293 */           println(str3 + " = " + getASTCreateString((GrammarAtom)paramAlternativeElement, str1) + ";");
/*      */         }
/*      */         else {
/*      */           
/* 2297 */           println(str3 + " = " + getASTCreateString(str1) + ";");
/*      */         } 
/*      */         
/* 2300 */         if (this.grammar instanceof TreeWalkerGrammar)
/*      */         {
/*      */           
/* 2303 */           println(str3 + "_in = " + str1 + ";");
/*      */         }
/*      */       } 
/*      */       
/* 2307 */       if (this.genAST)
/*      */       {
/* 2309 */         switch (paramAlternativeElement.getAutoGenType()) {
/*      */           
/*      */           case 1:
/* 2312 */             if (this.usingCustomAST || (paramAlternativeElement instanceof GrammarAtom && ((GrammarAtom)paramAlternativeElement).getASTNodeType() != null)) {
/*      */ 
/*      */               
/* 2315 */               println("astFactory.addASTChild(ref currentAST, (AST)" + str3 + ");"); break;
/*      */             } 
/* 2317 */             println("astFactory.addASTChild(ref currentAST, " + str3 + ");");
/*      */             break;
/*      */           case 2:
/* 2320 */             if (this.usingCustomAST || (paramAlternativeElement instanceof GrammarAtom && ((GrammarAtom)paramAlternativeElement).getASTNodeType() != null)) {
/*      */ 
/*      */               
/* 2323 */               println("astFactory.makeASTRoot(ref currentAST, (AST)" + str3 + ");"); break;
/*      */             } 
/* 2325 */             println("astFactory.makeASTRoot(ref currentAST, " + str3 + ");");
/*      */             break;
/*      */         } 
/*      */ 
/*      */       
/*      */       }
/* 2331 */       if (bool2);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void genErrorCatchForElement(AlternativeElement paramAlternativeElement) {
/* 2344 */     if (paramAlternativeElement.getLabel() == null)
/* 2345 */       return;  String str = paramAlternativeElement.enclosingRuleName;
/* 2346 */     if (this.grammar instanceof LexerGrammar) {
/* 2347 */       str = CodeGenerator.encodeLexerRuleName(paramAlternativeElement.enclosingRuleName);
/*      */     }
/* 2349 */     RuleSymbol ruleSymbol = (RuleSymbol)this.grammar.getSymbol(str);
/* 2350 */     if (ruleSymbol == null) {
/* 2351 */       this.antlrTool.panic("Enclosing rule not found!");
/*      */     }
/* 2353 */     ExceptionSpec exceptionSpec = ruleSymbol.block.findExceptionSpec(paramAlternativeElement.getLabel());
/* 2354 */     if (exceptionSpec != null) {
/* 2355 */       this.tabs--;
/* 2356 */       println("}");
/* 2357 */       genErrorHandler(exceptionSpec);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void genErrorHandler(ExceptionSpec paramExceptionSpec) {
/* 2365 */     for (byte b = 0; b < paramExceptionSpec.handlers.size(); b++) {
/*      */       
/* 2367 */       ExceptionHandler exceptionHandler = (ExceptionHandler)paramExceptionSpec.handlers.elementAt(b);
/*      */       
/* 2369 */       println("catch (" + exceptionHandler.exceptionTypeAndName.getText() + ")");
/* 2370 */       println("{");
/* 2371 */       this.tabs++;
/* 2372 */       if (this.grammar.hasSyntacticPredicate) {
/* 2373 */         println("if (0 == inputState.guessing)");
/* 2374 */         println("{");
/* 2375 */         this.tabs++;
/*      */       } 
/*      */ 
/*      */       
/* 2379 */       ActionTransInfo actionTransInfo = new ActionTransInfo();
/* 2380 */       printAction(processActionForSpecialSymbols(exceptionHandler.action.getText(), exceptionHandler.action.getLine(), this.currentRule, actionTransInfo));
/*      */ 
/*      */       
/* 2383 */       if (this.grammar.hasSyntacticPredicate) {
/*      */         
/* 2385 */         this.tabs--;
/* 2386 */         println("}");
/* 2387 */         println("else");
/* 2388 */         println("{");
/* 2389 */         this.tabs++;
/*      */ 
/*      */         
/* 2392 */         println("throw;");
/* 2393 */         this.tabs--;
/* 2394 */         println("}");
/*      */       } 
/*      */       
/* 2397 */       this.tabs--;
/* 2398 */       println("}");
/*      */     } 
/*      */   }
/*      */   
/*      */   private void genErrorTryForElement(AlternativeElement paramAlternativeElement) {
/* 2403 */     if (paramAlternativeElement.getLabel() == null)
/* 2404 */       return;  String str = paramAlternativeElement.enclosingRuleName;
/* 2405 */     if (this.grammar instanceof LexerGrammar) {
/* 2406 */       str = CodeGenerator.encodeLexerRuleName(paramAlternativeElement.enclosingRuleName);
/*      */     }
/* 2408 */     RuleSymbol ruleSymbol = (RuleSymbol)this.grammar.getSymbol(str);
/* 2409 */     if (ruleSymbol == null) {
/* 2410 */       this.antlrTool.panic("Enclosing rule not found!");
/*      */     }
/* 2412 */     ExceptionSpec exceptionSpec = ruleSymbol.block.findExceptionSpec(paramAlternativeElement.getLabel());
/* 2413 */     if (exceptionSpec != null) {
/* 2414 */       println("try   // for error handling");
/* 2415 */       println("{");
/* 2416 */       this.tabs++;
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   protected void genASTDeclaration(AlternativeElement paramAlternativeElement) {
/* 2422 */     genASTDeclaration(paramAlternativeElement, this.labeledElementASTType);
/*      */   }
/*      */ 
/*      */   
/*      */   protected void genASTDeclaration(AlternativeElement paramAlternativeElement, String paramString) {
/* 2427 */     genASTDeclaration(paramAlternativeElement, paramAlternativeElement.getLabel(), paramString);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected void genASTDeclaration(AlternativeElement paramAlternativeElement, String paramString1, String paramString2) {
/* 2433 */     if (this.declaredASTVariables.contains(paramAlternativeElement)) {
/*      */       return;
/*      */     }
/*      */ 
/*      */ 
/*      */     
/* 2439 */     println(paramString2 + " " + paramString1 + "_AST = null;");
/*      */ 
/*      */     
/* 2442 */     this.declaredASTVariables.put(paramAlternativeElement, paramAlternativeElement);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected void genHeader() {
/* 2448 */     println("// $ANTLR " + Tool.version + ": " + "\"" + this.antlrTool.fileMinusPath(this.antlrTool.grammarFile) + "\"" + " -> " + "\"" + this.grammar.getClassName() + ".cs\"$");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void genLiteralsTest() {
/* 2455 */     println("_ttype = testLiteralsTable(_ttype);");
/*      */   }
/*      */   
/*      */   private void genLiteralsTestForPartialToken() {
/* 2459 */     println("_ttype = testLiteralsTable(text.ToString(_begin, text.Length-_begin), _ttype);");
/*      */   }
/*      */ 
/*      */   
/*      */   protected void genMatch(BitSet paramBitSet) {}
/*      */   
/*      */   protected void genMatch(GrammarAtom paramGrammarAtom) {
/* 2466 */     if (paramGrammarAtom instanceof StringLiteralElement) {
/* 2467 */       if (this.grammar instanceof LexerGrammar) {
/* 2468 */         genMatchUsingAtomText(paramGrammarAtom);
/*      */       } else {
/*      */         
/* 2471 */         genMatchUsingAtomTokenType(paramGrammarAtom);
/*      */       }
/*      */     
/* 2474 */     } else if (paramGrammarAtom instanceof CharLiteralElement) {
/* 2475 */       if (this.grammar instanceof LexerGrammar) {
/* 2476 */         genMatchUsingAtomText(paramGrammarAtom);
/*      */       } else {
/*      */         
/* 2479 */         this.antlrTool.error("cannot ref character literals in grammar: " + paramGrammarAtom);
/*      */       }
/*      */     
/* 2482 */     } else if (paramGrammarAtom instanceof TokenRefElement) {
/* 2483 */       genMatchUsingAtomText(paramGrammarAtom);
/* 2484 */     } else if (paramGrammarAtom instanceof WildcardElement) {
/* 2485 */       gen((WildcardElement)paramGrammarAtom);
/*      */     } 
/*      */   }
/*      */   
/*      */   protected void genMatchUsingAtomText(GrammarAtom paramGrammarAtom) {
/* 2490 */     String str = "";
/* 2491 */     if (this.grammar instanceof TreeWalkerGrammar) {
/* 2492 */       if (this.usingCustomAST) {
/* 2493 */         str = "(AST)_t,";
/*      */       } else {
/* 2495 */         str = "_t,";
/*      */       } 
/*      */     }
/*      */     
/* 2499 */     if (this.grammar instanceof LexerGrammar && (!this.saveText || paramGrammarAtom.getAutoGenType() == 3)) {
/* 2500 */       declareSaveIndexVariableIfNeeded();
/* 2501 */       println("_saveIndex = text.Length;");
/*      */     } 
/*      */     
/* 2504 */     print(paramGrammarAtom.not ? "matchNot(" : "match(");
/* 2505 */     _print(str);
/*      */ 
/*      */     
/* 2508 */     if (paramGrammarAtom.atomText.equals("EOF")) {
/*      */       
/* 2510 */       _print("Token.EOF_TYPE");
/*      */     } else {
/*      */       
/* 2513 */       _print(paramGrammarAtom.atomText);
/*      */     } 
/* 2515 */     _println(");");
/*      */     
/* 2517 */     if (this.grammar instanceof LexerGrammar && (!this.saveText || paramGrammarAtom.getAutoGenType() == 3)) {
/* 2518 */       declareSaveIndexVariableIfNeeded();
/* 2519 */       println("text.Length = _saveIndex;");
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   protected void genMatchUsingAtomTokenType(GrammarAtom paramGrammarAtom) {
/* 2525 */     String str1 = "";
/* 2526 */     if (this.grammar instanceof TreeWalkerGrammar) {
/* 2527 */       if (this.usingCustomAST) {
/* 2528 */         str1 = "(AST)_t,";
/*      */       } else {
/* 2530 */         str1 = "_t,";
/*      */       } 
/*      */     }
/*      */     
/* 2534 */     Object object = null;
/* 2535 */     String str2 = str1 + getValueString(paramGrammarAtom.getType());
/*      */ 
/*      */     
/* 2538 */     println((paramGrammarAtom.not ? "matchNot(" : "match(") + str2 + ");");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void genNextToken() {
/* 2548 */     boolean bool = false;
/* 2549 */     for (byte b1 = 0; b1 < this.grammar.rules.size(); b1++) {
/* 2550 */       RuleSymbol ruleSymbol1 = (RuleSymbol)this.grammar.rules.elementAt(b1);
/* 2551 */       if (ruleSymbol1.isDefined() && ruleSymbol1.access.equals("public")) {
/* 2552 */         bool = true;
/*      */         break;
/*      */       } 
/*      */     } 
/* 2556 */     if (!bool) {
/* 2557 */       println("");
/* 2558 */       println("override public IToken nextToken()\t\t\t//throws TokenStreamException");
/* 2559 */       println("{");
/* 2560 */       this.tabs++;
/* 2561 */       println("try");
/* 2562 */       println("{");
/* 2563 */       this.tabs++;
/* 2564 */       println("uponEOF();");
/* 2565 */       this.tabs--;
/* 2566 */       println("}");
/* 2567 */       println("catch(CharStreamIOException csioe)");
/* 2568 */       println("{");
/* 2569 */       this.tabs++;
/* 2570 */       println("throw new TokenStreamIOException(csioe.io);");
/* 2571 */       this.tabs--;
/* 2572 */       println("}");
/* 2573 */       println("catch(CharStreamException cse)");
/* 2574 */       println("{");
/* 2575 */       this.tabs++;
/* 2576 */       println("throw new TokenStreamException(cse.Message);");
/* 2577 */       this.tabs--;
/* 2578 */       println("}");
/* 2579 */       println("return new CommonToken(Token.EOF_TYPE, \"\");");
/* 2580 */       this.tabs--;
/* 2581 */       println("}");
/* 2582 */       println("");
/*      */       
/*      */       return;
/*      */     } 
/*      */     
/* 2587 */     RuleBlock ruleBlock = MakeGrammar.createNextTokenRule(this.grammar, this.grammar.rules, "nextToken");
/*      */     
/* 2589 */     RuleSymbol ruleSymbol = new RuleSymbol("mnextToken");
/* 2590 */     ruleSymbol.setDefined();
/* 2591 */     ruleSymbol.setBlock(ruleBlock);
/* 2592 */     ruleSymbol.access = "private";
/* 2593 */     this.grammar.define(ruleSymbol);
/*      */     
/* 2595 */     boolean bool1 = this.grammar.theLLkAnalyzer.deterministic(ruleBlock);
/*      */ 
/*      */     
/* 2598 */     String str1 = null;
/* 2599 */     if (((LexerGrammar)this.grammar).filterMode) {
/* 2600 */       str1 = ((LexerGrammar)this.grammar).filterRule;
/*      */     }
/*      */     
/* 2603 */     println("");
/* 2604 */     println("override public IToken nextToken()\t\t\t//throws TokenStreamException");
/* 2605 */     println("{");
/* 2606 */     this.tabs++;
/*      */     
/* 2608 */     this.blockNestingLevel = 1;
/* 2609 */     this.saveIndexCreateLevel = 0;
/* 2610 */     println("IToken theRetToken = null;");
/* 2611 */     _println("tryAgain:");
/* 2612 */     println("for (;;)");
/* 2613 */     println("{");
/* 2614 */     this.tabs++;
/* 2615 */     println("IToken _token = null;");
/* 2616 */     println("int _ttype = Token.INVALID_TYPE;");
/* 2617 */     if (((LexerGrammar)this.grammar).filterMode) {
/* 2618 */       println("setCommitToPath(false);");
/* 2619 */       if (str1 != null) {
/*      */         
/* 2621 */         if (!this.grammar.isDefined(CodeGenerator.encodeLexerRuleName(str1))) {
/* 2622 */           this.grammar.antlrTool.error("Filter rule " + str1 + " does not exist in this lexer");
/*      */         } else {
/*      */           
/* 2625 */           RuleSymbol ruleSymbol1 = (RuleSymbol)this.grammar.getSymbol(CodeGenerator.encodeLexerRuleName(str1));
/* 2626 */           if (!ruleSymbol1.isDefined()) {
/* 2627 */             this.grammar.antlrTool.error("Filter rule " + str1 + " does not exist in this lexer");
/*      */           }
/* 2629 */           else if (ruleSymbol1.access.equals("public")) {
/* 2630 */             this.grammar.antlrTool.error("Filter rule " + str1 + " must be protected");
/*      */           } 
/*      */         } 
/* 2633 */         println("int _m;");
/* 2634 */         println("_m = mark();");
/*      */       } 
/*      */     } 
/* 2637 */     println("resetText();");
/*      */     
/* 2639 */     println("try     // for char stream error handling");
/* 2640 */     println("{");
/* 2641 */     this.tabs++;
/*      */ 
/*      */     
/* 2644 */     println("try     // for lexical error handling");
/* 2645 */     println("{");
/* 2646 */     this.tabs++;
/*      */ 
/*      */     
/* 2649 */     for (byte b2 = 0; b2 < ruleBlock.getAlternatives().size(); b2++) {
/* 2650 */       Alternative alternative = ruleBlock.getAlternativeAt(b2);
/* 2651 */       if (alternative.cache[1].containsEpsilon()) {
/*      */         
/* 2653 */         RuleRefElement ruleRefElement = (RuleRefElement)alternative.head;
/* 2654 */         String str = CodeGenerator.decodeLexerRuleName(ruleRefElement.targetRule);
/* 2655 */         this.antlrTool.warning("public lexical rule " + str + " is optional (can match \"nothing\")");
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/* 2660 */     String str2 = System.getProperty("line.separator");
/* 2661 */     CSharpBlockFinishingInfo cSharpBlockFinishingInfo = genCommonBlock(ruleBlock, false);
/* 2662 */     String str3 = "if (cached_LA1==EOF_CHAR) { uponEOF(); returnToken_ = makeToken(Token.EOF_TYPE); }";
/*      */     
/* 2664 */     str3 = str3 + str2 + "\t\t\t\t";
/* 2665 */     if (((LexerGrammar)this.grammar).filterMode) {
/* 2666 */       if (str1 == null) {
/*      */         
/* 2668 */         str3 = str3 + "\t\t\t\telse";
/* 2669 */         str3 = str3 + "\t\t\t\t{";
/* 2670 */         str3 = str3 + "\t\t\t\t\tconsume();";
/* 2671 */         str3 = str3 + "\t\t\t\t\tgoto tryAgain;";
/* 2672 */         str3 = str3 + "\t\t\t\t}";
/*      */       } else {
/*      */         
/* 2675 */         str3 = str3 + "\t\t\t\t\telse" + str2 + "\t\t\t\t\t{" + str2 + "\t\t\t\t\tcommit();" + str2 + "\t\t\t\t\ttry {m" + str1 + "(false);}" + str2 + "\t\t\t\t\tcatch(RecognitionException e)" + str2 + "\t\t\t\t\t{" + str2 + "\t\t\t\t\t\t// catastrophic failure" + str2 + "\t\t\t\t\t\treportError(e);" + str2 + "\t\t\t\t\t\tconsume();" + str2 + "\t\t\t\t\t}" + str2 + "\t\t\t\t\tgoto tryAgain;" + str2 + "\t\t\t\t}";
/*      */ 
/*      */ 
/*      */       
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     }
/*      */     else {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2690 */       str3 = str3 + "else {" + this.throwNoViable + "}";
/*      */     } 
/* 2692 */     genBlockFinish(cSharpBlockFinishingInfo, str3);
/*      */ 
/*      */     
/* 2695 */     if (((LexerGrammar)this.grammar).filterMode && str1 != null) {
/* 2696 */       println("commit();");
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2702 */     println("if ( null==returnToken_ ) goto tryAgain; // found SKIP token");
/* 2703 */     println("_ttype = returnToken_.Type;");
/* 2704 */     if (((LexerGrammar)this.grammar).getTestLiterals()) {
/* 2705 */       genLiteralsTest();
/*      */     }
/*      */ 
/*      */     
/* 2709 */     println("returnToken_.Type = _ttype;");
/* 2710 */     println("return returnToken_;");
/*      */ 
/*      */     
/* 2713 */     this.tabs--;
/* 2714 */     println("}");
/* 2715 */     println("catch (RecognitionException e) {");
/* 2716 */     this.tabs++;
/* 2717 */     if (((LexerGrammar)this.grammar).filterMode) {
/* 2718 */       if (str1 == null) {
/* 2719 */         println("if (!getCommitToPath())");
/* 2720 */         println("{");
/* 2721 */         this.tabs++;
/* 2722 */         println("consume();");
/* 2723 */         println("goto tryAgain;");
/* 2724 */         this.tabs--;
/* 2725 */         println("}");
/*      */       } else {
/*      */         
/* 2728 */         println("if (!getCommitToPath())");
/* 2729 */         println("{");
/* 2730 */         this.tabs++;
/* 2731 */         println("rewind(_m);");
/* 2732 */         println("resetText();");
/* 2733 */         println("try {m" + str1 + "(false);}");
/* 2734 */         println("catch(RecognitionException ee) {");
/* 2735 */         println("\t// horrendous failure: error in filter rule");
/* 2736 */         println("\treportError(ee);");
/* 2737 */         println("\tconsume();");
/* 2738 */         println("}");
/*      */         
/* 2740 */         this.tabs--;
/* 2741 */         println("}");
/* 2742 */         println("else");
/*      */       } 
/*      */     }
/* 2745 */     if (ruleBlock.getDefaultErrorHandler()) {
/* 2746 */       println("{");
/* 2747 */       this.tabs++;
/* 2748 */       println("reportError(e);");
/* 2749 */       println("consume();");
/* 2750 */       this.tabs--;
/* 2751 */       println("}");
/*      */     }
/*      */     else {
/*      */       
/* 2755 */       this.tabs++;
/* 2756 */       println("throw new TokenStreamRecognitionException(e);");
/* 2757 */       this.tabs--;
/*      */     } 
/* 2759 */     this.tabs--;
/* 2760 */     println("}");
/*      */ 
/*      */     
/* 2763 */     this.tabs--;
/* 2764 */     println("}");
/* 2765 */     println("catch (CharStreamException cse) {");
/* 2766 */     println("\tif ( cse is CharStreamIOException ) {");
/* 2767 */     println("\t\tthrow new TokenStreamIOException(((CharStreamIOException)cse).io);");
/* 2768 */     println("\t}");
/* 2769 */     println("\telse {");
/* 2770 */     println("\t\tthrow new TokenStreamException(cse.Message);");
/* 2771 */     println("\t}");
/* 2772 */     println("}");
/*      */ 
/*      */     
/* 2775 */     this.tabs--;
/* 2776 */     println("}");
/*      */ 
/*      */     
/* 2779 */     this.tabs--;
/* 2780 */     println("}");
/* 2781 */     println("");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void genRule(RuleSymbol paramRuleSymbol, boolean paramBoolean, int paramInt, TokenManager paramTokenManager) {
/* 2800 */     this.tabs = 1;
/* 2801 */     if (this.DEBUG_CODE_GENERATOR) System.out.println("genRule(" + paramRuleSymbol.getId() + ")"); 
/* 2802 */     if (!paramRuleSymbol.isDefined()) {
/* 2803 */       this.antlrTool.error("undefined rule: " + paramRuleSymbol.getId());
/*      */       
/*      */       return;
/*      */     } 
/*      */     
/* 2808 */     RuleBlock ruleBlock = paramRuleSymbol.getBlock();
/* 2809 */     this.currentRule = ruleBlock;
/* 2810 */     this.currentASTResult = paramRuleSymbol.getId();
/*      */ 
/*      */     
/* 2813 */     this.declaredASTVariables.clear();
/*      */ 
/*      */     
/* 2816 */     boolean bool = this.genAST;
/* 2817 */     this.genAST = (this.genAST && ruleBlock.getAutoGen());
/*      */ 
/*      */     
/* 2820 */     this.saveText = ruleBlock.getAutoGen();
/*      */ 
/*      */     
/* 2823 */     if (paramRuleSymbol.comment != null) {
/* 2824 */       _println(paramRuleSymbol.comment);
/*      */     }
/*      */ 
/*      */ 
/*      */     
/* 2829 */     print(paramRuleSymbol.access + " ");
/*      */ 
/*      */     
/* 2832 */     if (ruleBlock.returnAction != null) {
/*      */ 
/*      */       
/* 2835 */       _print(extractTypeOfAction(ruleBlock.returnAction, ruleBlock.getLine(), ruleBlock.getColumn()) + " ");
/*      */     } else {
/*      */       
/* 2838 */       _print("void ");
/*      */     } 
/*      */ 
/*      */     
/* 2842 */     _print(paramRuleSymbol.getId() + "(");
/*      */ 
/*      */     
/* 2845 */     _print(this.commonExtraParams);
/* 2846 */     if (this.commonExtraParams.length() != 0 && ruleBlock.argAction != null) {
/* 2847 */       _print(",");
/*      */     }
/*      */ 
/*      */     
/* 2851 */     if (ruleBlock.argAction != null) {
/*      */ 
/*      */       
/* 2854 */       _println("");
/* 2855 */       this.tabs++;
/* 2856 */       println(ruleBlock.argAction);
/* 2857 */       this.tabs--;
/* 2858 */       print(")");
/*      */     }
/*      */     else {
/*      */       
/* 2862 */       _print(")");
/*      */     } 
/*      */ 
/*      */     
/* 2866 */     _print(" //throws " + this.exceptionThrown);
/* 2867 */     if (this.grammar instanceof ParserGrammar) {
/* 2868 */       _print(", TokenStreamException");
/*      */     }
/* 2870 */     else if (this.grammar instanceof LexerGrammar) {
/* 2871 */       _print(", CharStreamException, TokenStreamException");
/*      */     } 
/*      */     
/* 2874 */     if (ruleBlock.throwsSpec != null) {
/* 2875 */       if (this.grammar instanceof LexerGrammar) {
/* 2876 */         this.antlrTool.error("user-defined throws spec not allowed (yet) for lexer rule " + ruleBlock.ruleName);
/*      */       } else {
/*      */         
/* 2879 */         _print(", " + ruleBlock.throwsSpec);
/*      */       } 
/*      */     }
/*      */     
/* 2883 */     _println("");
/* 2884 */     _println("{");
/* 2885 */     this.tabs++;
/*      */ 
/*      */     
/* 2888 */     if (ruleBlock.returnAction != null) {
/* 2889 */       println(ruleBlock.returnAction + ";");
/*      */     }
/*      */     
/* 2892 */     println(this.commonLocalVars);
/*      */     
/* 2894 */     if (this.grammar.traceRules) {
/* 2895 */       if (this.grammar instanceof TreeWalkerGrammar) {
/* 2896 */         if (this.usingCustomAST) {
/* 2897 */           println("traceIn(\"" + paramRuleSymbol.getId() + "\",(AST)_t);");
/*      */         } else {
/* 2899 */           println("traceIn(\"" + paramRuleSymbol.getId() + "\",_t);");
/*      */         } 
/*      */       } else {
/* 2902 */         println("traceIn(\"" + paramRuleSymbol.getId() + "\");");
/*      */       } 
/*      */     }
/*      */     
/* 2906 */     if (this.grammar instanceof LexerGrammar) {
/*      */ 
/*      */       
/* 2909 */       if (paramRuleSymbol.getId().equals("mEOF")) {
/* 2910 */         println("_ttype = Token.EOF_TYPE;");
/*      */       } else {
/* 2912 */         println("_ttype = " + paramRuleSymbol.getId().substring(1) + ";");
/*      */       } 
/*      */       
/* 2915 */       this.blockNestingLevel = 1;
/* 2916 */       this.saveIndexCreateLevel = 0;
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2927 */     if (this.grammar.debuggingOutput) {
/* 2928 */       if (this.grammar instanceof ParserGrammar) {
/* 2929 */         println("fireEnterRule(" + paramInt + ",0);");
/* 2930 */       } else if (this.grammar instanceof LexerGrammar) {
/* 2931 */         println("fireEnterRule(" + paramInt + ",_ttype);");
/*      */       } 
/*      */     }
/*      */     
/* 2935 */     if (this.grammar.debuggingOutput || this.grammar.traceRules) {
/* 2936 */       println("try { // debugging");
/* 2937 */       this.tabs++;
/*      */     } 
/*      */ 
/*      */     
/* 2941 */     if (this.grammar instanceof TreeWalkerGrammar)
/*      */     {
/* 2943 */       println(this.labeledElementASTType + " " + paramRuleSymbol.getId() + "_AST_in = (" + this.labeledElementASTType + ")_t;");
/*      */     }
/* 2945 */     if (this.grammar.buildAST) {
/*      */       
/* 2947 */       println("returnAST = null;");
/*      */ 
/*      */       
/* 2950 */       println("ASTPair currentAST = new ASTPair();");
/*      */       
/* 2952 */       println(this.labeledElementASTType + " " + paramRuleSymbol.getId() + "_AST = null;");
/*      */     } 
/*      */     
/* 2955 */     genBlockPreamble(ruleBlock);
/* 2956 */     genBlockInitAction(ruleBlock);
/* 2957 */     println("");
/*      */ 
/*      */     
/* 2960 */     ExceptionSpec exceptionSpec = ruleBlock.findExceptionSpec("");
/*      */ 
/*      */     
/* 2963 */     if (exceptionSpec != null || ruleBlock.getDefaultErrorHandler()) {
/* 2964 */       println("try {      // for error handling");
/* 2965 */       this.tabs++;
/*      */     } 
/*      */ 
/*      */     
/* 2969 */     if (ruleBlock.alternatives.size() == 1) {
/*      */ 
/*      */       
/* 2972 */       Alternative alternative = ruleBlock.getAlternativeAt(0);
/* 2973 */       String str = alternative.semPred;
/* 2974 */       if (str != null)
/* 2975 */         genSemPred(str, this.currentRule.line); 
/* 2976 */       if (alternative.synPred != null) {
/* 2977 */         this.antlrTool.warning("Syntactic predicate ignored for single alternative", this.grammar.getFilename(), alternative.synPred.getLine(), alternative.synPred.getColumn());
/*      */       }
/*      */ 
/*      */ 
/*      */       
/* 2982 */       genAlt(alternative, ruleBlock);
/*      */     
/*      */     }
/*      */     else {
/*      */       
/* 2987 */       boolean bool1 = this.grammar.theLLkAnalyzer.deterministic(ruleBlock);
/*      */       
/* 2989 */       CSharpBlockFinishingInfo cSharpBlockFinishingInfo = genCommonBlock(ruleBlock, false);
/* 2990 */       genBlockFinish(cSharpBlockFinishingInfo, this.throwNoViable);
/*      */     } 
/*      */ 
/*      */     
/* 2994 */     if (exceptionSpec != null || ruleBlock.getDefaultErrorHandler()) {
/*      */       
/* 2996 */       this.tabs--;
/* 2997 */       println("}");
/*      */     } 
/*      */ 
/*      */     
/* 3001 */     if (exceptionSpec != null) {
/*      */       
/* 3003 */       genErrorHandler(exceptionSpec);
/*      */     }
/* 3005 */     else if (ruleBlock.getDefaultErrorHandler()) {
/*      */ 
/*      */       
/* 3008 */       println("catch (" + this.exceptionThrown + " ex)");
/* 3009 */       println("{");
/* 3010 */       this.tabs++;
/*      */       
/* 3012 */       if (this.grammar.hasSyntacticPredicate) {
/* 3013 */         println("if (0 == inputState.guessing)");
/* 3014 */         println("{");
/* 3015 */         this.tabs++;
/*      */       } 
/* 3017 */       println("reportError(ex);");
/* 3018 */       if (!(this.grammar instanceof TreeWalkerGrammar)) {
/*      */ 
/*      */         
/* 3021 */         Lookahead lookahead = this.grammar.theLLkAnalyzer.FOLLOW(1, ruleBlock.endNode);
/* 3022 */         String str = getBitsetName(markBitsetForGen(lookahead.fset));
/* 3023 */         println("recover(ex," + str + ");");
/*      */       
/*      */       }
/*      */       else {
/*      */         
/* 3028 */         println("if (null != _t)");
/* 3029 */         println("{");
/* 3030 */         this.tabs++;
/* 3031 */         println("_t = _t.getNextSibling();");
/* 3032 */         this.tabs--;
/* 3033 */         println("}");
/*      */       } 
/* 3035 */       if (this.grammar.hasSyntacticPredicate) {
/*      */         
/* 3037 */         this.tabs--;
/*      */         
/* 3039 */         println("}");
/* 3040 */         println("else");
/* 3041 */         println("{");
/* 3042 */         this.tabs++;
/* 3043 */         println("throw ex;");
/* 3044 */         this.tabs--;
/* 3045 */         println("}");
/*      */       } 
/*      */       
/* 3048 */       this.tabs--;
/* 3049 */       println("}");
/*      */     } 
/*      */ 
/*      */     
/* 3053 */     if (this.grammar.buildAST) {
/* 3054 */       println("returnAST = " + paramRuleSymbol.getId() + "_AST;");
/*      */     }
/*      */ 
/*      */     
/* 3058 */     if (this.grammar instanceof TreeWalkerGrammar) {
/* 3059 */       println("retTree_ = _t;");
/*      */     }
/*      */ 
/*      */     
/* 3063 */     if (ruleBlock.getTestLiterals()) {
/* 3064 */       if (paramRuleSymbol.access.equals("protected")) {
/* 3065 */         genLiteralsTestForPartialToken();
/*      */       } else {
/*      */         
/* 3068 */         genLiteralsTest();
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/* 3073 */     if (this.grammar instanceof LexerGrammar) {
/* 3074 */       println("if (_createToken && (null == _token) && (_ttype != Token.SKIP))");
/* 3075 */       println("{");
/* 3076 */       this.tabs++;
/* 3077 */       println("_token = makeToken(_ttype);");
/* 3078 */       println("_token.setText(text.ToString(_begin, text.Length-_begin));");
/* 3079 */       this.tabs--;
/* 3080 */       println("}");
/* 3081 */       println("returnToken_ = _token;");
/*      */     } 
/*      */ 
/*      */     
/* 3085 */     if (ruleBlock.returnAction != null) {
/* 3086 */       println("return " + extractIdOfAction(ruleBlock.returnAction, ruleBlock.getLine(), ruleBlock.getColumn()) + ";");
/*      */     }
/*      */     
/* 3089 */     if (this.grammar.debuggingOutput || this.grammar.traceRules) {
/* 3090 */       this.tabs--;
/* 3091 */       println("}");
/* 3092 */       println("finally");
/* 3093 */       println("{ // debugging");
/* 3094 */       this.tabs++;
/*      */ 
/*      */       
/* 3097 */       if (this.grammar.debuggingOutput)
/* 3098 */         if (this.grammar instanceof ParserGrammar) {
/* 3099 */           println("fireExitRule(" + paramInt + ",0);");
/* 3100 */         } else if (this.grammar instanceof LexerGrammar) {
/* 3101 */           println("fireExitRule(" + paramInt + ",_ttype);");
/*      */         }  
/* 3103 */       if (this.grammar.traceRules) {
/* 3104 */         if (this.grammar instanceof TreeWalkerGrammar) {
/* 3105 */           println("traceOut(\"" + paramRuleSymbol.getId() + "\",_t);");
/*      */         } else {
/*      */           
/* 3108 */           println("traceOut(\"" + paramRuleSymbol.getId() + "\");");
/*      */         } 
/*      */       }
/*      */       
/* 3112 */       this.tabs--;
/* 3113 */       println("}");
/*      */     } 
/*      */     
/* 3116 */     this.tabs--;
/* 3117 */     println("}");
/* 3118 */     println("");
/*      */ 
/*      */     
/* 3121 */     this.genAST = bool;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void GenRuleInvocation(RuleRefElement paramRuleRefElement) {
/* 3128 */     _print(paramRuleRefElement.targetRule + "(");
/*      */ 
/*      */     
/* 3131 */     if (this.grammar instanceof LexerGrammar) {
/*      */       
/* 3133 */       if (paramRuleRefElement.getLabel() != null) {
/* 3134 */         _print("true");
/*      */       } else {
/*      */         
/* 3137 */         _print("false");
/*      */       } 
/* 3139 */       if (this.commonExtraArgs.length() != 0 || paramRuleRefElement.args != null) {
/* 3140 */         _print(",");
/*      */       }
/*      */     } 
/*      */ 
/*      */     
/* 3145 */     _print(this.commonExtraArgs);
/* 3146 */     if (this.commonExtraArgs.length() != 0 && paramRuleRefElement.args != null) {
/* 3147 */       _print(",");
/*      */     }
/*      */ 
/*      */     
/* 3151 */     RuleSymbol ruleSymbol = (RuleSymbol)this.grammar.getSymbol(paramRuleRefElement.targetRule);
/* 3152 */     if (paramRuleRefElement.args != null) {
/*      */ 
/*      */       
/* 3155 */       ActionTransInfo actionTransInfo = new ActionTransInfo();
/* 3156 */       String str = processActionForSpecialSymbols(paramRuleRefElement.args, 0, this.currentRule, actionTransInfo);
/* 3157 */       if (actionTransInfo.assignToRoot || actionTransInfo.refRuleRoot != null)
/*      */       {
/* 3159 */         this.antlrTool.error("Arguments of rule reference '" + paramRuleRefElement.targetRule + "' cannot set or ref #" + this.currentRule.getRuleName(), this.grammar.getFilename(), paramRuleRefElement.getLine(), paramRuleRefElement.getColumn());
/*      */       }
/*      */       
/* 3162 */       _print(str);
/*      */ 
/*      */       
/* 3165 */       if (ruleSymbol.block.argAction == null)
/*      */       {
/* 3167 */         this.antlrTool.warning("Rule '" + paramRuleRefElement.targetRule + "' accepts no arguments", this.grammar.getFilename(), paramRuleRefElement.getLine(), paramRuleRefElement.getColumn());
/*      */ 
/*      */       
/*      */       }
/*      */ 
/*      */     
/*      */     }
/* 3174 */     else if (ruleSymbol.block.argAction != null) {
/*      */       
/* 3176 */       this.antlrTool.warning("Missing parameters on reference to rule " + paramRuleRefElement.targetRule, this.grammar.getFilename(), paramRuleRefElement.getLine(), paramRuleRefElement.getColumn());
/*      */     } 
/*      */     
/* 3179 */     _println(");");
/*      */ 
/*      */     
/* 3182 */     if (this.grammar instanceof TreeWalkerGrammar) {
/* 3183 */       println("_t = retTree_;");
/*      */     }
/*      */   }
/*      */   
/*      */   protected void genSemPred(String paramString, int paramInt) {
/* 3188 */     ActionTransInfo actionTransInfo = new ActionTransInfo();
/* 3189 */     paramString = processActionForSpecialSymbols(paramString, paramInt, this.currentRule, actionTransInfo);
/*      */     
/* 3191 */     String str = this.charFormatter.escapeString(paramString);
/*      */ 
/*      */ 
/*      */     
/* 3195 */     if (this.grammar.debuggingOutput && (this.grammar instanceof ParserGrammar || this.grammar instanceof LexerGrammar)) {
/* 3196 */       paramString = "fireSemanticPredicateEvaluated(antlr.debug.SemanticPredicateEvent.VALIDATING," + addSemPred(str) + "," + paramString + ")";
/*      */     }
/* 3198 */     println("if (!(" + paramString + "))");
/* 3199 */     println("  throw new SemanticException(\"" + str + "\");");
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected void genSemPredMap() {
/* 3205 */     Enumeration enumeration = this.semPreds.elements();
/* 3206 */     println("private string[] _semPredNames = {");
/* 3207 */     this.tabs++;
/* 3208 */     while (enumeration.hasMoreElements())
/* 3209 */       println("\"" + enumeration.nextElement() + "\","); 
/* 3210 */     this.tabs--;
/* 3211 */     println("};");
/*      */   }
/*      */   protected void genSynPred(SynPredBlock paramSynPredBlock, String paramString) {
/* 3214 */     if (this.DEBUG_CODE_GENERATOR) System.out.println("gen=>(" + paramSynPredBlock + ")");
/*      */ 
/*      */     
/* 3217 */     println("bool synPredMatched" + paramSynPredBlock.ID + " = false;");
/*      */     
/* 3219 */     if (this.grammar instanceof TreeWalkerGrammar) {
/* 3220 */       println("if (_t==null) _t=ASTNULL;");
/*      */     }
/*      */     
/* 3223 */     println("if (" + paramString + ")");
/* 3224 */     println("{");
/* 3225 */     this.tabs++;
/*      */ 
/*      */     
/* 3228 */     if (this.grammar instanceof TreeWalkerGrammar) {
/* 3229 */       println("AST __t" + paramSynPredBlock.ID + " = _t;");
/*      */     } else {
/*      */       
/* 3232 */       println("int _m" + paramSynPredBlock.ID + " = mark();");
/*      */     } 
/*      */ 
/*      */     
/* 3236 */     println("synPredMatched" + paramSynPredBlock.ID + " = true;");
/* 3237 */     println("inputState.guessing++;");
/*      */ 
/*      */     
/* 3240 */     if (this.grammar.debuggingOutput && (this.grammar instanceof ParserGrammar || this.grammar instanceof LexerGrammar))
/*      */     {
/* 3242 */       println("fireSyntacticPredicateStarted();");
/*      */     }
/*      */     
/* 3245 */     this.syntacticPredLevel++;
/* 3246 */     println("try {");
/* 3247 */     this.tabs++;
/* 3248 */     gen(paramSynPredBlock);
/* 3249 */     this.tabs--;
/*      */     
/* 3251 */     println("}");
/*      */ 
/*      */     
/* 3254 */     println("catch (" + this.exceptionThrown + ")");
/* 3255 */     println("{");
/* 3256 */     this.tabs++;
/* 3257 */     println("synPredMatched" + paramSynPredBlock.ID + " = false;");
/*      */     
/* 3259 */     this.tabs--;
/* 3260 */     println("}");
/*      */ 
/*      */     
/* 3263 */     if (this.grammar instanceof TreeWalkerGrammar) {
/* 3264 */       println("_t = __t" + paramSynPredBlock.ID + ";");
/*      */     } else {
/*      */       
/* 3267 */       println("rewind(_m" + paramSynPredBlock.ID + ");");
/*      */     } 
/*      */     
/* 3270 */     println("inputState.guessing--;");
/*      */ 
/*      */     
/* 3273 */     if (this.grammar.debuggingOutput && (this.grammar instanceof ParserGrammar || this.grammar instanceof LexerGrammar)) {
/*      */       
/* 3275 */       println("if (synPredMatched" + paramSynPredBlock.ID + ")");
/* 3276 */       println("  fireSyntacticPredicateSucceeded();");
/* 3277 */       println("else");
/* 3278 */       println("  fireSyntacticPredicateFailed();");
/*      */     } 
/*      */     
/* 3281 */     this.syntacticPredLevel--;
/* 3282 */     this.tabs--;
/*      */ 
/*      */     
/* 3285 */     println("}");
/*      */ 
/*      */     
/* 3288 */     println("if ( synPredMatched" + paramSynPredBlock.ID + " )");
/* 3289 */     println("{");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void genTokenStrings() {
/* 3302 */     println("");
/* 3303 */     println("public static readonly string[] tokenNames_ = new string[] {");
/* 3304 */     this.tabs++;
/*      */ 
/*      */ 
/*      */     
/* 3308 */     Vector vector = this.grammar.tokenManager.getVocabulary();
/* 3309 */     for (byte b = 0; b < vector.size(); b++) {
/*      */       
/* 3311 */       String str = (String)vector.elementAt(b);
/* 3312 */       if (str == null)
/*      */       {
/* 3314 */         str = "<" + String.valueOf(b) + ">";
/*      */       }
/* 3316 */       if (!str.startsWith("\"") && !str.startsWith("<")) {
/* 3317 */         TokenSymbol tokenSymbol = this.grammar.tokenManager.getTokenSymbol(str);
/* 3318 */         if (tokenSymbol != null && tokenSymbol.getParaphrase() != null) {
/* 3319 */           str = StringUtils.stripFrontBack(tokenSymbol.getParaphrase(), "\"", "\"");
/*      */         }
/*      */       }
/* 3322 */       else if (str.startsWith("\"")) {
/* 3323 */         str = StringUtils.stripFrontBack(str, "\"", "\"");
/*      */       } 
/* 3325 */       print(this.charFormatter.literalString(str));
/* 3326 */       if (b != vector.size() - 1) {
/* 3327 */         _print(",");
/*      */       }
/* 3329 */       _println("");
/*      */     } 
/*      */ 
/*      */     
/* 3333 */     this.tabs--;
/* 3334 */     println("};");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void genTokenTypes(TokenManager paramTokenManager) throws IOException {
/* 3341 */     setupOutput(paramTokenManager.getName() + TokenTypesFileSuffix);
/*      */     
/* 3343 */     this.tabs = 0;
/*      */ 
/*      */     
/* 3346 */     genHeader();
/*      */     
/* 3348 */     println(this.behavior.getHeaderAction(""));
/*      */ 
/*      */     
/* 3351 */     if (nameSpace != null)
/* 3352 */       nameSpace.emitDeclarations(this.currentOutput); 
/* 3353 */     this.tabs++;
/*      */ 
/*      */ 
/*      */     
/* 3357 */     println("public class " + paramTokenManager.getName() + TokenTypesFileSuffix);
/*      */     
/* 3359 */     println("{");
/* 3360 */     this.tabs++;
/*      */     
/* 3362 */     genTokenDefinitions(paramTokenManager);
/*      */ 
/*      */     
/* 3365 */     this.tabs--;
/* 3366 */     println("}");
/*      */     
/* 3368 */     this.tabs--;
/*      */     
/* 3370 */     if (nameSpace != null) {
/* 3371 */       nameSpace.emitClosures(this.currentOutput);
/*      */     }
/*      */     
/* 3374 */     this.currentOutput.close();
/* 3375 */     this.currentOutput = null;
/* 3376 */     exitIfError();
/*      */   }
/*      */   
/*      */   protected void genTokenDefinitions(TokenManager paramTokenManager) throws IOException {
/* 3380 */     Vector vector = paramTokenManager.getVocabulary();
/*      */ 
/*      */     
/* 3383 */     println("public const int EOF = 1;");
/* 3384 */     println("public const int NULL_TREE_LOOKAHEAD = 3;");
/*      */     
/* 3386 */     for (byte b = 4; b < vector.size(); b++) {
/* 3387 */       String str = (String)vector.elementAt(b);
/* 3388 */       if (str != null) {
/* 3389 */         if (str.startsWith("\"")) {
/*      */           
/* 3391 */           StringLiteralSymbol stringLiteralSymbol = (StringLiteralSymbol)paramTokenManager.getTokenSymbol(str);
/* 3392 */           if (stringLiteralSymbol == null) {
/* 3393 */             this.antlrTool.panic("String literal " + str + " not in symbol table");
/*      */           }
/* 3395 */           else if (stringLiteralSymbol.label != null) {
/* 3396 */             println("public const int " + stringLiteralSymbol.label + " = " + b + ";");
/*      */           } else {
/*      */             
/* 3399 */             String str1 = mangleLiteral(str);
/* 3400 */             if (str1 != null) {
/*      */               
/* 3402 */               println("public const int " + str1 + " = " + b + ";");
/*      */               
/* 3404 */               stringLiteralSymbol.label = str1;
/*      */             } else {
/*      */               
/* 3407 */               println("// " + str + " = " + b);
/*      */             }
/*      */           
/*      */           } 
/* 3411 */         } else if (!str.startsWith("<")) {
/* 3412 */           println("public const int " + str + " = " + b + ";");
/*      */         } 
/*      */       }
/*      */     } 
/* 3416 */     println("");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String processStringForASTConstructor(String paramString) {
/* 3434 */     if (this.usingCustomAST && (this.grammar instanceof TreeWalkerGrammar || this.grammar instanceof ParserGrammar) && !this.grammar.tokenManager.tokenDefined(paramString))
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 3440 */       return "(AST)" + paramString;
/*      */     }
/*      */ 
/*      */ 
/*      */     
/* 3445 */     return paramString;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getASTCreateString(Vector paramVector) {
/* 3453 */     if (paramVector.size() == 0) {
/* 3454 */       return "";
/*      */     }
/* 3456 */     StringBuffer stringBuffer = new StringBuffer();
/* 3457 */     stringBuffer.append("(" + this.labeledElementASTType + ") astFactory.make(");
/*      */     
/* 3459 */     stringBuffer.append(paramVector.elementAt(0));
/* 3460 */     for (byte b = 1; b < paramVector.size(); b++) {
/* 3461 */       stringBuffer.append(", " + paramVector.elementAt(b));
/*      */     }
/* 3463 */     stringBuffer.append(")");
/* 3464 */     return stringBuffer.toString();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getASTCreateString(GrammarAtom paramGrammarAtom, String paramString) {
/* 3472 */     String str = "astFactory.create(" + paramString + ")";
/*      */     
/* 3474 */     if (paramGrammarAtom == null) {
/* 3475 */       return getASTCreateString(paramString);
/*      */     }
/* 3477 */     if (paramGrammarAtom.getASTNodeType() != null) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 3485 */       TokenSymbol tokenSymbol = this.grammar.tokenManager.getTokenSymbol(paramGrammarAtom.getText());
/* 3486 */       if (tokenSymbol == null || tokenSymbol.getASTNodeType() != paramGrammarAtom.getASTNodeType()) {
/* 3487 */         str = "(" + paramGrammarAtom.getASTNodeType() + ") astFactory.create(" + paramString + ", \"" + paramGrammarAtom.getASTNodeType() + "\")";
/* 3488 */       } else if (tokenSymbol != null && tokenSymbol.getASTNodeType() != null) {
/* 3489 */         str = "(" + tokenSymbol.getASTNodeType() + ") " + str;
/*      */       } 
/* 3491 */     } else if (this.usingCustomAST) {
/* 3492 */       str = "(" + this.labeledElementASTType + ") " + str;
/*      */     } 
/* 3494 */     return str;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getASTCreateString(String paramString) {
/* 3528 */     if (paramString == null) {
/* 3529 */       paramString = "";
/*      */     }
/* 3531 */     String str1 = "astFactory.create(" + paramString + ")";
/* 3532 */     String str2 = paramString;
/* 3533 */     String str3 = null;
/*      */     
/* 3535 */     boolean bool = false;
/*      */     
/* 3537 */     int i = paramString.indexOf(',');
/* 3538 */     if (i != -1) {
/* 3539 */       str2 = paramString.substring(0, i);
/* 3540 */       str3 = paramString.substring(i + 1, paramString.length());
/* 3541 */       i = str3.indexOf(',');
/* 3542 */       if (i != -1)
/*      */       {
/*      */ 
/*      */         
/* 3546 */         bool = true;
/*      */       }
/*      */     } 
/* 3549 */     TokenSymbol tokenSymbol = this.grammar.tokenManager.getTokenSymbol(str2);
/* 3550 */     if (null != tokenSymbol && null != tokenSymbol.getASTNodeType()) {
/* 3551 */       str1 = "(" + tokenSymbol.getASTNodeType() + ") " + str1;
/* 3552 */     } else if (this.usingCustomAST) {
/* 3553 */       str1 = "(" + this.labeledElementASTType + ") " + str1;
/*      */     } 
/* 3555 */     return str1;
/*      */   }
/*      */   
/*      */   protected String getLookaheadTestExpression(Lookahead[] paramArrayOfLookahead, int paramInt) {
/* 3559 */     StringBuffer stringBuffer = new StringBuffer(100);
/* 3560 */     boolean bool = true;
/*      */     
/* 3562 */     stringBuffer.append("(");
/* 3563 */     for (byte b = 1; b <= paramInt; b++) {
/* 3564 */       BitSet bitSet = (paramArrayOfLookahead[b]).fset;
/* 3565 */       if (!bool) {
/* 3566 */         stringBuffer.append(") && (");
/*      */       }
/* 3568 */       bool = false;
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 3573 */       if (paramArrayOfLookahead[b].containsEpsilon()) {
/* 3574 */         stringBuffer.append("true");
/*      */       } else {
/* 3576 */         stringBuffer.append(getLookaheadTestTerm(b, bitSet));
/*      */       } 
/*      */     } 
/* 3579 */     stringBuffer.append(")");
/*      */     
/* 3581 */     return stringBuffer.toString();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected String getLookaheadTestExpression(Alternative paramAlternative, int paramInt) {
/* 3589 */     int i = paramAlternative.lookaheadDepth;
/* 3590 */     if (i == Integer.MAX_VALUE)
/*      */     {
/*      */       
/* 3593 */       i = this.grammar.maxk;
/*      */     }
/*      */     
/* 3596 */     if (paramInt == 0)
/*      */     {
/*      */       
/* 3599 */       return "( true )";
/*      */     }
/* 3601 */     return "(" + getLookaheadTestExpression(paramAlternative.cache, i) + ")";
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected String getLookaheadTestTerm(int paramInt, BitSet paramBitSet) {
/* 3614 */     String str = lookaheadString(paramInt);
/*      */ 
/*      */     
/* 3617 */     int[] arrayOfInt = paramBitSet.toArray();
/* 3618 */     if (elementsAreRange(arrayOfInt)) {
/* 3619 */       return getRangeExpression(paramInt, arrayOfInt);
/*      */     }
/*      */ 
/*      */ 
/*      */     
/* 3624 */     int i = paramBitSet.degree();
/* 3625 */     if (i == 0) {
/* 3626 */       return "true";
/*      */     }
/*      */     
/* 3629 */     if (i >= this.bitsetTestThreshold) {
/* 3630 */       int j = markBitsetForGen(paramBitSet);
/* 3631 */       return getBitsetName(j) + ".member(" + str + ")";
/*      */     } 
/*      */ 
/*      */     
/* 3635 */     StringBuffer stringBuffer = new StringBuffer();
/* 3636 */     for (byte b = 0; b < arrayOfInt.length; b++) {
/*      */       
/* 3638 */       String str1 = getValueString(arrayOfInt[b]);
/*      */ 
/*      */       
/* 3641 */       if (b > 0) stringBuffer.append("||"); 
/* 3642 */       stringBuffer.append(str);
/* 3643 */       stringBuffer.append("==");
/* 3644 */       stringBuffer.append(str1);
/*      */     } 
/* 3646 */     return stringBuffer.toString();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getRangeExpression(int paramInt, int[] paramArrayOfint) {
/* 3655 */     if (!elementsAreRange(paramArrayOfint)) {
/* 3656 */       this.antlrTool.panic("getRangeExpression called with non-range");
/*      */     }
/* 3658 */     int i = paramArrayOfint[0];
/* 3659 */     int j = paramArrayOfint[paramArrayOfint.length - 1];
/*      */     
/* 3661 */     return "(" + lookaheadString(paramInt) + " >= " + getValueString(i) + " && " + lookaheadString(paramInt) + " <= " + getValueString(j) + ")";
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private String getValueString(int paramInt) {
/*      */     String str;
/* 3671 */     if (this.grammar instanceof LexerGrammar) {
/* 3672 */       str = this.charFormatter.literalChar(paramInt);
/*      */     }
/*      */     else {
/*      */       
/* 3676 */       TokenSymbol tokenSymbol = this.grammar.tokenManager.getTokenSymbolAt(paramInt);
/* 3677 */       if (tokenSymbol == null) {
/* 3678 */         return "" + paramInt;
/*      */       }
/*      */       
/* 3681 */       String str1 = tokenSymbol.getId();
/* 3682 */       if (tokenSymbol instanceof StringLiteralSymbol) {
/*      */ 
/*      */ 
/*      */         
/* 3686 */         StringLiteralSymbol stringLiteralSymbol = (StringLiteralSymbol)tokenSymbol;
/* 3687 */         String str2 = stringLiteralSymbol.getLabel();
/* 3688 */         if (str2 != null) {
/* 3689 */           str = str2;
/*      */         } else {
/*      */           
/* 3692 */           str = mangleLiteral(str1);
/* 3693 */           if (str == null) {
/* 3694 */             str = String.valueOf(paramInt);
/*      */           }
/*      */         } 
/*      */       } else {
/*      */         
/* 3699 */         str = str1;
/*      */       } 
/*      */     } 
/* 3702 */     return str;
/*      */   }
/*      */ 
/*      */   
/*      */   protected boolean lookaheadIsEmpty(Alternative paramAlternative, int paramInt) {
/* 3707 */     int i = paramAlternative.lookaheadDepth;
/* 3708 */     if (i == Integer.MAX_VALUE) {
/* 3709 */       i = this.grammar.maxk;
/*      */     }
/* 3711 */     for (byte b = 1; b <= i && b <= paramInt; b++) {
/* 3712 */       BitSet bitSet = (paramAlternative.cache[b]).fset;
/* 3713 */       if (bitSet.degree() != 0) {
/* 3714 */         return false;
/*      */       }
/*      */     } 
/* 3717 */     return true;
/*      */   }
/*      */   
/*      */   private String lookaheadString(int paramInt) {
/* 3721 */     if (this.grammar instanceof TreeWalkerGrammar) {
/* 3722 */       return "_t.Type";
/*      */     }
/* 3724 */     if (this.grammar instanceof LexerGrammar) {
/* 3725 */       if (paramInt == 1) {
/* 3726 */         return "cached_LA1";
/*      */       }
/* 3728 */       if (paramInt == 2) {
/* 3729 */         return "cached_LA2";
/*      */       }
/*      */     } 
/* 3732 */     return "LA(" + paramInt + ")";
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private String mangleLiteral(String paramString) {
/* 3742 */     String str = this.antlrTool.literalsPrefix;
/* 3743 */     for (byte b = 1; b < paramString.length() - 1; b++) {
/* 3744 */       if (!Character.isLetter(paramString.charAt(b)) && paramString.charAt(b) != '_')
/*      */       {
/* 3746 */         return null;
/*      */       }
/* 3748 */       str = str + paramString.charAt(b);
/*      */     } 
/* 3750 */     if (this.antlrTool.upperCaseMangledLiterals) {
/* 3751 */       str = str.toUpperCase();
/*      */     }
/* 3753 */     return str;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String mapTreeId(String paramString, ActionTransInfo paramActionTransInfo) {
/* 3764 */     if (this.currentRule == null) return paramString;
/*      */     
/* 3766 */     boolean bool = false;
/* 3767 */     String str1 = paramString;
/* 3768 */     if (this.grammar instanceof TreeWalkerGrammar)
/*      */     {
/* 3770 */       if (!this.grammar.buildAST) {
/*      */         
/* 3772 */         bool = true;
/*      */       
/*      */       }
/* 3775 */       else if (str1.length() > 3 && str1.lastIndexOf("_in") == str1.length() - 3) {
/*      */ 
/*      */         
/* 3778 */         str1 = str1.substring(0, str1.length() - 3);
/* 3779 */         bool = true;
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */     
/* 3785 */     for (byte b = 0; b < this.currentRule.labeledElements.size(); b++) {
/*      */       
/* 3787 */       AlternativeElement alternativeElement = (AlternativeElement)this.currentRule.labeledElements.elementAt(b);
/* 3788 */       if (alternativeElement.getLabel().equals(str1))
/*      */       {
/* 3790 */         return bool ? str1 : (str1 + "_AST");
/*      */       }
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 3797 */     String str2 = (String)this.treeVariableMap.get(str1);
/* 3798 */     if (str2 != null) {
/*      */       
/* 3800 */       if (str2 == NONUNIQUE) {
/*      */ 
/*      */         
/* 3803 */         this.antlrTool.error("Ambiguous reference to AST element " + str1 + " in rule " + this.currentRule.getRuleName());
/*      */         
/* 3805 */         return null;
/*      */       } 
/* 3807 */       if (str2.equals(this.currentRule.getRuleName())) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 3813 */         this.antlrTool.error("Ambiguous reference to AST element " + str1 + " in rule " + this.currentRule.getRuleName());
/*      */         
/* 3815 */         return null;
/*      */       } 
/*      */ 
/*      */       
/* 3819 */       return bool ? (str2 + "_in") : str2;
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 3825 */     if (str1.equals(this.currentRule.getRuleName())) {
/*      */       
/* 3827 */       String str = bool ? (str1 + "_AST_in") : (str1 + "_AST");
/* 3828 */       if (paramActionTransInfo != null && 
/* 3829 */         !bool) {
/* 3830 */         paramActionTransInfo.refRuleRoot = str;
/*      */       }
/*      */       
/* 3833 */       return str;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 3838 */     return str1;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void mapTreeVariable(AlternativeElement paramAlternativeElement, String paramString) {
/* 3848 */     if (paramAlternativeElement instanceof TreeElement) {
/* 3849 */       mapTreeVariable(((TreeElement)paramAlternativeElement).root, paramString);
/*      */       
/*      */       return;
/*      */     } 
/*      */     
/* 3854 */     String str = null;
/*      */ 
/*      */     
/* 3857 */     if (paramAlternativeElement.getLabel() == null) {
/* 3858 */       if (paramAlternativeElement instanceof TokenRefElement) {
/*      */         
/* 3860 */         str = ((TokenRefElement)paramAlternativeElement).atomText;
/*      */       }
/* 3862 */       else if (paramAlternativeElement instanceof RuleRefElement) {
/*      */         
/* 3864 */         str = ((RuleRefElement)paramAlternativeElement).targetRule;
/*      */       } 
/*      */     }
/*      */     
/* 3868 */     if (str != null) {
/* 3869 */       if (this.treeVariableMap.get(str) != null) {
/*      */         
/* 3871 */         this.treeVariableMap.remove(str);
/* 3872 */         this.treeVariableMap.put(str, NONUNIQUE);
/*      */       } else {
/*      */         
/* 3875 */         this.treeVariableMap.put(str, paramString);
/*      */       } 
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected String processActionForSpecialSymbols(String paramString, int paramInt, RuleBlock paramRuleBlock, ActionTransInfo paramActionTransInfo) {
/* 3889 */     if (paramString == null || paramString.length() == 0) {
/* 3890 */       return null;
/*      */     }
/*      */ 
/*      */     
/* 3894 */     if (this.grammar == null) {
/* 3895 */       return paramString;
/*      */     }
/*      */     
/* 3898 */     if ((this.grammar.buildAST && paramString.indexOf('#') != -1) || this.grammar instanceof TreeWalkerGrammar || ((this.grammar instanceof LexerGrammar || this.grammar instanceof ParserGrammar) && paramString.indexOf('$') != -1)) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 3905 */       ActionLexer actionLexer = new ActionLexer(paramString, paramRuleBlock, this, paramActionTransInfo);
/*      */       
/* 3907 */       actionLexer.setLineOffset(paramInt);
/* 3908 */       actionLexer.setFilename(this.grammar.getFilename());
/* 3909 */       actionLexer.setTool(this.antlrTool);
/*      */       
/*      */       try {
/* 3912 */         actionLexer.mACTION(true);
/* 3913 */         paramString = actionLexer.getTokenObject().getText();
/*      */ 
/*      */       
/*      */       }
/* 3917 */       catch (RecognitionException recognitionException) {
/* 3918 */         actionLexer.reportError(recognitionException);
/* 3919 */         return paramString;
/*      */       }
/* 3921 */       catch (TokenStreamException tokenStreamException) {
/* 3922 */         this.antlrTool.panic("Error reading action:" + paramString);
/* 3923 */         return paramString;
/*      */       }
/* 3925 */       catch (CharStreamException charStreamException) {
/* 3926 */         this.antlrTool.panic("Error reading action:" + paramString);
/* 3927 */         return paramString;
/*      */       } 
/*      */     } 
/* 3930 */     return paramString;
/*      */   }
/*      */   
/*      */   private void setupGrammarParameters(Grammar paramGrammar) {
/* 3934 */     if (paramGrammar instanceof ParserGrammar || paramGrammar instanceof LexerGrammar || paramGrammar instanceof TreeWalkerGrammar) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 3943 */       if (this.antlrTool.nameSpace != null) {
/* 3944 */         nameSpace = new CSharpNameSpace(this.antlrTool.nameSpace.getName());
/*      */       }
/*      */ 
/*      */ 
/*      */       
/* 3949 */       if (paramGrammar.hasOption("namespace")) {
/* 3950 */         Token token = paramGrammar.getOption("namespace");
/* 3951 */         if (token != null) {
/* 3952 */           nameSpace = new CSharpNameSpace(token.getText());
/*      */         }
/*      */       } 
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 3966 */     if (paramGrammar instanceof ParserGrammar) {
/* 3967 */       this.labeledElementASTType = "AST";
/* 3968 */       if (paramGrammar.hasOption("ASTLabelType")) {
/* 3969 */         Token token = paramGrammar.getOption("ASTLabelType");
/* 3970 */         if (token != null) {
/* 3971 */           String str = StringUtils.stripFrontBack(token.getText(), "\"", "\"");
/* 3972 */           if (str != null) {
/* 3973 */             this.usingCustomAST = true;
/* 3974 */             this.labeledElementASTType = str;
/*      */           } 
/*      */         } 
/*      */       } 
/* 3978 */       this.labeledElementType = "IToken ";
/* 3979 */       this.labeledElementInit = "null";
/* 3980 */       this.commonExtraArgs = "";
/* 3981 */       this.commonExtraParams = "";
/* 3982 */       this.commonLocalVars = "";
/* 3983 */       this.lt1Value = "LT(1)";
/* 3984 */       this.exceptionThrown = "RecognitionException";
/* 3985 */       this.throwNoViable = "throw new NoViableAltException(LT(1), getFilename());";
/*      */     }
/* 3987 */     else if (paramGrammar instanceof LexerGrammar) {
/* 3988 */       this.labeledElementType = "char ";
/* 3989 */       this.labeledElementInit = "'\\0'";
/* 3990 */       this.commonExtraArgs = "";
/* 3991 */       this.commonExtraParams = "bool _createToken";
/* 3992 */       this.commonLocalVars = "int _ttype; IToken _token=null; int _begin=text.Length;";
/* 3993 */       this.lt1Value = "cached_LA1";
/* 3994 */       this.exceptionThrown = "RecognitionException";
/* 3995 */       this.throwNoViable = "throw new NoViableAltForCharException(cached_LA1, getFilename(), getLine(), getColumn());";
/*      */     }
/* 3997 */     else if (paramGrammar instanceof TreeWalkerGrammar) {
/* 3998 */       this.labeledElementASTType = "AST";
/* 3999 */       this.labeledElementType = "AST";
/* 4000 */       if (paramGrammar.hasOption("ASTLabelType")) {
/* 4001 */         Token token = paramGrammar.getOption("ASTLabelType");
/* 4002 */         if (token != null) {
/* 4003 */           String str = StringUtils.stripFrontBack(token.getText(), "\"", "\"");
/* 4004 */           if (str != null) {
/* 4005 */             this.usingCustomAST = true;
/* 4006 */             this.labeledElementASTType = str;
/* 4007 */             this.labeledElementType = str;
/*      */           } 
/*      */         } 
/*      */       } 
/* 4011 */       if (!paramGrammar.hasOption("ASTLabelType")) {
/* 4012 */         paramGrammar.setOption("ASTLabelType", new Token(6, "AST"));
/*      */       }
/* 4014 */       this.labeledElementInit = "null";
/* 4015 */       this.commonExtraArgs = "_t";
/* 4016 */       this.commonExtraParams = "AST _t";
/* 4017 */       this.commonLocalVars = "";
/* 4018 */       if (this.usingCustomAST) {
/* 4019 */         this.lt1Value = "(_t==ASTNULL) ? null : (" + this.labeledElementASTType + ")_t";
/*      */       } else {
/* 4021 */         this.lt1Value = "_t";
/* 4022 */       }  this.exceptionThrown = "RecognitionException";
/* 4023 */       this.throwNoViable = "throw new NoViableAltException(_t);";
/*      */     } else {
/*      */       
/* 4026 */       this.antlrTool.panic("Unknown grammar type");
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setupOutput(String paramString) throws IOException {
/* 4036 */     this.currentOutput = this.antlrTool.openOutputFile(paramString + ".cs");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static String OctalToUnicode(String paramString) {
/* 4043 */     if (4 <= paramString.length() && '\'' == paramString.charAt(0) && '\\' == paramString.charAt(1) && '0' <= paramString.charAt(2) && '7' >= paramString.charAt(2) && '\'' == paramString.charAt(paramString.length() - 1)) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 4050 */       Integer integer = Integer.valueOf(paramString.substring(2, paramString.length() - 1), 8);
/*      */       
/* 4052 */       return "'\\x" + Integer.toHexString(integer.intValue()) + "'";
/*      */     } 
/*      */     
/* 4055 */     return paramString;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getTokenTypesClassName() {
/* 4064 */     TokenManager tokenManager = this.grammar.tokenManager;
/* 4065 */     return new String(tokenManager.getName() + TokenTypesFileSuffix);
/*      */   }
/*      */ 
/*      */   
/*      */   private void declareSaveIndexVariableIfNeeded() {
/* 4070 */     if (this.saveIndexCreateLevel == 0) {
/*      */       
/* 4072 */       println("int _saveIndex = 0;");
/* 4073 */       this.saveIndexCreateLevel = this.blockNestingLevel;
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public String[] split(String paramString1, String paramString2) {
/* 4079 */     StringTokenizer stringTokenizer = new StringTokenizer(paramString1, paramString2);
/* 4080 */     int i = stringTokenizer.countTokens();
/* 4081 */     String[] arrayOfString = new String[i];
/*      */     
/* 4083 */     byte b = 0;
/* 4084 */     while (stringTokenizer.hasMoreTokens()) {
/*      */       
/* 4086 */       arrayOfString[b] = stringTokenizer.nextToken();
/* 4087 */       b++;
/*      */     } 
/* 4089 */     return arrayOfString;
/*      */   }
/*      */ }


/* Location:              C:\Users\olatu\OneDrive\Documents\Calypso\syncbase\sync_base.jar!\BOOT-INF\lib\antlr-2.7.7.jar!\antlr\CSharpCodeGenerator.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */