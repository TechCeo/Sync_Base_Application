/*    */ package antlr.debug;
/*    */ 
/*    */ public class Tracer extends TraceAdapter implements TraceListener {
/*  4 */   String indent = "";
/*    */ 
/*    */   
/*    */   protected void dedent() {
/*  8 */     if (this.indent.length() < 2) {
/*  9 */       this.indent = "";
/*    */     } else {
/* 11 */       this.indent = this.indent.substring(2);
/*    */     } 
/*    */   } public void enterRule(TraceEvent paramTraceEvent) {
/* 14 */     System.out.println(this.indent + paramTraceEvent);
/* 15 */     indent();
/*    */   }
/*    */   public void exitRule(TraceEvent paramTraceEvent) {
/* 18 */     dedent();
/* 19 */     System.out.println(this.indent + paramTraceEvent);
/*    */   }
/*    */   protected void indent() {
/* 22 */     this.indent += "  ";
/*    */   }
/*    */ }


/* Location:              C:\Users\olatu\OneDrive\Documents\Calypso\syncbase\sync_base.jar!\BOOT-INF\lib\antlr-2.7.7.jar!\antlr\debug\Tracer.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */