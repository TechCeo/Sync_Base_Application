package antlr.debug;

public interface SemanticPredicateListener extends ListenerBase {
  void semanticPredicateEvaluated(SemanticPredicateEvent paramSemanticPredicateEvent);
}


/* Location:              C:\Users\olatu\OneDrive\Documents\Calypso\syncbase\sync_base.jar!\BOOT-INF\lib\antlr-2.7.7.jar!\antlr\debug\SemanticPredicateListener.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */