/*    */ package antlr.debug.misc;
/*    */ 
/*    */ import java.awt.BorderLayout;
/*    */ import javax.swing.JPanel;
/*    */ import javax.swing.JScrollPane;
/*    */ import javax.swing.JTree;
/*    */ import javax.swing.event.TreeSelectionListener;
/*    */ import javax.swing.tree.TreeModel;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class JTreeASTPanel
/*    */   extends JPanel
/*    */ {
/*    */   JTree tree;
/*    */   
/*    */   public JTreeASTPanel(TreeModel paramTreeModel, TreeSelectionListener paramTreeSelectionListener) {
/* 20 */     setLayout(new BorderLayout());
/*    */ 
/*    */     
/* 23 */     this.tree = new JTree(paramTreeModel);
/*    */ 
/*    */     
/* 26 */     this.tree.putClientProperty("JTree.lineStyle", "Angled");
/*    */ 
/*    */     
/* 29 */     if (paramTreeSelectionListener != null) {
/* 30 */       this.tree.addTreeSelectionListener(paramTreeSelectionListener);
/*    */     }
/*    */     
/* 33 */     JScrollPane jScrollPane = new JScrollPane();
/* 34 */     jScrollPane.getViewport().add(this.tree);
/*    */     
/* 36 */     add(jScrollPane, "Center");
/*    */   }
/*    */ }


/* Location:              C:\Users\olatu\OneDrive\Documents\Calypso\syncbase\sync_base.jar!\BOOT-INF\lib\antlr-2.7.7.jar!\antlr\debug\misc\JTreeASTPanel.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */