/*    */ package antlr;
/*    */ 
/*    */ import java.io.BufferedReader;
/*    */ import java.io.File;
/*    */ import java.io.FileNotFoundException;
/*    */ import java.io.FileReader;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class ImportVocabTokenManager
/*    */   extends SimpleTokenManager
/*    */   implements Cloneable
/*    */ {
/*    */   private String filename;
/*    */   protected Grammar grammar;
/*    */   
/*    */   ImportVocabTokenManager(Grammar paramGrammar, String paramString1, String paramString2, Tool paramTool) {
/* 25 */     super(paramString2, paramTool);
/*    */     
/* 27 */     this.grammar = paramGrammar;
/* 28 */     this.filename = paramString1;
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 33 */     File file = new File(this.filename);
/*    */     
/* 35 */     if (!file.exists()) {
/* 36 */       file = new File(this.antlrTool.getOutputDirectory(), this.filename);
/*    */       
/* 38 */       if (!file.exists()) {
/* 39 */         this.antlrTool.panic("Cannot find importVocab file '" + this.filename + "'");
/*    */       }
/*    */     } 
/*    */     
/* 43 */     setReadOnly(true);
/*    */ 
/*    */     
/*    */     try {
/* 47 */       BufferedReader bufferedReader = new BufferedReader(new FileReader(file));
/* 48 */       ANTLRTokdefLexer aNTLRTokdefLexer = new ANTLRTokdefLexer(bufferedReader);
/* 49 */       ANTLRTokdefParser aNTLRTokdefParser = new ANTLRTokdefParser(aNTLRTokdefLexer);
/* 50 */       aNTLRTokdefParser.setTool(this.antlrTool);
/* 51 */       aNTLRTokdefParser.setFilename(this.filename);
/* 52 */       aNTLRTokdefParser.file(this);
/*    */     }
/* 54 */     catch (FileNotFoundException fileNotFoundException) {
/* 55 */       this.antlrTool.panic("Cannot find importVocab file '" + this.filename + "'");
/*    */     }
/* 57 */     catch (RecognitionException recognitionException) {
/* 58 */       this.antlrTool.panic("Error parsing importVocab file '" + this.filename + "': " + recognitionException.toString());
/*    */     }
/* 60 */     catch (TokenStreamException tokenStreamException) {
/* 61 */       this.antlrTool.panic("Error reading importVocab file '" + this.filename + "'");
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   public Object clone() {
/* 67 */     ImportVocabTokenManager importVocabTokenManager = (ImportVocabTokenManager)super.clone();
/* 68 */     importVocabTokenManager.filename = this.filename;
/* 69 */     importVocabTokenManager.grammar = this.grammar;
/* 70 */     return importVocabTokenManager;
/*    */   }
/*    */ 
/*    */   
/*    */   public void define(TokenSymbol paramTokenSymbol) {
/* 75 */     super.define(paramTokenSymbol);
/*    */   }
/*    */ 
/*    */   
/*    */   public void define(String paramString, int paramInt) {
/* 80 */     TokenSymbol tokenSymbol = null;
/* 81 */     if (paramString.startsWith("\"")) {
/* 82 */       tokenSymbol = new StringLiteralSymbol(paramString);
/*    */     } else {
/*    */       
/* 85 */       tokenSymbol = new TokenSymbol(paramString);
/*    */     } 
/* 87 */     tokenSymbol.setTokenType(paramInt);
/* 88 */     super.define(tokenSymbol);
/* 89 */     this.maxToken = (paramInt + 1 > this.maxToken) ? (paramInt + 1) : this.maxToken;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean isReadOnly() {
/* 94 */     return this.readOnly;
/*    */   }
/*    */ 
/*    */   
/*    */   public int nextTokenType() {
/* 99 */     return super.nextTokenType();
/*    */   }
/*    */ }


/* Location:              C:\Users\olatu\OneDrive\Documents\Calypso\syncbase\sync_base.jar!\BOOT-INF\lib\antlr-2.7.7.jar!\antlr\ImportVocabTokenManager.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */