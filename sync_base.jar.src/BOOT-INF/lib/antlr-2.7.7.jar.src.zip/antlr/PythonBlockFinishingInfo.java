/*    */ package antlr;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class PythonBlockFinishingInfo
/*    */ {
/*    */   String postscript;
/*    */   boolean generatedSwitch;
/*    */   boolean generatedAnIf;
/*    */   boolean needAnErrorClause;
/*    */   
/*    */   public PythonBlockFinishingInfo() {
/* 23 */     this.postscript = null;
/* 24 */     this.generatedSwitch = false;
/* 25 */     this.needAnErrorClause = true;
/*    */   }
/*    */   
/*    */   public PythonBlockFinishingInfo(String paramString, boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3) {
/* 29 */     this.postscript = paramString;
/* 30 */     this.generatedSwitch = paramBoolean1;
/* 31 */     this.generatedAnIf = paramBoolean2;
/* 32 */     this.needAnErrorClause = paramBoolean3;
/*    */   }
/*    */ }


/* Location:              C:\Users\olatu\OneDrive\Documents\Calypso\syncbase\sync_base.jar!\BOOT-INF\lib\antlr-2.7.7.jar!\antlr\PythonBlockFinishingInfo.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */