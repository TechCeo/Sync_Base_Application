/*     */ package antlr;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class InputBuffer
/*     */ {
/*  32 */   protected int nMarkers = 0;
/*     */ 
/*     */   
/*  35 */   protected int markerOffset = 0;
/*     */ 
/*     */   
/*  38 */   protected int numToConsume = 0;
/*     */ 
/*     */   
/*     */   protected CharQueue queue;
/*     */ 
/*     */   
/*     */   public InputBuffer() {
/*  45 */     this.queue = new CharQueue(1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void commit() {
/*  55 */     this.nMarkers--;
/*     */   }
/*     */ 
/*     */   
/*     */   public void consume() {
/*  60 */     this.numToConsume++;
/*     */   }
/*     */ 
/*     */   
/*     */   public abstract void fill(int paramInt) throws CharStreamException;
/*     */   
/*     */   public String getLAChars() {
/*  67 */     StringBuffer stringBuffer = new StringBuffer();
/*  68 */     for (int i = this.markerOffset; i < this.queue.nbrEntries; i++)
/*  69 */       stringBuffer.append(this.queue.elementAt(i)); 
/*  70 */     return stringBuffer.toString();
/*     */   }
/*     */   
/*     */   public String getMarkedChars() {
/*  74 */     StringBuffer stringBuffer = new StringBuffer();
/*  75 */     for (byte b = 0; b < this.markerOffset; b++)
/*  76 */       stringBuffer.append(this.queue.elementAt(b)); 
/*  77 */     return stringBuffer.toString();
/*     */   }
/*     */   
/*     */   public boolean isMarked() {
/*  81 */     return (this.nMarkers != 0);
/*     */   }
/*     */ 
/*     */   
/*     */   public char LA(int paramInt) throws CharStreamException {
/*  86 */     fill(paramInt);
/*  87 */     return this.queue.elementAt(this.markerOffset + paramInt - 1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int mark() {
/*  94 */     syncConsume();
/*  95 */     this.nMarkers++;
/*  96 */     return this.markerOffset;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void rewind(int paramInt) {
/* 103 */     syncConsume();
/* 104 */     this.markerOffset = paramInt;
/* 105 */     this.nMarkers--;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void reset() {
/* 111 */     this.nMarkers = 0;
/* 112 */     this.markerOffset = 0;
/* 113 */     this.numToConsume = 0;
/* 114 */     this.queue.reset();
/*     */   }
/*     */ 
/*     */   
/*     */   protected void syncConsume() {
/* 119 */     while (this.numToConsume > 0) {
/* 120 */       if (this.nMarkers > 0) {
/*     */         
/* 122 */         this.markerOffset++;
/*     */       }
/*     */       else {
/*     */         
/* 126 */         this.queue.removeFirst();
/*     */       } 
/* 128 */       this.numToConsume--;
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\olatu\OneDrive\Documents\Calypso\syncbase\sync_base.jar!\BOOT-INF\lib\antlr-2.7.7.jar!\antlr\InputBuffer.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */