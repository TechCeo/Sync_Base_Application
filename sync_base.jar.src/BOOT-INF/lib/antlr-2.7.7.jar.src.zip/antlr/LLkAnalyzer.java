/*      */ package antlr;
/*      */ 
/*      */ import antlr.collections.impl.BitSet;
/*      */ import antlr.collections.impl.Vector;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class LLkAnalyzer
/*      */   implements LLkGrammarAnalyzer
/*      */ {
/*      */   public boolean DEBUG_ANALYZER = false;
/*      */   private AlternativeBlock currentBlock;
/*   25 */   protected Tool tool = null;
/*   26 */   protected Grammar grammar = null;
/*      */   
/*      */   protected boolean lexicalAnalysis = false;
/*      */   
/*   30 */   CharFormatter charFormatter = new JavaCharFormatter();
/*      */ 
/*      */   
/*      */   public LLkAnalyzer(Tool paramTool) {
/*   34 */     this.tool = paramTool;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean altUsesWildcardDefault(Alternative paramAlternative) {
/*   41 */     AlternativeElement alternativeElement = paramAlternative.head;
/*      */     
/*   43 */     if (alternativeElement instanceof TreeElement && ((TreeElement)alternativeElement).root instanceof WildcardElement)
/*      */     {
/*   45 */       return true;
/*      */     }
/*   47 */     if (alternativeElement instanceof WildcardElement && alternativeElement.next instanceof BlockEndElement) {
/*   48 */       return true;
/*      */     }
/*   50 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean deterministic(AlternativeBlock paramAlternativeBlock) {
/*   58 */     byte b1 = 1;
/*   59 */     if (this.DEBUG_ANALYZER) System.out.println("deterministic(" + paramAlternativeBlock + ")"); 
/*   60 */     boolean bool = true;
/*   61 */     int i = paramAlternativeBlock.alternatives.size();
/*   62 */     AlternativeBlock alternativeBlock = this.currentBlock;
/*   63 */     Alternative alternative = null;
/*   64 */     this.currentBlock = paramAlternativeBlock;
/*      */ 
/*      */     
/*   67 */     if (!paramAlternativeBlock.greedy && !(paramAlternativeBlock instanceof OneOrMoreBlock) && !(paramAlternativeBlock instanceof ZeroOrMoreBlock)) {
/*   68 */       this.tool.warning("Being nongreedy only makes sense for (...)+ and (...)*", this.grammar.getFilename(), paramAlternativeBlock.getLine(), paramAlternativeBlock.getColumn());
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*   74 */     if (i == 1) {
/*   75 */       AlternativeElement alternativeElement = (paramAlternativeBlock.getAlternativeAt(0)).head;
/*   76 */       this.currentBlock.alti = 0;
/*   77 */       (paramAlternativeBlock.getAlternativeAt(0)).cache[1] = alternativeElement.look(1);
/*   78 */       (paramAlternativeBlock.getAlternativeAt(0)).lookaheadDepth = 1;
/*   79 */       this.currentBlock = alternativeBlock;
/*   80 */       return true;
/*      */     } 
/*      */ 
/*      */     
/*   84 */     for (byte b2 = 0; b2 < i - 1; b2++) {
/*   85 */       this.currentBlock.alti = b2;
/*   86 */       this.currentBlock.analysisAlt = b2;
/*   87 */       this.currentBlock.altj = b2 + 1;
/*      */ 
/*      */ 
/*      */       
/*   91 */       for (int j = b2 + 1; j < i; j++) {
/*   92 */         boolean bool1; this.currentBlock.altj = j;
/*   93 */         if (this.DEBUG_ANALYZER) System.out.println("comparing " + b2 + " against alt " + j); 
/*   94 */         this.currentBlock.analysisAlt = j;
/*   95 */         b1 = 1;
/*      */ 
/*      */ 
/*      */         
/*   99 */         Lookahead[] arrayOfLookahead = new Lookahead[this.grammar.maxk + 1];
/*      */         
/*      */         do {
/*  102 */           bool1 = false;
/*  103 */           if (this.DEBUG_ANALYZER) System.out.println("checking depth " + b1 + "<=" + this.grammar.maxk);
/*      */           
/*  105 */           Lookahead lookahead1 = getAltLookahead(paramAlternativeBlock, b2, b1);
/*  106 */           Lookahead lookahead2 = getAltLookahead(paramAlternativeBlock, j, b1);
/*      */ 
/*      */ 
/*      */           
/*  110 */           if (this.DEBUG_ANALYZER) System.out.println("p is " + lookahead1.toString(",", this.charFormatter, this.grammar)); 
/*  111 */           if (this.DEBUG_ANALYZER) System.out.println("q is " + lookahead2.toString(",", this.charFormatter, this.grammar));
/*      */           
/*  113 */           arrayOfLookahead[b1] = lookahead1.intersection(lookahead2);
/*  114 */           if (this.DEBUG_ANALYZER) System.out.println("intersection at depth " + b1 + " is " + arrayOfLookahead[b1].toString()); 
/*  115 */           if (arrayOfLookahead[b1].nil())
/*  116 */             continue;  bool1 = true;
/*  117 */           b1++;
/*      */         
/*      */         }
/*  120 */         while (bool1 && b1 <= this.grammar.maxk);
/*      */         
/*  122 */         Alternative alternative1 = paramAlternativeBlock.getAlternativeAt(b2);
/*  123 */         Alternative alternative2 = paramAlternativeBlock.getAlternativeAt(j);
/*  124 */         if (bool1) {
/*  125 */           bool = false;
/*  126 */           alternative1.lookaheadDepth = Integer.MAX_VALUE;
/*  127 */           alternative2.lookaheadDepth = Integer.MAX_VALUE;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  135 */           if (alternative1.synPred != null) {
/*  136 */             if (this.DEBUG_ANALYZER) {
/*  137 */               System.out.println("alt " + b2 + " has a syn pred");
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*      */             }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           }
/*  150 */           else if (alternative1.semPred != null) {
/*  151 */             if (this.DEBUG_ANALYZER) {
/*  152 */               System.out.println("alt " + b2 + " has a sem pred");
/*      */ 
/*      */ 
/*      */             
/*      */             }
/*      */ 
/*      */           
/*      */           }
/*  160 */           else if (altUsesWildcardDefault(alternative2)) {
/*      */ 
/*      */             
/*  163 */             alternative = alternative2;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           }
/*  170 */           else if (paramAlternativeBlock.warnWhenFollowAmbig || (!(alternative1.head instanceof BlockEndElement) && !(alternative2.head instanceof BlockEndElement))) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*  180 */             if (paramAlternativeBlock.generateAmbigWarnings)
/*      */             {
/*      */ 
/*      */               
/*  184 */               if (!paramAlternativeBlock.greedySet || !paramAlternativeBlock.greedy || ((!(alternative1.head instanceof BlockEndElement) || alternative2.head instanceof BlockEndElement) && (!(alternative2.head instanceof BlockEndElement) || alternative1.head instanceof BlockEndElement)))
/*      */               {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */                 
/*  195 */                 this.tool.errorHandler.warnAltAmbiguity(this.grammar, paramAlternativeBlock, this.lexicalAnalysis, this.grammar.maxk, arrayOfLookahead, b2, j);
/*      */               
/*      */               }
/*      */             
/*      */             }
/*      */           
/*      */           }
/*      */ 
/*      */         
/*      */         }
/*      */         else {
/*      */ 
/*      */           
/*  208 */           alternative1.lookaheadDepth = Math.max(alternative1.lookaheadDepth, b1);
/*  209 */           alternative2.lookaheadDepth = Math.max(alternative2.lookaheadDepth, b1);
/*      */         } 
/*      */       } 
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  223 */     this.currentBlock = alternativeBlock;
/*  224 */     return bool;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean deterministic(OneOrMoreBlock paramOneOrMoreBlock) {
/*  231 */     if (this.DEBUG_ANALYZER) System.out.println("deterministic(...)+(" + paramOneOrMoreBlock + ")"); 
/*  232 */     AlternativeBlock alternativeBlock = this.currentBlock;
/*  233 */     this.currentBlock = paramOneOrMoreBlock;
/*  234 */     boolean bool1 = deterministic(paramOneOrMoreBlock);
/*      */ 
/*      */     
/*  237 */     boolean bool2 = deterministicImpliedPath(paramOneOrMoreBlock);
/*  238 */     this.currentBlock = alternativeBlock;
/*  239 */     return (bool2 && bool1);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean deterministic(ZeroOrMoreBlock paramZeroOrMoreBlock) {
/*  246 */     if (this.DEBUG_ANALYZER) System.out.println("deterministic(...)*(" + paramZeroOrMoreBlock + ")"); 
/*  247 */     AlternativeBlock alternativeBlock = this.currentBlock;
/*  248 */     this.currentBlock = paramZeroOrMoreBlock;
/*  249 */     boolean bool1 = deterministic(paramZeroOrMoreBlock);
/*      */ 
/*      */     
/*  252 */     boolean bool2 = deterministicImpliedPath(paramZeroOrMoreBlock);
/*  253 */     this.currentBlock = alternativeBlock;
/*  254 */     return (bool2 && bool1);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean deterministicImpliedPath(BlockWithImpliedExitPath paramBlockWithImpliedExitPath) {
/*  263 */     boolean bool = true;
/*  264 */     Vector vector = paramBlockWithImpliedExitPath.getAlternatives();
/*  265 */     int i = vector.size();
/*  266 */     this.currentBlock.altj = -1;
/*      */     
/*  268 */     if (this.DEBUG_ANALYZER) System.out.println("deterministicImpliedPath"); 
/*  269 */     for (byte b = 0; b < i; b++) {
/*  270 */       boolean bool1; Alternative alternative = paramBlockWithImpliedExitPath.getAlternativeAt(b);
/*      */       
/*  272 */       if (alternative.head instanceof BlockEndElement) {
/*  273 */         this.tool.warning("empty alternative makes no sense in (...)* or (...)+", this.grammar.getFilename(), paramBlockWithImpliedExitPath.getLine(), paramBlockWithImpliedExitPath.getColumn());
/*      */       }
/*      */       
/*  276 */       byte b1 = 1;
/*      */ 
/*      */       
/*  279 */       Lookahead[] arrayOfLookahead = new Lookahead[this.grammar.maxk + 1];
/*      */       
/*      */       do {
/*  282 */         bool1 = false;
/*  283 */         if (this.DEBUG_ANALYZER) System.out.println("checking depth " + b1 + "<=" + this.grammar.maxk);
/*      */         
/*  285 */         Lookahead lookahead2 = paramBlockWithImpliedExitPath.next.look(b1);
/*  286 */         paramBlockWithImpliedExitPath.exitCache[b1] = lookahead2;
/*  287 */         this.currentBlock.alti = b;
/*  288 */         Lookahead lookahead1 = getAltLookahead(paramBlockWithImpliedExitPath, b, b1);
/*      */         
/*  290 */         if (this.DEBUG_ANALYZER) System.out.println("follow is " + lookahead2.toString(",", this.charFormatter, this.grammar)); 
/*  291 */         if (this.DEBUG_ANALYZER) System.out.println("p is " + lookahead1.toString(",", this.charFormatter, this.grammar));
/*      */         
/*  293 */         arrayOfLookahead[b1] = lookahead2.intersection(lookahead1);
/*  294 */         if (this.DEBUG_ANALYZER) System.out.println("intersection at depth " + b1 + " is " + arrayOfLookahead[b1]); 
/*  295 */         if (arrayOfLookahead[b1].nil())
/*  296 */           continue;  bool1 = true;
/*  297 */         b1++;
/*      */       
/*      */       }
/*  300 */       while (bool1 && b1 <= this.grammar.maxk);
/*      */       
/*  302 */       if (bool1) {
/*  303 */         bool = false;
/*  304 */         alternative.lookaheadDepth = Integer.MAX_VALUE;
/*  305 */         paramBlockWithImpliedExitPath.exitLookaheadDepth = Integer.MAX_VALUE;
/*  306 */         Alternative alternative1 = paramBlockWithImpliedExitPath.getAlternativeAt(this.currentBlock.alti);
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  311 */         if (paramBlockWithImpliedExitPath.warnWhenFollowAmbig)
/*      */         {
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  317 */           if (paramBlockWithImpliedExitPath.generateAmbigWarnings)
/*      */           {
/*      */ 
/*      */             
/*  321 */             if (paramBlockWithImpliedExitPath.greedy == true && paramBlockWithImpliedExitPath.greedySet && !(alternative1.head instanceof BlockEndElement))
/*      */             {
/*  323 */               if (this.DEBUG_ANALYZER) System.out.println("greedy loop");
/*      */               
/*      */               
/*      */ 
/*      */ 
/*      */             
/*      */             }
/*  330 */             else if (!paramBlockWithImpliedExitPath.greedy && !(alternative1.head instanceof BlockEndElement))
/*      */             {
/*  332 */               if (this.DEBUG_ANALYZER) System.out.println("nongreedy loop");
/*      */ 
/*      */ 
/*      */ 
/*      */               
/*  337 */               if (!lookaheadEquivForApproxAndFullAnalysis(paramBlockWithImpliedExitPath.exitCache, this.grammar.maxk)) {
/*  338 */                 this.tool.warning(new String[] { "nongreedy block may exit incorrectly due", "\tto limitations of linear approximate lookahead (first k-1 sets", "\tin lookahead not singleton)." }, this.grammar.getFilename(), paramBlockWithImpliedExitPath.getLine(), paramBlockWithImpliedExitPath.getColumn());
/*      */ 
/*      */               
/*      */               }
/*      */ 
/*      */             
/*      */             }
/*      */             else
/*      */             {
/*      */               
/*  348 */               this.tool.errorHandler.warnAltExitAmbiguity(this.grammar, paramBlockWithImpliedExitPath, this.lexicalAnalysis, this.grammar.maxk, arrayOfLookahead, b);
/*      */             
/*      */             }
/*      */ 
/*      */           
/*      */           }
/*      */         
/*      */         }
/*      */       }
/*      */       else {
/*      */         
/*  359 */         alternative.lookaheadDepth = Math.max(alternative.lookaheadDepth, b1);
/*  360 */         paramBlockWithImpliedExitPath.exitLookaheadDepth = Math.max(paramBlockWithImpliedExitPath.exitLookaheadDepth, b1);
/*      */       } 
/*      */     } 
/*  363 */     return bool;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Lookahead FOLLOW(int paramInt, RuleEndElement paramRuleEndElement) {
/*      */     String str;
/*  371 */     RuleBlock ruleBlock = (RuleBlock)paramRuleEndElement.block;
/*      */ 
/*      */     
/*  374 */     if (this.lexicalAnalysis) {
/*  375 */       str = CodeGenerator.encodeLexerRuleName(ruleBlock.getRuleName());
/*      */     } else {
/*      */       
/*  378 */       str = ruleBlock.getRuleName();
/*      */     } 
/*      */     
/*  381 */     if (this.DEBUG_ANALYZER) System.out.println("FOLLOW(" + paramInt + "," + str + ")");
/*      */ 
/*      */     
/*  384 */     if (paramRuleEndElement.lock[paramInt]) {
/*  385 */       if (this.DEBUG_ANALYZER) System.out.println("FOLLOW cycle to " + str); 
/*  386 */       return new Lookahead(str);
/*      */     } 
/*      */ 
/*      */     
/*  390 */     if (paramRuleEndElement.cache[paramInt] != null) {
/*  391 */       if (this.DEBUG_ANALYZER) {
/*  392 */         System.out.println("cache entry FOLLOW(" + paramInt + ") for " + str + ": " + paramRuleEndElement.cache[paramInt].toString(",", this.charFormatter, this.grammar));
/*      */       }
/*      */       
/*  395 */       if ((paramRuleEndElement.cache[paramInt]).cycle == null) {
/*  396 */         return (Lookahead)paramRuleEndElement.cache[paramInt].clone();
/*      */       }
/*      */       
/*  399 */       RuleSymbol ruleSymbol1 = (RuleSymbol)this.grammar.getSymbol((paramRuleEndElement.cache[paramInt]).cycle);
/*  400 */       RuleEndElement ruleEndElement = (ruleSymbol1.getBlock()).endNode;
/*      */ 
/*      */       
/*  403 */       if (ruleEndElement.cache[paramInt] == null)
/*      */       {
/*  405 */         return (Lookahead)paramRuleEndElement.cache[paramInt].clone();
/*      */       }
/*      */       
/*  408 */       if (this.DEBUG_ANALYZER) {
/*  409 */         System.out.println("combining FOLLOW(" + paramInt + ") for " + str + ": from " + paramRuleEndElement.cache[paramInt].toString(",", this.charFormatter, this.grammar) + " with FOLLOW for " + ((RuleBlock)ruleEndElement.block).getRuleName() + ": " + ruleEndElement.cache[paramInt].toString(",", this.charFormatter, this.grammar));
/*      */       }
/*      */       
/*  412 */       if ((ruleEndElement.cache[paramInt]).cycle == null) {
/*      */ 
/*      */ 
/*      */         
/*  416 */         paramRuleEndElement.cache[paramInt].combineWith(ruleEndElement.cache[paramInt]);
/*  417 */         (paramRuleEndElement.cache[paramInt]).cycle = null;
/*      */ 
/*      */       
/*      */       }
/*      */       else {
/*      */ 
/*      */         
/*  424 */         Lookahead lookahead1 = FOLLOW(paramInt, ruleEndElement);
/*  425 */         paramRuleEndElement.cache[paramInt].combineWith(lookahead1);
/*      */         
/*  427 */         (paramRuleEndElement.cache[paramInt]).cycle = lookahead1.cycle;
/*      */       } 
/*  429 */       if (this.DEBUG_ANALYZER) {
/*  430 */         System.out.println("saving FOLLOW(" + paramInt + ") for " + str + ": from " + paramRuleEndElement.cache[paramInt].toString(",", this.charFormatter, this.grammar));
/*      */       }
/*      */ 
/*      */       
/*  434 */       return (Lookahead)paramRuleEndElement.cache[paramInt].clone();
/*      */     } 
/*      */ 
/*      */     
/*  438 */     paramRuleEndElement.lock[paramInt] = true;
/*      */     
/*  440 */     Lookahead lookahead = new Lookahead();
/*      */     
/*  442 */     RuleSymbol ruleSymbol = (RuleSymbol)this.grammar.getSymbol(str);
/*      */ 
/*      */     
/*  445 */     for (byte b = 0; b < ruleSymbol.numReferences(); b++) {
/*  446 */       RuleRefElement ruleRefElement = ruleSymbol.getReference(b);
/*  447 */       if (this.DEBUG_ANALYZER) System.out.println("next[" + str + "] is " + ruleRefElement.next.toString()); 
/*  448 */       Lookahead lookahead1 = ruleRefElement.next.look(paramInt);
/*  449 */       if (this.DEBUG_ANALYZER) System.out.println("FIRST of next[" + str + "] ptr is " + lookahead1.toString());
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  454 */       if (lookahead1.cycle != null && lookahead1.cycle.equals(str)) {
/*  455 */         lookahead1.cycle = null;
/*      */       }
/*      */       
/*  458 */       lookahead.combineWith(lookahead1);
/*  459 */       if (this.DEBUG_ANALYZER) System.out.println("combined FOLLOW[" + str + "] is " + lookahead.toString());
/*      */     
/*      */     } 
/*  462 */     paramRuleEndElement.lock[paramInt] = false;
/*      */ 
/*      */ 
/*      */     
/*  466 */     if (lookahead.fset.nil() && lookahead.cycle == null) {
/*  467 */       if (this.grammar instanceof TreeWalkerGrammar) {
/*      */ 
/*      */         
/*  470 */         lookahead.fset.add(3);
/*      */       }
/*  472 */       else if (this.grammar instanceof LexerGrammar) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  479 */         lookahead.setEpsilon();
/*      */       } else {
/*      */         
/*  482 */         lookahead.fset.add(1);
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*  487 */     if (this.DEBUG_ANALYZER) {
/*  488 */       System.out.println("saving FOLLOW(" + paramInt + ") for " + str + ": " + lookahead.toString(",", this.charFormatter, this.grammar));
/*      */     }
/*  490 */     paramRuleEndElement.cache[paramInt] = (Lookahead)lookahead.clone();
/*      */     
/*  492 */     return lookahead;
/*      */   }
/*      */   
/*      */   private Lookahead getAltLookahead(AlternativeBlock paramAlternativeBlock, int paramInt1, int paramInt2) {
/*      */     Lookahead lookahead;
/*  497 */     Alternative alternative = paramAlternativeBlock.getAlternativeAt(paramInt1);
/*  498 */     AlternativeElement alternativeElement = alternative.head;
/*      */     
/*  500 */     if (alternative.cache[paramInt2] == null) {
/*  501 */       lookahead = alternativeElement.look(paramInt2);
/*  502 */       alternative.cache[paramInt2] = lookahead;
/*      */     } else {
/*      */       
/*  505 */       lookahead = alternative.cache[paramInt2];
/*      */     } 
/*  507 */     return lookahead;
/*      */   }
/*      */ 
/*      */   
/*      */   public Lookahead look(int paramInt, ActionElement paramActionElement) {
/*  512 */     if (this.DEBUG_ANALYZER) System.out.println("lookAction(" + paramInt + "," + paramActionElement + ")"); 
/*  513 */     return paramActionElement.next.look(paramInt);
/*      */   }
/*      */ 
/*      */   
/*      */   public Lookahead look(int paramInt, AlternativeBlock paramAlternativeBlock) {
/*  518 */     if (this.DEBUG_ANALYZER) System.out.println("lookAltBlk(" + paramInt + "," + paramAlternativeBlock + ")"); 
/*  519 */     AlternativeBlock alternativeBlock = this.currentBlock;
/*  520 */     this.currentBlock = paramAlternativeBlock;
/*  521 */     Lookahead lookahead = new Lookahead();
/*  522 */     for (byte b = 0; b < paramAlternativeBlock.alternatives.size(); b++) {
/*  523 */       if (this.DEBUG_ANALYZER) System.out.println("alt " + b + " of " + paramAlternativeBlock);
/*      */       
/*  525 */       this.currentBlock.analysisAlt = b;
/*  526 */       Alternative alternative = paramAlternativeBlock.getAlternativeAt(b);
/*  527 */       AlternativeElement alternativeElement = alternative.head;
/*  528 */       if (this.DEBUG_ANALYZER && 
/*  529 */         alternative.head == alternative.tail) {
/*  530 */         System.out.println("alt " + b + " is empty");
/*      */       }
/*      */       
/*  533 */       Lookahead lookahead1 = alternativeElement.look(paramInt);
/*  534 */       lookahead.combineWith(lookahead1);
/*      */     } 
/*  536 */     if (paramInt == 1 && paramAlternativeBlock.not && subruleCanBeInverted(paramAlternativeBlock, this.lexicalAnalysis))
/*      */     {
/*  538 */       if (this.lexicalAnalysis) {
/*  539 */         BitSet bitSet = (BitSet)((LexerGrammar)this.grammar).charVocabulary.clone();
/*  540 */         int[] arrayOfInt = lookahead.fset.toArray();
/*  541 */         for (byte b1 = 0; b1 < arrayOfInt.length; b1++) {
/*  542 */           bitSet.remove(arrayOfInt[b1]);
/*      */         }
/*  544 */         lookahead.fset = bitSet;
/*      */       } else {
/*      */         
/*  547 */         lookahead.fset.notInPlace(4, this.grammar.tokenManager.maxTokenType());
/*      */       } 
/*      */     }
/*  550 */     this.currentBlock = alternativeBlock;
/*  551 */     return lookahead;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Lookahead look(int paramInt, BlockEndElement paramBlockEndElement) {
/*      */     Lookahead lookahead;
/*  567 */     if (this.DEBUG_ANALYZER) System.out.println("lookBlockEnd(" + paramInt + ", " + paramBlockEndElement.block + "); lock is " + paramBlockEndElement.lock[paramInt]); 
/*  568 */     if (paramBlockEndElement.lock[paramInt])
/*      */     {
/*      */ 
/*      */ 
/*      */       
/*  573 */       return new Lookahead();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  579 */     if (paramBlockEndElement.block instanceof ZeroOrMoreBlock || paramBlockEndElement.block instanceof OneOrMoreBlock) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  584 */       paramBlockEndElement.lock[paramInt] = true;
/*  585 */       lookahead = look(paramInt, paramBlockEndElement.block);
/*  586 */       paramBlockEndElement.lock[paramInt] = false;
/*      */     } else {
/*      */       
/*  589 */       lookahead = new Lookahead();
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  597 */     if (paramBlockEndElement.block instanceof TreeElement) {
/*  598 */       lookahead.combineWith(Lookahead.of(3));
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     }
/*  608 */     else if (paramBlockEndElement.block instanceof SynPredBlock) {
/*  609 */       lookahead.setEpsilon();
/*      */     
/*      */     }
/*      */     else {
/*      */       
/*  614 */       Lookahead lookahead1 = paramBlockEndElement.block.next.look(paramInt);
/*  615 */       lookahead.combineWith(lookahead1);
/*      */     } 
/*      */     
/*  618 */     return lookahead;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Lookahead look(int paramInt, CharLiteralElement paramCharLiteralElement) {
/*  641 */     if (this.DEBUG_ANALYZER) System.out.println("lookCharLiteral(" + paramInt + "," + paramCharLiteralElement + ")");
/*      */     
/*  643 */     if (paramInt > 1) {
/*  644 */       return paramCharLiteralElement.next.look(paramInt - 1);
/*      */     }
/*  646 */     if (this.lexicalAnalysis) {
/*  647 */       if (paramCharLiteralElement.not) {
/*  648 */         BitSet bitSet = (BitSet)((LexerGrammar)this.grammar).charVocabulary.clone();
/*  649 */         if (this.DEBUG_ANALYZER) System.out.println("charVocab is " + bitSet.toString());
/*      */         
/*  651 */         removeCompetingPredictionSets(bitSet, paramCharLiteralElement);
/*  652 */         if (this.DEBUG_ANALYZER) System.out.println("charVocab after removal of prior alt lookahead " + bitSet.toString());
/*      */         
/*  654 */         bitSet.clear(paramCharLiteralElement.getType());
/*  655 */         return new Lookahead(bitSet);
/*      */       } 
/*      */       
/*  658 */       return Lookahead.of(paramCharLiteralElement.getType());
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  663 */     this.tool.panic("Character literal reference found in parser");
/*      */     
/*  665 */     return Lookahead.of(paramCharLiteralElement.getType());
/*      */   }
/*      */ 
/*      */   
/*      */   public Lookahead look(int paramInt, CharRangeElement paramCharRangeElement) {
/*  670 */     if (this.DEBUG_ANALYZER) System.out.println("lookCharRange(" + paramInt + "," + paramCharRangeElement + ")");
/*      */     
/*  672 */     if (paramInt > 1) {
/*  673 */       return paramCharRangeElement.next.look(paramInt - 1);
/*      */     }
/*  675 */     BitSet bitSet = BitSet.of(paramCharRangeElement.begin);
/*  676 */     for (int i = paramCharRangeElement.begin + 1; i <= paramCharRangeElement.end; i++) {
/*  677 */       bitSet.add(i);
/*      */     }
/*  679 */     return new Lookahead(bitSet);
/*      */   }
/*      */   
/*      */   public Lookahead look(int paramInt, GrammarAtom paramGrammarAtom) {
/*  683 */     if (this.DEBUG_ANALYZER) System.out.println("look(" + paramInt + "," + paramGrammarAtom + "[" + paramGrammarAtom.getType() + "])");
/*      */     
/*  685 */     if (this.lexicalAnalysis)
/*      */     {
/*  687 */       this.tool.panic("token reference found in lexer");
/*      */     }
/*      */     
/*  690 */     if (paramInt > 1) {
/*  691 */       return paramGrammarAtom.next.look(paramInt - 1);
/*      */     }
/*  693 */     Lookahead lookahead = Lookahead.of(paramGrammarAtom.getType());
/*  694 */     if (paramGrammarAtom.not) {
/*      */       
/*  696 */       int i = this.grammar.tokenManager.maxTokenType();
/*  697 */       lookahead.fset.notInPlace(4, i);
/*      */       
/*  699 */       removeCompetingPredictionSets(lookahead.fset, paramGrammarAtom);
/*      */     } 
/*  701 */     return lookahead;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Lookahead look(int paramInt, OneOrMoreBlock paramOneOrMoreBlock) {
/*  709 */     if (this.DEBUG_ANALYZER) System.out.println("look+" + paramInt + "," + paramOneOrMoreBlock + ")"); 
/*  710 */     return look(paramInt, paramOneOrMoreBlock);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Lookahead look(int paramInt, RuleBlock paramRuleBlock) {
/*  720 */     if (this.DEBUG_ANALYZER) System.out.println("lookRuleBlk(" + paramInt + "," + paramRuleBlock + ")"); 
/*  721 */     return look(paramInt, paramRuleBlock);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Lookahead look(int paramInt, RuleEndElement paramRuleEndElement) {
/*  752 */     if (this.DEBUG_ANALYZER) {
/*  753 */       System.out.println("lookRuleBlockEnd(" + paramInt + "); noFOLLOW=" + paramRuleEndElement.noFOLLOW + "; lock is " + paramRuleEndElement.lock[paramInt]);
/*      */     }
/*  755 */     if (paramRuleEndElement.noFOLLOW) {
/*  756 */       Lookahead lookahead = new Lookahead();
/*  757 */       lookahead.setEpsilon();
/*  758 */       lookahead.epsilonDepth = BitSet.of(paramInt);
/*  759 */       return lookahead;
/*      */     } 
/*  761 */     return FOLLOW(paramInt, paramRuleEndElement);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Lookahead look(int paramInt, RuleRefElement paramRuleRefElement) {
/*  782 */     if (this.DEBUG_ANALYZER) System.out.println("lookRuleRef(" + paramInt + "," + paramRuleRefElement + ")"); 
/*  783 */     RuleSymbol ruleSymbol = (RuleSymbol)this.grammar.getSymbol(paramRuleRefElement.targetRule);
/*  784 */     if (ruleSymbol == null || !ruleSymbol.defined) {
/*  785 */       this.tool.error("no definition of rule " + paramRuleRefElement.targetRule, this.grammar.getFilename(), paramRuleRefElement.getLine(), paramRuleRefElement.getColumn());
/*  786 */       return new Lookahead();
/*      */     } 
/*  788 */     RuleBlock ruleBlock = ruleSymbol.getBlock();
/*  789 */     RuleEndElement ruleEndElement = ruleBlock.endNode;
/*  790 */     boolean bool = ruleEndElement.noFOLLOW;
/*  791 */     ruleEndElement.noFOLLOW = true;
/*      */     
/*  793 */     Lookahead lookahead = look(paramInt, paramRuleRefElement.targetRule);
/*  794 */     if (this.DEBUG_ANALYZER) System.out.println("back from rule ref to " + paramRuleRefElement.targetRule);
/*      */     
/*  796 */     ruleEndElement.noFOLLOW = bool;
/*      */ 
/*      */     
/*  799 */     if (lookahead.cycle != null) {
/*  800 */       this.tool.error("infinite recursion to rule " + lookahead.cycle + " from rule " + paramRuleRefElement.enclosingRuleName, this.grammar.getFilename(), paramRuleRefElement.getLine(), paramRuleRefElement.getColumn());
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*  805 */     if (lookahead.containsEpsilon()) {
/*  806 */       if (this.DEBUG_ANALYZER) {
/*  807 */         System.out.println("rule ref to " + paramRuleRefElement.targetRule + " has eps, depth: " + lookahead.epsilonDepth);
/*      */       }
/*      */ 
/*      */       
/*  811 */       lookahead.resetEpsilon();
/*      */ 
/*      */ 
/*      */       
/*  815 */       int[] arrayOfInt = lookahead.epsilonDepth.toArray();
/*  816 */       lookahead.epsilonDepth = null;
/*  817 */       for (byte b = 0; b < arrayOfInt.length; b++) {
/*  818 */         int i = paramInt - paramInt - arrayOfInt[b];
/*  819 */         Lookahead lookahead1 = paramRuleRefElement.next.look(i);
/*  820 */         lookahead.combineWith(lookahead1);
/*      */       } 
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  826 */     return lookahead;
/*      */   }
/*      */   
/*      */   public Lookahead look(int paramInt, StringLiteralElement paramStringLiteralElement) {
/*  830 */     if (this.DEBUG_ANALYZER) System.out.println("lookStringLiteral(" + paramInt + "," + paramStringLiteralElement + ")"); 
/*  831 */     if (this.lexicalAnalysis) {
/*      */       
/*  833 */       if (paramInt > paramStringLiteralElement.processedAtomText.length()) {
/*  834 */         return paramStringLiteralElement.next.look(paramInt - paramStringLiteralElement.processedAtomText.length());
/*      */       }
/*      */ 
/*      */       
/*  838 */       return Lookahead.of(paramStringLiteralElement.processedAtomText.charAt(paramInt - 1));
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  843 */     if (paramInt > 1) {
/*  844 */       return paramStringLiteralElement.next.look(paramInt - 1);
/*      */     }
/*  846 */     Lookahead lookahead = Lookahead.of(paramStringLiteralElement.getType());
/*  847 */     if (paramStringLiteralElement.not) {
/*      */       
/*  849 */       int i = this.grammar.tokenManager.maxTokenType();
/*  850 */       lookahead.fset.notInPlace(4, i);
/*      */     } 
/*  852 */     return lookahead;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Lookahead look(int paramInt, SynPredBlock paramSynPredBlock) {
/*  863 */     if (this.DEBUG_ANALYZER) System.out.println("look=>(" + paramInt + "," + paramSynPredBlock + ")"); 
/*  864 */     return paramSynPredBlock.next.look(paramInt);
/*      */   }
/*      */   
/*      */   public Lookahead look(int paramInt, TokenRangeElement paramTokenRangeElement) {
/*  868 */     if (this.DEBUG_ANALYZER) System.out.println("lookTokenRange(" + paramInt + "," + paramTokenRangeElement + ")");
/*      */     
/*  870 */     if (paramInt > 1) {
/*  871 */       return paramTokenRangeElement.next.look(paramInt - 1);
/*      */     }
/*  873 */     BitSet bitSet = BitSet.of(paramTokenRangeElement.begin);
/*  874 */     for (int i = paramTokenRangeElement.begin + 1; i <= paramTokenRangeElement.end; i++) {
/*  875 */       bitSet.add(i);
/*      */     }
/*  877 */     return new Lookahead(bitSet);
/*      */   }
/*      */   
/*      */   public Lookahead look(int paramInt, TreeElement paramTreeElement) {
/*  881 */     if (this.DEBUG_ANALYZER)
/*  882 */       System.out.println("look(" + paramInt + "," + paramTreeElement.root + "[" + paramTreeElement.root.getType() + "])"); 
/*  883 */     if (paramInt > 1) {
/*  884 */       return paramTreeElement.next.look(paramInt - 1);
/*      */     }
/*  886 */     Lookahead lookahead = null;
/*  887 */     if (paramTreeElement.root instanceof WildcardElement) {
/*  888 */       lookahead = paramTreeElement.root.look(1);
/*      */     } else {
/*      */       
/*  891 */       lookahead = Lookahead.of(paramTreeElement.root.getType());
/*  892 */       if (paramTreeElement.root.not) {
/*      */         
/*  894 */         int i = this.grammar.tokenManager.maxTokenType();
/*  895 */         lookahead.fset.notInPlace(4, i);
/*      */       } 
/*      */     } 
/*  898 */     return lookahead;
/*      */   }
/*      */   public Lookahead look(int paramInt, WildcardElement paramWildcardElement) {
/*      */     BitSet bitSet;
/*  902 */     if (this.DEBUG_ANALYZER) System.out.println("look(" + paramInt + "," + paramWildcardElement + ")");
/*      */ 
/*      */     
/*  905 */     if (paramInt > 1) {
/*  906 */       return paramWildcardElement.next.look(paramInt - 1);
/*      */     }
/*      */ 
/*      */     
/*  910 */     if (this.lexicalAnalysis) {
/*      */       
/*  912 */       bitSet = (BitSet)((LexerGrammar)this.grammar).charVocabulary.clone();
/*      */     } else {
/*      */       
/*  915 */       bitSet = new BitSet(1);
/*      */       
/*  917 */       int i = this.grammar.tokenManager.maxTokenType();
/*  918 */       bitSet.notInPlace(4, i);
/*  919 */       if (this.DEBUG_ANALYZER) System.out.println("look(" + paramInt + "," + paramWildcardElement + ") after not: " + bitSet);
/*      */     
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  925 */     return new Lookahead(bitSet);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Lookahead look(int paramInt, ZeroOrMoreBlock paramZeroOrMoreBlock) {
/*  932 */     if (this.DEBUG_ANALYZER) System.out.println("look*(" + paramInt + "," + paramZeroOrMoreBlock + ")"); 
/*  933 */     Lookahead lookahead1 = look(paramInt, paramZeroOrMoreBlock);
/*  934 */     Lookahead lookahead2 = paramZeroOrMoreBlock.next.look(paramInt);
/*  935 */     lookahead1.combineWith(lookahead2);
/*  936 */     return lookahead1;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Lookahead look(int paramInt, String paramString) {
/*  949 */     if (this.DEBUG_ANALYZER) System.out.println("lookRuleName(" + paramInt + "," + paramString + ")"); 
/*  950 */     RuleSymbol ruleSymbol = (RuleSymbol)this.grammar.getSymbol(paramString);
/*  951 */     RuleBlock ruleBlock = ruleSymbol.getBlock();
/*      */     
/*  953 */     if (ruleBlock.lock[paramInt]) {
/*  954 */       if (this.DEBUG_ANALYZER)
/*  955 */         System.out.println("infinite recursion to rule " + ruleBlock.getRuleName()); 
/*  956 */       return new Lookahead(paramString);
/*      */     } 
/*      */ 
/*      */     
/*  960 */     if (ruleBlock.cache[paramInt] != null) {
/*  961 */       if (this.DEBUG_ANALYZER) {
/*  962 */         System.out.println("found depth " + paramInt + " result in FIRST " + paramString + " cache: " + ruleBlock.cache[paramInt].toString(",", this.charFormatter, this.grammar));
/*      */       }
/*      */       
/*  965 */       return (Lookahead)ruleBlock.cache[paramInt].clone();
/*      */     } 
/*      */     
/*  968 */     ruleBlock.lock[paramInt] = true;
/*  969 */     Lookahead lookahead = look(paramInt, ruleBlock);
/*  970 */     ruleBlock.lock[paramInt] = false;
/*      */ 
/*      */     
/*  973 */     ruleBlock.cache[paramInt] = (Lookahead)lookahead.clone();
/*  974 */     if (this.DEBUG_ANALYZER) {
/*  975 */       System.out.println("saving depth " + paramInt + " result in FIRST " + paramString + " cache: " + ruleBlock.cache[paramInt].toString(",", this.charFormatter, this.grammar));
/*      */     }
/*      */     
/*  978 */     return lookahead;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean lookaheadEquivForApproxAndFullAnalysis(Lookahead[] paramArrayOfLookahead, int paramInt) {
/*  986 */     for (byte b = 1; b <= paramInt - 1; b++) {
/*  987 */       BitSet bitSet = (paramArrayOfLookahead[b]).fset;
/*  988 */       if (bitSet.degree() > 1) {
/*  989 */         return false;
/*      */       }
/*      */     } 
/*  992 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void removeCompetingPredictionSets(BitSet paramBitSet, AlternativeElement paramAlternativeElement) {
/* 1005 */     AlternativeElement alternativeElement = (this.currentBlock.getAlternativeAt(this.currentBlock.analysisAlt)).head;
/*      */     
/* 1007 */     if (alternativeElement instanceof TreeElement) {
/* 1008 */       if (((TreeElement)alternativeElement).root != paramAlternativeElement) {
/*      */         return;
/*      */       }
/*      */     }
/* 1012 */     else if (paramAlternativeElement != alternativeElement) {
/*      */       return;
/*      */     } 
/* 1015 */     for (byte b = 0; b < this.currentBlock.analysisAlt; b++) {
/* 1016 */       AlternativeElement alternativeElement1 = (this.currentBlock.getAlternativeAt(b)).head;
/* 1017 */       paramBitSet.subtractInPlace((alternativeElement1.look(1)).fset);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void removeCompetingPredictionSetsFromWildcard(Lookahead[] paramArrayOfLookahead, AlternativeElement paramAlternativeElement, int paramInt) {
/* 1029 */     for (byte b = 1; b <= paramInt; b++) {
/* 1030 */       for (byte b1 = 0; b1 < this.currentBlock.analysisAlt; b1++) {
/* 1031 */         AlternativeElement alternativeElement = (this.currentBlock.getAlternativeAt(b1)).head;
/* 1032 */         (paramArrayOfLookahead[b]).fset.subtractInPlace((alternativeElement.look(b)).fset);
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   private void reset() {
/* 1039 */     this.grammar = null;
/* 1040 */     this.DEBUG_ANALYZER = false;
/* 1041 */     this.currentBlock = null;
/* 1042 */     this.lexicalAnalysis = false;
/*      */   }
/*      */ 
/*      */   
/*      */   public void setGrammar(Grammar paramGrammar) {
/* 1047 */     if (this.grammar != null) {
/* 1048 */       reset();
/*      */     }
/* 1050 */     this.grammar = paramGrammar;
/*      */ 
/*      */     
/* 1053 */     this.lexicalAnalysis = this.grammar instanceof LexerGrammar;
/* 1054 */     this.DEBUG_ANALYZER = this.grammar.analyzerDebug;
/*      */   }
/*      */   
/*      */   public boolean subruleCanBeInverted(AlternativeBlock paramAlternativeBlock, boolean paramBoolean) {
/* 1058 */     if (paramAlternativeBlock instanceof ZeroOrMoreBlock || paramAlternativeBlock instanceof OneOrMoreBlock || paramAlternativeBlock instanceof SynPredBlock)
/*      */     {
/*      */ 
/*      */ 
/*      */       
/* 1063 */       return false;
/*      */     }
/*      */     
/* 1066 */     if (paramAlternativeBlock.alternatives.size() == 0) {
/* 1067 */       return false;
/*      */     }
/*      */ 
/*      */     
/* 1071 */     for (byte b = 0; b < paramAlternativeBlock.alternatives.size(); b++) {
/* 1072 */       Alternative alternative = paramAlternativeBlock.getAlternativeAt(b);
/*      */       
/* 1074 */       if (alternative.synPred != null || alternative.semPred != null || alternative.exceptionSpec != null) {
/* 1075 */         return false;
/*      */       }
/*      */       
/* 1078 */       AlternativeElement alternativeElement = alternative.head;
/* 1079 */       if ((!(alternativeElement instanceof CharLiteralElement) && !(alternativeElement instanceof TokenRefElement) && !(alternativeElement instanceof CharRangeElement) && !(alternativeElement instanceof TokenRangeElement) && (!(alternativeElement instanceof StringLiteralElement) || paramBoolean)) || !(alternativeElement.next instanceof BlockEndElement) || alternativeElement.getAutoGenType() != 1)
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1090 */         return false;
/*      */       }
/*      */     } 
/* 1093 */     return true;
/*      */   }
/*      */ }


/* Location:              C:\Users\olatu\OneDrive\Documents\Calypso\syncbase\sync_base.jar!\BOOT-INF\lib\antlr-2.7.7.jar!\antlr\LLkAnalyzer.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */