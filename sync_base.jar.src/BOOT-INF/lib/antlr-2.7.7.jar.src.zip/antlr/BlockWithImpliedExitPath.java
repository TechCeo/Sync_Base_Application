/*    */ package antlr;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ abstract class BlockWithImpliedExitPath
/*    */   extends AlternativeBlock
/*    */ {
/*    */   protected int exitLookaheadDepth;
/* 15 */   protected Lookahead[] exitCache = new Lookahead[this.grammar.maxk + 1];
/*    */   
/*    */   public BlockWithImpliedExitPath(Grammar paramGrammar) {
/* 18 */     super(paramGrammar);
/*    */   }
/*    */   
/*    */   public BlockWithImpliedExitPath(Grammar paramGrammar, Token paramToken) {
/* 22 */     super(paramGrammar, paramToken, false);
/*    */   }
/*    */ }


/* Location:              C:\Users\olatu\OneDrive\Documents\Calypso\syncbase\sync_base.jar!\BOOT-INF\lib\antlr-2.7.7.jar!\antlr\BlockWithImpliedExitPath.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */