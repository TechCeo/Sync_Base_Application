/*    */ package antlr;
/*    */ 
/*    */ import antlr.collections.impl.Vector;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class RuleSymbol
/*    */   extends GrammarSymbol
/*    */ {
/*    */   RuleBlock block;
/*    */   boolean defined;
/*    */   Vector references;
/*    */   String access;
/*    */   String comment;
/*    */   
/*    */   public RuleSymbol(String paramString) {
/* 22 */     super(paramString);
/* 23 */     this.references = new Vector();
/*    */   }
/*    */   
/*    */   public void addReference(RuleRefElement paramRuleRefElement) {
/* 27 */     this.references.appendElement(paramRuleRefElement);
/*    */   }
/*    */   
/*    */   public RuleBlock getBlock() {
/* 31 */     return this.block;
/*    */   }
/*    */   
/*    */   public RuleRefElement getReference(int paramInt) {
/* 35 */     return (RuleRefElement)this.references.elementAt(paramInt);
/*    */   }
/*    */   
/*    */   public boolean isDefined() {
/* 39 */     return this.defined;
/*    */   }
/*    */   
/*    */   public int numReferences() {
/* 43 */     return this.references.size();
/*    */   }
/*    */   
/*    */   public void setBlock(RuleBlock paramRuleBlock) {
/* 47 */     this.block = paramRuleBlock;
/*    */   }
/*    */   
/*    */   public void setDefined() {
/* 51 */     this.defined = true;
/*    */   }
/*    */ }


/* Location:              C:\Users\olatu\OneDrive\Documents\Calypso\syncbase\sync_base.jar!\BOOT-INF\lib\antlr-2.7.7.jar!\antlr\RuleSymbol.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */