/*     */ package org.apache.commons.io.input;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.FileNotFoundException;
/*     */ import java.io.IOException;
/*     */ import java.io.RandomAccessFile;
/*     */ import org.apache.commons.io.FileUtils;
/*     */ import org.apache.commons.io.IOUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Tailer
/*     */   implements Runnable
/*     */ {
/*     */   private final File file;
/*     */   private final long delay;
/*     */   private final boolean end;
/*     */   private final TailerListener listener;
/*     */   private volatile boolean run = true;
/*     */   
/*     */   public Tailer(File file, TailerListener listener) {
/* 140 */     this(file, listener, 1000L);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Tailer(File file, TailerListener listener, long delay) {
/* 150 */     this(file, listener, delay, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Tailer(File file, TailerListener listener, long delay, boolean end) {
/* 162 */     this.file = file;
/* 163 */     this.delay = delay;
/* 164 */     this.end = end;
/*     */ 
/*     */     
/* 167 */     this.listener = listener;
/* 168 */     listener.init(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Tailer create(File file, TailerListener listener, long delay, boolean end) {
/* 181 */     Tailer tailer = new Tailer(file, listener, delay, end);
/* 182 */     Thread thread = new Thread(tailer);
/* 183 */     thread.setDaemon(true);
/* 184 */     thread.start();
/* 185 */     return tailer;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Tailer create(File file, TailerListener listener, long delay) {
/* 197 */     return create(file, listener, delay, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Tailer create(File file, TailerListener listener) {
/* 209 */     return create(file, listener, 1000L, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public File getFile() {
/* 218 */     return this.file;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public long getDelay() {
/* 227 */     return this.delay;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void run() {
/* 234 */     RandomAccessFile reader = null;
/*     */     try {
/* 236 */       long last = 0L;
/* 237 */       long position = 0L;
/*     */       
/* 239 */       while (this.run && reader == null) {
/*     */         try {
/* 241 */           reader = new RandomAccessFile(this.file, "r");
/* 242 */         } catch (FileNotFoundException e) {
/* 243 */           this.listener.fileNotFound();
/*     */         } 
/*     */         
/* 246 */         if (reader == null) {
/*     */           try {
/* 248 */             Thread.sleep(this.delay);
/* 249 */           } catch (InterruptedException e) {}
/*     */           
/*     */           continue;
/*     */         } 
/* 253 */         position = this.end ? this.file.length() : 0L;
/* 254 */         last = System.currentTimeMillis();
/* 255 */         reader.seek(position);
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 260 */       while (this.run)
/*     */       {
/*     */         
/* 263 */         long length = this.file.length();
/*     */         
/* 265 */         if (length < position) {
/*     */ 
/*     */           
/* 268 */           this.listener.fileRotated();
/*     */ 
/*     */ 
/*     */           
/*     */           try {
/* 273 */             RandomAccessFile save = reader;
/* 274 */             reader = new RandomAccessFile(this.file, "r");
/* 275 */             position = 0L;
/*     */             
/* 277 */             IOUtils.closeQuietly(save);
/* 278 */           } catch (FileNotFoundException e) {
/*     */             
/* 280 */             this.listener.fileNotFound();
/*     */           } 
/*     */ 
/*     */           
/*     */           continue;
/*     */         } 
/*     */ 
/*     */         
/* 288 */         if (length > position) {
/*     */ 
/*     */           
/* 291 */           last = System.currentTimeMillis();
/* 292 */           position = readLines(reader);
/*     */         }
/* 294 */         else if (FileUtils.isFileNewer(this.file, last)) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 300 */           position = 0L;
/* 301 */           reader.seek(position);
/*     */ 
/*     */           
/* 304 */           last = System.currentTimeMillis();
/* 305 */           position = readLines(reader);
/*     */         } 
/*     */         
/*     */         try {
/* 309 */           Thread.sleep(this.delay);
/* 310 */         } catch (InterruptedException e) {}
/*     */       }
/*     */     
/*     */     }
/* 314 */     catch (Exception e) {
/*     */       
/* 316 */       this.listener.handle(e);
/*     */     } finally {
/*     */       
/* 319 */       IOUtils.closeQuietly(reader);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void stop() {
/* 327 */     this.run = false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private long readLines(RandomAccessFile reader) throws IOException {
/* 338 */     long pos = reader.getFilePointer();
/* 339 */     String line = readLine(reader);
/* 340 */     while (line != null) {
/* 341 */       pos = reader.getFilePointer();
/* 342 */       this.listener.handle(line);
/* 343 */       line = readLine(reader);
/*     */     } 
/* 345 */     reader.seek(pos);
/* 346 */     return pos;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String readLine(RandomAccessFile reader) throws IOException {
/* 356 */     StringBuffer sb = new StringBuffer();
/*     */     
/* 358 */     boolean seenCR = false; int ch;
/* 359 */     while ((ch = reader.read()) != -1) {
/* 360 */       switch (ch) {
/*     */         case 10:
/* 362 */           return sb.toString();
/*     */         case 13:
/* 364 */           seenCR = true;
/*     */           continue;
/*     */       } 
/* 367 */       if (seenCR) {
/* 368 */         sb.append('\r');
/* 369 */         seenCR = false;
/*     */       } 
/* 371 */       sb.append((char)ch);
/*     */     } 
/*     */     
/* 374 */     return null;
/*     */   }
/*     */ }


/* Location:              C:\Users\olatu\OneDrive\Documents\Calypso\syncbase\sync_base.jar!\BOOT-INF\lib\commons-io-2.2.jar!\org\apache\commons\io\input\Tailer.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */