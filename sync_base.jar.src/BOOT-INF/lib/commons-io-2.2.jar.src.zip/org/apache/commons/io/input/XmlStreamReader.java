/*     */ package org.apache.commons.io.input;
/*     */ 
/*     */ import java.io.BufferedInputStream;
/*     */ import java.io.BufferedReader;
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.InputStreamReader;
/*     */ import java.io.Reader;
/*     */ import java.io.StringReader;
/*     */ import java.net.URL;
/*     */ import java.net.URLConnection;
/*     */ import java.text.MessageFormat;
/*     */ import java.util.Locale;
/*     */ import java.util.regex.Matcher;
/*     */ import java.util.regex.Pattern;
/*     */ import org.apache.commons.io.ByteOrderMark;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class XmlStreamReader
/*     */   extends Reader
/*     */ {
/*     */   private static final int BUFFER_SIZE = 4096;
/*     */   private static final String UTF_8 = "UTF-8";
/*     */   private static final String US_ASCII = "US-ASCII";
/*     */   private static final String UTF_16BE = "UTF-16BE";
/*     */   private static final String UTF_16LE = "UTF-16LE";
/*     */   private static final String UTF_16 = "UTF-16";
/*     */   private static final String EBCDIC = "CP1047";
/*  81 */   private static final ByteOrderMark[] BOMS = new ByteOrderMark[] { ByteOrderMark.UTF_8, ByteOrderMark.UTF_16BE, ByteOrderMark.UTF_16LE };
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  86 */   private static final ByteOrderMark[] XML_GUESS_BYTES = new ByteOrderMark[] { new ByteOrderMark("UTF-8", new int[] { 60, 63, 120, 109 }), new ByteOrderMark("UTF-16BE", new int[] { 0, 60, 0, 63 }), new ByteOrderMark("UTF-16LE", new int[] { 60, 0, 63, 0 }), new ByteOrderMark("CP1047", new int[] { 76, 111, 167, 148 }) };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final Reader reader;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final String encoding;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final String defaultEncoding;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getDefaultEncoding() {
/* 109 */     return this.defaultEncoding;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public XmlStreamReader(File file) throws IOException {
/* 125 */     this(new FileInputStream(file));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public XmlStreamReader(InputStream is) throws IOException {
/* 140 */     this(is, true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public XmlStreamReader(InputStream is, boolean lenient) throws IOException {
/* 171 */     this(is, lenient, (String)null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public XmlStreamReader(InputStream is, boolean lenient, String defaultEncoding) throws IOException {
/* 203 */     this.defaultEncoding = defaultEncoding;
/* 204 */     BOMInputStream bom = new BOMInputStream(new BufferedInputStream(is, 4096), false, BOMS);
/* 205 */     BOMInputStream pis = new BOMInputStream(bom, true, XML_GUESS_BYTES);
/* 206 */     this.encoding = doRawStream(bom, pis, lenient);
/* 207 */     this.reader = new InputStreamReader(pis, this.encoding);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public XmlStreamReader(URL url) throws IOException {
/* 228 */     this(url.openConnection(), (String)null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public XmlStreamReader(URLConnection conn, String defaultEncoding) throws IOException {
/* 251 */     this.defaultEncoding = defaultEncoding;
/* 252 */     boolean lenient = true;
/* 253 */     String contentType = conn.getContentType();
/* 254 */     InputStream is = conn.getInputStream();
/* 255 */     BOMInputStream bom = new BOMInputStream(new BufferedInputStream(is, 4096), false, BOMS);
/* 256 */     BOMInputStream pis = new BOMInputStream(bom, true, XML_GUESS_BYTES);
/* 257 */     if (conn instanceof java.net.HttpURLConnection || contentType != null) {
/* 258 */       this.encoding = doHttpStream(bom, pis, contentType, lenient);
/*     */     } else {
/* 260 */       this.encoding = doRawStream(bom, pis, lenient);
/*     */     } 
/* 262 */     this.reader = new InputStreamReader(pis, this.encoding);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public XmlStreamReader(InputStream is, String httpContentType) throws IOException {
/* 284 */     this(is, httpContentType, true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public XmlStreamReader(InputStream is, String httpContentType, boolean lenient, String defaultEncoding) throws IOException {
/* 323 */     this.defaultEncoding = defaultEncoding;
/* 324 */     BOMInputStream bom = new BOMInputStream(new BufferedInputStream(is, 4096), false, BOMS);
/* 325 */     BOMInputStream pis = new BOMInputStream(bom, true, XML_GUESS_BYTES);
/* 326 */     this.encoding = doHttpStream(bom, pis, httpContentType, lenient);
/* 327 */     this.reader = new InputStreamReader(pis, this.encoding);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public XmlStreamReader(InputStream is, String httpContentType, boolean lenient) throws IOException {
/* 365 */     this(is, httpContentType, lenient, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getEncoding() {
/* 374 */     return this.encoding;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int read(char[] buf, int offset, int len) throws IOException {
/* 387 */     return this.reader.read(buf, offset, len);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void close() throws IOException {
/* 397 */     this.reader.close();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String doRawStream(BOMInputStream bom, BOMInputStream pis, boolean lenient) throws IOException {
/* 412 */     String bomEnc = bom.getBOMCharsetName();
/* 413 */     String xmlGuessEnc = pis.getBOMCharsetName();
/* 414 */     String xmlEnc = getXmlProlog(pis, xmlGuessEnc);
/*     */     try {
/* 416 */       return calculateRawEncoding(bomEnc, xmlGuessEnc, xmlEnc);
/* 417 */     } catch (XmlStreamReaderException ex) {
/* 418 */       if (lenient) {
/* 419 */         return doLenientDetection(null, ex);
/*     */       }
/* 421 */       throw ex;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String doHttpStream(BOMInputStream bom, BOMInputStream pis, String httpContentType, boolean lenient) throws IOException {
/* 439 */     String bomEnc = bom.getBOMCharsetName();
/* 440 */     String xmlGuessEnc = pis.getBOMCharsetName();
/* 441 */     String xmlEnc = getXmlProlog(pis, xmlGuessEnc);
/*     */     try {
/* 443 */       return calculateHttpEncoding(httpContentType, bomEnc, xmlGuessEnc, xmlEnc, lenient);
/*     */     }
/* 445 */     catch (XmlStreamReaderException ex) {
/* 446 */       if (lenient) {
/* 447 */         return doLenientDetection(httpContentType, ex);
/*     */       }
/* 449 */       throw ex;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String doLenientDetection(String httpContentType, XmlStreamReaderException ex) throws IOException {
/* 465 */     if (httpContentType != null && httpContentType.startsWith("text/html")) {
/* 466 */       httpContentType = httpContentType.substring("text/html".length());
/* 467 */       httpContentType = "text/xml" + httpContentType;
/*     */       try {
/* 469 */         return calculateHttpEncoding(httpContentType, ex.getBomEncoding(), ex.getXmlGuessEncoding(), ex.getXmlEncoding(), true);
/*     */       }
/* 471 */       catch (XmlStreamReaderException ex2) {
/* 472 */         ex = ex2;
/*     */       } 
/*     */     } 
/* 475 */     String encoding = ex.getXmlEncoding();
/* 476 */     if (encoding == null) {
/* 477 */       encoding = ex.getContentTypeEncoding();
/*     */     }
/* 479 */     if (encoding == null) {
/* 480 */       encoding = (this.defaultEncoding == null) ? "UTF-8" : this.defaultEncoding;
/*     */     }
/* 482 */     return encoding;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   String calculateRawEncoding(String bomEnc, String xmlGuessEnc, String xmlEnc) throws IOException {
/* 498 */     if (bomEnc == null) {
/* 499 */       if (xmlGuessEnc == null || xmlEnc == null) {
/* 500 */         return (this.defaultEncoding == null) ? "UTF-8" : this.defaultEncoding;
/*     */       }
/* 502 */       if (xmlEnc.equals("UTF-16") && (xmlGuessEnc.equals("UTF-16BE") || xmlGuessEnc.equals("UTF-16LE")))
/*     */       {
/* 504 */         return xmlGuessEnc;
/*     */       }
/* 506 */       return xmlEnc;
/*     */     } 
/*     */ 
/*     */     
/* 510 */     if (bomEnc.equals("UTF-8")) {
/* 511 */       if (xmlGuessEnc != null && !xmlGuessEnc.equals("UTF-8")) {
/* 512 */         String str = MessageFormat.format("Invalid encoding, BOM [{0}] XML guess [{1}] XML prolog [{2}] encoding mismatch", new Object[] { bomEnc, xmlGuessEnc, xmlEnc });
/* 513 */         throw new XmlStreamReaderException(str, bomEnc, xmlGuessEnc, xmlEnc);
/*     */       } 
/* 515 */       if (xmlEnc != null && !xmlEnc.equals("UTF-8")) {
/* 516 */         String str = MessageFormat.format("Invalid encoding, BOM [{0}] XML guess [{1}] XML prolog [{2}] encoding mismatch", new Object[] { bomEnc, xmlGuessEnc, xmlEnc });
/* 517 */         throw new XmlStreamReaderException(str, bomEnc, xmlGuessEnc, xmlEnc);
/*     */       } 
/* 519 */       return bomEnc;
/*     */     } 
/*     */ 
/*     */     
/* 523 */     if (bomEnc.equals("UTF-16BE") || bomEnc.equals("UTF-16LE")) {
/* 524 */       if (xmlGuessEnc != null && !xmlGuessEnc.equals(bomEnc)) {
/* 525 */         String str = MessageFormat.format("Invalid encoding, BOM [{0}] XML guess [{1}] XML prolog [{2}] encoding mismatch", new Object[] { bomEnc, xmlGuessEnc, xmlEnc });
/* 526 */         throw new XmlStreamReaderException(str, bomEnc, xmlGuessEnc, xmlEnc);
/*     */       } 
/* 528 */       if (xmlEnc != null && !xmlEnc.equals("UTF-16") && !xmlEnc.equals(bomEnc)) {
/* 529 */         String str = MessageFormat.format("Invalid encoding, BOM [{0}] XML guess [{1}] XML prolog [{2}] encoding mismatch", new Object[] { bomEnc, xmlGuessEnc, xmlEnc });
/* 530 */         throw new XmlStreamReaderException(str, bomEnc, xmlGuessEnc, xmlEnc);
/*     */       } 
/* 532 */       return bomEnc;
/*     */     } 
/*     */ 
/*     */     
/* 536 */     String msg = MessageFormat.format("Invalid encoding, BOM [{0}] XML guess [{1}] XML prolog [{2}] unknown BOM", new Object[] { bomEnc, xmlGuessEnc, xmlEnc });
/* 537 */     throw new XmlStreamReaderException(msg, bomEnc, xmlGuessEnc, xmlEnc);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   String calculateHttpEncoding(String httpContentType, String bomEnc, String xmlGuessEnc, String xmlEnc, boolean lenient) throws IOException {
/* 558 */     if (lenient && xmlEnc != null) {
/* 559 */       return xmlEnc;
/*     */     }
/*     */ 
/*     */     
/* 563 */     String cTMime = getContentTypeMime(httpContentType);
/* 564 */     String cTEnc = getContentTypeEncoding(httpContentType);
/* 565 */     boolean appXml = isAppXml(cTMime);
/* 566 */     boolean textXml = isTextXml(cTMime);
/*     */ 
/*     */     
/* 569 */     if (!appXml && !textXml) {
/* 570 */       String msg = MessageFormat.format("Invalid encoding, CT-MIME [{0}] CT-Enc [{1}] BOM [{2}] XML guess [{3}] XML prolog [{4}], Invalid MIME", new Object[] { cTMime, cTEnc, bomEnc, xmlGuessEnc, xmlEnc });
/* 571 */       throw new XmlStreamReaderException(msg, cTMime, cTEnc, bomEnc, xmlGuessEnc, xmlEnc);
/*     */     } 
/*     */ 
/*     */     
/* 575 */     if (cTEnc == null) {
/* 576 */       if (appXml) {
/* 577 */         return calculateRawEncoding(bomEnc, xmlGuessEnc, xmlEnc);
/*     */       }
/* 579 */       return (this.defaultEncoding == null) ? "US-ASCII" : this.defaultEncoding;
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 584 */     if (cTEnc.equals("UTF-16BE") || cTEnc.equals("UTF-16LE")) {
/* 585 */       if (bomEnc != null) {
/* 586 */         String msg = MessageFormat.format("Invalid encoding, CT-MIME [{0}] CT-Enc [{1}] BOM [{2}] XML guess [{3}] XML prolog [{4}], BOM must be NULL", new Object[] { cTMime, cTEnc, bomEnc, xmlGuessEnc, xmlEnc });
/* 587 */         throw new XmlStreamReaderException(msg, cTMime, cTEnc, bomEnc, xmlGuessEnc, xmlEnc);
/*     */       } 
/* 589 */       return cTEnc;
/*     */     } 
/*     */ 
/*     */     
/* 593 */     if (cTEnc.equals("UTF-16")) {
/* 594 */       if (bomEnc != null && bomEnc.startsWith("UTF-16")) {
/* 595 */         return bomEnc;
/*     */       }
/* 597 */       String msg = MessageFormat.format("Invalid encoding, CT-MIME [{0}] CT-Enc [{1}] BOM [{2}] XML guess [{3}] XML prolog [{4}], encoding mismatch", new Object[] { cTMime, cTEnc, bomEnc, xmlGuessEnc, xmlEnc });
/* 598 */       throw new XmlStreamReaderException(msg, cTMime, cTEnc, bomEnc, xmlGuessEnc, xmlEnc);
/*     */     } 
/*     */     
/* 601 */     return cTEnc;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static String getContentTypeMime(String httpContentType) {
/* 611 */     String mime = null;
/* 612 */     if (httpContentType != null) {
/* 613 */       int i = httpContentType.indexOf(";");
/* 614 */       if (i >= 0) {
/* 615 */         mime = httpContentType.substring(0, i);
/*     */       } else {
/* 617 */         mime = httpContentType;
/*     */       } 
/* 619 */       mime = mime.trim();
/*     */     } 
/* 621 */     return mime;
/*     */   }
/*     */   
/* 624 */   private static final Pattern CHARSET_PATTERN = Pattern.compile("charset=[\"']?([.[^; \"']]*)[\"']?");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static String getContentTypeEncoding(String httpContentType) {
/* 635 */     String encoding = null;
/* 636 */     if (httpContentType != null) {
/* 637 */       int i = httpContentType.indexOf(";");
/* 638 */       if (i > -1) {
/* 639 */         String postMime = httpContentType.substring(i + 1);
/* 640 */         Matcher m = CHARSET_PATTERN.matcher(postMime);
/* 641 */         encoding = m.find() ? m.group(1) : null;
/* 642 */         encoding = (encoding != null) ? encoding.toUpperCase(Locale.US) : null;
/*     */       } 
/*     */     } 
/* 645 */     return encoding;
/*     */   }
/*     */   
/* 648 */   public static final Pattern ENCODING_PATTERN = Pattern.compile("<\\?xml.*encoding[\\s]*=[\\s]*((?:\".[^\"]*\")|(?:'.[^']*'))", 8);
/*     */   
/*     */   private static final String RAW_EX_1 = "Invalid encoding, BOM [{0}] XML guess [{1}] XML prolog [{2}] encoding mismatch";
/*     */   
/*     */   private static final String RAW_EX_2 = "Invalid encoding, BOM [{0}] XML guess [{1}] XML prolog [{2}] unknown BOM";
/*     */   
/*     */   private static final String HTTP_EX_1 = "Invalid encoding, CT-MIME [{0}] CT-Enc [{1}] BOM [{2}] XML guess [{3}] XML prolog [{4}], BOM must be NULL";
/*     */   
/*     */   private static final String HTTP_EX_2 = "Invalid encoding, CT-MIME [{0}] CT-Enc [{1}] BOM [{2}] XML guess [{3}] XML prolog [{4}], encoding mismatch";
/*     */   
/*     */   private static final String HTTP_EX_3 = "Invalid encoding, CT-MIME [{0}] CT-Enc [{1}] BOM [{2}] XML guess [{3}] XML prolog [{4}], Invalid MIME";
/*     */ 
/*     */   
/*     */   private static String getXmlProlog(InputStream is, String guessedEnc) throws IOException {
/* 662 */     String encoding = null;
/* 663 */     if (guessedEnc != null) {
/* 664 */       byte[] bytes = new byte[4096];
/* 665 */       is.mark(4096);
/* 666 */       int offset = 0;
/* 667 */       int max = 4096;
/* 668 */       int c = is.read(bytes, offset, max);
/* 669 */       int firstGT = -1;
/* 670 */       String xmlProlog = null;
/* 671 */       while (c != -1 && firstGT == -1 && offset < 4096) {
/* 672 */         offset += c;
/* 673 */         max -= c;
/* 674 */         c = is.read(bytes, offset, max);
/* 675 */         xmlProlog = new String(bytes, 0, offset, guessedEnc);
/* 676 */         firstGT = xmlProlog.indexOf('>');
/*     */       } 
/* 678 */       if (firstGT == -1) {
/* 679 */         if (c == -1) {
/* 680 */           throw new IOException("Unexpected end of XML stream");
/*     */         }
/* 682 */         throw new IOException("XML prolog or ROOT element not found on first " + offset + " bytes");
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 687 */       int bytesRead = offset;
/* 688 */       if (bytesRead > 0) {
/* 689 */         is.reset();
/* 690 */         BufferedReader bReader = new BufferedReader(new StringReader(xmlProlog.substring(0, firstGT + 1)));
/*     */         
/* 692 */         StringBuffer prolog = new StringBuffer();
/* 693 */         String line = bReader.readLine();
/* 694 */         while (line != null) {
/* 695 */           prolog.append(line);
/* 696 */           line = bReader.readLine();
/*     */         } 
/* 698 */         Matcher m = ENCODING_PATTERN.matcher(prolog);
/* 699 */         if (m.find()) {
/* 700 */           encoding = m.group(1).toUpperCase();
/* 701 */           encoding = encoding.substring(1, encoding.length() - 1);
/*     */         } 
/*     */       } 
/*     */     } 
/* 705 */     return encoding;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static boolean isAppXml(String mime) {
/* 716 */     return (mime != null && (mime.equals("application/xml") || mime.equals("application/xml-dtd") || mime.equals("application/xml-external-parsed-entity") || (mime.startsWith("application/") && mime.endsWith("+xml"))));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static boolean isTextXml(String mime) {
/* 731 */     return (mime != null && (mime.equals("text/xml") || mime.equals("text/xml-external-parsed-entity") || (mime.startsWith("text/") && mime.endsWith("+xml"))));
/*     */   }
/*     */ }


/* Location:              C:\Users\olatu\OneDrive\Documents\Calypso\syncbase\sync_base.jar!\BOOT-INF\lib\commons-io-2.2.jar!\org\apache\commons\io\input\XmlStreamReader.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */