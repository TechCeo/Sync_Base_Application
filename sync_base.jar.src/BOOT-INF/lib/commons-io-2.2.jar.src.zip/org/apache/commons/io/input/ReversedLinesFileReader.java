/*     */ package org.apache.commons.io.input;
/*     */ 
/*     */ import java.io.Closeable;
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.io.RandomAccessFile;
/*     */ import java.io.UnsupportedEncodingException;
/*     */ import java.nio.charset.Charset;
/*     */ import java.nio.charset.CharsetEncoder;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ReversedLinesFileReader
/*     */   implements Closeable
/*     */ {
/*     */   private final int blockSize;
/*     */   private final String encoding;
/*     */   private final RandomAccessFile randomAccessFile;
/*     */   private final long totalByteLength;
/*     */   private final long totalBlockCount;
/*     */   private final byte[][] newLineSequences;
/*     */   private final int avoidNewlineSplitBufferSize;
/*     */   private final int byteDecrement;
/*     */   private FilePart currentFilePart;
/*     */   private boolean trailingNewlineOfFileSkipped = false;
/*     */   
/*     */   public ReversedLinesFileReader(File file) throws IOException {
/*  60 */     this(file, 4096, Charset.defaultCharset().toString());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ReversedLinesFileReader(File file, int blockSize, String encoding) throws IOException {
/*  76 */     this.blockSize = blockSize;
/*  77 */     this.encoding = encoding;
/*     */     
/*  79 */     this.randomAccessFile = new RandomAccessFile(file, "r");
/*  80 */     this.totalByteLength = this.randomAccessFile.length();
/*  81 */     int lastBlockLength = (int)(this.totalByteLength % blockSize);
/*  82 */     if (lastBlockLength > 0) {
/*  83 */       this.totalBlockCount = this.totalByteLength / blockSize + 1L;
/*     */     } else {
/*  85 */       this.totalBlockCount = this.totalByteLength / blockSize;
/*  86 */       if (this.totalByteLength > 0L) {
/*  87 */         lastBlockLength = blockSize;
/*     */       }
/*     */     } 
/*  90 */     this.currentFilePart = new FilePart(this.totalBlockCount, lastBlockLength, null);
/*     */ 
/*     */     
/*  93 */     Charset charset = Charset.forName(encoding);
/*  94 */     CharsetEncoder charsetEncoder = charset.newEncoder();
/*  95 */     float maxBytesPerChar = charsetEncoder.maxBytesPerChar();
/*  96 */     if (maxBytesPerChar == 1.0F)
/*     */     
/*  98 */     { this.byteDecrement = 1; }
/*  99 */     else if (charset == Charset.forName("UTF-8"))
/*     */     
/*     */     { 
/* 102 */       this.byteDecrement = 1; }
/* 103 */     else if (charset == Charset.forName("Shift_JIS"))
/*     */     
/*     */     { 
/* 106 */       this.byteDecrement = 1; }
/* 107 */     else if (charset == Charset.forName("UTF-16BE") || charset == Charset.forName("UTF-16LE"))
/*     */     
/*     */     { 
/* 110 */       this.byteDecrement = 2; }
/* 111 */     else { if (charset == Charset.forName("UTF-16")) {
/* 112 */         throw new UnsupportedEncodingException("For UTF-16, you need to specify the byte order (use UTF-16BE or UTF-16LE)");
/*     */       }
/*     */       
/* 115 */       throw new UnsupportedEncodingException("Encoding " + encoding + " is not supported yet (feel free to submit a patch)"); }
/*     */ 
/*     */ 
/*     */     
/* 119 */     this.newLineSequences = new byte[][] { "\r\n".getBytes(encoding), "\n".getBytes(encoding), "\r".getBytes(encoding) };
/*     */     
/* 121 */     this.avoidNewlineSplitBufferSize = (this.newLineSequences[0]).length;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String readLine() throws IOException {
/* 133 */     String line = this.currentFilePart.readLine();
/* 134 */     while (line == null) {
/* 135 */       this.currentFilePart = this.currentFilePart.rollOver();
/* 136 */       if (this.currentFilePart != null) {
/* 137 */         line = this.currentFilePart.readLine();
/*     */       }
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 145 */     if ("".equals(line) && !this.trailingNewlineOfFileSkipped) {
/* 146 */       this.trailingNewlineOfFileSkipped = true;
/* 147 */       line = readLine();
/*     */     } 
/*     */     
/* 150 */     return line;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void close() throws IOException {
/* 159 */     this.randomAccessFile.close();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private class FilePart
/*     */   {
/*     */     private final long no;
/*     */ 
/*     */     
/*     */     private final byte[] data;
/*     */ 
/*     */     
/*     */     private byte[] leftOver;
/*     */ 
/*     */     
/*     */     private int currentLastBytePos;
/*     */ 
/*     */     
/*     */     private FilePart(long no, int length, byte[] leftOverOfLastFilePart) throws IOException {
/* 179 */       this.no = no;
/* 180 */       int dataLength = length + ((leftOverOfLastFilePart != null) ? leftOverOfLastFilePart.length : 0);
/* 181 */       this.data = new byte[dataLength];
/* 182 */       long off = (no - 1L) * ReversedLinesFileReader.this.blockSize;
/*     */ 
/*     */       
/* 185 */       if (no > 0L) {
/* 186 */         ReversedLinesFileReader.this.randomAccessFile.seek(off);
/* 187 */         int countRead = ReversedLinesFileReader.this.randomAccessFile.read(this.data, 0, length);
/* 188 */         if (countRead != length) {
/* 189 */           throw new IllegalStateException("Count of requested bytes and actually read bytes don't match");
/*     */         }
/*     */       } 
/*     */       
/* 193 */       if (leftOverOfLastFilePart != null) {
/* 194 */         System.arraycopy(leftOverOfLastFilePart, 0, this.data, length, leftOverOfLastFilePart.length);
/*     */       }
/* 196 */       this.currentLastBytePos = this.data.length - 1;
/* 197 */       this.leftOver = null;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private FilePart rollOver() throws IOException {
/* 208 */       if (this.currentLastBytePos > -1) {
/* 209 */         throw new IllegalStateException("Current currentLastCharPos unexpectedly positive... last readLine() should have returned something! currentLastCharPos=" + this.currentLastBytePos);
/*     */       }
/*     */ 
/*     */       
/* 213 */       if (this.no > 1L) {
/* 214 */         return new FilePart(this.no - 1L, ReversedLinesFileReader.this.blockSize, this.leftOver);
/*     */       }
/*     */       
/* 217 */       if (this.leftOver != null) {
/* 218 */         throw new IllegalStateException("Unexpected leftover of the last block: leftOverOfThisFilePart=" + new String(this.leftOver, ReversedLinesFileReader.this.encoding));
/*     */       }
/*     */       
/* 221 */       return null;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private String readLine() throws IOException {
/* 233 */       String line = null;
/*     */ 
/*     */       
/* 236 */       boolean isLastFilePart = (this.no == 1L);
/*     */       
/* 238 */       int i = this.currentLastBytePos;
/* 239 */       while (i > -1) {
/*     */         
/* 241 */         if (!isLastFilePart && i < ReversedLinesFileReader.this.avoidNewlineSplitBufferSize) {
/*     */ 
/*     */           
/* 244 */           createLeftOver();
/*     */           
/*     */           break;
/*     */         } 
/*     */         int newLineMatchByteCount;
/* 249 */         if ((newLineMatchByteCount = getNewLineMatchByteCount(this.data, i)) > 0) {
/* 250 */           int lineStart = i + 1;
/* 251 */           int lineLengthBytes = this.currentLastBytePos - lineStart + 1;
/*     */           
/* 253 */           if (lineLengthBytes < 0) {
/* 254 */             throw new IllegalStateException("Unexpected negative line length=" + lineLengthBytes);
/*     */           }
/* 256 */           byte[] lineData = new byte[lineLengthBytes];
/* 257 */           System.arraycopy(this.data, lineStart, lineData, 0, lineLengthBytes);
/*     */           
/* 259 */           line = new String(lineData, ReversedLinesFileReader.this.encoding);
/*     */           
/* 261 */           this.currentLastBytePos = i - newLineMatchByteCount;
/*     */           
/*     */           break;
/*     */         } 
/*     */         
/* 266 */         i -= ReversedLinesFileReader.this.byteDecrement;
/*     */ 
/*     */         
/* 269 */         if (i < 0) {
/* 270 */           createLeftOver();
/*     */           
/*     */           break;
/*     */         } 
/*     */       } 
/*     */       
/* 276 */       if (isLastFilePart && this.leftOver != null) {
/*     */         
/* 278 */         line = new String(this.leftOver, ReversedLinesFileReader.this.encoding);
/* 279 */         this.leftOver = null;
/*     */       } 
/*     */       
/* 282 */       return line;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private void createLeftOver() {
/* 289 */       int lineLengthBytes = this.currentLastBytePos + 1;
/* 290 */       if (lineLengthBytes > 0) {
/*     */         
/* 292 */         this.leftOver = new byte[lineLengthBytes];
/* 293 */         System.arraycopy(this.data, 0, this.leftOver, 0, lineLengthBytes);
/*     */       } else {
/* 295 */         this.leftOver = null;
/*     */       } 
/* 297 */       this.currentLastBytePos = -1;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private int getNewLineMatchByteCount(byte[] data, int i) {
/* 308 */       for (byte[] newLineSequence : ReversedLinesFileReader.this.newLineSequences) {
/* 309 */         int k; boolean match = true;
/* 310 */         for (int j = newLineSequence.length - 1; j >= 0; j--) {
/* 311 */           int m = i + j - newLineSequence.length - 1;
/* 312 */           k = match & ((m >= 0 && data[m] == newLineSequence[j]) ? 1 : 0);
/*     */         } 
/* 314 */         if (k != 0) {
/* 315 */           return newLineSequence.length;
/*     */         }
/*     */       } 
/* 318 */       return 0;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\olatu\OneDrive\Documents\Calypso\syncbase\sync_base.jar!\BOOT-INF\lib\commons-io-2.2.jar!\org\apache\commons\io\input\ReversedLinesFileReader.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */