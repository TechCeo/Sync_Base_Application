/*      */ package org.apache.commons.io;
/*      */ 
/*      */ import java.io.File;
/*      */ import java.io.FileFilter;
/*      */ import java.io.FileInputStream;
/*      */ import java.io.FileNotFoundException;
/*      */ import java.io.FileOutputStream;
/*      */ import java.io.IOException;
/*      */ import java.io.InputStream;
/*      */ import java.io.InputStreamReader;
/*      */ import java.io.OutputStream;
/*      */ import java.io.Reader;
/*      */ import java.math.BigInteger;
/*      */ import java.net.URL;
/*      */ import java.net.URLConnection;
/*      */ import java.nio.ByteBuffer;
/*      */ import java.nio.channels.FileChannel;
/*      */ import java.nio.charset.Charset;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Collection;
/*      */ import java.util.Date;
/*      */ import java.util.Iterator;
/*      */ import java.util.LinkedList;
/*      */ import java.util.List;
/*      */ import java.util.zip.CRC32;
/*      */ import java.util.zip.CheckedInputStream;
/*      */ import java.util.zip.Checksum;
/*      */ import org.apache.commons.io.filefilter.DirectoryFileFilter;
/*      */ import org.apache.commons.io.filefilter.FalseFileFilter;
/*      */ import org.apache.commons.io.filefilter.FileFilterUtils;
/*      */ import org.apache.commons.io.filefilter.IOFileFilter;
/*      */ import org.apache.commons.io.filefilter.SuffixFileFilter;
/*      */ import org.apache.commons.io.filefilter.TrueFileFilter;
/*      */ import org.apache.commons.io.output.NullOutputStream;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class FileUtils
/*      */ {
/*      */   public static final long ONE_KB = 1024L;
/*      */   public static final long ONE_MB = 1048576L;
/*      */   private static final long FILE_COPY_BUFFER_SIZE = 31457280L;
/*      */   public static final long ONE_GB = 1073741824L;
/*      */   public static final long ONE_TB = 1099511627776L;
/*      */   public static final long ONE_PB = 1125899906842624L;
/*      */   public static final long ONE_EB = 1152921504606846976L;
/*  120 */   public static final BigInteger ONE_ZB = BigInteger.valueOf(1024L).multiply(BigInteger.valueOf(1152921504606846976L));
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  125 */   public static final BigInteger ONE_YB = ONE_ZB.multiply(BigInteger.valueOf(1152921504606846976L));
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  130 */   public static final File[] EMPTY_FILE_ARRAY = new File[0];
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  135 */   private static final Charset UTF8 = Charset.forName("UTF-8");
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static File getFile(File directory, String... names) {
/*  147 */     if (directory == null) {
/*  148 */       throw new NullPointerException("directorydirectory must not be null");
/*      */     }
/*  150 */     if (names == null) {
/*  151 */       throw new NullPointerException("names must not be null");
/*      */     }
/*  153 */     File file = directory;
/*  154 */     for (String name : names) {
/*  155 */       file = new File(file, name);
/*      */     }
/*  157 */     return file;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static File getFile(String... names) {
/*  168 */     if (names == null) {
/*  169 */       throw new NullPointerException("names must not be null");
/*      */     }
/*  171 */     File file = null;
/*  172 */     for (String name : names) {
/*  173 */       if (file == null) {
/*  174 */         file = new File(name);
/*      */       } else {
/*  176 */         file = new File(file, name);
/*      */       } 
/*      */     } 
/*  179 */     return file;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String getTempDirectoryPath() {
/*  190 */     return System.getProperty("java.io.tmpdir");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static File getTempDirectory() {
/*  201 */     return new File(getTempDirectoryPath());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String getUserDirectoryPath() {
/*  212 */     return System.getProperty("user.home");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static File getUserDirectory() {
/*  223 */     return new File(getUserDirectoryPath());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static FileInputStream openInputStream(File file) throws IOException {
/*  246 */     if (file.exists()) {
/*  247 */       if (file.isDirectory()) {
/*  248 */         throw new IOException("File '" + file + "' exists but is a directory");
/*      */       }
/*  250 */       if (!file.canRead()) {
/*  251 */         throw new IOException("File '" + file + "' cannot be read");
/*      */       }
/*      */     } else {
/*  254 */       throw new FileNotFoundException("File '" + file + "' does not exist");
/*      */     } 
/*  256 */     return new FileInputStream(file);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static FileOutputStream openOutputStream(File file) throws IOException {
/*  281 */     return openOutputStream(file, false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static FileOutputStream openOutputStream(File file, boolean append) throws IOException {
/*  307 */     if (file.exists()) {
/*  308 */       if (file.isDirectory()) {
/*  309 */         throw new IOException("File '" + file + "' exists but is a directory");
/*      */       }
/*  311 */       if (!file.canWrite()) {
/*  312 */         throw new IOException("File '" + file + "' cannot be written to");
/*      */       }
/*      */     } else {
/*  315 */       File parent = file.getParentFile();
/*  316 */       if (parent != null && 
/*  317 */         !parent.mkdirs() && !parent.isDirectory()) {
/*  318 */         throw new IOException("Directory '" + parent + "' could not be created");
/*      */       }
/*      */     } 
/*      */     
/*  322 */     return new FileOutputStream(file, append);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String byteCountToDisplaySize(long size) {
/*      */     String displaySize;
/*  342 */     if (size / 1152921504606846976L > 0L) {
/*  343 */       displaySize = String.valueOf(size / 1152921504606846976L) + " EB";
/*  344 */     } else if (size / 1125899906842624L > 0L) {
/*  345 */       displaySize = String.valueOf(size / 1125899906842624L) + " PB";
/*  346 */     } else if (size / 1099511627776L > 0L) {
/*  347 */       displaySize = String.valueOf(size / 1099511627776L) + " TB";
/*  348 */     } else if (size / 1073741824L > 0L) {
/*  349 */       displaySize = String.valueOf(size / 1073741824L) + " GB";
/*  350 */     } else if (size / 1048576L > 0L) {
/*  351 */       displaySize = String.valueOf(size / 1048576L) + " MB";
/*  352 */     } else if (size / 1024L > 0L) {
/*  353 */       displaySize = String.valueOf(size / 1024L) + " KB";
/*      */     } else {
/*  355 */       displaySize = String.valueOf(size) + " bytes";
/*      */     } 
/*  357 */     return displaySize;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void touch(File file) throws IOException {
/*  374 */     if (!file.exists()) {
/*  375 */       OutputStream out = openOutputStream(file);
/*  376 */       IOUtils.closeQuietly(out);
/*      */     } 
/*  378 */     boolean success = file.setLastModified(System.currentTimeMillis());
/*  379 */     if (!success) {
/*  380 */       throw new IOException("Unable to set the last modification time for " + file);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static File[] convertFileCollectionToFileArray(Collection<File> files) {
/*  394 */     return files.<File>toArray(new File[files.size()]);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static void innerListFiles(Collection<File> files, File directory, IOFileFilter filter, boolean includeSubDirectories) {
/*  409 */     File[] found = directory.listFiles((FileFilter)filter);
/*      */     
/*  411 */     if (found != null) {
/*  412 */       for (File file : found) {
/*  413 */         if (file.isDirectory()) {
/*  414 */           if (includeSubDirectories) {
/*  415 */             files.add(file);
/*      */           }
/*  417 */           innerListFiles(files, file, filter, includeSubDirectories);
/*      */         } else {
/*  419 */           files.add(file);
/*      */         } 
/*      */       } 
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Collection<File> listFiles(File directory, IOFileFilter fileFilter, IOFileFilter dirFilter) {
/*  452 */     validateListFilesParameters(directory, fileFilter);
/*      */     
/*  454 */     IOFileFilter effFileFilter = setUpEffectiveFileFilter(fileFilter);
/*  455 */     IOFileFilter effDirFilter = setUpEffectiveDirFilter(dirFilter);
/*      */ 
/*      */     
/*  458 */     Collection<File> files = new LinkedList<File>();
/*  459 */     innerListFiles(files, directory, FileFilterUtils.or(new IOFileFilter[] { effFileFilter, effDirFilter }, ), false);
/*      */     
/*  461 */     return files;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static void validateListFilesParameters(File directory, IOFileFilter fileFilter) {
/*  475 */     if (!directory.isDirectory()) {
/*  476 */       throw new IllegalArgumentException("Parameter 'directory' is not a directory");
/*      */     }
/*  478 */     if (fileFilter == null) {
/*  479 */       throw new NullPointerException("Parameter 'fileFilter' is null");
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static IOFileFilter setUpEffectiveFileFilter(IOFileFilter fileFilter) {
/*  490 */     return FileFilterUtils.and(new IOFileFilter[] { fileFilter, FileFilterUtils.notFileFilter(DirectoryFileFilter.INSTANCE) });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static IOFileFilter setUpEffectiveDirFilter(IOFileFilter dirFilter) {
/*  500 */     return (dirFilter == null) ? FalseFileFilter.INSTANCE : FileFilterUtils.and(new IOFileFilter[] { dirFilter, DirectoryFileFilter.INSTANCE });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Collection<File> listFilesAndDirs(File directory, IOFileFilter fileFilter, IOFileFilter dirFilter) {
/*  524 */     validateListFilesParameters(directory, fileFilter);
/*      */     
/*  526 */     IOFileFilter effFileFilter = setUpEffectiveFileFilter(fileFilter);
/*  527 */     IOFileFilter effDirFilter = setUpEffectiveDirFilter(dirFilter);
/*      */ 
/*      */     
/*  530 */     Collection<File> files = new LinkedList<File>();
/*  531 */     if (directory.isDirectory()) {
/*  532 */       files.add(directory);
/*      */     }
/*  534 */     innerListFiles(files, directory, FileFilterUtils.or(new IOFileFilter[] { effFileFilter, effDirFilter }, ), true);
/*      */     
/*  536 */     return files;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Iterator<File> iterateFiles(File directory, IOFileFilter fileFilter, IOFileFilter dirFilter) {
/*  559 */     return listFiles(directory, fileFilter, dirFilter).iterator();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Iterator<File> iterateFilesAndDirs(File directory, IOFileFilter fileFilter, IOFileFilter dirFilter) {
/*  583 */     return listFilesAndDirs(directory, fileFilter, dirFilter).iterator();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static String[] toSuffixes(String[] extensions) {
/*  595 */     String[] suffixes = new String[extensions.length];
/*  596 */     for (int i = 0; i < extensions.length; i++) {
/*  597 */       suffixes[i] = "." + extensions[i];
/*      */     }
/*  599 */     return suffixes;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Collection<File> listFiles(File directory, String[] extensions, boolean recursive) {
/*      */     SuffixFileFilter suffixFileFilter;
/*  616 */     if (extensions == null) {
/*  617 */       IOFileFilter filter = TrueFileFilter.INSTANCE;
/*      */     } else {
/*  619 */       String[] suffixes = toSuffixes(extensions);
/*  620 */       suffixFileFilter = new SuffixFileFilter(suffixes);
/*      */     } 
/*  622 */     return listFiles(directory, (IOFileFilter)suffixFileFilter, recursive ? TrueFileFilter.INSTANCE : FalseFileFilter.INSTANCE);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Iterator<File> iterateFiles(File directory, String[] extensions, boolean recursive) {
/*  641 */     return listFiles(directory, extensions, recursive).iterator();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean contentEquals(File file1, File file2) throws IOException {
/*  661 */     boolean file1Exists = file1.exists();
/*  662 */     if (file1Exists != file2.exists()) {
/*  663 */       return false;
/*      */     }
/*      */     
/*  666 */     if (!file1Exists)
/*      */     {
/*  668 */       return true;
/*      */     }
/*      */     
/*  671 */     if (file1.isDirectory() || file2.isDirectory())
/*      */     {
/*  673 */       throw new IOException("Can't compare directories, only files");
/*      */     }
/*      */     
/*  676 */     if (file1.length() != file2.length())
/*      */     {
/*  678 */       return false;
/*      */     }
/*      */     
/*  681 */     if (file1.getCanonicalFile().equals(file2.getCanonicalFile()))
/*      */     {
/*  683 */       return true;
/*      */     }
/*      */     
/*  686 */     InputStream input1 = null;
/*  687 */     InputStream input2 = null;
/*      */     try {
/*  689 */       input1 = new FileInputStream(file1);
/*  690 */       input2 = new FileInputStream(file2);
/*  691 */       return IOUtils.contentEquals(input1, input2);
/*      */     } finally {
/*      */       
/*  694 */       IOUtils.closeQuietly(input1);
/*  695 */       IOUtils.closeQuietly(input2);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean contentEqualsIgnoreEOL(File file1, File file2, String charsetName) throws IOException {
/*  718 */     boolean file1Exists = file1.exists();
/*  719 */     if (file1Exists != file2.exists()) {
/*  720 */       return false;
/*      */     }
/*      */     
/*  723 */     if (!file1Exists)
/*      */     {
/*  725 */       return true;
/*      */     }
/*      */     
/*  728 */     if (file1.isDirectory() || file2.isDirectory())
/*      */     {
/*  730 */       throw new IOException("Can't compare directories, only files");
/*      */     }
/*      */     
/*  733 */     if (file1.getCanonicalFile().equals(file2.getCanonicalFile()))
/*      */     {
/*  735 */       return true;
/*      */     }
/*      */     
/*  738 */     Reader input1 = null;
/*  739 */     Reader input2 = null;
/*      */     try {
/*  741 */       if (charsetName == null) {
/*  742 */         input1 = new InputStreamReader(new FileInputStream(file1));
/*  743 */         input2 = new InputStreamReader(new FileInputStream(file2));
/*      */       } else {
/*  745 */         input1 = new InputStreamReader(new FileInputStream(file1), charsetName);
/*  746 */         input2 = new InputStreamReader(new FileInputStream(file2), charsetName);
/*      */       } 
/*  748 */       return IOUtils.contentEqualsIgnoreEOL(input1, input2);
/*      */     } finally {
/*      */       
/*  751 */       IOUtils.closeQuietly(input1);
/*  752 */       IOUtils.closeQuietly(input2);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static File toFile(URL url) {
/*  772 */     if (url == null || !"file".equalsIgnoreCase(url.getProtocol())) {
/*  773 */       return null;
/*      */     }
/*  775 */     String filename = url.getFile().replace('/', File.separatorChar);
/*  776 */     filename = decodeUrl(filename);
/*  777 */     return new File(filename);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static String decodeUrl(String url) {
/*  796 */     String decoded = url;
/*  797 */     if (url != null && url.indexOf('%') >= 0) {
/*  798 */       int n = url.length();
/*  799 */       StringBuffer buffer = new StringBuffer();
/*  800 */       ByteBuffer bytes = ByteBuffer.allocate(n);
/*  801 */       for (int i = 0; i < n; ) {
/*  802 */         if (url.charAt(i) == '%') {
/*      */           try {
/*      */             do {
/*  805 */               byte octet = (byte)Integer.parseInt(url.substring(i + 1, i + 3), 16);
/*  806 */               bytes.put(octet);
/*  807 */               i += 3;
/*  808 */             } while (i < n && url.charAt(i) == '%');
/*      */             continue;
/*  810 */           } catch (RuntimeException e) {
/*      */ 
/*      */           
/*      */           } finally {
/*  814 */             if (bytes.position() > 0) {
/*  815 */               bytes.flip();
/*  816 */               buffer.append(UTF8.decode(bytes).toString());
/*  817 */               bytes.clear();
/*      */             } 
/*      */           } 
/*      */         }
/*  821 */         buffer.append(url.charAt(i++));
/*      */       } 
/*  823 */       decoded = buffer.toString();
/*      */     } 
/*  825 */     return decoded;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static File[] toFiles(URL[] urls) {
/*  848 */     if (urls == null || urls.length == 0) {
/*  849 */       return EMPTY_FILE_ARRAY;
/*      */     }
/*  851 */     File[] files = new File[urls.length];
/*  852 */     for (int i = 0; i < urls.length; i++) {
/*  853 */       URL url = urls[i];
/*  854 */       if (url != null) {
/*  855 */         if (!url.getProtocol().equals("file")) {
/*  856 */           throw new IllegalArgumentException("URL could not be converted to a File: " + url);
/*      */         }
/*      */         
/*  859 */         files[i] = toFile(url);
/*      */       } 
/*      */     } 
/*  862 */     return files;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static URL[] toURLs(File[] files) throws IOException {
/*  875 */     URL[] urls = new URL[files.length];
/*      */     
/*  877 */     for (int i = 0; i < urls.length; i++) {
/*  878 */       urls[i] = files[i].toURI().toURL();
/*      */     }
/*      */     
/*  881 */     return urls;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void copyFileToDirectory(File srcFile, File destDir) throws IOException {
/*  907 */     copyFileToDirectory(srcFile, destDir, true);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void copyFileToDirectory(File srcFile, File destDir, boolean preserveFileDate) throws IOException {
/*  936 */     if (destDir == null) {
/*  937 */       throw new NullPointerException("Destination must not be null");
/*      */     }
/*  939 */     if (destDir.exists() && !destDir.isDirectory()) {
/*  940 */       throw new IllegalArgumentException("Destination '" + destDir + "' is not a directory");
/*      */     }
/*  942 */     File destFile = new File(destDir, srcFile.getName());
/*  943 */     copyFile(srcFile, destFile, preserveFileDate);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void copyFile(File srcFile, File destFile) throws IOException {
/*  968 */     copyFile(srcFile, destFile, true);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void copyFile(File srcFile, File destFile, boolean preserveFileDate) throws IOException {
/*  997 */     if (srcFile == null) {
/*  998 */       throw new NullPointerException("Source must not be null");
/*      */     }
/* 1000 */     if (destFile == null) {
/* 1001 */       throw new NullPointerException("Destination must not be null");
/*      */     }
/* 1003 */     if (!srcFile.exists()) {
/* 1004 */       throw new FileNotFoundException("Source '" + srcFile + "' does not exist");
/*      */     }
/* 1006 */     if (srcFile.isDirectory()) {
/* 1007 */       throw new IOException("Source '" + srcFile + "' exists but is a directory");
/*      */     }
/* 1009 */     if (srcFile.getCanonicalPath().equals(destFile.getCanonicalPath())) {
/* 1010 */       throw new IOException("Source '" + srcFile + "' and destination '" + destFile + "' are the same");
/*      */     }
/* 1012 */     File parentFile = destFile.getParentFile();
/* 1013 */     if (parentFile != null && 
/* 1014 */       !parentFile.mkdirs() && !parentFile.isDirectory()) {
/* 1015 */       throw new IOException("Destination '" + parentFile + "' directory cannot be created");
/*      */     }
/*      */     
/* 1018 */     if (destFile.exists() && !destFile.canWrite()) {
/* 1019 */       throw new IOException("Destination '" + destFile + "' exists but is read-only");
/*      */     }
/* 1021 */     doCopyFile(srcFile, destFile, preserveFileDate);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static long copyFile(File input, OutputStream output) throws IOException {
/* 1042 */     FileInputStream fis = new FileInputStream(input);
/*      */     try {
/* 1044 */       return IOUtils.copyLarge(fis, output);
/*      */     } finally {
/* 1046 */       fis.close();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static void doCopyFile(File srcFile, File destFile, boolean preserveFileDate) throws IOException {
/* 1059 */     if (destFile.exists() && destFile.isDirectory()) {
/* 1060 */       throw new IOException("Destination '" + destFile + "' exists but is a directory");
/*      */     }
/*      */     
/* 1063 */     FileInputStream fis = null;
/* 1064 */     FileOutputStream fos = null;
/* 1065 */     FileChannel input = null;
/* 1066 */     FileChannel output = null;
/*      */     try {
/* 1068 */       fis = new FileInputStream(srcFile);
/* 1069 */       fos = new FileOutputStream(destFile);
/* 1070 */       input = fis.getChannel();
/* 1071 */       output = fos.getChannel();
/* 1072 */       long size = input.size();
/* 1073 */       long pos = 0L;
/* 1074 */       long count = 0L;
/* 1075 */       while (pos < size) {
/* 1076 */         count = (size - pos > 31457280L) ? 31457280L : (size - pos);
/* 1077 */         pos += output.transferFrom(input, pos, count);
/*      */       } 
/*      */     } finally {
/* 1080 */       IOUtils.closeQuietly(output);
/* 1081 */       IOUtils.closeQuietly(fos);
/* 1082 */       IOUtils.closeQuietly(input);
/* 1083 */       IOUtils.closeQuietly(fis);
/*      */     } 
/*      */     
/* 1086 */     if (srcFile.length() != destFile.length()) {
/* 1087 */       throw new IOException("Failed to copy full contents from '" + srcFile + "' to '" + destFile + "'");
/*      */     }
/*      */     
/* 1090 */     if (preserveFileDate) {
/* 1091 */       destFile.setLastModified(srcFile.lastModified());
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void copyDirectoryToDirectory(File srcDir, File destDir) throws IOException {
/* 1120 */     if (srcDir == null) {
/* 1121 */       throw new NullPointerException("Source must not be null");
/*      */     }
/* 1123 */     if (srcDir.exists() && !srcDir.isDirectory()) {
/* 1124 */       throw new IllegalArgumentException("Source '" + destDir + "' is not a directory");
/*      */     }
/* 1126 */     if (destDir == null) {
/* 1127 */       throw new NullPointerException("Destination must not be null");
/*      */     }
/* 1129 */     if (destDir.exists() && !destDir.isDirectory()) {
/* 1130 */       throw new IllegalArgumentException("Destination '" + destDir + "' is not a directory");
/*      */     }
/* 1132 */     copyDirectory(srcDir, new File(destDir, srcDir.getName()), true);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void copyDirectory(File srcDir, File destDir) throws IOException {
/* 1160 */     copyDirectory(srcDir, destDir, true);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void copyDirectory(File srcDir, File destDir, boolean preserveFileDate) throws IOException {
/* 1191 */     copyDirectory(srcDir, destDir, null, preserveFileDate);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void copyDirectory(File srcDir, File destDir, FileFilter filter) throws IOException {
/* 1240 */     copyDirectory(srcDir, destDir, filter, true);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void copyDirectory(File srcDir, File destDir, FileFilter filter, boolean preserveFileDate) throws IOException {
/* 1291 */     if (srcDir == null) {
/* 1292 */       throw new NullPointerException("Source must not be null");
/*      */     }
/* 1294 */     if (destDir == null) {
/* 1295 */       throw new NullPointerException("Destination must not be null");
/*      */     }
/* 1297 */     if (!srcDir.exists()) {
/* 1298 */       throw new FileNotFoundException("Source '" + srcDir + "' does not exist");
/*      */     }
/* 1300 */     if (!srcDir.isDirectory()) {
/* 1301 */       throw new IOException("Source '" + srcDir + "' exists but is not a directory");
/*      */     }
/* 1303 */     if (srcDir.getCanonicalPath().equals(destDir.getCanonicalPath())) {
/* 1304 */       throw new IOException("Source '" + srcDir + "' and destination '" + destDir + "' are the same");
/*      */     }
/*      */ 
/*      */     
/* 1308 */     List<String> exclusionList = null;
/* 1309 */     if (destDir.getCanonicalPath().startsWith(srcDir.getCanonicalPath())) {
/* 1310 */       File[] srcFiles = (filter == null) ? srcDir.listFiles() : srcDir.listFiles(filter);
/* 1311 */       if (srcFiles != null && srcFiles.length > 0) {
/* 1312 */         exclusionList = new ArrayList<String>(srcFiles.length);
/* 1313 */         for (File srcFile : srcFiles) {
/* 1314 */           File copiedFile = new File(destDir, srcFile.getName());
/* 1315 */           exclusionList.add(copiedFile.getCanonicalPath());
/*      */         } 
/*      */       } 
/*      */     } 
/* 1319 */     doCopyDirectory(srcDir, destDir, filter, preserveFileDate, exclusionList);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static void doCopyDirectory(File srcDir, File destDir, FileFilter filter, boolean preserveFileDate, List<String> exclusionList) throws IOException {
/* 1336 */     File[] srcFiles = (filter == null) ? srcDir.listFiles() : srcDir.listFiles(filter);
/* 1337 */     if (srcFiles == null) {
/* 1338 */       throw new IOException("Failed to list contents of " + srcDir);
/*      */     }
/* 1340 */     if (destDir.exists()) {
/* 1341 */       if (!destDir.isDirectory()) {
/* 1342 */         throw new IOException("Destination '" + destDir + "' exists but is not a directory");
/*      */       }
/*      */     }
/* 1345 */     else if (!destDir.mkdirs() && !destDir.isDirectory()) {
/* 1346 */       throw new IOException("Destination '" + destDir + "' directory cannot be created");
/*      */     } 
/*      */     
/* 1349 */     if (!destDir.canWrite()) {
/* 1350 */       throw new IOException("Destination '" + destDir + "' cannot be written to");
/*      */     }
/* 1352 */     for (File srcFile : srcFiles) {
/* 1353 */       File dstFile = new File(destDir, srcFile.getName());
/* 1354 */       if (exclusionList == null || !exclusionList.contains(srcFile.getCanonicalPath())) {
/* 1355 */         if (srcFile.isDirectory()) {
/* 1356 */           doCopyDirectory(srcFile, dstFile, filter, preserveFileDate, exclusionList);
/*      */         } else {
/* 1358 */           doCopyFile(srcFile, dstFile, preserveFileDate);
/*      */         } 
/*      */       }
/*      */     } 
/*      */ 
/*      */     
/* 1364 */     if (preserveFileDate) {
/* 1365 */       destDir.setLastModified(srcDir.lastModified());
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void copyURLToFile(URL source, File destination) throws IOException {
/* 1390 */     InputStream input = source.openStream();
/* 1391 */     copyInputStreamToFile(input, destination);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void copyURLToFile(URL source, File destination, int connectionTimeout, int readTimeout) throws IOException {
/* 1416 */     URLConnection connection = source.openConnection();
/* 1417 */     connection.setConnectTimeout(connectionTimeout);
/* 1418 */     connection.setReadTimeout(readTimeout);
/* 1419 */     InputStream input = connection.getInputStream();
/* 1420 */     copyInputStreamToFile(input, destination);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void copyInputStreamToFile(InputStream source, File destination) throws IOException {
/*      */     try {
/* 1440 */       FileOutputStream output = openOutputStream(destination);
/*      */       try {
/* 1442 */         IOUtils.copy(source, output);
/* 1443 */         output.close();
/*      */       } finally {
/* 1445 */         IOUtils.closeQuietly(output);
/*      */       } 
/*      */     } finally {
/* 1448 */       IOUtils.closeQuietly(source);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void deleteDirectory(File directory) throws IOException {
/* 1460 */     if (!directory.exists()) {
/*      */       return;
/*      */     }
/*      */     
/* 1464 */     if (!isSymlink(directory)) {
/* 1465 */       cleanDirectory(directory);
/*      */     }
/*      */     
/* 1468 */     if (!directory.delete()) {
/* 1469 */       String message = "Unable to delete directory " + directory + ".";
/*      */       
/* 1471 */       throw new IOException(message);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean deleteQuietly(File file) {
/* 1491 */     if (file == null) {
/* 1492 */       return false;
/*      */     }
/*      */     try {
/* 1495 */       if (file.isDirectory()) {
/* 1496 */         cleanDirectory(file);
/*      */       }
/* 1498 */     } catch (Exception ignored) {}
/*      */ 
/*      */     
/*      */     try {
/* 1502 */       return file.delete();
/* 1503 */     } catch (Exception ignored) {
/* 1504 */       return false;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean directoryContains(File directory, File child) throws IOException {
/* 1535 */     if (directory == null) {
/* 1536 */       throw new IllegalArgumentException("Directory must not be null");
/*      */     }
/*      */     
/* 1539 */     if (!directory.isDirectory()) {
/* 1540 */       throw new IllegalArgumentException("Not a directory: " + directory);
/*      */     }
/*      */     
/* 1543 */     if (child == null) {
/* 1544 */       return false;
/*      */     }
/*      */     
/* 1547 */     if (!directory.exists() || !child.exists()) {
/* 1548 */       return false;
/*      */     }
/*      */ 
/*      */     
/* 1552 */     String canonicalParent = directory.getCanonicalPath();
/* 1553 */     String canonicalChild = child.getCanonicalPath();
/*      */     
/* 1555 */     return FilenameUtils.directoryContains(canonicalParent, canonicalChild);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void cleanDirectory(File directory) throws IOException {
/* 1565 */     if (!directory.exists()) {
/* 1566 */       String message = directory + " does not exist";
/* 1567 */       throw new IllegalArgumentException(message);
/*      */     } 
/*      */     
/* 1570 */     if (!directory.isDirectory()) {
/* 1571 */       String message = directory + " is not a directory";
/* 1572 */       throw new IllegalArgumentException(message);
/*      */     } 
/*      */     
/* 1575 */     File[] files = directory.listFiles();
/* 1576 */     if (files == null) {
/* 1577 */       throw new IOException("Failed to list contents of " + directory);
/*      */     }
/*      */     
/* 1580 */     IOException exception = null;
/* 1581 */     for (File file : files) {
/*      */       try {
/* 1583 */         forceDelete(file);
/* 1584 */       } catch (IOException ioe) {
/* 1585 */         exception = ioe;
/*      */       } 
/*      */     } 
/*      */     
/* 1589 */     if (null != exception) {
/* 1590 */       throw exception;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean waitFor(File file, int seconds) {
/* 1607 */     int timeout = 0;
/* 1608 */     int tick = 0;
/* 1609 */     while (!file.exists()) {
/* 1610 */       if (tick++ >= 10) {
/* 1611 */         tick = 0;
/* 1612 */         if (timeout++ > seconds) {
/* 1613 */           return false;
/*      */         }
/*      */       } 
/*      */       try {
/* 1617 */         Thread.sleep(100L);
/* 1618 */       } catch (InterruptedException ignore) {
/*      */       
/* 1620 */       } catch (Exception ex) {
/*      */         break;
/*      */       } 
/*      */     } 
/* 1624 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String readFileToString(File file, String encoding) throws IOException {
/* 1639 */     InputStream in = null;
/*      */     try {
/* 1641 */       in = openInputStream(file);
/* 1642 */       return IOUtils.toString(in, encoding);
/*      */     } finally {
/* 1644 */       IOUtils.closeQuietly(in);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String readFileToString(File file) throws IOException {
/* 1659 */     return readFileToString(file, null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static byte[] readFileToByteArray(File file) throws IOException {
/* 1672 */     InputStream in = null;
/*      */     try {
/* 1674 */       in = openInputStream(file);
/* 1675 */       return IOUtils.toByteArray(in, file.length());
/*      */     } finally {
/* 1677 */       IOUtils.closeQuietly(in);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static List<String> readLines(File file, String encoding) throws IOException {
/* 1693 */     InputStream in = null;
/*      */     try {
/* 1695 */       in = openInputStream(file);
/* 1696 */       return IOUtils.readLines(in, encoding);
/*      */     } finally {
/* 1698 */       IOUtils.closeQuietly(in);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static List<String> readLines(File file) throws IOException {
/* 1712 */     return readLines(file, null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static LineIterator lineIterator(File file, String encoding) throws IOException {
/* 1747 */     InputStream in = null;
/*      */     try {
/* 1749 */       in = openInputStream(file);
/* 1750 */       return IOUtils.lineIterator(in, encoding);
/* 1751 */     } catch (IOException ex) {
/* 1752 */       IOUtils.closeQuietly(in);
/* 1753 */       throw ex;
/* 1754 */     } catch (RuntimeException ex) {
/* 1755 */       IOUtils.closeQuietly(in);
/* 1756 */       throw ex;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static LineIterator lineIterator(File file) throws IOException {
/* 1770 */     return lineIterator(file, null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void writeStringToFile(File file, String data, String encoding) throws IOException {
/* 1787 */     writeStringToFile(file, data, encoding, false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void writeStringToFile(File file, String data, String encoding, boolean append) throws IOException {
/* 1803 */     OutputStream out = null;
/*      */     try {
/* 1805 */       out = openOutputStream(file, append);
/* 1806 */       IOUtils.write(data, out, encoding);
/* 1807 */       out.close();
/*      */     } finally {
/* 1809 */       IOUtils.closeQuietly(out);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void writeStringToFile(File file, String data) throws IOException {
/* 1821 */     writeStringToFile(file, data, null, false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void writeStringToFile(File file, String data, boolean append) throws IOException {
/* 1835 */     writeStringToFile(file, data, null, append);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void write(File file, CharSequence data) throws IOException {
/* 1847 */     write(file, data, null, false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void write(File file, CharSequence data, boolean append) throws IOException {
/* 1861 */     write(file, data, null, append);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void write(File file, CharSequence data, String encoding) throws IOException {
/* 1875 */     write(file, data, encoding, false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void write(File file, CharSequence data, String encoding, boolean append) throws IOException {
/* 1891 */     String str = (data == null) ? null : data.toString();
/* 1892 */     writeStringToFile(file, str, encoding, append);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void writeByteArrayToFile(File file, byte[] data) throws IOException {
/* 1907 */     writeByteArrayToFile(file, data, false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void writeByteArrayToFile(File file, byte[] data, boolean append) throws IOException {
/* 1921 */     OutputStream out = null;
/*      */     try {
/* 1923 */       out = openOutputStream(file, append);
/* 1924 */       out.write(data);
/* 1925 */       out.close();
/*      */     } finally {
/* 1927 */       IOUtils.closeQuietly(out);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void writeLines(File file, String encoding, Collection<?> lines) throws IOException {
/* 1947 */     writeLines(file, encoding, lines, null, false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void writeLines(File file, String encoding, Collection<?> lines, boolean append) throws IOException {
/* 1965 */     writeLines(file, encoding, lines, null, append);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void writeLines(File file, Collection<?> lines) throws IOException {
/* 1979 */     writeLines(file, null, lines, null, false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void writeLines(File file, Collection<?> lines, boolean append) throws IOException {
/* 1995 */     writeLines(file, null, lines, null, append);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void writeLines(File file, String encoding, Collection<?> lines, String lineEnding) throws IOException {
/* 2016 */     writeLines(file, encoding, lines, lineEnding, false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void writeLines(File file, String encoding, Collection<?> lines, String lineEnding, boolean append) throws IOException {
/* 2036 */     OutputStream out = null;
/*      */     try {
/* 2038 */       out = openOutputStream(file, append);
/* 2039 */       IOUtils.writeLines(lines, lineEnding, out, encoding);
/* 2040 */       out.close();
/*      */     } finally {
/* 2042 */       IOUtils.closeQuietly(out);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void writeLines(File file, Collection<?> lines, String lineEnding) throws IOException {
/* 2058 */     writeLines(file, null, lines, lineEnding, false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void writeLines(File file, Collection<?> lines, String lineEnding, boolean append) throws IOException {
/* 2076 */     writeLines(file, null, lines, lineEnding, append);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void forceDelete(File file) throws IOException {
/* 2096 */     if (file.isDirectory()) {
/* 2097 */       deleteDirectory(file);
/*      */     } else {
/* 2099 */       boolean filePresent = file.exists();
/* 2100 */       if (!file.delete()) {
/* 2101 */         if (!filePresent) {
/* 2102 */           throw new FileNotFoundException("File does not exist: " + file);
/*      */         }
/* 2104 */         String message = "Unable to delete file: " + file;
/*      */         
/* 2106 */         throw new IOException(message);
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void forceDeleteOnExit(File file) throws IOException {
/* 2120 */     if (file.isDirectory()) {
/* 2121 */       deleteDirectoryOnExit(file);
/*      */     } else {
/* 2123 */       file.deleteOnExit();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static void deleteDirectoryOnExit(File directory) throws IOException {
/* 2135 */     if (!directory.exists()) {
/*      */       return;
/*      */     }
/*      */     
/* 2139 */     directory.deleteOnExit();
/* 2140 */     if (!isSymlink(directory)) {
/* 2141 */       cleanDirectoryOnExit(directory);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static void cleanDirectoryOnExit(File directory) throws IOException {
/* 2153 */     if (!directory.exists()) {
/* 2154 */       String message = directory + " does not exist";
/* 2155 */       throw new IllegalArgumentException(message);
/*      */     } 
/*      */     
/* 2158 */     if (!directory.isDirectory()) {
/* 2159 */       String message = directory + " is not a directory";
/* 2160 */       throw new IllegalArgumentException(message);
/*      */     } 
/*      */     
/* 2163 */     File[] files = directory.listFiles();
/* 2164 */     if (files == null) {
/* 2165 */       throw new IOException("Failed to list contents of " + directory);
/*      */     }
/*      */     
/* 2168 */     IOException exception = null;
/* 2169 */     for (File file : files) {
/*      */       try {
/* 2171 */         forceDeleteOnExit(file);
/* 2172 */       } catch (IOException ioe) {
/* 2173 */         exception = ioe;
/*      */       } 
/*      */     } 
/*      */     
/* 2177 */     if (null != exception) {
/* 2178 */       throw exception;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void forceMkdir(File directory) throws IOException {
/* 2194 */     if (directory.exists()) {
/* 2195 */       if (!directory.isDirectory()) {
/* 2196 */         String message = "File " + directory + " exists and is " + "not a directory. Unable to create directory.";
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2201 */         throw new IOException(message);
/*      */       }
/*      */     
/* 2204 */     } else if (!directory.mkdirs()) {
/*      */ 
/*      */       
/* 2207 */       if (!directory.isDirectory()) {
/*      */         
/* 2209 */         String message = "Unable to create directory " + directory;
/*      */         
/* 2211 */         throw new IOException(message);
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static long sizeOf(File file) {
/* 2238 */     if (!file.exists()) {
/* 2239 */       String message = file + " does not exist";
/* 2240 */       throw new IllegalArgumentException(message);
/*      */     } 
/*      */     
/* 2243 */     if (file.isDirectory()) {
/* 2244 */       return sizeOfDirectory(file);
/*      */     }
/* 2246 */     return file.length();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static long sizeOfDirectory(File directory) {
/* 2259 */     if (!directory.exists()) {
/* 2260 */       String message = directory + " does not exist";
/* 2261 */       throw new IllegalArgumentException(message);
/*      */     } 
/*      */     
/* 2264 */     if (!directory.isDirectory()) {
/* 2265 */       String message = directory + " is not a directory";
/* 2266 */       throw new IllegalArgumentException(message);
/*      */     } 
/*      */     
/* 2269 */     long size = 0L;
/*      */     
/* 2271 */     File[] files = directory.listFiles();
/* 2272 */     if (files == null) {
/* 2273 */       return 0L;
/*      */     }
/* 2275 */     for (File file : files) {
/* 2276 */       size += sizeOf(file);
/*      */     }
/*      */     
/* 2279 */     return size;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isFileNewer(File file, File reference) {
/* 2297 */     if (reference == null) {
/* 2298 */       throw new IllegalArgumentException("No specified reference file");
/*      */     }
/* 2300 */     if (!reference.exists()) {
/* 2301 */       throw new IllegalArgumentException("The reference file '" + reference + "' doesn't exist");
/*      */     }
/*      */     
/* 2304 */     return isFileNewer(file, reference.lastModified());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isFileNewer(File file, Date date) {
/* 2320 */     if (date == null) {
/* 2321 */       throw new IllegalArgumentException("No specified date");
/*      */     }
/* 2323 */     return isFileNewer(file, date.getTime());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isFileNewer(File file, long timeMillis) {
/* 2339 */     if (file == null) {
/* 2340 */       throw new IllegalArgumentException("No specified file");
/*      */     }
/* 2342 */     if (!file.exists()) {
/* 2343 */       return false;
/*      */     }
/* 2345 */     return (file.lastModified() > timeMillis);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isFileOlder(File file, File reference) {
/* 2364 */     if (reference == null) {
/* 2365 */       throw new IllegalArgumentException("No specified reference file");
/*      */     }
/* 2367 */     if (!reference.exists()) {
/* 2368 */       throw new IllegalArgumentException("The reference file '" + reference + "' doesn't exist");
/*      */     }
/*      */     
/* 2371 */     return isFileOlder(file, reference.lastModified());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isFileOlder(File file, Date date) {
/* 2387 */     if (date == null) {
/* 2388 */       throw new IllegalArgumentException("No specified date");
/*      */     }
/* 2390 */     return isFileOlder(file, date.getTime());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isFileOlder(File file, long timeMillis) {
/* 2406 */     if (file == null) {
/* 2407 */       throw new IllegalArgumentException("No specified file");
/*      */     }
/* 2409 */     if (!file.exists()) {
/* 2410 */       return false;
/*      */     }
/* 2412 */     return (file.lastModified() < timeMillis);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static long checksumCRC32(File file) throws IOException {
/* 2428 */     CRC32 crc = new CRC32();
/* 2429 */     checksum(file, crc);
/* 2430 */     return crc.getValue();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Checksum checksum(File file, Checksum checksum) throws IOException {
/* 2451 */     if (file.isDirectory()) {
/* 2452 */       throw new IllegalArgumentException("Checksums can't be computed on directories");
/*      */     }
/* 2454 */     InputStream in = null;
/*      */     try {
/* 2456 */       in = new CheckedInputStream(new FileInputStream(file), checksum);
/* 2457 */       IOUtils.copy(in, (OutputStream)new NullOutputStream());
/*      */     } finally {
/* 2459 */       IOUtils.closeQuietly(in);
/*      */     } 
/* 2461 */     return checksum;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void moveDirectory(File srcDir, File destDir) throws IOException {
/* 2478 */     if (srcDir == null) {
/* 2479 */       throw new NullPointerException("Source must not be null");
/*      */     }
/* 2481 */     if (destDir == null) {
/* 2482 */       throw new NullPointerException("Destination must not be null");
/*      */     }
/* 2484 */     if (!srcDir.exists()) {
/* 2485 */       throw new FileNotFoundException("Source '" + srcDir + "' does not exist");
/*      */     }
/* 2487 */     if (!srcDir.isDirectory()) {
/* 2488 */       throw new IOException("Source '" + srcDir + "' is not a directory");
/*      */     }
/* 2490 */     if (destDir.exists()) {
/* 2491 */       throw new FileExistsException("Destination '" + destDir + "' already exists");
/*      */     }
/* 2493 */     boolean rename = srcDir.renameTo(destDir);
/* 2494 */     if (!rename) {
/* 2495 */       if (destDir.getCanonicalPath().startsWith(srcDir.getCanonicalPath())) {
/* 2496 */         throw new IOException("Cannot move directory: " + srcDir + " to a subdirectory of itself: " + destDir);
/*      */       }
/* 2498 */       copyDirectory(srcDir, destDir);
/* 2499 */       deleteDirectory(srcDir);
/* 2500 */       if (srcDir.exists()) {
/* 2501 */         throw new IOException("Failed to delete original directory '" + srcDir + "' after copy to '" + destDir + "'");
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void moveDirectoryToDirectory(File src, File destDir, boolean createDestDir) throws IOException {
/* 2521 */     if (src == null) {
/* 2522 */       throw new NullPointerException("Source must not be null");
/*      */     }
/* 2524 */     if (destDir == null) {
/* 2525 */       throw new NullPointerException("Destination directory must not be null");
/*      */     }
/* 2527 */     if (!destDir.exists() && createDestDir) {
/* 2528 */       destDir.mkdirs();
/*      */     }
/* 2530 */     if (!destDir.exists()) {
/* 2531 */       throw new FileNotFoundException("Destination directory '" + destDir + "' does not exist [createDestDir=" + createDestDir + "]");
/*      */     }
/*      */     
/* 2534 */     if (!destDir.isDirectory()) {
/* 2535 */       throw new IOException("Destination '" + destDir + "' is not a directory");
/*      */     }
/* 2537 */     moveDirectory(src, new File(destDir, src.getName()));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void moveFile(File srcFile, File destFile) throws IOException {
/* 2555 */     if (srcFile == null) {
/* 2556 */       throw new NullPointerException("Source must not be null");
/*      */     }
/* 2558 */     if (destFile == null) {
/* 2559 */       throw new NullPointerException("Destination must not be null");
/*      */     }
/* 2561 */     if (!srcFile.exists()) {
/* 2562 */       throw new FileNotFoundException("Source '" + srcFile + "' does not exist");
/*      */     }
/* 2564 */     if (srcFile.isDirectory()) {
/* 2565 */       throw new IOException("Source '" + srcFile + "' is a directory");
/*      */     }
/* 2567 */     if (destFile.exists()) {
/* 2568 */       throw new FileExistsException("Destination '" + destFile + "' already exists");
/*      */     }
/* 2570 */     if (destFile.isDirectory()) {
/* 2571 */       throw new IOException("Destination '" + destFile + "' is a directory");
/*      */     }
/* 2573 */     boolean rename = srcFile.renameTo(destFile);
/* 2574 */     if (!rename) {
/* 2575 */       copyFile(srcFile, destFile);
/* 2576 */       if (!srcFile.delete()) {
/* 2577 */         deleteQuietly(destFile);
/* 2578 */         throw new IOException("Failed to delete original file '" + srcFile + "' after copy to '" + destFile + "'");
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void moveFileToDirectory(File srcFile, File destDir, boolean createDestDir) throws IOException {
/* 2598 */     if (srcFile == null) {
/* 2599 */       throw new NullPointerException("Source must not be null");
/*      */     }
/* 2601 */     if (destDir == null) {
/* 2602 */       throw new NullPointerException("Destination directory must not be null");
/*      */     }
/* 2604 */     if (!destDir.exists() && createDestDir) {
/* 2605 */       destDir.mkdirs();
/*      */     }
/* 2607 */     if (!destDir.exists()) {
/* 2608 */       throw new FileNotFoundException("Destination directory '" + destDir + "' does not exist [createDestDir=" + createDestDir + "]");
/*      */     }
/*      */     
/* 2611 */     if (!destDir.isDirectory()) {
/* 2612 */       throw new IOException("Destination '" + destDir + "' is not a directory");
/*      */     }
/* 2614 */     moveFile(srcFile, new File(destDir, srcFile.getName()));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void moveToDirectory(File src, File destDir, boolean createDestDir) throws IOException {
/* 2633 */     if (src == null) {
/* 2634 */       throw new NullPointerException("Source must not be null");
/*      */     }
/* 2636 */     if (destDir == null) {
/* 2637 */       throw new NullPointerException("Destination must not be null");
/*      */     }
/* 2639 */     if (!src.exists()) {
/* 2640 */       throw new FileNotFoundException("Source '" + src + "' does not exist");
/*      */     }
/* 2642 */     if (src.isDirectory()) {
/* 2643 */       moveDirectoryToDirectory(src, destDir, createDestDir);
/*      */     } else {
/* 2645 */       moveFileToDirectory(src, destDir, createDestDir);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isSymlink(File file) throws IOException {
/* 2664 */     if (file == null) {
/* 2665 */       throw new NullPointerException("File must not be null");
/*      */     }
/* 2667 */     if (FilenameUtils.isSystemWindows()) {
/* 2668 */       return false;
/*      */     }
/* 2670 */     File fileInCanonicalDir = null;
/* 2671 */     if (file.getParent() == null) {
/* 2672 */       fileInCanonicalDir = file;
/*      */     } else {
/* 2674 */       File canonicalDir = file.getParentFile().getCanonicalFile();
/* 2675 */       fileInCanonicalDir = new File(canonicalDir, file.getName());
/*      */     } 
/*      */     
/* 2678 */     if (fileInCanonicalDir.getCanonicalFile().equals(fileInCanonicalDir.getAbsoluteFile())) {
/* 2679 */       return false;
/*      */     }
/* 2681 */     return true;
/*      */   }
/*      */ }


/* Location:              C:\Users\olatu\OneDrive\Documents\Calypso\syncbase\sync_base.jar!\BOOT-INF\lib\commons-io-2.2.jar!\org\apache\commons\io\FileUtils.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */