/*      */ package org.apache.commons.io;
/*      */ 
/*      */ import java.io.BufferedInputStream;
/*      */ import java.io.BufferedReader;
/*      */ import java.io.ByteArrayInputStream;
/*      */ import java.io.CharArrayWriter;
/*      */ import java.io.Closeable;
/*      */ import java.io.EOFException;
/*      */ import java.io.File;
/*      */ import java.io.IOException;
/*      */ import java.io.InputStream;
/*      */ import java.io.InputStreamReader;
/*      */ import java.io.OutputStream;
/*      */ import java.io.OutputStreamWriter;
/*      */ import java.io.PrintWriter;
/*      */ import java.io.Reader;
/*      */ import java.io.Writer;
/*      */ import java.net.ServerSocket;
/*      */ import java.net.Socket;
/*      */ import java.net.URI;
/*      */ import java.net.URL;
/*      */ import java.nio.channels.Selector;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Collection;
/*      */ import java.util.List;
/*      */ import org.apache.commons.io.output.ByteArrayOutputStream;
/*      */ import org.apache.commons.io.output.StringBuilderWriter;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class IOUtils
/*      */ {
/*      */   private static final int EOF = -1;
/*      */   public static final char DIR_SEPARATOR_UNIX = '/';
/*      */   public static final char DIR_SEPARATOR_WINDOWS = '\\';
/*   96 */   public static final char DIR_SEPARATOR = File.separatorChar;
/*      */   
/*      */   public static final String LINE_SEPARATOR_UNIX = "\n";
/*      */   
/*      */   public static final String LINE_SEPARATOR_WINDOWS = "\r\n";
/*      */   
/*      */   public static final String LINE_SEPARATOR;
/*      */   
/*      */   private static final int DEFAULT_BUFFER_SIZE = 4096;
/*      */   
/*      */   private static final int SKIP_BUFFER_SIZE = 2048;
/*      */   
/*      */   private static char[] SKIP_CHAR_BUFFER;
/*      */   private static byte[] SKIP_BYTE_BUFFER;
/*      */   
/*      */   static {
/*  112 */     StringBuilderWriter buf = new StringBuilderWriter(4);
/*  113 */     PrintWriter out = new PrintWriter((Writer)buf);
/*  114 */     out.println();
/*  115 */     LINE_SEPARATOR = buf.toString();
/*  116 */     out.close();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void closeQuietly(Reader input) {
/*  175 */     closeQuietly(input);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void closeQuietly(Writer output) {
/*  201 */     closeQuietly(output);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void closeQuietly(InputStream input) {
/*  228 */     closeQuietly(input);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void closeQuietly(OutputStream output) {
/*  256 */     closeQuietly(output);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void closeQuietly(Closeable closeable) {
/*      */     try {
/*  284 */       if (closeable != null) {
/*  285 */         closeable.close();
/*      */       }
/*  287 */     } catch (IOException ioe) {}
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void closeQuietly(Socket sock) {
/*  316 */     if (sock != null) {
/*      */       try {
/*  318 */         sock.close();
/*  319 */       } catch (IOException ioe) {}
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void closeQuietly(Selector selector) {
/*  349 */     if (selector != null) {
/*      */       try {
/*  351 */         selector.close();
/*  352 */       } catch (IOException ioe) {}
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void closeQuietly(ServerSocket sock) {
/*  382 */     if (sock != null) {
/*      */       try {
/*  384 */         sock.close();
/*  385 */       } catch (IOException ioe) {}
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static InputStream toBufferedInputStream(InputStream input) throws IOException {
/*  413 */     return ByteArrayOutputStream.toBufferedInputStream(input);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static BufferedReader toBufferedReader(Reader reader) {
/*  426 */     return (reader instanceof BufferedReader) ? (BufferedReader)reader : new BufferedReader(reader);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static byte[] toByteArray(InputStream input) throws IOException {
/*  443 */     ByteArrayOutputStream output = new ByteArrayOutputStream();
/*  444 */     copy(input, (OutputStream)output);
/*  445 */     return output.toByteArray();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static byte[] toByteArray(InputStream input, long size) throws IOException {
/*  466 */     if (size > 2147483647L) {
/*  467 */       throw new IllegalArgumentException("Size cannot be greater than Integer max value: " + size);
/*      */     }
/*      */     
/*  470 */     return toByteArray(input, (int)size);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static byte[] toByteArray(InputStream input, int size) throws IOException {
/*  486 */     if (size < 0) {
/*  487 */       throw new IllegalArgumentException("Size must be equal or greater than zero: " + size);
/*      */     }
/*      */     
/*  490 */     if (size == 0) {
/*  491 */       return new byte[0];
/*      */     }
/*      */     
/*  494 */     byte[] data = new byte[size];
/*  495 */     int offset = 0;
/*      */     
/*      */     int readed;
/*  498 */     while (offset < size && (readed = input.read(data, offset, size - offset)) != -1) {
/*  499 */       offset += readed;
/*      */     }
/*      */     
/*  502 */     if (offset != size) {
/*  503 */       throw new IOException("Unexpected readed size. current: " + offset + ", excepted: " + size);
/*      */     }
/*      */     
/*  506 */     return data;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static byte[] toByteArray(Reader input) throws IOException {
/*  522 */     ByteArrayOutputStream output = new ByteArrayOutputStream();
/*  523 */     copy(input, (OutputStream)output);
/*  524 */     return output.toByteArray();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static byte[] toByteArray(Reader input, String encoding) throws IOException {
/*  546 */     ByteArrayOutputStream output = new ByteArrayOutputStream();
/*  547 */     copy(input, (OutputStream)output, encoding);
/*  548 */     return output.toByteArray();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public static byte[] toByteArray(String input) throws IOException {
/*  565 */     return input.getBytes();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static char[] toCharArray(InputStream is) throws IOException {
/*  584 */     CharArrayWriter output = new CharArrayWriter();
/*  585 */     copy(is, output);
/*  586 */     return output.toCharArray();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static char[] toCharArray(InputStream is, String encoding) throws IOException {
/*  608 */     CharArrayWriter output = new CharArrayWriter();
/*  609 */     copy(is, output, encoding);
/*  610 */     return output.toCharArray();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static char[] toCharArray(Reader input) throws IOException {
/*  626 */     CharArrayWriter sw = new CharArrayWriter();
/*  627 */     copy(input, sw);
/*  628 */     return sw.toCharArray();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String toString(InputStream input) throws IOException {
/*  646 */     return toString(input, (String)null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String toString(InputStream input, String encoding) throws IOException {
/*  667 */     StringBuilderWriter sw = new StringBuilderWriter();
/*  668 */     copy(input, (Writer)sw, encoding);
/*  669 */     return sw.toString();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String toString(Reader input) throws IOException {
/*  684 */     StringBuilderWriter sw = new StringBuilderWriter();
/*  685 */     copy(input, (Writer)sw);
/*  686 */     return sw.toString();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String toString(URI uri) throws IOException {
/*  699 */     return toString(uri, (String)null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String toString(URI uri, String encoding) throws IOException {
/*  714 */     return toString(uri.toURL(), encoding);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String toString(URL url) throws IOException {
/*  727 */     return toString(url, (String)null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String toString(URL url, String encoding) throws IOException {
/*  742 */     InputStream inputStream = url.openStream();
/*      */     try {
/*  744 */       return toString(inputStream, encoding);
/*      */     } finally {
/*  746 */       inputStream.close();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public static String toString(byte[] input) throws IOException {
/*  762 */     return new String(input);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public static String toString(byte[] input, String encoding) throws IOException {
/*  782 */     if (encoding == null) {
/*  783 */       return new String(input);
/*      */     }
/*  785 */     return new String(input, encoding);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static List<String> readLines(InputStream input) throws IOException {
/*  805 */     InputStreamReader reader = new InputStreamReader(input);
/*  806 */     return readLines(reader);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static List<String> readLines(InputStream input, String encoding) throws IOException {
/*  827 */     if (encoding == null) {
/*  828 */       return readLines(input);
/*      */     }
/*  830 */     InputStreamReader reader = new InputStreamReader(input, encoding);
/*  831 */     return readLines(reader);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static List<String> readLines(Reader input) throws IOException {
/*  849 */     BufferedReader reader = toBufferedReader(input);
/*  850 */     List<String> list = new ArrayList<String>();
/*  851 */     String line = reader.readLine();
/*  852 */     while (line != null) {
/*  853 */       list.add(line);
/*  854 */       line = reader.readLine();
/*      */     } 
/*  856 */     return list;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static LineIterator lineIterator(Reader reader) {
/*  889 */     return new LineIterator(reader);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static LineIterator lineIterator(InputStream input, String encoding) throws IOException {
/*  924 */     Reader reader = null;
/*  925 */     if (encoding == null) {
/*  926 */       reader = new InputStreamReader(input);
/*      */     } else {
/*  928 */       reader = new InputStreamReader(input, encoding);
/*      */     } 
/*  930 */     return new LineIterator(reader);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static InputStream toInputStream(CharSequence input) {
/*  943 */     return toInputStream(input.toString());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static InputStream toInputStream(CharSequence input, String encoding) throws IOException {
/*  960 */     return toInputStream(input.toString(), encoding);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static InputStream toInputStream(String input) {
/*  973 */     byte[] bytes = input.getBytes();
/*  974 */     return new ByteArrayInputStream(bytes);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static InputStream toInputStream(String input, String encoding) throws IOException {
/*  991 */     byte[] bytes = (encoding != null) ? input.getBytes(encoding) : input.getBytes();
/*  992 */     return new ByteArrayInputStream(bytes);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void write(byte[] data, OutputStream output) throws IOException {
/* 1009 */     if (data != null) {
/* 1010 */       output.write(data);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void write(byte[] data, Writer output) throws IOException {
/* 1028 */     if (data != null) {
/* 1029 */       output.write(new String(data));
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void write(byte[] data, Writer output, String encoding) throws IOException {
/* 1052 */     if (data != null) {
/* 1053 */       if (encoding == null) {
/* 1054 */         write(data, output);
/*      */       } else {
/* 1056 */         output.write(new String(data, encoding));
/*      */       } 
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void write(char[] data, Writer output) throws IOException {
/* 1075 */     if (data != null) {
/* 1076 */       output.write(data);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void write(char[] data, OutputStream output) throws IOException {
/* 1096 */     if (data != null) {
/* 1097 */       output.write((new String(data)).getBytes());
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void write(char[] data, OutputStream output, String encoding) throws IOException {
/* 1121 */     if (data != null) {
/* 1122 */       if (encoding == null) {
/* 1123 */         write(data, output);
/*      */       } else {
/* 1125 */         output.write((new String(data)).getBytes(encoding));
/*      */       } 
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void write(CharSequence data, Writer output) throws IOException {
/* 1142 */     if (data != null) {
/* 1143 */       write(data.toString(), output);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void write(CharSequence data, OutputStream output) throws IOException {
/* 1162 */     if (data != null) {
/* 1163 */       write(data.toString(), output);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void write(CharSequence data, OutputStream output, String encoding) throws IOException {
/* 1185 */     if (data != null) {
/* 1186 */       write(data.toString(), output, encoding);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void write(String data, Writer output) throws IOException {
/* 1202 */     if (data != null) {
/* 1203 */       output.write(data);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void write(String data, OutputStream output) throws IOException {
/* 1222 */     if (data != null) {
/* 1223 */       output.write(data.getBytes());
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void write(String data, OutputStream output, String encoding) throws IOException {
/* 1245 */     if (data != null) {
/* 1246 */       if (encoding == null) {
/* 1247 */         write(data, output);
/*      */       } else {
/* 1249 */         output.write(data.getBytes(encoding));
/*      */       } 
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public static void write(StringBuffer data, Writer output) throws IOException {
/* 1269 */     if (data != null) {
/* 1270 */       output.write(data.toString());
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public static void write(StringBuffer data, OutputStream output) throws IOException {
/* 1291 */     if (data != null) {
/* 1292 */       output.write(data.toString().getBytes());
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public static void write(StringBuffer data, OutputStream output, String encoding) throws IOException {
/* 1316 */     if (data != null) {
/* 1317 */       if (encoding == null) {
/* 1318 */         write(data, output);
/*      */       } else {
/* 1320 */         output.write(data.toString().getBytes(encoding));
/*      */       } 
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void writeLines(Collection<?> lines, String lineEnding, OutputStream output) throws IOException {
/* 1341 */     if (lines == null) {
/*      */       return;
/*      */     }
/* 1344 */     if (lineEnding == null) {
/* 1345 */       lineEnding = LINE_SEPARATOR;
/*      */     }
/* 1347 */     for (Object line : lines) {
/* 1348 */       if (line != null) {
/* 1349 */         output.write(line.toString().getBytes());
/*      */       }
/* 1351 */       output.write(lineEnding.getBytes());
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void writeLines(Collection<?> lines, String lineEnding, OutputStream output, String encoding) throws IOException {
/* 1373 */     if (encoding == null) {
/* 1374 */       writeLines(lines, lineEnding, output);
/*      */     } else {
/* 1376 */       if (lines == null) {
/*      */         return;
/*      */       }
/* 1379 */       if (lineEnding == null) {
/* 1380 */         lineEnding = LINE_SEPARATOR;
/*      */       }
/* 1382 */       for (Object line : lines) {
/* 1383 */         if (line != null) {
/* 1384 */           output.write(line.toString().getBytes(encoding));
/*      */         }
/* 1386 */         output.write(lineEnding.getBytes(encoding));
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void writeLines(Collection<?> lines, String lineEnding, Writer writer) throws IOException {
/* 1404 */     if (lines == null) {
/*      */       return;
/*      */     }
/* 1407 */     if (lineEnding == null) {
/* 1408 */       lineEnding = LINE_SEPARATOR;
/*      */     }
/* 1410 */     for (Object line : lines) {
/* 1411 */       if (line != null) {
/* 1412 */         writer.write(line.toString());
/*      */       }
/* 1414 */       writer.write(lineEnding);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int copy(InputStream input, OutputStream output) throws IOException {
/* 1440 */     long count = copyLarge(input, output);
/* 1441 */     if (count > 2147483647L) {
/* 1442 */       return -1;
/*      */     }
/* 1444 */     return (int)count;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static long copyLarge(InputStream input, OutputStream output) throws IOException {
/* 1465 */     return copyLarge(input, output, new byte[4096]);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static long copyLarge(InputStream input, OutputStream output, byte[] buffer) throws IOException {
/* 1486 */     long count = 0L;
/* 1487 */     int n = 0;
/* 1488 */     while (-1 != (n = input.read(buffer))) {
/* 1489 */       output.write(buffer, 0, n);
/* 1490 */       count += n;
/*      */     } 
/* 1492 */     return count;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static long copyLarge(InputStream input, OutputStream output, long inputOffset, long length) throws IOException {
/* 1516 */     return copyLarge(input, output, inputOffset, length, new byte[4096]);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static long copyLarge(InputStream input, OutputStream output, long inputOffset, long length, byte[] buffer) throws IOException {
/* 1541 */     if (inputOffset > 0L) {
/* 1542 */       skipFully(input, inputOffset);
/*      */     }
/* 1544 */     if (length == 0L) {
/* 1545 */       return 0L;
/*      */     }
/* 1547 */     int bufferLength = buffer.length;
/* 1548 */     int bytesToRead = bufferLength;
/* 1549 */     if (length > 0L && length < bufferLength) {
/* 1550 */       bytesToRead = (int)length;
/*      */     }
/*      */     
/* 1553 */     long totalRead = 0L; int read;
/* 1554 */     while (bytesToRead > 0 && -1 != (read = input.read(buffer, 0, bytesToRead))) {
/* 1555 */       output.write(buffer, 0, read);
/* 1556 */       totalRead += read;
/* 1557 */       if (length > 0L)
/*      */       {
/* 1559 */         bytesToRead = (int)Math.min(length - totalRead, bufferLength);
/*      */       }
/*      */     } 
/* 1562 */     return totalRead;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void copy(InputStream input, Writer output) throws IOException {
/* 1582 */     InputStreamReader in = new InputStreamReader(input);
/* 1583 */     copy(in, output);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void copy(InputStream input, Writer output, String encoding) throws IOException {
/* 1607 */     if (encoding == null) {
/* 1608 */       copy(input, output);
/*      */     } else {
/* 1610 */       InputStreamReader in = new InputStreamReader(input, encoding);
/* 1611 */       copy(in, output);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int copy(Reader input, Writer output) throws IOException {
/* 1636 */     long count = copyLarge(input, output);
/* 1637 */     if (count > 2147483647L) {
/* 1638 */       return -1;
/*      */     }
/* 1640 */     return (int)count;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static long copyLarge(Reader input, Writer output) throws IOException {
/* 1659 */     return copyLarge(input, output, new char[4096]);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static long copyLarge(Reader input, Writer output, char[] buffer) throws IOException {
/* 1678 */     long count = 0L;
/* 1679 */     int n = 0;
/* 1680 */     while (-1 != (n = input.read(buffer))) {
/* 1681 */       output.write(buffer, 0, n);
/* 1682 */       count += n;
/*      */     } 
/* 1684 */     return count;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static long copyLarge(Reader input, Writer output, long inputOffset, long length) throws IOException {
/* 1708 */     return copyLarge(input, output, inputOffset, length, new char[4096]);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static long copyLarge(Reader input, Writer output, long inputOffset, long length, char[] buffer) throws IOException {
/* 1732 */     if (inputOffset > 0L) {
/* 1733 */       skipFully(input, inputOffset);
/*      */     }
/* 1735 */     if (length == 0L) {
/* 1736 */       return 0L;
/*      */     }
/* 1738 */     int bytesToRead = buffer.length;
/* 1739 */     if (length > 0L && length < buffer.length) {
/* 1740 */       bytesToRead = (int)length;
/*      */     }
/*      */     
/* 1743 */     long totalRead = 0L; int read;
/* 1744 */     while (bytesToRead > 0 && -1 != (read = input.read(buffer, 0, bytesToRead))) {
/* 1745 */       output.write(buffer, 0, read);
/* 1746 */       totalRead += read;
/* 1747 */       if (length > 0L)
/*      */       {
/* 1749 */         bytesToRead = (int)Math.min(length - totalRead, buffer.length);
/*      */       }
/*      */     } 
/* 1752 */     return totalRead;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void copy(Reader input, OutputStream output) throws IOException {
/* 1776 */     OutputStreamWriter out = new OutputStreamWriter(output);
/* 1777 */     copy(input, out);
/*      */ 
/*      */     
/* 1780 */     out.flush();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void copy(Reader input, OutputStream output, String encoding) throws IOException {
/* 1808 */     if (encoding == null) {
/* 1809 */       copy(input, output);
/*      */     } else {
/* 1811 */       OutputStreamWriter out = new OutputStreamWriter(output, encoding);
/* 1812 */       copy(input, out);
/*      */ 
/*      */       
/* 1815 */       out.flush();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean contentEquals(InputStream input1, InputStream input2) throws IOException {
/* 1837 */     if (!(input1 instanceof BufferedInputStream)) {
/* 1838 */       input1 = new BufferedInputStream(input1);
/*      */     }
/* 1840 */     if (!(input2 instanceof BufferedInputStream)) {
/* 1841 */       input2 = new BufferedInputStream(input2);
/*      */     }
/*      */     
/* 1844 */     int ch = input1.read();
/* 1845 */     while (-1 != ch) {
/* 1846 */       int i = input2.read();
/* 1847 */       if (ch != i) {
/* 1848 */         return false;
/*      */       }
/* 1850 */       ch = input1.read();
/*      */     } 
/*      */     
/* 1853 */     int ch2 = input2.read();
/* 1854 */     return (ch2 == -1);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean contentEquals(Reader input1, Reader input2) throws IOException {
/* 1875 */     input1 = toBufferedReader(input1);
/* 1876 */     input2 = toBufferedReader(input2);
/*      */     
/* 1878 */     int ch = input1.read();
/* 1879 */     while (-1 != ch) {
/* 1880 */       int i = input2.read();
/* 1881 */       if (ch != i) {
/* 1882 */         return false;
/*      */       }
/* 1884 */       ch = input1.read();
/*      */     } 
/*      */     
/* 1887 */     int ch2 = input2.read();
/* 1888 */     return (ch2 == -1);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean contentEqualsIgnoreEOL(Reader input1, Reader input2) throws IOException {
/* 1907 */     BufferedReader br1 = toBufferedReader(input1);
/* 1908 */     BufferedReader br2 = toBufferedReader(input2);
/*      */     
/* 1910 */     String line1 = br1.readLine();
/* 1911 */     String line2 = br2.readLine();
/* 1912 */     while (line1 != null && line2 != null && line1.equals(line2)) {
/* 1913 */       line1 = br1.readLine();
/* 1914 */       line2 = br2.readLine();
/*      */     } 
/* 1916 */     return (line1 == null) ? ((line2 == null)) : line1.equals(line2);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static long skip(InputStream input, long toSkip) throws IOException {
/* 1936 */     if (toSkip < 0L) {
/* 1937 */       throw new IllegalArgumentException("Skip count must be non-negative, actual: " + toSkip);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1944 */     if (SKIP_BYTE_BUFFER == null) {
/* 1945 */       SKIP_BYTE_BUFFER = new byte[2048];
/*      */     }
/* 1947 */     long remain = toSkip;
/* 1948 */     while (remain > 0L) {
/* 1949 */       long n = input.read(SKIP_BYTE_BUFFER, 0, (int)Math.min(remain, 2048L));
/* 1950 */       if (n < 0L) {
/*      */         break;
/*      */       }
/* 1953 */       remain -= n;
/*      */     } 
/* 1955 */     return toSkip - remain;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static long skip(Reader input, long toSkip) throws IOException {
/* 1975 */     if (toSkip < 0L) {
/* 1976 */       throw new IllegalArgumentException("Skip count must be non-negative, actual: " + toSkip);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1983 */     if (SKIP_CHAR_BUFFER == null) {
/* 1984 */       SKIP_CHAR_BUFFER = new char[2048];
/*      */     }
/* 1986 */     long remain = toSkip;
/* 1987 */     while (remain > 0L) {
/* 1988 */       long n = input.read(SKIP_CHAR_BUFFER, 0, (int)Math.min(remain, 2048L));
/* 1989 */       if (n < 0L) {
/*      */         break;
/*      */       }
/* 1992 */       remain -= n;
/*      */     } 
/* 1994 */     return toSkip - remain;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void skipFully(InputStream input, long toSkip) throws IOException {
/* 2013 */     if (toSkip < 0L) {
/* 2014 */       throw new IllegalArgumentException("Bytes to skip must not be negative: " + toSkip);
/*      */     }
/* 2016 */     long skipped = skip(input, toSkip);
/* 2017 */     if (skipped != toSkip) {
/* 2018 */       throw new EOFException("Bytes to skip: " + toSkip + " actual: " + skipped);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void skipFully(Reader input, long toSkip) throws IOException {
/* 2038 */     long skipped = skip(input, toSkip);
/* 2039 */     if (skipped != toSkip) {
/* 2040 */       throw new EOFException("Chars to skip: " + toSkip + " actual: " + skipped);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int read(Reader input, char[] buffer, int offset, int length) throws IOException {
/* 2060 */     if (length < 0) {
/* 2061 */       throw new IllegalArgumentException("Length must not be negative: " + length);
/*      */     }
/* 2063 */     int remaining = length;
/* 2064 */     while (remaining > 0) {
/* 2065 */       int location = length - remaining;
/* 2066 */       int count = input.read(buffer, offset + location, remaining);
/* 2067 */       if (-1 == count) {
/*      */         break;
/*      */       }
/* 2070 */       remaining -= count;
/*      */     } 
/* 2072 */     return length - remaining;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int read(Reader input, char[] buffer) throws IOException {
/* 2088 */     return read(input, buffer, 0, buffer.length);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int read(InputStream input, byte[] buffer, int offset, int length) throws IOException {
/* 2106 */     if (length < 0) {
/* 2107 */       throw new IllegalArgumentException("Length must not be negative: " + length);
/*      */     }
/* 2109 */     int remaining = length;
/* 2110 */     while (remaining > 0) {
/* 2111 */       int location = length - remaining;
/* 2112 */       int count = input.read(buffer, offset + location, remaining);
/* 2113 */       if (-1 == count) {
/*      */         break;
/*      */       }
/* 2116 */       remaining -= count;
/*      */     } 
/* 2118 */     return length - remaining;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int read(InputStream input, byte[] buffer) throws IOException {
/* 2134 */     return read(input, buffer, 0, buffer.length);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void readFully(Reader input, char[] buffer, int offset, int length) throws IOException {
/* 2154 */     int actual = read(input, buffer, offset, length);
/* 2155 */     if (actual != length) {
/* 2156 */       throw new EOFException("Length to read: " + length + " actual: " + actual);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void readFully(Reader input, char[] buffer) throws IOException {
/* 2175 */     readFully(input, buffer, 0, buffer.length);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void readFully(InputStream input, byte[] buffer, int offset, int length) throws IOException {
/* 2195 */     int actual = read(input, buffer, offset, length);
/* 2196 */     if (actual != length) {
/* 2197 */       throw new EOFException("Length to read: " + length + " actual: " + actual);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void readFully(InputStream input, byte[] buffer) throws IOException {
/* 2216 */     readFully(input, buffer, 0, buffer.length);
/*      */   }
/*      */ }


/* Location:              C:\Users\olatu\OneDrive\Documents\Calypso\syncbase\sync_base.jar!\BOOT-INF\lib\commons-io-2.2.jar!\org\apache\commons\io\IOUtils.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */