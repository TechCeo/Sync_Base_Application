/*     */ package org.apache.commons.io.input;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.util.Arrays;
/*     */ import java.util.List;
/*     */ import org.apache.commons.io.ByteOrderMark;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BOMInputStream
/*     */   extends ProxyInputStream
/*     */ {
/*     */   private final boolean include;
/*     */   private final List<ByteOrderMark> boms;
/*     */   private ByteOrderMark byteOrderMark;
/*     */   private int[] firstBytes;
/*     */   private int fbLength;
/*     */   private int fbIndex;
/*     */   private int markFbIndex;
/*     */   private boolean markedAtStart;
/*     */   
/*     */   public BOMInputStream(InputStream delegate) {
/*  91 */     this(delegate, false, new ByteOrderMark[] { ByteOrderMark.UTF_8 });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BOMInputStream(InputStream delegate, boolean include) {
/* 102 */     this(delegate, include, new ByteOrderMark[] { ByteOrderMark.UTF_8 });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BOMInputStream(InputStream delegate, ByteOrderMark... boms) {
/* 112 */     this(delegate, false, boms);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BOMInputStream(InputStream delegate, boolean include, ByteOrderMark... boms) {
/* 124 */     super(delegate);
/* 125 */     if (boms == null || boms.length == 0) {
/* 126 */       throw new IllegalArgumentException("No BOMs specified");
/*     */     }
/* 128 */     this.include = include;
/* 129 */     this.boms = Arrays.asList(boms);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean hasBOM() throws IOException {
/* 140 */     return (getBOM() != null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean hasBOM(ByteOrderMark bom) throws IOException {
/* 154 */     if (!this.boms.contains(bom)) {
/* 155 */       throw new IllegalArgumentException("Stream not configure to detect " + bom);
/*     */     }
/* 157 */     return (this.byteOrderMark != null && getBOM().equals(bom));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ByteOrderMark getBOM() throws IOException {
/* 167 */     if (this.firstBytes == null) {
/* 168 */       this.fbLength = 0;
/* 169 */       int max = 0;
/* 170 */       for (ByteOrderMark bom : this.boms) {
/* 171 */         max = Math.max(max, bom.length());
/*     */       }
/* 173 */       this.firstBytes = new int[max];
/* 174 */       for (int i = 0; i < this.firstBytes.length; i++) {
/* 175 */         this.firstBytes[i] = this.in.read();
/* 176 */         this.fbLength++;
/* 177 */         if (this.firstBytes[i] < 0) {
/*     */           break;
/*     */         }
/*     */         
/* 181 */         this.byteOrderMark = find();
/* 182 */         if (this.byteOrderMark != null) {
/* 183 */           if (!this.include) {
/* 184 */             this.fbLength = 0;
/*     */           }
/*     */           break;
/*     */         } 
/*     */       } 
/*     */     } 
/* 190 */     return this.byteOrderMark;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getBOMCharsetName() throws IOException {
/* 201 */     getBOM();
/* 202 */     return (this.byteOrderMark == null) ? null : this.byteOrderMark.getCharsetName();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int readFirstBytes() throws IOException {
/* 214 */     getBOM();
/* 215 */     return (this.fbIndex < this.fbLength) ? this.firstBytes[this.fbIndex++] : -1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ByteOrderMark find() {
/* 224 */     for (ByteOrderMark bom : this.boms) {
/* 225 */       if (matches(bom)) {
/* 226 */         return bom;
/*     */       }
/*     */     } 
/* 229 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean matches(ByteOrderMark bom) {
/* 239 */     if (bom.length() != this.fbLength) {
/* 240 */       return false;
/*     */     }
/* 242 */     for (int i = 0; i < bom.length(); i++) {
/* 243 */       if (bom.get(i) != this.firstBytes[i]) {
/* 244 */         return false;
/*     */       }
/*     */     } 
/* 247 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int read() throws IOException {
/* 262 */     int b = readFirstBytes();
/* 263 */     return (b >= 0) ? b : this.in.read();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int read(byte[] buf, int off, int len) throws IOException {
/* 277 */     int firstCount = 0;
/* 278 */     int b = 0;
/* 279 */     while (len > 0 && b >= 0) {
/* 280 */       b = readFirstBytes();
/* 281 */       if (b >= 0) {
/* 282 */         buf[off++] = (byte)(b & 0xFF);
/* 283 */         len--;
/* 284 */         firstCount++;
/*     */       } 
/*     */     } 
/* 287 */     int secondCount = this.in.read(buf, off, len);
/* 288 */     return (secondCount < 0) ? ((firstCount > 0) ? firstCount : -1) : (firstCount + secondCount);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int read(byte[] buf) throws IOException {
/* 301 */     return read(buf, 0, buf.length);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized void mark(int readlimit) {
/* 310 */     this.markFbIndex = this.fbIndex;
/* 311 */     this.markedAtStart = (this.firstBytes == null);
/* 312 */     this.in.mark(readlimit);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized void reset() throws IOException {
/* 321 */     this.fbIndex = this.markFbIndex;
/* 322 */     if (this.markedAtStart) {
/* 323 */       this.firstBytes = null;
/*     */     }
/*     */     
/* 326 */     this.in.reset();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public long skip(long n) throws IOException {
/* 338 */     while (n > 0L && readFirstBytes() >= 0) {
/* 339 */       n--;
/*     */     }
/* 341 */     return this.in.skip(n);
/*     */   }
/*     */ }


/* Location:              C:\Users\olatu\OneDrive\Documents\Calypso\syncbase\sync_base.jar!\BOOT-INF\lib\commons-io-2.2.jar!\org\apache\commons\io\input\BOMInputStream.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */