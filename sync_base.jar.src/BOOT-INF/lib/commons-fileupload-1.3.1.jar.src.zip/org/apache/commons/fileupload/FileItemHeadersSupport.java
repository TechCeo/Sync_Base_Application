package org.apache.commons.fileupload;

public interface FileItemHeadersSupport {
  FileItemHeaders getHeaders();
  
  void setHeaders(FileItemHeaders paramFileItemHeaders);
}


/* Location:              C:\Users\olatu\OneDrive\Documents\Calypso\syncbase\sync_base.jar!\BOOT-INF\lib\commons-fileupload-1.3.1.jar!\org\apache\commons\fileupload\FileItemHeadersSupport.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */