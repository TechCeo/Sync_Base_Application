/*    */ package org.apache.commons.fileupload.servlet;
/*    */ 
/*    */ import javax.servlet.ServletContext;
/*    */ import javax.servlet.ServletContextEvent;
/*    */ import javax.servlet.ServletContextListener;
/*    */ import org.apache.commons.io.FileCleaningTracker;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FileCleanerCleanup
/*    */   implements ServletContextListener
/*    */ {
/* 38 */   public static final String FILE_CLEANING_TRACKER_ATTRIBUTE = FileCleanerCleanup.class.getName() + ".FileCleaningTracker";
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static FileCleaningTracker getFileCleaningTracker(ServletContext pServletContext) {
/* 50 */     return (FileCleaningTracker)pServletContext.getAttribute(FILE_CLEANING_TRACKER_ATTRIBUTE);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static void setFileCleaningTracker(ServletContext pServletContext, FileCleaningTracker pTracker) {
/* 63 */     pServletContext.setAttribute(FILE_CLEANING_TRACKER_ATTRIBUTE, pTracker);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void contextInitialized(ServletContextEvent sce) {
/* 74 */     setFileCleaningTracker(sce.getServletContext(), new FileCleaningTracker());
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void contextDestroyed(ServletContextEvent sce) {
/* 86 */     getFileCleaningTracker(sce.getServletContext()).exitWhenFinished();
/*    */   }
/*    */ }


/* Location:              C:\Users\olatu\OneDrive\Documents\Calypso\syncbase\sync_base.jar!\BOOT-INF\lib\commons-fileupload-1.3.1.jar!\org\apache\commons\fileupload\servlet\FileCleanerCleanup.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */