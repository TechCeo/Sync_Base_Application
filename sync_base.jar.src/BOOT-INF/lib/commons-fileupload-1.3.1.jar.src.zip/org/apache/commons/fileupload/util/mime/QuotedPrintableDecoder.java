/*     */ package org.apache.commons.fileupload.util.mime;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class QuotedPrintableDecoder
/*     */ {
/*     */   private static final int UPPER_NIBBLE_SHIFT = 4;
/*     */   
/*     */   public static int decode(byte[] data, OutputStream out) throws IOException {
/*  50 */     int off = 0;
/*  51 */     int length = data.length;
/*  52 */     int endOffset = off + length;
/*  53 */     int bytesWritten = 0;
/*     */     
/*  55 */     while (off < endOffset) {
/*  56 */       byte ch = data[off++];
/*     */ 
/*     */       
/*  59 */       if (ch == 95) {
/*  60 */         out.write(32); continue;
/*  61 */       }  if (ch == 61) {
/*     */ 
/*     */         
/*  64 */         if (off + 1 >= endOffset) {
/*  65 */           throw new IOException("Invalid quoted printable encoding; truncated escape sequence");
/*     */         }
/*     */         
/*  68 */         byte b1 = data[off++];
/*  69 */         byte b2 = data[off++];
/*     */ 
/*     */         
/*  72 */         if (b1 == 13) {
/*  73 */           if (b2 != 10) {
/*  74 */             throw new IOException("Invalid quoted printable encoding; CR must be followed by LF");
/*     */           }
/*     */           
/*     */           continue;
/*     */         } 
/*     */         
/*  80 */         int c1 = hexToBinary(b1);
/*  81 */         int c2 = hexToBinary(b2);
/*  82 */         out.write(c1 << 4 | c2);
/*     */         
/*  84 */         bytesWritten++;
/*     */         
/*     */         continue;
/*     */       } 
/*  88 */       out.write(ch);
/*  89 */       bytesWritten++;
/*     */     } 
/*     */ 
/*     */     
/*  93 */     return bytesWritten;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static int hexToBinary(byte b) throws IOException {
/* 105 */     int i = Character.digit((char)b, 16);
/* 106 */     if (i == -1) {
/* 107 */       throw new IOException("Invalid quoted printable encoding: not a valid hex digit: " + b);
/*     */     }
/* 109 */     return i;
/*     */   }
/*     */ }


/* Location:              C:\Users\olatu\OneDrive\Documents\Calypso\syncbase\sync_base.jar!\BOOT-INF\lib\commons-fileupload-1.3.1.jar!\org\apache\commons\fileuploa\\util\mime\QuotedPrintableDecoder.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */