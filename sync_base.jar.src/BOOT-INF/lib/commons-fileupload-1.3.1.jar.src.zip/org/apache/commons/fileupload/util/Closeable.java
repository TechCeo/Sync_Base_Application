package org.apache.commons.fileupload.util;

import java.io.IOException;

public interface Closeable {
  void close() throws IOException;
  
  boolean isClosed() throws IOException;
}


/* Location:              C:\Users\olatu\OneDrive\Documents\Calypso\syncbase\sync_base.jar!\BOOT-INF\lib\commons-fileupload-1.3.1.jar!\org\apache\commons\fileuploa\\util\Closeable.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */