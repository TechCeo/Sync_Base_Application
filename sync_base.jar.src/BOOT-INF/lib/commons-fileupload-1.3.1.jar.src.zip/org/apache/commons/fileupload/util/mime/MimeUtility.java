/*     */ package org.apache.commons.fileupload.util.mime;
/*     */ 
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.UnsupportedEncodingException;
/*     */ import java.util.HashMap;
/*     */ import java.util.Locale;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class MimeUtility
/*     */ {
/*     */   private static final String US_ASCII_CHARSET = "US-ASCII";
/*     */   private static final String BASE64_ENCODING_MARKER = "B";
/*     */   private static final String QUOTEDPRINTABLE_ENCODING_MARKER = "Q";
/*     */   private static final String ENCODED_TOKEN_MARKER = "=?";
/*     */   private static final String ENCODED_TOKEN_FINISHER = "?=";
/*     */   private static final String LINEAR_WHITESPACE = " \t\r\n";
/*  66 */   private static final Map<String, String> MIME2JAVA = new HashMap<String, String>();
/*     */   
/*     */   static {
/*  69 */     MIME2JAVA.put("iso-2022-cn", "ISO2022CN");
/*  70 */     MIME2JAVA.put("iso-2022-kr", "ISO2022KR");
/*  71 */     MIME2JAVA.put("utf-8", "UTF8");
/*  72 */     MIME2JAVA.put("utf8", "UTF8");
/*  73 */     MIME2JAVA.put("ja_jp.iso2022-7", "ISO2022JP");
/*  74 */     MIME2JAVA.put("ja_jp.eucjp", "EUCJIS");
/*  75 */     MIME2JAVA.put("euc-kr", "KSC5601");
/*  76 */     MIME2JAVA.put("euckr", "KSC5601");
/*  77 */     MIME2JAVA.put("us-ascii", "ISO-8859-1");
/*  78 */     MIME2JAVA.put("x-us-ascii", "ISO-8859-1");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String decodeText(String text) throws UnsupportedEncodingException {
/* 102 */     if (text.indexOf("=?") < 0) {
/* 103 */       return text;
/*     */     }
/*     */     
/* 106 */     int offset = 0;
/* 107 */     int endOffset = text.length();
/*     */     
/* 109 */     int startWhiteSpace = -1;
/* 110 */     int endWhiteSpace = -1;
/*     */     
/* 112 */     StringBuilder decodedText = new StringBuilder(text.length());
/*     */     
/* 114 */     boolean previousTokenEncoded = false;
/*     */     
/* 116 */     while (offset < endOffset) {
/* 117 */       char ch = text.charAt(offset);
/*     */ 
/*     */       
/* 120 */       if (" \t\r\n".indexOf(ch) != -1) {
/* 121 */         startWhiteSpace = offset;
/* 122 */         while (offset < endOffset) {
/*     */           
/* 124 */           ch = text.charAt(offset);
/* 125 */           if (" \t\r\n".indexOf(ch) != -1) {
/* 126 */             offset++;
/*     */             
/*     */             continue;
/*     */           } 
/* 130 */           endWhiteSpace = offset;
/*     */         } 
/*     */         
/*     */         continue;
/*     */       } 
/*     */       
/* 136 */       int wordStart = offset;
/*     */       
/* 138 */       while (offset < endOffset) {
/*     */         
/* 140 */         ch = text.charAt(offset);
/* 141 */         if (" \t\r\n".indexOf(ch) == -1) {
/* 142 */           offset++;
/*     */         }
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 150 */       String word = text.substring(wordStart, offset);
/*     */       
/* 152 */       if (word.startsWith("=?")) {
/*     */         
/*     */         try {
/* 155 */           String decodedWord = decodeWord(word);
/*     */ 
/*     */           
/* 158 */           if (!previousTokenEncoded && startWhiteSpace != -1) {
/* 159 */             decodedText.append(text.substring(startWhiteSpace, endWhiteSpace));
/* 160 */             startWhiteSpace = -1;
/*     */           } 
/*     */           
/* 163 */           previousTokenEncoded = true;
/*     */           
/* 165 */           decodedText.append(decodedWord);
/*     */ 
/*     */ 
/*     */           
/*     */           continue;
/* 170 */         } catch (ParseException e) {}
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 176 */       if (startWhiteSpace != -1) {
/* 177 */         decodedText.append(text.substring(startWhiteSpace, endWhiteSpace));
/* 178 */         startWhiteSpace = -1;
/*     */       } 
/*     */       
/* 181 */       previousTokenEncoded = false;
/* 182 */       decodedText.append(word);
/*     */     } 
/*     */ 
/*     */     
/* 186 */     return decodedText.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static String decodeWord(String word) throws ParseException, UnsupportedEncodingException {
/* 205 */     if (!word.startsWith("=?")) {
/* 206 */       throw new ParseException("Invalid RFC 2047 encoded-word: " + word);
/*     */     }
/*     */     
/* 209 */     int charsetPos = word.indexOf('?', 2);
/* 210 */     if (charsetPos == -1) {
/* 211 */       throw new ParseException("Missing charset in RFC 2047 encoded-word: " + word);
/*     */     }
/*     */ 
/*     */     
/* 215 */     String charset = word.substring(2, charsetPos).toLowerCase();
/*     */ 
/*     */     
/* 218 */     int encodingPos = word.indexOf('?', charsetPos + 1);
/* 219 */     if (encodingPos == -1) {
/* 220 */       throw new ParseException("Missing encoding in RFC 2047 encoded-word: " + word);
/*     */     }
/*     */     
/* 223 */     String encoding = word.substring(charsetPos + 1, encodingPos);
/*     */ 
/*     */     
/* 226 */     int encodedTextPos = word.indexOf("?=", encodingPos + 1);
/* 227 */     if (encodedTextPos == -1) {
/* 228 */       throw new ParseException("Missing encoded text in RFC 2047 encoded-word: " + word);
/*     */     }
/*     */     
/* 231 */     String encodedText = word.substring(encodingPos + 1, encodedTextPos);
/*     */ 
/*     */     
/* 234 */     if (encodedText.length() == 0) {
/* 235 */       return "";
/*     */     }
/*     */ 
/*     */     
/*     */     try {
/* 240 */       ByteArrayOutputStream out = new ByteArrayOutputStream(encodedText.length());
/*     */       
/* 242 */       byte[] encodedData = encodedText.getBytes("US-ASCII");
/*     */ 
/*     */       
/* 245 */       if (encoding.equals("B")) {
/* 246 */         Base64Decoder.decode(encodedData, out);
/* 247 */       } else if (encoding.equals("Q")) {
/* 248 */         QuotedPrintableDecoder.decode(encodedData, out);
/*     */       } else {
/* 250 */         throw new UnsupportedEncodingException("Unknown RFC 2047 encoding: " + encoding);
/*     */       } 
/*     */       
/* 253 */       byte[] decodedData = out.toByteArray();
/* 254 */       return new String(decodedData, javaCharset(charset));
/* 255 */     } catch (IOException e) {
/* 256 */       throw new UnsupportedEncodingException("Invalid RFC 2047 encoding");
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static String javaCharset(String charset) {
/* 270 */     if (charset == null) {
/* 271 */       return null;
/*     */     }
/*     */     
/* 274 */     String mappedCharset = MIME2JAVA.get(charset.toLowerCase(Locale.ENGLISH));
/*     */ 
/*     */     
/* 277 */     if (mappedCharset == null) {
/* 278 */       return charset;
/*     */     }
/* 280 */     return mappedCharset;
/*     */   }
/*     */ }


/* Location:              C:\Users\olatu\OneDrive\Documents\Calypso\syncbase\sync_base.jar!\BOOT-INF\lib\commons-fileupload-1.3.1.jar!\org\apache\commons\fileuploa\\util\mime\MimeUtility.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */