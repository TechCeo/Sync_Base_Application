/*    */ package org.apache.commons.fileupload.util;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import java.util.ArrayList;
/*    */ import java.util.Collections;
/*    */ import java.util.Iterator;
/*    */ import java.util.LinkedHashMap;
/*    */ import java.util.List;
/*    */ import java.util.Locale;
/*    */ import java.util.Map;
/*    */ import org.apache.commons.fileupload.FileItemHeaders;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FileItemHeadersImpl
/*    */   implements FileItemHeaders, Serializable
/*    */ {
/*    */   private static final long serialVersionUID = -4455695752627032559L;
/* 48 */   private final Map<String, List<String>> headerNameToValueListMap = new LinkedHashMap<String, List<String>>();
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String getHeader(String name) {
/* 54 */     String nameLower = name.toLowerCase(Locale.ENGLISH);
/* 55 */     List<String> headerValueList = this.headerNameToValueListMap.get(nameLower);
/* 56 */     if (null == headerValueList) {
/* 57 */       return null;
/*    */     }
/* 59 */     return headerValueList.get(0);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Iterator<String> getHeaderNames() {
/* 66 */     return this.headerNameToValueListMap.keySet().iterator();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Iterator<String> getHeaders(String name) {
/* 73 */     String nameLower = name.toLowerCase(Locale.ENGLISH);
/* 74 */     List<String> headerValueList = this.headerNameToValueListMap.get(nameLower);
/* 75 */     if (null == headerValueList) {
/* 76 */       headerValueList = Collections.emptyList();
/*    */     }
/* 78 */     return headerValueList.iterator();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public synchronized void addHeader(String name, String value) {
/* 88 */     String nameLower = name.toLowerCase(Locale.ENGLISH);
/* 89 */     List<String> headerValueList = this.headerNameToValueListMap.get(nameLower);
/* 90 */     if (null == headerValueList) {
/* 91 */       headerValueList = new ArrayList<String>();
/* 92 */       this.headerNameToValueListMap.put(nameLower, headerValueList);
/*    */     } 
/* 94 */     headerValueList.add(value);
/*    */   }
/*    */ }


/* Location:              C:\Users\olatu\OneDrive\Documents\Calypso\syncbase\sync_base.jar!\BOOT-INF\lib\commons-fileupload-1.3.1.jar!\org\apache\commons\fileuploa\\util\FileItemHeadersImpl.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */