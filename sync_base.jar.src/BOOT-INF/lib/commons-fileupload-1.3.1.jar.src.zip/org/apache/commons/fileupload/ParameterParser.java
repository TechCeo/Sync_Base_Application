/*     */ package org.apache.commons.fileupload;
/*     */ 
/*     */ import java.io.UnsupportedEncodingException;
/*     */ import java.util.HashMap;
/*     */ import java.util.Locale;
/*     */ import java.util.Map;
/*     */ import org.apache.commons.fileupload.util.mime.MimeUtility;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ParameterParser
/*     */ {
/*  44 */   private char[] chars = null;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  49 */   private int pos = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  54 */   private int len = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  59 */   private int i1 = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  64 */   private int i2 = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean lowerCaseNames = false;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean hasChar() {
/*  85 */     return (this.pos < this.len);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String getToken(boolean quoted) {
/*  99 */     while (this.i1 < this.i2 && Character.isWhitespace(this.chars[this.i1])) {
/* 100 */       this.i1++;
/*     */     }
/*     */     
/* 103 */     while (this.i2 > this.i1 && Character.isWhitespace(this.chars[this.i2 - 1])) {
/* 104 */       this.i2--;
/*     */     }
/*     */     
/* 107 */     if (quoted && this.i2 - this.i1 >= 2 && this.chars[this.i1] == '"' && this.chars[this.i2 - 1] == '"') {
/*     */ 
/*     */ 
/*     */       
/* 111 */       this.i1++;
/* 112 */       this.i2--;
/*     */     } 
/* 114 */     String result = null;
/* 115 */     if (this.i2 > this.i1) {
/* 116 */       result = new String(this.chars, this.i1, this.i2 - this.i1);
/*     */     }
/* 118 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean isOneOf(char ch, char[] charray) {
/* 131 */     boolean result = false;
/* 132 */     for (char element : charray) {
/* 133 */       if (ch == element) {
/* 134 */         result = true;
/*     */         break;
/*     */       } 
/*     */     } 
/* 138 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String parseToken(char[] terminators) {
/* 152 */     this.i1 = this.pos;
/* 153 */     this.i2 = this.pos;
/* 154 */     while (hasChar()) {
/* 155 */       char ch = this.chars[this.pos];
/* 156 */       if (isOneOf(ch, terminators)) {
/*     */         break;
/*     */       }
/* 159 */       this.i2++;
/* 160 */       this.pos++;
/*     */     } 
/* 162 */     return getToken(false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String parseQuotedToken(char[] terminators) {
/* 177 */     this.i1 = this.pos;
/* 178 */     this.i2 = this.pos;
/* 179 */     boolean quoted = false;
/* 180 */     boolean charEscaped = false;
/* 181 */     while (hasChar()) {
/* 182 */       char ch = this.chars[this.pos];
/* 183 */       if (!quoted && isOneOf(ch, terminators)) {
/*     */         break;
/*     */       }
/* 186 */       if (!charEscaped && ch == '"') {
/* 187 */         quoted = !quoted;
/*     */       }
/* 189 */       charEscaped = (!charEscaped && ch == '\\');
/* 190 */       this.i2++;
/* 191 */       this.pos++;
/*     */     } 
/*     */     
/* 194 */     return getToken(true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isLowerCaseNames() {
/* 206 */     return this.lowerCaseNames;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setLowerCaseNames(boolean b) {
/* 218 */     this.lowerCaseNames = b;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<String, String> parse(String str, char[] separators) {
/* 232 */     if (separators == null || separators.length == 0) {
/* 233 */       return new HashMap<String, String>();
/*     */     }
/* 235 */     char separator = separators[0];
/* 236 */     if (str != null) {
/* 237 */       int idx = str.length();
/* 238 */       for (char separator2 : separators) {
/* 239 */         int tmp = str.indexOf(separator2);
/* 240 */         if (tmp != -1 && tmp < idx) {
/* 241 */           idx = tmp;
/* 242 */           separator = separator2;
/*     */         } 
/*     */       } 
/*     */     } 
/* 246 */     return parse(str, separator);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<String, String> parse(String str, char separator) {
/* 259 */     if (str == null) {
/* 260 */       return new HashMap<String, String>();
/*     */     }
/* 262 */     return parse(str.toCharArray(), separator);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<String, String> parse(char[] charArray, char separator) {
/* 276 */     if (charArray == null) {
/* 277 */       return new HashMap<String, String>();
/*     */     }
/* 279 */     return parse(charArray, 0, charArray.length, separator);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<String, String> parse(char[] charArray, int offset, int length, char separator) {
/* 300 */     if (charArray == null) {
/* 301 */       return new HashMap<String, String>();
/*     */     }
/* 303 */     HashMap<String, String> params = new HashMap<String, String>();
/* 304 */     this.chars = charArray;
/* 305 */     this.pos = offset;
/* 306 */     this.len = length;
/*     */     
/* 308 */     String paramName = null;
/* 309 */     String paramValue = null;
/* 310 */     while (hasChar()) {
/* 311 */       paramName = parseToken(new char[] { '=', separator });
/*     */       
/* 313 */       paramValue = null;
/* 314 */       if (hasChar() && charArray[this.pos] == '=') {
/* 315 */         this.pos++;
/* 316 */         paramValue = parseQuotedToken(new char[] { separator });
/*     */ 
/*     */         
/* 319 */         if (paramValue != null) {
/*     */           try {
/* 321 */             paramValue = MimeUtility.decodeText(paramValue);
/* 322 */           } catch (UnsupportedEncodingException e) {}
/*     */         }
/*     */       } 
/*     */ 
/*     */       
/* 327 */       if (hasChar() && charArray[this.pos] == separator) {
/* 328 */         this.pos++;
/*     */       }
/* 330 */       if (paramName != null && paramName.length() > 0) {
/* 331 */         if (this.lowerCaseNames) {
/* 332 */           paramName = paramName.toLowerCase(Locale.ENGLISH);
/*     */         }
/*     */         
/* 335 */         params.put(paramName, paramValue);
/*     */       } 
/*     */     } 
/* 338 */     return params;
/*     */   }
/*     */ }


/* Location:              C:\Users\olatu\OneDrive\Documents\Calypso\syncbase\sync_base.jar!\BOOT-INF\lib\commons-fileupload-1.3.1.jar!\org\apache\commons\fileupload\ParameterParser.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */