package org.apache.commons.fileupload;

public interface ProgressListener {
  void update(long paramLong1, long paramLong2, int paramInt);
}


/* Location:              C:\Users\olatu\OneDrive\Documents\Calypso\syncbase\sync_base.jar!\BOOT-INF\lib\commons-fileupload-1.3.1.jar!\org\apache\commons\fileupload\ProgressListener.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */