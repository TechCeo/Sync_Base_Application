/*      */ package org.apache.commons.fileupload;
/*      */ 
/*      */ import java.io.IOException;
/*      */ import java.io.InputStream;
/*      */ import java.io.UnsupportedEncodingException;
/*      */ import java.util.ArrayList;
/*      */ import java.util.HashMap;
/*      */ import java.util.Iterator;
/*      */ import java.util.List;
/*      */ import java.util.Locale;
/*      */ import java.util.Map;
/*      */ import java.util.NoSuchElementException;
/*      */ import javax.servlet.http.HttpServletRequest;
/*      */ import org.apache.commons.fileupload.servlet.ServletFileUpload;
/*      */ import org.apache.commons.fileupload.servlet.ServletRequestContext;
/*      */ import org.apache.commons.fileupload.util.Closeable;
/*      */ import org.apache.commons.fileupload.util.FileItemHeadersImpl;
/*      */ import org.apache.commons.fileupload.util.LimitedInputStream;
/*      */ import org.apache.commons.fileupload.util.Streams;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public abstract class FileUploadBase
/*      */ {
/*      */   public static final String CONTENT_TYPE = "Content-type";
/*      */   public static final String CONTENT_DISPOSITION = "Content-disposition";
/*      */   public static final String CONTENT_LENGTH = "Content-length";
/*      */   public static final String FORM_DATA = "form-data";
/*      */   public static final String ATTACHMENT = "attachment";
/*      */   public static final String MULTIPART = "multipart/";
/*      */   public static final String MULTIPART_FORM_DATA = "multipart/form-data";
/*      */   public static final String MULTIPART_MIXED = "multipart/mixed";
/*      */   @Deprecated
/*      */   public static final int MAX_HEADER_SIZE = 1024;
/*      */   
/*      */   public static final boolean isMultipartContent(RequestContext ctx) {
/*   77 */     String contentType = ctx.getContentType();
/*   78 */     if (contentType == null) {
/*   79 */       return false;
/*      */     }
/*   81 */     if (contentType.toLowerCase(Locale.ENGLISH).startsWith("multipart/")) {
/*   82 */       return true;
/*      */     }
/*   84 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public static boolean isMultipartContent(HttpServletRequest req) {
/*  100 */     return ServletFileUpload.isMultipartContent(req);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  161 */   private long sizeMax = -1L;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  167 */   private long fileSizeMax = -1L;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private String headerEncoding;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private ProgressListener listener;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public long getSizeMax() {
/*  206 */     return this.sizeMax;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setSizeMax(long sizeMax) {
/*  220 */     this.sizeMax = sizeMax;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public long getFileSizeMax() {
/*  231 */     return this.fileSizeMax;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setFileSizeMax(long fileSizeMax) {
/*  242 */     this.fileSizeMax = fileSizeMax;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getHeaderEncoding() {
/*  254 */     return this.headerEncoding;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setHeaderEncoding(String encoding) {
/*  266 */     this.headerEncoding = encoding;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public List<FileItem> parseRequest(HttpServletRequest req) throws FileUploadException {
/*  288 */     return parseRequest((RequestContext)new ServletRequestContext(req));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public FileItemIterator getItemIterator(RequestContext ctx) throws FileUploadException, IOException {
/*      */     try {
/*  310 */       return new FileItemIteratorImpl(ctx);
/*  311 */     } catch (FileUploadIOException e) {
/*      */       
/*  313 */       throw (FileUploadException)e.getCause();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public List<FileItem> parseRequest(RequestContext ctx) throws FileUploadException {
/*  331 */     List<FileItem> items = new ArrayList<FileItem>();
/*  332 */     boolean successful = false;
/*      */     try {
/*  334 */       FileItemIterator iter = getItemIterator(ctx);
/*  335 */       FileItemFactory fac = getFileItemFactory();
/*  336 */       if (fac == null) {
/*  337 */         throw new NullPointerException("No FileItemFactory has been set.");
/*      */       }
/*  339 */       while (iter.hasNext()) {
/*  340 */         FileItemStream item = iter.next();
/*      */         
/*  342 */         String fileName = ((FileItemIteratorImpl.FileItemStreamImpl)item).name;
/*  343 */         FileItem fileItem = fac.createItem(item.getFieldName(), item.getContentType(), item.isFormField(), fileName);
/*      */         
/*  345 */         items.add(fileItem);
/*      */         try {
/*  347 */           Streams.copy(item.openStream(), fileItem.getOutputStream(), true);
/*  348 */         } catch (FileUploadIOException e) {
/*  349 */           throw (FileUploadException)e.getCause();
/*  350 */         } catch (IOException e) {
/*  351 */           throw new IOFileUploadException(String.format("Processing of %s request failed. %s", new Object[] { "multipart/form-data", e.getMessage() }), e);
/*      */         } 
/*      */         
/*  354 */         FileItemHeaders fih = item.getHeaders();
/*  355 */         fileItem.setHeaders(fih);
/*      */       } 
/*  357 */       successful = true;
/*  358 */       return items;
/*  359 */     } catch (FileUploadIOException e) {
/*  360 */       throw (FileUploadException)e.getCause();
/*  361 */     } catch (IOException e) {
/*  362 */       throw new FileUploadException(e.getMessage(), e);
/*      */     } finally {
/*  364 */       if (!successful) {
/*  365 */         for (FileItem fileItem : items) {
/*      */           try {
/*  367 */             fileItem.delete();
/*  368 */           } catch (Throwable e) {}
/*      */         } 
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Map<String, List<FileItem>> parseParameterMap(RequestContext ctx) throws FileUploadException {
/*  391 */     List<FileItem> items = parseRequest(ctx);
/*  392 */     Map<String, List<FileItem>> itemsMap = new HashMap<String, List<FileItem>>(items.size());
/*      */     
/*  394 */     for (FileItem fileItem : items) {
/*  395 */       String fieldName = fileItem.getFieldName();
/*  396 */       List<FileItem> mappedItems = itemsMap.get(fieldName);
/*      */       
/*  398 */       if (mappedItems == null) {
/*  399 */         mappedItems = new ArrayList<FileItem>();
/*  400 */         itemsMap.put(fieldName, mappedItems);
/*      */       } 
/*      */       
/*  403 */       mappedItems.add(fileItem);
/*      */     } 
/*      */     
/*  406 */     return itemsMap;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected byte[] getBoundary(String contentType) {
/*      */     byte[] arrayOfByte;
/*  420 */     ParameterParser parser = new ParameterParser();
/*  421 */     parser.setLowerCaseNames(true);
/*      */     
/*  423 */     Map<String, String> params = parser.parse(contentType, new char[] { ';', ',' });
/*  424 */     String boundaryStr = params.get("boundary");
/*      */     
/*  426 */     if (boundaryStr == null) {
/*  427 */       return null;
/*      */     }
/*      */     
/*      */     try {
/*  431 */       arrayOfByte = boundaryStr.getBytes("ISO-8859-1");
/*  432 */     } catch (UnsupportedEncodingException e) {
/*  433 */       arrayOfByte = boundaryStr.getBytes();
/*      */     } 
/*  435 */     return arrayOfByte;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   protected String getFileName(Map<String, String> headers) {
/*  449 */     return getFileName(getHeader(headers, "Content-disposition"));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected String getFileName(FileItemHeaders headers) {
/*  461 */     return getFileName(headers.getHeader("Content-disposition"));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private String getFileName(String pContentDisposition) {
/*  470 */     String fileName = null;
/*  471 */     if (pContentDisposition != null) {
/*  472 */       String cdl = pContentDisposition.toLowerCase(Locale.ENGLISH);
/*  473 */       if (cdl.startsWith("form-data") || cdl.startsWith("attachment")) {
/*  474 */         ParameterParser parser = new ParameterParser();
/*  475 */         parser.setLowerCaseNames(true);
/*      */         
/*  477 */         Map<String, String> params = parser.parse(pContentDisposition, ';');
/*  478 */         if (params.containsKey("filename")) {
/*  479 */           fileName = params.get("filename");
/*  480 */           if (fileName != null) {
/*  481 */             fileName = fileName.trim();
/*      */           
/*      */           }
/*      */           else {
/*      */             
/*  486 */             fileName = "";
/*      */           } 
/*      */         } 
/*      */       } 
/*      */     } 
/*  491 */     return fileName;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected String getFieldName(FileItemHeaders headers) {
/*  503 */     return getFieldName(headers.getHeader("Content-disposition"));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private String getFieldName(String pContentDisposition) {
/*  513 */     String fieldName = null;
/*  514 */     if (pContentDisposition != null && pContentDisposition.toLowerCase(Locale.ENGLISH).startsWith("form-data")) {
/*      */       
/*  516 */       ParameterParser parser = new ParameterParser();
/*  517 */       parser.setLowerCaseNames(true);
/*      */       
/*  519 */       Map<String, String> params = parser.parse(pContentDisposition, ';');
/*  520 */       fieldName = params.get("name");
/*  521 */       if (fieldName != null) {
/*  522 */         fieldName = fieldName.trim();
/*      */       }
/*      */     } 
/*  525 */     return fieldName;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   protected String getFieldName(Map<String, String> headers) {
/*  539 */     return getFieldName(getHeader(headers, "Content-disposition"));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   protected FileItem createItem(Map<String, String> headers, boolean isFormField) throws FileUploadException {
/*  560 */     return getFileItemFactory().createItem(getFieldName(headers), getHeader(headers, "Content-type"), isFormField, getFileName(headers));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected FileItemHeaders getParsedHeaders(String headerPart) {
/*  579 */     int len = headerPart.length();
/*  580 */     FileItemHeadersImpl headers = newFileItemHeaders();
/*  581 */     int start = 0;
/*      */     while (true) {
/*  583 */       int end = parseEndOfLine(headerPart, start);
/*  584 */       if (start == end) {
/*      */         break;
/*      */       }
/*  587 */       StringBuilder header = new StringBuilder(headerPart.substring(start, end));
/*  588 */       start = end + 2;
/*  589 */       while (start < len) {
/*  590 */         int nonWs = start;
/*  591 */         while (nonWs < len) {
/*  592 */           char c = headerPart.charAt(nonWs);
/*  593 */           if (c != ' ' && c != '\t') {
/*      */             break;
/*      */           }
/*  596 */           nonWs++;
/*      */         } 
/*  598 */         if (nonWs == start) {
/*      */           break;
/*      */         }
/*      */         
/*  602 */         end = parseEndOfLine(headerPart, nonWs);
/*  603 */         header.append(" ").append(headerPart.substring(nonWs, end));
/*  604 */         start = end + 2;
/*      */       } 
/*  606 */       parseHeaderLine(headers, header.toString());
/*      */     } 
/*  608 */     return (FileItemHeaders)headers;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected FileItemHeadersImpl newFileItemHeaders() {
/*  616 */     return new FileItemHeadersImpl();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   protected Map<String, String> parseHeaders(String headerPart) {
/*  634 */     FileItemHeaders headers = getParsedHeaders(headerPart);
/*  635 */     Map<String, String> result = new HashMap<String, String>();
/*  636 */     for (Iterator<String> iter = headers.getHeaderNames(); iter.hasNext(); ) {
/*  637 */       String headerName = iter.next();
/*  638 */       Iterator<String> iter2 = headers.getHeaders(headerName);
/*  639 */       StringBuilder headerValue = new StringBuilder(iter2.next());
/*  640 */       while (iter2.hasNext()) {
/*  641 */         headerValue.append(",").append(iter2.next());
/*      */       }
/*  643 */       result.put(headerName, headerValue.toString());
/*      */     } 
/*  645 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private int parseEndOfLine(String headerPart, int end) {
/*  657 */     int index = end;
/*      */     while (true) {
/*  659 */       int offset = headerPart.indexOf('\r', index);
/*  660 */       if (offset == -1 || offset + 1 >= headerPart.length()) {
/*  661 */         throw new IllegalStateException("Expected headers to be terminated by an empty line.");
/*      */       }
/*      */       
/*  664 */       if (headerPart.charAt(offset + 1) == '\n') {
/*  665 */         return offset;
/*      */       }
/*  667 */       index = offset + 1;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void parseHeaderLine(FileItemHeadersImpl headers, String header) {
/*  677 */     int colonOffset = header.indexOf(':');
/*  678 */     if (colonOffset == -1) {
/*      */       return;
/*      */     }
/*      */     
/*  682 */     String headerName = header.substring(0, colonOffset).trim();
/*  683 */     String headerValue = header.substring(header.indexOf(':') + 1).trim();
/*      */     
/*  685 */     headers.addHeader(headerName, headerValue);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   protected final String getHeader(Map<String, String> headers, String name) {
/*  702 */     return headers.get(name.toLowerCase(Locale.ENGLISH));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   class FileItemStreamImpl
/*      */     implements FileItemStream
/*      */   {
/*      */     private final String contentType;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private final String fieldName;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private final String name;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private final boolean formField;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private final InputStream stream;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private boolean opened;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private FileItemHeaders headers;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     FileItemStreamImpl(String pName, String pFieldName, String pContentType, boolean pFormField, long pContentLength) throws IOException {
/*      */       LimitedInputStream limitedInputStream;
/*  764 */       this.name = pName;
/*  765 */       this.fieldName = pFieldName;
/*  766 */       this.contentType = pContentType;
/*  767 */       this.formField = pFormField;
/*  768 */       final MultipartStream.ItemInputStream itemStream = ((FileUploadBase.FileItemIteratorImpl)FileUploadBase.this).multi.newInputStream();
/*  769 */       InputStream istream = itemStream;
/*  770 */       if (FileUploadBase.this.fileSizeMax != -1L) {
/*  771 */         if (pContentLength != -1L && pContentLength > FileUploadBase.this.fileSizeMax) {
/*      */           
/*  773 */           FileUploadBase.FileSizeLimitExceededException e = new FileUploadBase.FileSizeLimitExceededException(String.format("The field %s exceeds its maximum permitted size of %s bytes.", new Object[] { this.fieldName, Long.valueOf(FileUploadBase.access$200(((FileUploadBase.FileItemIteratorImpl)this$0).this$0)) }), pContentLength, FileUploadBase.this.fileSizeMax);
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  778 */           e.setFileName(pName);
/*  779 */           e.setFieldName(pFieldName);
/*  780 */           throw new FileUploadBase.FileUploadIOException(e);
/*      */         } 
/*  782 */         limitedInputStream = new LimitedInputStream(istream, FileUploadBase.this.fileSizeMax)
/*      */           {
/*      */             protected void raiseError(long pSizeMax, long pCount) throws IOException
/*      */             {
/*  786 */               itemStream.close(true);
/*  787 */               FileUploadBase.FileSizeLimitExceededException e = new FileUploadBase.FileSizeLimitExceededException(String.format("The field %s exceeds its maximum permitted size of %s bytes.", new Object[] { FileUploadBase.FileItemIteratorImpl.FileItemStreamImpl.access$300(this.this$2), Long.valueOf(pSizeMax) }), pCount, pSizeMax);
/*      */ 
/*      */ 
/*      */ 
/*      */               
/*  792 */               e.setFieldName(FileUploadBase.FileItemIteratorImpl.FileItemStreamImpl.this.fieldName);
/*  793 */               e.setFileName(FileUploadBase.FileItemIteratorImpl.FileItemStreamImpl.this.name);
/*  794 */               throw new FileUploadBase.FileUploadIOException(e);
/*      */             }
/*      */           };
/*      */       } 
/*  798 */       this.stream = (InputStream)limitedInputStream;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public String getContentType() {
/*  807 */       return this.contentType;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public String getFieldName() {
/*  816 */       return this.fieldName;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public String getName() {
/*  829 */       return Streams.checkFileName(this.name);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public boolean isFormField() {
/*  839 */       return this.formField;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public InputStream openStream() throws IOException {
/*  850 */       if (this.opened) {
/*  851 */         throw new IllegalStateException("The stream was already opened.");
/*      */       }
/*      */       
/*  854 */       if (((Closeable)this.stream).isClosed()) {
/*  855 */         throw new FileItemStream.ItemSkippedException();
/*      */       }
/*  857 */       return this.stream;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     void close() throws IOException {
/*  866 */       this.stream.close();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public FileItemHeaders getHeaders() {
/*  875 */       return this.headers;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void setHeaders(FileItemHeaders pHeaders)
/*      */     {
/*  884 */       this.headers = pHeaders; } } private class FileItemIteratorImpl implements FileItemIterator { private final MultipartStream multi; private final MultipartStream.ProgressNotifier notifier; private final byte[] boundary; private FileItemStreamImpl currentItem; private String currentFieldName; private boolean skipPreamble; private boolean itemValid; private boolean eof; class FileItemStreamImpl implements FileItemStream { private final String contentType; private final String fieldName; private final String name; public void setHeaders(FileItemHeaders pHeaders) { this.headers = pHeaders; }
/*      */       
/*      */       private final boolean formField; private final InputStream stream; private boolean opened; private FileItemHeaders headers;
/*      */       FileItemStreamImpl(String pName, String pFieldName, String pContentType, boolean pFormField, long pContentLength) throws IOException {
/*      */         LimitedInputStream limitedInputStream;
/*      */         this.name = pName;
/*      */         this.fieldName = pFieldName;
/*      */         this.contentType = pContentType;
/*      */         this.formField = pFormField;
/*      */         final MultipartStream.ItemInputStream itemStream = FileUploadBase.FileItemIteratorImpl.this.multi.newInputStream();
/*      */         InputStream istream = itemStream;
/*      */         if (FileUploadBase.this.fileSizeMax != -1L) {
/*      */           if (pContentLength != -1L && pContentLength > FileUploadBase.this.fileSizeMax) {
/*      */             FileUploadBase.FileSizeLimitExceededException e = new FileUploadBase.FileSizeLimitExceededException(String.format("The field %s exceeds its maximum permitted size of %s bytes.", new Object[] { this.fieldName, Long.valueOf(FileUploadBase.access$200(this$0.this$0)) }), pContentLength, FileUploadBase.this.fileSizeMax);
/*      */             e.setFileName(pName);
/*      */             e.setFieldName(pFieldName);
/*      */             throw new FileUploadBase.FileUploadIOException(e);
/*      */           } 
/*      */           limitedInputStream = new LimitedInputStream(istream, FileUploadBase.this.fileSizeMax) { protected void raiseError(long pSizeMax, long pCount) throws IOException {
/*      */                 itemStream.close(true);
/*      */                 FileUploadBase.FileSizeLimitExceededException e = new FileUploadBase.FileSizeLimitExceededException(String.format("The field %s exceeds its maximum permitted size of %s bytes.", new Object[] { FileUploadBase.FileItemIteratorImpl.FileItemStreamImpl.access$300(this.this$2), Long.valueOf(pSizeMax) }), pCount, pSizeMax);
/*      */                 e.setFieldName(FileUploadBase.FileItemIteratorImpl.FileItemStreamImpl.this.fieldName);
/*      */                 e.setFileName(FileUploadBase.FileItemIteratorImpl.FileItemStreamImpl.this.name);
/*      */                 throw new FileUploadBase.FileUploadIOException(e);
/*      */               } }
/*      */             ;
/*      */         } 
/*      */         this.stream = (InputStream)limitedInputStream;
/*      */       }
/*      */       public String getContentType() {
/*      */         return this.contentType;
/*      */       }
/*      */       public String getFieldName() {
/*      */         return this.fieldName;
/*      */       }
/*      */       public String getName() {
/*      */         return Streams.checkFileName(this.name);
/*      */       }
/*      */       public boolean isFormField() {
/*      */         return this.formField;
/*      */       }
/*      */       public InputStream openStream() throws IOException {
/*      */         if (this.opened)
/*      */           throw new IllegalStateException("The stream was already opened."); 
/*      */         if (((Closeable)this.stream).isClosed())
/*      */           throw new FileItemStream.ItemSkippedException(); 
/*      */         return this.stream;
/*      */       }
/*      */       void close() throws IOException {
/*      */         this.stream.close();
/*      */       }
/*      */       public FileItemHeaders getHeaders() {
/*      */         return this.headers;
/*      */       } }
/*      */     FileItemIteratorImpl(RequestContext ctx) throws FileUploadException, IOException {
/*      */       LimitedInputStream limitedInputStream;
/*  940 */       if (ctx == null) {
/*  941 */         throw new NullPointerException("ctx parameter");
/*      */       }
/*      */       
/*  944 */       String contentType = ctx.getContentType();
/*  945 */       if (null == contentType || !contentType.toLowerCase(Locale.ENGLISH).startsWith("multipart/"))
/*      */       {
/*  947 */         throw new FileUploadBase.InvalidContentTypeException(String.format("the request doesn't contain a %s or %s stream, content type header is %s", new Object[] { "multipart/form-data", "multipart/mixed", contentType }));
/*      */       }
/*      */ 
/*      */ 
/*      */       
/*  952 */       InputStream input = ctx.getInputStream();
/*      */ 
/*      */       
/*  955 */       int contentLengthInt = ctx.getContentLength();
/*      */       
/*  957 */       long requestSize = UploadContext.class.isAssignableFrom(ctx.getClass()) ? ((UploadContext)ctx).contentLength() : contentLengthInt;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  963 */       if (FileUploadBase.this.sizeMax >= 0L) {
/*  964 */         if (requestSize != -1L && requestSize > FileUploadBase.this.sizeMax) {
/*  965 */           throw new FileUploadBase.SizeLimitExceededException(String.format("the request was rejected because its size (%s) exceeds the configured maximum (%s)", new Object[] { Long.valueOf(requestSize), Long.valueOf(FileUploadBase.access$400(this$0)) }), requestSize, FileUploadBase.this.sizeMax);
/*      */         }
/*      */ 
/*      */ 
/*      */         
/*  970 */         limitedInputStream = new LimitedInputStream(input, FileUploadBase.this.sizeMax)
/*      */           {
/*      */             protected void raiseError(long pSizeMax, long pCount) throws IOException
/*      */             {
/*  974 */               FileUploadException ex = new FileUploadBase.SizeLimitExceededException(String.format("the request was rejected because its size (%s) exceeds the configured maximum (%s)", new Object[] { Long.valueOf(pCount), Long.valueOf(pSizeMax) }), pCount, pSizeMax);
/*      */ 
/*      */ 
/*      */               
/*  978 */               throw new FileUploadBase.FileUploadIOException(ex);
/*      */             }
/*      */           };
/*      */       } 
/*      */       
/*  983 */       String charEncoding = FileUploadBase.this.headerEncoding;
/*  984 */       if (charEncoding == null) {
/*  985 */         charEncoding = ctx.getCharacterEncoding();
/*      */       }
/*      */       
/*  988 */       this.boundary = FileUploadBase.this.getBoundary(contentType);
/*  989 */       if (this.boundary == null) {
/*  990 */         throw new FileUploadException("the request was rejected because no multipart boundary was found");
/*      */       }
/*      */       
/*  993 */       this.notifier = new MultipartStream.ProgressNotifier(FileUploadBase.this.listener, requestSize);
/*      */       try {
/*  995 */         this.multi = new MultipartStream((InputStream)limitedInputStream, this.boundary, this.notifier);
/*  996 */       } catch (IllegalArgumentException iae) {
/*  997 */         throw new FileUploadBase.InvalidContentTypeException(String.format("The boundary specified in the %s header is too long", new Object[] { "Content-type" }), iae);
/*      */       } 
/*      */       
/* 1000 */       this.multi.setHeaderEncoding(charEncoding);
/*      */       
/* 1002 */       this.skipPreamble = true;
/* 1003 */       findNextItem();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private boolean findNextItem() throws IOException {
/* 1013 */       if (this.eof) {
/* 1014 */         return false;
/*      */       }
/* 1016 */       if (this.currentItem != null) {
/* 1017 */         this.currentItem.close();
/* 1018 */         this.currentItem = null;
/*      */       } 
/*      */       while (true) {
/*      */         boolean nextPart;
/* 1022 */         if (this.skipPreamble) {
/* 1023 */           nextPart = this.multi.skipPreamble();
/*      */         } else {
/* 1025 */           nextPart = this.multi.readBoundary();
/*      */         } 
/* 1027 */         if (!nextPart) {
/* 1028 */           if (this.currentFieldName == null) {
/*      */             
/* 1030 */             this.eof = true;
/* 1031 */             return false;
/*      */           } 
/*      */           
/* 1034 */           this.multi.setBoundary(this.boundary);
/* 1035 */           this.currentFieldName = null;
/*      */           continue;
/*      */         } 
/* 1038 */         FileItemHeaders headers = FileUploadBase.this.getParsedHeaders(this.multi.readHeaders());
/* 1039 */         if (this.currentFieldName == null) {
/*      */           
/* 1041 */           String fieldName = FileUploadBase.this.getFieldName(headers);
/* 1042 */           if (fieldName != null) {
/* 1043 */             String subContentType = headers.getHeader("Content-type");
/* 1044 */             if (subContentType != null && subContentType.toLowerCase(Locale.ENGLISH).startsWith("multipart/mixed")) {
/*      */ 
/*      */               
/* 1047 */               this.currentFieldName = fieldName;
/*      */               
/* 1049 */               byte[] subBoundary = FileUploadBase.this.getBoundary(subContentType);
/* 1050 */               this.multi.setBoundary(subBoundary);
/* 1051 */               this.skipPreamble = true;
/*      */               continue;
/*      */             } 
/* 1054 */             String fileName = FileUploadBase.this.getFileName(headers);
/* 1055 */             this.currentItem = new FileItemStreamImpl(fileName, fieldName, headers.getHeader("Content-type"), (fileName == null), getContentLength(headers));
/*      */ 
/*      */             
/* 1058 */             this.currentItem.setHeaders(headers);
/* 1059 */             this.notifier.noteItem();
/* 1060 */             this.itemValid = true;
/* 1061 */             return true;
/*      */           } 
/*      */         } else {
/* 1064 */           String fileName = FileUploadBase.this.getFileName(headers);
/* 1065 */           if (fileName != null) {
/* 1066 */             this.currentItem = new FileItemStreamImpl(fileName, this.currentFieldName, headers.getHeader("Content-type"), false, getContentLength(headers));
/*      */ 
/*      */ 
/*      */             
/* 1070 */             this.currentItem.setHeaders(headers);
/* 1071 */             this.notifier.noteItem();
/* 1072 */             this.itemValid = true;
/* 1073 */             return true;
/*      */           } 
/*      */         } 
/* 1076 */         this.multi.discardBodyData();
/*      */       } 
/*      */     }
/*      */     
/*      */     private long getContentLength(FileItemHeaders pHeaders) {
/*      */       try {
/* 1082 */         return Long.parseLong(pHeaders.getHeader("Content-length"));
/* 1083 */       } catch (Exception e) {
/* 1084 */         return -1L;
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public boolean hasNext() throws FileUploadException, IOException {
/* 1099 */       if (this.eof) {
/* 1100 */         return false;
/*      */       }
/* 1102 */       if (this.itemValid) {
/* 1103 */         return true;
/*      */       }
/*      */       try {
/* 1106 */         return findNextItem();
/* 1107 */       } catch (FileUploadIOException e) {
/*      */         
/* 1109 */         throw (FileUploadException)e.getCause();
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public FileItemStream next() throws FileUploadException, IOException {
/* 1125 */       if (this.eof || (!this.itemValid && !hasNext())) {
/* 1126 */         throw new NoSuchElementException();
/*      */       }
/* 1128 */       this.itemValid = false;
/* 1129 */       return this.currentItem;
/*      */     } }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static class FileUploadIOException
/*      */     extends IOException
/*      */   {
/*      */     private static final long serialVersionUID = -7047616958165584154L;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private final FileUploadException cause;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public FileUploadIOException(FileUploadException pCause) {
/* 1160 */       this.cause = pCause;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public Throwable getCause() {
/* 1170 */       return this.cause;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static class InvalidContentTypeException
/*      */     extends FileUploadException
/*      */   {
/*      */     private static final long serialVersionUID = -9073026332015646668L;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public InvalidContentTypeException() {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public InvalidContentTypeException(String message) {
/* 1201 */       super(message);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public InvalidContentTypeException(String msg, Throwable cause) {
/* 1214 */       super(msg, cause);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static class IOFileUploadException
/*      */     extends FileUploadException
/*      */   {
/*      */     private static final long serialVersionUID = 1749796615868477269L;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private final IOException cause;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public IOFileUploadException(String pMsg, IOException pException) {
/* 1242 */       super(pMsg);
/* 1243 */       this.cause = pException;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public Throwable getCause() {
/* 1253 */       return this.cause;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected static abstract class SizeException
/*      */     extends FileUploadException
/*      */   {
/*      */     private static final long serialVersionUID = -8776225574705254126L;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private final long actual;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private final long permitted;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     protected SizeException(String message, long actual, long permitted) {
/* 1287 */       super(message);
/* 1288 */       this.actual = actual;
/* 1289 */       this.permitted = permitted;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public long getActualSize() {
/* 1299 */       return this.actual;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public long getPermittedSize() {
/* 1309 */       return this.permitted;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public static class UnknownSizeException
/*      */     extends FileUploadException
/*      */   {
/*      */     private static final long serialVersionUID = 7062279004812015273L;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public UnknownSizeException() {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public UnknownSizeException(String message) {
/* 1346 */       super(message);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static class SizeLimitExceededException
/*      */     extends SizeException
/*      */   {
/*      */     private static final long serialVersionUID = -2474893167098052828L;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @Deprecated
/*      */     public SizeLimitExceededException() {
/* 1368 */       this(null, 0L, 0L);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @Deprecated
/*      */     public SizeLimitExceededException(String message) {
/* 1378 */       this(message, 0L, 0L);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public SizeLimitExceededException(String message, long actual, long permitted) {
/* 1391 */       super(message, actual, permitted);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static class FileSizeLimitExceededException
/*      */     extends SizeException
/*      */   {
/*      */     private static final long serialVersionUID = 8150776562029630058L;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private String fileName;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private String fieldName;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public FileSizeLimitExceededException(String message, long actual, long permitted) {
/* 1427 */       super(message, actual, permitted);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public String getFileName() {
/* 1437 */       return this.fileName;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void setFileName(String pFileName) {
/* 1447 */       this.fileName = pFileName;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public String getFieldName() {
/* 1457 */       return this.fieldName;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void setFieldName(String pFieldName) {
/* 1468 */       this.fieldName = pFieldName;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ProgressListener getProgressListener() {
/* 1479 */     return this.listener;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setProgressListener(ProgressListener pListener) {
/* 1488 */     this.listener = pListener;
/*      */   }
/*      */   
/*      */   public abstract FileItemFactory getFileItemFactory();
/*      */   
/*      */   public abstract void setFileItemFactory(FileItemFactory paramFileItemFactory);
/*      */ }


/* Location:              C:\Users\olatu\OneDrive\Documents\Calypso\syncbase\sync_base.jar!\BOOT-INF\lib\commons-fileupload-1.3.1.jar!\org\apache\commons\fileupload\FileUploadBase.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */