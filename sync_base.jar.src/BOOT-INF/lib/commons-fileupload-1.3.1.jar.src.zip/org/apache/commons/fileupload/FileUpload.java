/*    */ package org.apache.commons.fileupload;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FileUpload
/*    */   extends FileUploadBase
/*    */ {
/*    */   private FileItemFactory fileItemFactory;
/*    */   
/*    */   public FileUpload() {}
/*    */   
/*    */   public FileUpload(FileItemFactory fileItemFactory) {
/* 69 */     this.fileItemFactory = fileItemFactory;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public FileItemFactory getFileItemFactory() {
/* 81 */     return this.fileItemFactory;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setFileItemFactory(FileItemFactory factory) {
/* 91 */     this.fileItemFactory = factory;
/*    */   }
/*    */ }


/* Location:              C:\Users\olatu\OneDrive\Documents\Calypso\syncbase\sync_base.jar!\BOOT-INF\lib\commons-fileupload-1.3.1.jar!\org\apache\commons\fileupload\FileUpload.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */