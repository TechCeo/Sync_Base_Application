/*     */ package org.apache.commons.fileupload;
/*     */ 
/*     */ import java.io.PrintStream;
/*     */ import java.io.PrintWriter;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FileUploadException
/*     */   extends Exception
/*     */ {
/*     */   private static final long serialVersionUID = 8881893724388807504L;
/*     */   private final Throwable cause;
/*     */   
/*     */   public FileUploadException() {
/*  45 */     this(null, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public FileUploadException(String msg) {
/*  55 */     this(msg, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public FileUploadException(String msg, Throwable cause) {
/*  66 */     super(msg);
/*  67 */     this.cause = cause;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void printStackTrace(PrintStream stream) {
/*  77 */     super.printStackTrace(stream);
/*  78 */     if (this.cause != null) {
/*  79 */       stream.println("Caused by:");
/*  80 */       this.cause.printStackTrace(stream);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void printStackTrace(PrintWriter writer) {
/*  92 */     super.printStackTrace(writer);
/*  93 */     if (this.cause != null) {
/*  94 */       writer.println("Caused by:");
/*  95 */       this.cause.printStackTrace(writer);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Throwable getCause() {
/* 104 */     return this.cause;
/*     */   }
/*     */ }


/* Location:              C:\Users\olatu\OneDrive\Documents\Calypso\syncbase\sync_base.jar!\BOOT-INF\lib\commons-fileupload-1.3.1.jar!\org\apache\commons\fileupload\FileUploadException.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */