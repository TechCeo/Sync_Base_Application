package org.apache.commons.fileupload;

import java.util.Iterator;

public interface FileItemHeaders {
  String getHeader(String paramString);
  
  Iterator<String> getHeaders(String paramString);
  
  Iterator<String> getHeaderNames();
}


/* Location:              C:\Users\olatu\OneDrive\Documents\Calypso\syncbase\sync_base.jar!\BOOT-INF\lib\commons-fileupload-1.3.1.jar!\org\apache\commons\fileupload\FileItemHeaders.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */