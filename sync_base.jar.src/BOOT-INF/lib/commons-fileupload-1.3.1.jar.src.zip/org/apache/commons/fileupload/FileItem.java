package org.apache.commons.fileupload;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.Serializable;
import java.io.UnsupportedEncodingException;

public interface FileItem extends Serializable, FileItemHeadersSupport {
  InputStream getInputStream() throws IOException;
  
  String getContentType();
  
  String getName();
  
  boolean isInMemory();
  
  long getSize();
  
  byte[] get();
  
  String getString(String paramString) throws UnsupportedEncodingException;
  
  String getString();
  
  void write(File paramFile) throws Exception;
  
  void delete();
  
  String getFieldName();
  
  void setFieldName(String paramString);
  
  boolean isFormField();
  
  void setFormField(boolean paramBoolean);
  
  OutputStream getOutputStream() throws IOException;
}


/* Location:              C:\Users\olatu\OneDrive\Documents\Calypso\syncbase\sync_base.jar!\BOOT-INF\lib\commons-fileupload-1.3.1.jar!\org\apache\commons\fileupload\FileItem.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */