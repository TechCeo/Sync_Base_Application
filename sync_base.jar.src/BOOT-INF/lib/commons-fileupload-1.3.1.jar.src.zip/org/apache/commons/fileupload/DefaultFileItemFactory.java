/*     */ package org.apache.commons.fileupload;
/*     */ 
/*     */ import java.io.File;
/*     */ import org.apache.commons.fileupload.disk.DiskFileItemFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Deprecated
/*     */ public class DefaultFileItemFactory
/*     */   extends DiskFileItemFactory
/*     */ {
/*     */   @Deprecated
/*     */   public DefaultFileItemFactory() {}
/*     */   
/*     */   @Deprecated
/*     */   public DefaultFileItemFactory(int sizeThreshold, File repository) {
/*  74 */     super(sizeThreshold, repository);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public FileItem createItem(String fieldName, String contentType, boolean isFormField, String fileName) {
/* 103 */     return (FileItem)new DefaultFileItem(fieldName, contentType, isFormField, fileName, getSizeThreshold(), getRepository());
/*     */   }
/*     */ }


/* Location:              C:\Users\olatu\OneDrive\Documents\Calypso\syncbase\sync_base.jar!\BOOT-INF\lib\commons-fileupload-1.3.1.jar!\org\apache\commons\fileupload\DefaultFileItemFactory.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */