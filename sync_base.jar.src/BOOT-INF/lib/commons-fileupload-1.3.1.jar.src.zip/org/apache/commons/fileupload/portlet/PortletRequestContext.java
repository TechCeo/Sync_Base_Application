/*     */ package org.apache.commons.fileupload.portlet;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import javax.portlet.ActionRequest;
/*     */ import org.apache.commons.fileupload.UploadContext;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PortletRequestContext
/*     */   implements UploadContext
/*     */ {
/*     */   private final ActionRequest request;
/*     */   
/*     */   public PortletRequestContext(ActionRequest request) {
/*  55 */     this.request = request;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getCharacterEncoding() {
/*  67 */     return this.request.getCharacterEncoding();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getContentType() {
/*  76 */     return this.request.getContentType();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public int getContentLength() {
/*  87 */     return this.request.getContentLength();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public long contentLength() {
/*     */     long l;
/*     */     try {
/*  99 */       l = Long.parseLong(this.request.getProperty("Content-length"));
/* 100 */     } catch (NumberFormatException e) {
/* 101 */       l = this.request.getContentLength();
/*     */     } 
/* 103 */     return l;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public InputStream getInputStream() throws IOException {
/* 114 */     return this.request.getPortletInputStream();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 124 */     return String.format("ContentLength=%s, ContentType=%s", new Object[] { Long.valueOf(contentLength()), getContentType() });
/*     */   }
/*     */ }


/* Location:              C:\Users\olatu\OneDrive\Documents\Calypso\syncbase\sync_base.jar!\BOOT-INF\lib\commons-fileupload-1.3.1.jar!\org\apache\commons\fileupload\portlet\PortletRequestContext.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */