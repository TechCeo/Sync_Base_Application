/*    */ package org.apache.commons.fileupload.util.mime;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class ParseException
/*    */   extends Exception
/*    */ {
/*    */   private static final long serialVersionUID = 5355281266579392077L;
/*    */   
/*    */   public ParseException(String message) {
/* 35 */     super(message);
/*    */   }
/*    */ }


/* Location:              C:\Users\olatu\OneDrive\Documents\Calypso\syncbase\sync_base.jar!\BOOT-INF\lib\commons-fileupload-1.3.1.jar!\org\apache\commons\fileuploa\\util\mime\ParseException.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */