package javax.inject;

public interface Provider<T> {
  T get();
}


/* Location:              C:\Users\olatu\OneDrive\Documents\Calypso\syncbase\sync_base.jar!\BOOT-INF\lib\javax.inject-1.jar!\javax\inject\Provider.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */